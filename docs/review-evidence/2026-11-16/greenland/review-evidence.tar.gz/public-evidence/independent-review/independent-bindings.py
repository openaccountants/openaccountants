import json,hashlib,re,subprocess,html
from pathlib import Path
from decimal import Decimal as D
from datetime import date,timedelta
R=Path('/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-resume-2026-11-16');E=R/'evidence-greenland';W=R/'wt-greenland';O=R/'review-greenland'
h=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *args:subprocess.check_output(['git','-C',str(W),*args])
head=git('rev-parse','HEAD').decode().strip();base=json.loads((E/'COMMIT-RECEIPT.json').read_text())['base'];assert head=='a05382212754a9c48a8ee30fd6c7d1db20f46741';assert not git('status','--porcelain')
manifest=json.loads((E/'FINAL-MANIFEST.json').read_text()); failures=[]
for a in manifest['artifacts']:
 p=E/a['path'];assert h(p.read_bytes())==a['sha256'],a['path']
files={}
for f,a in manifest['candidate_files'].items():
 b=(W/f).read_bytes();orig=git('show',base+':'+f);assert h(b)==a['sha256'];assert b==git('show',head+':'+f)
 oldlocal=E/'recovered-15nov-preparation/originals'/Path(f).name;assert oldlocal.read_bytes()==orig
 files[f]={'base_sha256':h(orig),'candidate_sha256':h(b),'unchanged':orig==b}
 for field in ['name','jurisdiction','tax_year','category','license','tier','reviewed_by','reviewed_on','verified_by','approved_by','author','written_by']:
  match=lambda t:re.findall(r'^'+field+r':.*$',t.decode().split('---',2)[1] if t.startswith(b'---') else '',re.M)
  assert match(orig)==match(b),(f,field)
 assert not re.search(r'^reviewed_by:|^tier: 1',b.decode(),re.M)
oldrows=0;destinations=0
for pack in json.loads((E/'OLD-LINE-DESTINATIONS.json').read_text()):
 old=(E/'recovered-15nov-preparation/originals'/pack['file']).read_text().splitlines();new=(W/'skills/greenland'/pack['file']).read_text().splitlines()
 assert set(r['old_line'] for r in pack['lines'])==set(i for i,s in enumerate(old,1) if s.strip())
 for r in pack['lines']:
  oldrows+=1;assert r['old_text']==old[r['old_line']-1];assert h(r['old_text'].encode())==r['old_line_sha256']
  for d in r['destinations']:
   destinations+=1;payload='\n'.join(new[d['lines'][0]-1:d['lines'][1]]);assert payload==d['payload'];assert h(payload.encode())==d['payload_sha256']
items=json.loads((E/'CANDIDATE-ITEMS.json').read_text());assert len(items)==176
for r in items:
 t=(W/'skills/greenland'/r['file']).read_text().splitlines()[r['line']-1];assert t==r['text'];assert h(t.encode())==r['sha256']
C=R/'evidence-greenland-binding-correction-a05382212'
cm=json.loads((C/'FINAL-MANIFEST.json').read_text())
for a in cm['artifacts']:
 assert h((C/a['path']).read_bytes())==a['sha256'],a['path']
ledger=json.loads((C/'RULE-LEDGER-CORRECTED.json').read_text());oldledger=json.loads((E/'RULE-LEDGER.json').read_text());anchors=[]
delta=[]
for old,new in zip(oldledger,ledger):
 assert {k:v for k,v in old.items() if k!='sources'}=={k:v for k,v in new.items() if k!='sources'}
 for os,ns in zip(old['sources'],new['sources']):
  if os!=ns:delta.append((old['id'],os['source_id']));assert os['source_id']==ns['source_id']=='B'
assert delta==[('Q01','B'),('Q02','B'),('Q09','B'),('Q16','B')]

def norm(t):
 t=html.unescape(t);t=re.sub(r'<[^>]*>',' ',t);t=re.sub(r'^L\d+(?:@P\d+)?:\s*','',t,flags=re.M);return ' '.join(t.split())
for r in ledger:
 new=(W/r['file']).read_text().splitlines();payload='\n'.join(new[r['candidate_lines'][0]-1:r['candidate_lines'][1]]);assert payload==r['payload'];assert h(payload.encode())==r['payload_sha256']
 for s in r['sources']:
  p=E/s['capture_path'];assert h(p.read_bytes())==s['capture_sha256'];q=s['quote_exact_native'];assert h(q.encode())==s['quote_sha256']
  text=p.read_text(errors='replace') if p.suffix!='.pdf' else (E/'sources/finance-annex2.txt').read_text()
  good=bool(q) and norm(q) in norm(text)
  anchors.append({'group':r['id'],'source':s['source_id'],'provision':s['act_article'],'quote_nonempty':bool(q),'normalized_native_match':good})
  if not good:failures.append(anchors[-1])
calc=[D(125000)*D('.09')*0,D('.09')*(D(150000)-125000)/50000,D(150000)*D('.045'),D(175000)*D('.09'),D(300000)*D('.09'),D(300000)*D('.09'),D(300000)*D('.09')-20000,D(100000)*D('.019'),D(100000)*D('.019')+32000]
assert calc==list(map(D,['0','.045','6750','15750','27000','27000','7000','1900','33900']))
assert date(2026,10,10).weekday()==5 and date(2026,11,1).weekday()==6
assert date(2026,10,10)+timedelta(days=2)==date(2026,10,12);assert date(2026,11,1)+timedelta(days=1)==date(2026,11,2)
result={'head':head,'base':base,'writer_manifest_sha256':h((E/'FINAL-MANIFEST.json').read_bytes()),'writer_artifacts_verified':len(manifest['artifacts']),'files':files,'complete_old_populated_lines':oldrows,'literal_destination_spans_verified':destinations,'candidate_items_verified':len(items),'ledger_groups':len(ledger),'native_bindings':len(anchors),'native_binding_issues':failures,'corrected_writer_manifest_sha256':h((C/'FINAL-MANIFEST.json').read_bytes()),'corrected_bindings_only':delta,'case_outputs':list(map(str,calc)),'conditional_calendar':'2026-10-12 / 2026-11-02 weekend-only; no holidays/notice clearance','changed_files':git('diff','--name-only',base,head).decode().splitlines()}
(O/'independent-bindings.json').write_text(json.dumps(result,indent=2)+'\n');(O/'native-binding-results.json').write_text(json.dumps(anchors,indent=2)+'\n');print(json.dumps(result,indent=2))
