# Gate invocation and source-reading limits

The initial changed-only validation and calculator commands ran before the candidate was committed and saw zero changed guides. Those zero-file outputs are retained and are not acceptance. The committed candidate was then checked with both guides selected.

The initial `--mode sync --worktree --strict-metadata` command lacked provenance and failed. A subsequent unverified revision0 fixture produced a mechanically passing exporter-sync output. That fixture was not based on persisted platform state and is explicitly retired as `UNVERIFIED-REVISION-FIXTURE-NOT-FOR-SYNC.json`; its stdout is `sync-unverified-fixture-NOT-ACCEPTANCE.log`. Neither is acceptable production provenance or a completed strict-sync gate. No database was read or written.

The correct public repository gate is `python scripts/check-sync-integrity.py --base origin/main --head HEAD --mode audit --strict-metadata`, as the script docstring lines2–7 and `.github/workflows/sync-integrity.yml` lines58–62/68–72 expressly provide. It passes for2guides with0errors/0warnings/0notices. Production exporter sync has not been performed and is not asserted.

The stock figure check read6amount-bearing rows with0MISS/0UNREADABLE; date-only rows are not in that population, and numeric appearance is not legal/source-condition verification. The candidate's complete41group native-rule ledger and independent review are separate requirements. The3oa-check blocks cover all6original numeric scenarios and9expected outputs; the original calendar example is separately recomputed and explicitly conditional.

A first draft standard run found missing per-case table URLs and explicit Not yet confirmed lines; both were fixed before committed validation. Final standard19/19each. No full Python suite repeated for content changes. Required hosted CI remains for the publication coordinator.
