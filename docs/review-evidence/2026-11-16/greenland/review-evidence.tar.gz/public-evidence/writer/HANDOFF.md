# Greenland two-guide writer handoff

Frozen clean head `a05382212754a9c48a8ee30fd6c7d1db20f46741` on `world/codex-greenland-2026-11-16`, fetched main/base `bbab4f1a6d82cace432e6ca8eda89c98ffb1c038`. Only `skills/greenland/gl-mandatory-pension.md` and `skills/greenland/gl-payroll-ama.md` changed. Both versions 0.2→0.3. README is byte unchanged; names, tax year, licence, tier and absent approval/author fields are exact. No professional approval or country completeness is claimed. No push, PR, merge or production action.

## Recovery before new reading

`PRIOR-READ-SCOPE-RECEIPT.json` and `recovered-15nov-preparation/` preserve the completed 15 November actual primary reads and original dates. Allthree current main country originals matched those exact baseline bytes. That checkpoint contained preparation only: no finished Greenland draft, ledger, cases or independent review was found. Completed native pension/AMA/employer-register/Sulinal-notice reads were reused once for the same unchanged rules. No fresh 16 November read of those whole unchanged sources is claimed.

New bounded reads close the actual enacted 2026 budget note (Finance Act 85 s 2 plus its actual Annex 2 attachment, p 40 account 24.11.22), pension-payment cross-references in income-law 39–41/47 b, actual A-tax 81 reporting/payment clauses, and current public monthly/annual instructions. The Annex 2 operative page was actually viewed as an image; its forarbejder URL alone was not treated as enactment. No claim to read all 137 pages or the entire income-tax law. The source catalog gives 13 actual scoped bodies with exact hashes and dates.

## Corrected or made precise

| Topic | Final behavior and authority |
|---|---|
| Standard/type | Pension is a bounded computation with 2 recomputing blocks; employer guide is filing-howto with 1 recomputing block, canonical method, public fields/routes, response evidence and explicit stopping conditions. |
|2026 pension | Keeps 9%ordinary rate after Act 19, separate 6%profit/tapers and 200 kcessation, with exact age/scheme/base/conversion/civil-service/collection conditions. Temporary foreign permission is at most 2 income years, including the expected-stay condition. |
|2026 private AMA | Keeps 1.9% and corroborates the 0.0%supplement with the actual enacted Finance Act 85/Annex 2 p 40, not only the Sulinal notice. No projection into 2027. |
|Pension integration | Mandatory-pension scheme eligibility does not automatically satisfy AMA exclusions under income-law 39/40/47 b(6). No automatic Danish-pension deduction. Unclassified payments stop the base calculation. |
|Report/payment | Actual income-law 81 independently establishes the A-tax sequence; AMA 42 ss 3–6 controls AMA. Deadline rolls/special notices are adjacent. Return acknowledgement is not payment proof. |
|Unread manual | September 2026 PDF remains unread after ordinary access failure. Its nil-report assertion is explicitly unusable; publication announcement proves a link, not its content. Original July 2025 manual 2.1%example retained as unverified historical warning. |

## Full no-loss and case populations

`RULE-LEDGER.json` and `ledgers/<slug>.md` cover 41 current groups with 102 exact native quote/hash bindings, complete candidate payloads and actual source scopes. `CANDIDATE-ITEMS.json` classifies every 176 populated candidate line. This writer ledger is not independent approval. The reviewer should read all 41 groups and the complete relevant native provisions/neighbors, not treat a snippet or hash as a completed legal read.

`OLD-LINE-DESTINATIONS.json` maps every 67 old populated lines (102 total original lines) with full current destination payloads and semantic dispositions. `OLD-TOPIC-DESTINATIONS.json` covers all 11 original headings. Allold rules, refusals, questions, source history and numeric inputs are retained or explicitly restricted. No topic moved to another file.

All 6 original numeric scenarios are retained in 3 oa-check blocks with 9 expected outputs: four ordinary pension bases; the 300 k/20 kcontribution remainder; the 100 kAMA/32 kassumed A-tax reconciliation. The originalSeptember 2026 calendar example is also preserved and recomputed, explicitly conditional on the unverified holiday calendar and accelerated notice. No original oa-check block existed. `CASE-INPUTS-AND-RECOMPUTATION.json` includes manual arithmetic/eligibility; required interpreter pass is separate. The 32 kA-tax figure remains an assumption, not a flat tax rate.

## Removed and why / Moved / Not moved

No legal topic or original input was silently removed. The inaccessible manual's nil-report assertion is moved into an explicit nonusable hold; its A-tax dates are corroborated by actual 81 instead. The original source-access 22 October history is retained in the snapshot and source-history text; completed 15 November dates are not renewed. Method material moves under canonical headings, with actual scheme/base conditions beside computations. No legal rule moves to README or another country file; README remains unchanged. No contributor name or approval is added or changed.

## Genuine limits

Pension actual-fact holds remain for age/full taxability, income exclusions/civil-service benefits, scheme permission, pre-tax conversion, mixed income and historical differences. The guide does not supply an unverified combined-income formula or fixed pension age. Contractual promises remain separate.

Payroll does not compute residence, card allowances/net pay, pensions, benefits, holiday-pay timing, gross scheme, combined Danish withholding or late interest. Private fields/submission/payment were not tested. The calendar dates are weekend-only illustrations. The nil-return rule cannot be used until actual authority evidence is obtained; the public page's no-employees contact instruction does not close that separate rule. These are bounded gaps, not a declaration that the entire country is unusable.

## Targeted checks and honest invocation history

Final standard 19/19 each and changed-only validation 2 guides/0 warnings. Required examples:2 files/3 blocks/0 failures. Calculator quotes pass. Live row check:4 pension+2 payroll amount-bearing rows,0 MISS/0 UNREADABLE; date-only rows and legal exceptions are outside that stock check. Exact case/pre-worked amount-table continuity binds those applicable earlier results to this final head without a repeated network/full suite.

The actual required public gate passes: `python scripts/check-sync-integrity.py --base origin/main --head HEAD --mode audit --strict-metadata`,2 source guides,0 errors/0 warnings/0 notices. This follows the script's public-audit contract and `.github/workflows/sync-integrity.yml`58–62/68–72. No persisted platform revision is asserted. The initial private-exporter sync invocation failed for missing provenance; a subsequent unverified 0 fixture and its stdout are retained explicitly NOT-ACCEPTANCE, not passed provenance evidence. See `SETUP-AND-CHECK-LIMITS.md`. No database access or production sync occurred. Initial zero-file precommit checks likewise are not acceptance.

`SOURCE-LIMITS.json` also records an early unanchored section 81 extract that selected a cross-reference in interest-tax 36 e. That unused fragment remains historical; the actual heading-anchored payroll 81 body was subsequently read in full with its neighbors and is separately saved. No candidate rule relies on the misleading extract.

This packet is ready for one fresh independent country review of the two assigned guides and explicit dependencies. Full Python suite was not repeated for content changes; required hosted CI remains with the publication coordinator.
