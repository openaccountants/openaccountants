# Bahrain VAT row-source diagnostic reconciliation

The unchanged repository diagnostic checked 4 numeric table rows and reported 3 MISS entries, 0 UNREADABLE entries. Its actual output remains `row-sources.log`. No script or statutory value was changed to evade this result. All three misses arise because the official Arabic regulation spells out the amounts in words. The rule ledger binds the actual full Arabic bodies and neighboring conditions.

| Miss | Ledger ID | Actual official native form | Read body and explanation |
|---|---|---|---|
| Mandatory BHD 37,500 | B007; B006/B008/B009 for conditions | `سبعة وثلاثون ألف وخمسمائة دينار` | Resolution12/2018 art33(a), actual `cache/reg.html` and `cache/reg.txt`, https://www.lloc.gov.bh/Legislation/HTM/RFNE1218. This is thirty-seven thousand five hundred dinars. Art29 of the Law supplies rolling tests rather than printing this figure numerically |
| Voluntary BHD 18,750 | B012; B013 for supplies/expenses tests | `ثمانية عشر ألف وسبعمائة وخمسين دينار` | Resolution12/2018 art44(a), same official Arabic body. This is eighteen thousand seven hundred fifty dinars. Law art33 supplies the actual/forecast supply-or-expense tests |
| Monthly threshold BHD 3,000,000 | B014; B015 for assigned-period exceptions | `ثلاثة ملايين دينار` | Resolution12/2018 art48(a), same official Arabic body. This is three million dinars. Monthly exceeds this value; quarterly does not exceed it, subject to NBR adjustment/approval |

Actual source read date: 2026-11-16. The independent reviewer must check these bindings, not accept a parser failure as proof either way. The dates, standard-rate amendment, documentary conditions and image-only dated return numbering are separately ledgered; this narrow parser does not claim to verify every legal rule or every form image.
