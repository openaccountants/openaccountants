# Bahrain VAT complete predecessor destination map

Original guide SHA256 `6841e3f37c129e45038f02735e4901bc28f2755a7cf5ec722b60409bd96d8d48`; candidate SHA256 `fe5f506b452e22c9d65362705b3f93367b76c4c733e6f7873d4de02a1932f640`. Original is the exact main/base VAT file, 356 lines. The local exact snapshot is cache/original-bahrain-vat.md; all original case input lines are unchanged in the candidate. All old topics are retained, corrected or explicitly NON-USABLE. No source or accountant attestation is inferred from the earlier five-Guide country review.

| Original lines | Topic and preserved inputs | Candidate destination | Disposition / reason |
|---|---|---|---|
| 1–13 | Identity and metadata | Frontmatter / title | 2026;2.1;tax/situation-rules;same name,jurisdiction,licence,tier; no reviewed_by |
| 15–21 | Bahrain scope | Scope | Retained |
| 22–25 | Rates/zero/exempt | Scope quick reference; classify actual supply | Rate retained; construction and local transport corrected; complete category conditions |
| 26–29 | NBR electronic return,portal,authority,BHD | Scope and Filing and payment | Retained with current portal access hold |
| 30–33 | Filing periods,deadline,registration37500/18750 | Scope; registration; filing | Retained with assigned-period exceptions, rolling tests and expense eligibility |
| 34–34 | Primary legislation | Scope quick reference; Sources | Law33/2021 corrects predecessor Resolution33 misidentification |
| 35–35 | Contributor credit | Scope: Contributor | Open Accounting Skills Registry | Value retained exactly; no named credit touched |
| 36–37 | Pending validation / April research date | Sources and evidence | Replaced stale researchdate with actual16Novreads; independentreview still pending |
| 39–48 | All six conservative defaults | Ask the client first, final paragraph | Each unknown rate/purchaseVAT/country/GCCstatus/businessuse/block nowexplicitfacthold; do not invent domestic or10% |
| 50–54 | Fullperiod bankCSV/PDF/paste; NBB,BBK,AhliUnited,BisB,SICO,AlBaraka,Ithmaar,anybank | Ask the client first | All formats and banknames retained |
| 56–58 | Sales/purchaseinvoices,VATreg,register,priorreturn,credit | Ask the client first / input recovery | All retained; oldBHD50evidencecutoff rejected and recorded Sources |
| 60–60 | No statementstop; bankonlysoftwarning exactsentence | Ask the client first: Document policy | Warning retained; bankonlytriage notfiling-ready; equivalentcompleteledgerworkflow permitted |
| 62–66 | Three refusals R-BH-1/2/3 | When to refuse or refer | All triggers retained; groupconsolidation and upstreamspecialist boundaries; partialexemption condition corrected |
| 68–70 | Case-insensitive pattern match/fallthrough | Supplier pattern library | Retained asinvestigationleads; unmatchedactualsupplyrules |
| 72–83 | Banks NBB/NATIONALBANK,BBK,AHLI/AUB,BISB/ALSALAM,ALBARAKA/ITHMAAR,INTEREST/LOAN/REPAYMENT | Supplier pattern library firsttwo rows | Allactualpatternnamesretained; explicitfees taxable vs exemptmargin; splitprincipal |
| 85–96 | NBR,LMRA,SIO,MOIC,CUSTOMS,TAMKEEN andfullnames | Supplier pattern library government/customs rows | Allretained; governmentname notblanketexclude; taxlevygrantvsbusinesssupply; importVATevidence |
| 98–105 | EWA/ELECTRICITYANDWATER;BATELCO/STCBAHRAIN/ZAIN | Supplier pattern library utilities | Allretained; actualplace/invoiceconfirmed |
| 107–115 | GOOGLE/MICROSOFT/ADOBE/META/AWS/AMAZONWEBSERVICES/ZOOM/SLACK/NOTION/ANTHROPIC/OPENAI | Supplier pattern library digital | Allretained; actualbillingestablishmentreplacesbrand/residencyguess |
| 117–123 | SOLIDARITY/AXABAHRAIN/GIGBAHRAIN | Supplier pattern library insurance | Allretained; lifeexemptversusgeneralstandard |
| 125–134 | SALARY/WAGES/PAYROLL/GOSI/SOCIALINSURANCEORGANIZATION/OWNTRANSFER/INTERNAL/DIVIDEND | Supplier pattern library payroll/transfers | Allretained; genuinenonsupplyvsagencycharge |
| 136–148 | Original example1 exactline USD16.00/BHD6.03,05.01.2026,NOTIONLABSINC,DEBIT,Monthlyplan;oldVAT0.60 | Workedcases originalexample1 and oa-check | Allinputbytesretained; BHDtaxpointconversionassumptionexplicit;0.603output/input;netnilfullrecovery; old0.60displayreconciled |
| 150–160 | Original example2 exactline10.01.2026,ALJAZEERATRADING,CREDIT,Invoice2026-001,+5000.00BHD;500VAT | Workedcases originalexample2 and oa-check | Allinputbytesretained; originalnetassumption500VAT kept; gross5000alternative454.545VAT; bankreconciliationrequired |
| 162–172 | Original example3 exactline15.01.2026,GULFHOTELBAHRAIN,DEBIT,Clientdinner,-250.00BHD;net250/recovery0 | Workedcases originalexample3 and oa-check | Allinputbytesretained; grosscost250 vsVATexclusive227.273/embedded22.727; blocked0; correctReg58replacesunverifiedOrder14/2019 |
| 174–178 | Defaultstandard10% | Classify actual supply | Amendedart3replaceswrongart56citation; actualtaxablegoods/services |
| 180–182 | Exportgoods/services,intltransport,newresidential3years,food,health,education,oilgas,freezones | Classify actual supply; Sources oldclaims | Alltopicsretained; 3yearfirstsale rejected; constructionseparate; actualcustomssuspensionconditions notfreezoneblanket; correctarts53andReg67–80 |
| 184–186 | Financeinterest/forex,bareland,localtransport,residentialrental,lifeinsurance | Classify actual supply and EC5/EC6 | Allretained; localtransportzero withconditions; realestatecommercialincluded; explicitfeesexception |
| 188–190 | SA,UAE,OM,KW,QA status;GCCsales/services/imports | GCC transition; Sources recognitionhold | Allfivecountriesretained; nootherImplementingStateinactualMarchNBR; postMarchnoticeheld; servicesownplacerules |
| 192–210 | Old output boxes1–11 and formulas | Sources non-usable predecessor formhistory; datedformrouting | Allnumbers/descriptions/formulasretained asrejectedhistory; actualimagefieldsmappedwithcurrentUIhold |
| 212–223 | Old input boxes12–17 andformula | Sources non-usable predecessor formhistory; inputrecovery and datedformrouting | Allretained asrejectednumbering; actualblocked/apportionedinputworkingpaperretained |
| 225–233 | Old netboxes18–20/netcreditformulas | Sources non-usable predecessor formhistory; returnreconciliation | Alloldinputs/formulasretainednonusable; actualoutputlessinput+corrections/credit computation |
| 235–239 | ImportedservicesRCoutput10/input14/netzero | Reverse charge; originalexample1; test3 | Alllegsretained; wrongboxes/art34replacedactualart4/inputconditions; netnilconditional |
| 241–243 | Goodsimports10%CIF+duty/customs/input | Reversechargeandgoodsimports | Customsvalue+excise+duty+othercharges; Customscollection/approveddeferral; importerproof |
| 245–247 | GCCimportsRCversusordinaryimports | GCC transition | IncorrectblanketRCremoved; datedconfirmedordinaryimports; laterrecognitionheld |
| 249–253 | Blockedvehicles/taxi/carhire/drivinginstruction/dealerstock;entertainment/private/club/noinvoice | Inputrecoveryblockedtable; Sources vehiclehold | Alltopicsretained; businessportionactualReg58, specifictaxi/rentalexceptions; drivinginstruction/dealerstockstandaloneexceptionsheldexplicitly; missingevidencevspermanentblock |
| 255–259 | Partialexemptionratio taxable/total*100;NBRagreement | Input recovery partial exemption | Ratio retainedwithdirectattribution,exclusions,1dp,annualtrueup; ordinarymethodnotapproval; specialapproval |
| 261–269 | Monthlyquarterlyendnextmonthreturns/payment | Scope and Filing and payment | Allretainedwithassignedperiodexceptions |
| 271–281 | Oldpenalties500minimum/5%monthly/5000–10000/1000–5000/evasion10000minimum | Filing: Penalties and interest; Sources oldclaims | EachreplacedactualLaw60/63/64; exactrejectedvaluespreservedinthismapandoriginalsnapshot |
| 283–287 | EC1AWSUS/noVAT/RC10/netzero/old10and14boxes | Boundary EC1; reversecharge; datedformrouting; oldhistory | Allfactsretained; liabilityandfullrecoveryconditional |
| 289–289 | EC2BahrainmanufacturergoodstoOman/oldBox4 | Boundary EC2; GCCtransition; datedformrouting | Allfactsretained; documentation/currentstatuscondition; oldboxnumberhistory |
| 291–291 | EC3director sedan/privateVATfullcost | Boundary EC3; blockedvehicle row | Retainedwithactualbusiness/privateanalysis |
| 293–293 | EC4goodstoQatar | Boundary EC4; GCCtransition | Retainedwithactualexportevidenceanddatedrecognitionhold |
| 295–295 | EC5newapartmentwithin3years/zero/input | Boundary EC5; constructionvsrealestate | Allinputfactsretained; outcome correctedexemptsale vszeroconstruction |
| 297–297 | EC6bankinterestexempt/noinput | Boundary EC6 and test6 | Retained |
| 299–299 | EC7consultingandexemptfinancialadvisory | Boundary EC7; partialexemption | Advisoryfeesnotautomaticallyexempt; genuineexemptactivitiestriggerapportionment |
| 301–301 | EC8returnedgoodscreditnote/issuemonth | Boundary EC8; creditnotesparagraph | Bothpartiesadjust; legalcommercialevent/discoveryrulesratherthanlateissuedate |
| 303–305 | Test1goods10000net/output1000 | Workedcases originalsix/oa-check | Allinputsandexpectedresultpreserved |
| 307–307 | Test2localsupplies5000+500/input500 | Workedcases originalsix/oa-check | Allinputsandexpectedresultpreservedwithtaxableuse/evidence |
| 309–309 | Test3UKIT2000/noVAT/output200/input200/net0 | Workedcases originalsix/oa-check | AllinputsandexpectedresultpreservedwithBahrainplaceandfullrecovery |
| 311–311 | Test4goodsexport50000/zero/inputrecovery | Workedcases originalsix/oa-check | Allinputsandexpectedresultpreservedwithqualifiedexportcondition |
| 313–313 | Test5clientdinner300+30/input0 | Workedcases originalsix/oa-check | Allinputsandexpectedresultpreserved |
| 315–315 | Test6bankinterest100000/exempt/noVAT/noinput | Workedcases originalsix/oa-check | Allinputsandexpectedresultpreserved; exemptionnotzerotaxablesupply |
| 317–335 | T2reviewerflag transaction/issue/options/recommended/action; T3stoprefer | When to refuse or refer fourthbullet | Allfields,tiersandrefusalintentpreserved inprose |
| 337–342 | OutscopeCIT0/noCIT;PITnone;SS12/7and3/1;excise100/100/50 | When to refuse/directtaxrouter; Sources non-usablepredecessorclaims | AlltopicsandoldratespreservedNON-USABLE; routeowners; notcurrentVATfindings |
| 344–346 | Prohibitionratesother10/0/exempt | Completion checklist | Currentratesretained; blanketbanunsafehistoricaladjustments |
| 347–348 | Noblockedinput/noignoreRC | Completion checklist | Retained |
| 349–349 | NeverKW/QAimplementing | GCCtransition/currentrecognitionhold | QualifiedtoactualNBRrecognitionposition,allGCCstates |
| 350–350 | Nevercomputenumber/engine | Completion checklist/oa-checks | Engineworkflowretained; recomputationrequired,notblanketban |
| 351–352 | Checkpriorcredit andvalidVATreginvoice | Completion checklist; input recovery | Retainedwithproperinvoice/customsexceptions |
| 354–356 | Disclaimer/generalreference/review/no liability | End Completion checklist before Sources | MeaningretainedwithstandardGuidewarning |

## Exact original case input strings

- `05.01.2026 ; NOTION LABS INC ; DEBIT ; Monthly plan ; USD 16.00 ; BHD 6.03`
- `10.01.2026 ; AL JAZEERA TRADING ; CREDIT ; Invoice 2026-001 ; +5,000.00 ; BHD`
- `15.01.2026 ; GULF HOTEL BAHRAIN ; DEBIT ; Client dinner ; -250.00 ; BHD`

## Original box-by-box mapping, all NON-USABLE

All former box numbers remain in Sources as rejected history. This table maps the intended working-paper topic rather than authorizing the old numbering.

| Old box | Intended topic | New destination |
|---|---|---|
| 1 | Standard rated sales (10%); Domestic taxable supplies | Return reconciliation; dated image routing; Sources old mapping hold |
| 2 | Sales to GCC registered customers; Intra-GCC taxable | Return reconciliation; dated image routing; Sources old mapping hold |
| 3 | Zero-rated domestic sales; Healthcare, education, new buildings, foodstuffs | Return reconciliation; dated image routing; Sources old mapping hold |
| 4 | Zero-rated exports; Exports outside Bahrain/GCC | Return reconciliation; dated image routing; Sources old mapping hold |
| 5 | Exempt sales; Financial, land, residential rental | Return reconciliation; dated image routing; Sources old mapping hold |
| 6 | Total sales; Sum | Return reconciliation; dated image routing; Sources old mapping hold |
| 7 | Output VAT on standard rated; 10% of Box 1+2 | Return reconciliation; dated image routing; Sources old mapping hold |
| 8 | Adjustments to output; Credit notes | Return reconciliation; dated image routing; Sources old mapping hold |
| 9 | VAT on imports (goods); Customs VAT | Return reconciliation; dated image routing; Sources old mapping hold |
| 10 | VAT on imports (services); Reverse charge output | Return reconciliation; dated image routing; Sources old mapping hold |
| 11 | Total output VAT; 7+8+9+10 | Return reconciliation; dated image routing; Sources old mapping hold |
| 12 | Standard rated purchases; Local purchases with VAT | Return reconciliation; dated image routing; Sources old mapping hold |
| 13 | Imports (goods); From customs entries | Return reconciliation; dated image routing; Sources old mapping hold |
| 14 | Imports (services); Reverse charge input | Return reconciliation; dated image routing; Sources old mapping hold |
| 15 | Total input VAT; Sum of allowable input | Return reconciliation; dated image routing; Sources old mapping hold |
| 16 | Adjustments; Blocked items, apportionment | Return reconciliation; dated image routing; Sources old mapping hold |
| 17 | Allowable input VAT; 15 minus 16 | Return reconciliation; dated image routing; Sources old mapping hold |
| 18 | Net VAT; 11 minus 17 | Return reconciliation; dated image routing; Sources old mapping hold |
| 19 | Credit brought forward; Prior period | Return reconciliation; dated image routing; Sources old mapping hold |
| 20 | Net payable / (refundable); 18 minus 19 | Return reconciliation; dated image routing; Sources old mapping hold |

## Removed and why

No substantive topic or original case input was removed. The original definitive wrong classifications, invented form numbering, unsupported penalty amounts and out-of-scope rates were replaced or explicitly held. Redundant decorative headings were consolidated into the canonical method shape. Source dates and tax year/version were advanced on actual work. All refusal classes, investigation patterns, original monetary inputs, outputs requiring correction, old vehicle exception topics, professional escalation fields and contributor credit are accounted for above.

Old words: 2788; candidate words: 5592; reduction: 0.0%. No greater-than25% reduction.
