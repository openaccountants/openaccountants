# Bahrain VAT independent source and preservation review

Reviewer: Codex `/root/social_insurance`, separate from writer `/root/crypto`. Read date: 2026-11-16. Scope: only `skills/bahrain/bahrain-vat.md`. This is independent source review, not approval by an accountant.

Result: the frozen candidate passes this scoped review with its explicitly non-usable source holds. No unresolved review finding remains. Guide SHA256: `fe5f506b452e22c9d65362705b3f93367b76c4c733e6f7873d4de02a1932f640`. The complete rule-by-rule record is `independent-checks.json`; it is the canonical exact inventory, not a sampled review.

## Figures and rules checked

All **99 ledger rows** were checked: original B001-B098 and new B099 for the holiday deadline condition. Actual cached official operative bodies were read, including the enacted rate amendment, original-law commencement, registration and nonresident exceptions, tax points, place and taxable value, zero/exempt conditions, evidence and recovery, apportionment, adjustments, reporting/payment, penalties, groups and rounding. Sources were not treated as verified merely because they downloaded or matched a phrase. Cache hashes match the writer's six-source manifest.

The Arabic Law48/2018 and Executive Regulations12/2018 were read with relevant neighboring clauses. The entire enacted Law33/2021 was read:10% replaces original art3 from1January2022; the original5% text alone is not current-rate proof, and the contractual transition cannot supply an ordinary2026rate. No bill or search snippet was used as operative authority.

The NBR GeneralGuide actually read is1.14 updated11March2026. Its introduction and20.4 support the dated GCC recognition statement; it is not represented as the latest edition. Its medical/education/finance, service export, recovery/apportionment and return guidance were compared with the cited law as relevant. Full-return manual1.2 dated27February2025 and simplified manual1.0 January2022 were read for their identified procedure/scope. No live portal was accessed or submitted by this reviewer, and no fresh source scan was required because the actual cited cached body was available.

The three row-source diagnostic misses are explained and independently substantiated: Regulation33 writes37,500 in Arabic words;44 writes18,750;48 writes3million. I read each actual clause, threshold comparator and neighboring conditions. These are parser limits, not unresolved statutory figures. The row-source script was not edited or its failure hidden.

## Actual visual form check

I directly viewed `cache/manual-full-form.png`, rendered from `manual-b.pdf` PDFpage23, printedpage21. I checked every label and column: sales1(a)-7; purchases8(a),9(a),10,11(a),12-14; current-periodVAT15, prior correction16, carried credit17, **net VAT18**, late-payment penalty19. The image has19lines. The manual's printedpage14 prose calls net VAT17 and conflicts with the image. The draft correctly retains that conflict and makes live-form selection non-usable until confirmed. Neither the old invented20-box mapping nor the prose17 is authorized for current filing.

## Preservation and computations

The exact original snapshot equals the Git base blob. I read all356original lines and the entire destination map. All242nonblank original lines are covered. The3original bank input strings are byte-for-byte present, and every monetary input/country/service from the6original tests survives. Every named supplier/bank investigation pattern, all8edge cases, all3refusal classes, theT2/T3escalation meaning and the contributor `Open Accounting Skills Registry` remain. Tier stays2, no `reviewed_by` is introduced, and no human approval/name is added or removed.

The map accounts for corrected or explicitly non-usable historical rules, including the full old box map/formulas, unsupported old penalty amounts, old vehicle exceptions and out-of-scope direct-tax rates. These are not silently dropped or reused as current advice. This remains the same broad bank-classification/VAT-return working-paper job. It has not been reduced to a miniature rates Guide.

All **4 oa-check blocks** independently recomputed with0failures/0missing. Separate Decimal arithmetic agrees: Notion6.03 base gives0.603 output/input andnilnet; AlJazeera5000 net gives500VAT/5500gross, while5000inclusive gives454.545VAT/4545.455net;250gross dinner gives22.727embeddedVAT/227.273invoice net/nil recovery/250expense. The six tests give1000output;500input;200/200/nil reverse-charge;nil export output;nil dinner recovery with330gross;nil exempt-interest output and no directly related recovery. Taxability, evidence, gross/net ambiguity and recovery assumptions remain explicit. See `recomputed-examples.log` and `preservation-and-arithmetic.json`.

## Fixes made by the writer and independently checked

- **BR-01, legal condition:** added Regulation106(c)'s public-holiday extension beside the return/payment deadline and in Filing. I read106(a)-(d), the native holiday clause and corroborating manualp4. NewB099 records the operative condition. This closes the omission without changing the original datasets.
- **BR-02, source evidence:** B083-B085 originally quoted the manual cover or the conflicting prose without an image-native excerpt. The writer replaced these with actual short visual label transcriptions and explicit PNG/page provenance. I checked them against the image. No legal/form-field conclusion changed.

The source and preservation review of unchanged rules is retained through these deltas. No redundant full legal review or test suite was rerun. The reviewer did not edit the Guide, scripts or writer inventory, and made no commit/push/PR.

## Not yet confirmed and practical limits

Later NBR guide contents and postMarch GCC recognition were not obtained. Current portal screens/tooltips, simplified-return eligibility/numbering and payment-channel availability remain explicit non-usable holds; dated PDF instructions cannot establish them. Standalone driving-instruction/dealer-stock vehicle exceptions are also not established by the provisions read and remain on hold. The ordinary law-supported working paper may be prepared; no unqualified live-field selection or final filing readiness is certified.

The writer records live NBR403/access failures. I reused the actual accessible official cached bodies and did not attempt to bypass a challenge or repeat those failed fetches. No accountant approval, paid authority or secondary-firm source was substituted. Root owns the final ordinary committed-head repository gates and publication decision.
