# BR-01 writer correction

The independent reviewer identified the statutory public-holiday extension omitted from the original deadline statement. Writer read the actual cached Regulations104–106 with106(a) return/payment scope,106(b) notice-date rule,106(c) holiday extension,106(d) Gregorian calendar, plus neighboring107. Added the extension beside the quick-reference deadline and Filing and payment text, with direct106(c) citation, and added actual source scope and ledgerB099. No case input, rate, other rule or protected credit changed.

Prior SHA: a642415d7b1aee13c31e5a74446d740b89d589a8ed250eb9b346dd7167d4a3bb
New SHA: fe5f506b452e22c9d65362705b3f93367b76c4c733e6f7873d4de02a1932f640
