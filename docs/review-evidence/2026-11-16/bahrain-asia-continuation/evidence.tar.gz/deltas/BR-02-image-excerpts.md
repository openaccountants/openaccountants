# BR-02 evidence correction

Independent reviewer confirmed the actual manual image. LedgerB083/B084/B085 now quote the relevant exact image labels rather than cover text or inconsistent prose. Visual source: cache/manual-full-form.png, manual-b.pdf printed21/PDF23. Structured records identify separate exact label fragments and image provenance. No Guide content or hash change.
