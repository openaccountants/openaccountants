# Bahrain numeric source citation supplement

This bounded follow-up adds only three source-cell links and the parent-requested Sources read-scope addition for §§3.2.2–3.2.3 to the already cached/read official NBR GeneralGuide1.14. Controlling Arabic Law/Regulation links, figures and conditions are unchanged. It does not claim the dated NBR edition is latest. Root owns the independent citation-diff check against the retained full99-row review; the agent making this supplement does not self-approve its own citation change.

The exact4-line diff and before/after Guide hashes are alongside this record. JSON binds the original PDF and text byte lengths/SHA256 and exact cached paragraph line/UTF8byte ranges, paragraph hashes and actual read date. No raw official PDF is republished. The parent can read those existing cached paragraphs directly.

Mandatory registration: §3.2.2, printed10/PDF17, provides the same37500 numeric amount, actual/forecast12month tests, VATable/capital-disposal/RCM components, with related-party continuation following. Filing periods: §13.2, printed104-105/PDF111-112, provides3million prose and literal3000000 numeric table, strictmonthly/quarterly comparators and NBR exceptions.

Voluntary registration: §3.2.3, printed12/PDF19, corroborates18750 and the supplies-or-expenses/12month structure. Its shorthand uses exceeds for the prior-period limb. The controlling Arabic Law33(b)(1) instead allows reaching that amount; the Guide correctly retains the law's reach/forecast-exceed distinction. This link is therefore explicitly labelled numeric amount only. No eligibility condition was changed to make the checker pass.

The original three-MISS output and native-word reconciliation remain untouched. One targeted unchanged row-source check follows; no other tests, reviews, source scans or script edits are repeated. Existing source/UI/GCC holds remain in effect.

The one targeted network source-row check passed:4rows,0MISS,0UNREADABLE. Its actual output is `../validation/row-sources-citation-supplement.log`. The subsequent Sources scope-only addition changes no figures or sourceURLs and did not trigger another check. Actual new paragraph read date remains2026-11-16.
