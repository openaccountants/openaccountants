# Jordan row-source access result

The unchanged checker checked two figure-bearing rows: private-shareholding subscribed capital and the LLC first capital payment. Both linked JSC PDF pages were UNREADABLE through its direct curl route. Raw result: 2 rows, 0 literal misses, 2 unreadable rows. Successful exit does not establish a source pass.

These correspond to ledger JF06 and JF07. The actual official web-extracted Arabic article 66 bis states the fifty-thousand-dinar subscribed floor; article 59(b)(2) states 50% within 60 days after registration. Those complete clauses and their neighbors were separately read and cached locally, as recorded in the ledger. No alternate amount, article or legal rule was introduced to satisfy the checker. No script was changed. Independent legal source review remains separate and pending.
