from pathlib import Path
import hashlib,json,sys
E=Path(__file__).resolve().parent;p=Path('skills/kuwait/kw-vat-gst.md');old=p.read_text();(E/'original.md').write_bytes(p.read_bytes())
assert hashlib.sha256(p.read_bytes()).hexdigest()=='18cee488aaed65bd48b959c6f2cdc89037a307357a2650a3b0d913b5dbc0b97f'
sys.path.insert(0,'scripts');import skill_checks as sc
fm=sc.read_frontmatter(old);assert fm['tier']==2 and not fm.get('reviewed_by')
(E/'original-standard-findings.json').write_text(json.dumps({k:v for k,v in sc.run_checks(str(p),old,fm).items() if v},indent=2)+'\n')
start=old.index('| Item | Figure and conditions |');end=old.index('\n## The base',start);table=old[start:end].rstrip()
newtable='''No current Kuwait rate, registration threshold or return frequency is established here. The table records only the existing 2026-11-01 index-reading scope, not tax rates or proof of implementation. The held tax questions remain under Sources.

| Index | Reading boundary only | Read on | Official URL |
|---|---|---|---|
| MOF laws list | Financial/tax law titles read; index scope only, no VAT or excise title identified | 2026-11-01 | https://www.mof.gov.kw/MOFDesicions/mofDesicions1.aspx |
| MOF decree-laws list | Financial/tax decree titles including 157/2024 read; index scope only | 2026-11-01 | https://www.mof.gov.kw/MOFDesicions/mofDesicions2.aspx |
| MOF resolutions list | Tax resolution titles and 2025 DMTT material read; index scope only | 2026-11-01 | https://www.mof.gov.kw/MOFDesicions/mofDesicions3.aspx |
'''
new=old[:start]+newtable+old[end:]
new=new.replace('version: 0.3\n','version: 0.4\ntype: situation-rules\n',1).replace('last_updated: 2026-11-01','last_updated: 2026-11-16',1).replace('# Kuwait VAT / GST v0.3','# Kuwait VAT / GST v0.4',1)
# This historical read date qualifies only the index, never legal status.
archive=table.replace('https://www.mof.gov.kw/MOFDesicions/mofDesicions1.aspx |','https://www.mof.gov.kw/MOFDesicions/mofDesicions1.aspx (index read 2026-11-01 only; legal status remains unverified) |',1)
new+='\n### Held questions retained from the former rates table\n\nThe following rows are non-operative source gaps, not usable tax guidance. The tax-year column is the research target, not confirmation of current law.\n\n'+archive+'\n'
p.write_text(new)
print({k:v for k,v in sc.run_checks(str(p),new,sc.read_frontmatter(new)).items() if v})
