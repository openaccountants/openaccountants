# Isle of Man independent assigned-pair review

Reviewed 16 November 2026 by fresh independent AI reviewer `/root/review_li_fi`, separate from the writer. PASS for this expressly partial source-supported pair at the hashes below. No actionable legal/source finding remains. This review uses completed prior source review for unchanged claims and independently checks the actual changes and their dependencies. It is not accountant approval or a fresh full-country statutory audit.

## Exact Guide binding

- `skills/isle-of-man/im-company-formation.md`: SHA256 `0290290948e86bb4200a3e5e0056ba88412519e58bdb57c578480f02db6bad80`
- `skills/isle-of-man/im-tax-overview.md`: SHA256 `47ecc694cb73e622ff2cfe179009006602e2ecfd89fbcb1b0a81f89e439a841e`

Baseline: `bbab4f1a6d82cace432e6ca8eda89c98ffb1c038`. Inventory: 47 rule/figure rows (25 formation, 22 overview), all accounted for below. Two new examples independently recomputed from stated facts, without importing writer formulas. No original example or worked input existed in either baseline.

## Applicability and provenance

Independently read both canonical prior comments and compared their exact UTF-8 bytes to retained GitHub API JSON. The complete prior review records are [formation1021](https://github.com/openaccountants/openaccountants/pull/1021#issuecomment-6540778199) and [overview1020](https://github.com/openaccountants/openaccountants/pull/1020#issuecomment-6540761510). They record17and16ledger rows respectively (approximately 40 and 35 figures), not this revision's expanded47-row inventory. Canonical comments are preserved untouched by the writer.

Compared each retained reviewed source body with the actual baseline Git blob, excluding retired metadata and an old platform CTA only. Every baseline legal paragraph, Sources entry and original Not yet confirmed paragraph is identical. Formation reused-body SHA256 is `724bb5edf99dac0adac1e03c4bee19ad7eb962f90a643a437425d67ab2f345e0`; overview is `85ca3b0178551c36c1f60ab03aa06777be6eca1c4d3888a2417a8acdb4c86494`. I then read the entire candidate pair, full diff, both ledgers and complete no-loss map. Reuse covers the unchanged claims only and does not renew missing original source captures or invent new quotes/read dates.

## Delta sources actually read

Opened/read the [current2006Registry page](https://www.gov.im/categories/business-and-industries/companies-registry/registries/2006-act-companies), [annual-return page](https://www.gov.im/categories/business-and-industries/companies-registry/file-an-annual-return/?iomg-device=Mobile), [2006fee schedule](https://www.gov.im/categories/business-and-industries/companies-registry/fees/2006-companies/) and [1931incorporation page](https://www.gov.im/categories/business-and-industries/companies-registry/registries/1931-act-companies/incorporation?iomg-device=Desktop) on16 November. Their substantive passages, footnotes, exceptions and rejection condition support the changed wording. Fee timing distinguishes annual made-up dates from other-document due dates.

The first direct [CA1982PDF](https://legislation.gov.im/cms/images/LEGISLATION/PRINCIPAL/1982/1982-0002/1982-0002_4.pdf) open returned rejection; opening its indexed official result then yielded the complete3,022-line PDF text. I read ss. 18–20 and endnotes 71–72 from that full view, not merely search excerpts. Section 19(4) says “public company having a share capital”; its alternative routes include historic appointment, relevant experience, listed professional membership, auditor eligibility and legal qualification. Knowledge/experience is an additional condition. Section 19(2) covers vacancy/incapacity substitution;19(3) prevents the same individual fulfilling both sides of a required dual act. Endnote 71 records the1992 CIMA insertion; 72 records the 1986 amendment. The Guide's scoped correction is supported. No whole-Act or complete amendment-chain audit is claimed.

Read the recovered official rates/NI/employer-compliance HTML text once, with the14 November snapshot provenance retained. Explicit2026/27 columns support the rate-example factors and unchanged rate headlines; age/status/eligibility remain delegated. New source annotations correctly retain October dates for reused blocked sources and describe actual named current reads. These dates are not claims of today's full statutory reread. No raw/full sources are included in this receipt.

## Per-row outcome

“Reuse” means applicability-checked completed independent review, with no new operative-source reread claimed. “Mixed” identifies a current check plus retained prior scope. “Delta/current” means the named actual operative source passage was independently read. Editorial rows verify preservation/referral rather than certify a new tax rule.

|ID|Outcome|Method|Support|Result|
|---|---|---|---|---|
|F01|PASS|reuse|Original completed formation review|Regimes, vehicles, equal tax treatment and GBP unchanged.|
|F02|PASS|current|Registry 2006 Incorporation|Named first agent and Class 4 licence confirmed.|
|F03|PASS|delta|Registry 2006 Memorandum/Articles|Documents, three-month approval and prescribed-type Model Articles restriction confirmed.|
|F04|PASS|current|Registry 2006 General/Post incorporation|One director within one month, corporate director, member, agent and optional seal supported.|
|F05|PASS|mixed|CA1982 ss18-20 and Registry1931 Form1|Two individuals, secretary, roles, corporate-secretary caveat and Island office supported.|
|F06|PASS|delta|CA1982 s19(4), endnotes 71–72|Public company with share capital condition and knowledge/experience plus alternative route correct.|
|F07|PASS|delta|CA1982 s19(2)-(3)|Dual-capacity restriction correctly distinguishes holding offices from satisfying both sides of a required act.|
|F08|PASS|reuse|Original completed formation review|Public members/accounts, private subsidiary exception and 9N clock unchanged.|
|F09|PASS|reuse|Original completed formation review|LLC Act, documents, liability, management, suffixes and member taxation unchanged.|
|F10|PASS|reuse|Original completed formation review|Foundation/MF01, partnerships, business names, foreign and PCC signposts preserved.|
|F11|PASS|mixed|Current 2006 fee schedule; original review other entities|Incorporation amounts/times match; other-entity scales retained under prior review.|
|F12|PASS|reuse|Original review express foreign-company correction|Foreign registration/declaration fees and exclusion from express scale preserved.|
|F13|PASS|current|Current annual-return page|Anniversary, one-month filing, forms and sanctions match.|
|F14|PASS|delta|Current annual-return/2006 fee pages|380/480/630 bands run from made-up date; corrected clock supported.|
|F15|PASS|current|Current 2006 fee schedule|Excepted and charity amounts match; excepted eligibility remains held.|
|F16|PASS|reuse|Original completed formation review|LLC, foundation, partnership and foreign recurring fee types/scales preserved.|
|F17|PASS|current|Current 2006 fee schedule|Other-document late bands use document due date; rejection warning retained.|
|F18|PASS|current|Current 2006 fee schedule|Charge, re-registration and restoration amounts match.|
|F19|PASS|reuse|Original review express 2026 beneficial-owner check|Officer/category, 21-day notice,25%,other control and SMO unchanged.|
|F20|PASS|reuse|Original review ITA/GN58 check|Online pay/file, no-income filing and12-month-plus-one-day rule unchanged.|
|F21|PASS|reuse|Original completed17-row formation review|Substance signpost and2021extension unchanged; no broader assessment inferred.|
|F22|PASS|reuse|Original completed review plus current compliance snapshot|Employer/VAT routing preserved; employer14-day/T30c corroborated offline.|
|F23|PASS|delta|Current 2006 fee footnotes|Cash/cheque/card restriction and conditional accelerated processing correct.|
|F24|PASS|delta|Current 2006 fee schedule; independent arithmetic|Standard-category assumptions and480minus380=100 correct.|
|F25|PASS|editorial|Guide Sources/referrals compared with baseline|Every original unresolved topic remains non-usable; no new exemption inferred.|
|O01|PASS|mixed|Prior review; recovered rates HTML|Year and accounting-period distinction preserved;6April-5April corroborated.|
|O02|PASS|reuse|Original review express currency check|Parity/GBP headline unchanged; unread Currency Act remains held.|
|O03|PASS|reuse|Original completed overview review|Direct-tax authority context unchanged.|
|O04|PASS|reuse|Original completed overview review|Indirect-tax authority context unchanged.|
|O05|PASS|reuse|Original completed overview review|Residence, nonresident21%and no allowance unchanged.|
|O06|PASS|current|Recovered official rates HTML,2026/27 section|17000/34000and1-for-2taper above100000/200000 match.|
|O07|PASS|current|Recovered official rates HTML,2026/27 section|10%/21%,6500/13000and nonresident21%match.|
|O08|PASS|mixed|Recovered rates HTML; original review statutory election conditions|220000/440000amounts corroborated; five/ten-year conditions reused.|
|O09|PASS|reuse|Original review corporate/Pillar2check|Company and top-up headlines/conditions unchanged; detailed group rules referred.|
|O10|PASS|current|Recovered official NI HTML,26/27column|All employee/employer/Class2/Class4figures match correct year; no older column substituted.|
|O11|PASS|reuse|Original review VATA check|Rates, local reduced classes, common area and90000headline unchanged.|
|O12|PASS|reuse|Original review moving-to-Island source check|NoCGT/IHTheadline unchanged.|
|O13|PASS|reuse|Original review ITAs62check|Before6October interpretation and2027example preserved.|
|O14|PASS|reuse|Original completed overview review|January timing and2028example preserved; no new GN3read claimed.|
|O15|PASS|reuse|Original review ITAA66/GN58check|Company pay/file deadline unchanged.|
|O16|PASS|current|Recovered official employer compliance HTML|19th T35 and5Mayannual return confirmed in actual paragraphs.|
|O17|PASS|current|Current 2006 fee schedule|100standard incorporation and380timely return corroborated.|
|O18|PASS|reuse|Original completed overview review|2018UKtreaty and6April2019effect headline unchanged.|
|O19|PASS|reuse|Original completed overview review|Constitution/authority/common-area context preserved.|
|O20|PASS|editorial|Baseline/new intro and Not yet confirmed|Unsupported blanket UKrate comparison moved to explicit non-usable hold.|
|O21|PASS|delta|Recovered2026/27rates plus independent arithmetic|40000less17000=23000;650plus3465=4115before credits.|
|O22|PASS|editorial|Existing sibling paths and baseline holds|Seven routes exist; refusals do not establish eligibility; original holds retained.|

## Independent arithmetic and no loss

Formation: the assumed ordinary company's accepted return at two months from its made-up date falls in theGBP 480 band, versus GBP 380 within one month; the increase is GBP 100, not an additional charge on GBP 480. Rejection can move acceptance across a band. No excepted/charity status is inferred.

Overview:GBP 40,000 income minusGBP 17,000 assumed full allowance leaves GBP 23,000. The first GBP 6,500 at 10% is GBP 650; remaining GBP 16,500 at 21% is GBP 3,465; sum GBP 4,115 before credits. Full-year single residence, allowance, income classification, no special regime and no cap election are express assumptions.

All old topics and numeric factors checked against candidate destinations. Formation retains both company regimes, LLC/foundation/LP/PCC/foreign routes, officer/agent conditions, documents, all original fee scales, BO/control/SMO/notice rules, corporate pay/file, substance, employer and VAT handoffs. New qualifications correct old overbreadth rather than delete topics. Overview preserves 18 headline rows and seven routes; only the blanket UKcomparison moves to a non-usable hold. No prior calculation input lost; both new cases retain their complete inputs. Files grow 10,625 to 20,519 and 8,813 to 14,714 bytes. Existing licence and tier 2 remain; baseline contains no CTA or accountant approval to alter.

## Holds and boundaries

Retain non-usable holds for Companies Act2006 primary text; minimum capital/no secretary/no AGM/accounts/audit claims; excepted-company definition; PCC eligibility/filings; Currency Act1992; Island VAT return due date; blanket UK direct-rate comparison. Reused BO, LLC, substance,foreign-entity,statutory deadline and treaty statements remain limited to the original completed review, not a reconstructed current source read. All source/quote recovery gaps are expressly disclosed in ledgers. No broader eligibility, taxpayer filing readiness, comprehensive coverage or professional approval follows.

Parent owns actual-head validator, strict sync, shared tests and publication packaging. This reviewer did not run those again, modify Guides/Git, submit live forms, publish or merge. Subsequent wrapper/hash-only movement does not require restarting this review. A substantive legal change requires only focused review of that change and affected conditions.
