# Isle of Man writer handoff

The two assigned, unsigned tier-2 Guides are complete at version 0.2 for 2026/27. No branch, staging, commit, push or publication was performed. Only the two assigned Guides were edited.

The complete original independent review comments are preserved byte-exact in `PRIOR-REVIEW-1020.md` and `PRIOR-REVIEW-1021.md`, with their API records. `REUSE-APPLICABILITY.json` proves that both original reviewed legal bodies equal the current-main baseline through Sources and Not yet confirmed. The original read dates remain intact for reused claims.

The focused corrections and affected conditions are:

- Annual-return fee bands run from the return's made-up date, rather than from an additional delay after its due date.
- Companies Act 1982 section 19(4) sets the qualification rule for a public company with share capital. Section 19(3) also prevents one person satisfying both sides of an act requiring a director and secretary.
- Model Articles apply only to the prescribed company types.
- Accelerated incorporation services carry the published payment-method and acceptance conditions.
- The overview's blanket comparison with UK direct tax rates was moved to a non-usable hold.

Two new conditional calculations recompute: GBP 480 minus GBP 380 gives a GBP 100 annual-return fee difference; assumed GBP 40,000 resident income with the GBP 17,000 allowance and ordinary bands gives GBP 4,115 before credits. Neither baseline Guide had a worked example. Every original entity topic, headline figure, refusal and unconfirmed topic is preserved in `NO-LOSS-MAP.md`.

The formation ledger has 25 rows and the overview ledger 22. Exact native excerpts appear only where actually recovered. Other rows identify the completed original review and the missing recovered excerpt explicitly. No source read or quotation is invented. The separate reviewer should inspect the deltas and their dependencies, while reusing the documented unchanged review.

Both `skill_checks` results are `{}`. `examples.log` records two blocks, zero failures and zero missing examples. `git diff --check` passes. Parent handles committed-head validator/sync checks and the shared calculator/copy tests once. The writer does not claim independent delta review or accountant approval.

Direct Registry index, beneficial-ownership, general 1931 and LLC pages returned 403. The Income Tax Act and VAT Act requests returned rejection HTML despite HTTP 200. Those responses are not source proof. The canonical 2006 guidance, linked 2006 fee schedule, annual-return page, Companies Act 1982 sections 18-20 and 1931 incorporation page were actually opened and read through the web reader. Valid official rates, NI and employer-compliance HTML snapshots captured on 14 November were read on 16 November. Raw source captures remain local under `cache/`.

Exact baseline and candidate hashes, provenance, validation state and holds are in `CHECKPOINT.json`. `STATUS.json` marks the writer checkpoint complete, pending independent delta review and parent publication checks. Existing unconfirmed capital, accounts/audit, excepted-company, PCC, currency-act and VAT-return-date topics remain explicit holds.
