The Isle of Man formation workflow now applies the correct annual-return fee clock and secretary qualifications. The tax overview adds a conditional rate calculation and a clear route to the detailed workflows. Both remain tier 2 for 2026/27.

## Corrected

| Old | New | Authority |
|---|---|---|
| Qualified secretary required for every 1931 Act company | Qualification rule applies to a public company with share capital; dual-role restriction retained | Companies Act 1982 s.19(1)–(4) |
| Annual-return fee bands described as months late | Bands measured from the return made-up date | Registry 2006 company fee schedule |
| Model Articles and accelerated service conditions incomplete | Prescribed company types, payment and acceptance conditions included | Official Registry guidance |
| No executable formation or overview control | GBP 380/480 fee comparison and assumed GBP 40,000 resident-income calculation | Registry fees; 2026/27 official rates |

Complete independent reviews #1020/#1021 are reused after comparing their exact reviewed legal bodies with the current baseline. Fresh independent review covers changed conditions, source dependencies, new controls and preservation. No professional approval or full-country completion claim is made.

Committed-content validation and strict sync audit must pass without warnings before publication. Both examples recompute and skill checks pass. Row-source transport reports zero misses and eight unreadable rows; the actual completed source reads and reuse scope are documented separately. Shared calculator/copy tests are reused after verifying unchanged scripts/tests. Required CI runs at the final head. Compact indexed evidence: `docs/review-evidence/2026-11-16/europe-continuation/isle-of-man/`.

Unconfirmed capital, accounts/audit, excepted-company, protected-cell, currency-act and VAT calendar conditions remain explicit non-usable holds. Blocked downloads are disclosed and are never represented as fresh reads.

## Removed and why

Only duplicate structure and the blanket UK direct-tax comparison, which is retained as a non-usable hold. No original topic, human credit or contributed file is removed; the baseline contained no executable cases.

## Moved

Existing topics move within the same file to canonical scope, inputs, method, cases, referral and sources. Exact old-topic destinations and authority are in the archived no-loss map. No file merge or deletion.

## Not moved

No topic is silently dropped. Unconfirmed conditions remain explicit non-usable holds under Sources.

Written by Codex (world wave). Not reviewed by an accountant.
