# Focused source-read record, 16 November 2026

This is a writer record, not independent review. The original 30 October source review is reused for unchanged rules after exact-body applicability comparison. Current reads were limited to changed claims, neighboring conditions and the factors used in the new examples.

| Official source | Actual passages read | Result |
|---|---|---|
| https://www.gov.im/categories/business-and-industries/companies-registry/registries/2006-act-companies | Incorporation; memorandum; articles and prescribed types; general company requirements; post-incorporation | Supports agent, documents and officer conditions. Read via web reader after the trailing-slash URL failed. |
| https://www.gov.im/categories/business-and-industries/companies-registry/fees/2006-companies/ | Incorporation and both payment footnotes; standard/excepted/charity annual fees; late fees; selected miscellaneous fees | Corrects the annual-return clock and supports the fee example. |
| https://www.gov.im/categories/business-and-industries/companies-registry/file-an-annual-return/?iomg-device=Mobile | Filing period; AR/IMAR/ARF; all fee bands; explicit made-up-date clock; rejection warning | Confirms the fee-clock correction. This ordinary published variant was discovered in official search results. |
| https://legislation.gov.im/cms/images/LEGISLATION/PRINCIPAL/1982/1982-0002/1982-0002_4.pdf | Sections 18-20, especially all of section 19 and its qualification/dual-capacity conditions | Supports the secretary correction. No comprehensive audit of the Act or all amendments claimed. |
| https://www.gov.im/categories/business-and-industries/companies-registry/registries/1931-act-companies/incorporation?iomg-device=Desktop | Form 1; Public Company Requirements and neighboring incorporation conditions | Corroborates individual directors, secretary roles and the public-company qualification scope. |
| Official rates and allowances page, recovered valid HTML captured 14 November | Explicit 2026/27 tax year, allowances/taper, rates/bands and cap | Read offline on 16 November; supports the new rate calculation. |
| Official NI rates and thresholds page, recovered valid HTML captured 14 November | Explicit 2026/27 column for employee, employer and self-employed figures | Confirms applicability of the unchanged NI headline. |
| Official employer compliance page, recovered valid HTML captured 14 November | Employer registration, monthly T35 remittance and annual-return rows | Confirms the unchanged filing headline. |

Rejected statute responses, search excerpts and successfully downloaded rejection HTML were not treated as operative law. Original source excerpts not recovered are identified in the ledgers and rely on the preserved completed prior review. No challenge bypass, paid API or Firecrawl call was used.
