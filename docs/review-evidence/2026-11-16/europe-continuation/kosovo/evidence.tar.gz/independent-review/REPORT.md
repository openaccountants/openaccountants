# Kosovo independent planning review, 16 November 2026

Fresh reviewer `/root/review_sm` accepts only `skills/kosovo/kosovo-tax-optimization.md` v0.3 for its stated limited income-tax planning scope. No blocking finding. Exact accepted SHA256: `323f9be19611ed661f67680ef49aa56b48cd6a396bb48959983bded73bb5c74f`.

This is independent source/delta review, not accountant approval, country completion, an all-in owner/employer comparison, CI success, publication or merge. No Guide edits, Git mutation, authenticated portal or taxpayer action by this reviewer. Parent owns committed-head gates and the shared test run; unchanged suites were not duplicated.

## Review inventory and reuse

All 27 legal rows are explicitly inventoried in `ROW-OUTCOMES.json`: 23 reuse completed independent primary-source review after one applicability check; four receive new independent delta/dependency reads (02, 14, 20, 21). Reuse is the canonical whole-pack independent reviews from 25 and 30 October, recovered byte-exact from PR #784 comments 6395420996 and 6531000213. They expressly cover the planning method, election/continuing periods, rates, deductions/losses, extraction/dividend, anti-splitting restrictions and both worked cases. The original October scope and unresolved issues remain attached; a newly prepared quote or November wrapper is not called a fresh whole-law read.

I compared old/current planning content with that recorded scope and inspected current TAK rate and law-catalogue text for applicability. The current rates preserve separate EUR 50,000 individual and EUR 30,000 corporate ceilings, 3%/9% activities, 10% company tax and amended annual bands. No failure or conflicting changed authority requiring a repeated full source scan was identified. Exact local source/review identities are in `FINAL-MANIFEST.json`; identities supplement substantive review rather than replace it.

## Actual changed-source reads

PIT articles 32-34 support the explicit partnership/group real-income books condition independently of a sole trader's EUR 50,000 ceiling. The declaration does not admit partnerships to the individual gross method merely because their receipts are small.

PIT article 39(1)-(5), read with neighboring 40/41, supports the specified business-natural-person, partnership and group payer classes, non-exempt interest/royalty 10%, rent 9% of gross and payment-or-crediting trigger. Corporate article 31(2)-(6), read with neighboring article 32, separately supports corporate interest/royalty and rent withholding, payment/credit timing, ordinary-course loans by CBK-licensed financial institutions, public-authority instrument interest and exempt-lessor exceptions. The Guide keeps these corporate exceptions in the corporate branch; it does not silently transplant them into PIT or describe every extraction as a dividend.

TAK's Albanian notice actually quotes Law 08/L-142 article 5: EUR 3,000 is included in the zero band and EUR 5,400 in the 8% excess band, with EUR 192 plus 10% above EUR 5,400. The surrounding official notice states publication and immediate commencement on 23 August 2024. I read these operative quoted paragraphs and current rate text; the Gazette download shell was not treated as an operative source read. Boundary arithmetic is consistent: EUR 3,000 yields zero and EUR 5,400 yields EUR 192. The decision structure preserves two methods, a worked income-tax choice both ways, full continuing-term costs and the explicit fact switches before recommendation.

All 27 published quote candidates, including the parent's corrected 03/05/11/12 strings, match actual retained official published text after whitespace normalization. English Gazette text is identified as its published English, not represented as an Albanian quote. The amended-band quote is Albanian. Unchanged rows preserve 30 October source-read provenance and separate 16 November quote recovery/applicability; changed rows state the actual 16 November read.

## Preservation and independent arithmetic

All 23 old topic-block map hashes were independently reproduced, including the final reference-definition block's trailing newline. Manual old/current comparison confirms original topics, statutory references, refusals, election/threshold conditions, health/linked implementation holds and professional-review limits survive. Duplicate references became inline URLs; canonical headings and early inputs add no entitlement. Protected identity/place/licence/tier/period/category/domain fields remain unchanged, with no new approval/credit/CTA.

Both original oa-check blocks are byte-exact, including all original inputs and expected outputs. Both independently recompute with separate Decimal formulas, without evaluating Guide steps or importing the repository checker. `INDEPENDENT-CONTROLS.json` records exact inputs and outputs. Case 1: EUR 450 quarterly gross tax, EUR 1,800 annual gross tax, EUR 4,000 taxable profit, EUR 400 CIT and EUR 1,400 difference. Case 2: EUR 600 receipts at 3% yield EUR 18, raised to EUR 37.50; the next quarter has **zero receipts**, zero payment and a required statement. The writer ledger's compressed phrase around “zero receipts0.18percentage” is read as two separate values, zero receipts and EUR 18 percentage tax; no 0.18 receipt assumption is adopted.

Operative health phase/start/forms and named linked implementation questions remain explicit non-usable holds. No zero health liability, complete all-in comparison, transaction-specific incentive, reorganisation or cross-border outcome is certified. These holds do not invalidate the bounded income-tax arithmetic but prevent treating it as a complete entity recommendation.

Raw source captures/PDFs/full extracted text remain local in the writer cache. This public-safe receipt contains only bounded scope, quotes already in the ledger, exact identities, preservation and independent arithmetic outcomes.

Written by Codex (world wave). Not reviewed by an accountant.
