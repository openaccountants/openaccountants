Independent review (rev-XK-784, 30 Oct 2026): about 185 figures and rules checked against gzk.rks-gov.net, atk-ks.org, crmm.atk-ks.org, bqk-kos.org, fssh.rks-gov.net and the Government decision page. There was no writer ledger, so the reviewer built its own figure list from all eight skills. Main merged in (9b58e6fc). Review commit 491316d8.

**Law in force for 2026:** the Gazette records list 08/L-142 as the only amendment to PIT 05/L-028 (bands 0% to EUR 3,000, 8% to EUR 5,400, EUR 192 + 10%; in force 23 Aug 2024). There is no amendment to CIT 06/L-105. 08/L-276 is the only amendment to VAT 05/L-037. The amendments to pension 04/L-101 are 04/L-115, 04/L-168 (EUR 600 quarterly cap) and 05/L-116. Health law 10/L-028 was published in OG 11/2026 on 15 May 2026, in force 15 days later. Its 7% (3.5% + 3.5%) standard rate is subject to phase rates under art. 35(2). The FSSH site shows collection is still being prepared.

**Fixed:**
- CIT: added the three-year wait, last-period income under EUR 30,000 and TAK approval before 1 March for a return to the gross method (06/L-105 arts. 35(3)-(4), 38(3)). Corrected the bad-debt citation to art. 13(1)-(3).
- TP: removed an unconfirmed form date and PDF page cites. The submission channel now follows TAK's 30 Mar 2026 notice.
- VAT: the insurance exemption covers life and health insurance only (art. 28(1.1)). The AI art. 64(2) exception is limited to the repeated-transactions rule.
- XB: the MAP guide is 5 pages. Added the WR form, the 22-treaty register and the Italy treaty (in force 21 Dec 2025, applies from 1 Jan 2026).
- PIT: added the 3% special-category withholding (art. 40), the purchase and sales book duty (08/L-257 art. 43(3)-(4)) and the business-day rule (art. 13(7)).
- SC: stated that 04/L-101 as amended has no maximum contribution base.
- README: rewritten to the pack template. Partial now applies to SC and PR only (health-insurance collection start and phase rate). The other notes were niche implementation questions, not core gaps.
- All files:
  - last_updated 2026-10-30, tax_year 2026, tier 2, team byline (added where it was missing).
  - "Guide", "Source-cited draft" and "verified" wording removed. Process notes about the earlier AI review removed. Sources dated 2026-10-30.

**Lost content restored: 12.**
- VAT (7): full 8% list (art. 26(2)), agricultural inputs exempt with recovery (Annex IV, arts. 29(2), 33(2)), international transport (arts. 32, 33(4)), diplomatic/KFOR (art. 33(1)), exempt list items, blocked vehicles (art. 36(5.1)), import VAT and the SAD (art. 37(2.1)).
- Other files (5):
  - The 3-year amended-return window (08/L-257 art. 14(2)).
  - The interest rate must be above commercial bank lending rates (art. 24(3)).
  - The 23 Aug 2024 start of the current bands (08/L-142 art. 7).
  - The 10% interest/royalty and 9% rent withholding as extraction routes (PIT art. 39).
  - The entity-splitting warning (08/L-257 art. 41).

**Confirmed:**
- PIT: EUR 50,000; 3%/9%; EUR 37.50; 1% representation; 10% donations; depreciation at 5/20/10%; EUR 1,000; extra 10%; six-period losses and more than 50% ownership change; 10% rent deemed cost; withholding at 10%/9%/5%; EUR 5,000 gifts; 110% and 20% advance rules; 1 March and 31 March dates.
- Payroll: monthly bands 250/450 (TAK table); secondary employer 10% after pension; EUR 65 benefits in kind; travel limits EUR 50, 15/25 and 0.16; AI 03/2016 art. 6.
- Pension: 5%+5%; up to 15% voluntary; age 65; art. 6(6), (12), (14).
- Minimum wage EUR 425 / EUR 2.50 and EUR 500 / EUR 3 (Decision 10/273).
- Penalties under 08/L-257 arts. 99, 100, 102(3) and 103.
- CIT 10%, EUR 30,000, four-period losses. VAT 18%/8%, EUR 30,000, the 20th.
- TP: EUR 300,000 "exceeds" (the FAQ conflict is recorded), 7% low-value markup, 30 days.
- All 16 examples recompute by hand and in check-examples (0 failures).

**Contradictions with sibling skills:** none. One wording difference: payroll certificates are due "by 1 March" (PIT art. 38(6)), while the nonresident reconciliation is due "before 1 March" (CIT art. 33(6) Albanian). Each follows its own article.

**Still not confirmed:** the 2026 tax late-interest rate; the health-insurance collection start, phase rates and forms; the PD24 donation-field filing treatment; the TP loan-balance measurement; CIT gross-interest reporting and education-retention duration; service-PE proviso interpretation; implementing acts for VAT art. 52(1.4.2)-(1.4.7); the full Annex 1 code list.

Checks: check-examples 8 files, 16 blocks, 0 failures; validate-guides passes; sync-integrity 0 errors.
