Independent whole-pack review closure for commit `e2d95e7382d1cf20b365dda4f793138df6c4679c`.

Accepted for **partial tier-2 source-cited draft publication**, not country completion or professional attestation. All nine published country files match the final independent review hashes below. The writer corrected the disposal basis formula, required bad-debt document and six-month boundary, and disclosed the verified original-language differences.

Local publication checks: eight current-year Guides pass focused validation without errors/warnings; all 16 examples pass; strict sync audit passes with zero errors/warnings/notices; full source validation passes with inherited repository warning groups (814 missing Sources, five freshness, five jurisdiction). All 129 repository tests and 40 MCP tests pass. The initial repository run had one missing temporary-directory failure; creating that directory and rerunning the full suite resolved it. Protected platform fields and CTA tails are unchanged; generated files are untouched and historical research is preserved.

Kosovo remains partial across the seven domains for the specific gaps documented below. PR #784 stays draft and issue #430 stays open. All five exact-head CI checks passed: cla, guard-derived-trees, validate, compare and unit-tests. Validation workflow https://github.com/openaccountants/openaccountants/actions/runs/40176099000 ; sync/test workflow https://github.com/openaccountants/openaccountants/actions/runs/40176098984 .

---

# Kosovo PR #784: independent whole-pack review

Decision: **accept corrected material for publication as a partial, tier-2 source-cited draft pack. Do not mark Kosovo complete.** Decision date: 25 October 2026. Reviewer: fresh independent AI agent, separate from the writer. This is not a Kosovo professional attestation or a licensed legal translation.

The reviewer read all nine country files in /private/tmp/oa-kosovo-completion, read AGENTS.md, CLAUDE.md, docs/skill-template.md and docs/pack-readme-template.md, and independently checked actual primary evidence. Country files were read-only to this reviewer; the writer made corrections and froze final wording for re-read. No research subagents were used.

## Final acceptance and completeness

All seven tax Guides have the nine authored deep-tax sections in order, dated Sources tables, 2026 integer tax years, tier 2, and exactly two oa-check examples each. The supporting tax-planning Guide follows the general template, with two additional comparisons. All eight descriptions meet 80–150 words. Existing platform CTA sections are outside the nine authored sections and are not a reason to delete protected content.

The corrected stated ordinary numerical rules checked below contain no remaining identified P1/P2 error. This is acceptance of the scoped draft material, not a finding that every potentially applicable rule or implementing instrument is confirmed. The README retains all seven genuine partial flags. The coverage report reads complete:false. Completion and publication are separate decisions.

## Primary evidence and source access

Actual official downloads and forms in /private/tmp/oa-kosovo-evidence were read and identified from their contents. Filenames were not treated as proof: pit-ai-2016 is PIT AI 01/2016, whereas pit-instruction is corporate AI 02/2016 implementing the repealed corporate statute. The latter was not treated as current PIT authority. The downloaded Malta treaty is the 24-page Albanian TAK scan. I rendered/OCR-read physical pages 8–9 and confirmed art. 7's functions/assets/risks, corresponding adjustment and separately classified income. Page 24 says English prevails in divergence; this review does not settle a future treaty-language conflict.

Checked primary provisions and the numerical claims they support:

| Domain | Primary evidence checked |
|---|---|
| PIT | 05/L-028 residence/worldwide/Kosovo scope; EUR 50,000; 3%/9%, EUR 37.50; 1% representation; 10% ordinary donation; 5%/20%/10% depreciation, EUR 1,000 and extra 10%; six-period losses/>50%; rent/royalties/withholding, gifts/inheritance, adjusted asset basis, annual/quarterly/election rules and credits. Replacement bands in 08/L-142 art. 5: EUR 3,000/5,400, 0%/8%/10%, EUR 192. |
| Payroll | PIT AI 01/2016 art. 14: EUR 65 excess benefit, domestic EUR 50 lodging/EUR 15 or 25 meals/EUR 0.16/km. Art. 37: pension deduction before principal and secondary withholding, voluntary additional limits. Current wage bands and reporting/certificates reconcile with the statute. |
| Pension | 04/L-101 art. 6, 04/L-168 art. 3 and 05/L-116 art. 10: 5% each, 10 additional percentage points/15% total each; full-time floor asymmetry; owner 10%, EUR 600 mandatory quarterly cap, 30%-of-minimum-wage floor; presumptive one-third and voluntary three-times limits; residence/temporary-foreign coverage. |
| Wage/health | Decision 10/273 para. 1: EUR 425/EUR 2.50 from 1 January, EUR 500/EUR 3 from 1 July 2026; derived owner floors EUR 127.50/EUR 150. Health 10/L-028 arts. 21–22/35–37: standard 7%/3.5% shares, transition, repeal and entry into force. No operative collected rate was inferred. |
| CIT | 06/L-105: 10%, EUR 30,000, 3%/9% and EUR 37.50; rent method; elections/continuing term; ordinary deductions; 1%/10%; 5%/20%/10%, EUR 1,000, extra 10%, 20-year intangible; four-period losses/>50%; disposal/distribution/liquidation/reorganisation; quarterly 110% prior liability and annual settlement/shortfall rules. Original Albanian arts. 35(4)/33(6) checked against English discrepancies. |
| CIT special recognition | Construction ruling 02/2019 pp. 8, 13, 20 and TAK ATK27334/2023/ATK27829/2024: contractor versus investor/advance/accrual treatment, matching costs and retention. ATK26322/2021: finance lease >75%/>90% alternatives; ATK28224/2025: operating lease and lessor depreciation. Its wrong interest/rent cross-reference is identified and actual art. 31(3) 9% applied. These are positive administrative applications, not proof every old bylaw survives. |
| VAT | 05/L-037: EUR 30,000 calendar-year/crossing-supply registration, fifteen-day notification/foreign five-day appointment; 18%/8%; supply/value/place; blocked/proportional inputs and 50% mixed-car restriction; following-year deduction window; upward-rounded proportion/January true-up; five-/twenty-year adjustment and small-difference rule; stock credit; EUR 3,000/three-month and exporter refunds; bad-debt invoice/timing; monthly 20th, invoice before 15th, deregistration/six-/twenty-year records. AI 03/2015 registration, import approvals, bad debt/construction with AI 06/2016/01/2018; 08/L-276 arts. 48–49 changing VAT arts. 52/61. |
| TP | 02/2017 actual instruction and current CIT art. 28: relationships/scope, methods, eligible 7% low-value cost markup, ranges/median, both articles numbered 28, strict >EUR 300,000 notice including loans/no netting, thirty-day request, three-year/annual refresh, languages/corresponding adjustment. Actual notification form's opening/closing loan fields and guidance read. It does not supply a settled threshold aggregation formula. |
| XB | CIT arts. 29–33: 5% no-PE service, 10% interest/royalty, 9% rent, dividend exemption; >six-month/>183-day/>90-day PE tests and service proviso; credit ceiling, finality/certificates/reconciliation. Actual Albanian proviso, Malta art. 7 and TAK MAP guide read, including thirty-day information/acknowledgement and treaty-specific clock. |
| Procedure | 08/L-257 arts. 24/26/43/99–103: EUR 50/150/20 missing liability-producing returns; 15%/25% understatement bands; 25% withholding/contribution shortfall; EUR 500 worker/request failures; EUR 150 information statement/max EUR 3,000 and records-access daily default; monthly/part-month interest up to ten years/instalment suspension; three-year refund claim/thirty-day review. KO159/24 actual dispositive preserves art. 26 and invalidates arts. 9(5)–(7)/79 provisions, not these penalties. TP uses art. 9(1) requests. |

Official anchors, with the Guide's article-level citations retained:

- PIT: https://www.atk-ks.org/wp-content/uploads/2017/07/LAW_NO._05_L_-028__ON_PERSONAL_INCOME_TAX.pdf and https://gzk.rks-gov.net/ActDetail.aspx?ActID=96360&langid=2
- PIT AI: https://gzk.rks-gov.net/ActDocumentDetail.aspx?ActID=12233
- CIT: https://www.atk-ks.org/wp-content/uploads/2019/09/LAW_NO.06_L-105.pdf and https://gzk.rks-gov.net/ActDetail.aspx?ActID=20988&langid=1
- VAT: https://www.atk-ks.org/wp-content/uploads/2017/07/LAW_NO._05_L-037_ON_VALUE_ADDED_TAX___ANNEX.pdf and https://gzk.rks-gov.net/ActDetail.aspx?ActID=100032&langid=2
- Pension: https://bqk-kos.org/wp-content/uploads/2024/11/Law-on-Pension-Funds.pdf?lang=en and https://gzk.rks-gov.net/ActDocumentDetail.aspx?ActID=8655
- Health: https://gzk.rks-gov.net/ActDetail.aspx?ActID=119938&langid=1
- Minimum wage: https://kryeministri.rks-gov.net/wp-content/uploads/2025/10/Vendimet-e-mbledhjes-se-273-te-te-Qeverise.pdf
- TP: https://gzk.rks-gov.net/ActDetail.aspx?ActID=14937&langid=2
- Procedure: https://www.atk-ks.org/wp-content/uploads/2024/01/LAW_NO._08_L-257_ON_THE_ADMINISTRATION_OF_TAX_PROCEDURES.pdf
- Construction: https://www.atk-ks.org/wp-content/uploads/2019/02/VendimiShpjeguesPublik.pdf
- MAP: https://www.atk-ks.org/wp-content/uploads/2022/11/Njoftim-per-tatimpagues-mbi-procedurat-e-MAP.pdf
- Malta actual reviewed scan: https://www.atk-ks.org/wp-content/uploads/2019/07/MARR%C3%8BVESHJE_QRK_MALTA.pdf

Independently opened/read in a normal browser on 25 October: TAK current rates/forms timetable, TP FAQ 46–49, 30 March 2026 notification, 23 January 2025 WR notice, PD24, IL24 and CD layouts. Confirmed FAQ 'reach or exceed' versus instruction/current notice 'exceed'; PD24 still says donation 5% versus statutory 10%; IL24 shows 110%/4 and owner 10%/EUR 600/minimum-wage floor; WR Country reporting removes separate forms on its conditions. These conflicts are retained rather than silently using stale labels.

Some direct web PDF/FAQ fetches returned timeouts/502. Actual PDFs were re-read from supplied official downloads, not all independently re-downloaded. Browser fallback succeeded for current pages listed above. No TLS warning, CAPTCHA or human check was bypassed. No authenticated EDI filing or production tax calculation was submitted. OCR has extraction defects on Albanian scans; passages used were read in context, and unresolved interpretation stays unresolved. This is not an exhaustive assurance of all Kosovo law or a professional translation.

## Findings and final corrections

1. **P1 corrected, corporate gain/depreciation sign.** Initial xk-corporate-income-tax.md lines 141–143 described subtracting prior depreciation from proceeds as well as cost. CIT art. 22(2),(5) requires proceeds minus (cost plus improvements minus allowed depreciation/expenses). Final lines 148–152 explicitly reduce basis by prior depreciation, increasing gain. Re-read against actual statute; XB sibling matches.
2. **P2 corrected, bad-debt document.** Initial PIT row 118 and CIT lines 93–99 omitted the required linked Bad Debt document/invoice. PIT art. 17(1.6)/CIT art. 13(1.6) require the uncollected amount and original invoice reference, supporting seller-income/purchaser-expense treatment. Final passages include this prerequisite and were re-read.
3. **P2 corrected, six-month boundary.** Both initially said more than six months overdue. PIT art. 17(1.2)/CIT art. 13(1.2) say at least six months. Both final passages now match. VAT retains its different clock after the relevant VAT period.
4. **Evidence-provenance request resolved.** Local malta-treaty.pdf was Albanian while the initial source row described a separate Malta-government URL as English. I could not equate the local file with that URL; writer reported a separate English web source. Final citation points directly to the reviewed TAK Albanian scan, identifying language/pages accurately. This does not prove the separate English source never existed.
5. **Writer-proposed translation fixes independently confirmed.** Albanian art. 35(4) says last period, supporting final CIT rather than English last quarter. Albanian art. 33(6) says before 1 March; final XB uses the earlier boundary and discloses English no-later-than conflict. No extra filing day is claimed.
6. **Review-state/README wording resolved.** Final files accurately record independent AI acceptance of partial draft publication without professional attestation. README VAT partial names the concrete numeric-interest gap. Existing platform review_status:pending_review remains unchanged, consistent with no professional attestation.

No uncorrected P1/P2 remains in the reviewed stated material. Residual implementation gaps below are not cured by formatting or arithmetic success.

## Arithmetic and validation

Independent arithmetic/read-through and corrected example-runner command: nine files, **16 oa-check blocks, zero failures, zero missing**. Seven tax Guides have two each; planning has two additional comparisons.

| Guide | Recomputed results |
|---|---|
| PIT | EUR 360/zero quarter; EUR 31,600 base, EUR 2,812 PIT, EUR 812 balance |
| Payroll | Primary EUR 570 taxable/EUR 28 PIT/EUR 542 remainder/EUR 630 cost; secondary EUR 380/EUR 38/EUR 342/EUR 420 |
| SC | EUR 50 each, EUR 100 remittance/EUR 1,050 cost; owner EUR 600 cap + EUR 150 floor = EUR 750 |
| CIT | EUR 35,000 base/EUR 3,500 tax/EUR 900 balance; EUR 37.50/450/0/540 = EUR 1,027.50 |
| VAT | EUR 1,800 output - EUR 900 input = EUR 900 due; reverse EUR 180/input EUR 108/net EUR 72 |
| TP | EUR 15,000 CUP adjustment/EUR 1,500 CIT; EUR 20,000 + EUR 1,400 = EUR 21,400 |
| XB | EUR 1,000 withholding/EUR 19,000 payment; EUR 20,000 base/EUR 2,000 credit cap/zero residual Kosovo tax |
| Planning | EUR 1,800 gross versus EUR 400 real/EUR 1,400 difference; EUR 18 raised to EUR 37.50, zero quarter EUR 0 |

validate-guides.py --no-index-check passed: 2,250 Guides; repository-wide warnings were 814 missing Sources, five freshness and five jurisdiction cases, not attributed to Kosovo. Version checks against origin/main show existing Guide versions advance one step; new CIT/XB/TP/README have no main counterpart. No reviewed_by/reviewed_on was introduced. The first attempt to invoke check-examples.py on the directory raised IsADirectoryError; corrected individual *.md invocation passed and was repeated after frozen edits.

## Genuine remaining gaps

- SC/PR: operative health phase/rate, collection start and filing instruments. No complete final payroll/all-in owner burden or zero health charge is certified.
- CIT: ministerial continuity beyond positive TAK applications, gross-interest recognition/reporting and education-retention implementation. Particular cessation/treaty cases need their evidence.
- PIT: operational handling of the PD24 donation conflict and specific exit/cessation treatment; linked health gap. Statutory ordinary donation ceiling is confirmed.
- TP: loan threshold measurement where opening/closing balances change reporting status. Wider CbCR/APA matters remain specialist/unconfirmed, not asserted absent.
- XB: service-PE proviso, general attribution/mixed-location apportionment and residence/asset-migration/final branch closure implementation. One treaty illustration cannot fill these gaps.
- All/VAT: numeric 2026 tax late-interest rate remains unconfirmed. Searches did not establish absence or justify importing a historic/commercial rate. VAT electronic-services/tourist operational schemes remain specialist limits.

These real ordinary gaps prevent country completion. Named specialist treaty matrices, individual treaty outcomes, special schemes and transaction-specific incentives/reorganisations do not by themselves justify a not-applicable conclusion. Formation/accounting packs were not audited. Final hashes below bind only the reviewed bytes; subsequent substantive changes require re-review.

## Final checked hashes and description lengths

| File | Words | SHA256 |
|---|---:|---|
| README.md | 0 | `cfbb0b8948c7b2e65b8920d83768e09fb0316a768ad75cf17f8db28e8a774d63` |
| kosovo-income-tax.md | 100 | `2dc6aba4d2f99c95c482e1da506f21ef4fecb96d82b1db0324d88caf5fc582c9` |
| kosovo-payroll.md | 101 | `a7231d8de1f95a5de82d44a58c753f9e0e028290379448cd4dae342e41d8e94a` |
| kosovo-social-contributions.md | 98 | `0dd1f23020c2ef8b019a51b95007982581c8063b15b1c2313c3c880cb255f074` |
| kosovo-tax-optimization.md | 105 | `4b30c7f3b6e11a976cc2f6086ed56a54dd24dc59bd7c3b09be8eb8757f9676ce` |
| kosovo-vat.md | 108 | `dcf6401a9e527636cd6082960f9c9c5682f5cee8f4e7133e0e35c97227e1154e` |
| xk-corporate-income-tax.md | 112 | `364e604a5fb3893a0c38d15981c6a223063e97fa12c577cef346d24f93288b77` |
| xk-cross-border.md | 103 | `a93f79aa225acfbd8c620163bb0ec6c6a0099e291d4154f4a75902fa639b54dd` |
| xk-transfer-pricing.md | 101 | `2b1b422596dd759fb537e10a0d367c93132a9ee8faeeb02eabd711a0da70a6f6` |

Supporting JSON: independent-final-country-hashes.json. Actual primary evidence hashes: independent-primary-evidence-hashes.json. Reviewer did not push, post public comments, change protected metadata or grant professional attestation.
