# Kosovo planning focused refresh

One assigned file. Reuses the whole-pack independent reviews from25/30October2026, recovered byte-exact fromPR#784. Current applicability checked against actual TAK rates/catalogue, actual PIT/CIT PDFs and TAK’s Albanian quoted amendment. No claim to country completion or accountant approval.

Corrections: payment-or-crediting trigger; specific PIT versus corporate payer classes; non-exempt interest and corporate financial-institution/public-instrument/rent exceptions; partnership/group real-books condition; inclusive progressive-band boundaries. Changes to law were not invented: these were missing conditions. Canonical decision layout, actual version/date, row-local official sources and early required inputs added. Both original oa-check blocks remain byte exact.

The complete previous topic-block inventory maps to new destinations in no-loss-map.json. No substantive content removed. Hold: operative health start/phase/forms and linked implementation questions cannot support a complete all-in comparison. No zero-health assumption or claimed incentive/reorganisation/cross-border result. Limited income-tax planning is usable subject to actual facts and qualified review.

Fresh independent review is required for these deltas and preserved scope; prior complete research/reviews apply to unchanged rules.
