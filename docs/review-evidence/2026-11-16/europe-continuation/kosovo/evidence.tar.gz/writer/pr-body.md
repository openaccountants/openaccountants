The Kosovo tax-planning workflow now distinguishes the payer and payment category before comparing gross-income and real-income methods. It retains every original topic and both original executable case blocks byte-exact.

## Corrected

| Old | New | Authority |
|---|---|---|
| Withholding described only at payment | Payment or crediting; specific PIT and corporate payer classes and statutory exemptions | PIT art. 39; CIT art. 31(2)–(4) |
| Individual ceiling lacked the partnership/group books condition | Partnerships and groups must keep real-income books; individual ceiling remains EUR 50,000 | PIT art. 33(1)–(2) |
| Unclear band endpoints and noncanonical layout | Inclusive annual band boundaries, early required inputs, canonical decision workflow and row-local official URLs | 08/L-142 art. 5; current template |

The complete independent pack reviews in PR #784 (25 and 30 October) cover unchanged planning rules and cases. Current applicability was checked, and a fresh independent review covers the changed conditions and dependencies. This is tier 2, without accountant approval or a country-completion claim.

Committed-content validation and strict sync audit passed without warnings. Both examples recompute; skill checks pass. The row-source transport reports zero misses and six unreadable rows, whose actual official cached text was read and independently checked. Shared calculator/copy tests are reused after confirming unchanged scripts/tests. Required CI runs at this PR head. Compact indexed evidence: `docs/review-evidence/2026-11-16/europe-continuation/kosovo/`.

Health phase, collection and forms, plus the named linked implementation questions, remain explicitly non-usable. The cases compare income tax only and cannot support a complete entity/all-in recommendation.

## Removed and why

Only duplicate headings and expanded reference definitions. No substantive topic, original case input, human credit or contributed file is removed.

## Moved

Topics move within the same file into scope, required inputs, method, cases, referral, filing and sources. The complete archived old-topic map identifies each destination. No file merge or deletion.

## Not moved

No topic is silently dropped. Unconfirmed conditions remain explicit non-usable holds under Sources.

Written by Codex (world wave). Not reviewed by an accountant.
