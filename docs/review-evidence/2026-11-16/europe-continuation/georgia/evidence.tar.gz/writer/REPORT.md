# Georgia writer checkpoint

The two assigned Guides are complete as a writer candidate for fresh independent review. No commit, remote branch, publication, merge, release, production action or other country edit was performed by this writer.

| Guide | Version | Exact Git blob | SHA-256 |
|---|---|---|---|
| skills/georgia/ge-tax-overview.md | 1.1 | d9178cc3681c0b952fde3966ffe88d614d3bdcf1 | 24a7ed7fc4cdee02eb74d8e7d18c28cc3d4c5ce45c6949ea9c70482302f91fc5 |
| skills/georgia/georgia-tax-optimization.md | 0.3 | 8613459c4d23e4d580d19b69e9720fa1ccc06c7c | 2b39f0da7deb6d61198403b2248e305176bd6138e8cc503d45c07e5f48bbc64b |

## Corrected

| Previous claim or gap | Current rule | Primary authority |
|---|---|---|
| Ordinary company tax only arises on distribution; retained profit broadly described as untaxed | All four statutory triggers retained; retention alone is not a trigger, while nonbusiness/deemed payments can still be taxable | Tax Code arts. 97–98, https://matsne.gov.ge/ka/document/view/1043717 |
| Blanket dividend/interest 5% and preferential-country 15% | Recipient classes and exemptions stated; 15% limited to interest, royalties and residual payments under art. 134(1)(b), (b1), (e) | Tax Code arts. 130–134, same official Code |
| Micro prohibited-activity list omitted trading | Trading prohibited, with purchased-goods processing/supply exception | Resolution 74/2011 art. 1, https://matsne.gov.ge/ka/document/view/1213287 |
| Salary withholding exception described only as obtaining small-business status that year | Same-year individual-entrepreneur registration and status both required, unless the separate previous-year income condition applies | Tax Code art. 94(4), same official Code |
| Company versus small-business recommendation categorical | Same original GEL 100 illustration retained, plus a fully stated tax-only comparison at both margins and computed 5.1948% break-even | Code arts. 90, 97, 98, 130 |
| Construction for private customers unconditionally described as 1% | Private non-entrepreneur customer is only one gate; valid status, source and 1%/3% threshold conditions still apply | Resolution 436/2024 art. 1 and Code art. 90 |
| International-company conditions/list not read; all outside activity described as losing status | Current public original-plus-seven-amendment chain reconciled: related ancillary income up to 2%, core Georgian activity/resources, experience, service-contract and status-interaction gates supplied | Ordinance 619 and amending acts 180/2021, 366/2021, 9/2022, 279/2023, 420/2025 |
| Virtual-zone certificate plus foreign supply could be read as sufficient | Qualifying IT creation in Georgia required alongside status, qualifying product and foreign supply | IT Zones Law arts. 2–6, https://matsne.gov.ge/ka/document/view/1152405 |
| Property headline could invite unadjusted book-value multiplication | Statutory base adjustments, revaluation and leasing exceptions flagged | Code art. 202 |
| Fixed-tax carveout absent | Separate regime and grandfather transitions referred before using micro/small treatment | Resolution 58/2012 and the affected later amendments |

## Recovery and source scope

Recovered both original Guides from actual main and searched the read-only recovery repository's research tree, local outputs and local temporary evidence. No independent Georgia review record for these two Guides was recovered. Recovered original Tax Code snapshots at `/Users/michaelcutajar/Downloads/oa-world-2026-11-14/sources/georgia`. Current applicability was checked against the official current publication index and covered operative clauses; the latest Code publication shown is 28 October 2026. Prior source-date assertions were not substituted for a current read or independent review.

Resolution 415 and Ordinance 619 show their paid consolidation notice. No access control was bypassed. Their public initial texts and complete fourteen- and seven-amendment histories were recovered and reconciled where necessary because the old Guides had genuine missing conditions. Their current amendment indexes end at 19/2025 and 420/2025 respectively. Fixed-tax and maritime changes were read only for their effect on the covered conditions; detailed rates/status entitlement for those regimes remain outside scope.

LEDGER.md inventories 88 figure/rule rows with native quotes, operative article/paragraph, official URL and actual read date. Full law captures remain in the local cache and must not be included in the public archive. NO-LOSS-MAP.md maps all original topics, refusal rules and the original GEL 100 / GEL 15 / GEL 4.25 / GEL 19.25 example inputs and outputs.

## Verification

- Both Guides pass every `skill_checks` check.
- Four required executable examples recompute with zero failures or missing cases.
- Explicit scoped validator `check_guides` inspected the actual two edited Guides: zero errors and warnings.
- Row-source checker used cached official documents. Its reported numeric-row scope is recorded in row-sources.txt; it is not a substitute for legal review.
- Parent runs shared calculator quote/copy tests once and final committed-content validation/sync gates. Those tests are deliberately not repeated here merely for this writer checkpoint.
- Current open PRs were queried with complete paginated file lists for both exact paths; no overlap and no Claude reservation overlap. See ownership-check.json.
- Both remain tier 2; no professional approval, accountant identity, licence, contributor credit or protected CTA changed.

## Removed and why

Removed the unsupported worldwide ranking about low effective rates. The underlying 1% regime and its conditions remain. Replaced the categorical entity recommendation with an explicit tax-only comparison. Historical source-version narration is superseded by actual scoped current reads; the original Guides remain in local recovery. No tax topic, case input or refusal was removed, and both Guides grew.

## Moved

Overview bullets became sourced table rows. Planning sections moved into the canonical method shape. All prior material destinations are indexed in NO-LOSS-MAP.md.

## Not moved

No sibling Guide, generated package/index, website code, database or live service was changed.

## Holds

Fresh independent review of the candidate is required. The confirmed rules above are usable only after documenting the stated conditions. Current designated virtual-zone granting body/live procedure, nil small-business return procedure without income, case-specific VAT source and pension facts, fixed-tax grandfather entitlement, detailed maritime application and allowed-expense claim mechanics remain explicit non-usable holds. No actual status application, filing or payment was tested.

Written by Codex (world wave). Not reviewed by an accountant.

## Independent-review correction addendum

The reviewer identified three omitted conditions and three poorly targeted native ledger quote anchors. The writer corrected those and the additional international-company conditions identified during the reviewer's complete ordinance-chain reading. This addendum records writer changes; reviewer closure remains independent.

- Overview residential-rent 5% now explicitly requires the Ministerial register and privilege procedure for letting to legal persons under Code article 81(5).
- The micro medical exception now names nurse/paramedic, following Resolution 98/2021.
- Overview payroll separates cash-payment remittance from nonmonetary payment remittance on the last day of the month, Code article 154(3)(a).
- International-company eligibility expressly requires article 97(1) taxation and the precise two-year enterprise, foreign-representative or qualifying >50% partner routes. Each qualifying partner must independently have the relevant experience.
- International-company activity breach runs from 1 January of the activity year; status-requirement failure runs from the grant date. Amendment-caused failures use the amendment effective date. Virtual-zone acquisition cancels international status at the grant moment; innovative-startup acquisition cancels it from the first day of the following month.
- Ledger GE-007 now quotes the Georgian foreign-income exemption in 82(1)(ფ), mapping English (u); GE-023 quotes the financial institution annual basis in 97(12); GE-028 quotes residual nonresident payments in 134(1)(e). GE-055 now also inventories the article 97(1) admission gate.

Only affected source paragraphs already in the cache were reread. All four calculation blocks remain unchanged. Affected Guide checks pass and the two-file scoped validator reports zero errors/warnings in skill-checks-corrections.txt and scoped-validator-corrections.txt. Arithmetic, shared tests and full source scans were not repeated for unchanged content. Current ownership check inspected all 23 open PRs with complete paginated file lists and the helper reservation, finding no overlap. writer-checkpoint.json and STATUS.json identify the corrected candidate.

Final narrow dependency correction: Ordinance 416/2021 broadened the status-failure ground to the requirements of the status rules as a whole. The sentence now follows current annex 1 article 3(1)(c), preserving the confirmed retroactive grant-date and amendment-effective-date timing. No calculation changed.
