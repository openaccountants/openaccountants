# Georgia complete no-loss destination map

Baseline is the actual main content of the two assigned Guides. No other source Guide is changed. The original files are retained locally as old-ge-tax-overview.md and old-georgia-tax-optimization.md.

| Original topic or case input | Current destination | Preservation or correction |
|---|---|---|
| Overview introduction and metadata | Overview title, description, introduction | 2026 scope and country identity retained. Qualifies ordinary company system instead of saying tax arises only on distributions. |
| Overview national/local taxes, calendar year, currency, authority | Rates table first four rows | All named taxes, local property, default year/month and GEL/Revenue Service retained. |
| Overview individual/company residence | Rates table residence rows and required inputs | 183 days/12 months and company place rules retained; statutory day exceptions and other routes expressly required. |
| Overview source taxation and personal/rent rates | Rates table individual rows | Foreign-source exemption, nonresident distinctions, 20% and residential-rent 5% retained with conditions. |
| Overview small/micro businesses | Rates table special-status rows; optimization handoff | 1%/3%, 500 k/700 k, monthly 15 th, no employees/30 k/0% retained; full eligibility remains in optimization. |
| Overview profit/financial institutions | Rates table company row | 15%/0.85 and four triggers retained, financial 20% annualbasis retained. No blanket retained-profit shelter. |
| Overview dividend/interest/nonresident WHT | Rates table withholding row | 5/10/15 figures retained; payee/payment/exemption and 15% category scope corrected. |
| Overview VAT and profit/payroll returns | Rates table VAT/profit/payroll rows | 18%,100 k,2 businessdays,rolling 12 months,monthly 15 th and payrollremittance-onpayment retained. |
| Overview annual return and advances | Rates table annual/advance rows | Before 1 April and four 25% instalments retained; micro/small advance exception added from original Georgian text. |
| Overview property and late interest | Rates table finalrows | Up-to 1% and 0.05%daily retained. Property base adjustments/leaseexceptions explicitly prevent a false blanket formula. |
| Overview unresolved pension/excise/import/local/residence items | Sources Not yet confirmed | Every original unresolved topic retained or routed to domainGuide. No new pension/import figures invented. |
| Optimization opening/reference | Scope/quickreference | Every regime, currency and base retained. Unsupported comparative global ranking removed with reason below. |
| Optimization SmallBusiness featuretable | Method 1 | Every one of ten rows retained, all rates and caps, source exclusions, salary 6000/prior 50000, statusends, records, losses, VATinventory retained. Same-yearindividual-entrepreneur registrationcondition made explicit. |
| Optimization MicroBusiness eligibility/barred/status/return/customers | Method 2 | All five original bullets retained. Trading prohibition/processing exception added; prescribed document exception correctly restricted to goods. |
| Optimization VAT/ordinary system | Method 3 | Thresholdcount exclusions, supplysource referral, standard 20/15/5/0.85 and retainedprofit discussion preserved with explicit ordinary-regime/paymentconditions. |
| Original GEL 100 pretax 15+4.25=19.25 case | Method 3 plus WorkedcaseA | All original inputs and outputs retained and executable; dividend 85 and shareholder 80.75 explicitly recompute. |
| CompanyversusSBS low margin or retention topic | Method 3 and WorkedcaseB | Preserved decision topic, removed unsupported overall-only recommendation; two tax-only margin alternatives now compute under explicit same facts. |
| Optimization Internationalcompany all six bullets | Method 4 | Governmentgrant,5%profit/0.95,5%salary,dividend exemption,property except land,noFIZ,expenses andcancellation retained. Missing operative 619 exceptions/substance/status interactions supplied. |
| Optimization Virtualzone all four bullets | Method 5 | Legalperson/ITdefinition,exports/domesticallocation,10+2 workingdays,dividend/salary boundaries retained; Georgian IT creationcondition supplied. |
| Optimization full sevenitem smallbusinessbarredlist | When to refuse or refer | All listed activities retained; taxi exception, consulting, staffing andexcisablegoods preserved. |
| Optimization construction rule andprivate customer statement | When to refuse or refer | B 2 B/organisation/IE exclusion,41.2/42/43,1 Feb 2025 retained. Privateindividual sentence conditioned onvalidstatus,source,1/3%ratetoavoidblanketeligibility. |
| Optimization employment/cap/filing/scope redlines | When to refuse or refer | Salary 20%,threshold 3%,two years,monthly 15 th,late 5/10%,nil fine 0,daily 0.05% retained. IC permittedancillary condition incorporated. |
| Optimization PROHIBITIONS fiveitems | When to refuse or refer | All five refusal instructions preserved. No invented pensions, nilreturnpenalties or status approval. |
| Optimization disclaimer | Before Sources | Original disclaimer retained. |
| Optimization source/read/hold list | Sources | All original primarysources retained aslatestCode/currentpublicchain, with actual dates. Former 415 and 619 unknownchain gaps now closed; allremainingnil filing,virtual grant body,service VAT,pension holds retained. |

## Original and added worked inputs

| Case | Inputs and expected results |
|---|---|
| Original ordinarycompany | GEL 100 pre-tax profit;15%profit;5%dividendwithholding; GEL 15+4.25=19.25. Every original value remains. Added explicit 85 dividend and 80.75 cash. |
| Added overview distribution | GEL 85 before withholding /0.85 =100 base;15 tax;4.25 withholding;80.75 cash;19.25 total. |
| Added comparison both ways | Revenue 100000; costs 90000 and 97000; rates 1%,15%,5%; taxes 1000 versus 1925 and 577.50; differences 925 and 422.50; margin 5.1948051948%. |
| Added threshold case | Prior 490000; October 20000; cap 500000;3%; year 510000,excess 10000,tax 600. |

## Removed and why

The unsourced statement that Georgia has one of the lowest effective rates anywhere was removed. It is a comparative global ranking without a fetched source and adds no rule; the 1% regime it introduced remains. The categorical statement that a company is better only at low margins or when retaining profit was replaced with a tax-only comparison plus explicit non-tax and eligibility conditions. No tax topic, exampleinput, refusal or named credit was removed. Original historical source-read prose was replaced by scoped actual current reads; it is not asserted as independent review.

ge-tax-overview.md: old 7131 bytes; current 11493 bytes. No 25% shrinkage.
georgia-tax-optimization.md: old 16990 bytes; current 31443 bytes. No 25% shrinkage.

## Focused review corrections

No topic or worked input was removed. The rent row now includes article 81(5) legal-person procedure; payroll cash and nonmonetary remittance clocks are explicit; the micro medical exception names paramedic. Existing international-company eligibility and cancellation topics now state each operative route, threshold and date instead of relying on broad references. Native quote anchors GE-007, GE-023 and GE-028 were corrected to the intended provisions; existing ledger GE-055 also records the already required article 97(1) admission rule. All four worked cases remain unchanged.
