Georgia's tax overview and planning workflow now carry the missing eligibility, exclusion and timing conditions beside their headline rates. The original GEL 100 / 15 / 4.25 / 19.25 case inputs and results remain, with four executable controls across the pair.

## Corrected

| Old | New | Authority |
|---|---|---|
| Micro and small-business conditions incomplete | Trading prohibition and processing/medical exceptions, excluded activities and status gates restored | Tax Code; Resolution 415 and its public amendment chain |
| International-company and virtual-zone benefits too broad | Georgian core activity, exact experience routes, ancillary-income cap, incompatible statuses and separate cancellation clocks included | Tax Code; Ordinance 619 and its public amendment chain |
| Rent, payroll and withholding summaries omitted conditions | Legal-person residential-rent register procedure; noncash payroll timing; correct recipient/payment bases | Tax Code arts. 81, 130–134, 154 |
| Categorical incorporation recommendation | Income-tax-only decision with actual status, source, VAT, pension and compliance facts required | Tax Code and preserved case assumptions |

The official [Tax Code](https://matsne.gov.ge/ka/document/view/1043717) and complete public amendment histories were read. No paid consolidation or access control was bypassed. A separate reviewer verifies every ledger row, preserved topic and case, with focused closure of the conditions it identified. This supplies no accountant approval or country-completion claim.

Committed-content validation and strict sync audit must pass without warnings before publication. Skill checks pass, all four examples recompute, and 17 source rows have no misses or unreadable pages in the cached-source check. Shared calculator/copy tests are reused after confirming unchanged scripts/tests. Required CI runs at the final head. Compact indexed evidence: `docs/review-evidence/2026-11-16/europe-continuation/georgia/`.

Virtual-zone grant-body/live procedure, nil small-business return procedure, case-specific VAT/pension facts, fixed-tax grandfather entitlement and detailed maritime/expense-claim mechanics remain explicit non-usable holds. No live application or filing was tested.

## Removed and why

The unsupported worldwide low-tax ranking was removed. The categorical entity recommendation was replaced by the documented tax-only comparison. Historical source-version narration is superseded by scoped current reads. The underlying rates, topics, original case inputs and refusal rules remain; both files grew.

## Moved

Overview bullets become sourced rows. Planning topics move into the canonical decision workflow. The complete no-loss map lists exact destinations and authorities. No file merge or deletion.

## Not moved

No original tax topic or refusal is silently dropped. Unverified implementation conditions remain explicitly non-usable under Sources. Sibling Guides, generated outputs and human approval fields are untouched.

Written by Codex (world wave). Not reviewed by an accountant.
