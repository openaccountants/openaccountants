# Independent review: Georgia overview and tax planning

PASS for the exact two Guide versions below, with explicit nonusable holds retained. Fresh independent Codex reviewer `/root/review_az`, 16 November 2026. This is an AI primary-source review, not professional accountant approval. It covers only `ge-tax-overview` and `georgia-tax-optimization`.

Checked **88 of 88 legal ledger rows** and independently recomputed all **four worked cases**. Every row has a result in [row-results.json](row-results.json); the original and added hypothetical input/result inventory is in the writer's NO-LOSS-MAP.md, with independent recomputations below. No prior complete Georgia review was recovered or reused.

Read the actual operative clauses and neighboring exceptions in the cached official Tax Code (Georgian and English parallel), IT Zones Law arts. 2–6 and the public original-plus-amendment chains. The latest Code publication, 28 October 2026, was independently confirmed on the official publication index. Read all fourteen Resolution 415 amending acts and all seven Ordinance 619 amending acts for their effect on the covered conditions. Fixed-tax and maritime amendments were read for scope, grandfathering and interaction only; full regime application is outside this review. Paid consolidated views were not accessed, and no access control was bypassed. The English clauses for 94 and 274 are stale; the operative Georgian clauses were read and control the review.

The writer applied the corrections below. Targeted closure reviewed those changed rules and dependencies against the completed initial source read; it did not repeat the full source scan or shared test suites.

| Corrections verified closed | Official authority |
|---|---|
| Residential-rent 5% adds legal-person letting register/privilege procedure; payroll adds nonmonetary month-end remittance | [Tax Code arts. 81(2), (5), 154(3)(a)](https://matsne.gov.ge/ka/document/view/1043717) |
| Village medical exception includes nurse/paramedic | [Resolution 98/2021 art. 1](https://matsne.gov.ge/ka/document/view/5120243) |
| IC admission limited to article 97(1) entities; explicit two-year enterprise, foreign-representation and >50% partner routes with each qualifying partner independently experienced | [Ordinance 619 annex 1 art. 2(1)](https://matsne.gov.ge/ka/document/view/5012362), [Ordinance 366/2021](https://matsne.gov.ge/ka/document/view/5221309) |
| IC core Georgian activity/resources, service-contract and related-ancillary cap of 2% confirmed; no general unrelated-income allowance | [Ordinance 180/2021](https://matsne.gov.ge/ka/document/view/5155134), [Ordinance 9/2022](https://matsne.gov.ge/ka/document/view/5352456) |
| Activity-breach cancellation from 1 January of activity-start year; failure of entire status-rule requirements retroactive to original grant; amendment-caused breach from amendment effective date | [Ordinance 279/2023](https://matsne.gov.ge/ka/document/view/5886927), [Ordinance 416/2021](https://matsne.gov.ge/ka/document/view/5243947) |
| Virtual grant cancels IC at grant instant; IC grant cancels virtual status; innovative-startup interaction cancels IC from first day of month after decision | [Ordinance 366/2021](https://matsne.gov.ge/ka/document/view/5221309), [Ordinance 420/2025](https://matsne.gov.ge/ka/document/view/6635309) |
| Ledger native quotes GE007, GE023, GE028 now support foreign-source exemption, financial annual profit and residual nonresident payments respectively | [Tax Code arts. 82(1)(ფ), English (u); 97(12); 134(1)(e)](https://matsne.gov.ge/ka/document/view/1043717) |

Also confirmed the writer's substantive recoveries: micro trading prohibition and processing/supply exception; all small-business barred activities and excluded receipt types; construction customer, source/status/rate conditions; 1%/3% whole-month threshold operation; actual status requirements; ordinary four-trigger profit base and 0.85 gross-up; correct dividend/interest/nonresident payment classes; property base adjustments; virtual IT creation in Georgia plus qualifying foreign supply; Georgian late-return and interest provisions. The passing legal review is based on those source reads, not checker success.

Preservation: read both entire originals and independently compared their topic destinations. Every original tax topic, refusal, boundary, unresolved item and named case input is preserved or expressly corrected. All five original prohibitions remain. Unsupported worldwide ranking and categorical entity recommendation were removed with reasons; the decision topic remains and now computes both margins. Historical read claims were replaced by actual current scoped reads. Both Guides grew. No original protected credit, accountant approval or CTA existed; both remain tier 2.

Independent arithmetic:

- Overview GEL 85 distribution / 0.85 = **100**; profit tax **15**, withholding **4.25**, shareholder cash **80.75**, total tax **19.25**.
- Original GEL 100 pre-tax profit: **15** company tax, **85** declared dividend, **4.25** withholding, **80.75** shareholder cash, total **19.25**. Original 100/15/4.25/19.25 inputs and outputs remain.
- GEL 100,000 receipts: eligible small business **1,000**; company with 90,000 costs **1,925** (925 more); company with 97,000 costs **577.50** (422.50 saving). Combined company rate **19.25%**; break-even profit margin **5.1948051948%**. Comparison expressly excludes differences in status, VAT, pension, salary and retention.
- Threshold: 490,000 + 20,000 = **510,000**, excess **10,000**; the whole October 20,000 at 3% gives **600**, not tax only on excess.

Remaining nonusable holds: current designated virtual-zone grant body/live procedure; nil small-business return procedure; case-specific VAT place of supply and pension entitlement; fixed-tax rates/individual grandfather entitlement; detailed maritime application and expense-claim mechanics. Complete municipal/property/land calculations and special residence procedures remain outside the overview. These holds are explicit and cannot be treated as confirmed entitlements. No live application, filing or payment was tested.

Coordinator owns final committed-content validation, shared tests, live ownership/PR gates and publication. Reviewer fetch failed DNS and was not reported as successful. No Guide/Git mutation, publication, merge or professional approval was performed by this reviewer. Full source captures remain local and are excluded from this review folder.

Exact accepted files:

| Path | SHA-256 | Git blob |
|---|---|---|
| `skills/georgia/ge-tax-overview.md` | `24a7ed7fc4cdee02eb74d8e7d18c28cc3d4c5ce45c6949ea9c70482302f91fc5` | `d9178cc3681c0b952fde3966ffe88d614d3bdcf1` |
| `skills/georgia/georgia-tax-optimization.md` | `2b39f0da7deb6d61198403b2248e305176bd6138e8cc503d45c07e5f48bbc64b` | `8613459c4d23e4d580d19b69e9720fa1ccc06c7c` |

Scope and preservation hashes: [RECEIPT.json](RECEIPT.json).
