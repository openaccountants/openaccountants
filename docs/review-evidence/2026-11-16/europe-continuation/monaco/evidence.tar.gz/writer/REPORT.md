# Monaco writer handoff, 16 November 2026

Candidate: only `skills/monaco/mc-company-formation.md` and `skills/monaco/mc-tax-overview.md`, each 1.3 to 1.4 with matching H1, date 2026-11-16, tier 2. No branch, stage, commit, push, PR or production action was performed. Source base: `bbab4f1a6d82cace432e6ca8eda89c98ffb1c038`. The existing current-main credit lines are preserved exactly: OpenAccountants on formation and Michael Cutajar on overview.

The common brief including Michael's 16 November proportionate-verification rule was read. The current repository AGENTS and template are byte-identical to the ones already read in the preceding lane. Pre-edit checks covered all 19 then-current open PRs and their complete paginated file lists, plus the Claude reservation: no assigned-file overlap. See `pre-edit-open-pr-files.json`.

## Reuse and actual source work

The October 24 research/review and October 25 completion research/full independent review were recovered byte-exact as `prior-*` records. The final completed review approved source `c9f5925bfbb0f3470d0a61ac520efd51f03ba67a` within its stated limits. Exact formation and overview Git blobs named by its independent manifest were recovered; their SHA256s match. `prior-review-applicability.json` establishes that current-main usable legal text equals those reviewed bodies. Excluded differences are disclosed: frontmatter and platform/credit history; relocated overview research links; formation's later addition of explicit non-usable SNC/SCS/board/auditor holds. Those holds remain in the candidate.

One current applicability comparison was performed. Current normalized official visible text equals the retained original primary source for commerce Code, Law 1.573, Law 1.596, Law 1.144, VAT Code, residence ordinance and new-enterprises ordinance. The comparison used the same HTML parser on old and current captures, and is evidence of identity alongside the completed substantive review, not an invented fresh full read. The unchanged native quote/read scopes are in `LEDGER.md` and `ledger.json`.

ISB Ordinance 3.152 changed elsewhere since the old primary capture. Every overview pinpoint, articles 1-4, 14, 21-23 and 29, was separately compared and is unchanged (`isb-pinpoint-applicability.json`). The actual Ordinance 12.211 of 23 October 2026 was retrieved/read, including its 30 October publication and article 4 commencement for financial years opened from 1 January 2026. Its cross-referenced current period/advance/penalty provisions were inspected for the bounded dependency notice. The candidate does not calculate those penalties or revise sibling Guides. The overview cautions against reusing older methods for them.

Government personal-tax scope paragraphs were re-read directly: genuine establishment/activity, French convention and other-state reservations remain. The old employer-PDF filename discrepancy was retained as an explicitly dated 25 October observation instead of asserting a new live-PDF read. The minimum-tax record remains described only as a project, with no general negative enactment conclusion.

Raw official captures and old caches remain local under `cache/`; do not publish them. `applicability-retrieval.json`, `source-applicability-comparison.json` and `cache-manifest.json` give the compact provenance. No form, account or taxpayer portal was submitted/accessed.

## Corrected / changed

| Old | Candidate | Source / reason |
|---|---|---|
| Missing declared shapes; noncanonical headings | Formation situation-rules and overview router; canonical method/referral/input headings | Current template |
| Invalid domain formation | Category formation retained; invalid domain removed | Current domain schema |
| No body version matching frontmatter | Both H1s carry v1.4 | Current template |
| Formation examples only illustrate capital | Original 30000/15000 case gains a SAM funding decision: same 30000 cash budget is 120000 short of SAM150000 minimum | Code35-3; Law1.573arts11/15-16; F16 |
| Overview has headline rates but no recomputing control | Exact25% turnover-boundary example plus independently established100000 taxable profit at25%=25000 | Ordinance3.152arts1-4/21; O15 |
| General present-tense evidence/old consolidation reference | Dated historical PDF observation and bounded current12.211 dependency notice | O12/O14 |
| No common general-reference notice | Required notice added; all original limits retained | Template |

## Preservation

The complete old nonblank line inventory, topics, source rows, refusals, credit and every worked-case input/output are mapped in `NO-LOSS-mc-company-formation.md` and `NO-LOSS-mc-tax-overview.md`. Original 30000/15000 SARL inputs/outputs remain, with one added funding variable/output. Original 300000/150000 SAM block is unchanged. No original topic, case input or hold was removed; neither Guide shrank by 25%. `guide-manifest.json` binds the exact candidate bytes. No protected names/approvals/CTA or generated file was changed.

## Review scope and checks

`LEDGER.md`/`ledger.json` contain 32 full rule/figure/example rows with native snippets, operative pinpoints, URLs, original actual read dates, applicability dates and explicit reuse/delta scope. A separate reviewer should verify the reuse applicability once, review F16/O14/O15 and the shape/referral/date changes, spot-check no-loss maps, and recompute the changed/new controls. Repeating the completed full source scan for unchanged rules is unnecessary under Michael's latest instruction.

- Both skill_checks return `{}` (`skill-checks.json`).
- Two files, three oa-check controls, zero failures/missing (`examples.txt`).
- Row-source check: zero misses and zero unreadable rows (`row-sources.txt`).
- Worktree sync audit against origin/main, strict metadata: zero errors/warnings (`sync-integrity.txt`); shared working tree, not the final committed country head.
- `git diff --check` on the assigned files passed.
- Scoped worktree validator preview: zero warnings, six sparse-checkout dependency errors. It is disclosed as a pre-commit preview harness, not an actual-head CLI pass. Missing global slugs: tax-residency-planning, permanent-establishment-risk, withholding-tax-matrix, eu-social-security-coordination, eu-directives-cross-border, oecd-model-treaty-defaults. Parent owns exact unchanged dependency materialisation and final committed-head CLI checks.
- Parent explicitly owns the one shared calculator/copy test run. This writer did not repeat the suite.

Preparation failures are retained in `INITIAL-FAILURES.md`. No scripts/tests were changed.

## Holds and handoff

Existing formation holds remain explicit and non-usable: SNC/SCS partnership detail, SAM board/auditor obligations, complete registry/beneficial-owner procedures, fees, sanctions, account/audit thresholds and deferred October implementation. Tax specialist schemes and operative multinational minimum-tax calculation remain outside the overview. Professional sign-off has not been obtained or invented.

Writer stopped; fresh independent delta review and final country-head gates/publication belong to parent. Do not label this writer record as independent review. Parent should consolidate one public-safe deterministic indexed evidence package, reference the existing complete public review where useful, and keep raw cache local. No merge, auto-merge or release.

Written by Codex (world wave). Not reviewed by an accountant.
