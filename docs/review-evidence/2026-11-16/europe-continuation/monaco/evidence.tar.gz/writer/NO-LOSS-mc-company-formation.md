# Complete old-topic/input map: mc-company-formation

Every nonblank old line is included, so no old rule, condition, input, source, hold or credit can vanish behind a summary.

| Old line | Exact old content | New destination / disposition |
|---|---|---|
| 1 | --- | Frontmatter/title; version1.3->1.4/dateadvanced/H1matched/typeadded;invalidformationdomainremoved;otherkeys/creditsretained |
| 2 | name: mc-company-formation | Frontmatter/title; version1.3->1.4/dateadvanced/H1matched/typeadded;invalidformationdomainremoved;otherkeys/creditsretained |
| 3 | description: "Monaco company formation reference checked in October 2026. Covers SARL and sole member SURL capital rules, the natural person exception, cash and in kind payment gates, and SAM subscription, minimum paid capital and approval requirements. Use for Monaco incorporation, entity choice and capital planning questions. Separates nationality and activity permissions from registry filings and records the 2025 and October 2026 reform transition limits. Includes two reproducible capital illustrations. Complete forms, beneficial ownership, fees, audit and accounts procedures await a named Monaco professional review." | Frontmatter/title; version1.3->1.4/dateadvanced/H1matched/typeadded;invalidformationdomainremoved;otherkeys/creditsretained |
| 4 | version: 1.3 | Frontmatter/title; version1.3->1.4/dateadvanced/H1matched/typeadded;invalidformationdomainremoved;otherkeys/creditsretained |
| 5 | jurisdiction: MC | Frontmatter/title; version1.3->1.4/dateadvanced/H1matched/typeadded;invalidformationdomainremoved;otherkeys/creditsretained |
| 6 | tax_year: 2026 | Frontmatter/title; version1.3->1.4/dateadvanced/H1matched/typeadded;invalidformationdomainremoved;otherkeys/creditsretained |
| 7 | last_updated: 2026-11-14 | Frontmatter/title; version1.3->1.4/dateadvanced/H1matched/typeadded;invalidformationdomainremoved;otherkeys/creditsretained |
| 8 | category: formation | Frontmatter/title; version1.3->1.4/dateadvanced/H1matched/typeadded;invalidformationdomainremoved;otherkeys/creditsretained |
| 9 | license: AGPL-3.0-or-later (code) / OpenAccountants Guide License v1.0 (content) | Frontmatter/title; version1.3->1.4/dateadvanced/H1matched/typeadded;invalidformationdomainremoved;otherkeys/creditsretained |
| 10 | tier: 2 | Frontmatter/title; version1.3->1.4/dateadvanced/H1matched/typeadded;invalidformationdomainremoved;otherkeys/creditsretained |
| 11 | domain: formation | Frontmatter/title; version1.3->1.4/dateadvanced/H1matched/typeadded;invalidformationdomainremoved;otherkeys/creditsretained |
| 12 | --- | Frontmatter/title; version1.3->1.4/dateadvanced/H1matched/typeadded;invalidformationdomainremoved;otherkeys/creditsretained |
| 14 | # Monaco company formation and capital | Frontmatter/title; version1.3->1.4/dateadvanced/H1matched/typeadded;invalidformationdomainremoved;otherkeys/creditsretained |
| 16 | > **Source-cited draft; partial scope.** Checked 24 October 2026. No named Monaco professional has reviewed this Guide. It produces a working paper, not a filing or a final tax position. Read the [country gap register](README.md) before use. | Frontmatter/title; version1.3->1.4/dateadvanced/H1matched/typeadded;invalidformationdomainremoved;otherkeys/creditsretained |
| 18 | ## Scope and currency | Scope |
| 20 | This retained formation Guide is a source-cited reference checked 24 October 2026. It is an Accounting packs topic, not an extra completed tax domain. It covers core SARL/SURL and SAM capital and permission gates. It does not provide a complete incorporation checklist, accounts/audit implementation or tested registry filing route. | Scope |
| 22 | ## Entity and capital rules | The method, step by step / Entity and capital rules |
| 24 | \| Form \| Rule \| Current official source \| | The method, step by step / Entity and capital rules |
| 25 | \|---\|---\|---\| | The method, step by step / Entity and capital rules |
| 26 | \| SARL \| Minimum EUR 15,000; capital fully subscribed \| [Code de commerce, arts. 35-1–35-3](https://legimonaco.mc/code/code-commerce/) \| | The method, step by step / Entity and capital rules |
| 27 | \| SURL with one natural-person member \| Minimum EUR 8,000; do not apply this exception to every sole-member company \| [Art. 35-3](https://legimonaco.mc/code/code-commerce/) \| | The method, step by step / Entity and capital rules |
| 28 | \| SARL/SURL cash \| At least the minimum capital paid at constitution; fully paid within eighteen months, subject to transition scope \| [Art. 35-3 and consolidation note](https://legimonaco.mc/code/code-commerce/) \| | The method, step by step / Entity and capital rules |
| 29 | \| SARL/SURL in-kind \| Fully paid at constitution; valuation and liability rules apply \| [Art. 35-3](https://legimonaco.mc/code/code-commerce/) \| | The method, step by step / Entity and capital rules |
| 30 | \| SAM \| Minimum EUR 150,000; all capital subscribed, each cash subscriber pays at least one quarter and total paid capital cannot be below the minimum \| [Law 1.573, arts. 15–18](https://legimonaco.mc/tnc/loi/2025/04-08-1.573) \| | The method, step by step / Entity and capital rules |
| 31 | \| SAM cash balance \| Within eighteen months after first constitutive assembly, subject to applicable special rules \| [Art. 16](https://legimonaco.mc/tnc/loi/2025/04-08-1.573) \| | The method, step by step / Entity and capital rules |
| 33 | Code article 35-1 recognises a sole-member SURL. Article 35-3 requires cash paid through a Monaco credit institution account evidenced for RCI registration. Its note limits the eighteen-month rule to companies registered after Law 1.573's entry into force. Assess actual incorporation and registration dates; do not rewrite older companies' obligations from the current rule alone. [Arts. 35-1–35-3](https://legimonaco.mc/code/code-commerce/). | The method, step by step / Entity and capital rules |
| 35 | SAM constitution needs administrative authorisation under article 11. Article 12 allows private deed or notarial deed. Do not repeat the old universal-notary or half-capital rule. In-kind contributions and special advantages need the separate article 18 procedure. Capital is not a formation fee and is not evidence of permission to trade. [Arts. 11–18](https://legimonaco.mc/tnc/loi/2025/04-08-1.573). | The method, step by step / Entity and capital rules |
| 37 | ## Permissions and filing sequence | The method, step by step / Permissions and filing sequence |
| 39 | Determine activity, legal form, nationality of associates/managers and any regulated profession first. Law 1.144 distinguishes declarations for specified Monegasque persons/associates/managers from authorisation for foreign counterparts; specified regulated activities also require authorisation for Monegasque persons. Foreign branches/offices face their own authorisation rule. SAM approval is separate. Do not promise a universal approval time or start date. [Arts. 1–8](https://legimonaco.mc/tnc/loi/1991/07-26-1.144/); [Art. 11](https://legimonaco.mc/tnc/loi/2025/04-08-1.573). | The method, step by step / Permissions and filing sequence |
| 41 | Prepare the applicable permission dossier, constitutional documents, subscriptions, payment/valuation evidence and registry application. This is a working sequence, not a verified exhaustive filing list. Current application forms, beneficial-owner/registry filings, fees and practical acceptance have not been checked end to end. | The method, step by step / Permissions and filing sequence |
| 43 | ## October 2026 reforms and unresolved accounts work | The method, step by step / October 2026 reforms and unresolved accounts work |
| 45 | Read the consolidated Code together with Law 1.596 of 9 October 2026. Its article 93 generally applies from the day after publication; article 102 separately defers four specified provisions until implementing regulations set their date, no later than 31 December 2026. Articles 94–103 also address transitional cases. This Guide has not established the implementing instruments for those deferred provisions or a complete accounts/audit filing calendar. Do not state that every October amendment operates on the same date. [Arts. 93–103](https://legimonaco.mc/tnc/loi/2026/10-09-1.596/). | The method, step by step / October 2026 reforms and unresolved accounts work |
| 47 | ## Two capital illustrations | Worked cases; original inputs/outputs preserved; F16 adds funding comparison only |
| 49 | ### Ordinary SARL cash capital | Worked cases; original inputs/outputs preserved; F16 adds funding comparison only |
| 51 | Assume a new post-reform SARL with EUR 30,000 all-cash subscribed capital and no special requirement. Minimum cash at constitution is EUR 15,000 and the remaining EUR 15,000 falls under the applicable eighteen-month rule, not a statement that 50% is a universal fraction. Code article 35-3. | Worked cases; original inputs/outputs preserved; F16 adds funding comparison only |
| 53 | ```oa-check | Worked cases; original inputs/outputs preserved; F16 adds funding comparison only |
| 54 | name: SARL statutory minimum cash versus subscribed amount | Worked cases; original inputs/outputs preserved; F16 adds funding comparison only |
| 55 | inputs: | Worked cases; original inputs/outputs preserved; F16 adds funding comparison only |
| 56 |   subscribed: 30000 | Worked cases; original inputs/outputs preserved; F16 adds funding comparison only |
| 57 |   minimum: 15000 | Worked cases; original inputs/outputs preserved; F16 adds funding comparison only |
| 58 | steps: | Worked cases; original inputs/outputs preserved; F16 adds funding comparison only |
| 59 |   - initial_minimum: min(subscribed, minimum) | Worked cases; original inputs/outputs preserved; F16 adds funding comparison only |
| 60 |   - remaining: subscribed - initial_minimum | Worked cases; original inputs/outputs preserved; F16 adds funding comparison only |
| 61 | expected: | Worked cases; original inputs/outputs preserved; F16 adds funding comparison only |
| 62 |   initial_minimum: 15000 | Worked cases; original inputs/outputs preserved; F16 adds funding comparison only |
| 63 |   remaining: 15000 | Worked cases; original inputs/outputs preserved; F16 adds funding comparison only |
| 64 | ``` | Worked cases; original inputs/outputs preserved; F16 adds funding comparison only |
| 66 | ### SAM aggregate floor overrides one quarter | Worked cases; original inputs/outputs preserved; F16 adds funding comparison only |
| 68 | Assume EUR 300,000 all-cash SAM capital, equal cash payment proportions for every shareholder and no special requirement. One quarter would be EUR 75,000, below the EUR 150,000 minimum. At least EUR 150,000 must therefore be paid overall, while each subscriber's quarter test is independently satisfied. EUR 150,000 remains due under article 16. | Worked cases; original inputs/outputs preserved; F16 adds funding comparison only |
| 70 | ```oa-check | Worked cases; original inputs/outputs preserved; F16 adds funding comparison only |
| 71 | name: SAM quarter subscription with aggregate minimum floor | Worked cases; original inputs/outputs preserved; F16 adds funding comparison only |
| 72 | inputs: | Worked cases; original inputs/outputs preserved; F16 adds funding comparison only |
| 73 |   subscribed: 300000 | Worked cases; original inputs/outputs preserved; F16 adds funding comparison only |
| 74 |   minimum: 150000 | Worked cases; original inputs/outputs preserved; F16 adds funding comparison only |
| 75 | steps: | Worked cases; original inputs/outputs preserved; F16 adds funding comparison only |
| 76 |   - quarter: subscribed / 4 | Worked cases; original inputs/outputs preserved; F16 adds funding comparison only |
| 77 |   - initial_minimum: max(quarter, minimum) | Worked cases; original inputs/outputs preserved; F16 adds funding comparison only |
| 78 |   - remaining: subscribed - initial_minimum | Worked cases; original inputs/outputs preserved; F16 adds funding comparison only |
| 79 | expected: | Worked cases; original inputs/outputs preserved; F16 adds funding comparison only |
| 80 |   quarter: 75000 | Worked cases; original inputs/outputs preserved; F16 adds funding comparison only |
| 81 |   initial_minimum: 150000 | Worked cases; original inputs/outputs preserved; F16 adds funding comparison only |
| 82 |   remaining: 150000 | Worked cases; original inputs/outputs preserved; F16 adds funding comparison only |
| 83 | ``` | Worked cases; original inputs/outputs preserved; F16 adds funding comparison only |
| 85 | ## Ask before choosing the route | Ask the client first |
| 87 | - What activity, form, associates/managers, nationality and regulated status are intended? | Ask the client first |
| 88 | - Is the sole member a natural person, and what cash/in-kind capital is proposed? | Ask the client first |
| 89 | - What constitution/registration dates and existing permissions apply? | Ask the client first |
| 90 | - What premises, beneficial ownership, audit and accounts requirements arise? | Ask the client first |
| 92 | ## Sources | Sources |
| 94 | \| Official source and provisions read \| URL \| Read on \| | Sources |
| 95 | \|---\|---\|---\| | Sources |
| 96 | \| Code de commerce, arts. 35-1–35-3 and transition note \| https://legimonaco.mc/code/code-commerce/ \| 2026-10-24 \| | Sources |
| 97 | \| Law 1.573, arts. 11–18 and art. 101(7) \| https://legimonaco.mc/tnc/loi/2025/04-08-1.573 \| 2026-10-24 \| | Sources |
| 98 | \| Law 1.144, arts. 1–8 \| https://legimonaco.mc/tnc/loi/1991/07-26-1.144/ \| 2026-10-24 \| | Sources |
| 99 | \| Law 1.596, arts. 93–103 \| https://legimonaco.mc/tnc/loi/2026/10-09-1.596/ \| 2026-10-24 \| | Sources |
| 101 | **Not yet confirmed:** SNC and SCS partnership rules, SAM board size and statutory-auditor duty (carried in the earlier version without a cited provision), complete registry/beneficial-owner procedures, fees, sanctions, account/audit thresholds and deferred October implementation. Obtain Monaco professional review before incorporation or filing. | Sources |
| 103 | > Contributed by OpenAccountants. | Exact original credit line preserved byte-for-byte |

## Removed and why

No substantive topic, original worked input/output, source or refusal was removed. Headings were renamed/reordered to the declared shape; overview gained one required recomputing control. Invalid domain formation was removed while category formation remains. The misleading current-PDF present tense became an explicitly dated historical observation. No source read date was reset to imply a full fresh scan. No file shrank by 25%.

Old bytes7692; new bytes10066.
