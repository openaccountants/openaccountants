# Turkmenistan writer handoff, 16 November 2026

The complete assigned two-file candidate is frozen for the coordinator's independent source review. This is writer evidence, not accountant approval or an independent review.

## Files and inventory

- `skills/turkmenistan/tm-income-tax.md`: version1.1, tax year2026, 35 ledger rows, two new illustrative cases.
- `skills/turkmenistan/tm-payroll-social.md`: version1.1, tax year2026, 19 ledger rows, two new illustrative cases.
- Every original bullet and the payroll introduction have a destination table in the corresponding ledger. Exact original snapshots are under `originals/`. There were no original worked inputs, refusals, human names, approval fields, contribution credits or protected CTAs. The platform licence is unchanged and tier remains2.

## Recovery and source access

Git history for the exact target paths contained layout/domain/trust edits, with no recovered target-file research or independent legal review. The central recovery path inventory and targeted search found repeated clone/generated copies, not completed Turkmen legal work. Sibling overview/CIT Guides contain prior actual Tax Code readings, but that does not establish a full review of either assigned original. No previous target-file full review is claimed.

The official Russian Parliament Tax Code and Pension Insurance Law bodies were downloaded once and read from the cache, including residence, income exclusions, neighboring deduction conditions, reporting/payment conditions and coverage exceptions. Native ledger fragments were matched exactly after whitespace normalisation. Statutes are authoritative primary legal text; their available Russian version is an official translation. The pension consolidation identifies amendments through22November2025 and the statute's original commencement1January2013. The Tax Code's commencement rule and exceptions were read; no 2026 legislative change or specialist entitlement is inferred from a search snippet.

Cached `tax-code-ministry-index` was used to locate official code copies. Additional Ministry of Justice fetches rendered a site shell in the accessible body and did not establish operative paragraphs or a current consolidation date. They support no legal claim in the Guide. No access-control bypass or paid source was used.

## Corrections

- Tax deduction is a statutory basic unit rather than the old unsupported1280TMT amount. Its current TMT value remains explicitly non-usable until the operative instrument is obtained.
- PIT residence/source conditions, personal-property and bank-interest exclusions, documented disposal costs, main-workplace deductions and first incomplete employment month now determine the calculation.
- PIT remittance is tied to the income bank payment/withdrawal date; annual agent information is due20January. Individual filing/payment distinguish ordinary non-foreign self-filers from foreign citizens, including departure rules.
- Employer pension20% and additional designated occupational3.5% are distinct from voluntary employee saving of at least2%. Employer own-fund financing, category-specific bases and coverage, payment-date remittance and next-month declaration are stated separately.
- The resident employee territorial levy is included in the payroll examples so the stated pay after specified deductions does not omit it.

## Genuine non-usable holds

Current tax basic-unit TMT value/instrument; current approved declaration, certificate and application editions, electronic filing route and field mapping; specific occupational lists, employer concessions, non-employee minimum-wage bases and applicable treaty/special-regime instruments for an actual claimant. The usable ordinary rules are not described as comprehensive specialist coverage.

## Verification already performed

All19 skill checks have no problems for each changed Guide. Four arithmetic blocks pass. Sync-integrity audit against the actual base checks two source Guides with zero errors, warnings or notices. Calculator quote tests20/20 and repository copy rules2/2 pass. Row-source checker used its actual `read_bytes` parser with the once-downloaded official HTML in its normal cache: four numeric table rows, zero misses and zero unreadables.

The ordinary `validate-guides --changed-only --no-index-check` command sees zero committed Guide changes because this writer is prohibited from committing. Its output is retained honestly. A separate working-tree selection harness ran the unchanged validator over the exact two uncommitted Guides against actual merge-basebbab4f1a, with zero warnings. The coordinator must run the ordinary committed gate at publication. Initial header/sparse-dependency failures and the first ephemeral import-path failures are preserved in validation logs; none required a repository script edit.

No commit, push, PR, merge, source-checker edits or self-certification was performed. Only the assigned two Guide files are modified in Git. Root owns the fresh independent review and final publication checks. Raw source documents stay local.

## Frozen SHA256

- `skills/turkmenistan/tm-income-tax.md`: `d702843248b21429da208a19ced39e65d520d978ecccbfe283b1f93415030859`
- `skills/turkmenistan/tm-payroll-social.md`: `22fac56ad3ced1379b42c4c5cf785569ea34d66efc2a56c806d5d33d553d7611`
- `ledgers/tm-payroll-social.md`: `ae1f713e36815e8fe89cb911b5051fc6c9da92f2f035df6e46708bd3df27624f`
- `ledgers/tm-income-tax.md`: `7bc86fb3ffd7fc32484d1e0eefa82026e4e20d99afe2ee3632d8b8531e70182b`

Independent pinpoint IT17/IT33 corrections are recorded in `deltas/IT17-IT33.md`. Only the income Guide/ledger were corrected; payroll unchanged. Existing unchanged primary review/calculations are retained. The independent reviewer owns final delta confirmation.
