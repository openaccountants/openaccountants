# Turkmenistan independent two-Guide pack review

**PASS after two pinpoint corrections.** Independent source review completed on 16 November 2026 by a reviewer different from the writer. This is advisory research review, not accountant approval.

## Complete inventory and actual authority review

Checked every **54 ledger entries: IT01–IT35 (35) and PR01–PR19 (19)**, including each rule, figure, condition and explicitly non-usable hold. Read both complete Guides and both original files. Checked all20 original-topic map entries, including the payroll introduction, against byte-exact snapshots independently matched to Git base `bbab4f1a6d82cace432e6ca8eda89c98ffb1c038`. No original example inputs, refusals, protected human names, approval, credits or CTAs existed; platform licence and tier2 remain intact. All original topics have operative treatment or an explicit corrected/held destination.

Independently opened/read the actual cached official Parliament Russian Tax Code and Pension Insurance Law paragraphs, not merely ledger quotations. Scope included Tax Code arts1–6,14,30,70,182–200 and207–209, plus the actual154/155 expense cross-reference context; Pension Law arts2–7,19–23,34 and49–50, including coverage and neighboring exceptions. Every native ledger fragment also matches both cached text and independently parsed actual HTML. Row-by-row operative-context verdicts and exact source/cache hashes are in `independent-checks.json`; fragment checks are supplemental evidence, not a substitute for the paragraph review.

Read the Tax Code introduction/restatement commencement and exceptions, including deferred2030 procedural provisions; none was imported into current ordinary PIT guidance. Read the pension amendment list through22November2025 and art50 original1January2013 commencement. Neither Guide invents a2026 legislative change.

## Corrections resolved with actual sources

1. **IT17:** art189(2) limits professional/civil-contract and author actual-expense deductions under189(1)(b)–(c) to the art155 material-expense category, including VAT. The initially broader wording omitted this neighboring restriction. The writer added it to the Guide and ledger; the reviewer checked that precise delta against actual arts189(2) and155. Official source: https://mejlis.gov.tm/single-code/10?lang=ru.
2. **IT33:** the Ministry-approved declaration statement now cites actual art30(1), with the exact native quote and Sources scope added. Arts195/197 continue to bind certificates, agent location and return contents. Current form/portal holds remain. Same official source.

The corrected frozen income Guide is bound below. Payroll bytes and all four arithmetic blocks remained unchanged; no completed unchanged review was repeated.

## Every example recomputed

- PIT case1:5,000 first-incomplete-month salary, main workplace, no exemption/reduction/prior tax; art195(3) prevents agent188 deductions, yielding500 withholding. Annual correction remains separate.
- PIT case2:10,000 proceeds minus7,000 documented costs =3,000 taxable securities gain component;10%=300 before any annual188 deductions. Eligible personal-property sale remains excluded, PIT0.
- Payroll case1:5,000 salary ×20%=1,000 employer pension;500 PIT and5 resident levy produce4,495 after specified deductions. Salary plus employer pension=6,000. All supplied coverage/election/prior-payment facts retained.
- Payroll case2: same5,000 first-incomplete-month salary and confirmed whole-base occupational eligibility;20%=1,000, additional3.5%=175, optional2%=100. PIT remains500 at this withholding stage. Pay=4,495 without voluntary saving or4,395 with it; salary plus both employer pensions=6,175 under either choice.

## Remaining explicit limits and validation

The current tax basic-unit manat value/instrument, approved form editions and field mapping/electronic routes, and claimant-specific occupational/reduced-rate/minimum-wage/treaty/special-regime instruments remain non-usable holds. The former1,280TMT amount is expressly blocked. Ordinary employer20%, designated occupational3.5%, voluntary-contract minimum2%, residence/source/first-month distinctions and the separate resident employee5TMT levy are supported within their stated scope. No unresolved factual defect remains in the reviewed ordinary rules.

Reused the writer's completed validation evidence; independently recomputed all four cases without rerunning full suites or source hunts. The ordinary uncommitted changed-only gate checked zero files, explicitly disclosed by the writer; the coordinator must run the actual committed publication gate. Raw source bodies stay local. No Guide/script edit, commit, push, PR action or accountant attestation was performed by this reviewer.

## Exact final bindings

- `skills/turkmenistan/tm-income-tax.md`: `d702843248b21429da208a19ced39e65d520d978ecccbfe283b1f93415030859`
- `skills/turkmenistan/tm-payroll-social.md`: `22fac56ad3ced1379b42c4c5cf785569ea34d66efc2a56c806d5d33d553d7611`
- Ledger `tm-income-tax.md`: `7bc86fb3ffd7fc32484d1e0eefa82026e4e20d99afe2ee3632d8b8531e70182b`
- Ledger `tm-payroll-social.md`: `ae1f713e36815e8fe89cb911b5051fc6c9da92f2f035df6e46708bd3df27624f`
