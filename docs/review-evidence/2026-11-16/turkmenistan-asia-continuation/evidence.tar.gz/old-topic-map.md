# Turkmenistan complete old-topic map

The authoritative complete map is included in each ledger to keep each review inventory self-contained.

- `ledgers/tm-income-tax.md`: all10 original bullets.
- `ledgers/tm-payroll-social.md`: original introduction and all9 bullets.

No original examples, refusal cases, human credits, approval fields or protected CTAs existed. Original snapshots are in `originals/`.
