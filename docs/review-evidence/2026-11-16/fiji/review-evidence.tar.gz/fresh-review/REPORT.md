# Fiji fresh cumulative independent review

**Qualified PASS for the exact five-file candidate, within its stated scope and explicit holds.** No new material Guide defect was found. This is a complete independent source/content review, not accountant approval or a claim that Fiji coverage is complete. The country delivery should remain draft while its genuine source holds remain.

Reviewed on 16 November 2026 by a fresh separate Codex reviewer, independently of the writers. No subagents were used. No candidate, README, sibling, old evidence or old checkout was edited. The old reviewer chat was not contacted.

Review head: `14de6846bf3bc95365da20364024a1c05c9ad90d`.

Current main supplied and mechanically validated by the coordinator: `bbbab4f1a6d82cace432e6ca8eda89c98ffb1c038`.

The five reviewed files exactly match the recovered frozen source at `34d3435b4f7da42cb95d290f6a9bd4e7c096b66f`. Later evidence-only commits do not invalidate this content review if all five SHA256 values remain equal.

| Reviewed path under skills/fiji/ | SHA256 |
|---|---|
| fiji-vat.md | add26b923bf25a9394e6420afddd0f7ec74a2fd7c4de4699053f0d4339f89f35 |
| fj-company-formation.md | 37023a7ed36ecfe9b0e92769f6d4e3746e77e0d0bc387eec99364472a93e7428 |
| fj-corporate-income-tax.md | 0b85989ee9ddb5819075e1952a7d2429bafde5be87f96d7be1a0fcf8a1b96c06 |
| fj-payroll-social.md | 2435f5d277c1dac19f7e85870341b37982493a7e6c15799a86b902b982eba1a6 |
| fj-tax-overview.md | 3da7df0637f1edba4d56059b7f93bb10d74a9732b34cf9bac75419ac19527c7c |

## Inventory and actual work

All five final bodies and their original bodies were read. The complete unchanged income-tax sibling and generated README were read for compatibility and preservation only; their tax claims are not newly certified.

- **123 ledger groups assessed:** 18 formation, 19 corporate, 9 overview, 41 VAT and 36 payroll groups. These contain 119 primary-source rule or historical groups and four case/internal-workflow inventories. Every group has an independent disposition in `LEDGER-ASSESSMENTS.json`. Repeated rules and all twenty individual rate cells were checked; 123 is not a count of distinct numerical facts.
- **35 actual scoped official-source reads:** 34 sources supporting this five-file review and the March 2026 Income Tax amendment as extra sibling context. Complete operative paragraphs, definitions, conditions, commencement and neighbouring exceptions were read in the scopes recorded in `SOURCE-READS.json`. Long Acts were read only in the named scopes. Short Acts explicitly marked entire were read in full. Existing authentic official caches were reused; a fresh source read is not represented as a fresh network acquisition of every PDF.
- **119 writer quote groups matched** after transcription normalization, separately from substantive source review. Four other groups inventory internal controls or illustrative cases. `SOURCE-READS.json` supplies a short original-language anchor per source and hashes its cached text; the bound writer ledgers carry each group's original quotation. Quotes or hashes did not substitute for reading the operative clauses.
- **Five PDF page images inspected:** LN 55/56 pages 4-6, including both complete rate tables and the cumulative PAYE formula, plus the complete 2014 and 2026 FNPF amendment pages. Fresh official web reads also covered the 2026 FNPF amendment, 2026 Income Tax amendment, employer-page split and historical Government wage address.
- **592 original nonblank lines in the five Guides accounted for**, including 541 body lines excluding frontmatter. `ORIGINAL-LINE-PRESERVATION.json` binds every original line to its checked destination and disposition. Writer map display substitutions for pipes/em dashes were normalized only for comparison; the original text remains exact in the canonical inventory. No legal topic remains lost.
- **16 worked cases independently recomputed**, including all 41 declared expected outputs. A separate Decimal marginal-slice implementation derives income tax from the enacted bands; candidate step expressions were not evaluated to manufacture expected answers. Twenty-two additional resident/nonresident boundary results were calculated. All match. `INDEPENDENT-ARITHMETIC.json` records every input and result.
- **122 final table rows containing digits inventoried.** This broad count includes Sources dates, citation section numbers and workflow rows. It is deliberately distinct from the stock checker's 33 recognized rows and from the 123 substantive ledger groups. Full prose was reviewed as well.

`SOURCE-CACHE-PROVENANCE.json` records independent rehashing against existing acquisition evidence. Full law documents, HTML captures, raw session data and page images are not included in the public manifest.

## Prior findings and independent resolution

| Prior finding | Current independent result | Operative authority |
|---|---|---|
| FJ-F01: VAT maintenance link lost | Closed. The original canonical maintenance sentence is restored verbatim at the final line. Its old-line mapping now names that actual destination. Lost content restored before this fresh review: **1 maintenance route**. | Original VAT line 271 and current VAT line 230 |
| FJ-F02: credit/debit-note timing omitted payments basis | Closed. Method 6 distinguishes invoice issue-period treatment from directed payments-basis treatment. All hire-purchase, financial-lease and non-independent-person exceptions are stated and the actual basis direction is required. | [VAT Act, full sections 36, 39(2)-(4) and 42](https://frcs.org.fj/files/2026/06/VALUE-ADDED-TAX-ACT-1991-Revised-to-1-August-2025.pdf) |

The earlier three-file preflight and previous five-file review were read for provenance and known findings. Neither substitutes for this fresh complete cumulative review. Their original records remain unchanged.

## Material reconciliations verified

The FRCS consolidation reproduces obsolete company/individual rate tables and a one-ninth startup estimate. The actual [LN 55/56 of 2023](https://www.frcs.org.fj/wp-content/uploads/2023/08/LN-52-65-Customs-Budget-Amendment-Income-Tax-Regs-Water-Resources.pdf) and [Act 5 of 2024, section 5](https://frcs.org.fj/files/2024/08/Act-5-Income-Tax-Budget-Amendment-Act-2024.pdf) override those passages. Current company rates, individual bands, cumulative PAYE and `(30,000 - 3,000) / 3 = 9,000` advances are correctly represented.

The enacted temporary FNPF total is 16% from August 2026 through July 2027. The [2026 Act](https://www.parliament.gov.fj/wp-content/uploads/2026/07/Act-21-Fiji-National-Provident-Fund-Budget-Amendment-Act-2026.pdf) changes section 37; it does not expressly amend section 39's [2014 recovery fraction](https://www.parliament.gov.fj/wp-content/uploads/2017/03/ACT-No-13-FNPF-Budget-Amendment.pdf?ver=1794354122). On FJD 3,750 covered August wages, total contributions are FJD 600. Applying 8/18 gives FJD 266.666... before rounding, while the [agency's 8% employee statement](https://myfnpf.com.fj/employers/) gives FJD 300. The candidate preserves this conflict as an unusable employee-deduction branch and does not certify a post-August payslip/employer split. The deleted original section 37(5) was not silently revived to resolve it.

The VAT inclusive fraction is one-ninth under the current rate. The four original bank inputs remain exact: FJD 1,090 sale, FJD 5,000 export, FJD -218 Azure charge and FJD -25 account fee. Their revised outcomes are conditional on stated evidence. The Azure example uses actual foreign consideration FJD 218, output VAT FJD 27.25 and no unsupported matching input offset. The six payroll raw inputs also remain; unsupported annual/post-August net-pay and employer-cost results are held rather than filled with assumed rates.

The final enacted 2026 tax, VAT, beneficial-ownership and Tourism Services Tax provisions were read with their distinct commencement dates. Announcements and Bills were not accepted as operative law. The historical wage announcement remains explicitly historical, and its arithmetic case does not certify current wage compliance.

## Preservation, protected fields and limits

All old rule/referral categories, bank-pattern queues, internal FJD 10,000/FJD 500 VAT review flags, six payroll refusal IDs, two VAT refusal IDs, workbook purposes/columns, onboarding facts, edge cases and regression topics retain destinations. Obsolete or unsupported rate, exemption, default, finality and penalty instructions are corrected, withdrawn or explicitly held. Duplicate headings/disclaimers and repeated compressed rules were consolidated. No file shrank by more than 25%; all five are larger than their originals. No contributed file was deleted.

Names, jurisdiction, licence, tier and existing reviewer/author/contributor metadata are preserved. All five remain tier 2 without a named approver. No protected CTA marker was added, edited or removed. Versions and body headings match the recovered candidate, and the content date is 16 November 2026.

Genuine limits remain: the post-August FNPF recovery instrument and complete current coverage/amendment chain; current national/sector wage instruments; foreign-investment detailed regulations and fees; charitable-company appointed commencement; special incentives, 2026 insurance withholding and transaction-specific treaties/foreign credits; special VAT medicine/concession/vehicle/entertainment/imported-service deduction facts; actual client documents, approved obligations and live portal fields. The unchanged income-tax sibling retains its own later-law and other explicit holds. None is newly certified through this review. These holds must remain outside usable conclusions.

**Separate README observation:** the current generated `skills/fiji/README.md` is unchanged and still says all six Guides are 2025/need updating with `partial: {}`. It is stale relative to the five reviewed 2026 files and the current income-tax sibling. It is outside this reviewer's five-file ownership and was left unchanged. The prior review's different README with explicit partial entries is not the current README, so that earlier README conclusion is not carried forward.

## Validation attribution

The coordinator reported completed checks at source head `14de6846`: five `skill_checks` results `{}`, changed-Guide validation with zero warnings, 16 executable examples, strict sync with zero errors/warnings, stock live checker 33 recognized rows with zero MISS/UNREADABLE, supplemental cached checks, calculator quote preservation and tests, and copy-rule tests. These are **coordinator-run checks**, not reruns or independent source-review counts. This reviewer independently performed the substantive reads, metadata comparison, source-cache rehash, exhaustive map binding and 16-case/41-output recomputation recorded here. Mechanical suites were not repeated for the evidence wrapper.

An attempted local `git status -sb` triggered an unavailable sparse-promisor fetch because the local shell could not resolve GitHub. Exact `git rev-parse HEAD` and all five file hashes were obtained successfully; no network fetch result is claimed by this reviewer. The coordinator owns current-main mechanical validation and country PR publication. No hosted CI, live filing, production database, deployment or professional sign-off is claimed.

## Canonical public artifact index

`PUBLIC-MANIFEST.json` lists each public-safe artifact and its exact SHA256. It excludes the local build script, all full/raw source material and previous evidence directories. Preserve these canonical artifacts byte-exact. A readable display projection may explain old wording, but must not overwrite canonical records.

Written by Codex. Independently source-reviewed by Codex. **Not reviewed by an accountant.**
