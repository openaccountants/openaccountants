# fj-tax-overview ledger projection

Mechanical per-slug projection of preserved original writer ledger units. Fresh independent assessment is a separate record.

| ID | Figure/rule | Provision | Official URL | Short native quote | Read on |
|---|---|---|---|---|---|
| O01 | FRCS identity and FJD local-tax convention; only a navigation source, operative law controls. | Authority current tax headings/tables | https://frcs.org.fj/tax-rates-and-codes/ | Non-Resident Withholding Taxes | 2026-11-16 |
| O02 | Calendar/substituted year, source/residence and return due date; sole final-withholding employment does not always require return. | sections14,36,104-105,125; definitiontaxyear | https://frcs.org.fj/files/2026/06/INCOME-TAX-ACT-2015-Revised-to-1-August-2025.pdf | has 2 or more employments at the same time | 2026-11-16 |
| O03 | Resident nil30000, top39% above1m;20% intermediate only; nonresident no resident nil band. | LN55 regulation3(a); resident/nonresident tables | https://www.frcs.org.fj/wp-content/uploads/2023/08/LN-52-65-Customs-Budget-Amendment-Income-Tax-Regs-Water-Resources.pdf | $318,500 + 39% | 2026-11-16 |
| O04 | SRT definition/separate charge removed1Jan2024; no additive high-income SRT table. | sections1-3 | https://www.frcs.org.fj/wp-content/uploads/2023/07/Act-5-Income-Tax-Budget-Amendment.pdf | deleting the definition of “Social Responsibility Tax” | 2026-11-16 |
| O05 | Standard VAT12.5% with classification conditions; inclusive worked example1125/1.125=1000 and125VAT; not input-credit proof. | sections2,15; schedules1-2 | https://frcs.org.fj/files/2026/06/VALUE-ADDED-TAX-ACT-1991-Revised-to-1-August-2025.pdf | 12.5% | 2026-11-16 |
| O06 | FRCS marks former service ECAL removed and separates VAT/TST; exact historical repeal instrument held. | VAT tax-label table | https://frcs.org.fj/our-services/taxation-section/non-individuals/reporting-and-paying-taxes/vat-guide/ | Removed as per revised 2021-2022 budget | 2026-11-16 |
| O07 | TST1Sep2026;5% annual gross turnover over2m for scheduled services; invoice separately and no VAT on TST itself, monthly accountable-person return/payment. | sections1-4 and Schedule | https://www.parliament.gov.fj/wp-content/uploads/2026/07/Act-20-Tourism-Services-Tax-Act-2026.pdf?ver=1794354122 | not be subject to the value added tax | 2026-11-16 |
| O08 | CRS Jan2027 distinct from BOAug2026; do not apply entire bill/announcement retrospectively. | sections1,6-7 | https://www.parliament.gov.fj/wp-content/uploads/2026/07/Act-13-Tax-Administration-Budget-Amendment-Act-2026.pdf?ver=1794354122 | except for section 6 which comes | 2026-11-16 |
| O09 | Final enacted law startsAugust2026, not original filing-year proposal. | section1 | https://www.parliament.gov.fj/wp-content/uploads/2026/07/Act-14-Income-Tax-Budget-Amendment-No.-2-Act-2026.pdf?ver=1794354122 | This Act comes into force on 1 August 2026. | 2026-11-16 |
