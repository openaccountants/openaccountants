from pathlib import Path
import json, re, hashlib, datetime

HERE=Path(__file__).resolve().parent
EV=HERE.parent/'evidence-fiji'
HEAD='5c56d52149f457c628f9e8741d9c225911ae38f4'
def save(n,x): (HERE/n).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

quotes={x['id']:x for x in json.loads((HERE/'quote-transcription-check.json').read_text())}
rows=json.loads((EV/'root-native-quote-ledger.json').read_text())+json.loads((EV/'payroll-vat-writer/ledger-units.json').read_text())
decisions=[]
for r in rows:
    i=r['id'];q=quotes[i]
    status='CHECKED_WITHIN_STATED_SOURCE_AND_GUIDE_LIMITS'
    note='Final candidate wording checked against the complete operative cited branch and relevant neighbours in source-read-records; quote match is transcription evidence only.'
    if i=='V33':status='CHANGES_REQUIRED';note='FJ-F02: unqualified issue-period direction omits the payments-basis rule and exceptions in VAT section39(4).'
    if i in ['V40','V41','P34','P35']:status='WORKFLOW_AND_CASE_PRESERVATION_CHECKED';note='Not a statutory quotation group. Compared original fixtures, referral IDs, supplier cues, onboarding/workpaper controls and final cases. VAT maintenance-link loss recorded separately as FJ-F01.'
    if i in ['V25','V26']:
        note='Ledger supplies more statutory detail than the final Guide spells out. Section39(7) de-minimis amounts and section39(6) late-input three-year limit were actually checked in the law; Guide refers to these tests but does not publish those figures as a standalone instruction. Do not count every ledger detail as a separate published numeric claim.'
    if i=='P27':note='Both statutory instruments and the agency statement actually read. Temporary16% total is established; 8/8 employee/employer agency claim is not treated as enacted. Candidate explicitly holds net-pay/cost finalisation on this unresolved branch.'
    if i=='P32':note='Official historical budget wage section independently read on web. Figures are retained as announcement history and raw-input arithmetic; current enacted wage instrument remains expressly held.'
    if i in ['F12','F16','F17','F18','C14','C19','O06','O08']:
        note+=' Commencement, unretrieved detailed regulation, historical repeal, treaty or workflow limit is retained; no unverified operational result accepted.'
    decisions.append({'id':i,'file':r.get('file'),'claim':r.get('rule',r.get('claim')),'provision':r.get('provision',r.get('section')),'official_url':r.get('official_url',r.get('url')),'source_cache':q['source_cache'],'source_sha256':sha(Path(q['source_cache'])) if Path(q['source_cache']).is_file() else None,'quote_transcription':q['status'],'review_status':status,'review_note':note})
assert len(decisions)==123 and sum(x['review_status']=='CHANGES_REQUIRED' for x in decisions)==1
save('final-ledger-assessments.json',{'head':HEAD,'groups':decisions,'primary_quote_groups':119,'workflow_case_groups':4})

# Independent original-line disposition. Every changed-file line is inventoried;
# section destinations are based on complete original and final-body reads.
vat=[(1,12,'Frontmatter; companion dependency retained and formalised'),(13,48,'Scope, quick reference, method1–2; obsolete rates/categories corrected'),(49,60,'Ask the client first; R-FJ-1/R-FJ-2 refusal section'),(61,120,'Method3 supplier library; classification evidence controls'),(121,166,'Worked cases1–4; exact original raw inputs retained, false derivations corrected'),(167,200,'Methods1–6 and classification table; obsolete blanket rules corrected or expressly held'),(201,222,'Methods3–5, refusal section; evidence holds replace unsupported zero/default classification'),(223,226,'Method6 workbook and original summary categories'),(227,230,'Method6 statement format/own-transfer controls'),(231,252,'Ask the client first; actual registration/period/credit and industry/export evidence'),(253,266,'Sources, explicit remaining holds and version2.1 change record'),(267,275,'Single general-reference notice; duplicate disclaimers consolidated')]
pay=[(1,11,'Frontmatter; protected identity/license/tier retained'),(12,59,'Scope, quick reference, ask-first controls; old caps/levies/defaults corrected'),(60,76,'Ask the client first; all six refusal IDs retained'),(77,106,'Method1–3 resident table and actual cumulative formula'),(107,132,'Method2 SRT/ECAL history and corrected current tax treatment'),(133,143,'Method1–3 nonresident table/code/coverage distinction'),(144,173,'Methods4–6 FNPF base, coverage, month/rate/recovery conflict and directions'),(174,186,'Method6 PAYE registration/timing/payment/reporting/certificates'),(187,197,'Method7 wage announcement versus current legal-instrument hold'),(198,208,'Method7 corporate context and corporate-Guide handoff'),(209,242,'Method8 all bank/payment patterns and exclusions as evidence controls'),(243,333,'Worked cases1–6: raw facts retained; period assumptions explicit; unsupported full-year net/cost held'),(334,360,'Operative methods plus refusal/prohibitions; deterministic false rules corrected and judgment gaps retained'),(361,389,'Method8 A–O workbook purposes, prior-history inputs, controls and reconciliations'),(390,407,'Method8 statement and terminology guide; definitions corrected to statute'),(408,418,'Ask the client first and method8 onboarding/evidence holds'),(419,433,'Sources and explicit remaining holds; primary sources replace stale/derivative links'),(434,445,'Retained regression controls and all six case calculations; wrong bracket totals corrected'),(446,458,'Refusal section corrected prohibitions, no invented rates/caps/finality'),(459,461,'Single general-reference notice; actual-return qualified review retained')]
rootmap={(Path(x['file']).name,x['old_line']):x for x in json.loads((EV/'root-old-line-map.json').read_text())}
oldlines=[]
for p in sorted((HERE/'originals').glob('*.md')):
    if p.name=='fj-income-tax.md':continue
    for num,text in enumerate(p.read_text().split('\n'),1):
        if not text.strip():continue
        status='PRESERVED_OR_EXPLICITLY_CORRECTED_HELD_CONSOLIDATED'
        if p.name=='fiji-vat.md':dest=next(d for a,b,d in vat if a<=num<=b)
        elif p.name=='fj-payroll-social.md':dest=next(d for a,b,d in pay if a<=num<=b)
        elif p.name=='README.md':dest='README taxonomy/link structure retained;2026 owner years plus explicit partial and missing statuses, no complete-coverage claim'
        else:dest=rootmap[(p.name,num)]['destination']
        if p.name=='fiji-vat.md' and num==271:status='MISSING_FJ_F01';dest='No final equivalent; writer generic destination is not preservation'
        if p.name=='fiji-vat.md' and 197<=num<=199:status='TOPIC_RETAINED_RULE_NEEDS_FJ_F02';dest='Final111 repeats issue-period direction without payments-basis exception'
        oldlines.append({'file':p.name,'original_line':num,'original_text':text,'final_destination':dest,'independent_disposition':status})
assert len(oldlines)==624
save('final-original-line-dispositions.json',{'head':HEAD,'original_nonblank_lines_in_changed_files':624,'body_lines_excluding_frontmatter':566,'all_originals_read':7,'unchanged_income_sibling_nonblank_lines':542,'unchanged_income_sibling_body_lines':516,'sibling_scope':'Read for compatibility, byte preservation proved; no fresh certification of all unchanged tax claims.','lines':oldlines})

figures=[]
for p in sorted((HERE/'candidate').glob('*.md')):
    if p.name in ['README.md','fj-income-tax.md']:continue
    for i,line in enumerate(p.read_text().split('## Sources')[0].split('\n'),1):
        if line.startswith('|') and re.search(r'\d',re.sub(r'https?://[^\s)]+','',line)):
            figures.append({'file':p.name,'line':i,'row':line,'assessment':'Checked wording/base/conditions/dates against actual source reads. Citation section numbers are included in this deliberately broad inventory; not a count of independent numeric facts.','candidate_sha256':sha(p)})
save('final-table-claim-inventory.json',{'head':HEAD,'table_rows_containing_digits_including_reference_numbers':len(figures),'rows':figures,'scope':'Whole final bodies and operative ledger reviewed separately, not only these table rows.'})

find=json.loads((HERE/'findings-in-progress.json').read_text());find.update(full_review_complete=True,verdict='CHANGES_REQUIRED',review_date='2026-11-16');save('FINAL-FINDINGS-5c56d521.json',find)
sources=json.loads((HERE/'source-read-records-in-progress.json').read_text())
for r in sources:r.pop('whole_pack_PASS',None)
save('FINAL-SOURCE-READS-5c56d521.json',{'head':HEAD,'actual_scoped_sources':len(sources),'reads':sources,'visual_reads':['LN55/56 PDFpages4–6 including all20ratecells and entire currentformula','FNPFAct13/2014 wholepage1','FNPFAct21/2026 wholepage1'],'limits':'Authenticated caches reused with70raw/text SHAchecks; independentwebVAT10/2025andITA14/2026 plushistoricalwageaddress. A successfuldownload or quotecheck is not a source read. NoCAPTCHAbypass orFirecrawl.'})

artifacts=['candidate-binding.json','FINAL-FINDINGS-5c56d521.json','FINAL-SOURCE-READS-5c56d521.json','final-ledger-assessments.json','final-original-line-dispositions.json','final-table-claim-inventory.json','independent-arithmetic.json','metadata-and-sibling-proof.json','independent-local-checks.json','source-cache-rehash.json','writer-raw-text-cache-rehash.json','quote-transcription-check.json','verify-independent.py','build-final-evidence.py','FINAL-REVIEW-5c56d521.md']
save('FINAL-MANIFEST-5c56d521.json',{'head':HEAD,'base':'2844c309238b4fdb63be0a3d0ad9ae99a8ea89c8','verdict':'CHANGES_REQUIRED','full_independent_review_complete':True,'blocking_findings':['FJ-F01','FJ-F02'],'artifacts':[{'file':n,'sha256':sha(HERE/n)} for n in artifacts],'Guide_mutations_by_reviewer':False,'push_publish_merge_release_by_reviewer':False})
progress=json.loads((HERE/'progress.json').read_text());progress.update(state='Full independent review completed with2actionablefindings; exacthead5c56d521 notPASS',PASS=False,verdict='CHANGES_REQUIRED',full_review_complete=True,source_scopes=35,ledger_groups=123,original_lines=624,independent_cases=16,last_progress_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());save('progress.json',progress)
print(json.dumps({'verdict':'CHANGES_REQUIRED','head':HEAD,'findings':2,'ledger_groups':123,'sources':len(sources),'old_lines':len(oldlines),'broad_table_rows':len(figures)},indent=2))
