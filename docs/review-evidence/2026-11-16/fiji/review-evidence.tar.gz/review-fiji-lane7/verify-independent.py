from pathlib import Path
from decimal import Decimal as D, ROUND_HALF_UP
import hashlib, importlib.util, json, re, subprocess, sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
EV = ROOT / 'evidence-fiji'
WT = ROOT / 'wt-fiji'
HEAD = '5c56d52149f457c628f9e8741d9c225911ae38f4'
BASE = '2844c309238b4fdb63be0a3d0ad9ae99a8ea89c8'
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(n, o): (HERE/n).write_text(json.dumps(o, indent=2, ensure_ascii=False, default=str)+'\n')
def cents(v): return v.quantize(D('.01'), rounding=ROUND_HALF_UP)

# Independent integration of marginal slices read from enacted LN55, rather
# than reusing candidate base-plus-excess expressions.
BOUNDS = [0,30000,50000,270000,300000,350000,400000,450000,500000,1000000]
RATES = ['0','.18','.20','.33','.34','.35','.36','.37','.38','.39']
def tax(amount, resident=True):
    amount = D(str(amount)); result = D(0)
    rates = RATES if resident else ['.20','.20','.20']+RATES[3:]
    for index, lower in enumerate(BOUNDS):
        upper = D(BOUNDS[index+1]) if index+1<len(BOUNDS) else amount
        result += max(min(amount,upper)-D(lower),D(0))*D(rates[index])
    return result

spec = importlib.util.spec_from_file_location('examples', WT/'scripts/check-examples.py')
checker = importlib.util.module_from_spec(spec); spec.loader.exec_module(checker)
oracle = [
 ('inclusive revenue boundary', {'consolidated_revenue':D(4000000)+D(1000000),'excess_over_small_limit':D(0)}),
 ('ordinary company balance', {'gross_tax':D(100000)/4,'balance':D(100000)/4-D(18000)}),
 ('listing-period rate comparison', {'within_seventh_tax_year':D(200000)*D('.15'),'more_than_seven_tax_years':D(200000)/4,'difference':D(20000)}),
 ('advance withholding', {'each_advance':(D(30000)-D(3000))/3,'total_advances':D(30000)-D(3000)}),
 ('overview routes', {'net_value':D(1125)*8/9,'vat':D(1125)/9}),
 ('inclusive standard domestic sale', {'vat':cents(D(1090)/9),'net_sales':D(1090)-cents(D(1090)/9)}),
 ('qualifying export', {'output_vat':D(0),'zero_rated_sales':D(5000)}),
 ('conditional foreign service', {'bank_cost':D(218),'output_vat':D(218)/8,'supported_input_vat':D(0),'total_cost':D(218)*9/8}),
 ('confirmed exempt account-operation fee', {'expense':D(25),'deductible_input':D(0)}),
 ('original 20000', {'annual_income_tax':tax(20000),'employee_recovery':D(20000)*D('.08'),'employer_own_cost':D(2000),'pay_after_tax_and_recovery':D(18400)}),
 ('primary January cumulative', {'C1':D(45000),'T_C1':tax(45000),'PAYE':tax(45000)/12,'employee_recovery':D(300),'employer_own_cost':D(375),'net_pay':D(3750)-tax(45000)/12-D(300),'employer_payroll_cost':D(4125)}),
 ('original annual 80000', {'income_tax':tax(80000)}),
 ('original annual 320000', {'income_tax':tax(320000)}),
 ('nonresident original annual 60000', {'income_tax':tax(60000,False)}),
 ('original hourly input', {'annual_gross':D(5)*40*52,'annual_income_tax':tax(10400),'january_employee_recovery':D(16),'january_employer_own_cost':D(20),'january_week_net':D(184)}),
 ('August statutory total only', {'total_contribution':cents(D(3750)*D('.16'))}),
]
results=[]
for p in sorted((HERE/'candidate').glob('*.md')):
    if p.name in ['README.md','fj-income-tax.md']: continue
    for raw in checker.BLOCK_RE.findall(p.read_text()):
        b=checker.parse_block(raw)
        matches=[(n,o) for n,o in oracle if n.lower() in b['name'].lower()]
        assert len(matches)==1,(b['name'], matches)
        n,o=matches[0]
        differences={k:{'candidate':v,'independent':o.get(k)} for k,v in b['expected'].items() if k not in o or abs(D(v)-o[k])>D('.001')}
        assert not differences,(b['name'],differences)
        results.append({'file':p.name,'case':b['name'],'source_based_independent_result':o,'matches_all_declared_outputs':True})
assert len(results)==len(oracle)==16
boundaries=[]
for resident in [True,False]:
    for b in BOUNDS[1:]:
        boundaries.append({'resident':resident,'income':b,'at':tax(b,resident),'one_cent_above':tax(D(b)+D('.01'),resident)})
save('independent-arithmetic.json',{'head':HEAD,'method':'Marginal-slice integration from LN55; actual basis and wage-month assumptions independently read. No post-August recovery split invented. All16 candidate cases, including every declared expected field, checked.','cases':results,'boundary_checks':boundaries})

# Rehash authenticated acquisition evidence; transport is not semantic proof.
acq=[]
for r in json.loads((HERE/'source-acquisition-inventory.json').read_text()):
    checks=[]
    for pathkey, hashkey in [('path','sha256'),('text_path','text_sha256')]:
        if r.get(pathkey) and r.get(hashkey):
            p=Path(r[pathkey]); checks.append({'path':str(p),'expected':r[hashkey],'actual':digest(p) if p.is_file() else None,'match':p.is_file() and digest(p)==r[hashkey]})
    acq.append({'id':r.get('id'),'url':r.get('url'),'status':r.get('status'),'hash_checks':checks})
save('source-cache-rehash.json',acq)
assert all(c['match'] for r in acq for c in r['hash_checks'])

binding=json.loads((HERE/'candidate-binding.json').read_text()); metadata=[]
for row in binding['files']:
    p=HERE/'candidate'/row['file']; assert digest(p)==row['sha256']
    blob=subprocess.check_output(['git','show',HEAD+':skills/fiji/'+p.name],cwd=WT)
    assert hashlib.sha256(blob).hexdigest()==row['sha256']
    old=HERE/'originals'/p.name
    def field(t,k):
        fm=t.split('---',2)[1] if t.startswith('---') else ''
        m=re.search(r'^'+re.escape(k)+r':.*(?:\n[ \t]+.*)*',fm,re.M)
        return m.group(0) if m else None
    errors=[]
    if p.name!='README.md':
        for key in ['name','jurisdiction','license','tier','author','authors','reviewed_by','verified_by','contributor','contributors','attribution']:
            if field(old.read_text(),key)!=field(p.read_text(),key): errors.append(key)
    if p.name=='fj-income-tax.md': assert p.read_bytes()==old.read_bytes()
    metadata.append({'file':p.name,'candidate_sha256':digest(p),'original_sha256':digest(old),'protected_errors':errors,'unchanged_sibling_byte_identical':p.read_bytes()==old.read_bytes() if p.name=='fj-income-tax.md' else None})
assert not any(x['protected_errors'] for x in metadata)
save('metadata-and-sibling-proof.json',{'head':HEAD,'files':metadata})

commands=[
 ['python3','scripts/validate-guides.py','--changed-only','--no-index-check','--base',BASE],
 ['python3','scripts/check-examples.py','--require']+['skills/fiji/'+r['file'] for r in metadata if r['file'] not in ['README.md','fj-income-tax.md']],
 ['python3','scripts/check-sync-integrity.py','--base',BASE,'--head',HEAD,'--mode','audit','--strict-metadata'],
 ['python3','scripts/check-calculator-quotes.py','--changed-only'],
 ['git','diff','--check',BASE+'..'+HEAD],
]
checks=[]
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=WT,text=True).strip()==HEAD
for cmd in commands:
    p=subprocess.run(cmd,cwd=WT,text=True,capture_output=True)
    checks.append({'command':cmd,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
save('independent-local-checks.json',{'head':HEAD,'checks':checks,'all_pass':all(c['exit_code']==0 for c in checks)})
print(json.dumps({'head':HEAD,'independent_cases':len(results),'boundary_checks':len(boundaries),'source_hash_checks':sum(len(x['hash_checks']) for x in acq),'metadata_errors':0,'local_checks':[(c['exit_code'],c['stdout'].strip()) for c in checks]},indent=2))
