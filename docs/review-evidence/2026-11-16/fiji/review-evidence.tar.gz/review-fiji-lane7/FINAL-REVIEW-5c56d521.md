# Fiji full independent pack review — changes required

Reviewed on 16 November 2026. **Full independent review completed; two findings remain open. This candidate does not pass.**

Exact head: `5c56d52149f457c628f9e8741d9c225911ae38f4`.
Comparison base: `2844c309238b4fdb63be0a3d0ad9ae99a8ea89c8`.
Reviewer: existing lane7 parent, independently from the Fiji writers, with no additional agents.

Scope: the five assigned Fiji Guides, their complete operative cited provisions and relevant conditions, and README coverage. All seven originals were read, including the unchanged income-tax sibling. Final candidate bytes are frozen under `candidate/` and bound in `candidate-binding.json`. No Guide was edited by this reviewer, and nothing was pushed, published, merged, released or deployed.

## Findings

### FJ-F02 — P2: qualify credit/debit-note timing for payments accounting

File: `skills/fiji/fiji-vat.md`, final line111, method6.

The method directs users to use the note's issue period without the payments-basis exception. This Guide expressly supports invoice accounting and authorised payments accounting. VAT section39(2)(c) and (3)(b) provide the ordinary issue-period adjustments, but section39(4)(b) attributes notes to payments made or received in the period for a registered person directed onto payments accounting. Section39(4)(c)–(e) retains distinct hire-purchase, financial-lease and non-independent-person exceptions.

A note issued in March but paid or received in April can therefore reach the wrong monthly return if this instruction is followed. Qualify the issue-period direction as invoice accounting, state the payments-basis rule and exceptions, and retain the taxpayer's actual accounting-basis direction. Source: [VAT Act, full section39](https://frcs.org.fj/files/2026/06/VALUE-ADDED-TAX-ACT-1991-Revised-to-1-August-2025.pdf), actual cached text2894–3043 read, including the complete operative subsection4. Ledger groupV33 is marked changes required.

### FJ-F01 — P2: restore the canonical maintenance link and correct its no-loss mapping

File: `skills/fiji/fiji-vat.md`, end of final file; original line271.

The original explicitly links readers to OpenAccountants for the maintained version. The candidate contains neither that canonical link nor an equivalent maintenance statement. The writer map assigns original271 generically to “Sources / remaining holds / change record” and labels it preserved, although that destination contains no equivalent. This line is not an obsolete tax rule that needed correction.

Restore the original maintenance link and point the old-line map to its actual destination. The review's independent original-line inventory marks it missing. Other disclaimer repetition can remain consolidated into the single notice; this finding concerns the lost maintenance route.

## Verification completed

- **123 ledger inventory groups assessed:** 46 formation/company/overview groups and77 VAT/payroll groups.119 primary quotation groups match their source text after transcription normalisation;4 groups are workflow/case inventories. These matches were not used as a substitute for reading operative clauses. V33 needs the correction above. Some ledger details, such as the numerical de-minimis and late-input limits, go beyond what the final Guide spells out; their source support is recorded without counting them as separate published instructions.
- **35 actual scoped official-source reads**, with source text hashes and exact read boundaries in `FINAL-SOURCE-READS-5c56d521.json`. Long Acts were read for complete relevant branches and neighbours, not represented as whole-Act reads. Authentic caches were reused;70 acquisition raw/text hashes and23 additional writer PDF/text hashes matched. Fresh official web reads included the2026 income-tax Act,2025 VAT Act and historical wage address. An unsuccessful direct FNPF web request was not counted as a fresh acquisition.
- **PDF images inspected:** LN55/56 pages4–6, both full resident/nonresident tables and the current cumulative PAYE formula; the complete2014 and2026 FNPF amendment pages. The temporary16% total does not itself amend employee recovery. The agency's8/8 split remains a properly labelled unresolved branch in the candidate.
- **16 worked cases independently recomputed**, comparing every declared expected output. An independent marginal-slice tax function also checked18 resident/nonresident boundary points. All passed. Original bank inputs and six payroll input cases remain; changed outcomes follow explicit assumptions, current law or documented holds. No unsupported full-year/post-August net-pay split was accepted.
- **624 original nonblank lines inventoried across the six changed paths**, including566 body lines excluding frontmatter. The unchanged income-tax sibling's542 nonblank lines/516 body lines remain byte-identical. The VAT maintenance-link omission and credit-note rule defect are recorded explicitly; a full no-loss PASS is not claimed.
- **Protected metadata passed:** names, jurisdiction, licence, tier and existing author/reviewer/contributor fields. No professional attestation was added. The unchanged income-tax sibling was read for compatibility and preservation; its entire body of tax claims was not freshly certified.
- **All local checks passed at the exact head:** changed-Guide validation with no index check (five Guides/six paths, zero warnings),16 example blocks, strict metadata sync, calculator quote preservation and whitespace. The reviewer reran these; logs are in `independent-local-checks.json`. No hosted CI, live TPOS, production database or live filing check is claimed.

The broad table inventory contains77 rows with digits, including citation section numbers and workflow rows. It is deliberately not a count of distinct numeric legal facts. The source/ledger review covers the full bodies beyond those tables.

## Preserved limits and coverage

README honestly retains partial status for current-law gaps and missing transfer-pricing/cross-border methods. The final methods keep foreign-investment detailed-regulation/fee gaps, charitable-amendment appointed commencement, incentives/treaties/insurance uncertainty, medicine/special concessions, imported-service deductions, coverage exemptions, wage instruments and electronic filing facts explicit. The unchanged income-tax sibling's later2026 budget reconciliation remains partial. None is treated as a verified filing result.

The earlier three-file preflight is supporting evidence only. This report binds the combined five-Guide candidate and README at the head above. After corrections, review the actual delta and rebind evidence/checks to the replacement head before recording any full-pack PASS.

Communication limit: automatic approval review rejected an attempted findings message to the coordinator chat because it found no explicit trusted user authorization to send it. The findings and complete review are available locally; no alternative message route was used.

Artifact index: `FINAL-MANIFEST-5c56d521.json` binds all review evidence and candidate hashes.
