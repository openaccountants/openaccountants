# Fiji VAT/payroll writer handoff

Exact final head: `484b347c6ed989f16e550f41cbbdb5eead83d2a4`. Base: `2844c309238b4fdb63be0a3d0ad9ae99a8ea89c8`.
Branch: `world/codex-fiji-payroll-vat-2026-11-16`.
Worktree: `/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-resume-2026-11-16/wt-fiji-payroll-vat`.

Take **both commits**, in order: `7046ad9ce71b615f09713a720e9073c41004e804` and `484b347c6ed989f16e550f41cbbdb5eead83d2a4`. Exactly two assigned source files changed: `skills/fiji/fiji-vat.md`, `skills/fiji/fj-payroll-social.md`. Root formation/CIT/overview and unchanged income-tax were not edited. No push, PR, merge, release, database or production operation. Clean worktree. Both commits Michael Cutajar with the required email and no AI trailer.

## Corrections and findings

- VAT9% becomes12.5%; original1090 inclusive sale now968.89net and121.11VAT rather than1000/90. All four original bank strings are exact.
- Azure original-218 no longer invents200net/18VAT or equal input/output. Under separately explicit foreign-service/consideration facts,218is the actual exclusive base, output27.25; input is not automatically offset. The raw line itself remains insufficient.
- Monthly default/quarterly CEO application uses300000test, not automatic500000split. Registration excludes a qualifying produce supplier and applies actual rolling/forward tests. Medicine/education/publicbus/insurance and bank/utility brand assumptions corrected with exact boundaries.
- Current hotel checkout tax point and separately invoiced tourism tax from their different2026 commencement dates; no obsolete STT/ECAL stacking.
- Current resident/nonresident tables reach39%, not20%cap plus historic SRT/ECAL. Annual320000resident chargeable income yields64300income tax; old stack was71800. Gross/chargeable/FNPF bases are not conflated.
- Actual cumulative Regulation6 P-code formula, history, other codes/certificates and conditional finality replace annual/F and unconditional no-return claims. PAYE payment is endfollowingmonth, not15th.
- FNPF total18% beforeAugust and16% during1Aug2026-31July2027, with different actual rounding.2012payment amendment resolves month-end;2024statement deadline and10%balance penalty confirmed.
- **Unresolved legal recovery conflict is outside usable guidance:** agency says8%employee/8%employer; the read s39 amendment retains8/18or44.4%ofmandated total and Act21changes onlytotal. No later reconciliation found. Do not treat the agency split as settled statute. All six raw payroll inputs remain, with current annual tax, explicit pre-August scenarios or a hold where full-year/net/base data are missing.
- Current wage/sector instrument, full membership amendment chain/specific Board decision, special benefit and penalty/reporting inputs and contribution incentive remain held. Government wage announcement is historical context only.

## Validation and sparse checkout note

- Both skill_checks empty, zero findings.
- Required changed-only validator:2Guides,zero warnings. An initial sparse checkout lacked the existing shared VAT dependency; the checkout was corrected to include exactly that unchanged source, and validation then passed. No dependency checker or shared file edit.
-11oa-check blocks across2files:0failures,0missing.
- Strict sync/metadata:2sources,0errors/warnings/notices.
- Stock direct-fetch figures:25numeric linked rows,0MISS,0UNREADABLE; all actual official pages readable by stock checker. Supplemental complete cached-primary check same25/0/0. Pure page_values memoization only in external supplement; no repository checker edits.
- The stock report was run at first commit; final delta only adds actual s6 citation/part-year boundary and narrows read-scope wording. Every linked table row before Worked cases and every oa-check block is byte-identical, asserted from both git blobs by `freeze_handoff.py`. `final-binding.json` rebinds that exact proof to final hashes.
- Calculator quote guard passes; no quoted line lost. Whitespace/protected-metadata/credit/no-em-dash guards pass.

## Independent-review inputs

- `ledgers/fiji-payroll-vat.md`:77rule/figure groups with actual officialURLs, article/section, short native quote, read date and scope.
- `figure-row-bindings.json`:all25numeric linked rows, each figure list, URLs and final file hash, including every annual-band row.
- `old-line-destination-map.md`:all519nonblank original lines mapped, including every raw input/refusal, with Removedandwhy/Moved/Notmoved record. File bytes grow substantially, but line consolidation exceeds25%, so this full cut/consolidation map is provided.
- `originals/` and `original-pack-hashes.json`:old source bytes and all-seven-pack baseline hashes. All seven old files were read before writing.
- `sources/`, acquisition manifests, `source-cache-map.json`, `source-hashes.json`, `referenced-source-text-hashes.json`:download versus actual read distinction, official raw PDFs/text, failures and byte bindings. Root source caches unchanged. Government page was read through official web tool; bounded read record says explicitly it is not a full downloaded page.
- `anchor-preflight.json`:statutory anchors match normalized actual complete cached source text; Government web-read and internal-original anchors are distinct transport cases, not falsely claimed as full PDF/page matches. Critical individual-table/formula and recovery-fraction pages rendered and visually read.

No independent review or accountant approval claimed by writer. Root assembles one country batch, obtains a fresh full-pack review and decides publication; the no-release hold remains. This handoff does not call Fiji fully covered.
