# Supplemental cached-primary figure check

No repository checker changes. The only transport substitution is the complete actual source text extracted from the downloaded official PDF/HTML with source hashes. The pure page_values(text) is memoized. This numeric check is not independent legal review. The stock direct-fetch report remains separate.
## skills/fiji/fiji-vat.md

7 rows, 0 misses, 0 unreadable.

## skills/fiji/fj-payroll-social.md

18 rows, 0 misses, 0 unreadable.

