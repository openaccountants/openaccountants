# Denmark reference router: source and rule ledger

Written 16 November 2026. This is source navigation, not an adopted tax-rate opinion. Actual official body excerpts and their complete page-navigation context were read through the ordinary web tool. The local captured response is `sources/official-index-read.txt`; its source identities and scopes are sealed with the handoff. No private repository was researched as legal authority. No failed URL is presented as read.

| Rule | Candidate scope | Actual authority / record | Short exact read anchor | Disposition |
|---|---|---|---|---|
| R01 | Method1: investments, share gains, departure, crypto source navigation | https://skat.dk/en-us/individuals/shares-and-securities | "Shares and securities"; "About calculating gains and losses on shares" | Official index body and adjacent navigation read. No linked substantive law or rate adopted. |
| R02 | Method2: distinguish preliminary and annual assessments and their year labels | https://skat.dk/en-us/individuals | "Preliminary income assessment"; "Tax assessment notice" | Actual headings, separate year-labelled links and neighboring personal-tax navigation read. No deadline or calculation adopted. |
| R03 | Method4: FX publisher's units, historical links, current feeds and limited purpose | https://www.nationalbanken.dk/en/what-we-do/stable-prices-monetary-policy-and-the-danish-economy/exchange-rates | "100 units of foreign currency"; "historical exchange rates"; "indicative rates"; "information purposes only" | Complete relevant publisher prose and neighbors read. No dated value or statutory tax-conversion method adopted. |
| R04 | Methods1-3: skill routes | Actual same-head dk-capital-gains, dk-income-tax, dk-payroll, dk-cross-border files and index | Exact file identities and stated task scopes inspected | Routing only; no independent legal reapproval of these unchanged siblings. All relative links resolve. |
| R05 | Scope, input checklist and final handoff | Scope-limiting workflow instructions for this source router | Not a statutory assertion | Inputs, jurisdiction/year selection, actual official source before calculation and unresolved-question handoff are explicit. |
| R06 | Refusal boundary and historical archive | Complete original references.md preserved in original.md and per-line destination map | Every old project bullet retains an individual destination | No calculator/FIFO/rate/licence assertion is operative. Nothing deleted to make a validator pass. |

## Source-access limits

An exploratory employee-share-schemes URL returned inaccessible in the web tool, and the Retsinformation home URL exposed only its JavaScript shell. Neither is used as a source or dated as read. They did not block this navigation-only index because none of its active claims requires either substantive law body. The selected substantive skill must obtain the applicable current law before a tax result. No rate, threshold, cost method, deadline or private-project licence was inferred from a shell, download success or unavailable source.

## Shape and preservation

`type: router`, `category: orchestrator`, `tax_year: 2026`. No operative rates/deadlines/worked cases, and no guard headings. The archived figures remain explicitly non-operative original research claims. Therefore router minimum zero examples is applicable; no invented oa-check or calculation is added. Version1.0 becomes1.1 and actual update date becomes16November2026. Existing name/jurisdiction/tier remain; no reviewed_by, human credit, platform marker, original case or calculator quote exists in this file to edit. Existing general-reference disclaimer is unchanged.

Removed and why: no substantive topic or original project statement removed. The old project-only title becomes a router title, three project headings nest below the historical archive, and the unprotected skattefar prose em dash becomes a colon. The old title's em dash is also replaced by the new title. Every original nonblank body line has an exact final destination. No person or approval field is added or removed.
