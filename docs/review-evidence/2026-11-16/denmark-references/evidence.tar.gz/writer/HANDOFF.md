# Denmark references: one-file writer handoff

**Finished local candidate, independent scoped review required before publication.** No push, PR, merge or release performed.

- Worktree: `/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-resume-2026-11-16/wt-denmark-references`
- Branch: `world/codex-denmark-references-2026-11-16`
- Exact clean commit: `1c659e9d14b506faf24d432545b9b7705f6d2cbd`
- Actual main/merge-base: `bbab4f1a6d82cace432e6ca8eda89c98ffb1c038`
- Sole changed file: `skills/denmark/references.md`
- Candidate SHA256: `f29720d154303cc04e436eab6f3597c6b56af7f1e59bfca4ff3a895e44e6b0f0`
- Author: Michael Cutajar, using the required GitHub noreply identity. No AI trailer.

## What changed and why

The old file called itself primary-source references but contained only three private project descriptions. Its historical rates, threshold, married-couple treatment, FIFO and broad licensing/integration assertions had no official source support in that file. The candidate adds an actual official-source navigation method and explicitly separates every old project statement as unverified, non-operative research context. It does not declare those tax figures wrong or newly verified, infer a 2026 replacement, recommend FIFO, or grant reuse rights.

The router chooses among the existing investment, income-tax, payroll and cross-border skills by actual taxpayer, transaction and period facts. All four relative routes exist and their task identities were inspected. Their unchanged substantive laws were not re-reviewed. Three official bodies were actually read: Skattestyrelsen's shares/securities index, its year-labelled individuals index and Danmarks Nationalbank's exchange-rate publisher page. Read scope is limited to the navigation, units, history/feed links and publisher qualification actually used. No linked law, dated FX value, private software or source-shell result is represented as legal proof.

`source-and-rule-ledger.md` covers all six new workflow/source groups, with exact short read anchors and source-access limits. `sources/official-index-read.txt` preserves the actual ordinary-tool read response locally. An exploratory employee-share URL was inaccessible and Retsinformation home exposed only a JavaScript shell; neither is used as evidence. Their failure does not establish any missing tax rule.

## Preservation and honest limits

All 25 original nonblank body lines have individual final destinations in `old-line-destinations.json`, including all three project identities and every licence, star count, language, historical tax-rate/method and integration assertion. Every archived claim is non-operative under the archive introduction and final `Not yet confirmed:` line. The original general-reference disclaimer is byte-identical. No substantive topic was deleted and no original case exists to remove.

Removed and why: the old project-only title becomes an explicit router/version title; project headings nest below the archive; the unprotected skattefar prose em dash becomes a colon. No original claim or person's name was removed. No protected credit, platform CTA or accountant approval existed in this file. Existing `name`, `jurisdiction` and `tier` are unchanged; no approval is added. The version advances once, 1.0 to 1.1, with actual 16 November date. All other tracked paths are unchanged.

This is honestly `type: router`, `category: orchestrator`, `tax_year: 2026`. It has no operative rate, deadline or worked case, and none of the guard headings. Zero `oa-check` cases is the standard's applicable router minimum; no fictitious calculation was added. Archived historical figures remain individually identifiable and unusable. The source/permission holds are real remaining limitations, not claims of comprehensive Denmark coverage or accountant approval.

## Targeted checks

All terminal checks apply to this exact committed one-file candidate:

| Check | Actual result |
|---|---|
| Target complete skill standard | `{}` |
| Ordinary changed-only validator, correct main base | One guide, zero warning groups, exit 0 |
| Examples `--require` | One file, zero blocks, zero failures, zero missing |
| Strict sync, actual main merge-base to HEAD | One guide, zero errors/warnings/notices |
| Calculator quotations | Pass; every referenced quoted line preserved |
| Stock row-source checker | Zero eligible rows, zero MISS/UNREADABLE; no network or complete-source-proof claim |
| Committed whitespace check | Pass |

Two initial validation attempts exposed only the sparse checkout's absent unchanged dependency graph. Those failed logs are preserved honestly. Materializing the unchanged skills tree resolves them; `validate-complete-dependency-tree.txt` is the authoritative passing target validation. No candidate edit or dependency rewrite was made to bypass an error. No full repository test suite, giant law scan or duplicate network figure run was performed.

## Independent review scope

Check the small router's actual three source scopes, four relative routes and scope/refusal boundaries; verify all 25 old-line destinations and metadata/credit protection. Distinguish preserved historical claims from the operative navigation. The source pages are indexes/publisher prose, so no full-country statute review or arithmetic population is being claimed. Existing complete research may be reused where genuinely applicable; root owns final scoped independent acceptance and publication.

The final manifest seals this complete new handoff packet. Full primary response text is local-only. The own ledger, preservation dispositions, candidate hashes and check results can be shared without publishing the raw source capture. No prior immutable review or other chat's country file was changed.
