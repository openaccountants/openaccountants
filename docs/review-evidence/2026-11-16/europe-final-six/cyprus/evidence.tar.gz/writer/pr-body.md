The Cyprus planning workflow now uses the current accounts thresholds and the full conditions for residence, domicile, employment and other named incentives. It preserves all original topics and adds two conditional decisions, while keeping unverified procedures outside usable guidance.

## Corrected

| Old | New | Authority |
|---|---|---|
| Natural-person accounts threshold EUR 70,000 | EUR 120,000 specified turnover/gross-income exemption; separate review route with EUR 200,000, EUR 500,000 asset and two-year conditions | Assessment Law art. 30; 243(I)/2025 |
| Incomplete 60-day residence and domicile exceptions | Actual physical-stay, tax-resident office, termination/home and statutory non-residence conditions | Income Tax Law art. 2; SDC Law art. 2(3) |
| Payment described as renewing non-dom exemption | Alternative fixed SDC imposition, prepayment, irrevocability and no-credit/refund conditions | SDC Law art. 3D |
| Employment, share-plan and private-asset conditions too broad | Current employment/history/pay gates and the specific approval, asset-use and share-plan conditions | Income Tax Law arts. 8, 20D; SDC Law art. 3A |
| R&D allowance lacked operative gates | International accounting standards recognition of R&D, business economic ownership of resulting intangibles, and separate capital-cost exclusions | Income Tax Law art. 9(1)(δ), art. 10 |
| IP percentage unconfirmed; old GHS guide used | Statutory 80% supported while actual assets/nexus remain held; current GHS statute used | Income Tax Law art. 9(1)(κ); GHS Law art. 19 |

The 63-row ledger contains actual primary paragraphs, native quotations, operative pinpoints and dates. No earlier independent Cyprus approval was recovered. A separate reviewer checks the entire bounded workflow, original topics and both calculations.

Source provenance is explicit: the amendment PDFs reproduce the official Gazette; the nonprofit CyLaw consolidation is a maintained reading aid, not a government-hosted official consolidation. EU N-Lex and Publications Office provenance pages were actually opened. No equality with blocked government PDF bytes is asserted. Failed WAF responses are not source evidence.

Content checks pass, both controls recompute and 30 cached source rows have no misses. Committed validation and strict sync must pass before publication; mandatory CI runs at the final head. One compact indexed evidence archive is under `docs/review-evidence/2026-11-16/europe-final-six/cyprus/`. Raw captures stay local.

T.D.38 procedure, TD631/TFA advance applications and attachments, exact overseas GHS scope/documents/exclusivity and IP qualifying-assets/nexus regulations remain explicit non-usable holds. Tier 2 remains; this work supplies no accountant approval or country-completion claim.

## Removed and why

Unsupported general employment-termination and old-profit transition rules are replaced by their actual legal conditions, with history and referral topics retained. Duplicate source-only rows become row-local citations. Invalid domain metadata and unsupported description promises are corrected. No substantive topic, human credit or original case input is silently removed; the original had no cases and the candidate grew.

## Moved

Every original nonblank line is mapped into the same file's canonical scope, inputs, method, cases, referral and sources. The no-loss map preserves original handoffs, red lines and held procedures. No file merge or deletion.

## Not moved

No sibling Cyprus Guide, generated output, approval, script, database or live service is changed. Unverified implementation questions remain non-usable under Sources.

Written by Codex (world wave). Not reviewed by an accountant.
