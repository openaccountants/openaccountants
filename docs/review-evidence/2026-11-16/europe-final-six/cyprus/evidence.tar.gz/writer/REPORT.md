# Cyprus tax optimisation writer handoff

Only `skills/cyprus/cyprus-tax-optimization.md` was edited. Version 0.1 becomes 0.2, dated 16 November 2026, with decision shape, canonical headings, linked rate rows, two recomputing decisions and explicit non-usable holds. Tier and licence are retained. No accountant names, approvals or protected CTAs existed in the original. No git mutation or publication was performed by this writer.

## Corrected

| Former draft | Candidate | Operative authority |
| --- | --- | --- |
| Self-employed audited accounts above EUR 70,000 | Current natural-person accounts exemption up to EUR 120,000 specified turnover/gross income; review route up to EUR 200,000 with EUR 500,000 asset test and required two-year history | Assessment Law art. 30; 243(I)/2025 commencement |
| Other-country residence wording; office anywhere in Cyprus; missing office termination event | Physical stay test, office in Cyprus tax-resident person, complete termination/home conditions | Income Tax Law art. 2 |
| First domicile exception required the period immediately before current year; pre-2015 exception described as residence abroad | Correct any qualifying twenty-year non-residence period for the first exception; statutory immediate-precommencement tax non-residence for the second | SDC Law art. 2(3) |
| Payment renews non-dom exemption | Alternative fixed SDC imposition after deemed domicile: EUR 50,000/year, prepaid EUR 250,000, irrevocable period; no credits/refunds and late-payment consequences | SDC Law art. 3D |
| General eight-profit-year limit on old individual dividends | Actual six-year receipt transition on pre-2026 profits; old profit/deemed-distribution history retained as a referral | SDC Law art. 3(1)(a)(ii) |
| Broad private-asset market-value charge | Private-use proportion, changes, donor and employment/capital exceptions and prior-benefit adjustment included | SDC Law art. 3A |
| Ten-year main employment test, inclusive minimum pay, automatic end-of-first-job cliff | Current fifteen-year main rule; strict threshold, annual/start-year and protected historic conditions; no unsupported automatic cliff | Income Tax Law art. 8(23A), (21A) |
| IP percentage said unavailable | Statutory 80% of qualifying profit now supported; actual assets/nexus regulations remain a non-usable hold | Income Tax Law art. 9(1)(κ) |
| Missing share-plan gates | Approval, vesting, transfer, share rights, exercise-price floor, caps and expired transition included | Income Tax Law art. 20D |
| GHS 4% supported only by 2025 return guide | Current GHS statute used; personal aggregate cap and payer distinction included | GHS Law art. 19 |

## Moved

Every original nonblank line is mapped in NO-LOSS.md/no-loss.json, including the six original input questions, original handoffs, old-profit referrals, red lines and procedures that now require holds. The original had no worked cases or client case inputs. Two illustrative cases were added without simplifying any existing case.

## Not moved

No sibling Cyprus Guides, indices, generated copies, scripts, approvals or shared tests were changed. Parent owns required committed validator/sync gates and shared calculator/copy tests. The current lane HEAD may advance while other assigned writers/parent commit; the Guide SHA256 in guide-manifest.json binds this exact candidate independently of that.

## Evidence and checks

- LEDGER.md / ledger.json: 63 grouped rule/figure rows, article, URL, native quote, actual read date and local pinpoint.
- operative-excerpts.json: adjacent operative excerpts and source provenance for the separate reviewer. Full raw sources stay in local cache and are not for public evidence packaging.
- NO-LOSS.md / no-loss.json: all 178 original nonblank lines mapped; frozen original preserved.
- skill-checks.json: `{}` using the existing Python environment.
- examples.txt: 1 file, 2 blocks, zero failures or missing examples.
- row-sources.json: 30 figure-bearing rows, zero misses and zero unreadable rows, using the committed checker and once-fetched substantive cache instead of redundant network scans.
- `git diff --check -- skills/cyprus/cyprus-tax-optimization.md` passed.

No prior Cyprus independent approval was recovered from the searched research/cache/read-only clone paths. This is a writer handoff, not an independent review or accountant approval. The separate reviewer should check the ledger and preservation map and recompute both cases. Raw failed government captures are not legal evidence.

## Genuine holds

Current T.D.38 procedure; TD631/TFA, advance application and attachments; exact overseas-GHS exemption scope/documents/exclusivity; operative IP qualifying-assets/nexus regulations. They remain expressly non-usable in Sources. The accessible statutes support the legal rules above, but do not establish the held administrative steps. Access failures and encoding correction are in INITIAL-FAILURES.md and applicability-retrieval.json.

## Removed and why

Redundant source-only rows became citations on each relevant row. Invalid domain metadata and unsupported description promises were corrected. Unsupported job-termination and eight-profit-year general rules were replaced by law, with their history/referral topics preserved. The candidate is longer than the original. No substantive original topic or case input was silently discarded.

## Provenance distinction

See PROVENANCE.md: CyLaw maintained consolidations are not government-hosted or themselves an official Gazette. Laws 244/245 PDFs reproduce the official Gazette, but were not byte-compared with a government-hosted file. EU N-Lex actually opened here refers readers directly to CyLaw; the EU Publications Office Gazette page explains the legal Gazette/consolidation distinction. This establishes the referral and document provenance, not a claim that all CyLaw content is an official consolidation.

## Focused independent-review correction

Added the operative article9(1)(δ) business/economic-ownership conditions and exclusion for article10 machinery, plant and building costs, including staff accommodation, beside the20% rule and its interaction paragraph. Corrected CY38: the original quote search selected an unrelated asset provision atline805; article13(1) begins at922 and the seven-year proviso is at923. The legal seven-year conclusion is unchanged; ledger quote and local operative excerpt now point to the actual loss provision. No new source fetch, cases, inputs or unrelated rules changed.

Final focused correction: R&D recognition under international accounting standards added from article 9(1)(δ), already substantively read at cache/income.txt:447. Final Guide SHA-256: d5aac6be13ca26518d6fc84ee0d2467bee116241a042b63752bba16e7c70eb91. No numerical inputs or controls changed.
