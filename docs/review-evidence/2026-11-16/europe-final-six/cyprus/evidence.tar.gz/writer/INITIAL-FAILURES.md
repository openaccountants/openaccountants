# Access and initial checks

Recovered government PDF captures contained Azure WAF error/challenge text, not the requested documents. Live direct curl attempts failed (see applicability-retrieval.json); web opening returned 403. None were treated as completed source reads. A real-browser fallback failed: IAB was unavailable; the enabled Brave browser tab call returned `Cannot read properties of undefined (reading 'timeoutMs')`. No challenge bypass was attempted.

Current Cyprus-law HTML declares Windows-1253. The initial helper decoded it as UTF-8, producing corrupt Greek text. This was corrected from the original raw bytes with the declared charset before the operative paragraphs were read. The current normalized cache and ledger quotes are Greek, with exact source/line provenance. The old helper retrieval status does not imply a substantive read.

Initial lightweight system-Python checks used fallback frontmatter parsing and reported missing type. The description's colon was changed to a valid YAML folded scalar, and checks were rerun in the existing `/private/tmp/ng-check-env` environment. Final skill_checks are `{}`. Initial check output was shown in the tool record; no prior full-output artifact was created. No passing initial result is claimed.

A current-law consolidation's commencement notes contain apparent law-number typographical errors (224 instead of 244; 145 instead of 245). Actual authentic Laws 244(I)/2025 and 245(I)/2025 were read for their titles, affected provisions and commencement, resolving those references rather than guessing.
