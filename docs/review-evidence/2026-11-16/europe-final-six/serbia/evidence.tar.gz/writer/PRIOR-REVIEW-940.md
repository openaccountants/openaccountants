Independent review: 27 ledger rows checked (26 figures/rules confirmed against the mfin.gov.rs copies of ZPDG to 80/2026, ZPDPL, ZDOSO and the Minister's 2026 base notices; 80/2026 changes only Arts. 15a, 21v-21d and 33a and applies from 2027, so no cited article moves). check-examples: 0 blocks (none required for a tax-optimisation skill); validate-guides: passed.

Fixed:
- 10% yearly cap on flat-rate base growth now sourced and restored: Government flat-rate decree Art. 6(1) to (3), Tax Administration consolidated text to Sl. glasnik 115/2025, in force 27 Dec 2025 (purs.gov.rs, uredbe/6095). Cap applies to rises caused by the new method, up to and including 2027; not to rises from a change of activity code, municipality or place of registration; a move within the same city is not a change of municipality. Added to Sources.
- Applying (ZPDG Art. 42(1)): added the 15-day window after removal from the VAT register, no later than 31 December.
- Freelancer amounts RSD 110,647 / 66,733 marked as the 2026 indexed amounts (Art. 12a; Sl. glasnik 6/2026).
- Banner: "source-cited draft" replaced with "checked against the law".

Confirmed: 10% self-employment tax (Art. 38), 15% CIT (ZPDPL 39), 5-year loss carry-forward (ZPDPL 32), 15% dividends (Art. 64) withheld (Art. 99(1)(3)), contributions 24% / 10.3% / 0.75% (ZDOSO 44), 2026 bases RSD 51,297 / 732,820, ZDOSO 22 and 36, flat-rate limit RSD 6,000,000 and exclusions (Art. 40), deemed-income method (Art. 41), 31 October deadline and loss of status (Art. 42), books (Art. 43), Art. 37a, independence test 5 of 9 with 70% and 130 days (Art. 85(1)(17)), full gross base (85(5)(1)), 20% / 10% rates (Art. 86), withholding (99(1)(9)).

Sibling disagreements: none. serbia-income-tax, serbia-social-contributions, rs-corporate-tax and serbia-payroll carry the same figures. can-a-foreigner-start-a-business-in-serbia and how-to-open-a-company-in-serbia-as-a-foreigner-... still say tax_year 2025 (no conflicting figures).

Lost content restored: 1 (the 10% base-growth cap to end-2027 with its activity-code/municipality exception). The old "substance" anti-avoidance word had no rule behind it.

Still not confirmed: typical monthly flat-rate amounts (old EUR 250 to 400); EUR equivalents of RSD 6,000,000; old "contributions on 60% of a self-set salary" (contradicts ZDOSO Art. 22); how flat-rate and foreign freelance income enter the annual personal income tax.

Ready to merge as Checked against the law.