The two assigned Serbia workflows now have canonical steps, required inputs, official row citations and executable comparisons. Their reviewed legal content is preserved. The approved `can-a-foreigner-start-a-business-in-serbia.md` sibling, including Andrija Eminovic's approval, is unchanged.

## Corrected

| Old | New | Source |
|---|---|---|
| No declared workflow shape or early required facts | Formation filing workflow and tax-method decision with their actual boundaries | Current template; existing official authorities in each ledger |
| Formation fees lacked a recomputing comparison | RSD 8,000 versus RSD 2,500 gives RSD 5,500, expressly using the reviewed archived fees | APR archived fee pages; completed review #950 |
| Tax-method summary lacked a worked decision | Separately established hypothetical deemed and real taxable bases compared at 10%; contributions and total-cost advice remain separate | ZPDG arts. 37a, 38, 40; completed review #940 |

The complete original reviews are preserved byte-exact. Their legal bodies match current main, so unchanged substantive review is reused after an applicability check. Fresh independent delta review covers the new examples, scope, citations and preservation. No new tax rate or threshold is introduced.

Committed-content validation and strict sync must pass before publication. Content checks pass and all three controls recompute. Selected cached source-row checks have no misses; unavailable archived APR/decree captures are covered by the original completed review with their actual provenance and dates, rather than claimed as fresh reads. Mandatory CI runs at the final head. One compact indexed evidence archive is under `docs/review-evidence/2026-11-16/europe-final-six/serbia/`.

Existing UBO, provider, fee-route, personal-salary, EUR-estimate, typical assessment, salary-percentage and annual-income-tax gaps remain explicit non-usable holds. Neither comparison supplies a complete registration filing or owner-cost recommendation. Tier 2 remains; no professional approval is added.

## Removed and why

Only duplicate structure. No original substantive topic, case input, human credit, approval or contributed file is removed.

## Moved

Existing topics move within the same files into canonical scope, inputs, method, cases, referral and source sections. The complete archived block inventory gives each destination and authority. No file merge or deletion.

## Not moved

All prior refusals and unconfirmed topics remain explicit. No approved sibling, generated output, database or website file is changed.

Written by Codex (world wave). Not reviewed by an accountant.
