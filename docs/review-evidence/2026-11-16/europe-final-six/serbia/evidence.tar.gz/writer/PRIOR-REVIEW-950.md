Independent review: 29 figures and rules checked (ledger rows 1 to 19 plus 10 reviewer rows R1 to R10). Commit 0358df1e.

Fixed:
1. Attribution: the figures changed, so under Michael's rule of 23 Oct the named outside author is removed. authored_by: Andrija Eminovic and trust_label: Accountant-authored are replaced by the team byline "Built by Michael Cutajar and the OpenAccountants team". The "Contributed by" line is replaced by the same byline. A tier 2 "checked against the law" banner is added, plus category: formation. The author's first-person practice lines ("we require", "in our practice") are made neutral, so they no longer read as ours.
2. DOO electronic-only filing is now sourced: from 17 May 2023, under the APR registration procedure law, Art. 9(2), as APR's founding instructions state. Removed from Not yet confirmed.
3. Entrepreneur filing: in person at APR, by post, or electronically since 1 Jan 2018. The one-stop system gives a PIB and takes the application for paušal, personal salary or VAT in the same filing.
4. APR fees added: RSD 8,000 to register a company's founding, including its documents, and RSD 2,500 for an entrepreneur. apr.gov.rs blocks both curl and Chrome from our network, so these come from APR's own pages as captured by the Internet Archive on 17 Jan and 17 Feb 2026 (rule 3).
5. Beneficial owner: since 1 Oct 2023 it can be recorded in the same electronic founding filing (APR).
6. From APR's founding instructions: the bank's confirmation is needed when capital is paid before founding; a certified translation by a permanent court interpreter; an Apostille or legalisation; a founding act signed with e-certificates or digitised.
7. Removed the unconfirmed named certificate provider (Chamber of Commerce). APR requires a qualified certificate issued in Serbia.
8. "guide" replaced by "skill" in the intro.

Confirmed: every ledger quote. The Company Law is unchanged since 19/2025, and Arts. 11, 46, 85, 89, 139, 141 and 145 were read on PIS. The ZPDG, ZPDPL, ZDOSO and ZPDV quotes are in the Ministry of Finance copies and in force for 2026. The figures match serbia-tax-optimization, serbia-income-tax, serbia-social-contributions, serbia-vat and rs-corporate-tax on main.

Contradictions with siblings: none. Examples: none (formation skill); check-examples 0 blocks; validate-guides passed.

Still not confirmed:
- The deadline for recording the beneficial owner outside the founding filing. APR's page still cites the 2018 UBO law and its 15 days, but that law was replaced in 2025 and the new law was not read.
- The text of the APR registration procedure law itself; Art. 9(2) is cited through APR's own page.
- Whether the entrepreneur fee differs between paper and electronic filing.
- Certificate providers' conditions for foreigners.
- The conditions for lična zarada.

Lost content restored: 0. Nothing was dropped against main.

Ready to merge as Checked against the law. The CTA block (platform-owned) still says "verified accountant" and was left untouched.
