# Serbia focused read record, 16 November 2026

The exact original reviewed legal bodies were recovered from Git and compared with current main once. They match after excluding retired metadata/platform footer content. Complete independent review comments #940 and #950 are reused for unchanged rules. The approved sibling was read only for its protection metadata and hash; it was not edited.

New source work was limited to the factors used in the new controls and direct-source annotations. The official DOCX files were recovered read-only from the 14 November source cache, their hashes recorded, and actual document XML text extracted. A `.ok` filename marker was not treated as proof. Selected operative passages were actually read: ZPDG37a/38/40, ZPDPL39, ZDOSO44, both complete short2026minimum/maximum-base notices, and VAT38 with neighboring text and application notes. Other unchanged provisions retain the complete prior review and original dates.

The new planning examples take an already established actual taxable base after deductions as an input. This avoids treating contribution expense as simultaneously ignored and deducted, or inventing a full contribution calculation. Eligibility and independence are explicit assumptions; the cases compare only the income-tax component.

No fresh archived-APR or decree transport read was claimed. Those unchanged sources retain their prior completed review and capture/read dates. Exact native excerpts appear only where actually available; missing recovered excerpts are explicit in the ledgers. No paid API, private source, challenge bypass, live form submission or production write was used.
