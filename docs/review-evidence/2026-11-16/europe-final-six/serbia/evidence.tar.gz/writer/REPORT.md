# Serbia writer handoff

The two assigned unsigned tier-2 Guides are complete at version 0.3 for 2026. Only the assigned registration and tax-planning files were edited. No branch, staging, commit, push or publication was performed.

The complete original reviews are preserved byte-exact in `PRIOR-REVIEW-940.md` and `PRIOR-REVIEW-950.md`, with their API records. They checked 27 planning ledger rows and 29 registration figures/rules. `REUSE-APPLICABILITY.json` proves that both reviewed legal bodies match current main. Original read dates and archived APR capture dates are preserved. This work does not repeat or claim a new complete legal audit.

No tax rate or threshold was changed. The edits add declared shapes, canonical method headings, required inputs, direct official URLs on the relevant rows, explicit computed-total labelling, a bold audit marker and conditional examples. Existing source and practical paragraphs, refusals, Michael/team credit lines and held topics remain intact. `NO-LOSS-MAP.md` inventories every old block; `PARAGRAPH-INVENTORY.json` supplies all original block text and hashes.

The registration example compares the reviewed archived APR fees of RSD 8,000 and RSD 2,500, giving a RSD 5,500 difference. It keeps subscribed capital separate from fees. The planning cases compare the income-tax component on assumed deemed income of RSD 60,000 for 12 months against separately established actual taxable profit of RSD 2,400,000 or RSD 300,000. At 10%, the results are RSD 72,000 against RSD 240,000 or RSD 30,000. These cases do not invent a tax-assessment decision, contribution computation, annual-income-tax treatment or total-cost recommendation.

Focused source reads used recovered official Ministry DOCX files: ZPDG articles 37a, 38 and 40; ZPDPL article 39; ZDOSO article 44; both short 2026 monthly-base notices; and VAT article 38 for its row citation. The original review expressly considered the 80/2026 commencement and applicability for unchanged provisions. Current Ministry landing pages were opened as source-navigation checks, not treated as proof of the operative paragraphs. Raw snapshots and extracted law text remain local under `cache/`.

Both `skill_checks` results are `{}`. All three calculation blocks pass, and `git diff --check` passes. The unchanged row checker against selected recovered official text checked six registration rows and twelve planning rows with zero misses. Two archived APR fee pages and the decree text were outside that selected cache; the preserved completed reviews cover their unchanged amounts/rules. The row check was not a fresh online transport audit. Parent handles committed-head validator/sync checks and shared calculator/copy tests once.

The approved `can-a-foreigner-start-a-business-in-serbia.md` sibling, including Andrija Eminovic's approval and all protected content, is byte-identical. `PROTECTED-SIBLING.json` and `CHECKPOINT.json` record the proof.

Separate independent delta review remains required for the new examples, declared shapes and source annotations. Existing UBO, provider, fee-distinction, personal-salary, EUR-estimate, 60%-salary and annual-income-tax gaps remain explicit non-usable holds. Exact baseline/candidate hashes, checks and holds are in `CHECKPOINT.json` and `STATUS.json`. No accountant approval is claimed.
