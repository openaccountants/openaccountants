# EU IOSS independent primary-source review, 16 November 2026

Fresh reviewer `/root/review_sm` accepts only `skills/eu/eu-ioss-gb-sellers.md` v0.1 within its stated scope, after one P2 timing dependency was corrected and closed. Exact final SHA256: `cfd32b3990b3e3285ba996da59792de0bcb6421b66f3c89cb493f89b284c9632`. Initial reviewed hash: `fa97455b1c401b7bdc7d9ed3a619a3b382f2147d0fa001c140a71210f2e71d2c`.

No earlier substantive source review was recovered or reused. All 38 legal rows received a new independent primary-source read in context. `ROW-OUTCOMES.json` records every row, official URL/pinpoint, actual read scope, exact input identity, quote comparison and outcome. All 38 short published quote candidates match actual retained official text after whitespace normalization. This is source review, not a successful-download inference or parser result. No Guide edits, Git mutation, publication, merge, customs filing, checkout change or accountant approval by this reviewer.

## Actual primary reads and current-law reconciliation

I read the Commission scheme background, imported-distance-sale/deemed-supplier/intermediary/consumption definitions; registration and identification-state/identifier/allocation FAQs; monthly return, nil conditions, country/rate contents, negative-country balance, exempt/zero-rate, input-tax, currency, correction, payment and deadline FAQs; and records/retention/electronic-availability rules with their neighboring qualifications. These support the stated IOSS workpaper without inventing national portal fields or a universal product rate.

I read operative Regulation 2026/382 articles 1-4 and relevant recitals: threshold relief is removed from 1 July 2026, with the temporary EUR 3 per defined item for inclusive EUR 150 consignments satisfying the IOSS import-exemption limb or the separate postal limb, until 1 July 2028. Review/proposal clauses do not themselves extend that period. Commission customs guidance sections 2, 4, 5.1, 5.2, 5.4, 6.4 and relevant 8 passages were read for intrinsic value, consignment versus item, declaration-line grouping, foreign-stock/bonded-warehouse distinctions, preferential limitations, representative hierarchy and PID handoff. The actual document says 5 October 2026.

I read Regulation 2026/2108 definitions 5(15), (44), (78), article 20 and its neighboring exceptions, article 85(2) and article 287's staged commencement. The fee is distinct from duty, applies to distance-sale releases without an EUR 150 limit, has the customs debtor or would-be debtor and is non-refundable. The lower customs-warehouse limb is later and is not applied early.

Published Regulation 2026/2152, OJ 22 October, articles 1-2 fixes EUR 2 per item and expressly applies from 1 November 2026. Its final published commencement supersedes the October explanatory PDFs' expected-date wording and the earlier adopted draft's blank publication date. I read its operative text and neighboring recitals. Regulation 2026/1022 article 2 and Annex 2(a)-(c) separately establish July declarant data and November mandatory PID data; voluntary earlier PID provision is not made a mandatory early obligation.

The actual VAT addendum is revised 6 October, despite its August filename. Its IOSS paragraphs on duty and handling fee, and neighboring non-IOSS branches, were read. Valid IOSS import exemption avoids import VAT on those charges; charges passed to the buyer at sale enter the earlier supply's consideration. A later customs debt alone does not automatically enter that earlier base. Duty and handling-fee refunds/obligations are kept distinct from VAT corrections.

## Finding and exact focused closure

P2-1, EU-026: method 8 initially stated the declaration hierarchy only from 20 September 2026. That is the correct commencement of new UCC article 85(2) under article 287(3)(e), but the covered EUR 150 Annex B hierarchy already applies from 1 July under Regulation 2026/1022 article 2(2), Annex 2(c). Only Annex 2(a)-(b) PID data are deferred to November. The Commission guidance's July language therefore reflects a separate earlier operative dependency, rather than contradicting the September statutory date.

The parent corrected only that dependency in method 8, source scope and ledger row 26. I compared the resulting paragraph and annotation with those actual provisions. The final text now distinguishes the July Annex B rule, September UCC rule and November PID obligation, without deferring the July requirement. P2-1 is closed at the final hash above. No repeated full scan or unchanged-case rerun was needed for this focused closure.

## Figures, cases and preservation

The source-row CLI reports **zero rows** because its recognizer misses plain euro integers. I manually verified all three figure rows, EUR 150, EUR 3 and EUR 2, with their scope, period and item conditions; `MANUAL-FIGURE-ROWS.json` states the actual coverage. Zero parser rows is not represented as three parser passes.

Both executable cases independently recompute using separate Decimal formulas, without evaluating Guide steps or importing the repository checker. The preserved duty-only inputs 100, 20%, 3 produce 103 and 20.60; without passing duty at sale, 100 and 20 remain. The July-October or isolated-duty qualification preserves their purpose without presenting a current full landed cost. The November case uses one confirmed item and both charges at sale: 3 duty plus 2 fee gives 105 consideration, 21 VAT and 126 total; without checkout charges, the assumed supply VAT remains 20. The 20% is hypothetical product-rate arithmetic, not a general EU rate.

All 48 original nonblank lines have destinations, zero missing. I compared original/current topics and scenarios with the map: duty-only, equality at EUR 150, multiple physical units/items, EU stock, pending registration and marketplace responsibility remain, along with every original refusal and monetary input/output. Bonded warehouses, UK/NI/export, national recovery/portal details, product-specific rates, preferential/special customs flows and detailed later-period outcomes remain explicit non-usable holds. No human name, approval or CTA existed or was added. Exact source hashes, case inputs/results and preservation outcomes accompany this receipt; raw captures and full source documents stay local.

Parent owns committed-head validator/sync gates and shared unchanged tests. This acceptance is a bounded source-reviewed workpaper, not national implementation assurance, complete landed-cost advice or professional attestation.

Written by Codex (world wave). Not reviewed by an accountant.
