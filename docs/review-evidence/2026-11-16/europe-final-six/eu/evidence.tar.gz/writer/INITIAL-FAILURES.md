# Preparation failures and their resolution

- Initial sparse-checkout set omitted --skip-checks for a single template file; it failed without editing a Guide. Corrected command materialized only assigned folders and validator resources.
- Original history lookup in the new partial clone tried to fetch an absent historical object without network permission and failed DNS resolution. The existing complete public-workflow-fixes clone supplied the platform-sync history read-only. No earlier substantive independent IOSS review was recovered.
- First exploratory index loader assumed key skills; actual index uses another container. The inventory/source path was established directly and no Guide depended on that failed loader.
- Some normal web-reader EUR-Lex opens returned robot-check HTML or internal errors. No challenge was bypassed. Normal certificate-verifying curl returned the complete official laws, read from actual text; the final2152 official web view independently opened as full law.
- Worktree validator dependency previews (CLI reports0changed because nothing committed yet) identified five absent global methods, followed by six cross-border dependencies. Exact unchanged dependencies were materialized. This is not a claimed committed-head pass.
- Source-row checker recognizes neither standalone EUR150 nor euro-symbol3/2 as figure tokens:0rows. Actual three rows require independent primary-source review; this parser limit is not represented as substantive confirmation.
