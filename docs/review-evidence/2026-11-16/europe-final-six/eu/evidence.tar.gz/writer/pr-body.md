The EU IOSS workflow now applies the published November handling-fee law and distinguishes it from the temporary customs duty. The original duty-only calculation and all boundary scenarios remain, with their period and assumptions stated.

## Corrected

| Old | New | Official source |
|---|---|---|
| Handling fee left as an announced future measure | Separate EUR 2 per customs item applies from 1 November 2026 | [Regulation 2026/2152 arts. 1–2](https://eur-lex.europa.eu/eli/reg_del/2026/2152/oj/eng) |
| October check and August PDF label implied old source versions | Actual 5 October customs and 6 October VAT addendum versions read; published law supersedes their expected-date wording | Scoped Commission sources and operative regulations in the ledger |
| Missing current fee/VAT and customs handoff conditions | Fee debtor and non-refundability; checkout consideration; indirect-representative and product-data handoff | [Regulation 2026/2108 arts. 20, 85, 287](https://eur-lex.europa.eu/eli/reg/2026/2108/oj/eng); [Regulation 2026/1022 art. 2(3)](https://eur-lex.europa.eu/eli/reg_del/2026/1022/oj/eng) |
| Manual-only duty example | Preserve EUR 100 / 20% / EUR 3 / EUR 103 / EUR 20.60 / EUR 100 / EUR 20; add executable current-period comparison | Current Commission VAT addendum; example rates remain assumptions |

The 38-row ledger inventories actual published primary text, operative scope, short English source quotations and read dates. No earlier substantive independent review was recovered. A fresh separate reviewer checks the complete bounded workflow, three rate rows, all old topics and both calculations. Raw captures stay local; no access challenge was bypassed.

Content checks and both calculations pass. Committed validation and strict sync must pass before publication; mandatory CI runs at the final head. The row-source parser recognizes none of the standalone euro integers and reports zero rows, so it supplies no substantive rate confirmation. Independent primary-source review covers those rows. One compact indexed evidence archive is under `docs/review-evidence/2026-11-16/europe-final-six/eu/`.

Actual product rates, national portal fields and refund procedures, detailed carrier customs/PID implementation, UK/NI/export, bonded or preferential/special customs routes and detailed January 2027 changes remain explicit non-usable holds. This is an IOSS workpaper, without professional approval or a complete landed-cost/customs-filing conclusion.

## Removed and why

No substantive topic or original example input is removed. Old PDF section/date labels and unverified handling-fee wording are replaced by the actual current source versions and published law.

## Moved

All original topics remain within the same file under canonical scope, inputs, method, cases, referral, filing and sources. The archived no-loss map records every original nonblank line. No file merge or deletion.

## Not moved

The UK export, Northern Ireland, product-rate, special-flow and later-period boundaries remain explicit. No sibling or generated file changes.

Written by Codex (world wave). Not reviewed by an accountant.
