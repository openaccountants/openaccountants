# EU IOSS writer handoff

Only `skills/eu/eu-ioss-gb-sellers.md` is edited, from current main `bbab4f1a6`. No earlier substantive independent source review was recovered from local records or the original platform-sync history. Actual Commission paragraphs and operative EU-law articles were read. Raw captures remain local.

Published Regulation 2026/2152 articles 1–2 establishes EUR 2 per customs item from 1 November 2026. The earlier Commission PDFs' expected-date wording is superseded by that published law. The actual customs PDF is dated 5 October and the VAT addendum 6 October, despite older labels in the original Guide and filename.

The candidate adds the canonical filing workflow, scoped source dates and initial version 0.1. It distinguishes the temporary duty period from the handling fee, its debtor and non-refundable character, and the supply-VAT effect of amounts charged at checkout. It adds the current indirect-representative and product-data handoff plus country, correction and payment records. It does not replace a national customs declaration or the intermediary's actual portal.

The original EUR 100, 20%, EUR 3, EUR 103, EUR 20.60, EUR 100 and EUR 20 example figures remain, with the period and assumptions stated. The new November case produces EUR 105 taxable consideration, EUR 21 VAT and EUR 126 checkout total. All six original scenarios and refusal boundaries remain, including UK/NI, product rates, special flows and later-period changes. No human credit, approval or CTA existed or was added.

`LEDGER.md` and `ledger.json` inventory 38 legal rows with short exact official English quotations, operative pinpoints, URLs and actual read date. `NO-LOSS-MAP.md` maps every original nonblank line. `preservation.json` records original inputs and protected-field equality.

Content checks pass and both executable controls recompute. The source-row CLI reports zero rows because its figure recognizer does not count plain euro integers. This is a parser limit, not three validated rows: the separate reviewer must check the EUR 150, EUR 3 and EUR 2 rows against actual authority. Parent owns committed-head validation, strict sync and the already completed unchanged shared test evidence.

Non-usable holds remain for the actual destination product rate, national portal fields and recovery procedures, detailed carrier PID/customs implementation, UK/NI/export, preferential and special customs routes, bonded warehouses and detailed January 2027 outcomes. This is a bounded workpaper without professional approval or a country-completion claim.

Fresh separate review is required for all 38 rows, original topics and both controls. No Git mutation or publication by writer.

Independent review correction: the covered Annex B declaration hierarchy applies from 1 July under 2026/1022; the new Code article 85(2) applies from 20 September. Those dates are now separate. No case input or arithmetic changed.
