# Hungary old-topic and original-input destination map

Base main: bbab4f1a6d82cace432e6ca8eda89c98ffb1c038. Only the two assigned unsigned tier2 Guides were written. This is a writer preservation inventory; independent delta review is pending. Raw source cache is local only.

## hungary-einvoice

| Old topic | Destination / treatment |
| --- | --- |
| Section 1 -- Quick Reference | Section 1 -- Quick Reference |
| Section 2 -- Mandate Scope | Section 2 -- Mandate Scope |
| Who Must Comply | Who Must Comply |
| Timeline Phases | Timeline Phases |
| RTIR vs E-Invoicing Distinction | RTIR vs E-Invoicing Distinction |
| Section 3 -- Technical Format | Section 3 -- Technical Format |
| XML Schema (Online Számla 3.0) | XML Schema (Online Számla 3.0) |
| Key Schema Structures | Key Schema Structures |
| API Request Types | API Request Types |
| Section 4 -- Mandatory Fields | Section 4 -- Mandatory Fields |
| Invoice content required by the Áfa tv. | Invoice content required by the Áfa tv. |
| Invoice data fields (schema 3.0) | Invoice data fields (schema 3.0) |
| Modification Invoice Fields | Modification Invoice Fields |
| Electronic Invoice Through NAV (completenessIndicator = true) | Electronic Invoice Through NAV (completenessIndicator = true) |
| Section 5 -- Transmission Method | Section 5 -- Transmission Method |
| The legal deadline | The legal deadline |
| Outages | Outages |
| NAV Online Számla API | NAV Online Számla API |
| API Workflow | API Workflow |
| Request Signature | Request Signature |
| Batch Submission | Batch Submission |
| Technical User Management | Technical User Management |
| Section 6 -- Validation Rules | Section 6 -- Validation Rules |
| NAV-Side Validation | NAV-Side Validation |
| Pre-Submission Checks | Pre-Submission Checks |
| Common Rejection Reasons | Common Rejection Reasons |
| Technical Annulment | Technical Annulment |
| Section 7 -- Tax Computation Rules | Section 7 -- Tax Computation Rules |
| Hungarian VAT Rates (2026) | Hungarian VAT Rates (2026) |
| Rounding and Tolerances | Rounding and Tolerances |
| Multi-Rate Invoice Handling | Multi-Rate Invoice Handling |
| Currency Handling | Currency Handling |
| Reverse Charge | Reverse Charge |
| Section 8 -- Archiving Requirements | Section 8 -- Archiving Requirements |
| Section 9 -- Penalties for Non-Compliance | Section 9 -- Penalties for Non-Compliance |
| Invoice Data Reporting | Invoice Data Reporting |
| General Invoicing and VAT Penalties | General Invoicing and VAT Penalties |
| Practical Consequences | Practical Consequences |
| Section 10 -- Interaction with Tax Skills | Section 10 -- Interaction with Tax Guides |
| Invoice Data → VAT Return (eÁfa) | Invoice Data → VAT Return (eÁfa) |
| Received Invoices (M sheets) | Received Invoices (M sheets) |
| Electronic Invoice Through NAV → Buyer AP | Electronic Invoice Through NAV → Buyer AP |
| Invoice Data → Corporate Tax | Invoice Data → Corporate Tax |
| Receipts and e-Receipts (e-nyugta) | Receipts and e-Receipts (e-nyugta) |
| Sources | Sources |
| Disclaimer | Disclaimer |

### Other old topics / held claims

All ten original sections and all schema names, request types, enum values, field paths, hashes, dates, deadlines, rates, currencies, fees/fines, retention periods, permitted route conditions, outage exceptions, eÁfa/M-sheet interactions and receipt exceptions remain in the Method. Tables now have row URLs. §163 issue windows were added because the existing description promised them but body omitted them.

The original eleven unconfirmed topic groups stay in Sources as non-usable holds: historic100k threshold; retirement of schemas1/2; Art221 call procedure; software declaration; rounding beyond tolerance; ViDA/structured-invoice plans; eÁfa start; 13/C size limit; graduated delay fines; Hungary/EU archive access; Btk criminal penalties. No current attempt is claimed for the old EUR-Lex failure.

Correction: printed-pad retention penalty reworded from fixed to an upper ceiling and from missing pads to missing printed invoices/receipts, per actual Art228(3). Original200k/500k inputs retained.

### Credits, approval and calls to action

The actual assigned main files had no named credentialed author, reviewed_by, verified_by or approval field and no CTA block. Tier2 and platform license remain unchanged. The VAT change-log attribution to the OpenAccountants team remains. The older PR960 raw Guide and review comments preserve historical names/CTA bytes in prior-review evidence; removed pre-main trust/CTA fields were not restored as new attestations.

## hungary-vat-return

| Old topic | Destination / treatment |
| --- | --- |
| The method, step by step | The method, step by step |
| Ask the client first | Ask the client first |
| When to refuse or refer | When to refuse or refer |
| Section 1: Quick reference | Section 1: Quick reference |
| Section 2: Required inputs and refusal catalogue | Section 2: Required inputs and refusal catalogue |
| Required inputs | Required inputs |
| Hungary-specific refusal catalogue | Hungary-specific refusal catalogue |
| Section 3: Supplier pattern library | Section 3: Supplier pattern library |
| 3.1 Hungarian banks (exempt, exclude) | 3.1 Hungarian banks (exempt, exclude) |
| 3.2 Hungarian government (exclude) | 3.2 Hungarian government (exclude) |
| 3.3 Hungarian utilities | 3.3 Hungarian utilities |
| 3.4 Insurance (exempt, exclude) | 3.4 Insurance (exempt, exclude) |
| 3.5 Post and logistics | 3.5 Post and logistics |
| 3.6 SaaS: EU suppliers (reverse charge, row 18, deduction row 67) | 3.6 SaaS: EU suppliers (reverse charge, row 18, deduction row 67) |
| 3.7 SaaS: non-EU suppliers (reverse charge, row 27, deduction row 67) | 3.7 SaaS: non-EU suppliers (reverse charge, row 27, deduction row 67) |
| 3.8 Payment processors | 3.8 Payment processors |
| 3.9 Professional services | 3.9 Professional services |
| 3.10 Payroll (exclude) | 3.10 Payroll (exclude) |
| 3.11 Food retail and restaurants | 3.11 Food retail and restaurants |
| 3.12 Internal transfers and exclusions | 3.12 Internal transfers and exclusions |
| Section 4: Worked examples | Original bank-line cases |
| Example 1: non-EU SaaS reverse charge (Notion) | Example 1: non-EU SaaS reverse charge (Notion) |
| Example 2: EU service reverse charge (Google Ads) | Example 2: EU service reverse charge (Google Ads) |
| Example 3: restaurant | Example 3: restaurant |
| Example 4: EU B2B service sale | Example 4: EU B2B service sale |
| Example 5: equipment purchase | Example 5: equipment purchase |
| Example 6: motor vehicle fuel | Example 6: motor vehicle fuel |
| Section 5: Tier 1 classification rules (compressed) | Section 5: Tier 1 classification rules (compressed) |
| 5.1 Standard 27% (Áfa tv. § 82(1)) | 5.1 Standard 27% (Áfa tv. § 82(1)) |
| 5.2 Reduced 18% | 5.2 Reduced 18% |
| 5.3 Reduced 5% | 5.3 Reduced 5% |
| 5.4 0% rate, exports and intra-EU supplies | 5.4 0% rate, exports and intra-EU supplies |
| 5.5 Exempt without the right to deduct (Áfa tv. §§ 85 to 87) | 5.5 Exempt without the right to deduct (Áfa tv. §§ 85 to 87) |
| 5.6 Reverse charge, EU | 5.6 Reverse charge, EU |
| 5.7 Reverse charge, non-EU | 5.7 Reverse charge, non-EU |
| 5.8 Domestic reverse charge (Áfa tv. § 142) | 5.8 Domestic reverse charge (Áfa tv. § 142) |
| 5.9 Online invoice reporting | 5.9 Online invoice reporting |
| 5.10 Blocked input | 5.10 Blocked input |
| Section 6: Tier 2 catalogue (compressed) | Section 6: Tier 2 catalogue (compressed) |
| 6.1 Vehicle costs | 6.1 Vehicle costs |
| 6.2 Entertainment and restaurants | 6.2 Entertainment and restaurants |
| 6.3 SaaS entity | 6.3 SaaS entity |
| 6.4 Owner transfers | 6.4 Owner transfers |
| 6.5 Fixed assets | 6.5 Fixed assets |
| 6.6 Mixed-use telecom | 6.6 Mixed-use telecom |
| 6.7 Cash withdrawals | 6.7 Cash withdrawals |
| 6.8 KATA status | 6.8 KATA status |
| Section 7: Excel working paper template | Section 7: Excel working paper template |
| Section 8: Hungary bank statement reading guide | Section 8: Hungary bank statement reading guide |
| Section 9: Onboarding fallback | Section 9: Onboarding fallback |
| 9.1 Entity type | 9.1 Entity type |
| 9.2 VAT status | 9.2 VAT status |
| 9.3 Adószám | 9.3 Adószám |
| 9.4 Filing frequency | 9.4 Filing frequency |
| 9.5 Filing channel | 9.5 Filing channel |
| 9.6 Exempt supplies | 9.6 Exempt supplies |
| 9.7 Credit brought forward | 9.7 Credit brought forward |
| Section 10: Reference material | Section 10: Reference material |
| Change log | Method → Section10 → Change log; preserve historical v3.0 label as corrected record |
| Sources | Sources |
| Disclaimer | Disclaimer |

### Every original supplier pattern / input

| Original pattern | Current status |
| --- | --- |
| OTP, OTP BANK | Preserved verbatim as search hint; historic candidate EXCLUDE is non-usable. Invoice and legal test required. |
| K&H, K&H BANK | Preserved verbatim as search hint; historic candidate EXCLUDE is non-usable. Invoice and legal test required. |
| ERSTE BANK HU, ERSTE | Preserved verbatim as search hint; historic candidate EXCLUDE is non-usable. Invoice and legal test required. |
| MBH BANK, BUDAPEST BANK, TAKAREKBANK | Preserved verbatim as search hint; historic candidate EXCLUDE is non-usable. Invoice and legal test required. |
| CIB BANK | Preserved verbatim as search hint; historic candidate EXCLUDE is non-usable. Invoice and legal test required. |
| UNICREDIT HU | Preserved verbatim as search hint; historic candidate EXCLUDE is non-usable. Invoice and legal test required. |
| REVOLUT, WISE, N26 (fee lines) | Preserved verbatim as search hint; historic candidate EXCLUDE is non-usable. Invoice and legal test required. |
| KAMAT, INTEREST | Preserved verbatim as search hint; historic candidate EXCLUDE is non-usable. Invoice and legal test required. |
| HITEL, KOLCSON, LOAN | Preserved verbatim as search hint; historic candidate EXCLUDE is non-usable. Invoice and legal test required. |
| NAV, NEMZETI ADO | Preserved verbatim as search hint; historic candidate EXCLUDE is non-usable. Invoice and legal test required. |
| TB, TARSADALOMBIZTOSITAS | Preserved verbatim as search hint; historic candidate EXCLUDE is non-usable. Invoice and legal test required. |
| ONKORMANYZAT, MUNICIPALITY | Preserved verbatim as search hint; historic candidate EXCLUDE is non-usable. Invoice and legal test required. |
| CEGJEGYZEK, COMPANY REGISTER | Preserved verbatim as search hint; historic candidate EXCLUDE is non-usable. Invoice and legal test required. |
| MVM, ELMÜ-ÉMÁSZ, E.ON HU | Preserved verbatim as search hint; historic candidate Domestic 27% unless the invoice shows another rate is non-usable. Invoice and legal test required. |
| FŐVÁROSI VÍZMŰVEK, VÍZMŰ | Preserved verbatim as search hint; historic candidate Rate as shown on the invoice is non-usable. Invoice and legal test required. |
| FŐGÁZ, GÁZ | Preserved verbatim as search hint; historic candidate Domestic 27% unless the invoice shows another rate is non-usable. Invoice and legal test required. |
| FŐTÁV, TÁVHŐ | Preserved verbatim as search hint; historic candidate Domestic 5% is non-usable. Invoice and legal test required. |
| MAGYAR TELEKOM, T-MOBILE HU | Preserved verbatim as search hint; historic candidate Split by invoice line: internet access 5%, other telecom 27% is non-usable. Invoice and legal test required. |
| VODAFONE HU, YETTEL HU | Preserved verbatim as search hint; historic candidate Split by invoice line as above is non-usable. Invoice and legal test required. |
| DIGI HU | Preserved verbatim as search hint; historic candidate Split by invoice line as above is non-usable. Invoice and legal test required. |
| ALLIANZ HUNGARIA | Preserved verbatim as search hint; historic candidate EXCLUDE is non-usable. Invoice and legal test required. |
| GENERALI BIZTOSITO | Preserved verbatim as search hint; historic candidate EXCLUDE is non-usable. Invoice and legal test required. |
| GROUPAMA BIZTOSITO | Preserved verbatim as search hint; historic candidate EXCLUDE is non-usable. Invoice and legal test required. |
| BIZTOSITAS, INSURANCE | Preserved verbatim as search hint; historic candidate EXCLUDE is non-usable. Invoice and legal test required. |
| MAGYAR POSTA | Preserved verbatim as search hint; historic candidate EXCLUDE for standard post; 27% for parcel is non-usable. Invoice and legal test required. |
| GLS HU | Preserved verbatim as search hint; historic candidate Domestic 27%, row 66 is non-usable. Invoice and legal test required. |
| MPL (Magyar Posta Logisztika) | Preserved verbatim as search hint; historic candidate Domestic 27%, row 66 is non-usable. Invoice and legal test required. |
| DHL INTERNATIONAL | Preserved verbatim as search hint; historic candidate EU reverse charge (rows 18 and 67) is non-usable. Invoice and legal test required. |
| GOOGLE | Preserved verbatim as search hint; historic candidate Google Ireland Ltd (IE) is non-usable. Invoice and legal test required. |
| MICROSOFT | Preserved verbatim as search hint; historic candidate Microsoft Ireland (IE) is non-usable. Invoice and legal test required. |
| ADOBE | Preserved verbatim as search hint; historic candidate Adobe Ireland (IE) is non-usable. Invoice and legal test required. |
| META, FACEBOOK | Preserved verbatim as search hint; historic candidate Meta Ireland (IE) is non-usable. Invoice and legal test required. |
| SPOTIFY | Preserved verbatim as search hint; historic candidate Spotify AB (SE) is non-usable. Invoice and legal test required. |
| DROPBOX | Preserved verbatim as search hint; historic candidate Dropbox Ireland (IE) is non-usable. Invoice and legal test required. |
| SLACK | Preserved verbatim as search hint; historic candidate Slack Ireland (IE) is non-usable. Invoice and legal test required. |
| ATLASSIAN | Preserved verbatim as search hint; historic candidate Atlassian BV (NL) is non-usable. Invoice and legal test required. |
| ZOOM | Preserved verbatim as search hint; historic candidate Zoom Ireland (IE) is non-usable. Invoice and legal test required. |
| AWS EMEA SARL | Preserved verbatim as search hint; historic candidate LU entity is non-usable. Invoice and legal test required. |
| NOTION | Preserved verbatim as search hint; historic candidate Notion Labs Inc (US) is non-usable. Invoice and legal test required. |
| ANTHROPIC, CLAUDE | Preserved verbatim as search hint; historic candidate Anthropic PBC (US) is non-usable. Invoice and legal test required. |
| OPENAI, CHATGPT | Preserved verbatim as search hint; historic candidate OpenAI Inc (US) is non-usable. Invoice and legal test required. |
| GITHUB | Preserved verbatim as search hint; historic candidate GitHub Inc (US) is non-usable. Invoice and legal test required. |
| FIGMA | Preserved verbatim as search hint; historic candidate Figma Inc (US) is non-usable. Invoice and legal test required. |
| CANVA | Preserved verbatim as search hint; historic candidate Canva Pty Ltd (AU) is non-usable. Invoice and legal test required. |
| STRIPE (transaction fees) | Preserved verbatim as search hint; historic candidate EXCLUDE (exempt) is non-usable. Invoice and legal test required. |
| PAYPAL (transaction fees) | Preserved verbatim as search hint; historic candidate EXCLUDE (exempt) is non-usable. Invoice and legal test required. |
| KÖZJEGYZŐ, NOTARY | Preserved verbatim as search hint; historic candidate Domestic 27%, row 66 is non-usable. Invoice and legal test required. |
| KÖNYVELŐ, ACCOUNTANT | Preserved verbatim as search hint; historic candidate Domestic 27%, row 66 is non-usable. Invoice and legal test required. |
| ÜGYVÉD, LAWYER | Preserved verbatim as search hint; historic candidate Domestic 27%, row 66 is non-usable. Invoice and legal test required. |
| TB, JÁRULÉK | Preserved verbatim as search hint; historic candidate EXCLUDE is non-usable. Invoice and legal test required. |
| BÉR, FIZETÉS, SALARY | Preserved verbatim as search hint; historic candidate EXCLUDE is non-usable. Invoice and legal test required. |
| SZJA | Preserved verbatim as search hint; historic candidate EXCLUDE is non-usable. Invoice and legal test required. |
| TESCO HU, ALDI HU, LIDL HU, SPAR HU, PENNY | Preserved verbatim as search hint; historic candidate Default BLOCK is non-usable. Invoice and legal test required. |
| ÉTTEREM, RESTAURANT, VENDÉGLŐ | Preserved verbatim as search hint; historic candidate Default BLOCK is non-usable. Invoice and legal test required. |
| SAJÁT ÁTUTALÁS, OWN TRANSFER | Preserved verbatim as search hint; historic candidate EXCLUDE is non-usable. Invoice and legal test required. |
| OSZTALÉK, DIVIDEND | Preserved verbatim as search hint; historic candidate EXCLUDE is non-usable. Invoice and legal test required. |
| HITELTÖRLESZTÉS, LOAN REPAYMENT | Preserved verbatim as search hint; historic candidate EXCLUDE is non-usable. Invoice and legal test required. |
| ATM, KÉSZPÉNZ | Preserved verbatim as search hint; historic candidate Ask is non-usable. Invoice and legal test required. |

### Original six case inputs (verbatim)

1. `03.04.2026 ; NOTION LABS INC ; debit` → Worked cases, original bank-line case 1. No original monetary amount existed. Assumed invoice/contract facts now explicit; fuel ban corrected to petrol/other fuel distinction. Treatment and original date/name/debit-credit labels retained.
2. `10.04.2026 ; GOOGLE IRELAND LIMITED ; debit` → Worked cases, original bank-line case 2. No original monetary amount existed. Assumed invoice/contract facts now explicit; fuel ban corrected to petrol/other fuel distinction. Treatment and original date/name/debit-credit labels retained.
3. `15.04.2026 ; BORKONYHA ÉTTEREM ; debit` → Worked cases, original bank-line case 3. No original monetary amount existed. Assumed invoice/contract facts now explicit; fuel ban corrected to petrol/other fuel distinction. Treatment and original date/name/debit-credit labels retained.
4. `22.04.2026 ; STUDIO KREBS GMBH ; credit` → Worked cases, original bank-line case 4. No original monetary amount existed. Assumed invoice/contract facts now explicit; fuel ban corrected to petrol/other fuel distinction. Treatment and original date/name/debit-credit labels retained.
5. `18.04.2026 ; MEDIAMARKT HU ; Laptop ; debit` → Worked cases, original bank-line case 5. No original monetary amount existed. Assumed invoice/contract facts now explicit; fuel ban corrected to petrol/other fuel distinction. Treatment and original date/name/debit-credit labels retained.
6. `28.04.2026 ; MOL NYRT ; Fuel ; debit` → Worked cases, original bank-line case 6. No original monetary amount existed. Assumed invoice/contract facts now explicit; fuel ban corrected to petrol/other fuel distinction. Treatment and original date/name/debit-credit labels retained.

### Other old topics / held claims

Original unknown-rate, purchaseVAT, country, B2B/B2C, businessshare, SaaSentity, blockedinput and channel defaults now become explicit non-usable review holds. None permits an inferred legal classification. Redflags remain adopting-accountant choices, not statutory thresholds.

Bankstatement list, Hungarian words, HU IBAN, CSV delimiter/date hints, Kft/sole-trader onboarding, 11-digit tax-number question, year2024 frequency inputs, exemption actual2025/expected+actual2026 conditions, form2665 row codes and ColumnH workingpaper instructions preserved. CSV patterns are explicitly unverified import hints. Bankstatement alone only triage; invoices/registration/prior credit now required before filing.

Zero rate: old newspaper-only assertion is corrected; daily-newspaper input and rows110/111 preserved and prescription-only medicines/human magistral preparations added from1Sept2026. Originalbookletquote retained as newspaper proof, supplemented by operative Annex3/B.

Original numeric rate/threshold/form rows are enumerated individually in ledgerHU072 onward; method dependency groups follow. Existing six qualitative examples remain, and the new case inputs below are explicitly hypothetical additions.

### Credits, approval and calls to action

The actual assigned main files had no named credentialed author, reviewed_by, verified_by or approval field and no CTA block. Tier2 and platform license remain unchanged. The VAT change-log attribution to the OpenAccountants team remains. The older PR960 raw Guide and review comments preserve historical names/CTA bytes in prior-review evidence; removed pre-main trust/CTA fields were not restored as new attestations.

## New hypothetical inputs and results

| Case | Inputs | Recomputed results |
| --- | --- | --- |
| Software invoice | net100000HUF; rate0.27 | VAT27000; gross127000 |
| Batch split | operations101; limit100 | ceil(101/100)=2 requests; lastrequest1 |
| VAT return | sales1000000HUF; rate0.27; inputVAT135000; priorcredit50000 | output270000; balance85000HUF; main-sheet row84=85(thousandHUF) |

All original qualitative bank-case inputs remain unchanged; none had a supplied monetary figure. Existing prior-review quality-cases.json is preserved byte-exact, including monthly/annual/EU-number/refund threshold examples. No invented old amount is claimed.

Focused review closure: source-attribution rows corrected to actual NAV XSD/spec/decree sources; editorial citations removed. Human medicinal qualifier restored on the e-invoice magistral zero-rate row, matching the existing operative ledger/VAT Guide. No old input/topic was removed.
