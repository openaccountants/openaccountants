# Hungary writer handoff — 16 November 2026

Writer stopped. Candidate requires the separate independent delta reviewer; this report does not certify its own review.

Only `skills/hungary/hungary-einvoice.md` (1.1 → 1.2) and `skills/hungary/hungary-vat-return.md` (2.0 → 2.1) were written. Both remain unsigned tier2. Baseline was main `bbab4f1a6d82cace432e6ca8eda89c98ffb1c038`; current shared-lane HEAD at freeze is recorded in STATUS.json. Other lane work moved HEAD without changing the assigned baseline content. Writer made no branch, stage, commit, push, merge, release or database change.

## Substantive corrections / delta review scope

1. Periodic VAT's newspaper-only zero-rate claim was stale. Operative Áfa tv. Annex3/B rows2–3 include prescription-only medicines and human medicinal magistral preparations; ActXL2026 §4 commences 1September2026. The old newspaper quote and form110/111 destinations remain. Current NJT public annex blocks and commencement paragraph were read; no private or paid source used.
2. All eight guessed classification defaults and all original provider/billing-entity patterns now are explicit non-usable holds/search hints. Establish actual supply, supplier establishment, customer status, rate, deduction evidence and channel before posting/filing. Every original pattern/name and six bank-case input strings remain. A bank statement alone permits triage, not filing. CSV formats are unverified import hints.
3. Fuel case now distinguishes motor petrol (blocked irrespective of vehicle type) from other fuel for passenger cars, with §125 exceptions reserved for established facts. Mixed-use telecom expressly requires its specific statutory restriction/exception, not business-use share alone. Native §124–125/125A operative conditions are in the ledger.
4. E-invoice description already promised invoice issue deadlines, but body omitted them. Added §163 issue windows: qualifying cross-border15th next month, paid/advance without delay subject167(c) exception, other charged-VAT invoices8days; separate §164 aggregate and §170(2) correction timing checks. Reporting remains immediate once software invoice closes.
5. A genuine conflict reopens one old PR960 conclusion. Art228(3) says the printed-invoice/receipt preservation fine may extend **up to** the computed200k/500kHUF × number missing (used or unused), not a fixed fine per missing pad. Guide now follows actual operative wording `összegig terjedhet`. Prior reviewer statement is preserved unchanged as historical evidence.
6. Both Guides now declare filing-howto, use canonical headings, have row URLs and explicit read/applicability scopes. VAT missing category restored and description2565 corrected to2665. Historical change-log v3.0 label remains explicitly historical; actual published frontmatter2.0 controls the2.1 increment. Three hypothetical recomputing cases added without inventing old monetary inputs.

## Completed research/review reused

- `prior-review/pr960-comments.json` and `pr960-reviewed-guide.md` bind the 30October independent e-invoice review (104+5 legal rows in its original inventory). Actual main legal body matched the reviewed Guide exactly; only legacy trust/CTA metadata removed before current main differed. No historic name/CTA was silently recreated as a new attestation.
- The actual periodic-VAT body equals the recovered reviewed packet after skill/Guide public-copy normalization, with original bodySHA256 `3dd0dcc0ba98722728d0c65d28fce46f57693279f90fec9be885e8fced7dce59`. `prior-review/applicability.json` records the comparison. Its review.json, quality-evidence.json, quality-cases.json, figures.json, metadata.json and sources.json are byte-exact original copies; `prior-review/bindings.json` records hashes.
- `prior-review/pr700-comments.json` is sibling-VAT corroboration, not substituted for the assigned periodic Guide's own review. It already identified the newspaper-only defect.
- Current official NJT operative annexes/affected paragraphs and the pinned NAV repository tree confirm2026 applicability. NAV technical treeSHA `cc7a775d6dce361311e409abb9934eb755f2749c` retains the12February2026 specification. Original read dates distinguish completed reads from this applicability/anchor check; no new whole-law read is claimed.

## Evidence and checks

- `ledgers/hungary-einvoice.md` and `ledgers/hungary-vat-return.md`: full figure/rule inventory with native quotes, act/article or schema declaration, official URL, read date and provenance. `ledger.json` has160 unique rows:71 apply to e-invoice,90 to VAT, with one shared zero-rate row. Grouped technical/form dependency rows enumerate their component fields; hypothetical numbers are separately inventoried in the no-loss map.
- `NO-LOSS-MAP.md` and `no-loss-checks.json`: every old heading, every provider pattern, all six input strings and three new cases.171 preservation checks pass. Actual main credits/license/tier preserved.
- `scoped-checks.json`: both assigned results `{}`. `scoped-checks.txt` contains the full scoped output. `row-sources.json`: scoped row-source checks pass. `examples.txt`:3 oa-check blocks,0 failures,0 missing. `git diff --check -- <two assigned paths>` exits0.
- STATUS.json binds exact final Guide SHA256/Git blobs. Parent handles the single shared calculator/copy suite and committed-content validator/sync gates. They were not rerun by writer.
- `cache/` holds local-only NJT/NAV raw captures, parsed anchors and technical sources. `recovered-cache.json` maps the original14November cache. `retrieval.json` records current downloads; download success alone is not claimed as a source read.

## Genuine non-usable holds

The eleven existing e-invoice groups remain: historic100k threshold; schema1/2 retirement dates; Art221 call procedure before229fine; software declaration; rounding beyond tolerance; ViDA/structured-invoice plans; eÁfa start; current13/C size limit; graduated-delay fines; Hungary/EU archive access; Btk criminal penalties. The old EUR-Lex failure remains explicitly a prior read failure, not a new attempted read. Provider-specific current billing entities, bank-inferred treatment and universal CSV formats also remain unverified non-usable hints. No usable delta is being held out as verified despite a failed source read.

## Focused independent-review corrections

After the initial freeze, corrected only cited source rows and the human-medicinal qualifier. Quick-reference schema/system/model claims now cite NAV schemas/README/decree rather than the VAT Act; each technical table points to the relevant cached XSD or exact pinned NAV specification PDF. Removed source URLs from editorial country/version/companion rows. E-invoice zero-rate wording now expressly limits magistral preparations to human medicinal use. VAT zero-rate quick-reference row now cites operative Annex3/B and ActXL2026 alongside the old newspaper booklet. Ledger technical URLs refined to the exact already-cached specification, with native quotes/rules unchanged. No unchanged research or arithmetic suite repeated. Current ownership/reservation check is review-correction-ownership.json.

Editorial country/version/companion information remains as prose immediately after its quick-reference table, since the row-source checker correctly requires authority for every row of an amount-bearing table. The initial affected-check failure from uncited editorial rows was resolved by this placement; no legal claim changed.
