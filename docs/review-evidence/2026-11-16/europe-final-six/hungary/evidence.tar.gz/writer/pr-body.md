The Hungarian invoice and VAT-return workflows now require actual supply evidence before classification and state the current zero-rate scope, issue deadlines and statutory fine ceiling. Both existing Guides keep their original topics, names, bank inputs and prior review evidence.

## Corrected

| Old | New | Authority |
|---|---|---|
| Zero rate described as newspapers only | Current Annex 3/B also covers the specified prescription-only human medicines and magistral preparations from 1 September 2026 | VAT Act Annex 3/B; Act XL/2026 section 4 |
| Provider or bank patterns could imply a posting result | Explicit non-usable search hints until supplier, supply, customer, rate, deduction and channel evidence are established | VAT Act sections 124–125A and the applicable transaction provisions |
| Invoice issue deadlines promised but omitted | Conditional section 163 issue windows, aggregate-invoice and correction checks | VAT Act sections 163–164, 170 |
| Printed-document preservation fine presented as fixed | Up-to statutory ceiling calculated from missing used or unused invoices/receipts | Tax Administration Act section 228(3) |
| Incomplete filing structure and source attribution | Required inputs, conditional steps, row-local authority, three recomputing controls and canonical headings | NAV schema and form materials; actual legislative paragraphs |

The 160 unique legal/technical ledger rows distinguish completed research and review reused after an applicability check from changed rules actually reopened. The prior e-invoice and periodic-VAT review records are preserved byte-exact. The independent reviewer checks all changed claims and their dependencies, the prior-review applicability, preservation and arithmetic; the contradictory old fine conclusion remains visible as historical evidence.

All 171 preservation checks pass, including the original provider patterns and six bank input strings. Both scoped content checks pass and all three controls recompute. Committed validation and strict sync must pass before publication; required CI runs on the final head. A deterministic indexed evidence archive is under `docs/review-evidence/2026-11-16/europe-final-six/hungary/`; raw source captures stay local.

Existing e-invoice source gaps, current provider entities, universal CSV imports and bank-inferred treatments remain explicit non-usable holds. Tier 2 remains; there is no accountant approval or country-completion claim.

## Removed and why

Guessed default treatments are converted to explicit holds, preserving the original names and search patterns. The misleading fixed-fine conclusion is replaced by the operative ceiling. Invalid metadata, the obsolete form number in the description and unsupported source attribution are corrected. No original substantive topic or case input is silently removed.

## Moved

Existing topics are mapped within the same two files to scope, inputs, method, controls, handoffs and sources. Historical version and provider material remains explicitly historical or non-usable. No Guide merge or deletion.

## Not moved

Only the two assigned Hungarian Guides and their evidence are changed. Human names and credits remain. Generated outputs, scripts, approvals, databases and live services are untouched.

Written by Codex (world wave). Not reviewed by an accountant.
