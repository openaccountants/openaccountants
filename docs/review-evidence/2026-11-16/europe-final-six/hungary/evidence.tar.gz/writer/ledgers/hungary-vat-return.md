# hungary-vat-return figure and rule ledger

Base: bbab4f1a6d82cace432e6ca8eda89c98ffb1c038. Evidence is a writer inventory, not a new independent attestation. Unchanged PR960/periodic-VAT packet research and review are reused after one 2026-11-16 applicability check. Read dates below name original actual reads; current anchors bind applicability and changed claims. Native Hungarian law/authority excerpts are normalized only for whitespace; XML declarations are native technical identifiers. Hypothetical amounts/results and every retained provider/import hold are fully inventoried in NO-LOSS-MAP.md, not counted as legal rows.

## HU053 — Zero-rate scope

Daily newspapers; prescription-only medicines and human medicinal magistral preparations from2026-09-01

- Act/article: Áfa tv. Annex3/B rows1–3; ActXL2026§4
- Official URL: https://njt.jog.gov.hu/jogszabaly/2007-127-00-00
- Read: 2026-11-16; Changed VAT wording and unchanged e-invoice rule verified in operative official annex and commencement
- Cached locator: vat-annex-block.txt;amend-zero.txt
- Exact native anchor(s):
  - `Kizárólag orvosi rendelvényhez kötött gyógyszerek`
  - `Humán gyógyászati célú magisztrális készítmények`
  - `Ez a törvény 2026. szeptember 1-jén lép hatályba.`

## HU072 — Quick reference: Quick reference field table

0% rate = 0% for daily newspapers (row 110). Exports and intra-EU supplies of goods are exempt with the right to deduct, on rows 01 and 02, not "0% rate" sales

- Act/article: Áfa tv.§82
- Official URL: 
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `0% rate`

## HU073 — Quick reference: Quick reference field table

Return form = Form 2665 for 2026 periods (the year digits followed by 65). "2665A" names the main sheets inside form 2665, not a separate form

- Act/article: NAV Quick reference field table
- Official URL: 
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `2665A`

## HU074 — Quick reference: Rates, frequency, deadlines, refunds and invoice reporting (NAV booklet 14, published 22 January 2026)

Standard rate (Áfa tv. § 82(1)) = 27%

- Act/article: Áfa tv.§82
- Official URL: https://nav.gov.hu/pfile/file?path=/ugyfeliranytu/nezzen-utana/inf_fuz/2026/14.-Hasznos-tudnivalok-kezdo-afaalanyoknak-2025.-02.-03
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `általános adómértéke az adó alapjának 27 százaléka`

## HU075 — Quick reference: Rates, frequency, deadlines, refunds and invoice reporting (NAV booklet 14, published 22 January 2026)

Reduced rate: certain foodstuffs listed by tariff number in the annex; the booklet does not print the full list = 18%

- Act/article: Áfa tv.§82
- Official URL: https://nav.gov.hu/pfile/file?path=/ugyfeliranytu/nezzen-utana/inf_fuz/2026/14.-Hasznos-tudnivalok-kezdo-afaalanyoknak-2025.-02.-03
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `A 18 százalékos adómértékű termékeket – ilyenek egyes élelmiszerek`

## HU076 — Quick reference: Rates, frequency, deadlines, refunds and invoice reporting (NAV booklet 14, published 22 January 2026)

Reduced rate: admission to occasional open-air events = 18%

- Act/article: Áfa tv.§82
- Official URL: https://nav.gov.hu/pfile/file?path=/ugyfeliranytu/nezzen-utana/inf_fuz/2026/14.-Hasznos-tudnivalok-kezdo-afaalanyoknak-2025.-02.-03
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `a szintén 18 százalékos adómértékű, az alkalmi szabadtéri rendezvényre`

## HU077 — Quick reference: Rates, frequency, deadlines, refunds and invoice reporting (NAV booklet 14, published 22 January 2026)

Reduced rate, goods: for example books, sheet music, periodicals, certain medical products and aids, certain pork, beef, sheep, goat, poultry, egg and milk products, fish for human consumption = 5%

- Act/article: Áfa tv.§82
- Official URL: https://nav.gov.hu/pfile/file?path=/ugyfeliranytu/nezzen-utana/inf_fuz/2026/14.-Hasznos-tudnivalok-kezdo-afaalanyoknak-2025.-02.-03
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `5 százalékos adómérték alá tartozik például a könyv, a kotta, a folyóirat`

## HU078 — Quick reference: Rates, frequency, deadlines, refunds and invoice reporting (NAV booklet 14, published 22 January 2026)

Reduced rate, services: for example district heating, some performing-arts services, internet access, restaurant food and on-the-spot non-alcoholic drinks, commercial accommodation = 5%

- Act/article: Áfa tv.§82
- Official URL: https://nav.gov.hu/pfile/file?path=/ugyfeliranytu/nezzen-utana/inf_fuz/2026/14.-Hasznos-tudnivalok-kezdo-afaalanyoknak-2025.-02.-03
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `Néhány szolgáltatás is az 5 százalékos adómérték alá tartozik, például a távhőszolgáltatás`

## HU079 — Quick reference: Rates, frequency, deadlines, refunds and invoice reporting (NAV booklet 14, published 22 January 2026)

Daily newspapers (published at least four times a week) = 0%

- Act/article: NAV Rates, frequency, deadlines, refunds and invoice reporting (NAV booklet 14, published 22 January 2026)
- Official URL: https://nav.gov.hu/pfile/file?path=/ugyfeliranytu/nezzen-utana/inf_fuz/2026/14.-Hasznos-tudnivalok-kezdo-afaalanyoknak-2025.-02.-03
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `A 0 százalékos kulcs alá tartozik a napilap (hetente legalább négyszer`

## HU080 — Quick reference: Rates, frequency, deadlines, refunds and invoice reporting (NAV booklet 14, published 22 January 2026)

Cash accounting: available only if supplies net of VAT, annualised, did not exceed this in the previous year actually AND are neither expected to nor do exceed it in the current year = HUF 125,000,000

- Act/article: NAV Rates, frequency, deadlines, refunds and invoice reporting (NAV booklet 14, published 22 January 2026)
- Official URL: https://nav.gov.hu/pfile/file?path=/ugyfeliranytu/nezzen-utana/inf_fuz/2026/14.-Hasznos-tudnivalok-kezdo-afaalanyoknak-2025.-02.-03
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `nem haladja meg a 125.000.000 forintnak megfelelő pénzösszeget`

## HU081 — Quick reference: Rates, frequency, deadlines, refunds and invoice reporting (NAV booklet 14, published 22 January 2026)

Monthly filing: VAT to be accounted for in the second year before, annualised, positive AND at least this = HUF 1 million

- Act/article: NAV Rates, frequency, deadlines, refunds and invoice reporting (NAV booklet 14, published 22 January 2026)
- Official URL: https://nav.gov.hu/pfile/file?path=/ugyfeliranytu/nezzen-utana/inf_fuz/2026/14.-Hasznos-tudnivalok-kezdo-afaalanyoknak-2025.-02.-03
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `összege pozitív előjelű, és az 1 millió forintot elérte`

## HU082 — Quick reference: Rates, frequency, deadlines, refunds and invoice reporting (NAV booklet 14, published 22 January 2026)

Annual filing, test 1: VAT to be accounted for in the second year before, annualised, below this whatever its sign = HUF 250 thousand

- Act/article: NAV Rates, frequency, deadlines, refunds and invoice reporting (NAV booklet 14, published 22 January 2026)
- Official URL: https://nav.gov.hu/pfile/file?path=/ugyfeliranytu/nezzen-utana/inf_fuz/2026/14.-Hasznos-tudnivalok-kezdo-afaalanyoknak-2025.-02.-03
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `előjelétől függetlenül nem érte el a 250 ezer forintot`

## HU083 — Quick reference: Rates, frequency, deadlines, refunds and invoice reporting (NAV booklet 14, published 22 January 2026)

Annual filing, test 2: net supplies, annualised, not above this = HUF 50 million

- Act/article: NAV Rates, frequency, deadlines, refunds and invoice reporting (NAV booklet 14, published 22 January 2026)
- Official URL: https://nav.gov.hu/pfile/file?path=/ugyfeliranytu/nezzen-utana/inf_fuz/2026/14.-Hasznos-tudnivalok-kezdo-afaalanyoknak-2025.-02.-03
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `éves szinten összesített összege nem haladja meg az 50 millió forintot`

## HU084 — Quick reference: Rates, frequency, deadlines, refunds and invoice reporting (NAV booklet 14, published 22 January 2026)

Monthly return and payment due = 20th of the following month

- Act/article: NAV Rates, frequency, deadlines, refunds and invoice reporting (NAV booklet 14, published 22 January 2026)
- Official URL: https://nav.gov.hu/pfile/file?path=/ugyfeliranytu/nezzen-utana/inf_fuz/2026/14.-Hasznos-tudnivalok-kezdo-afaalanyoknak-2025.-02.-03
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `a tárgyhónapot követő hónap 20-ig`

## HU085 — Quick reference: Rates, frequency, deadlines, refunds and invoice reporting (NAV booklet 14, published 22 January 2026)

Quarterly return and payment due = 20th of the month after the quarter

- Act/article: NAV Rates, frequency, deadlines, refunds and invoice reporting (NAV booklet 14, published 22 January 2026)
- Official URL: https://nav.gov.hu/pfile/file?path=/ugyfeliranytu/nezzen-utana/inf_fuz/2026/14.-Hasznos-tudnivalok-kezdo-afaalanyoknak-2025.-02.-03
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `a negyedéves adóbevallásra kötelezett adóalanynak a negyedévet követő hónap 20-ig`

## HU086 — Quick reference: Rates, frequency, deadlines, refunds and invoice reporting (NAV booklet 14, published 22 January 2026)

Annual return and payment due = 25 February of the following year

- Act/article: NAV Rates, frequency, deadlines, refunds and invoice reporting (NAV booklet 14, published 22 January 2026)
- Official URL: https://nav.gov.hu/pfile/file?path=/ugyfeliranytu/nezzen-utana/inf_fuz/2026/14.-Hasznos-tudnivalok-kezdo-afaalanyoknak-2025.-02.-03
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `a tárgyévet követő év február 25-ig`

## HU087 — Quick reference: Rates, frequency, deadlines, refunds and invoice reporting (NAV booklet 14, published 22 January 2026)

Refund minimum, monthly filer (negative balance reaches or exceeds) = HUF 1 million

- Act/article: NAV Rates, frequency, deadlines, refunds and invoice reporting (NAV booklet 14, published 22 January 2026)
- Official URL: https://nav.gov.hu/pfile/file?path=/ugyfeliranytu/nezzen-utana/inf_fuz/2026/14.-Hasznos-tudnivalok-kezdo-afaalanyoknak-2025.-02.-03
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `a havi bevallásra kötelezett adóalanynál az 1 millió forintot`

## HU088 — Quick reference: Rates, frequency, deadlines, refunds and invoice reporting (NAV booklet 14, published 22 January 2026)

Refund minimum, quarterly filer = HUF 250 thousand

- Act/article: NAV Rates, frequency, deadlines, refunds and invoice reporting (NAV booklet 14, published 22 January 2026)
- Official URL: https://nav.gov.hu/pfile/file?path=/ugyfeliranytu/nezzen-utana/inf_fuz/2026/14.-Hasznos-tudnivalok-kezdo-afaalanyoknak-2025.-02.-03
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `negyedéves bevallásra kötelezett adóalanynál a 250 ezer forintot`

## HU089 — Quick reference: Rates, frequency, deadlines, refunds and invoice reporting (NAV booklet 14, published 22 January 2026)

Refund minimum, annual filer = HUF 50 thousand

- Act/article: NAV Rates, frequency, deadlines, refunds and invoice reporting (NAV booklet 14, published 22 January 2026)
- Official URL: https://nav.gov.hu/pfile/file?path=/ugyfeliranytu/nezzen-utana/inf_fuz/2026/14.-Hasznos-tudnivalok-kezdo-afaalanyoknak-2025.-02.-03
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `éves bevallásra kötelezett adóalanynál az 50 ezer forintot`

## HU090 — Quick reference: Rates, frequency, deadlines, refunds and invoice reporting (NAV booklet 14, published 22 January 2026)

Paper invoice: report on NAV's online interface within 4 days = 4 days

- Act/article: NAV Rates, frequency, deadlines, refunds and invoice reporting (NAV booklet 14, published 22 January 2026)
- Official URL: https://nav.gov.hu/pfile/file?path=/ugyfeliranytu/nezzen-utana/inf_fuz/2026/14.-Hasznos-tudnivalok-kezdo-afaalanyoknak-2025.-02.-03
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `4 napon belül, vagy ha a számla adótartalma eléri vagy meghaladja`

## HU091 — Quick reference: Rates, frequency, deadlines, refunds and invoice reporting (NAV booklet 14, published 22 January 2026)

Paper invoice whose VAT content reaches or exceeds this: report within 1 day = HUF 500,000

- Act/article: NAV Rates, frequency, deadlines, refunds and invoice reporting (NAV booklet 14, published 22 January 2026)
- Official URL: https://nav.gov.hu/pfile/file?path=/ugyfeliranytu/nezzen-utana/inf_fuz/2026/14.-Hasznos-tudnivalok-kezdo-afaalanyoknak-2025.-02.-03
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `adótartalma eléri vagy meghaladja az 500.000 forintot, akkor 1 napon belül`

## HU092 — Quick reference: Subjective exemption (NAV news item, 11 December 2025)

Limit for choosing the exemption for 2026 (raised from the 2025 limit; later years carry higher limits already legislated) = HUF 20 million

- Act/article: NAV Subjective exemption (NAV news item, 11 December 2025)
- Official URL: https://nav.gov.hu/ado/afa/Emelkedik_az_alanyi_adomentesseg_ertekhatara
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `2026-tól 18 millió forintról 20 millió forintra`

## HU093 — Quick reference: Subjective exemption (NAV news item, 11 December 2025)

Deadline to notify NAV of the choice for 2026 = 31 December 2025

- Act/article: NAV Subjective exemption (NAV news item, 11 December 2025)
- Official URL: https://nav.gov.hu/ado/afa/Emelkedik_az_alanyi_adomentesseg_ertekhatara
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `2025. december 31-éig kell bejelenteni a Nemzeti Adó- és Vámhivatalhoz`

## HU094 — Quick reference: Frequency reference year and EU sales list (NAV booklet 24, published 26 January 2026)

Year whose data set the 2026 monthly test = 2024

- Act/article: NAV Frequency reference year and EU sales list (NAV booklet 24, published 26 January 2026)
- Official URL: https://nav.gov.hu/pfile/file?path=/ugyfeliranytu/nezzen-utana/inf_fuz/2026/24.-Bevallasi-adofizetesi-informaciok-2026.01.26
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `akinek/amelynek a 2024. évre vonatkozóan`

## HU095 — Quick reference: Frequency reference year and EU sales list (NAV booklet 24, published 26 January 2026)

EU sales list moves from quarterly to monthly when intra-EU supplies of goods (and acquisitions, triangulation) in the quarter, net of VAT, exceed this = EUR 50,000

- Act/article: NAV Frequency reference year and EU sales list (NAV booklet 24, published 26 January 2026)
- Official URL: https://nav.gov.hu/pfile/file?path=/ugyfeliranytu/nezzen-utana/inf_fuz/2026/24.-Bevallasi-adofizetesi-informaciok-2026.01.26
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `meghaladja az 50 000 eurónak megfelelő pénzösszeget`

## HU096 — Quick reference: EU transactions (NAV booklet 29, published 26 January 2026)

EU-wide threshold for distance sales of goods and telecom, broadcasting and electronic services to consumers in other EU states; above it VAT is due in the customer's state = EUR 10,000

- Act/article: NAV EU transactions (NAV booklet 29, published 26 January 2026)
- Official URL: https://nav.gov.hu/pfile/file?path=/ugyfeliranytu/nezzen-utana/inf_fuz/2026/29_Az_altalanos_szabalyok_szerint_adozo_afaalanyok_kozossegi_ugyletei_2026.01.26
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `túllépi a 10 000 euró küszöbértéket, vagyis a 3 100 000 forintot`

## HU097 — Quick reference: EU transactions (NAV booklet 29, published 26 January 2026)

Invoice wording where the customer pays the VAT = "fordított adózás"

- Act/article: NAV EU transactions (NAV booklet 29, published 26 January 2026)
- Official URL: https://nav.gov.hu/pfile/file?path=/ugyfeliranytu/nezzen-utana/inf_fuz/2026/29_Az_altalanos_szabalyok_szerint_adozo_afaalanyok_kozossegi_ugyletei_2026.01.26
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `fordított adózás`
  - `a számlán a „fordított adózás” kifejezést kell szerepeltetni`

## HU098 — Quick reference: Form 2665 rows and refund deadline (2665 form guide)

01 = Exempt export of goods outside the EU

- Act/article: NAV Form 2665 rows and refund deadline (2665 form guide)
- Official URL: https://nav.gov.hu/pfile/file?path=%2Fnyomtatvanyok%2Fletoltesek%2Fnyomtatvanykitolto_programok%2Fnyomtatvanykitolto_programok_nav%2F2665%2F2665-kitoltesi-utmutato
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `a Közösség területén kívülre történő mentes termékértékesítés (export)`

## HU099 — Quick reference: Form 2665 rows and refund deadline (2665 form guide)

02 = Exempt intra-EU supply of goods

- Act/article: NAV Form 2665 rows and refund deadline (2665 form guide)
- Official URL: https://nav.gov.hu/pfile/file?path=%2Fnyomtatvanyok%2Fletoltesek%2Fnyomtatvanykitolto_programok%2Fnyomtatvanykitolto_programok_nav%2F2665%2F2665-kitoltesi-utmutato
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `mentes termékértékesítés adó nélkül számított ellenértékét`

## HU100 — Quick reference: Form 2665 rows and refund deadline (2665 form guide)

04 = Domestic sales where the buyer pays the VAT (reverse charge), net amount

- Act/article: NAV Form 2665 rows and refund deadline (2665 form guide)
- Official URL: https://nav.gov.hu/pfile/file?path=%2Fnyomtatvanyok%2Fletoltesek%2Fnyomtatvanykitolto_programok%2Fnyomtatvanykitolto_programok_nav%2F2665%2F2665-kitoltesi-utmutato
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `a fordított adózás szabályai szerint az adó fizetésére a termék beszerzője`

## HU101 — Quick reference: Form 2665 rows and refund deadline (2665 form guide)

110 = Domestic sales at 0%

- Act/article: NAV Form 2665 rows and refund deadline (2665 form guide)
- Official URL: https://nav.gov.hu/pfile/file?path=%2Fnyomtatvanyok%2Fletoltesek%2Fnyomtatvanykitolto_programok%2Fnyomtatvanykitolto_programok_nav%2F2665%2F2665-kitoltesi-utmutato
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `a 0%-os kulcs alá tartozó termékértékesítések ellenértékét`

## HU102 — Quick reference: Form 2665 rows and refund deadline (2665 form guide)

05 = Domestic sales at 5%, base and VAT

- Act/article: NAV Form 2665 rows and refund deadline (2665 form guide)
- Official URL: https://nav.gov.hu/pfile/file?path=%2Fnyomtatvanyok%2Fletoltesek%2Fnyomtatvanykitolto_programok%2Fnyomtatvanykitolto_programok_nav%2F2665%2F2665-kitoltesi-utmutato
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `az 5%-os kulcs alá tartozó termékértékesítések és szolgáltatásnyújtások`

## HU103 — Quick reference: Form 2665 rows and refund deadline (2665 form guide)

06 = Domestic sales at 18%, base and VAT

- Act/article: NAV Form 2665 rows and refund deadline (2665 form guide)
- Official URL: https://nav.gov.hu/pfile/file?path=%2Fnyomtatvanyok%2Fletoltesek%2Fnyomtatvanykitolto_programok%2Fnyomtatvanykitolto_programok_nav%2F2665%2F2665-kitoltesi-utmutato
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `a belföldi teljesítési helyű 18%-os adómértékű termékek`

## HU104 — Quick reference: Form 2665 rows and refund deadline (2665 form guide)

07 = Domestic sales at 27%, base and VAT

- Act/article: NAV Form 2665 rows and refund deadline (2665 form guide)
- Official URL: https://nav.gov.hu/pfile/file?path=%2Fnyomtatvanyok%2Fletoltesek%2Fnyomtatvanykitolto_programok%2Fnyomtatvanykitolto_programok_nav%2F2665%2F2665-kitoltesi-utmutato
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `A 27%-os kulcs alá tartozó értékesítés után`

## HU105 — Quick reference: Form 2665 rows and refund deadline (2665 form guide)

08 = Exempt supplies without the right to deduct (Áfa tv. §§ 85 to 87)

- Act/article: NAV Form 2665 rows and refund deadline (2665 form guide)
- Official URL: https://nav.gov.hu/pfile/file?path=%2Fnyomtatvanyok%2Fletoltesek%2Fnyomtatvanykitolto_programok%2Fnyomtatvanykitolto_programok_nav%2F2665%2F2665-kitoltesi-utmutato
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `a tevékenység közérdekű jellegére tekintettel mentes szolgáltatások`

## HU106 — Quick reference: Form 2665 rows and refund deadline (2665 form guide)

12 to 14 = Taxable intra-EU acquisitions of goods, on the row for the rate

- Act/article: NAV Form 2665 rows and refund deadline (2665 form guide)
- Official URL: https://nav.gov.hu/pfile/file?path=%2Fnyomtatvanyok%2Fletoltesek%2Fnyomtatvanykitolto_programok%2Fnyomtatvanykitolto_programok_nav%2F2665%2F2665-kitoltesi-utmutato
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `(az adómértéknek megfelelő sorban)`

## HU107 — Quick reference: Form 2665 rows and refund deadline (2665 form guide)

18 = Services from a taxable person in another EU state, taxable in Hungary under § 37(1)

- Act/article: NAV Form 2665 rows and refund deadline (2665 form guide)
- Official URL: https://nav.gov.hu/pfile/file?path=%2Fnyomtatvanyok%2Fletoltesek%2Fnyomtatvanykitolto_programok%2Fnyomtatvanykitolto_programok_nav%2F2665%2F2665-kitoltesi-utmutato
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `a szolgáltatás nyújtója olyan, a Közösség más tagállamában adószámmal rendelkező adóalany`

## HU108 — Quick reference: Form 2665 rows and refund deadline (2665 form guide)

19 = Other EU services taxable in Hungary, not on row 18

- Act/article: NAV Form 2665 rows and refund deadline (2665 form guide)
- Official URL: https://nav.gov.hu/pfile/file?path=%2Fnyomtatvanyok%2Fletoltesek%2Fnyomtatvanykitolto_programok%2Fnyomtatvanykitolto_programok_nav%2F2665%2F2665-kitoltesi-utmutato
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `a 18. sorban nem szereplő egyéb, közösségi adóalanytól igénybevett szolgáltatás`

## HU109 — Quick reference: Form 2665 rows and refund deadline (2665 form guide)

27 = Services from a non-EU taxable person, base and VAT

- Act/article: NAV Form 2665 rows and refund deadline (2665 form guide)
- Official URL: https://nav.gov.hu/pfile/file?path=%2Fnyomtatvanyok%2Fletoltesek%2Fnyomtatvanykitolto_programok%2Fnyomtatvanykitolto_programok_nav%2F2665%2F2665-kitoltesi-utmutato
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `a harmadik országbeli adóalanytól igénybe vett szolgáltatás ellenértékét`

## HU110 — Quick reference: Form 2665 rows and refund deadline (2665 form guide)

29 = Domestic reverse-charge VAT the buyer pays; detail on rows 51 to 54 (real estate, waste, emission rights, services)

- Act/article: NAV Form 2665 rows and refund deadline (2665 form guide)
- Official URL: https://nav.gov.hu/pfile/file?path=%2Fnyomtatvanyok%2Fletoltesek%2Fnyomtatvanykitolto_programok%2Fnyomtatvanykitolto_programok_nav%2F2665%2F2665-kitoltesi-utmutato
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `a fordított adózás szabályai szerint – adófizetésre kötelezett vevőként`

## HU111 — Quick reference: Form 2665 rows and refund deadline (2665 form guide)

36 = Total output VAT: rows 01 to 35 and 110

- Act/article: NAV Form 2665 rows and refund deadline (2665 form guide)
- Official URL: https://nav.gov.hu/pfile/file?path=%2Fnyomtatvanyok%2Fletoltesek%2Fnyomtatvanykitolto_programok%2Fnyomtatvanykitolto_programok_nav%2F2665%2F2665-kitoltesi-utmutato
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `a 01-35. és 110. sorokban található részösszegeket`

## HU112 — Quick reference: Form 2665 rows and refund deadline (2665 form guide)

64 = Deductible domestic input VAT at 5%

- Act/article: NAV Form 2665 rows and refund deadline (2665 form guide)
- Official URL: https://nav.gov.hu/pfile/file?path=%2Fnyomtatvanyok%2Fletoltesek%2Fnyomtatvanykitolto_programok%2Fnyomtatvanykitolto_programok_nav%2F2665%2F2665-kitoltesi-utmutato
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `terhelő 5%-os mértékű előzetesen felszámított adót`

## HU113 — Quick reference: Form 2665 rows and refund deadline (2665 form guide)

65 = Deductible domestic input VAT at 18%

- Act/article: NAV Form 2665 rows and refund deadline (2665 form guide)
- Official URL: https://nav.gov.hu/pfile/file?path=%2Fnyomtatvanyok%2Fletoltesek%2Fnyomtatvanykitolto_programok%2Fnyomtatvanykitolto_programok_nav%2F2665%2F2665-kitoltesi-utmutato
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `terhelő 18%-os mértékű előzetesen felszámított adót`

## HU114 — Quick reference: Form 2665 rows and refund deadline (2665 form guide)

66 = Deductible domestic input VAT at 27%

- Act/article: NAV Form 2665 rows and refund deadline (2665 form guide)
- Official URL: https://nav.gov.hu/pfile/file?path=%2Fnyomtatvanyok%2Fletoltesek%2Fnyomtatvanykitolto_programok%2Fnyomtatvanykitolto_programok_nav%2F2665%2F2665-kitoltesi-utmutato
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `terhelő 27%-os mértékű előzetesen felszámított adót`

## HU115 — Quick reference: Form 2665 rows and refund deadline (2665 form guide)

67 = Deductible VAT on services entered on rows 18, 19 and 27

- Act/article: NAV Form 2665 rows and refund deadline (2665 form guide)
- Official URL: https://nav.gov.hu/pfile/file?path=%2Fnyomtatvanyok%2Fletoltesek%2Fnyomtatvanykitolto_programok%2Fnyomtatvanykitolto_programok_nav%2F2665%2F2665-kitoltesi-utmutato
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `(a 18., a 19. és a 27. sorban feltüntetett)`

## HU116 — Quick reference: Form 2665 rows and refund deadline (2665 form guide)

68 = Apportioned input VAT (mixed taxable and exempt activity)

- Act/article: NAV Form 2665 rows and refund deadline (2665 form guide)
- Official URL: https://nav.gov.hu/pfile/file?path=%2Fnyomtatvanyok%2Fletoltesek%2Fnyomtatvanykitolto_programok%2Fnyomtatvanykitolto_programok_nav%2F2665%2F2665-kitoltesi-utmutato
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `akkor az arányosítás szabályai`

## HU117 — Quick reference: Form 2665 rows and refund deadline (2665 form guide)

69 = Deductible VAT on intra-EU acquisitions from rows 12 to 16 and 112

- Act/article: NAV Form 2665 rows and refund deadline (2665 form guide)
- Official URL: https://nav.gov.hu/pfile/file?path=%2Fnyomtatvanyok%2Fletoltesek%2Fnyomtatvanykitolto_programok%2Fnyomtatvanykitolto_programok_nav%2F2665%2F2665-kitoltesi-utmutato
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `fizetendőként a bevallás 12-16. és 112. soraiban feltüntetett`

## HU118 — Quick reference: Form 2665 rows and refund deadline (2665 form guide)

76 = Total deductible input VAT: rows 63 to 75 and 111

- Act/article: NAV Form 2665 rows and refund deadline (2665 form guide)
- Official URL: https://nav.gov.hu/pfile/file?path=%2Fnyomtatvanyok%2Fletoltesek%2Fnyomtatvanykitolto_programok%2Fnyomtatvanykitolto_programok_nav%2F2665%2F2665-kitoltesi-utmutato
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `63-75. és 111. sorokban feltüntetett együttes`

## HU119 — Quick reference: Form 2665 rows and refund deadline (2665 form guide)

82 = Credit brought forward from the previous period

- Act/article: NAV Form 2665 rows and refund deadline (2665 form guide)
- Official URL: https://nav.gov.hu/pfile/file?path=%2Fnyomtatvanyok%2Fletoltesek%2Fnyomtatvanykitolto_programok%2Fnyomtatvanykitolto_programok_nav%2F2665%2F2665-kitoltesi-utmutato
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `az előző adómegállapítási időszakról áthozott`

## HU120 — Quick reference: Form 2665 rows and refund deadline (2665 form guide)

83 = Balance: row 36 less row 76 less row 82

- Act/article: NAV Form 2665 rows and refund deadline (2665 form guide)
- Official URL: https://nav.gov.hu/pfile/file?path=%2Fnyomtatvanyok%2Fletoltesek%2Fnyomtatvanykitolto_programok%2Fnyomtatvanykitolto_programok_nav%2F2665%2F2665-kitoltesi-utmutato
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `az összes fizetendő adó (36. sor) összege csökkentve`

## HU121 — Quick reference: Form 2665 rows and refund deadline (2665 form guide)

84 = Payable (row 83 positive), without sign

- Act/article: NAV Form 2665 rows and refund deadline (2665 form guide)
- Official URL: https://nav.gov.hu/pfile/file?path=%2Fnyomtatvanyok%2Fletoltesek%2Fnyomtatvanykitolto_programok%2Fnyomtatvanykitolto_programok_nav%2F2665%2F2665-kitoltesi-utmutato
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `ha a tárgyidőszakban a 83. sor adata előjel nélküli`

## HU122 — Quick reference: Form 2665 rows and refund deadline (2665 form guide)

85 = Refund claimed (row 83 negative and a refund right exists)

- Act/article: NAV Form 2665 rows and refund deadline (2665 form guide)
- Official URL: https://nav.gov.hu/pfile/file?path=%2Fnyomtatvanyok%2Fletoltesek%2Fnyomtatvanykitolto_programok%2Fnyomtatvanykitolto_programok_nav%2F2665%2F2665-kitoltesi-utmutato
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `ha a tárgyidőszakban a 83. sor adata mínusz előjelű`

## HU123 — Quick reference: Form 2665 rows and refund deadline (2665 form guide)

86 = Credit carried forward to row 82 of the next return

- Act/article: NAV Form 2665 rows and refund deadline (2665 form guide)
- Official URL: https://nav.gov.hu/pfile/file?path=%2Fnyomtatvanyok%2Fletoltesek%2Fnyomtatvanykitolto_programok%2Fnyomtatvanykitolto_programok_nav%2F2665%2F2665-kitoltesi-utmutato
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `a következő bevallási időszakban csökkentő tételként a 82. sorban`

## HU124 — Quick reference: Form 2665 rows and refund deadline (2665 form guide)

92 = EU B2B services under the general place-of-supply rule (ties to form 26A60)

- Act/article: NAV Form 2665 rows and refund deadline (2665 form guide)
- Official URL: https://nav.gov.hu/pfile/file?path=%2Fnyomtatvanyok%2Fletoltesek%2Fnyomtatvanykitolto_programok%2Fnyomtatvanykitolto_programok_nav%2F2665%2F2665-kitoltesi-utmutato
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `„határon átnyúló, Közösségen belüli szolgáltatások” ellenértékét (ideértve az előleget is)`

## HU125 — Quick reference: Form 2665 rows and refund deadline (2665 form guide)

93 = EU B2B services whose place of supply is outside Hungary under a rule other than § 37(1); not on the EU sales list

- Act/article: NAV Form 2665 rows and refund deadline (2665 form guide)
- Official URL: https://nav.gov.hu/pfile/file?path=%2Fnyomtatvanyok%2Fletoltesek%2Fnyomtatvanykitolto_programok%2Fnyomtatvanykitolto_programok_nav%2F2665%2F2665-kitoltesi-utmutato
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `A 93. sorba kell beírni a „határon átnyúló, Közösségen belüli szolgáltatások” ellenértékét, amely esetben`

## HU126 — Quick reference: Form 2665 rows and refund deadline (2665 form guide)

M-02 = Every received domestic invoice under normal taxation with deducted VAT, no value threshold

- Act/article: NAV Form 2665 rows and refund deadline (2665 form guide)
- Official URL: https://nav.gov.hu/pfile/file?path=%2Fnyomtatvanyok%2Fletoltesek%2Fnyomtatvanykitolto_programok%2Fnyomtatvanykitolto_programok_nav%2F2665%2F2665-kitoltesi-utmutato
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `értékhatártól függetlenül minden olyan befogadott, egyenes adózás alá tartozó számláról`

## HU127 — Quick reference: Form 2665 rows and refund deadline (2665 form guide)

64 to 68 = Filling the rate-by-rate columns for VAT actually deducted is optional

- Act/article: NAV Form 2665 rows and refund deadline (2665 form guide)
- Official URL: https://nav.gov.hu/pfile/file?path=%2Fnyomtatvanyok%2Fletoltesek%2Fnyomtatvanykitolto_programok%2Fnyomtatvanykitolto_programok_nav%2F2665%2F2665-kitoltesi-utmutato
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `adómértékenként (5 %, 18 %, 27 %, arányosítás) elkülönített rovatok kitöltése önkéntes`

## HU128 — Quick reference: Form 2665 rows and refund deadline (2665 form guide)

Refund = General refund payment deadline

- Act/article: NAV Form 2665 rows and refund deadline (2665 form guide)
- Official URL: https://nav.gov.hu/pfile/file?path=%2Fnyomtatvanyok%2Fletoltesek%2Fnyomtatvanykitolto_programok%2Fnyomtatvanykitolto_programok_nav%2F2665%2F2665-kitoltesi-utmutato
- Read: 2026-10-05; Unchanged exact figure/form quote from preserved reviewed packet; latestzero-rate scope supplemented separately
- Cached locator: prior reviewed source packet
- Exact native anchor(s):
  - `A visszaigényelt általános forgalmi adót 75 napon belül kell kiutalni`

## HU129 — Method/dependencies: exemption-test

Subjective exemption for 2026: domestic supplies did not exceed the limit in 2025 actually AND are neither reasonably expected to nor actually exceed it in 2026 (both conditions).

- Act/article: 'Ki választhatja 2026-ra?' paragraph: 'sem a 2025. naptári évben ténylegesen, sem a 2026. naptári évben észszerűen várhatóan, illetve ténylegesen nem haladja meg a 20 millió forintot'
- Official URL: https://nav.gov.hu/ado/afa/Emelkedik_az_alanyi_adomentesseg_ertekhatara
- Read: 2026-10-05; Unchanged independent review quality-evidence exact claim/locator reused; individual figure/form anchors above provide detailed row proof
- Cached locator: prior-review/quality-evidence.json;packet/sources
- Exact native anchor(s):
  - `Ki választhatja 2026-ra?`
  - `sem a 2025. naptári évben ténylegesen, sem a 2026. naptári évben észszerűen várhatóan, illetve ténylegesen nem haladja meg a 20 millió forintot`

## HU130 — Method/dependencies: exemption-notice

Choice for 2026 notified by 31 December 2025; a business already exempt on 31 December 2025 that stays eligible need not act.

- Act/article: 'Hogyan kell bejelenteni?' and 'Aki már alanyi adómentes' paragraphs
- Official URL: https://nav.gov.hu/ado/afa/Emelkedik_az_alanyi_adomentesseg_ertekhatara
- Read: 2026-10-05; Unchanged independent review quality-evidence exact claim/locator reused; individual figure/form anchors above provide detailed row proof
- Cached locator: prior-review/quality-evidence.json;packet/sources
- Exact native anchor(s):
  - `sség 2026-ra akkor is választható, [3] ha az adóalany 2024-ben átlépte az alanyi adómentesség abban az évben érvényes, 12 millió forintos értékhatárát,és akkor is, ha 2025. évben átlépte a 18 millió forintos értékhatárt. [4] Hogyan kell bejelenteni? A 2026-ra választott alanyi adómentességet 2025. december 31-éig kell bejelenteni a Nemzeti Adó- és Vámhivatalhoz [5] az Online Nyomtatványkitöltő Alkalmazásban (ONYA), vagy az Általános Nyomtatványkitöltő Keretprogramban (ÁNYK) – a vállalkozási formának megfelelően – a 25T101, 25T101E, 25T201, 25T201T, 25T201CSZ, 25T201TSZ nyomtatványok F lapján. Aki már alanyi adómentes Nincs teendője annak, aki 2025. december 31-én alanyi adómentes, 2026-ban is az kíván maradni, és a feltételeknek megfelel. Nemzeti Adó- és Vámhivatal [1] Az általános forgalmi adóról szóló 2007. évi CXXVII. törvény (a továbbiakban: Áfa tv.) 188. § (2) bekezdés 2026. január 1-jétől. [2] Áfa tv. 2025. november 22-étől hatályos 377. § (1) bekezdése. [3] Áfa tv. 2025. november 22-étől hatályos 377. § (2) bekezdése. [4] Nem kell alkalmazni tehát az Áfa tv. 191. § (3) és 195/K. § (6) bekezdéseit, miszerint, ha az alanyi adómentesség azért szűnt meg, mert a tárgy naptári évben a tényadatok alapján az adóalany bevétele ténylegesen meghaladta az alanyi adómentesség választásának feltételeként meghatározott összeget, az adóalany az alanyi adómentesség választására vonatkozó joggal a megszűnés évét követő második naptári év végéig nem élhet. [5] Áfa tv. 192. § (2) bekezdése. Adó 2025.12.11. Hozzáadás a kedvencekhez, regisztráció és bejelentkezés után. Hozzáadás a myNAV-hoz Kapcsolatfelvétel További honlapok Adatvédelmi tájékoztató Impresszum Közadatkereső Oldaltérkép Integritás, korrupció Akadálymentesítési nyilatkozatok Elérhetőségek Cím: 1054 Budapest, Széchenyi utca 2. Telefon: +36 (1) 428 51 00 A honlapon szerep`

## HU131 — Method/dependencies: exempt-occasional

Subjectively exempt businesses file only occasional returns (when a tax liability, an EU transaction needing an EU sales list, or a deduction arises).

- Act/article: Section 5, 'Havi bevallás' list: 'csak akkor van „alkalmi” áfabevallási kötelezettsége'
- Official URL: https://nav.gov.hu/pfile/file?path=/ugyfeliranytu/nezzen-utana/inf_fuz/2026/14.-Hasznos-tudnivalok-kezdo-afaalanyoknak-2025.-02.-03
- Read: 2026-10-05; Unchanged independent review quality-evidence exact claim/locator reused; individual figure/form anchors above provide detailed row proof
- Cached locator: prior-review/quality-evidence.json;packet/sources
- Exact native anchor(s):
  - `Havi bevallás`
  - `csak akkor van „alkalmi” áfabevallási kötelezettsége`

## HU132 — Method/dependencies: freq-ref-year

2026 frequency is set from data of the second year before (2024).

- Act/article: Section 3.1: 'a tárgyévet megelőző második év adatai határozzák meg'; table 'a 2024. évre vonatkozóan'
- Official URL: https://nav.gov.hu/pfile/file?path=/ugyfeliranytu/nezzen-utana/inf_fuz/2026/24.-Bevallasi-adofizetesi-informaciok-2026.01.26
- Read: 2026-10-05; Unchanged independent review quality-evidence exact claim/locator reused; individual figure/form anchors above provide detailed row proof
- Cached locator: prior-review/quality-evidence.json;packet/sources
- Exact native anchor(s):
  - `a tárgyévet megelőző második év adatai határozzák meg`
  - `a 2024. évre vonatkozóan`

## HU133 — Method/dependencies: freq-monthly-new

Businesses formed without a legal predecessor file monthly in the registration year and the following year; VAT groups file monthly.

- Act/article: Section 5 'Havi bevallás' bullets
- Official URL: https://nav.gov.hu/pfile/file?path=/ugyfeliranytu/nezzen-utana/inf_fuz/2026/14.-Hasznos-tudnivalok-kezdo-afaalanyoknak-2025.-02.-03
- Read: 2026-10-05; Unchanged independent review quality-evidence exact claim/locator reused; individual figure/form anchors above provide detailed row proof
- Cached locator: prior-review/quality-evidence.json;packet/sources
- Exact native anchor(s):
  - `izárólag az adómentes termékimportot megalapozó közösségi adómentes értékesítés miatt adóalannyá váló adózónak, valamint • az adóalanynak a bejelentkezés évének, valamint az azt követő évnek az általános forgalmi adó kötelezettségéről, feltéve, hogy jogelőd nélkül alakult. Havi gyakorisággal köteles áfabevallást benyújtani az említetteken túl • a speciális adózói körbe tartozó, alanyi adómentességet választó, • a kizárólag közérdekű vagy egyéb speciális jellege miatt adómentes tevékenységet végző és • a mezőgazdasági tevékenységet folytató, különös jogállású adóalany. E speciális adózói körbe tartozó adóalanynak csak akkor van „alkalmi” áfabevallási kötelezettsége, ha • az adott hónapban volt áfabevallást eredményező ügylete: adófizetési kötelezettsége keletkezett, • olyan közösségi ügylete volt, ami miatt összesítő nyilatkozatot kell benyújtania, vagy • levonási jogot kíván gyakorolni.101 Éves bevallás 98 Art. 2. számú melléklet I. B) 3. pont. 99 Áfa tv. 96. §. 100 Áfa tv. 89/A. §. 101 Áfa tv. 257. §. 28 Évente kell adóbevallást benyújtania az adó fizetésére kötelezett adóalanynak, ha • a tárgyévet megelőző második évben az elszámolandó adójának éves szinten összesített – vagy annak időarányosan éves szintre átszámított – összege előjelétől függetlenül nem érte el a 250 ezer forintot, és • az Áfa tv. szerinti termékértékesítése, szolgáltatásnyújtása ellenértékének adó nélküli, éves szinten összesített összege nem haladja meg `

## HU134 — Method/dependencies: freq-annual-and

Annual filing requires all three conditions: VAT below threshold whatever sign, AND net supplies not above cap, AND no EU VAT number.

- Act/article: Section 5 'Éves bevallás' bullets joined by 'és'
- Official URL: https://nav.gov.hu/pfile/file?path=/ugyfeliranytu/nezzen-utana/inf_fuz/2026/14.-Hasznos-tudnivalok-kezdo-afaalanyoknak-2025.-02.-03
- Read: 2026-10-05; Unchanged independent review quality-evidence exact claim/locator reused; individual figure/form anchors above provide detailed row proof
- Cached locator: prior-review/quality-evidence.json;packet/sources
- Exact native anchor(s):
  - `lási kötelezettsége, ha • az adott hónapban volt áfabevallást eredményező ügylete: adófizetési kötelezettsége keletkezett, • olyan közösségi ügylete volt, ami miatt összesítő nyilatkozatot kell benyújtania, vagy • levonási jogot kíván gyakorolni.101 Éves bevallás 98 Art. 2. számú melléklet I. B) 3. pont. 99 Áfa tv. 96. §. 100 Áfa tv. 89/A. §. 101 Áfa tv. 257. §. 28 Évente kell adóbevallást benyújtania az adó fizetésére kötelezett adóalanynak, ha • a tárgyévet megelőző második évben az elszámolandó adójának éves szinten összesített – vagy annak időarányosan éves szintre átszámított – összege előjelétől függetlenül nem érte el a 250 ezer forintot, és • az Áfa tv. szerinti termékértékesítése, szolgáltatásnyújtása ellenértékének adó nélküli, éves szinten összesített összege nem haladja meg az 50 millió forintot, és • nem rendelkezik közösségi adószámmal. Negyedéves bevallás Negyedéves bevallási gyakoriság például az éves gyakorisági értékhatárok átlépése, közösségi adószám kiváltása miatt állhat fenn. A bevallási gyakoriság az értékhatárok átlépésével változhat, erre figyelemmel kell lenni. 102 Bevallást attól függetlenül be kell nyújtani, hogy az elszámolandó adó összege pozitív vagy negatív előjelű vagy esetleg nulla. X. Az online számlaadat-szolgáltatási kötelezettség (belföldi összesítő jelentés)103 Az értékesítő adóalanyt, mint számlakibocsátót, online számlaadat-szolgáltatási kötelezettség terheli, amit • nyomtatvány használatával kibocsátott számlákról – a NAV erre a célja biztosított elektronikus felületén – 4 napon belü`

## HU135 — Method/dependencies: freq-quarterly-eu

Quarterly is the residual; holders of an EU VAT number who would otherwise be annual file quarterly.

- Act/article: Section 3.1 table, quarterly row: 'sem a havonkénti, sem az évenkénti ... negyedévente'; 'közösségi adószámmal rendelkeznek szintén'
- Official URL: https://nav.gov.hu/pfile/file?path=/ugyfeliranytu/nezzen-utana/inf_fuz/2026/24.-Bevallasi-adofizetesi-informaciok-2026.01.26
- Read: 2026-10-05; Unchanged independent review quality-evidence exact claim/locator reused; individual figure/form anchors above provide detailed row proof
- Cached locator: prior-review/quality-evidence.json;packet/sources
- Exact native anchor(s):
  - `közösségi adószámmal rendelkeznek szintén`

## HU136 — Method/dependencies: freq-midyear

Mid-year: a quarterly filer moves to monthly when VAT since 1 January, sign-correct and annualised, is positive and reaches HUF 1 million; an annual filer moves to monthly when the same difference, sign-correct, is positive and reaches HUF 1 million; an annual filer moves to quarterly when the sign-correct cumulated VAT difference reaches HUF 250 thousand, or net supplies exceed HUF 50 million, or an EU VAT number is assigned.

- Act/article: Part I, frequency section: 'Havi áfabevallásra köteles áttérni ...' and 'Az éves bevallásról negyedéves bevallásra kell áttérnie ...', with 'az év elejétől – előjelhelyesen – összesített fizetendő és levonható előzetesen felszámított adó különbözete a 250 ezer forintot elérte'; booklet 24 prints the same test as 'a +/- 250 ezer forintot elérte' (read as plus or minus), https://nav.gov.hu/pfile/file?path=/ugyfeliranytu/nezzen-utana/inf_fuz/2026/24.-Bevallasi-adofizetesi-informaciok-2026.01.26
- Official URL: https://nav.gov.hu/pfile/file?path=%2Fnyomtatvanyok%2Fletoltesek%2Fnyomtatvanykitolto_programok%2Fnyomtatvanykitolto_programok_nav%2F2665%2F2665-kitoltesi-utmutato
- Read: 2026-10-05; Unchanged independent review quality-evidence exact claim/locator reused; individual figure/form anchors above provide detailed row proof
- Cached locator: prior-review/quality-evidence.json;packet/sources
- Exact native anchor(s):
  - `az év elejétől – előjelhelyesen – összesített fizetendő és levonható előzetesen felszámított adó különbözete a 250 ezer forintot elérte`

## HU137 — Method/dependencies: eafa-draft

Returns may be filed by approving the eÁfa draft (web or M2M) or on the form via ÁNYK.

- Act/article: Part I.3 'Hogyan lehet benyújtani a bevallást?'
- Official URL: https://njt.jog.gov.hu/jogszabaly/2007-127-00-00
- Read: 2026-10-05; Unchanged independent review quality-evidence exact claim/locator reused; individual figure/form anchors above provide detailed row proof
- Cached locator: prior-review/quality-evidence.json;packet/sources
- Exact native anchor(s):
  - `a) Az adóalany az Art. szerinti nyomtatványt nyújt be.`
  - `b) Az adóalany az állami adó- és vámhatóság által az adó megállapításához az erre a célra biztosított elektronikus felületen rendelkezésére bocsátott adatokat kiegészíti, módosítja, az adólevonási jogáról és annak gyakorlásáról nyilatkozik, és az így előállított adónyilvántartásból összeállított bevallástervezetet ugyanezen a felületen bevallásként jóváhagyja.`
  - `c) Az adóalany az állami adó- és vámhatóság által közzétett módon és adatszerkezetben gépi interfész alkalmazásával továbbítja a fizetendő adó megállapításának és az adólevonási jog gyakorlásának alapjául szolgáló bizonylat szintű adatokat és az ezen adónyilvántartásból összeállított bevallástervezetet bevallásként gépi úton jóváhagyja.`
  - `(3) A (2) bekezdés b) vagy c) pont ja szerinti bevallástervezet jóváhagyása a bevallás benyújtásának minősül.`

## HU138 — Method/dependencies: form-2665

The 2026 VAT return is form 2665; 2665A are its main sheets; 2665M the domestic summary report sheets.

- Act/article: Part I.9 'Milyen részei vannak a bevallásnak?'
- Official URL: https://nav.gov.hu/pfile/file?path=%2Fnyomtatvanyok%2Fletoltesek%2Fnyomtatvanykitolto_programok%2Fnyomtatvanykitolto_programok_nav%2F2665%2F2665-kitoltesi-utmutato
- Read: 2026-10-05; Unchanged independent review quality-evidence exact claim/locator reused; individual figure/form anchors above provide detailed row proof
- Cached locator: prior-review/quality-evidence.json;packet/sources
- Exact native anchor(s):
  - `l (gov.hu) oldalon tájékozódhat. 8. Mik a jogkövetkezmények? Ha az adózó a bevallási, adatszolgáltatási kötelezettségét hibásan, hiányos adattartalommal, késve teljesíti, vagy azt elmulasztja, a NAV a törvényben meghatározott szankcióval élhet16. 9. Milyen részei vannak a bevallásnak? 16 Art. 150-162. §, 220-221. § és 237-238. §. 9 • A bevallási főgarnitúra részei: főlap, 2665A lapjai: -01-01, 01-02, 01-03, 01-04, 01-05 lapok; • 2665A-170 számú lap: Átvezetési és kiutalási kérelem a pénzforgalmat lebonyolító bizonylatokhoz; • 2665A-02 számú lap: Állatbetegséggel összefüggő járványügyi intézkedés miatti kártalanítás okán fizetési halasztás kérése; • 2665A-03 számú lap: Közvetett vámjogi képviselő importonkénti nyilatkozata engedményezett adólevonási jog érvényesítése esetén • 2665A-04 számú lap: Önellenőrzési melléklet a 2026. évi adómegállapítási időszakok bevallásainak önellenőrzésére; • 2665A-06 számú lap: A behajthatatlan követelés elszámolásával összefüggő nyilatkozatok; • 2665A-07 számú lap: Az Áfa tv. 6/A., 6/B. és a 6/C. számú mellékletei szerint a fordított adózás keretében történt értékesítésre vonatkozó nyilatkozat; • 2665A-08 számú lap: Az Áfa tv. 6/A., 6/B. és a 6/C. számú mellékletei szerint a fordított adózás keretében történt beszerzésre vonatkozó nyilatkozat; • 2665A-09 számú lap: Az Áfa tv. 4/A. számú melléklet II. pont szerinti adatszolgáltatás a személygépkocsi alvázszámáról • 2665A-A88 számú lap: Adatszolgáltatás új közlekedési eszköz értékesítéséről; • 2665M számú főlap: Összesítő jelentés kereskedelmi partnerenként a belföldi, egyenes adózás alá tartozó forgalom számlánként részletezett tételeiről; • `

## HU139 — Method/dependencies: rows-output

Row mapping for outputs: 01 export, 02 intra-EU goods, 04 domestic reverse charge sales, 05/06/07 domestic 5/18/27, 08 exempt, 110 0%, 36 total.

- Act/article: Part II rows 01, 02, 04, 05, 06, 07, 08, 110, 36
- Official URL: https://nav.gov.hu/pfile/file?path=%2Fnyomtatvanyok%2Fletoltesek%2Fnyomtatvanykitolto_programok%2Fnyomtatvanykitolto_programok_nav%2F2665%2F2665-kitoltesi-utmutato
- Read: 2026-10-05; Unchanged independent review quality-evidence exact claim/locator reused; individual figure/form anchors above provide detailed row proof
- Cached locator: prior-review/quality-evidence.json;packet/sources
- Exact native anchor(s):
  - `01 = Exempt export of goods outside the EU: a Közösség területén kívülre történő mentes termékértékesítés (export)`
  - `02 = Exempt intra-EU supply of goods: mentes termékértékesítés adó nélkül számított ellenértékét`
  - `04 = Domestic sales where the buyer pays the VAT (reverse charge), net amount: a fordított adózás szabályai szerint az adó fizetésére a termék beszerzője`
  - `110 = Domestic sales at 0%: a 0%-os kulcs alá tartozó termékértékesítések ellenértékét`
  - `05 = Domestic sales at 5%, base and VAT: az 5%-os kulcs alá tartozó termékértékesítések és szolgáltatásnyújtások`
  - `06 = Domestic sales at 18%, base and VAT: a belföldi teljesítési helyű 18%-os adómértékű termékek`
  - `07 = Domestic sales at 27%, base and VAT: A 27%-os kulcs alá tartozó értékesítés után`
  - `08 = Exempt supplies without the right to deduct (Áfa tv. §§ 85 to 87): a tevékenység közérdekű jellegére tekintettel mentes szolgáltatások`
  - `36 = Total output VAT: rows 01 to 35 and 110: a 01-35. és 110. sorokban található részösszegeket`

## HU140 — Method/dependencies: rows-rc

Reverse charge rows: 12-14 EU goods by rate, 18 EU services under 37(1), 19 other EU services, 27 non-EU services, 29 domestic RC with 51-54 detail; deductions 67 (services 18/19/27), 69 (EU goods 12-16, 112), domestic RC deduction in 64-66 sub-field.

- Act/article: Part II rows 12-14, 18, 19, 27, 29, 51-54, 64, 67, 69
- Official URL: https://nav.gov.hu/pfile/file?path=%2Fnyomtatvanyok%2Fletoltesek%2Fnyomtatvanykitolto_programok%2Fnyomtatvanykitolto_programok_nav%2F2665%2F2665-kitoltesi-utmutato
- Read: 2026-10-05; Unchanged independent review quality-evidence exact claim/locator reused; individual figure/form anchors above provide detailed row proof
- Cached locator: prior-review/quality-evidence.json;packet/sources
- Exact native anchor(s):
  - `12 to 14 = Taxable intra-EU acquisitions of goods, on the row for the rate: (az adómértéknek megfelelő sorban)`
  - `18 = Services from a taxable person in another EU state, taxable in Hungary under § 37(1): a szolgáltatás nyújtója olyan, a Közösség más tagállamában adószámmal rendelkező adóalany`
  - `19 = Other EU services taxable in Hungary, not on row 18: a 18. sorban nem szereplő egyéb, közösségi adóalanytól igénybevett szolgáltatás`
  - `27 = Services from a non-EU taxable person, base and VAT: a harmadik országbeli adóalanytól igénybe vett szolgáltatás ellenértékét`
  - `29 = Domestic reverse-charge VAT the buyer pays; detail on rows 51 to 54 (real estate, waste, emission rights, services): a fordított adózás szabályai szerint – adófizetésre kötelezett vevőként`
  - `64 = Deductible domestic input VAT at 5%: terhelő 5%-os mértékű előzetesen felszámított adót`
  - `67 = Deductible VAT on services entered on rows 18, 19 and 27: (a 18., a 19. és a 27. sorban feltüntetett)`
  - `69 = Deductible VAT on intra-EU acquisitions from rows 12 to 16 and 112: fizetendőként a bevallás 12-16. és 112. soraiban feltüntetett`

## HU141 — Method/dependencies: rows-input

Input rows: 64/65/66 domestic at 5/18/27, 111 at 0%, 68 apportionment, 76 total of 63-75 and 111.

- Act/article: Part II rows 64-68, 76, 111
- Official URL: https://nav.gov.hu/pfile/file?path=%2Fnyomtatvanyok%2Fletoltesek%2Fnyomtatvanykitolto_programok%2Fnyomtatvanykitolto_programok_nav%2F2665%2F2665-kitoltesi-utmutato
- Read: 2026-10-05; Unchanged independent review quality-evidence exact claim/locator reused; individual figure/form anchors above provide detailed row proof
- Cached locator: prior-review/quality-evidence.json;packet/sources
- Exact native anchor(s):
  - `64 = Deductible domestic input VAT at 5%: terhelő 5%-os mértékű előzetesen felszámított adót`
  - `65 = Deductible domestic input VAT at 18%: terhelő 18%-os mértékű előzetesen felszámított adót`
  - `66 = Deductible domestic input VAT at 27%: terhelő 27%-os mértékű előzetesen felszámított adót`
  - `68 = Apportioned input VAT (mixed taxable and exempt activity): akkor az arányosítás szabályai`
  - `76 = Total deductible input VAT: rows 63 to 75 and 111: 63-75. és 111. sorokban feltüntetett együttes`

## HU142 — Method/dependencies: rows-balance

Balance: 82 brought forward, 83 = 36 less 76 less 82, 84 payable if 83 positive, 85 refund if 83 negative and refund right exists, 86 carried forward to next 82.

- Act/article: Part II rows 82-86
- Official URL: https://nav.gov.hu/pfile/file?path=%2Fnyomtatvanyok%2Fletoltesek%2Fnyomtatvanykitolto_programok%2Fnyomtatvanykitolto_programok_nav%2F2665%2F2665-kitoltesi-utmutato
- Read: 2026-10-05; Unchanged independent review quality-evidence exact claim/locator reused; individual figure/form anchors above provide detailed row proof
- Cached locator: prior-review/quality-evidence.json;packet/sources
- Exact native anchor(s):
  - `82 = Credit brought forward from the previous period: az előző adómegállapítási időszakról áthozott`
  - `83 = Balance: row 36 less row 76 less row 82: az összes fizetendő adó (36. sor) összege csökkentve`
  - `84 = Payable (row 83 positive), without sign: ha a tárgyidőszakban a 83. sor adata előjel nélküli`
  - `85 = Refund claimed (row 83 negative and a refund right exists): ha a tárgyidőszakban a 83. sor adata mínusz előjelű`
  - `86 = Credit carried forward to row 82 of the next return: a következő bevallási időszakban csökkentő tételként a 82. sorban`

## HU143 — Method/dependencies: rows-eu-services-out

EU B2B services under the general rule go on row 92 (from row 91) and tie to the EU sales list; other EU B2B services under a place-of-supply rule other than § 37(1) go on row 93, not on the EU sales list.

- Act/article: Part II rows 91-93; row 93: 'A 93. sorba kell beírni a „határon átnyúló, Közösségen belüli szolgáltatások” ellenértékét, amely esetben ... a teljesítés helye nem az Áfa tv. 37. § (1) bekezdése alapján esik belföldön kívülre. Az összesítő nyilatkozatban ezt az adatot nem kell szerepeltetni.'
- Official URL: https://nav.gov.hu/pfile/file?path=%2Fnyomtatvanyok%2Fletoltesek%2Fnyomtatvanykitolto_programok%2Fnyomtatvanykitolto_programok_nav%2F2665%2F2665-kitoltesi-utmutato
- Read: 2026-10-05; Unchanged independent review quality-evidence exact claim/locator reused; individual figure/form anchors above provide detailed row proof
- Cached locator: prior-review/quality-evidence.json;packet/sources
- Exact native anchor(s):
  - `92 = EU B2B services under the general place-of-supply rule (ties to form 26A60): „határon átnyúló, Közösségen belüli szolgáltatások” ellenértékét (ideértve az előleget is)`
  - `93 = EU B2B services whose place of supply is outside Hungary under a rule other than § 37(1); not on the EU sales list: A 93. sorba kell beírni a „határon átnyúló, Közösségen belüli szolgáltatások” ellenértékét, amely esetben`

## HU144 — Method/dependencies: rounding

Main-sheet amounts in thousand forints, 499 down / 500 up; 2665A-07, -08, -03 and M-02 sheets in forints.

- Act/article: Part I.5 'A bevallás összegadatait ezer forintra kerekítve'
- Official URL: https://nav.gov.hu/pfile/file?path=%2Fnyomtatvanyok%2Fletoltesek%2Fnyomtatvanykitolto_programok%2Fnyomtatvanykitolto_programok_nav%2F2665%2F2665-kitoltesi-utmutato
- Read: 2026-10-05; Unchanged independent review quality-evidence exact claim/locator reused; individual figure/form anchors above provide detailed row proof
- Cached locator: prior-review/quality-evidence.json;packet/sources
- Exact native anchor(s):
  - `A bevallás összegadatait ezer forintra kerekítve`

## HU145 — Method/dependencies: holiday

A payment deadline falling on a non-working day moves to the next working day.

- Act/article: Part I.5: 'Ha a befizetendő részlet, kötelezettség fizetési határideje munkaszüneti napra esik, a határidő a legközelebbi munkanap.'
- Official URL: https://nav.gov.hu/pfile/file?path=%2Fnyomtatvanyok%2Fletoltesek%2Fnyomtatvanykitolto_programok%2Fnyomtatvanykitolto_programok_nav%2F2665%2F2665-kitoltesi-utmutato
- Read: 2026-10-05; Unchanged independent review quality-evidence exact claim/locator reused; individual figure/form anchors above provide detailed row proof
- Cached locator: prior-review/quality-evidence.json;packet/sources
- Exact native anchor(s):
  - `Ha a befizetendő részlet, kötelezettség fizetési határideje munkaszüneti napra esik, a határidő a legközelebbi munkanap.`

## HU146 — Method/dependencies: nil-return

A return is due whether the balance is positive, negative or zero.

- Act/article: Section 5 footnote paragraph 'Bevallást attól függetlenül be kell nyújtani'
- Official URL: https://nav.gov.hu/pfile/file?path=/ugyfeliranytu/nezzen-utana/inf_fuz/2026/14.-Hasznos-tudnivalok-kezdo-afaalanyoknak-2025.-02.-03
- Read: 2026-10-05; Unchanged independent review quality-evidence exact claim/locator reused; individual figure/form anchors above provide detailed row proof
- Cached locator: prior-review/quality-evidence.json;packet/sources
- Exact native anchor(s):
  - `Bevallást attól függetlenül be kell nyújtani`

## HU147 — Method/dependencies: m-sheets

Buyer lists every received domestic normally-taxed invoice with deducted VAT, no value threshold; eÁfa filers exempt.

- Act/article: Section on 2665M-02: 'értékhatártól függetlenül'; booklet 14 Section X: 'E kötelezettség alól mentesül ... eÁfa rendszer'
- Official URL: https://nav.gov.hu/pfile/file?path=%2Fnyomtatvanyok%2Fletoltesek%2Fnyomtatvanykitolto_programok%2Fnyomtatvanykitolto_programok_nav%2F2665%2F2665-kitoltesi-utmutato
- Read: 2026-10-05; Unchanged independent review quality-evidence exact claim/locator reused; individual figure/form anchors above provide detailed row proof
- Cached locator: prior-review/quality-evidence.json;packet/sources
- Exact native anchor(s):
  - `értékhatártól függetlenül`

## HU148 — Method/dependencies: refund-carry

Below the refund minimum the negative balance is carried forward; refund claimable from the due date.

- Act/article: Section on refunds: 'a soron következő adómegállapítási időszakban, a fizetendő adót csökkentő tételként beszámíthatja'
- Official URL: https://nav.gov.hu/pfile/file?path=/ugyfeliranytu/nezzen-utana/inf_fuz/2026/14.-Hasznos-tudnivalok-kezdo-afaalanyoknak-2025.-02.-03
- Read: 2026-10-05; Unchanged independent review quality-evidence exact claim/locator reused; individual figure/form anchors above provide detailed row proof
- Cached locator: prior-review/quality-evidence.json;packet/sources
- Exact native anchor(s):
  - `a soron következő adómegállapítási időszakban, a fizetendő adót csökkentő tételként beszámíthatja`

## HU149 — Method/dependencies: refund-special

Special refund deadlines exist (30 days special rule, liquidation 60/45 days); the Guide refers rather than quoting them.

- Act/article: Part I.7 'Visszaigénylés' / 'Speciális kiutalási szabály'
- Official URL: https://nav.gov.hu/pfile/file?path=%2Fnyomtatvanyok%2Fletoltesek%2Fnyomtatvanykitolto_programok%2Fnyomtatvanykitolto_programok_nav%2F2665%2F2665-kitoltesi-utmutato
- Read: 2026-10-05; Unchanged independent review quality-evidence exact claim/locator reused; individual figure/form anchors above provide detailed row proof
- Cached locator: prior-review/quality-evidence.json;packet/sources
- Exact native anchor(s):
  - `elszámolás vagy végelszámolás esetén 60, egyszerűsített felszámolás, vagy egyszerűsített végelszámolás esetén 45 napon belül kell kiutalni, amely határidőt a lezáró adóbevallás beérkezésének napjától, de legkorábban az esedékességtől kell számítani. Speciális kiutalási szabály A visszaigényelt áfát, feltéve, hogy az adózó a kiutalási igényét nem a felszámolást (egyszerűsített felszámolást) vagy a végelszámolást (egyszerűsített végelszámolást) lezáró adóbevallásban terjeszti elő, a bevallás beérkezésének napjától, de legkorábban az esedékességtől számított 30 napon belül, ha a visszaigényelhető adó összege az 1 millió forintot meghaladja, 45 napon belül kell kiutalni, ha az adózó az általános forgalmi adó áthárítására jogalapot teremtő minden ügylet - melynek teljesítését tanúsító számla (számlák) alapján az adott adómegállapítási időszakban adólevonási jogát gyakorolja - számlá(k)ban feltüntetett ellenértékének adót is tartalmazó összegét a bevallás benyújtásának napjáig teljes mértékben megfizette vagy tartozása egészében más módon megszűnt, és a feltétel fennállásáról az adózó a bevallásában nyilatkozik.58 Ha a felszámolás alatt álló adózóval szemben ezen határidő alatt az igényelt költségvetési támogatással összefüggésben bevallások utólagos vizsgálatára irányuló ellenőrzés indul, vagy van folyamatban, a költségvetési támogatás kiutalásának határidejét az ellenőrzés megállapításairól hozott határozat véglegessé válásától kell számítani. E rendelkezés alkalmazása során az ellenértéket megfizetettnek kell tekinteni, ha abból kizárólag szerződésben előre kikötött teljesítési garancia miatt történik a visszatartás. A törvényi feltételek fennállása esetén, a főlap (D) blokkjában, a megfelelő adatmezőbe [Nyilatkozat az Art. 64. § (3) bekezdése szerint] tett „X”-szel kell nyilatkoznia a kedvezőbb utalási határidő érvényesítése érdekében. A kockázatos adózó által visszaigényelt általános forgalmi adó kiutalási határideje 75 nap.59 A kockázatos adózók nem használhatják a kedvezményes kiutalás jelölésére szolgáló mezőt. A megbízható adózó – ide nem értve a nyilvánosan működő részvénytársaságot – által visszaigényelt általános forgalmi adót a NAV az Art. 64. § (1) bekezdése szerinti esetben 30 napon belül, a megbízható`

## HU150 — Method/dependencies: esl

EU sales list on form 26A60 by the 20th after month or quarter; eÁfa does not replace it.

- Act/article: Section 3.1 EU sales list table 'Havi a tárgyhónapot követő hó 20-ig Negyedéves a negyedévet követő hó 20-ig'; booklet 14 on 26A60
- Official URL: https://nav.gov.hu/pfile/file?path=/ugyfeliranytu/nezzen-utana/inf_fuz/2026/24.-Bevallasi-adofizetesi-informaciok-2026.01.26
- Read: 2026-10-05; Unchanged independent review quality-evidence exact claim/locator reused; individual figure/form anchors above provide detailed row proof
- Cached locator: prior-review/quality-evidence.json;packet/sources
- Exact native anchor(s):
  - `Havi a tárgyhónapot követő hó 20-ig Negyedéves a negyedévet követő hó 20-ig`

## HU151 — Method/dependencies: rtir

Online invoice data reporting covers every invoice issued to which the VAT Act applies; software invoices immediately M2M; paper within 4 days or 1 day.

- Act/article: Section X 'Az online számlaadat-szolgáltatási kötelezettség'
- Official URL: https://nav.gov.hu/pfile/file?path=/ugyfeliranytu/nezzen-utana/inf_fuz/2026/14.-Hasznos-tudnivalok-kezdo-afaalanyoknak-2025.-02.-03
- Read: 2026-10-05; Unchanged independent review quality-evidence exact claim/locator reused; individual figure/form anchors above provide detailed row proof
- Cached locator: prior-review/quality-evidence.json;packet/sources
- Exact native anchor(s):
  - `00 forintot, akkor 1 napon belül kell teljesítenie • számlázó programmal – számlázási funkcióval rendelkező programmal – kiállított számlák adattartalmáról azonnal, külön jogszabályban104 meghatározott módon, gép- gép kapcsolattal kell teljesítenie. Az online számlaadat-szolgáltatási kötelezettség az adóalany által kiállított, kibocsátott mindazon számlát érinti, melyre az Áfa tv. szabályai vonatkoznak. Mindezekről bővebb tájékoztatás a NAV honlapján a kiemelt témák között, az Online számla cím alatt található. A számlákkal összefüggésben az adólevonási jogot gyakorló, számlabefogadó adóalanynak is van belföldi összesítő jelentés-tételi kötelezettsége termék beszerzése, szolgáltatás igénybevétele, illetve előleg fizetése esetén. Ezt az áfabevallásban, a 2665 jelű nyomtatvány M 102 Áfa-bevallás gyakoriságára vonatkozó szabályok az Art. 2. számú melléklet I. B) 3. pontjában találhatók. 103 Áfa tv. 10. számú melléklet. 104 A számla és a nyugta adóigazgatási azonosításáról, valamint az elektronikus formában megőrzött számlák adóhatósági ellenőrzéséről szóló 23/2014. (VI.30.) NGM rendelet. 29 lapjain kell megtennie. E kötelezettség alól mentesül az az adóalany, aki (amely) bevallási kötelezettségét az eÁfa rendszer használatával teljesíti. A Közösségen belüli termékbeszerzés, termékértékesítés, szolgáltatásnyújtás és igénybevétel adókötelezettségeiről külön információs füzetek tartalmaznak részletes eligazítást, melyek a NAV honlapjáról letölthetők. XI. További információ, segítség Ha további kérdése van az adózási szabályokkal kapcsolatban, keressen minket bizalommal alábbi elérhetőségeinken! Interneten: ➢ a NAV honlapján a NAV - Nemzeti Adó- és Vámhivatal (gov.hu)-n. E-mailen: ➢ a következő címen található űrlapon: https://nav.gov.hu/ugyfeliranytu/keressen_minket/levelkuldes/e-ugyfsz Telefonon: ➢ a NAV Infóvonalán o belföldről a 1819, o külföldről a +36 (1) 461-1819 hívószámon. A NAV Infóvonala hétfőtől csütörtökig 8 óra 30 perctől 16 óráig, valamint péntekenként 8 óra 30 perctől 13 óra 30 percig hívható. Általános tájékoztatáshoz az (1) menüpontot, egyedi tájékoztatáshoz és ügyintézéshez a (2)* menüpontot kell választani. *A szolgáltatás használatához ügyfél-azonosító számmal kell rendelkeznie. Ha nincs ügyfél- azonosító száma, akkor azt a TEL jelű nyomtatványon igényelhet, amit a NAV-hoz személyesen vagy a KÜNY-tárhelyen keresztül lehet benyújtani. Felhívjuk figyelmét, hogy ha nem saját ügyében kívánja használni az ÜCC-t, akkor UJEGYKE-adatlap benyújtása is szükséges. Személyesen: ➢ országszerte a NAV ügyf`

## HU152 — Method/dependencies: car-ban

The VAT Act bans deduction on buying a passenger car; purchase for resale lifts the ban.

- Act/article: Section on exempt resale: 'a személygépkocsi beszerzésére vonatkozó levonási tilalmat a továbbértékesítési célú beszerzés feloldotta'
- Official URL: https://nav.gov.hu/pfile/file?path=/ugyfeliranytu/nezzen-utana/inf_fuz/2026/14.-Hasznos-tudnivalok-kezdo-afaalanyoknak-2025.-02.-03
- Read: 2026-10-05; Unchanged independent review quality-evidence exact claim/locator reused; individual figure/form anchors above provide detailed row proof
- Cached locator: prior-review/quality-evidence.json;packet/sources
- Exact native anchor(s):
  - `a személygépkocsi beszerzésére vonatkozó levonási tilalmat a továbbértékesítési célú beszerzés feloldotta`

## HU153 — Method/dependencies: deduction-bans

The VAT Act has specific deduction prohibitions (Áfa tv. §§ 124-125) and some deduction-restricted goods and services are defined by statistical classification.

- Act/article: Áfa tv. SZ124@BE1@POA,SZ124@BE2@POG,SZ125@BE1@POA
- Official URL: https://njt.jog.gov.hu/jogszabaly/2007-127-00-00
- Read: 2026-10-05; Unchanged independent review quality-evidence exact claim/locator reused; individual figure/form anchors above provide detailed row proof
- Cached locator: prior-review/quality-evidence.json;packet/sources
- Exact native anchor(s):
  - `a) 313 a motorbenzint (vtsz. 2710 12 41, 27 10 12 45, 2710 12 49, 2710 12 59; 2710 20 90-ből) terhelő előzetesen felszámított adó;`
  - `g) a vendéglátó-ipari szolgáltatást,`
  - `a) a 124. § (1) bekezdés ének a)–g) és i)–k) pontjaiban említett esetekben a termék igazoltan továbbértékesítési célt szolgál;`

## HU154 — Method/dependencies: exempt-85-87

Exempt activities of public-interest or special nature are listed in Áfa tv. §§ 85-87 and reported on row 08; option to tax letting exists.

- Act/article: V. Adómentességek 1., 'a tevékenység közérdekű, vagy egyéb speciális jellege miatti adómentes értékesítések körét az Áfa tv. 85-87. §-ai sorolják fel'; examples 'Például az egyetemes postai szolgáltatás, a humán egészségügyi szolgáltatás, az oktatási tevékenységek széles köre ... engedéllyel rendelkező szolgáltató nyújtja' and 'az egyes biztosítási, pénzügyi, illetve szerencsejáték-szolgáltatások ... ezen kívül az egyes ingatlanok értékesítése, bérbeadása, melyekre adómentesség helyett adókötelezettség választható'; 2665 guide row 08
- Official URL: https://nav.gov.hu/pfile/file?path=/ugyfeliranytu/nezzen-utana/inf_fuz/2026/14.-Hasznos-tudnivalok-kezdo-afaalanyoknak-2025.-02.-03
- Read: 2026-10-05; Unchanged independent review quality-evidence exact claim/locator reused; individual figure/form anchors above provide detailed row proof
- Cached locator: prior-review/quality-evidence.json;packet/sources
- Exact native anchor(s):
  - `a tevékenység közérdekű, vagy egyéb speciális jellege miatti adómentes értékesítések körét az Áfa tv. 85-87. §-ai sorolják fel`

## HU155 — Method/dependencies: internet-5

Internet access, district heating, restaurant food and commercial accommodation are on the 5% list.

- Act/article: Section III 5% services bullet
- Official URL: https://nav.gov.hu/pfile/file?path=/ugyfeliranytu/nezzen-utana/inf_fuz/2026/14.-Hasznos-tudnivalok-kezdo-afaalanyoknak-2025.-02.-03
- Read: 2026-10-05; Unchanged independent review quality-evidence exact claim/locator reused; individual figure/form anchors above provide detailed row proof
- Cached locator: prior-review/quality-evidence.json;packet/sources
- Exact native anchor(s):
  - `ecske, baromfi, tojás- és tejtermékek, emberi fogyasztásra alkalmas halak, valamint az Áfa tv. 8. számú melléklet I. részében felsorolt műalkotások importja. • Néhány szolgáltatás is az 5 százalékos adómérték alá tartozik, például a távhőszolgáltatás, az előadóművészi szolgáltatások egy bizonyos köre, az internetszolgáltatás, az étkezőhelyi vendéglátásban az étel és a helyben készített, nem alkoholos italforgalmú vendéglátó szolgáltatás (ez utóbbit TESZOR számra hivatkozással és megnevezéssel határozza meg az Áfa tv.), valamint a kereskedelmi szálláshely-szolgáltatás. • A 18 százalékos adómértékű termékeket – ilyenek egyes élelmiszerek – az erre vonatkozó melléklet vámtarifaszámra hivatkozással és megnevezéssel határozza meg, míg a szintén 18 százalékos adómértékű, az alkalmi szabadtéri rendezvényre történő belépést biztosító szolgáltatás statisztikai besorolására nem utal az Áfa tv. • A közérdekű vagy egyéb speciális jellege miatt adómentes termékértékesítések, szolgáltatásnyújtások körét már nem a statisztikai besorolásra alapozza az Áfa tv.,`

## HU156 — Method/dependencies: rc-wording

Invoices where the customer pays the VAT must state 'fordított adózás'.

- Act/article: reverse charge invoice paragraph
- Official URL: https://nav.gov.hu/pfile/file?path=/ugyfeliranytu/nezzen-utana/inf_fuz/2026/29_Az_altalanos_szabalyok_szerint_adozo_afaalanyok_kozossegi_ugyletei_2026.01.26
- Read: 2026-10-05; Unchanged independent review quality-evidence exact claim/locator reused; individual figure/form anchors above provide detailed row proof
- Cached locator: prior-review/quality-evidence.json;packet/sources
- Exact native anchor(s):
  - `zerzője vagy a szolgáltatás igénybevevője legyen kötelezett.103 Ha ezekben az esetekben az adóalanyt számlakiállítási kötelezettség terheli, akkor a számlán a „fordított adózás” kifejezést kell szerepeltetni,104 feltéve, hogy a megrendelő a saját országában adófizetésre lesz kötelezett. Bár a törvény nem írja elő, hogy a külföldön teljesített ügyleteknél az „Áfa tv. területi hatályán kívüli” kitételt fel kellene tüntetni, azonban – tekintve, hogy a bizonylatnak egyértelmű adatokat kell tartalmaznia, illetve abból ki kell derülnie, hogy miért nem tartalmaz áfát – célszerű minden olyan számlán szerepeltetni a területi hatályon kívüliségre utalást, amely külföldön teljesített ügyletet dokumentál. Az adóalany a Közösségben letelepedett nem adóalanyoknak nyújtott szolgáltatások után a letelepedésének tagállamától eltérő tagállamban keletkezett adófizetési kötelezettségének (feltéve, hogy a teljesítés tagállamában nincs letelepedve) és a távértékesítések (a 9. pont szerinti Közösségen belüli távértékesítések és a harmadik államból importált termékek `

## HU157 — Method/dependencies: cash-accounting-wording

Cash accounting invoices must carry 'pénzforgalmi elszámolás'.

- Act/article: Áfa tv. SZ169@POH
- Official URL: https://njt.jog.gov.hu/jogszabaly/2007-127-00-00
- Read: 2026-10-05; Unchanged independent review quality-evidence exact claim/locator reused; individual figure/form anchors above provide detailed row proof
- Cached locator: prior-review/quality-evidence.json;packet/sources
- Exact native anchor(s):
  - `h) a „pénzforgalmi elszámolás” kifejezés, a XIII/A. fejezetben meghatározott különös szabályok szerinti adózás alkalmazása esetében;`

## HU158 — InputVAT holds/cases

Fuelcase: petrolanyvehicle, otherfuelpassengercar; specific125exceptions afterproof

- Act/article: Áfa tv. SZ124@BE1@POA,SZ124@BE1@POB,SZ125@BE1@POA,SZ125@BE2@POI,SZ125@BE2@POJ
- Official URL: https://njt.jog.gov.hu/jogszabaly/2007-127-00-00
- Read: 2026-11-16; Changed/missing operative restriction and exceptions read; remain non-usable until transaction facts established
- Cached locator: vat-law.html
- Exact native anchor(s):
  - `SZ124@BE1@POA: a) 313 a motorbenzint (vtsz. 2710 12 41, 27 10 12 45, 2710 12 49, 2710 12 59; 2710 20 90-ből) terhelő előzetesen felszámított adó;`
  - `SZ124@BE1@POB: b) az a) pont ban nem említett egyéb üzemanyagot terhelő előzetesen felszámított adó, feltéve, hogy az személygépkocsi (vtsz. 8703) üzemeltetéséhez szükséges;`
  - `SZ125@BE1@POA: a) a 124. § (1) bekezdés ének a)–g) és i)–k) pontjaiban említett esetekben a termék igazoltan továbbértékesítési célt szolgál;`
  - `SZ125@BE2@POI: i) 328 a 124. § (1) bekezdés ének a) pont jában említett esetben kísérleti fejlesztés keretében igazoltan a környezetet jobban kímélő motorokkal kapcsolatos technológiai fejlesztéshez használja fel;`
  - `SZ125@BE2@POJ: j) 329 a 124. § (1) bekezdés a) pont jában említett esetben igazoltan egészben vagy túlnyomó részben úgy használja, egyéb módon hasznosítja, hogy az közvetlen anyagjellegű ráfordításként más termékértékesítés adóalapjába épül be.`

## HU159 — InputVAT holds/cases

Telephone30%restriction; carservices/hire50%; specialexceptionsseparate frombusinessshare

- Act/article: Áfa tv. SZ124@BE3,SZ124@BE3@POA,SZ124@BE3@POB,SZ124@BE3@POC,SZ124@BE4,SZ125@BE1@POE,SZ125@BE1@POF,9742
- Official URL: https://njt.jog.gov.hu/jogszabaly/2007-127-00-00
- Read: 2026-11-16; Changed/missing operative restriction and exceptions read; remain non-usable until transaction facts established
- Cached locator: vat-law.html
- Exact native anchor(s):
  - `SZ124@BE3: (3) 319 A 120. és 121. § -tól függetlenül szintén nem vonható le:`
  - `SZ124@BE3@POA: a) a vezetékes telefonszolgáltatást (TESZOR'15 61.10.11, 61.10.12),`
  - `SZ124@BE3@POB: b) a vezeték nélküli telefonszolgáltatást (TESZOR'15 61.20.12, 61.20.13, 61.20.14-ből),`
  - `SZ124@BE3@POC: c) az internetprotokollt alkalmazó, beszédcélú szolgáltatást (TESZOR'15 61.10.49-ből, 61.20.49-ből, 61.90.10-ből) terhelő előzetesen felszámított adó összegének 30 százaléka.`
  - `SZ124@BE4: (4) 320 A 120. és 121. § -tól függetlenül szintén nem vonható le a személygépkocsi`
  - `SZ125@BE1@POE: e) a 124. § (3) bekezdés ében felsorolt esetekben a szolgáltatás igénybevétele fejében járó ellenérték legalább 30 százalékára igazoltan teljesül, hogy az a 15. § szerinti szolgáltatásnyújtás adóalapjába épül be;`
  - `SZ125@BE1@POF: f) 322 a 124. § (4) bekezdés ében felsorolt esetben a szolgáltatás igénybevétele fejében járó ellenérték legalább 50 százalékára igazoltan teljesül, hogy az a 15. § szerinti szolgáltatásnyújtás adóalapjába épül be.`
  - `9742: 125/A. § 330 Az adóalany dönthet úgy is, hogy a 124. § (4) bekezdés b) pont ja helyett a 120. és 121. § -t alkalmazza.`

## HU160 — InputVAT holds/cases

Restaurant/food/entertainment blockedunlessoperative125exception established

- Act/article: Áfa tv. SZ124@BE1@POJ,SZ124@BE1@POK,SZ124@BE2@POG,SZ124@BE2@POH,SZ125@BE1@POA,SZ125@BE1@POD,SZ125@BE2@POG
- Official URL: https://njt.jog.gov.hu/jogszabaly/2007-127-00-00
- Read: 2026-11-16; Changed/missing operative restriction and exceptions read; remain non-usable until transaction facts established
- Cached locator: vat-law.html
- Exact native anchor(s):
  - `SZ124@BE1@POJ: j) az élelmiszert terhelő előzetesen felszámított adó;`
  - `SZ124@BE1@POK: k) az italt terhelő előzetesen felszámított adó.`
  - `SZ124@BE2@POG: g) a vendéglátó-ipari szolgáltatást,`
  - `SZ124@BE2@POH: h) 318 a szórakoztatási célú szolgáltatást (TESZOR'15 56.30, 90.01, 90.02, 93.21, 93.29) terhelő előzetesen felszámított adó.`
  - `SZ125@BE1@POA: a) a 124. § (1) bekezdés ének a)–g) és i)–k) pontjaiban említett esetekben a termék igazoltan továbbértékesítési célt szolgál;`
  - `SZ125@BE1@POD: d) a 124. § (2) bekezdés ében felsorolt esetekben a szolgáltatást igazoltan a 15. § szerinti szolgáltatásnyújtás teljesítése érdekében veszik igénybe;`
  - `SZ125@BE2@POG: g) a 124. § (1) bekezdés ének j) és k) pontjában említett esetekben igazoltan egészben vagy túlnyomó részben úgy használja, egyéb módon hasznosítja, hogy az közvetlen anyagjellegű ráfordításként más termékértékesítés, szolgáltatásnyújtás adóalapjába épül be;`
