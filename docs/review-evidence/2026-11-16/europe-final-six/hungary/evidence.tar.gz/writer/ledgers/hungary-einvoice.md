# hungary-einvoice figure and rule ledger

Base: bbab4f1a6d82cace432e6ca8eda89c98ffb1c038. Evidence is a writer inventory, not a new independent attestation. Unchanged PR960/periodic-VAT packet research and review are reused after one 2026-11-16 applicability check. Read dates below name original actual reads; current anchors bind applicability and changed claims. Native Hungarian law/authority excerpts are normalized only for whitespace; XML declarations are native technical identifiers. Hypothetical amounts/results and every retained provider/import hold are fully inventoried in NO-LOSS-MAP.md, not counted as legal rows.

## HU001 — Scope/mandate

Hungarian invoicing jurisdiction; every issued invoice/equivalent document; OSS/IOSS exclusion only other-member-state taxed supplies

- Act/article: Áfa tv. SZ158A@BE1, ME10@MP1.
- Official URL: https://njt.jog.gov.hu/jogszabaly/2007-127-00-00
- Read: 2026-10-30; Unchanged PR960 independent review reused; current official anchor inventory and 2026 applicability check
- Cached locator: vat official HTML/block
- Exact native anchor(s):
  - `SZ158A@BE1: 158/A. § 415 (1) A számlára vonatkozó kötelezettségekre – a (2) és (4) bekezdés ben foglalt eltéréssel – annak a tagállamnak a szabályait kell alkalmazni, ahol azt a termékértékesítést vagy szolgáltatásnyújtást, amelyre a számla vonatkozik, teljesítik.`
  - `ME10@MP1.: 1. 894 Az adóalany köteles adatot szolgáltatni az adó- és vámhatóság részére azon általa teljesített termékértékesítésekről, szolgáltatásnyújtásokról kibocsátott vagy kiállított számláról, számlával egy tekintet alá eső okiratról, amelyre e törvény rendelkezéseit kell alkalmazni a 158/A. § értelmében, kivéve azon termékértékesítésről, szolgáltatásnyújtásról, melynek teljesítési helye a Közösség másik tagállama és amely tekintetében az adóalany adófizetési kötelezettségének a XIX/A., illetve a XIX/B. Fejezet szerinti különös szabályok szerint tesz eleget.`

## HU002 — Mandate

Cash-register/e-cash-register invoices follow cash-register reporting, not duplicate Online Számla

- Act/article: Áfa tv. SZ257G@BE2, SZ257G@BE3
- Official URL: https://njt.jog.gov.hu/jogszabaly/2007-127-00-00
- Read: 2026-10-30; Unchanged PR960 independent review reused; current official anchor inventory and 2026 applicability check
- Cached locator: vat official HTML/block
- Exact native anchor(s):
  - `SZ257G@BE2: (2) Az adóalany az általa teljesített termékértékesítésekről, szolgáltatásnyújtásokról kiállított, kibocsátott számláról, számlával egy tekintet alá eső okiratról, – a pénztárgéppel, valamint az e-pénztárgéppel kiállított számlák, számlával egy tekintet alá eső okiratok kivételével – valamint termék beszerzése, szolgáltatás igénybevétele esetén azon számlákról, számlával egy tekintet alá eső okiratokról, amelyek alapján adólevonási jogot gyakorol, az adatszolgáltatást a 10. számú mellékletben meghatározottak szerint teljesíti.`
  - `SZ257G@BE3: (3) Az adóalany az általa teljesített 2. § a) pont ja szerinti termékértékesítésekről, szolgáltatásnyújtásokról kiállított, kibocsátott nyugtákról – kivéve a pénztárgéppel kiállított nyugtákat –, e-nyugtákról, e-pénztárgéppel kiállított számlákról, továbbá az azokkal egy tekintet alá eső okiratokról az adatszolgáltatást a 11. számú mellékletben foglaltak szerint teljesíti.`

## HU003 — Mandate/mandatory fields

Software/printed report invoice contents, currency and FX; omit private-person name/address

- Act/article: Áfa tv. ME10@MP2., ME10@MP4.
- Official URL: https://njt.jog.gov.hu/jogszabaly/2007-127-00-00
- Read: 2026-10-30; Unchanged PR960 independent review reused; current official anchor inventory and 2026 applicability check
- Cached locator: vat official HTML/block
- Exact native anchor(s):
  - `ME10@MP2.: 2. 895 Az adóalany a nyomdai úton előállított nyomtatvány használatával kibocsátott számla, számlával egy tekintet alá eső okirat e törvény szerinti adattartalmáról, továbbá, az adó alapjának meghatározásakor használt pénznemről, külföldi pénznem esetén annak forintra történő átszámításához alkalmazott, 80. § és 80/A. § szerinti árfolyamról köteles adatot szolgáltatni. Nem adóalany természetes személy részére kibocsátott számla, számlával egy tekintet alá eső okirat esetében az adatszolgáltatás nem terjed ki a termék beszerzőjének, szolgáltatás igénybevevőjének nevére és címére.`
  - `ME10@MP4.: 4. 896 A számlázási funkcióval rendelkező programmal kiállított számla, számlával egy tekintet alá eső okirat esetében az adóalany külön jogszabályban meghatározott elektronikus módon teljesít adatszolgáltatást a számla, számlával egy tekintet alá eső okirat e törvény szerinti adattartalmáról, továbbá az adó alapjának meghatározásakor használt pénznemről, külföldi pénznem esetén a forintra átszámított adatokról és a forintra történő átszámításhoz alkalmazott, 80. § és 80/A. § szerinti árfolyamról. Nem adóalany természetes személy részére kibocsátott számla, számlával egy tekintet alá eső okirat esetében az adatszolgáltatás nem terjed ki a termék beszerzőjének, szolgáltatás igénybevevőjének nevére és címére.`

## HU004 — Mandate

Deemed supplies11/14; advance on final invoice; predecessor and VAT-group-member tax number

- Act/article: Áfa tv. ME10@MP4/A., ME10@MP5., ME10@MP5/A., ME10@MP5
- Official URL: https://njt.jog.gov.hu/jogszabaly/2007-127-00-00
- Read: 2026-10-30; Unchanged PR960 independent review reused; current official anchor inventory and 2026 applicability check
- Cached locator: vat official HTML/block
- Exact native anchor(s):
  - `ME10@MP4/A.: 4/A. 897 Amennyiben az adóalany a 11. § szerinti termékértékesítést, a 14. § szerinti szolgáltatásnyújtást teljesít tőle eltérő személy, szervezet részére, köteles adatot szolgáltatni az ügylet 11. § , illetve 14. § hatálya alá tartozásáról, valamint arról, hogy a számlában feltüntetett áfát a termékbeszerző, szolgáltatást igénybe vevő köteles-e számára megtéríteni.`
  - `ME10@MP5.: 5. 898 Amennyiben az adóalany az általa teljesített termékértékesítéshez, szolgáltatáshoz 59. § szerinti előleget kapott, a teljesítésről kibocsátott, kiállított számla, számlával egy tekintet alá eső okirat vonatkozásában az előleg figyelembevételével adódó különbözetről is szolgáltat adatot.`
  - `ME10@MP5/A.: 5/A. 899 Amennyiben az adóalany belföldön kívül teljesített termékértékesítést, szolgáltatásnyújtást, köteles adatot szolgáltatni arról, hogy az ügylet e törvény területi hatályán kívül esik.`
  - `ME10@MP5: 5/C. 901 Csoportos adóalany által teljesített termékértékesítésről, szolgáltatásnyújtásról a csoportos adóalany által kiállított számla, számlával egy tekintet alá eső okirat esetén az ügyletben résztvevő tag adószámáról is adatot kell szolgáltatni.`

## HU005 — Mandate

Taxpayer or designated reporter declarations attributed to taxpayer; decree Hungarian registration scope

- Act/article: Áfa tv. ME10@MP6, ME10@MP7
- Official URL: https://njt.jog.gov.hu/jogszabaly/2007-127-00-00
- Read: 2026-10-30; Unchanged PR960 independent review reused; current official anchor inventory and 2026 applicability check
- Cached locator: vat official HTML/block
- Exact native anchor(s):
  - `ME10@MP6: 6. 902 Az 1–5/C. pont szerinti adatszolgáltatást az állami adó- és vámhatóság által erre a célra biztosított elektronikus felületen kell teljesíteni. Az elektronikus felület az adóalany egyedi azonosítására szolgáló adatok igénylését követően használható. Az azonosító adatokat az adóalany vagy annak Air. szerinti állandó meghatalmazottja igényli.`
  - `ME10@MP7: 7. 903 Az 1–5/C. pont szerinti adatszolgáltatást az adóalany nevében az a személy is teljesítheti, akit az adóalany vagy annak Air. szerinti állandó meghatalmazottja a 6. pont szerinti elektronikus felületen megjelöl. Az adóalany vagy annak Air. szerinti állandó meghatalmazottja által megjelölt személy által teljesített valamennyi adatszolgáltatás az adóalany nevében tett jognyilatkozatnak minősül.`

## HU006 — Mandate

Decree applies Hungarian registered taxable persons

- Act/article: NGM23/2014 1558
- Official URL: https://njt.jog.gov.hu/jogszabaly/2014-23-20-2X
- Read: 2026-10-30; Unchanged PR960 independent review reused; current official anchor inventory and 2026 applicability check
- Cached locator: decree official HTML/block
- Exact native anchor(s):
  - `1558: 1/A. § 4 E rendelet hatálya a belföldön nyilvántartásba vett adóalanyra terjed ki.`

## HU007 — Timeline

2018-07-01 start: invoices issued afterJune30; 2021-01-04 expansion

- Act/article: Áfa tv. SZ317@BE1, 10640
- Official URL: https://njt.jog.gov.hu/jogszabaly/2007-127-00-00
- Read: 2026-10-30; Unchanged PR960 independent review reused; current official anchor inventory and 2026 applicability check
- Cached locator: vat official HTML/block
- Exact native anchor(s):
  - `SZ317@BE1: 317. § 779 (1) E törvénynek az általános közigazgatási rendtartásról szóló törvény hatálybalépésével összefüggő törvények és egyes egyéb törvények módosításáról szóló 2017. évi CLIX. törvénnyel megállapított 2018. július 1-jétől hatályos 10. számú melléklete 5–8. pontjait a 2018. június 30-át követően nyomdai úton előállított nyomtatvány használatával kibocsátott vagy számlázási funkcióval rendelkező programmal kiállított számla, számlával egy tekintet alá eső okirat tekintetében kell először alkalmazni. Azon kibocsátott vagy kiállított számla, számlával egy tekintet alá eső okirat tekintetében, amelyről a terméket értékesítő, szolgáltatást nyújtó adóalanynak mind a 2018. június 30-ig hatályos, mind a 2018. július 1-jétől hatályos szabályok alapján adatot kell szolgáltatni, az adóalany dönthet úgy is, hogy csak a 2018. július 1-jétől hatályos szabályok szerint szolgáltat adatot.`
  - `10640: 339. § 799 E törvény 10. számú melléklete 2021. január 3. napján hatályos 1. és 2. pontját kell alkalmazni a 2020. június 30-át követően, de 2021. január 4. napja előtt kibocsátott vagy kiállított számla, számlával egy tekintet alá eső okirat esetén.`

## HU008 — Timeline

2020-07-01 value limit abolished; 2021 scope includes natural-person/EU/export invoices

- Act/article: NAV Online Számla3.0 specification2026-02-12: 2020.07.01 óta történt értékhatár eltörlés
- Official URL: https://github.com/nav-gov-hu/Online-Invoice/blob/cc7a775d6dce361311e409abb9934eb755f2749c/CHANGELOG_3.0.md
- Read: 2026-10-30; Unchanged PR960 independent technical review reused; native counterpart anchor located 2026-11-16
- Cached locator: CHANGELOG_3.0.md
- Exact native anchor(s):
  - `2020.07.01 óta történt értékhatár eltörlés miatt az Online számla API egy olyan közös nyelv és kommunikációs platform lett, amelyet országosan minden jogszabályok szerint működő számlázó szoftvernek ismernie kell, a NAV informatikailag továbbviszi ezt a koncepciót. Az Online számla saját sémáiból kiemelésre kerülnek azon generikus, üzleti katalógus jellegű, valamint a kommunikációt leíró típusok, amelyek más projektben is felhasználhatóak és átkerülnek egy új common XSD-be. A common XSD-nek sajá`

## HU009 — NAV route

Paper/electronic invoice; customer consent required unless law otherwise

- Act/article: Áfa tv. SZ174@BE1, SZ175@BE3@POB
- Official URL: https://njt.jog.gov.hu/jogszabaly/2007-127-00-00
- Read: 2026-10-30; Unchanged PR960 independent review reused; current official anchor inventory and 2026 applicability check
- Cached locator: vat official HTML/block
- Exact native anchor(s):
  - `SZ174@BE1: 174. § 452 (1) A számla és a nyugta lehet elektronikus vagy papíralapú.`
  - `SZ175@BE3@POB: b) egyéb esetben a számlabefogadó beleegyezése, kivéve, ha jogszabály ettől eltérően rendelkezik.`

## HU010 — NAV route

Optional invoice throughNAV: true flag, technically valid hash, successfulprocessing; buyerdownload

- Act/article: NGM23/2014 SZ13C@BE1, SZ13C@BE2, SZ13C@BE5
- Official URL: https://njt.jog.gov.hu/jogszabaly/2014-23-20-2X
- Read: 2026-10-30; Unchanged PR960 independent review reused; current official anchor inventory and 2026 applicability check
- Cached locator: decree official HTML/block
- Exact native anchor(s):
  - `SZ13C@BE1: 13/C. § (1) 29 Az adóalany az Áfa tv. 10. számú melléklet 1–5/C. pont ja szerinti adatszolgáltatási kötelezettségének eleget tehet úgy is, hogy az általa teljesített termékértékesítésről, szolgáltatásnyújtásról, ennek teljesítéséhez kapott előlegről kiállított elektronikus számlát, számlával egy tekintet alá eső okiratot az állami adó- és vámhatóság által erre a célra kialakított infrastruktúrán keresztül bocsátja a terméket beszerző, szolgáltatást igénybevevő rendelkezésére.`
  - `SZ13C@BE2: (2) Az (1) bekezdés szerinti esetben az adatszolgáltatás akkor minősül teljesítettnek, ha a számla, számlával egy tekintet alá eső okirat adattartalmát a 13/A. és 13/B. § szerint, a 13/A. § (1) bekezdésében említett közleményben erre a célra meghatározott külön jelzést is alkalmazva, technikailag érvényes hash kóddal továbbították az állami adó- és vámhatóság részére, és a sikeres feldolgozást az állami adó- és vámhatóság az erre a célra kialakított infrastruktúra segítségével visszaigazolta.`
  - `SZ13C@BE5: (5) Az állami adó- és vámhatóság lehetővé teszi, hogy az általa erre a célra kialakított infrastruktúrán keresztül az (1)–(4) bekezdésben foglaltaknak megfelelően továbbított számla, számlával egy tekintet alá eső okirat XML állományát az állami adó- és vámhatóság által megállapított adószámmal, csoportazonosító számmal rendelkező terméket beszerző, szolgáltatást igénybevevő személy, szervezet a feltöltéssel mindenben megegyező tartalommal és formában lekérdezze és letöltse. A számla, számlával egy tekintet alá eső okirat rendelkezésre bocsátása megtörténik a számla, számlával egy tekintet alá eső okirat XML állományának lekérdezhetővé és letölthetővé válásával.`

## HU011 — NAV route

Size-limit condition; prohibited privatepersons and corrections of invoices outsideNAVroute; invoicing/retention unaffected

- Act/article: NGM23/2014 SZ13C@BE3, SZ13C@BE4@POA, SZ13C@BE4@POB, SZ13C@BE6
- Official URL: https://njt.jog.gov.hu/jogszabaly/2014-23-20-2X
- Read: 2026-10-30; Unchanged PR960 independent review reused; current official anchor inventory and 2026 applicability check
- Cached locator: decree official HTML/block
- Exact native anchor(s):
  - `SZ13C@BE3: (3) Az (1) bekezdés alkalmazásának feltétele, hogy az elektronikus számla, számlával egy tekintet alá eső okirat mérete ne haladja meg a 13/A. § (1) bekezdése szerinti közleményben meghatározott méretkorlátot.`
  - `SZ13C@BE4@POA: a) a terméket beszerző, szolgáltatást igénybevevő nem adóalany természetes személy, vagy`
  - `SZ13C@BE4@POB: b) a számlával egy tekintet alá eső okirat olyan számla adattartalmát módosítja vagy érvényteleníti, amelyről az adatszolgáltatás nem az (1) és (2) bekezdés szerint történt.`
  - `SZ13C@BE6: (6) Az állami adó- és vámhatóság által kialakított infrastruktúra (1)–(5) bekezdésben foglaltak szerinti használata nem érinti a számla kibocsátására kötelezett adóalanynak és a számlát befogadó személynek, szervezetnek a számlázással és annak megőrzésével kapcsolatos jogait és kötelezettségeit. A (3), (4) és (7) bekezdésben foglaltaknak történő megfelelés a számla kibocsátására kötelezett adóalany felelőssége.`

## HU012 — Technical format

Schema namespaces3.0 data/API/base/annul; common NTCA1.0

- Act/article: invoiceApi.xsd declarations ManageInvoiceRequest,ManageAnnulmentRequest
- Official URL: https://github.com/nav-gov-hu/Online-Invoice/blob/cc7a775d6dce361311e409abb9934eb755f2749c/src/schemas/nav/gov/hu/OSA/3.0/invoiceApi.xsd
- Read: 2026-10-30; Unchanged PR960 reviewed schema rules reused; pinned current NAV tree applicability check
- Cached locator: invoiceApi.xsd
- Exact native anchor(s):
  - `<xs:element name="ManageInvoiceRequest"> A POST /manageInvoice REST operáció kérésének root elementje`
  - `<xs:element name="ManageAnnulmentRequest"> A POST /manageAnnulment REST operáció kérésének root elementje`

## HU013 — Structures

InvoiceData root number/date/completenessIndicator/invoiceMain; single invoice versus batch modification

- Act/article: invoiceData.xsd declarations InvoiceData,invoiceNumber,invoiceIssueDate,completenessIndicator,invoiceMain,invoice,batchInvoice
- Official URL: https://github.com/nav-gov-hu/Online-Invoice/blob/cc7a775d6dce361311e409abb9934eb755f2749c/src/schemas/nav/gov/hu/OSA/3.0/invoiceData.xsd
- Read: 2026-10-30; Unchanged PR960 reviewed schema rules reused; pinned current NAV tree applicability check
- Cached locator: invoiceData.xsd
- Exact native anchor(s):
  - `<xs:element name="InvoiceData"> XML root element, számla vagy módosítás adatait leíró típus, amelyet BASE64 kódoltan tartalmaz az invoiceApi sémaleíró invoiceData elementje`
  - `<xs:element name="invoiceNumber" type="common:SimpleText50NotBlankType"> Számla vagy módosító okirat sorszáma - ÁFA tv. 169. § b) vagy 170. § (1) bek. b) pont`
  - `<xs:element name="invoiceIssueDate" type="base:InvoiceDateType"> Számla vagy módosító okirat kelte - ÁFA tv. 169. § a), ÁFA tv. 170. § (1) bek. a)`
  - `<xs:element name="completenessIndicator" type="xs:boolean"> Jelöli, ha az adatszolgáltatás maga a számla (a számlán nem szerepel több adat)`
  - `<xs:element name="invoiceMain" type="InvoiceMainType"> Számlaadatok leírására szolgáló közös típus`
  - `<xs:element name="invoice" type="InvoiceType"> Egy számla vagy módosító okirat adatai`
  - `<xs:element name="batchInvoice" type="BatchInvoiceType" maxOccurs="unbounded"> Kötegelt módosító okirat adatai`

## HU014 — Structures

Original invoice reference/without-master/modificationindex; invoiceHead supplier/customer/optional fiscalrepresentative/detail

- Act/article: invoiceData.xsd declarations invoiceReference,originalInvoiceNumber,modifyWithoutMaster,modificationIndex,invoiceHead,supplierInfo,customerInfo,fiscalRepresentativeInfo,invoiceDetail
- Official URL: https://github.com/nav-gov-hu/Online-Invoice/blob/cc7a775d6dce361311e409abb9934eb755f2749c/src/schemas/nav/gov/hu/OSA/3.0/invoiceData.xsd
- Read: 2026-10-30; Unchanged PR960 reviewed schema rules reused; pinned current NAV tree applicability check
- Cached locator: invoiceData.xsd
- Exact native anchor(s):
  - `<xs:element name="invoiceReference" type="InvoiceReferenceType" minOccurs="0"> A módosítás vagy érvénytelenítés adatai`
  - `<xs:element name="originalInvoiceNumber" type="common:SimpleText50NotBlankType"> Az eredeti számla sorszáma, melyre a módosítás vonatkozik - ÁFA tv. 170. § (1) c)`
  - `<xs:element name="modifyWithoutMaster" type="xs:boolean"> Annak jelzése, hogy a módosítás olyan alapszámlára hivatkozik, amelyről nem történt és nem is fog történni adatszolgáltatás`
  - `<xs:element name="modificationIndex" type="base:InvoiceUnboundedIndexType"> A számlára vonatkozó módosító okirat egyedi sorszáma`
  - `<xs:element name="invoiceHead" type="InvoiceHeadType"> A számla egészét jellemző adatok`
  - `<xs:element name="supplierInfo" type="SupplierInfoType"> Számla kibocsátó (eladó) adatai`
  - `<xs:element name="customerInfo" type="CustomerInfoType" minOccurs="0"> Vevő adatai`
  - `<xs:element name="fiscalRepresentativeInfo" type="FiscalRepresentativeType" minOccurs="0"> Pénzügyi képviselő adatai`
  - `<xs:element name="invoiceDetail" type="InvoiceDetailType"> Számla részletező adatok`

## HU015 — Structures

Detail currency/delivery/FX/payment/appearance; lines and VAT-rate summary/gross

- Act/article: invoiceData.xsd declarations invoiceDeliveryDate,currencyCode,exchangeRate,paymentMethod,paymentDate,invoiceAppearance,invoiceLines,summaryByVatRate,invoiceGrossAmount,invoiceGrossAmountHUF
- Official URL: https://github.com/nav-gov-hu/Online-Invoice/blob/cc7a775d6dce361311e409abb9934eb755f2749c/src/schemas/nav/gov/hu/OSA/3.0/invoiceData.xsd
- Read: 2026-10-30; Unchanged PR960 reviewed schema rules reused; pinned current NAV tree applicability check
- Cached locator: invoiceData.xsd
- Exact native anchor(s):
  - `<xs:element name="invoiceDeliveryDate" type="base:InvoiceDateType"> Teljesítés dátuma (ha nem szerepel a számlán, akkor azonos a számla keltével) - ÁFA tv. 169. § g)`
  - `<xs:element name="currencyCode" type="common:CurrencyType"> A számla pénzneme az ISO 4217 szabvány szerint`
  - `<xs:element name="exchangeRate" type="ExchangeRateType"> HUF-tól különböző pénznem esetén az alkalmazott árfolyam: egy egység értéke HUF-ban`
  - `<xs:element name="paymentMethod" type="base:PaymentMethodType" minOccurs="0"> Fizetés módja`
  - `<xs:element name="paymentDate" type="base:InvoiceDateType" minOccurs="0"> Fizetési határidő`
  - `<xs:element name="invoiceAppearance" type="base:InvoiceAppearanceType"> A számla vagy módosító okirat megjelenési formája`
  - `<xs:element name="invoiceLines" type="LinesType" minOccurs="0"> A számlán szereplő tételek adatai`
  - `<xs:element name="summaryByVatRate" type="SummaryByVatRateType" maxOccurs="unbounded"> Összesítés ÁFA-mérték szerint`
  - `<xs:element name="invoiceGrossAmount" type="base:MonetaryType"> A számla bruttó összege a számla pénznemében`
  - `<xs:element name="invoiceGrossAmountHUF" type="base:MonetaryType"> A számla bruttó összege forintban`

## HU016 — API requests

TokenExchange; ManageInvoice(CREATE/MODIFY/STORNO); ManageAnnulment; QueryTransactionStatus/List

- Act/article: invoiceApi.xsd declarations TokenExchangeRequest,ManageInvoiceRequest,ManageAnnulmentRequest,QueryTransactionStatusRequest,QueryTransactionListRequest
- Official URL: https://github.com/nav-gov-hu/Online-Invoice/blob/cc7a775d6dce361311e409abb9934eb755f2749c/src/schemas/nav/gov/hu/OSA/3.0/invoiceApi.xsd
- Read: 2026-10-30; Unchanged PR960 reviewed schema rules reused; pinned current NAV tree applicability check
- Cached locator: invoiceApi.xsd
- Exact native anchor(s):
  - `<xs:element name="TokenExchangeRequest"> A POST /tokenExchange REST operáció kérésének root elementje`
  - `<xs:element name="ManageInvoiceRequest"> A POST /manageInvoice REST operáció kérésének root elementje`
  - `<xs:element name="ManageAnnulmentRequest"> A POST /manageAnnulment REST operáció kérésének root elementje`
  - `<xs:element name="QueryTransactionStatusRequest"> A POST /queryTransactionStatus REST operáció kérésének root elementje`
  - `<xs:element name="QueryTransactionListRequest"> A POST /queryTransactionList REST operáció kérésének root elementje`

## HU017 — API requests

QueryInvoiceData/Digest/Check/ChainDigest and QueryTaxpayer

- Act/article: invoiceApi.xsd declarations QueryInvoiceDataRequest,QueryInvoiceDigestRequest,QueryInvoiceCheckRequest,QueryInvoiceChainDigestRequest,QueryTaxpayerRequest
- Official URL: https://github.com/nav-gov-hu/Online-Invoice/blob/cc7a775d6dce361311e409abb9934eb755f2749c/src/schemas/nav/gov/hu/OSA/3.0/invoiceApi.xsd
- Read: 2026-10-30; Unchanged PR960 reviewed schema rules reused; pinned current NAV tree applicability check
- Cached locator: invoiceApi.xsd
- Exact native anchor(s):
  - `<xs:element name="QueryInvoiceDataRequest"> A POST /queryInvoiceData REST operáció kérésének root elementje`
  - `<xs:element name="QueryInvoiceDigestRequest"> A POST /queryInvoiceDigest REST operáció válaszának root elementje`
  - `<xs:element name="QueryInvoiceCheckRequest"> A POST /queryInvoiceCheck REST operáció kérésének root elementje`
  - `<xs:element name="QueryInvoiceChainDigestRequest"> A POST /queryInvoiceChainDigest REST operáció kérésének root elementje`
  - `<xs:element name="QueryTaxpayerRequest"> A POST /queryTaxpayer REST operáció kérésének root elementje`

## HU018 — Mandatory invoice fields

Issue date/unique serial/supplier taxnumber/buyer reverse-charge,EU or domesticfirst8 taxnumber

- Act/article: Áfa tv. SZ169@POA, SZ169@POB, SZ169@POC, SZ169@POD@APDA, SZ169@POD@APDB, SZ169@POD@APDC
- Official URL: https://njt.jog.gov.hu/jogszabaly/2007-127-00-00
- Read: 2026-10-30; Unchanged PR960 independent review reused; current official anchor inventory and 2026 applicability check
- Cached locator: vat official HTML/block
- Exact native anchor(s):
  - `SZ169@POA: a) a számla kibocsátásának kelte;`
  - `SZ169@POB: b) a számla sorszáma, amely a számlát kétséget kizáróan azonosítja;`
  - `SZ169@POC: c) a termék értékesítőjének, szolgáltatás nyújtójának adószáma, amely alatt a termék értékesítését, szolgáltatás nyújtását teljesítette;`
  - `SZ169@POD@APDA: da) adószáma, amely alatt mint adófizetésre kötelezettnek a termék értékesítését, szolgáltatás nyújtását teljesítették, vagy`
  - `SZ169@POD@APDB: db) adószáma, amely alatt a 89. § -ban meghatározott termékértékesítést részére teljesítették, vagy`
  - `SZ169@POD@APDC: dc) 441 adószámának vagy csoportos általános forgalmiadó-alanyiság esetén csoportazonosító számának első nyolc számjegye, amely alatt, mint belföldön nyilvántartásba vett adóalany részére a termékértékesítést, szolgáltatásnyújtást teljesítették, feltéve, hogy a termék értékesítője, szolgáltatás nyújtója gazdasági céllal belföldön telepedett le, gazdasági célú letelepedés hiányában pedig lakóhelye vagy szokásos tartózkodási helye van belföldön;`

## HU019 — Mandatory invoice fields

Parties names/addresses, description/quantity/tarifforTESZORchoice, differing supplydate

- Act/article: Áfa tv. SZ169@POE, SZ169@POF, SZ169@POG
- Official URL: https://njt.jog.gov.hu/jogszabaly/2007-127-00-00
- Read: 2026-10-30; Unchanged PR960 independent review reused; current official anchor inventory and 2026 applicability check
- Cached locator: vat official HTML/block
- Exact native anchor(s):
  - `SZ169@POE: e) a termék értékesítőjének, szolgáltatás nyújtójának, valamint a termék beszerzőjének, szolgáltatás igénybevevőjének neve és címe;`
  - `SZ169@POF: f) 442 az értékesített termék megnevezése, annak jelölésére – a számlakibocsátásra kötelezett választása alapján – az e törvényben alkalmazott vtsz., továbbá mennyisége vagy a nyújtott szolgáltatás megnevezése, annak jelölésére – a számlakibocsátásra kötelezett választása alapján – az e törvényben alkalmazott TESZOR'15, továbbá mennyisége, feltéve, hogy az természetes mértékegységben kifejezhető;`
  - `SZ169@POG: g) a 163. § (1) bekezdés a) és b) pont jában említett időpont, ha az eltér a számla kibocsátásának keltétől;`

## HU020 — Mandatory invoice fields

Cash-accounting/selfbilling/reverse-charge phrases; taxablebase/unitprice/discount/VATrate/tax; exemptionreference

- Act/article: Áfa tv. SZ169@POH, SZ169@POI, SZ169@POJ, SZ169@POK, SZ169@POL, SZ169@POM, SZ169@PON
- Official URL: https://njt.jog.gov.hu/jogszabaly/2007-127-00-00
- Read: 2026-10-30; Unchanged PR960 independent review reused; current official anchor inventory and 2026 applicability check
- Cached locator: vat official HTML/block
- Exact native anchor(s):
  - `SZ169@POH: h) a „pénzforgalmi elszámolás” kifejezés, a XIII/A. fejezetben meghatározott különös szabályok szerinti adózás alkalmazása esetében;`
  - `SZ169@POI: i) az adó alapja, továbbá az értékesített termék adó nélküli egységára vagy a nyújtott szolgáltatás adó nélküli egységára, ha az természetes mértékegységben kifejezhető, valamint az alkalmazott árengedmény, feltéve, hogy azt az egységár nem tartalmazza;`
  - `SZ169@POJ: j) az alkalmazott adó mértéke;`
  - `SZ169@POK: k) az áthárított adó, kivéve, ha annak feltüntetését e törvény kizárja;`
  - `SZ169@POL: l) az „önszámlázás” kifejezés, ha a számlát a terméket beszerző vagy a szolgáltatást igénybevevő állítja ki;`
  - `SZ169@POM: m) adómentesség esetében jogszabályi vagy a Héa-irányelv vonatkozó rendelkezéseire történő hivatkozás vagy bármely más, de egyértelmű utalás arra, hogy a termék értékesítése, szolgáltatás nyújtása mentes az adó alól;`
  - `SZ169@PON: n) a „fordított adózás” kifejezés, ha adófizetésre a termék beszerzője, szolgáltatás igénybevevője kötelezett;`

## HU021 — Mandatory invoice fields

Margin-scheme wording and fiscalrepresentative name/address/taxno

- Act/article: Áfa tv. SZ169@POP, SZ169@POQ, SZ169@POR
- Official URL: https://njt.jog.gov.hu/jogszabaly/2007-127-00-00
- Read: 2026-10-30; Unchanged PR960 independent review reused; current official anchor inventory and 2026 applicability check
- Cached locator: vat official HTML/block
- Exact native anchor(s):
  - `SZ169@POP: p) a „különbözet szerinti szabályozás – utazási irodák” kifejezés, a XV. fejezetben meghatározott különös szabályok szerinti utazásszervezési szolgáltatás nyújtása esetében;`
  - `SZ169@POQ: q) a „különbözet szerinti szabályozás – használt cikkek” vagy a „különbözet szerinti szabályozás – műalkotások”, vagy a „különbözet szerinti szabályozás – gyűjteménydarabok és régisek” kifejezések közül a megfelelő kifejezés, a XVI. fejezetben meghatározott különös szabályok szerinti használt ingóság, műalkotás, gyűjteménydarab vagy régiség értékesítése esetében;`
  - `SZ169@POR: r) pénzügyi képviselő alkalmazása esetében a pénzügyi képviselő neve, címe és adószáma.`

## HU022 — Simplified invoice

Advance, receiptcustomeraskinginvoice(HUF), crossborder159(2)c/d, EUR100limitwith exclusions; subjectivelyexempt

- Act/article: Áfa tv. SZ176@BE1@POA, SZ176@BE1@POB, SZ176@BE1@POC, SZ176@BE1@POD, SZ176@BE1@POE
- Official URL: https://njt.jog.gov.hu/jogszabaly/2007-127-00-00
- Read: 2026-10-30; Unchanged PR960 independent review reused; current official anchor inventory and 2026 applicability check
- Cached locator: vat official HTML/block
- Exact native anchor(s):
  - `SZ176@BE1@POA: a) a számlakibocsátásra jogalapot teremtő ügylet a 159. § (2) bekezdés ének a) pont ja alá tartozik, feltéve, hogy a számlán szereplő adatok egyébként forintban kifejezettek;`
  - `SZ176@BE1@POB: b) a 159. § (2) bekezdés ének b) pont jában és a 165. § (1) bekezdés ének b) pont jában meghatározott esetben az ott említett személy, szervezet az adóalanytól számla kibocsátását kéri, feltéve, hogy a számlán szereplő adatok egyébként forintban kifejezettek;`
  - `SZ176@BE1@POC: c) 461 a számlakibocsátásra jogalapot teremtő ügylet a 159. § (2) bekezdés ének c) vagy d) pont jai alá tartozik;`
  - `SZ176@BE1@POD: d) 462 a számla adóval növelt végösszege nem haladja meg a 100 eurónak megfelelő pénzösszeget, feltéve, hogy a számlakibocsátásra jogalapot teremtő ügylet a 29. § vagy a 89. § szerinti termékértékesítéstől eltérő ügylet, továbbá a számlakibocsátásra a 159. § (2) bekezdés c) és d) pont jában említett esetektől eltérő esetben kerül sor.`
  - `SZ176@BE1@POE: e) 463 a számlakibocsátásra jogalapot teremtő ügyletet a 187. § (1) bekezdés e vagy a 195/G. § (1) bekezdés e szerinti alanyi adómentesség hatálya alá tartozó adóalany e minőségében teljesíti.`

## HU023 — Invoice issue deadlines

Supply/advanceVATdetermination; followingmonth15 for qualifyingEUgoods/services; paidwithoutdelay exception167c; other chargedVAT8days

- Act/article: Áfa tv. SZ163@BE1, SZ163@BE1@POA, SZ163@BE1@POB, SZ163@BE2@POA, SZ163@BE2@POB, SZ163@BE2@POC
- Official URL: https://njt.jog.gov.hu/jogszabaly/2007-127-00-00
- Read: 2026-11-16; Changed/missing condition: current operative paragraph read
- Cached locator: vat official HTML/block
- Exact native anchor(s):
  - `SZ163@BE1: 163. § 420 (1) Az adóalany a számla kibocsátásáról legkésőbb`
  - `SZ163@BE1@POA: a) a teljesítésig,`
  - `SZ163@BE1@POB: b) előleg fizetése esetében a fizetendő adó megállapításáig, de legfeljebb az attól számított ésszerű időn belül köteles gondoskodni.`
  - `SZ163@BE2@POA: a) a 89. § szerinti termékértékesítés vagy olyan szolgáltatásnyújtás esetén, amely után az adót a Héa-irányelv 196. cikkének tartalmában megfelelő tagállami szabályozás alapján a szolgáltatást igénybevevő fizeti, a teljesítés hónapját követő hónap 15. napján belüli,`
  - `SZ163@BE2@POB: b) 422 az a) pont alá nem tartozó, valamint a 167. § c) pont jától eltérő olyan esetekben, ahol az ellenértéket az (1) bekezdés a) pont jában, illetve a 164. § (1) bekezdés a) pont jában említett időpontig, előleg fizetése esetén a fizetendő adó megállapításáig megtérítik, haladéktalan,`
  - `SZ163@BE2@POC: c) 423 egyéb, a b) pont alá nem tartozó olyan esetben, amelyben a számla áthárított adót tartalmaz, vagy annak áthárított adót kellene tartalmaznia, 8 napon belüli számlakibocsátási kötelezettséget jelent.`

## HU024 — Invoice issue deadlines

Aggregateinvoice and correction timing require owncheck; correctionclock fromlegalbasis fact

- Act/article: Áfa tv. SZ164@BE1, SZ164@BE1@POA, SZ164@BE1@POB, SZ170@BE2
- Official URL: https://njt.jog.gov.hu/jogszabaly/2007-127-00-00
- Read: 2026-11-16; Changed/missing condition: current operative paragraph read
- Cached locator: vat official HTML/block
- Exact native anchor(s):
  - `SZ164@BE1: 164. § 424 (1) A 163. § -tól eltérően, ha az adóalany`
  - `SZ164@BE1@POA: a) a teljesítés napján egyidejűleg vagy`
  - `SZ164@BE1@POB: b) az adott naptári hónapban ugyanannak a személynek, szervezetnek több, számlakibocsátásra jogalapot teremtő ügyletet teljesít, számlakibocsátási kötelezettségéről úgy is gondoskodhat, hogy azokról egy számlát (a továbbiakban: gyűjtőszámla) bocsát ki.`
  - `SZ170@BE2: (2) 444 A számlával egy tekintet alá eső okiratra egyebekben e törvénynek a számlára vonatkozó rendelkezéseit kell megfelelően alkalmazni azzal, hogy a 163. § -ban említett ésszerű időt a módosításra [ (1) bekezdés e) pont ja] jogalapot teremtő tény, egyéb körülmény bekövetkeztétől kell számítani.`

## HU025 — Mandatory schema fields

InvoicecategoryNORMAL/SIMPLIFIED/AGGREGATE; appearancePAPER/ELECTRONIC/EDI/UNKNOWN

- Act/article: invoiceData.xsd declarations NORMAL,SIMPLIFIED,AGGREGATE,PAPER,ELECTRONIC,EDI,UNKNOWN
- Official URL: https://github.com/nav-gov-hu/Online-Invoice/blob/cc7a775d6dce361311e409abb9934eb755f2749c/src/schemas/nav/gov/hu/OSA/3.0/invoiceBase.xsd; https://github.com/nav-gov-hu/Online-Invoice/blob/cc7a775d6dce361311e409abb9934eb755f2749c/src/schemas/nav/gov/hu/OSA/3.0/invoiceData.xsd
- Read: 2026-10-30; Unchanged PR960 reviewed schema rules reused; pinned current NAV tree applicability check
- Cached locator: invoiceData.xsd
- Exact native anchor(s):
  - `<xs:enumeration value="NORMAL"> Normál (nem egyszerűsített és nem gyűjtő) számla`
  - `<xs:enumeration value="SIMPLIFIED"> Egyszerűsített számla`
  - `<xs:enumeration value="AGGREGATE"> Gyűjtőszámla`
  - `<xs:enumeration value="PAPER"> Papír alapú számla`
  - `<xs:enumeration value="ELECTRONIC"> Elektronikus formában előállított, nem EDI számla`
  - `<xs:enumeration value="EDI"> EDI számla`
  - `<xs:enumeration value="UNKNOWN"> A szoftver nem képes azonosítani vagy a kiállításkor nem ismert`

## HU026 — Mandatory schema fields

CustomerDOMESTIC/OTHER/PRIVATE_PERSON; paymentTRANSFER/CASH/CARD/VOUCHER/OTHER; optionalpaymentdate

- Act/article: invoiceData.xsd declarations DOMESTIC,OTHER,PRIVATE_PERSON,TRANSFER,CASH,CARD,VOUCHER,paymentDate
- Official URL: https://github.com/nav-gov-hu/Online-Invoice/blob/cc7a775d6dce361311e409abb9934eb755f2749c/src/schemas/nav/gov/hu/OSA/3.0/invoiceApi.xsd; https://github.com/nav-gov-hu/Online-Invoice/blob/cc7a775d6dce361311e409abb9934eb755f2749c/src/schemas/nav/gov/hu/OSA/3.0/invoiceBase.xsd; https://github.com/nav-gov-hu/Online-Invoice/blob/cc7a775d6dce361311e409abb9934eb755f2749c/src/schemas/nav/gov/hu/OSA/3.0/invoiceData.xsd
- Read: 2026-10-30; Unchanged PR960 reviewed schema rules reused; pinned current NAV tree applicability check
- Cached locator: invoiceData.xsd
- Exact native anchor(s):
  - `<xs:enumeration value="DOMESTIC"> Belföldi ÁFA alany`
  - `<xs:enumeration value="OTHER"> Egyéb (belföldi nem ÁFA alany, nem természetes személy, külföldi ÁFA alany és külföldi nem ÁFA alany, nem természetes személy)`
  - `<xs:enumeration value="PRIVATE_PERSON"> Nem ÁFA alany (belföldi vagy külföldi) természetes személy`
  - `<xs:enumeration value="TRANSFER"> Banki átutalás`
  - `<xs:enumeration value="CASH"> Készpénz`
  - `<xs:enumeration value="CARD"> Bankkártya, hitelkártya, egyéb készpénz helyettesítő eszköz`
  - `<xs:enumeration value="VOUCHER"> Utalvány, váltó, egyéb pénzhelyettesítő eszköz`
  - `<xs:element name="paymentDate" type="base:InvoiceDateType" minOccurs="0"> Fizetési határidő`

## HU027 — Mandatory schema fields

Line description/quantity/unit/normalor simplified amounts and VATrate; invoice totals

- Act/article: invoiceData.xsd declarations lineDescription,quantity,unitOfMeasure,lineAmountsNormal,lineAmountsSimplified,lineVatRate,invoiceSummary
- Official URL: https://github.com/nav-gov-hu/Online-Invoice/blob/cc7a775d6dce361311e409abb9934eb755f2749c/src/schemas/nav/gov/hu/OSA/3.0/invoiceData.xsd
- Read: 2026-10-30; Unchanged PR960 reviewed schema rules reused; pinned current NAV tree applicability check
- Cached locator: invoiceData.xsd
- Exact native anchor(s):
  - `<xs:element name="lineDescription" type="common:SimpleText512NotBlankType" minOccurs="0"> A termék vagy szolgáltatás megnevezése`
  - `<xs:element name="quantity" type="QuantityType" minOccurs="0"> Mennyiség`
  - `<xs:element name="unitOfMeasure" type="UnitOfMeasureType" minOccurs="0"> A számlán szereplő mennyiségi egység kanonikus kifejezése az interfész specifikáció szerint`
  - `<xs:element name="lineAmountsNormal" type="LineAmountsNormalType" minOccurs="0"> Normál (nem egyszerűsített) számla esetén (beleértve a gyűjtőszámlát) kitöltendő tétel érték adatok.`
  - `<xs:element name="lineAmountsSimplified" type="LineAmountsSimplifiedType" minOccurs="0"> Egyszerűsített számla esetén kitöltendő tétel érték adatok`
  - `<xs:element name="lineVatRate" type="VatRateType"> Adómérték vagy adómentesség jelölése`
  - `<xs:element name="invoiceSummary" type="SummaryType"> Az ÁFA törvény szerinti összesítő adatok`

## HU028 — Modification fields

Modificationindexabove1000 warning; originalinvoice/withoutmaster controls

- Act/article: NAV Online Számla3.0 specification2026-02-12: modificationIndex > 1000
- Official URL: https://github.com/nav-gov-hu/Online-Invoice/blob/cc7a775d6dce361311e409abb9934eb755f2749c/docs/API%20docs/hu/Online_Szamla_interfesz%20specifikacio_HU_v3.0.%20%282026.02.12%29.pdf
- Read: 2026-10-30; Unchanged PR960 independent technical review reused; native counterpart anchor located 2026-11-16
- Cached locator: spec-hu.txt
- Exact native anchor(s):
  - `modificationIndex > 1000). A módosítás sorszáma (modificationIndex) kisebb vagy egyenlő legyen, mint 1000. 77 eltérés van a pénznem (HUF) és a megadott A számla pénzneme HUF, de a számla árfolyama nem 1. Ha HUF a pénznem, akkor árfolyamként csak 1-et lehet árfolyam között. megadni. NAV Online Számla rendszer 190. oldal 78 a megjelölt pénznemhez tartozó árfolyam Bizonyos devizákhoz eltárolják, hogy a hozzá tartozó árfolyam milyen intervallumon belül mozoghat. Ha a pénznemhez extrém tartozó árfolyam kívül esik a megjelölt határokon, akkor az hiba`

## HU029 — Modification fields

Correction date/ownnumber/originalreference/changeddata and quantitativeeffect

- Act/article: Áfa tv. SZ170@BE1@POA, SZ170@BE1@POB, SZ170@BE1@POC, SZ170@BE1@POE
- Official URL: https://njt.jog.gov.hu/jogszabaly/2007-127-00-00
- Read: 2026-10-30; Unchanged PR960 independent review reused; current official anchor inventory and 2026 applicability check
- Cached locator: vat official HTML/block
- Exact native anchor(s):
  - `SZ170@BE1@POA: a) az okirat kibocsátásának kelte;`
  - `SZ170@BE1@POB: b) az okirat sorszáma, amely az okiratot kétséget kizáróan azonosítja;`
  - `SZ170@BE1@POC: c) hivatkozás arra a számlára, amelynek adattartalmát az okirat módosítja;`
  - `SZ170@BE1@POE: e) a számla adatának megnevezése, amelyet a módosítás érint, valamint a módosítás természete, illetőleg annak számszerű hatása, ha ilyen van.`

## HU030 — Electronic invoice hash

electronicInvoiceHash + cryptoType; true completeness hash usesSHA3-512

- Act/article: invoiceApi.xsd declarations electronicInvoiceHash
- Official URL: https://github.com/nav-gov-hu/Online-Invoice/blob/cc7a775d6dce361311e409abb9934eb755f2749c/src/schemas/nav/gov/hu/OSA/3.0/invoiceApi.xsd
- Read: 2026-10-30; Unchanged PR960 reviewed schema rules reused; pinned current NAV tree applicability check
- Cached locator: invoiceApi.xsd
- Exact native anchor(s):
  - `<xs:element name="electronicInvoiceHash" type="common:CryptoType" minOccurs="0"> Elektronikus számla vagy módosító okirat állomány hash lenyomata`

## HU031 — Electronic invoice limitations

ELECTRONIC, notPRIVATE_PERSON/OTHERwithouttaxno; no mergedlines; originalmustuse route; no technicalannulment

- Act/article: NAV Online Számla3.0 specification2026-02-12: completenessIndicator
- Official URL: https://github.com/nav-gov-hu/Online-Invoice/blob/cc7a775d6dce361311e409abb9934eb755f2749c/docs/API%20docs/hu/Online_Szamla_interfesz%20specifikacio_HU_v3.0.%20%282026.02.12%29.pdf; https://github.com/nav-gov-hu/Online-Invoice/blob/cc7a775d6dce361311e409abb9934eb755f2749c/CHANGELOG_3.0.md
- Read: 2026-10-30; Unchanged PR960 independent technical review reused; native counterpart anchor located 2026-11-16
- Cached locator: spec-hu.txt
- Exact native anchor(s):
  - `completenessIndicator jelölő true értéke esetén kötelező. Az electronicInvoiceHash tag a típusából adódóan kiegészül egy új, kötelező attibútummal: cryptoType néven. Elfogadott értéke az adott számla completenessIndicator (adatszolgáltatás maga a számla) tag értékétől függ. Ha a completenessIndicator értéke true, az egyetlen elfogadott érték az SHA3-512. Ilyen esetben a hash értékének nagybetűs változatát kell beküldeni. Ha a completenessIndicator jelölő értéke false, az elfogadott értékek: SHA3-512, SHA-256. 7) A ManageInvoiceRequest/user/predecessorTaxNumber tag megadása esetén validálásra k`
  - `- új ERROR: ha az alapszámlában a completenessIndicator értéke false, akkor egy módosító okiraté sem lehet true (az API nem támogatja az ilyen irányba történő váltást a számlaláncon belül, de a másik irányba történő váltás megengedett)`
  - `- új ERROR: ha a completenessIndicator értéke true, az invoiceAppearance értéke csak ELECTRONIC lehet`
  - `- új ERROR: az electronicInvoicehash megadása kötelező, ha a completenessIndicator értéke true`
  - `- új ERROR: ha a completenessIndicator értéke true akkor a mergedItemIndicator értéke nem lehet true`
  - `- új ERROR: ha a completenessIndicator értéke true akkor a vevő nem lehet magánszemély`

## HU032 — Reporting deadline

Immediate XMLsoftware closeddata atissue; successfulprocessingcounts; rejectionresend

- Act/article: NGM23/2014 SZ8@BE6, SZ13A@BE1, SZ13A@BE3, SZ13A@BE4
- Official URL: https://njt.jog.gov.hu/jogszabaly/2014-23-20-2X
- Read: 2026-10-30; Unchanged PR960 independent review reused; current official anchor inventory and 2026 applicability check
- Cached locator: decree official HTML/block
- Exact native anchor(s):
  - `SZ8@BE6: (6) 12 A számlázó programmal előállított számla, számlával egy tekintet alá eső okirat az (1) bekezdés d) pontja alkalmazásában abban az időpontban minősül kiállítottnak, amely időponttal a számlázó program az előállított számla, számlával egy tekintet alá eső okirat adatait lezárja.`
  - `SZ13A@BE1: 13/A. § (1) 20 A számlázó programnak a gép-gép interfész használatához szükséges azonosító adatok megküldése mellett a kiállított számla, számlával egy tekintet alá eső okirat legalább az Áfa tv. 10. számú melléklet 4–5/C. pont jában meghatározottak szerinti adattartalmát a számla, számlával egy tekintet alá eső okirat kiállításakor azonnal, XML-formátumban, az állami adó- és vámhatóság közleményében meghatározott módon és adatszerkezetben, elektronikus úton továbbítania kell az állami adó- és vámhatóság részére.`
  - `SZ13A@BE3: (3) A számlázó programmal történő adatszolgáltatás akkor minősül teljesítettnek, ha az (1) bekezdés szerint történt a benyújtása, és a sikeres feldolgozást az állami adó- és vámhatóság rendszere visszaigazolta.`
  - `SZ13A@BE4: (4) Ha az állami adó- és vámhatóság visszaigazolása alapján az adatszolgáltatás nem dolgozható fel, a hiba elhárítását követően az adatszolgáltatást meg kell ismételni.`

## HU033 — Printed deadline

VAT>=500000HUF nextcalendarday; otherwise4calendardays; manualportal

- Act/article: Áfa tv. ME10@MP3., ME10@MP6
- Official URL: https://njt.jog.gov.hu/jogszabaly/2007-127-00-00
- Read: 2026-10-30; Unchanged PR960 independent review reused; current official anchor inventory and 2026 applicability check
- Cached locator: vat official HTML/block
- Exact native anchor(s):
  - `ME10@MP3.: 3. Amennyiben a nyomdai úton előállított nyomtatvány használatával kibocsátott számlában vagy számlával egy tekintet alá eső okiratban az áthárított adó összege az 500 000 forintot eléri vagy meghaladja, az adóalany a számla kibocsátását követő naptári napon belül, egyéb esetben a kibocsátást követő négy naptári napon belül köteles adatot szolgáltatni.`
  - `ME10@MP6: 6. 902 Az 1–5/C. pont szerinti adatszolgáltatást az állami adó- és vámhatóság által erre a célra biztosított elektronikus felületen kell teljesíteni. Az elektronikus felület az adóalany egyedi azonosítására szolgáló adatok igénylését követően használható. Az azonosító adatokat az adóalany vagy annak Air. szerinti állandó meghatalmazottja igényli.`

## HU034 — Foreign selfbilling

Buyeractingagent noHungarianseat/noHungarianregistration qualifyingcase6days

- Act/article: NGM23/2014 SZ13A@BE8, SZ13A@BE9
- Official URL: https://njt.jog.gov.hu/jogszabaly/2014-23-20-2X
- Read: 2026-10-30; Unchanged PR960 independent review reused; current official anchor inventory and 2026 applicability check
- Cached locator: decree official HTML/block
- Exact native anchor(s):
  - `SZ13A@BE8: (8) 23 Ha a számlakibocsátásra kötelezett adóalany ezen kötelezettségének meghatalmazott útján tesz eleget, és meghatalmazottként a terméket beszerző, szolgáltatást igénybe vevő olyan személy, szervezet jár el, aki (amely) belföldön nem rendelkezik székhellyel, és a meghatalmazotti minőségében történő számlakiállítás alapjául szolgáló ügylettel kapcsolatban belföldön nyilvántartásba nem vett adóalany, a meghatalmazott által számlázó programmal kiállított számláról, számlával egy tekintet alá eső okiratról az (1) bekezdés szerinti adatszolgáltatási kötelezettség teljesíthető a meghatalmazott számlázó programjától eltérő számítástechnikai rendszerből is, feltéve, hogy az gép-gép kapcsolattal, elektronikus úton valósul meg.`
  - `SZ13A@BE9: (9) 24 A (8) bekezdés szerinti esetben az (1) bekezdés szerinti adatszolgáltatási kötelezettséget az (1) bekezdéstől eltérően a számla, számlával egy tekintet alá eső okirat kiállítását követő 6 napon belül kell teljesíteni.`

## HU035 — Outages

NAVsystem/maintenance/internet and ownsystem outage24hafterend

- Act/article: NGM23/2014 SZ13B@BE3, SZ13B@BE4
- Official URL: https://njt.jog.gov.hu/jogszabaly/2014-23-20-2X
- Read: 2026-10-30; Unchanged PR960 independent review reused; current official anchor inventory and 2026 applicability check
- Cached locator: decree official HTML/block
- Exact native anchor(s):
  - `SZ13B@BE3: (3) 25 Ha a számla, számlával egy tekintet alá eső okirat kiállításának időpontjában a számla, számlával egy tekintet alá eső okirat adatait fogadó elektronikus rendszer üzemzavar, karbantartás vagy az internetszolgáltatás elégtelensége miatt nem érhető el, a számlázó programnak a kiállított számla, számlával egy tekintet alá eső okirat legalább az Áfa tv. 10. számú melléklet 4–5/C. pont jában meghatározottak szerinti adattartalmát az üzemzavar, karbantartás vagy az internetszolgáltatás elégtelensége megszűnését követő 24 órán belül kell az állami adó- és vámhatóság részére elektronikus úton továbbítania.`
  - `SZ13B@BE4: (4) 26 Ha a számlázó program a számla, számlával egy tekintet alá eső okirat kiállításának időpontjában a számla, számlával egy tekintet alá eső okirat adatainak szolgáltatására kötelezett adóalany rendszerének üzemzavara vagy az internetszolgáltatás elégtelensége miatt nem továbbítja az állami adó- és vámhatóság részére, a számlázó programnak az előállított számla, számlával egy tekintet alá eső okirat legalább az Áfa tv. 10. számú melléklet 4–5/C. pont jában meghatározottak szerinti adattartalmát az üzemzavar elhárulását követő 24 órán belül kell az állami adó- és vámhatóság részére elektronikus úton továbbítania.`

## HU036 — Outages

Ownoutage>48h notifyby48h, manualwithin24h, extendnoticeevery24h

- Act/article: NGM23/2014 SZ13B@BE5
- Official URL: https://njt.jog.gov.hu/jogszabaly/2014-23-20-2X
- Read: 2026-10-30; Unchanged PR960 independent review reused; current official anchor inventory and 2026 applicability check
- Cached locator: decree official HTML/block
- Exact native anchor(s):
  - `SZ13B@BE5: (5) 27 A (4) bekezdés től eltérően az adatszolgáltatásra kötelezett adóalany rendszerének 48 órát meghaladó üzemzavara vagy az internetszolgáltatás elégtelensége esetén ezt a tényt az adatszolgáltatásra kötelezett adóalanynak az állami adó- és vámhatóság rendszerében legkésőbb a 48 órás időtartam leteltekor jeleznie kell és az adatszolgáltatást ezen időtartam leteltétől számított 24 órán belül az állami adó- és vámhatóság rendszerében a kiállított számla, számlával egy tekintet alá eső okirat legalább az Áfa tv. 10. számú melléklet 4–5/C. pont jában meghatározottak szerinti adattartalmának manuális rögzítésével köteles teljesíteni. Amennyiben ezen 24 órás időkeret alatt az üzemzavar vagy az internetszolgáltatás elégtelensége nem hárul el, az időkeret az állami adó- és vámhatóság rendszerében tett ismételt bejelentéssel újabb 24 órával meghosszabbítandó mindaddig míg az üzemzavar, internetszolgáltatás elégtelensége fennáll.`

## HU037 — Accepted errors

Errorcorrection/resend/approval/manualoptional; ifunfixedwithin3workingdays manualrequired

- Act/article: NGM23/2014 SZ13A@BE5, SZ13A@BE6, SZ13A@BE7
- Official URL: https://njt.jog.gov.hu/jogszabaly/2014-23-20-2X
- Read: 2026-10-30; Unchanged PR960 independent review reused; current official anchor inventory and 2026 applicability check
- Cached locator: decree official HTML/block
- Exact native anchor(s):
  - `SZ13A@BE5: (5) 21 Amennyiben az adatszolgáltatásra kötelezett adóalany az állami adó- és vámhatóság rendszerének sikeres feldolgozásra vonatkozó visszaigazolása ellenére észleli, hogy hibás adatszolgáltatás történt, vagy a szolgáltatott adat módosítása egyéb körülmény miatt válik utólag szükségessé, az adatszolgáltatást a hiba elhárítását vagy a módosításra okot adó körülmény bekövetkezését követően meg kell ismételni. Az ismételt adatszolgáltatást az adatszolgáltatásra kötelezett adóalanynak az állami adó- és vámhatóság rendszerében jóvá kell hagynia.`
  - `SZ13A@BE6: (6) 22 A (4)–(5) bekezdés szerinti hibás adatszolgáltatás esetén az adatszolgáltatásra kötelezett adóalany a javított adatszolgáltatást az állami adó- és vámhatóság rendszerében a kiállított számla, számlával egy tekintet alá eső okirat legalább az Áfa tv. 10. számú melléklet 4–5/C. pont jában meghatározottak szerinti adattartalmának manuális rögzítésével is megteheti.`
  - `SZ13A@BE7: (7) Ha a (4)–(5) bekezdés szerinti hibás adatszolgáltatás észlelésének napjától számított 3 munkanapon belül a hiba elhárítása nem történt meg, akkor az adatszolgáltatásra kötelezett adóalany az adatszolgáltatást a hiba elhárulásáig a (6) bekezdésben foglaltak szerint köteles teljesíteni.`

## HU038 — API/authentication

XMLHTTPScontextrootv3; production/testendpoints; webportals

- Act/article: NAV Online Számla3.0 specification2026-02-12: https://api.onlineszamla.nav.gov.hu
- Official URL: https://github.com/nav-gov-hu/Online-Invoice/blob/cc7a775d6dce361311e409abb9934eb755f2749c/README.md
- Read: 2026-10-30; Unchanged PR960 independent technical review reused; native counterpart anchor located 2026-11-16
- Cached locator: README.md
- Exact native anchor(s):
  - `https://api.onlineszamla.nav.gov.hu/ Aktuális API dokumentáció: [Online Szamla_interfesz specifikáció_HU_v3.0 ](https://github.com/nav-gov-hu/Online-Invoice/tree/master/docs/API%20docs/hu) Fejlesztői dokumentációk: https://onlineszamla.nav.gov.hu/dokumentaciok Fejlesztői napló: https://onlineszamla.nav.gov.hu/fejlesztoi_naplo ## 1) A tárhely tartal`

## HU039 — API/authentication

PasswordSHA-512; signatureSHA3-512; exchange-key decodedtoken

- Act/article: NAV Online Számla3.0 specification2026-02-12: requestSignature
- Official URL: https://github.com/nav-gov-hu/Online-Invoice/blob/cc7a775d6dce361311e409abb9934eb755f2749c/docs/API%20docs/hu/Online_Szamla_interfesz%20specifikacio_HU_v3.0.%20%282026.02.12%29.pdf
- Read: 2026-10-30; Unchanged PR960 independent technical review reused; native counterpart anchor located 2026-11-16
- Cached locator: spec-hu.txt
- Exact native anchor(s):
  - `requestSignature számításában játszik szerepet, míg a cserekulcs az adatszolgáltatási token szerveroldali elkódolásához és a kliensoldali dekódolásához szükséges. 4) A technikai felhasználók kapcsán az elsődleges felhasználónak meg kell határoznia, hogy jogosult-e a beküldött számlaadatok utólagos lekérdezésére. A felsorolt követelmények rendszersíkonként értendők, azaz a tesztkörnyezetben elvégzett regisztráció nem helyettesíti az éles környezetben elvégzett regisztrációt, illetve a tesztkörnye`
  - `A passwordHash a login tagban szereplő technikai felhasználó jelszavának nagybetűs SHA-512 hash értéke. A literál jelszót a technikai felhasználót létrehozó elsődleges felhasználó adja meg az Online Számla webfelületen. A passwordHash az authentikáció egyik eleme. 3) A taxNumber azon adózó adószámának első 8 száma, aki nevében a technikai felhasználó tevékenykedik, és akihez ta`
  - `A requestSignature a kliens által generált aláírása az üzenetnek. Minden kéréshez kötelezően tartoznia kell egy requestSignature-nek. A szerver a kérésben szereplő adatok alapján elvégzi a saját requestSignature számítását és csak akkor hajtja végre a kérést, ha a tárolt és kapott adatokból a helyes érték ténylegesen előállítható. A requestSignature számításáról a „requestSignature számítása” fejezet nyújt tájékoztatást. 5) A passwordHash és requestSignature komplex típusa a cryptoType. A típusnak kötelező attribútuma a cryptoType, melyben a hash-képző algoritmust kell megadni. Üzleti validáció vizsgálja az értékét, nincs xsd szintű enum értékkészlete. 6) A passwordHash tag a típusából adódóan kiegészül egy új, kötelező attribútummal: crypt`

## HU040 — Token/workflow

Singleuse taxpayer token, validityinreply(current5minnotfixeddeadline), exchange-keydecode; batchmax100

- Act/article: NAV Online Számla3.0 specification2026-02-12: Az adatszolgáltatási token adózóra szól
- Official URL: https://github.com/nav-gov-hu/Online-Invoice/blob/cc7a775d6dce361311e409abb9934eb755f2749c/docs/API%20docs/hu/Online_Szamla_interfesz%20specifikacio_HU_v3.0.%20%282026.02.12%29.pdf
- Read: 2026-10-30; Unchanged PR960 independent technical review reused; native counterpart anchor located 2026-11-16
- Cached locator: spec-hu.txt
- Exact native anchor(s):
  - `Az adatszolgáltatási token adózóra szól, és a válaszban visszaadott időpontig – jelenleg a kiállítást követően 5 percig – érvényes. Az érvényesség időtartama később változhat. Az adatszolgáltatási tokent a rendszer a kérvényező technikai felhasználó cserekulcsával kódolva adja ki. A tokent felhasználni csak akkor lehet, ha az a helyes, dekódolt értékkel kerül a szervernek visszaküldésre. A számlák beküldése történhet egyenként vagy kötegelve. Egy adatszolgáltatás jelenlegi beküldési limitje a sémaleíró szerint 100 számlára vonatkozó adatszolgáltatás, tehát egy HTTP requestben és egy adatszolgáltatási tokennel egyszerre legfeljebb ennyi számlaadat-szolgáltatás küldhető be. Javasolt a kliensoldali implementáció közben ezt az értéket paraméterezhetővé tenni. Az adatszolgáltatást a token lejárati idejéig vagy a beküldési limit eléréséig - ha az előbb következik be - lehet beküldeni. A token lejárati idejének megállapításában egzakt módon a szerveridő fog dönteni, ezért az esetleges klienso`

## HU041 — Workflow

BASE64content, optionalcompression, operationindex; async transactionID

- Act/article: invoiceApi.xsd declarations invoiceData,compressedContent,index,transactionId
- Official URL: https://github.com/nav-gov-hu/Online-Invoice/blob/cc7a775d6dce361311e409abb9934eb755f2749c/src/schemas/nav/gov/hu/OSA/3.0/invoiceApi.xsd
- Read: 2026-10-30; Unchanged PR960 reviewed schema rules reused; pinned current NAV tree applicability check
- Cached locator: invoiceApi.xsd
- Exact native anchor(s):
  - `<xs:element name="invoiceData" type="xs:base64Binary"> Számla adatok BASE64-ben kódolt tartalma`
  - `<xs:element name="compressedContent" type="xs:boolean"> Tömörített tartalom jelzése a feldolgozási folyamat számára`
  - `<xs:element name="index" type="base:InvoiceIndexType"> A technikai érvénytelenítés sorszáma a kérésen belül`
  - `<xs:element name="transactionId" type="common:EntityIdType" minOccurs="0"> A számla tranzakció azonosítója, ha az gépi interfészen került beküldésre`

## HU042 — Statuses

RequestRECEIVED/PROCESSING/SAVED/FINISHED/NOTIFIED; invoiceRECEIVED/PROCESSING/SAVED/DONE/ABORTED

- Act/article: invoiceApi.xsd declarations RECEIVED,PROCESSING,SAVED,FINISHED,NOTIFIED,DONE,ABORTED
- Official URL: https://github.com/nav-gov-hu/Online-Invoice/blob/cc7a775d6dce361311e409abb9934eb755f2749c/src/schemas/nav/gov/hu/OSA/3.0/invoiceApi.xsd
- Read: 2026-10-30; Unchanged PR960 reviewed schema rules reused; pinned current NAV tree applicability check
- Cached locator: invoiceApi.xsd
- Exact native anchor(s):
  - `<xs:enumeration value="RECEIVED"> Befogadva`
  - `<xs:enumeration value="PROCESSING"> Feldolgozás alatt`
  - `<xs:enumeration value="SAVED"> Elmentve`
  - `<xs:enumeration value="FINISHED"> Feldolgozás befejezve`
  - `<xs:enumeration value="NOTIFIED"> Lekérdezve`
  - `<xs:enumeration value="DONE"> Kész`
  - `<xs:enumeration value="ABORTED"> Kihagyva`

## HU043 — Request signature

requestID+UTCtimestamp+signingkey thenordereduppercaseSHA3operation+BASE64 hashes, finaluppercaseSHA3

- Act/article: NAV Online Számla3.0 specification2026-02-12: a requestId értéke - a timestamp tag értéke
- Official URL: https://github.com/nav-gov-hu/Online-Invoice/blob/cc7a775d6dce361311e409abb9934eb755f2749c/docs/API%20docs/hu/Online_Szamla_interfesz%20specifikacio_HU_v3.0.%20%282026.02.12%29.pdf
- Read: 2026-10-30; Unchanged PR960 independent technical review reused; native counterpart anchor located 2026-11-16
- Cached locator: spec-hu.txt
- Exact native anchor(s):
  - `a requestId értéke - a timestamp tag értéke YYYYMMDDhhmmss maszkkal, UTC időben - a technikai felhasználó aláírókulcsának literál értéke Az összefűzéskor a timestamp maszkoláshoz ki kell venni a dátum- és időpontszeparátorokat, valamint az időzónát. Az index hash értékeket az egyes indexek alatt álló operation és base64 tartalom összefűzését követő nagybetűs SHA3-512 hash értékéből lehet megállapítani: - invoiceOperation vagy annulmentOperation literál értéke - az invoiceData vagy invoiceAnnulment tagban található base64 tartalom NAV Online Számla rendszer 12. oldal A kiszámított index hash-eket a parciális hash mögé kell fűzni az indexek által leírt sorrendben. Az így és sorrendben konkatenált string nagybetűs SHA3-512 hash eredménye lesz a requestSignature értéke. Egy fiktív példa request adatai: • requestId = TSTKFT1222564 • timestamp = 2017-12-30T18:25:45.000Z • a technikai felhaszná`

## HU044 — Batch limit/workedcase

Up to100invoiceoperations and100annulmentoperations perrequest; 101splits100+1

- Act/article: invoiceApi.xsd maxOccurs
- Official URL: https://github.com/nav-gov-hu/Online-Invoice/blob/cc7a775d6dce361311e409abb9934eb755f2749c/src/schemas/nav/gov/hu/OSA/3.0/invoiceApi.xsd
- Read: 2026-10-30; Unchanged reviewed technical limit; new hypothetical case independently recomputes arithmetic
- Cached locator: invoiceApi.xsd
- Exact native anchor(s):
  - `<xs:element name="annulmentOperation" type="AnnulmentOperationType" maxOccurs="100">`
  - `<xs:element name="invoiceOperation" type="InvoiceOperationType" maxOccurs="100">`

## HU045 — Technical users

Primaryuser creates technicalusers and signing/exchangekeys onweb; taxpayer decides queryrights

- Act/article: NAV Online Számla3.0 specification2026-02-12: A technikai felhasználó számára aláírókulcsot
- Official URL: https://github.com/nav-gov-hu/Online-Invoice/blob/cc7a775d6dce361311e409abb9934eb755f2749c/docs/API%20docs/hu/Online_Szamla_interfesz%20specifikacio_HU_v3.0.%20%282026.02.12%29.pdf
- Read: 2026-10-30; Unchanged PR960 independent technical review reused; native counterpart anchor located 2026-11-16
- Cached locator: spec-hu.txt
- Exact native anchor(s):
  - `A technikai felhasználó számára aláírókulcsot és cserekulcsot kell generáltatni az Online Számla rendszerben. A kulcsok generálását csak elsődleges felhasználó jogosult elvégezni az Online Számla web felületen. Az aláírókulcs az üzenetek aláírására szolgáló requestSignature számításában játszik szerepet, míg a cserekulcs az adatszolgáltatási token szerveroldali elkódolásához és a kliensoldali dekódolásához szükséges. 4) A technikai felhasználók kapcsán az elsődleges felhasználónak meg kell határoznia, hogy jogosult-e a beküldött számlaadatok utólagos lekérdezésére. A felsorolt követelmények rendszersíkonként értendők, azaz a tesztkörnyezetben elvégzett regisztráció nem helyettesíti az éles környezetben elvégzett regisztrációt, illetve a tesztkörnyezetben létrehozott technikai felhasználók és kulcsok sem használhatók az éles környezetben! `

## HU046 — Technical users

Test/production registration/userkeys separate

- Act/article: NAV Online Számla3.0 specification2026-02-12: teszt
- Official URL: https://github.com/nav-gov-hu/Online-Invoice/blob/cc7a775d6dce361311e409abb9934eb755f2749c/docs/API%20docs/hu/Online_Szamla_interfesz%20specifikacio_HU_v3.0.%20%282026.02.12%29.pdf
- Read: 2026-10-30; Unchanged PR960 independent technical review reused; native counterpart anchor located 2026-11-16
- Cached locator: spec-hu.txt
- Exact native anchor(s):
  - `tesztkörnyezetben elvégzett regisztráció nem helyettesíti az éles környezetben elvégzett regisztrációt, illetve a tesztkörnyezetben létrehozott technikai felhasználók és kulcsok sem használhatók az éles környezetben! A kapcsolódáshoz implementálandó technológiák • HTTPS – Biztonságos HTTP • Webservice - Webszolgáltatás • WADL – Webalkalmazás Leíró Nyelv • REST API – Adatszolgáltatáshoz szükséges REST interfész • XML – Kiterjeszthető Jelölő Nyelv `

## HU047 — Validation

Schema/authentication/business layers; ERRORreject vs WARNaccepted; businessnumber/sequence/reference/taxnumber checks

- Act/article: NAV Online Számla3.0 specification2026-02-12: INVOICE_NUMBER_NOT_UNIQUE
- Official URL: https://github.com/nav-gov-hu/Online-Invoice/blob/cc7a775d6dce361311e409abb9934eb755f2749c/docs/API%20docs/hu/Online_Szamla_interfesz%20specifikacio_HU_v3.0.%20%282026.02.12%29.pdf
- Read: 2026-10-30; Unchanged PR960 independent technical review reused; native counterpart anchor located 2026-11-16
- Cached locator: spec-hu.txt
- Exact native anchor(s):
  - `INVOICE_NUMBER_NOT_UNIQUE 1.0 MODIFY, XML tag STORNO 3 CREATE, minden típus businessValidationMessages ERROR LINE_NUMBER_NOT_SEQUENTIAL 1.0 MODIFY, XML tag STORNO 4 CREATE, minden típus businessValidationMessages ERROR INVOICE_LINE_MISSING 1.0 STORNO XML tag 5 MODIFY, minden típus businessValidationMessages ERROR INVALID_INVOICE_REFERENCE 1.0 STORNO XML tag 6 MODIFY, minden típus businessValidationMessages ERROR INVOICE_TYPE_MISMATCH 1.0 STORNO XML tag 7 MODIFY, minden típus businessValidationMessages ERROR INVOICE_LINE_ALREADY_EXISTS 1.0 STORNO XML tag 8 ANNUL minden típus businessValidationMessages ERROR INVALID_ANNULMENT_REFERENCE 1.0 XML tag 9 ANNUL minden típus businessValidationMessages ERROR ANNULMENT_IN_PROGRESS 1.0 XML tag 10 CREATE, minden típus businessValidationMessages ERROR C`
  - `az adatszolgáltatás befogadását megakadályozza => ERROR típusú visszajelzés) - figyelmeztetést (olyan üzleti hiba, amely az adatszolgáltatás befogadását nem blokkolja, azonban a számla, vagy az erről nyújtott adatszolgáltatás tartalmilag helytelen vagy helytelen lehet => WARN típusú visszajelzés) - tájékoztató üzenetet (INFO típusú visszajelzés) - nyugtaüzenetet (az adatszolgáltatás helyes és a befogadása megtörtént => OK típusú visszajelzés) Az adatszolgáltatás addig nem tekinthető teljesítettnek, amíg a kliens az aszinkronfeldolgozás sikerességéről meg nem győződött és az adott számlához tartozó nyugtaüzenetet meg nem kapta. 1.2 Az XML-üzen`

## HU048 — Validation

2025July24/December8 and2026January/February WARNupdates

- Act/article: NAV Online Számla3.0 specification2026-02-12: 2026.02.12
- Official URL: https://github.com/nav-gov-hu/Online-Invoice/blob/cc7a775d6dce361311e409abb9934eb755f2749c/docs/API%20docs/hu/Online_Szamla_interfesz%20specifikacio_HU_v3.0.%20%282026.02.12%29.pdf
- Read: 2026-10-30; Unchanged PR960 independent technical review reused; native counterpart anchor located 2026-11-16
- Cached locator: spec-hu.txt
- Exact native anchor(s):
  - `2025.07.24. 3.0 WARN és ERROR változások a következő oldalakon: 176, 177, 187, 188, 189, 210, 211, 230, 245, 248, 287, 288, 293. 2025.12.08 AK 3.0 Új ERROR és WARN üzenetek bevezetése, WARN és ERROR változtatások. 2026.02.12 3.0 Módosultak a következő WARN üzenetek: 11400, 11401. NAV Online Számla rendszer BEVEZETÉS Az általános forgalmi adóról szóló 2007. évi CXXVII. törvény 10. mellékletének 2021. január 4-től hatá`
  - `2026.01.01-től aktív az éles környezeten. NAV Online Számla rendszer 248. oldal Azonosító: 11401. Figyelmeztetés csoport`

## HU049 — Validation codes

ExemptionTAM/AAM/KBAET/KBAUK/EAM/NAM; domesticreversechargeflag

- Act/article: invoiceData.xsd declarations vatExemption,vatDomesticReverseCharge
- Official URL: https://github.com/nav-gov-hu/Online-Invoice/blob/cc7a775d6dce361311e409abb9934eb755f2749c/src/schemas/nav/gov/hu/OSA/3.0/invoiceData.xsd
- Read: 2026-10-30; Unchanged PR960 reviewed schema rules reused; pinned current NAV tree applicability check
- Cached locator: invoiceData.xsd
- Exact native anchor(s):
  - `<xs:element name="vatExemption" type="DetailedReasonType"> Az adómentesség jelölése - ÁFA tv. 169. § m)`
  - `<xs:element name="vatDomesticReverseCharge" type="xs:boolean" fixed="true"> A belföldi fordított adózás jelölése - ÁFA tv. 142. §`

## HU050 — Validation/tolerance

HUF FX1; foreignFXrange; lineHUFdifference1%, minimumlargerofHUF1/0.01currency

- Act/article: NAV Online Számla3.0 specification2026-02-12: A tolerált eltérés
- Official URL: https://github.com/nav-gov-hu/Online-Invoice/blob/cc7a775d6dce361311e409abb9934eb755f2749c/docs/API%20docs/hu/Online_Szamla_interfesz%20specifikacio_HU_v3.0.%20%282026.02.12%29.pdf
- Read: 2026-10-30; Unchanged PR960 independent technical review reused; native counterpart anchor located 2026-11-16
- Cached locator: spec-hu.txt
- Exact native anchor(s):
  - `A tolerált eltérést vizsgáló WARN-ok esetében változott a tolerált eltérés mértéke a következők szerint: „A tolerált eltérés a számított forintban kifejezett érték 1%-a, de legalább 1 HUF és a számla pénznemének 0,01 egysége közül a nagyobb.” Törölt WARN -üzenetek 1) A 3.0-ás verzióban a séma változásai az alábbi WARN -üzenetek törlését eredményezik: - INCORRECT_VAT_CODE_SUPPLI`

## HU051 — Technical annulment

Wrongreportnotinvoicecorrection; DONEnotcancelled; authorizedapproval; onepending; truecompletenessforbidden

- Act/article: NAV Online Számla3.0 specification2026-02-12: 1.10.2
- Official URL: https://github.com/nav-gov-hu/Online-Invoice/blob/cc7a775d6dce361311e409abb9934eb755f2749c/docs/API%20docs/hu/Online_Szamla_interfesz%20specifikacio_HU_v3.0.%20%282026.02.12%29.pdf
- Read: 2026-10-30; Unchanged PR960 independent technical review reused; native counterpart anchor located 2026-11-16
- Cached locator: spec-hu.txt
- Exact native anchor(s):
  - `1. Technikai érvénytelenítés kizárólag olyan korábbi adatszolgáltatásra vonatkozóan teljesíthető, amelyre már sikeres visszaigazoló nyugta („DONE”) érkezett, és kizárólag figyelmeztetéseket („WARN”) vagy azt sem tartalmaz a válaszüzenet. 2. Technikai érvénytelenítés a /manageAnnulment operáción keresztül történik úgy, hogy a legfeljebb 100 darab annulmentOperation elem mindegyike technikai érvénytelenítést tartalmaz. A belső base64 tartalomnak az invoiceAnnulment sémaleíróban definiált elemeket kell tartalmaznia. A séma nem enged meg egy műveleten belül technikai érvénytelenítést és „eredeti” (CREATE/MODIFY/STORNO) adatszolgáltatást vegyesen benyújtani. 3. Technikai érvénytelenítés számlán és számlával egy tekintet alá eső okiraton egyaránt elvégezhető. A technikai érvénytelenítések száma nem korlátozott. Ugyanakkor a technikai érvénytelenítésekre vonatkozó adatok a kockázatelemző rendszer bemenő adataként használhatók. 4. A feldolgozó rendszer a technikai érvénytelenítést a számla vagy számlával egy tekintet alá eső okirat sorszáma (invoiceNumber elem) alapján illeszti, amit a technikai érvénytelenítésről történő adatszolgáltatásban az annulmentReference elemben kell közölni. 5. Ha a technikai érvénytelenítés olyan számlára érkezik, amelyhez kapcsolódóan már történt módosításról történő adatszolgáltatás is, akkor a technikai érvénytelenítés automatikusan, külön kérés nélkül vonatkozik mindegyik módosításról történő adatszolgáltatásra is. 6. Ha a technikai érvénytelenítés módosító okiratra vonatkozik, akkor a technikai érvénytelenítés kizárólag erre az okiratra értendő, az eredeti számlára, illetve esetleges más módosításokra nem. 7. Technikai érvénytelenítéskor az annulmentOperation tag értékét mindig ANNUL értékkel kell közölni. 8. A technikai érvénytelenítés sikeres teljesítését követően a technikai érvénytelenítések mindegyikére vonatkozóan web felhasználói jóváhagyás szükséges. Ennek részleteit a felhasználói felület dokumentációja tartalmazza. 9. A technikai érvénytelenítéssel érintett okiratok sorszáma (a technikai érvénytelenítés jóváhagyását követően) újra felhasználható. 10. A completenessIndicator = true jelzésű adatszolgáltatásokat, ahol az adatszolgáltatás maga az elektronikus számla, nem lehetséges technikai érvényteleníteni. Ezt külön üzleti validáció figyeli, részletek a „Hibakezelés” fejezetben. 2.5 Adatszolgáltatás számlával egy tekintet alá eső okiratokról A Bevezetőben említett törvényi szabályozás kifejezetten rendelkezik arról, hogy a számlázó programmal kiállított számlák módosításáról, érvénytelenítéséről (Áfa törvény terminológiája szerint „számlával egy tekintet alá eső okiratokról”) is adatot kell szolgáltatnia a számlázó programnak, a vonatkozó feltételek teljesülése esetén. A számlát leíró séma úgy került kidolgozásra, hogy alkalmas legyen az adott számlát érintő módosítások adatainak közlésére is, figyelemmel a következő tényekre: NAV Online Számla rendszer 149. oldal • Az Áfa törvény a gazdasági eseményt leíró eredeti számlát tekinti számlának, ennek minden módosítása, adott esetben érvénytelenítése is az eredeti `
  - `ha olyan számlára érkezik ismételten technikai érvénytelenítés, amire már van jóváhagyásra váró technikai érvénytelenítés folyamatban. A másik, ha olyan alapszámlához érkezik új módosító vagy sztornó számla, amire már van jóváhagyásra váró technikai érvénytelenítés folyamatban. A technikai érvénytelenítés jóváhagyása / elutasítása az Online Számla felületén végezhető el, mindkét esetben meg kell várni az érvénytelenítési kérés elbírálását. Az adott számlára a számla tulajdonosa és a jogutódja(i) által beküldött érvénytelenítési kéréseket is figyelembe veszi a validáció. 10 a vevő adószáma ninc`

## HU052 — VAT rates

27standard;5Annex3;18Annex3A;0Annex3B

- Act/article: Áfa tv. SZ82@BE1, SZ82@BE2, SZ82@BE3, SZ82@BE4
- Official URL: https://njt.jog.gov.hu/jogszabaly/2007-127-00-00
- Read: 2026-10-30; Unchanged PR960 independent review reused; current official anchor inventory and 2026 applicability check
- Cached locator: vat official HTML/block
- Exact native anchor(s):
  - `SZ82@BE1: 82. § (1) 174 Az adó mértéke az adó alapjának 27 százaléka.`
  - `SZ82@BE2: (2) 175 A 3. számú mellékletben felsorolt termékek, szolgáltatások esetében az adó mértéke az adó alapjának 5 százaléka.`
  - `SZ82@BE3: (3) 176 A 3/A. számú mellékletben felsorolt termékek, szolgáltatások esetében az adó mértéke az adó alapjának 18 százaléka.`
  - `SZ82@BE4: (4) 177 A 3/B. számú mellékletben felsorolt termékek esetében az adó mértéke az adó alapjának 0 százaléka.`

## HU053 — Zero-rate scope

Daily newspapers; prescription-only medicines and human medicinal magistral preparations from2026-09-01

- Act/article: Áfa tv. Annex3/B rows1–3; ActXL2026§4
- Official URL: https://njt.jog.gov.hu/jogszabaly/2007-127-00-00
- Read: 2026-11-16; Changed VAT wording and unchanged e-invoice rule verified in operative official annex and commencement
- Cached locator: vat-annex-block.txt;amend-zero.txt
- Exact native anchor(s):
  - `Kizárólag orvosi rendelvényhez kötött gyógyszerek`
  - `Humán gyógyászati célú magisztrális készítmények`
  - `Ez a törvény 2026. szeptember 1-jén lép hatályba.`

## HU054 — Rates/summaries

Exempt/outofscopecodeandreasons distinctfrom0%; multirateperline andsummary

- Act/article: invoiceData.xsd declarations vatExemption,vatOutOfScope,lineVatRate,summaryByVatRate
- Official URL: https://github.com/nav-gov-hu/Online-Invoice/blob/cc7a775d6dce361311e409abb9934eb755f2749c/src/schemas/nav/gov/hu/OSA/3.0/invoiceData.xsd
- Read: 2026-10-30; Unchanged PR960 reviewed schema rules reused; pinned current NAV tree applicability check
- Cached locator: invoiceData.xsd
- Exact native anchor(s):
  - `<xs:element name="vatExemption" type="DetailedReasonType"> Az adómentesség jelölése - ÁFA tv. 169. § m)`
  - `<xs:element name="vatOutOfScope" type="DetailedReasonType"> Az ÁFA törvény hatályán kívüli`
  - `<xs:element name="lineVatRate" type="VatRateType"> Adómérték vagy adómentesség jelölése`
  - `<xs:element name="summaryByVatRate" type="SummaryByVatRateType" maxOccurs="unbounded"> Összesítés ÁFA-mérték szerint`

## HU055 — FX

CurrencyinvoiceVATalsoHUF; dateadvance/acquisition/§60,§58invoiceissue,otherwise supply; bank selling/MNBadvancechoice/ECB, MNBfollowingyearlock

- Act/article: Áfa tv. SZ172@BE0, SZ80@BE1@POA, SZ80@BE1@POB, SZ80@BE1@POC, SZ80@BE2@POA, SZ80@BE2@POB, SZ80@BE4, SZ80A@BE1, SZ80A@BE3
- Official URL: https://njt.jog.gov.hu/jogszabaly/2007-127-00-00
- Read: 2026-10-30; Unchanged PR960 independent review reused; current official anchor inventory and 2026 applicability check
- Cached locator: vat official HTML/block
- Exact native anchor(s):
  - `SZ172@BE0: 172. § 446 A 2. § a) pont ja szerinti termékértékesítésről, szolgáltatásnyújtásról kibocsátott számlán az áthárított adót [ 169. § k) pont ja] – a 80. § szerint meghatározott árfolyam alkalmazásával – forintban kifejezve abban az esetben is fel kell tüntetni, ha az egyéb adatok külföldi pénznemben kifejezettek.`
  - `SZ80@BE1@POA: a) termék Közösségen belüli beszerzése, illetőleg előleg fizetése esetében, valamint a 60. § -ban említett esetekben a fizetendő adó megállapításakor,`
  - `SZ80@BE1@POB: b) az 58. § -ban említett esetben a számla kibocsátásakor,`
  - `SZ80@BE1@POC: c) egyéb esetekben pedig a teljesítéskor érvényes.`
  - `SZ80@BE2@POA: a) belföldön pénzváltási engedéllyel rendelkező hitelintézet devizában eladási árként jegyez; vagy`
  - `SZ80@BE2@POB: b) 171 a Magyar Nemzeti Bank (a továbbiakban: MNB) hivatalosan közzé tesz, feltéve, hogy a forintra történő átszámításra kötelezett (e § alkalmazásában a továbbiakban: kötelezett) így dönt, és erről a döntéséről az állami adóhatóságnak előzetes bejelentést tesz.`
  - `SZ80@BE4: (4) Az a kötelezett, aki (amely) élt a (2) bekezdés b) pont jában említett választási jogával, attól a választása évét követő naptári év végéig nem térhet el.`
  - `SZ80A@BE1: 80/A. § 173 (1) A 80. § (2) bekezdés étől eltérően az adó alapjának forintra történő átszámításához választható az EKB által a 80. § (1) bekezdés ében meghatározott időpontban hivatalosan közzétett legutolsó árfolyam is.`
  - `SZ80A@BE3: (3) Az EKB által közzétett árfolyam választására az MNB által közzétett árfolyam választására vonatkozó rendelkezéseket kell alkalmazni.`

## HU056 — Retention

VATrecords issued/received untilassessmentlapse; issuerpapercopy/recipientoriginalorcertifiedcopy

- Act/article: Áfa tv. SZ179@BE1, SZ179@BE2
- Official URL: https://njt.jog.gov.hu/jogszabaly/2007-127-00-00
- Read: 2026-10-30; Unchanged PR960 independent review reused; current official anchor inventory and 2026 applicability check
- Cached locator: vat official HTML/block
- Exact native anchor(s):
  - `SZ179@BE1: 179. § (1) 470 Minden személy, szervezet, aki (amely) e törvényben szabályozott jogot gyakorol, illetőleg akire (amelyre) e törvény kötelezettséget állapít meg, köteles az adómegállapítás hiánytalan és helyes volta ellenőrizhetőségének érdekében az általa vagy nevében kibocsátott, valamint a birtokában levő vagy egyéb módon rendelkezésére álló okiratot legalább az adó megállapításához való jog elévüléséig megőrizni.`
  - `SZ179@BE2: (2) 471 Az (1) bekezdés szerinti megőrzési kötelezettség papír alapú okirat esetében a kibocsátásra kötelezett részéről a másodlati példányra, a befogadó részéről az okirat eredeti példányára, vagy – ha azt e törvény nem zárja ki – eredeti példány hiányában annak hiteles másolatára vonatkozik. A megőrzési kötelezettség teljesíthető a papír alapon kibocsátott okirat elektronikus formában történő megőrzésével is. Elektronikus okirat kizárólag elektronikus formában őrizhető meg. A kötelezettség teljesítését nem befolyásolja az elektronikus okirat formátumának a 168/A. § -ban foglalt követelményeknek megfelelő megváltoztatása. A megőrzési kötelezettség elektronikus formában történő teljesítése esetén az adóalanynak elektronikusan kell megőriznie a számla eredetének hitelességét, adattartalma sértetlenségét biztosító adatokat is.`

## HU057 — Retention

General5years fromendreturn-dueyear, subjectstatutoryexceptions

- Act/article: Art. SZ202@BE1
- Official URL: https://njt.jog.gov.hu/jogszabaly/2017-150-00-00
- Read: 2026-10-30; Unchanged PR960 independent review reused; current official anchor inventory and 2026 applicability check
- Cached locator: art official HTML/block
- Exact native anchor(s):
  - `SZ202@BE1: (1) Az adó megállapításához való jog annak a naptári évnek az utolsó napjától számított öt év elteltével évül el, amelyben az adóról bevallást, adatbejelentést, bejelentést kellett volna tenni, illetve bevallás, adatbejelentés, bejelentés hiányában az adót meg kellett volna fizetni. A költségvetési támogatás igényléséhez, a túlfizetés visszaigényléséhez való jog – ha törvény másként nem rendelkezik – annak a naptári évnek az utolsó napjától számított öt év elteltével évül el, amelyben az annak igényléséhez való jog megnyílt.`

## HU058 — Retention

Accountingvouchers atleast8years readable/traceable; electronicretention promptretrieval andnoalteration

- Act/article: Számv. tv. SZ169@BE2, SZ169@BE5
- Official URL: https://njt.jog.gov.hu/jogszabaly/2000-100-00-00
- Read: 2026-10-30; Unchanged PR960 independent review reused; current official anchor inventory and 2026 applicability check
- Cached locator: accounting official HTML/block
- Exact native anchor(s):
  - `SZ169@BE2: (2) 918 A könyvviteli elszámolást közvetlenül és közvetetten alátámasztó számviteli bizonylatot (ideértve a főkönyvi számlákat, az analitikus, illetve részletező nyilvántartásokat is), legalább 8 évig kell olvasható formában, a könyvelési feljegyzések hivatkozása alapján visszakereshető módon megőrizni.`
  - `SZ169@BE5: (5) 919 Az elektronikus formában kiállított bizonylatot – a digitális archiválás szabályairól szóló jogszabály előírásainak figyelembevételével – elektronikus formában kell megőrizni, oly módon, hogy az alkalmazott módszer biztosítsa a bizonylat összes adatának késedelem nélküli előállítását, folyamatos leolvashatóságát, illetve kizárja az utólagos módosítás lehetőségét.`

## HU059 — Retention

Authenticity/integrity/legibility throughout; softwaredocumentation untilassessmentlapse; daterange/numberrangeauditexport

- Act/article: Áfa tv. SZ168A@BE1
- Official URL: https://njt.jog.gov.hu/jogszabaly/2007-127-00-00
- Read: 2026-10-30; Unchanged PR960 independent review reused; current official anchor inventory and 2026 applicability check
- Cached locator: vat official HTML/block
- Exact native anchor(s):
  - `SZ168A@BE1: 168/A. § 439 (1) A számla kibocsátásának időpontjától a számla megőrzésére vonatkozó időszak végéig biztosítani kell a számla eredetének hitelességét, adattartalma sértetlenségét és olvashatóságát.`

## HU060 — Retention

Softwaredocs retention and auditexport dateornumberrange

- Act/article: NGM23/2014 SZ10@BE4, 1620, SZ11A@POA, SZ11A@POB
- Official URL: https://njt.jog.gov.hu/jogszabaly/2014-23-20-2X
- Read: 2026-10-30; Unchanged PR960 independent review reused; current official anchor inventory and 2026 applicability check
- Cached locator: decree official HTML/block
- Exact native anchor(s):
  - `SZ10@BE4: (4) A számlázó programot használó adóalany az (1) bekezdés szerinti dokumentációt, valamint annak (3) bekezdése szerinti valamennyi kiegészítését, módosítását az ezen számlázó programmal kibocsátott számlában áthárított adó megállapításához való jog elévüléséig köteles megőrizni. Az adóalany ezen megőrzési kötelezettségének elektronikusan is eleget tehet.`
  - `1620: 11/A. § 17 A számlázó programnak olyan önálló, de a programba beépített, „adóhatósági ellenőrzési adatszolgáltatás” elnevezésű funkcióval kell rendelkeznie, amelynek elindításával adatexport végezhető`
  - `SZ11A@POA: a) a kezdő és záró dátum (év, hónap, nap) megadásával meghatározható időszakban kibocsátott, illetve`
  - `SZ11A@POB: b) a kezdő és a záró számlasorszám megadásával meghatározható sorszámtartományba tartozó számlákra.`

## HU061 — Retention

NAVnotstatutoryelectronicarchive; taxpayerownretention

- Act/article: NAV Online Számla3.0 specification2026-02-12: azonban ebben az esetben sem vállalja az adóhivatal
- Official URL: https://github.com/nav-gov-hu/Online-Invoice/blob/cc7a775d6dce361311e409abb9934eb755f2749c/docs/API%20docs/hu/Online_Szamla_interfesz%20specifikacio_HU_v3.0.%20%282026.02.12%29.pdf
- Read: 2026-10-30; Unchanged PR960 independent technical review reused; native counterpart anchor located 2026-11-16
- Cached locator: spec-hu.txt
- Exact native anchor(s):
  - `azonban ebben az esetben sem vállalja az adóhivatal az archiválási rendelet szerinti megőrzést. Az elektronikus számlák megőrzéséről minden esetben az adózónak kell gondoskodnia. f) Az Áfa törvény alapján az elektronikus számlázáshoz a vevőnek hozzá kell járulnia. Ebben a két partnernek kell megállapodnia, az adóhivatal nem vállalja át a megállapodás létrejöttéhez kapcsolódó ügyvitelt még részben sem. A vevő elektronikus számlázáshoz történő hozz`

## HU062 — Penalties

Annex10report failures late/incomplete/incorrect/untrue affectedinvoicecount*generalmaximum; individual400k/other1m

- Act/article: Art. SZ229@BE0, SZ220@BE1
- Official URL: https://njt.jog.gov.hu/jogszabaly/2017-150-00-00
- Read: 2026-10-30; Unchanged PR960 independent review reused; current official anchor inventory and 2026 applicability check
- Cached locator: art official HTML/block
- Exact native anchor(s):
  - `SZ229@BE0: Az általános forgalmi adó összesítő jelentés szerinti adatszolgáltatási kötelezettség elmulasztása, késedelmes, hiányos, hibás vagy valótlan adattartalmú teljesítése esetén a kiszabható mulasztási bírság felső határa az érintett számlák, illetve számlával egy tekintet alá eső okiratok számának és az általános bírságszabály szerinti bírság adózóra egyébként vonatkozó legmagasabb mértékének szorzata.`
  - `SZ220@BE1: (1) 360 Ha jogszabály eltérően nem rendelkezik, az adóhatóság az e törvényben, adókötelezettséget előíró törvényben, illetve e törvények felhatalmazásán alapuló más jogszabályban megállapított kötelezettségnek a megszegése miatt a természetes személy adózót négyszázezer forintig, nem természetes személy adózót egymillió forintig terjedő mulasztási bírsággal sújthatja.`

## HU063 — Penalties

Reasonablyexpectedlatenessexcuse onlyaftercompliance/proof

- Act/article: Art. SZ220@BE3
- Official URL: https://njt.jog.gov.hu/jogszabaly/2017-150-00-00
- Read: 2026-10-30; Unchanged PR960 independent review reused; current official anchor inventory and 2026 applicability check
- Cached locator: art official HTML/block
- Exact native anchor(s):
  - `SZ220@BE3: (3) A késedelem esetén nincs helye mulasztási bírság megállapításának, ha az adózó a kötelezettség teljesítése mellett késedelmét annak igazolásával menti ki, hogy úgy járt el, ahogy az az adott helyzetben általában elvárható.`

## HU064 — Penalties

Failuretoissue/realconsideration andrecordkeeping up to2mHUF

- Act/article: Art. SZ228@BE1, SZ228@BE1@POA, SZ228@BE1@POB
- Official URL: https://njt.jog.gov.hu/jogszabaly/2017-150-00-00
- Read: 2026-10-30; Unchanged PR960 independent review reused; current official anchor inventory and 2026 applicability check
- Cached locator: art official HTML/block
- Exact native anchor(s):
  - `SZ228@BE1: (1) 370 Az adóhatóság az adózót kétmillió forintig terjedő mulasztási bírsággal sújthatja, ha`
  - `SZ228@BE1@POA: a) a számla-, egyszerűsített számla-, nyugtakibocsátási kötelezettségét elmulasztja, vagy a számlát, egyszerűsített számlát, nyugtát nem a tényleges ellenértékről bocsátja ki, vagy`
  - `SZ228@BE1@POB: b) iratmegőrzési kötelezettségének nem tesz eleget.`

## HU065 — Penalties

Missingprintedinvoice/receipt retention: ceiling200k/500k*numbermissing usedorunused, notfixedautomaticfine

- Act/article: Art. SZ228@BE3
- Official URL: https://njt.jog.gov.hu/jogszabaly/2017-150-00-00
- Read: 2026-11-16; Changed/missing condition: current operative paragraph read
- Cached locator: art official HTML/block
- Exact native anchor(s):
  - `SZ228@BE3: (3) 371 Ha az adózó iratmegőrzési kötelezettségének a nyomdai úton előállított számla, nyugta megőrzésének elmulasztásával nem tesz eleget, függetlenül attól, hogy a számla, illetve nyugta felhasználása ténylegesen megtörtént-e, a kiszabható mulasztási bírság összege természetes személy esetén kettőszázezer forint, nem természetes személy adózó esetében ötszázezer forint és a hiányzó számlák, illetve nyugták számának szorzata által meghatározott összegig terjedhet.`

## HU066 — Penalties

Shortfall50%,200%hiddenincome/false/destroyedrecords; lateinterestbaserate+5pp/365

- Act/article: Art. SZ215@BE3, SZ215@BE4, SZ209@BE1
- Official URL: https://njt.jog.gov.hu/jogszabaly/2017-150-00-00
- Read: 2026-10-30; Unchanged PR960 independent review reused; current official anchor inventory and 2026 applicability check
- Cached locator: art official HTML/block
- Exact native anchor(s):
  - `SZ215@BE3: (3) Az adóbírság mértéke – ha e törvény másként nem rendelkezik – az adóhiány, illetve jogosulatlan igénylés ötven százaléka.`
  - `SZ215@BE4: (4) 356 Az adóbírság mértéke az adóhiány, illetve jogosulatlan igénylés kétszáz százaléka, ha az adóhiány a bevétel eltitkolásával, hamis bizonylatok, könyvek, nyilvántartások előállításával, felhasználásával, illetve a bizonylatok, könyvek, nyilvántartások meghamisításával, megsemmisítésével függ össze.`
  - `SZ209@BE1: (1) A késedelmi pótlék mértéke minden naptári nap után a késedelem, illetve az esedékesség előtti igénybevétel (felszámítás) időpontjában érvényes jegybanki alapkamat 5 százalékponttal növelt mértékének háromszázhatvanötöd része.`

## HU067 — eÁfa/audit

Approvedweb/M2Mdraftisfiling; unapprovedM2Mdraftdeletedlastdaymonthafterdeadline;NAVdataauditselection

- Act/article: Áfa tv. SZ184@BE2@POB, SZ184@BE2@POC, SZ184@BE3, SZ184@BE4, SZ257G@BE5
- Official URL: https://njt.jog.gov.hu/jogszabaly/2007-127-00-00
- Read: 2026-10-30; Unchanged PR960 independent review reused; current official anchor inventory and 2026 applicability check
- Cached locator: vat official HTML/block
- Exact native anchor(s):
  - `SZ184@BE2@POB: b) Az adóalany az állami adó- és vámhatóság által az adó megállapításához az erre a célra biztosított elektronikus felületen rendelkezésére bocsátott adatokat kiegészíti, módosítja, az adólevonási jogáról és annak gyakorlásáról nyilatkozik, és az így előállított adónyilvántartásból összeállított bevallástervezetet ugyanezen a felületen bevallásként jóváhagyja.`
  - `SZ184@BE2@POC: c) Az adóalany az állami adó- és vámhatóság által közzétett módon és adatszerkezetben gépi interfész alkalmazásával továbbítja a fizetendő adó megállapításának és az adólevonási jog gyakorlásának alapjául szolgáló bizonylat szintű adatokat és az ezen adónyilvántartásból összeállított bevallástervezetet bevallásként gépi úton jóváhagyja.`
  - `SZ184@BE3: (3) A (2) bekezdés b) vagy c) pont ja szerinti bevallástervezet jóváhagyása a bevallás benyújtásának minősül.`
  - `SZ184@BE4: (4) Amennyiben az adóalany a (2) bekezdés c) pont ja szerinti adónyilvántartásból összeállított bevallástervezetet bevallásként nem hagyja jóvá, úgy a bevallási határidőt követő hónap utolsó napján az állami adó- és vámhatóság törli az adónyilvántartást és az abból összeállított bevallástervezetet.`
  - `SZ257G@BE5: (5) A 178. § (1a) bekezdés e, valamint a 10. és 11. számú melléklet szerinti adatokat az állami adó- és vámhatóság az Air. szerinti adózók ellenőrzéséhez, ellenőrzésre történő kiválasztásához és jogszabályban meghatározott egyéb feladata ellátásához használhatja fel az adó megállapításához való jog elévülési idején belül.`

## HU068 — Faultyreportdevelopers

NAVtellsdeveloper technicalcauses withoutbusinessdata, copyingissuer

- Act/article: Art. SZ131@BE30
- Official URL: https://njt.jog.gov.hu/jogszabaly/2017-150-00-00
- Read: 2026-10-30; Unchanged PR960 independent review reused; current official anchor inventory and 2026 applicability check
- Cached locator: art official HTML/block
- Exact native anchor(s):
  - `SZ131@BE30: (30) 236 Az állami adó- és vámhatóság hivatalból – a számla kiállítója, önszámlázás esetén a vevő egyidejű értesítése mellett – elektronikus úton tájékoztatja az online számlaadat-szolgáltatásra használt számlázó programnak az adatszolgáltatásban rögzített adószám alapján beazonosítható fejlesztőjét a hibás adatszolgáltatások okainak feltárásához és javításához szükséges, üzleti adatokat nem tartalmazó műszaki-informatikai információkról, valamint a számla kiállítójának nevéről és adószámáról, önszámlázás esetén a vevő nevéről és adószámáról.`

## HU069 — M sheets

Deductedreceivedinvoice supplierfirst8,baseVAT,number,date; eÁfaexemption; rewrittenrulesmayapplyperiodincludingJuly1

- Act/article: Áfa tv. ME10@MP9, ME10@MP9@MP.A, ME10@MP9@MP.B, ME10@MP9@MP.C, ME10@MP15, SZ380@BE0
- Official URL: https://njt.jog.gov.hu/jogszabaly/2007-127-00-00
- Read: 2026-10-30; Unchanged PR960 independent review reused; current official anchor inventory and 2026 applicability check
- Cached locator: vat official HTML/block
- Exact native anchor(s):
  - `ME10@MP9: 9. Az adóalany termék beszerzése, szolgáltatás igénybevétele esetén arról az adómegállapítási időszakról teljesítendő bevallásban, amelyben az ügylet teljesítését vagy az előleg megfizetését tanúsító számla alapján adólevonási jogot gyakorol, számlánként nyilatkozni köteles:`
  - `ME10@MP9@MP.A: a) a terméket értékesítő, szolgáltatást nyújtó adóalany adószámának, csoportos adóalanyiság esetén csoportazonosító számának első nyolc számjegyéről,`
  - `ME10@MP9@MP.B: b) a nevére szóló számlában feltüntetett adóalapról és áthárított adó összegről, a számla sorszámáról, valamint`
  - `ME10@MP9@MP.C: c) a számlában a 169. § g) pont ja szerint feltüntetett időpontról, ennek hiányában a számla kibocsátásának keltéről.`
  - `ME10@MP15: 15. Mentesül a 9–10. pont ban meghatározott nyilatkozattételi kötelezettség alól az az adóalany, aki (amely) bevallási kötelezettségét a 184. § (2) bekezdés b) vagy c) pont ja szerint teljesíti.`
  - `SZ380@BE0: 380. § 846 E törvénynek a Helyreállítási és Ellenállóképességi Terv végrehajtása érdekében szükséges adóintézkedésekről, valamint egyéb törvények módosításáról szóló 2026. évi XXXV. törvénnyel módosított 10. számú melléklet Számla befogadása című alcíme a 2026. július 1-jét magában foglaló adómegállapítási időszakról teljesítendő bevallások tekintetében is alkalmazható.`

## HU070 — Receipts

Paidconsumer/noinvoiceasked receipt; excludedtaxable/legalpersonand>=900kconsumer; e-receiptissuedonreceiptstorearrival

- Act/article: Áfa tv. SZ165@BE1@POB, SZ165@BE3@POA, SZ165@BE3@POB, SZ166@BE1, SZ166@BE1A, SZ174@BE2
- Official URL: https://njt.jog.gov.hu/jogszabaly/2007-127-00-00
- Read: 2026-10-30; Unchanged PR960 independent review reused; current official anchor inventory and 2026 applicability check
- Cached locator: vat official HTML/block
- Exact native anchor(s):
  - `SZ165@BE1@POB: b) 426 a termék beszerzője, szolgáltatás igénybevevője az ellenérték adót is tartalmazó összegét legkésőbb a 163. § (1) bekezdés a) pont jában, illetve a 164. § (1) bekezdés a) pont jában említett időpontig maradéktalanul megtéríti, és számla kibocsátását az adóalanytól nem kéri;`
  - `SZ165@BE3@POA: a) egy másik adóalany vagy nem adóalany jogi személy részére történik;`
  - `SZ165@BE3@POB: b) az a) pont alá nem tartozó személy, szervezet részére történik, és az ellenérték adót is tartalmazó összege eléri vagy meghaladja a 900 000 forintnak megfelelő pénzösszeget.`
  - `SZ166@BE1: 166. § (1) 434 Abban az esetben, ha az adóalany a 165. § (1) bekezdés ének b) pontja szerint mentesül a számlakibocsátási kötelezettség alól, köteles a termék beszerzője, szolgáltatás igénybevevője részére nyugta kibocsátásáról gondoskodni.`
  - `SZ166@BE1A: (1a) 435 Az e-nyugta a nyugtatárba való beérkezéssel minősül kibocsátottnak.`
  - `SZ174@BE2: (2) Az (1) bekezdés től eltérően e-nyugtát kiállítani, kibocsátani kizárólag elektronikusan lehet. A kibocsátott e-nyugtát a terméket beszerző, szolgáltatást igénybe vevő a nyugtatárban érheti el vevői alkalmazás segítségével.`

## HU071 — Receipt reporting

Otherreceipts3calendardays dailybyVATrate; extraordinarycashregistertemporarypadexception

- Act/article: Áfa tv. ME11@MP1, ME11@MP2
- Official URL: https://njt.jog.gov.hu/jogszabaly/2007-127-00-00
- Read: 2026-10-30; Unchanged PR960 independent review reused; current official anchor inventory and 2026 applicability check
- Cached locator: vat official HTML/block
- Exact native anchor(s):
  - `ME11@MP1: 1. Az adóalany a nyugta, nyugtával egy tekintet alá eső okirat, kivéve a pénztárgéppel kiállított nyugtákat, az e-nyugtákat, és az e-pénztárgéppel kiállított nyugtával egy tekintet alá eső okiratokat, e törvény szerinti adattartalmáról a kibocsátást követő 3 naptári napon belül köteles adatot szolgáltatni. Az adatszolgáltatást napi szinten összesítve, adómértékek szerinti bontásban kell teljesíteni.`
  - `ME11@MP2: 2. Az 1. pont ban foglalt adatszolgáltatási kötelezettség nem vonatkozik arra az esetre, amikor a pénztárgépet üzemeltető adóalany jogszabályban felsorolt rendkívüli körülmények fennállása miatt mentesül a nyugtaadási kötelezettség pénztárgép útján történő teljesítése alól és nyugta-kibocsátási kötelezettségét ideiglenesen nyomtatvány felhasználásával teljesíti.`
