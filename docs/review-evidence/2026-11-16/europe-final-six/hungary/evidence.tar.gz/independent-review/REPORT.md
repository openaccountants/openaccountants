# Hungary independent focused review

Reviewed 16 November 2026 by fresh independent AI reviewer `/root/review_li_fi`, separate from the writer. **PASS after focused closure of two review findings.** This is a source-supported partial pair, not accountant approval or comprehensive country coverage. No Guide, Git or public-system edits were made by this reviewer.

## Exact frozen Guides

- `skills/hungary/hungary-einvoice.md`: SHA256 `201a521235e6ac90989018916240b81d02ea5cf0832908f7082f1452ef60cd67`
- `skills/hungary/hungary-vat-return.md`: SHA256 `651dcf6d9fb205bc7b92bfec5a2fc3baf18e447b68ade0bced8e83bd2bfb3dfe`

Baseline assigned content: `bbab4f1a6d82cace432e6ca8eda89c98ffb1c038`. Final hashes independently match the stopped writer checkpoint. Shared-lane HEAD movement does not renew the legal review.

## Inventory and proportionate reuse

All **160 unique grouped ledger rows** were inventoried and receive individual outcomes/methods/support in RECEIPT.json: 71 apply to e-invoice, 90 to VAT, one shared. This is not a claim of 160 new statutory rereads or an invented individual-figure count.

Read canonical [PR960 review](https://github.com/openaccountants/openaccountants/pull/960#issuecomment-6529893297), whose original inventory is 104 plus 5 added rows. Independently compared retained reviewed e-invoice legal body with baseline: exact match, SHA256 `10f6200e36d22c2867a3cdd654b2a1f67e91d319af19525abd6a6a7729c6834a`. Retired metadata/CTA are outside the reused body. Its printed-pad fine conclusion is expressly reopened below; the original comment remains untouched.

VAT packet body SHA256 `3dd0dcc0ba98722728d0c65d28fce46f57693279f90fec9be885e8fced7dce59` matches its review binding. Baseline differs only in skill/Guide terminology. Six canonical review/evidence/figure/case/metadata/source artifacts are byte-exact original packet copies. Read its 17 figure records, 29 claim/locator records and six decision-case records. [PR700](https://github.com/openaccountants/openaccountants/pull/700#issuecomment-6362973159) supplies sibling corroboration only. Unchanged primary research and completed substantive review are reused after this one applicability check; absent original captures are not called new reads.

## Actual operative delta reads

Read cached current [VAT Act](https://njt.jog.gov.hu/jogszabaly/2007-127-00-00) native paragraphs and annex blocks: 82(1)-(4), Annex 3/B rows 1-3 and neighboring medicine exclusion; 163(1)-(2), 164(1)-(5), 167(c), 170(1)-(2); affected 124/125/125A restrictions and exceptions. Selected anchor text independently matches raw official HTML. Current official pages display the same 15 September VAT and 1 October Art time states.

[Act XL of 2026](https://njt.jog.gov.hu/jogszabaly/2026-40-00-00) section 4 and adjacent notes support 1 September commencement. The spent amending Act's later self-repeal does not reverse its incorporated current Annex 3/B. Prescription-only medicines and **human medicinal** magistral preparations have the stated zero-rate scope.

Read [Art 228(1)-(3)](https://njt.jog.gov.hu/jogszabaly/2017-150-00-00): `összegig terjedhet` sets a ceiling of HUF 200,000/500,000 times missing printed invoices or receipts, whether used or unused. Candidate correctly says up to; PR960's fixed-per-pad interpretation is superseded, not silently rewritten.

Invoice issue deadlines correctly distinguish the qualifying cross-border next-month 15th, paid/advance without-delay cases and 167(c) exception, and other charged-VAT eight-day cases. Aggregate/correction clocks are separately referred. Immediate software reporting is unchanged. Fuel, telephone and catering corrections retain actual statutory exceptions; business share or a bank name alone establishes no deduction.

The cached pinned NAV tree `cc7a775d6dce361311e409abb9934eb755f2749c` retains the 12 February 2026 edition. Inspected invoiceApi.xsd invoice/annulment batch declarations for the new case's 100-operation factor. Reused unchanged technical research; no new full API/schema audit. Also checked 149 available native quote strings against anchors without mismatch; that identity check is not presented as 149 fresh substantive reads. Exact local source hashes are in RECEIPT.json; raw/full documents remain local.

## Findings closed at the final hashes

1. New quick-reference law links incorrectly appeared to source technical schema/version/editorial facts, and VAT's new medicine quick-reference row cited only January guidance. Writer replaced these with actual NAV README/XSD/pinned specification/decree links and current Annex 3/B/Act XL links; internal version/companion facts moved to uncited editorial prose. Focused corrected-row check passed.
2. E-invoice's magistral wording lacked the human-medicinal condition. Writer added it to match the native annex and VAT Guide. Final wording checked.

No actionable finding remains. Only the corrections and affected sources were checked again; unchanged scans and full suites were not repeated.

## Cases and no loss

All three new controls independently recompute from raw assumptions: HUF 100,000 at 27% gives 27,000 VAT and 127,000 gross; 101 operations at maximum 100 need two requests, final batch one; 1,000,000 sales at 27% gives 270,000 output, less 135,000 input and 50,000 credit gives 85,000 payable. Main-sheet rows 36/76/82/83/84 are 270/135/50/85/85 in thousands. Arithmetic does not certify eligibility.

Six original bank-case input strings are byte-identical, including every date/name; no original monetary amounts existed to discard. Conditional Notion/Google/Studio Krebs/MediaMarkt outcomes remain under established invoice/contract premises. Restaurant/fuel cases now require actual restrictions/exceptions to be resolved. Also assessed the six prior review decision cases under their stated premises: monthly 2024 threshold, annual-test EU-number failure, below-minimum refund carry, 2025 startup monthly in 2026, 2026 exemption transition, established EU general-rule service on 18/67.

Rechecked all **171 preservation destinations**, including the semantic historical-v3.0 change-log mapping, and all **70 historical pattern rows**. Eight unsafe defaults/provider entities/import formats are explicit non-usable holds. Topics, names, original source/read limits, licence/tier 2 and case inputs remain; both Guides grew. No old case was simplified.

## Holds and boundary

Retain eleven existing e-invoice unresolved groups: historic threshold; schema 1/2 retirement; Art 221 call procedure; software declaration; rounding beyond NAV tolerance; ViDA/structured-invoice plans; eÁfa start; 13/C size limit; graduated-delay fines; Hungary/EU archive access; criminal sanctions. Provider entities, name-inferred VAT and universal bank formats remain non-usable. Client eligibility, specialist VAT, actual filing and accountant approval remain separate.

Parent owns committed-head validation, strict sync, shared tests and publication packaging. This reviewer did not rerun those gates or submit live forms. Review complete; file access stops on delivery so parent can commit/switch.
