# Eritrea: two-file writer recovery, 16 November 2026

**Ready for one independent source/no-loss/case review. Not approved for publication by this writer.** Exact candidate `0092c616a65666bd61e1a9dc7f2b0796fc6f4656` changes only `er-income-tax.md` and `er-tax-overview.md` from main `bbab4f1a6d82cace432e6ca8eda89c98ffb1c038`. Both remain unsigned, tier2. No push, PR, merge or release was performed.

## What was recovered

The completed15November writer packet at `L/lane-7/eritrea`, candidate `b2873bb676f1af2dd6878e8fabd050419849563e`, already contained both full drafts,80 rule groups,185 original populated-line destinations and actual official gazette bodies, scope receipts, OCR and image reads. All7 current-main country originals match that packet's baseline hashes. The independent reviewer was interrupted before a completed review; its inventory is empty. No full independent approval is invented or reused.

This work recovers that completed research rather than writing the same pack again. The old packet remains unchanged, including original read dates and incomplete check records. Only the assigned two skills are recovered. README and4 passing siblings remain exact. The old README's “Ready” status is based on the tax year and is not a currentness or accountant-approval claim; no country-wide clearance is claimed here.

Both files now declare their actual shape: income computation and overview decision/map with its existing company-versus-person worked comparison. Version0.3 is one step above current main0.2. Edit date16November is not represented as a fresh read of every law. Description and opening scope identify historical source-year law and require an explicit STOP before any current calculation or filing where later applicability cannot be established.

## Provenance and currentness

The previous sole UK-government translation citation is replaced by the original Eritrean gazette scan of Proclamation67/1995 plus the Eritrean Embassy's own RRT page. UK AnnexII is retained only as a clearly identified reading aid in local evidence; it is not primary Eritrean current law, a certified translation, or proof of a worldwide statutory base. The original Tigrinya scan was visually inspected for identity, numbered clauses and embedded English employment/net-income/treasury terms; no claim of an authoritative English original is made.

The original gazettes held by the US Library of Congress are historical facsimiles of Eritrean instruments, not evidence that the foreign archive establishes current Eritrean law. Their original source years and the15November actual scoped reads remain explicit. The Embassy's operative main page was opened again on16November: it corroborates eligible citizens abroad contributing2% of net income and its qualified US consular requirements/student statement/workflow. This does not establish universal payment dates, worldwide-base details or a complete2026 amendment chain. The existing local15November HTML hash is not passed off as a fresh16November response hash.

The Ministry of Justice's2023 inventory identifies instruments; it does not prove the absence of later amendments. Current consolidated law, later applicable instruments, fiscal-year dates and current domestic forms/payment/portal implementation remain unconfirmed and non-usable pending establishment. No broad new law hunt or paid service was used.

Historical access provenance is preserved here: the earlier work obtained gazette PDFs directly from the Library of Congress's ordinary public file host. Its item-page security check was not solved or bypassed. The old scans' Birr versus later Nakfa terminology remains distinguished; no unsupported currency conversion is introduced. No access-control, CAPTCHA or TLS bypass was used.

## Real corrections in the recovered work

The80-group ledger records each source and condition, including: correct origin/schedule article locators; direct-owner versus sublease rent allowance; receipt-year attribution rather than advice to declare half of advance rent in each year; the repealed Regulations20(2) loss restriction; full rural-craft/casual/diplomatic/bank-interest and foreign-representative conditions; the exact183-day conflict held rather than guessed; specific professional/import/export category limbs and prescribed books; appeal deposits and pending-payment rules; business-only scope of article63's20% penalty; receipt-penalty figures held because a Notice81 cover is not Proclamation138's operative text; stamp-duty petition exceptions; and no inference that a sales-tax framework proves absence of a later VAT/GST.

The recovered rent case had replaced the old raw `income:45000` input with a60000 gross-rent derivation. This recovery preserves both. It derives the45000 base from60000 less the25% allowance and checks zero difference against the original input. All4 original case inputs and all5 original expected outputs remain; the final4 blocks contain8 expected outputs. Independent writer Decimal controls check salary1064, allowance15000, rent base45000/tax8268, company30000, personal24768 and difference5232. These are source-year conditional illustrations, not current liability or incorporation recommendations.

## Honest historical farm placement and machine results

The complete recovered historical-farm row was already expressly non-operative because currency/current application and the2016 reform interaction are unconfirmed. Stock replay against exact retained official bodies exposed5 MISS: the scanned1994 gazette has no machine text while its linked2016 government news is readable but does not contain the older2/5/10/15/20% rates. This was not proof those old rates were wrong, nor a green result.

The complete four-cell payload, including every figure, threshold, condition and URL, was relocated into explicitly non-operative prose in Sources beside the existing farm hold. It is no longer presented as an operative rates row. HISTORICAL-FARM-RELOCATION.json proves full cell preservation, and the original five-MISS diagnostic is retained. No number was rewritten in words, source substituted, checker changed or bypass annotation added. Current farm rates remain genuinely held.

Final unmodified stock `read_bytes`/`check_text` replay against actual retained official response bodies: **22 rows,0 MISS,19 UNREADABLE** (income16/0/15, overview6/0/4). This is a cached-body replay, not a fresh network check. It uses the actual raw PDFs/HTML and stock extraction without OCR injection. Scan UNREADABLE results do not establish source verification; the independent actual-body review remains required. The old15November network report23/0/23 remains historical, not a final-head live result.

## Targeted checks and handoff

At initial recovery3a41d7da0: both standards returned{}, committed two-guide validation had0warnings,4oa-check blocks had0failures, strict sync2guides/0errors/0warnings, and calculator quotes passed with calculator files actually present. After the sole farm relocation, income standard{}, committed two-guide validation0warnings, strict sync2/0 and diff whitespace check passed. Unchanged cases, overview standard and quoted operative rules reuse the applicable earlier targeted checks after exact byte/input/expected preservation; no repeated full repository suite or source/case audit was run.

RULE-LEDGER.json binds80 groups to actual source bodies/hash/date/scope and current destinations. OLD-TOPICS-DESTINATIONS.json maps all185 populated main-original lines, including rejected unsupported claims retained in holds. ORIGINAL-CASE-PRESERVATION.json proves raw inputs/expected outputs. PROTECTED-SIBLINGS.json binds5 unchanged siblings/README. Recovered input hashes bind the immutable earlier packet. No people's names, `reviewed_by`, approvals, credits, CTA or calculator source quotes were added or changed.

The independent reviewer must inspect the complete80 groups, old-topic semantics and4cases once, using the completed actual official-body research and current applicability holds. Required GitHub gates remain for publication. This handoff is neither accountant approval nor a claim that Eritrea's entire2026 tax law is now confirmed. Raw source PDFs, images, full OCR, archives and HTML remain local; public outputs should contain own ledgers, reports and hash/scope receipts only.
