# Albania optimization: writer handoff for independent review

Status: **READY FOR INDEPENDENT REVIEW**, not a legal PASS or accountant approval.

- Candidate: `33152686ace007ffc7b3c51ed2f82d70c7c4a42b` on `world/codex-albania-optimization-2026-11-16`.
- Official fresh main/base: `bbab4f1a6d82cace432e6ca8eda89c98ffb1c038`.
- Worktree: `/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-resume-2026-11-16/wt-albania-optimization`.
- Only changed path: `skills/albania/albania-tax-optimization.md`. Clean local commit; no push or PR.
- The root reservation assigns this exact file to this writer; publication and merges remain with root.

The existing planning guide is rewritten as a declared decision method, with the original identity/license/tier/human credit preserved. All eight other Albania country files, including README, are byte unchanged. No reviewed_by/reviewed_on existed or was added. Two new arithmetic cases contain 19 expected outputs; there were no original case blocks or inputs to alter.

## Corrected and strengthened

| Original problem | Candidate result | Primary authority |
|---|---|---|
| No declared shape, canonical method or recomputing comparisons | Decision method with complete facts, scoped options, cap-edge and individual/company retained/distributed cases | Repository standard; tax inputs bound below |
| Company “profit above the threshold” could imply a profit allowance | Gross-income eligibility first, then corporate tax on the whole taxable profit when it fails | Law29/2023 arts.41,69(1)(dh) |
| Company comparison omitted the consequence of distributing profits when company income tax is zero | Corporate and shareholder taxes expressly separate; individual gross dividends remain taxable; retained company funds are not personal cash | Arts.24(3)–(4),58–59 |
| March status-declaration language lacked the following-year clarification and detailed evidence | Native instruction12.8.1 following-year timing, reclassification and Annex1 facts retained; no declaration-only safe harbour | Lawart.12,Annex1; Instruction26 paras.12.8–12.9,61 |
| Voluntary VAT election appeared without commitment/turnover qualifications | Standard and rolling tests, scoped exclusions, proportionate new-registration rule, election lock/exit and no-input-credit restrictions alongside the existing threshold | VATlaw117–122; VKM953art.11 |
| Historical contribution decision prints old fixed sums | Current official2026 bases combined with compulsory percentage rules; derived14900 minimum, coverage exclusions and separate obligation explicit | VKM77ch.III(6)–(7); GDT14Jan2026notice |

## Removed and why

Only unsupported rhetoric (“extremely efficient” and the assertion that a single-client freelancer is the “primary” target) and duplicate legacy title/version headings were removed. All associated operative warnings, rates and burdens remain. The detailed disclaimer is retained under the canonical referral section. No old rule, refusal, source URL, research gap or protected person name was silently discarded.

## Moved / Not moved

Quick reference is now in Scope. Existing regime, single-client and red-line material is in the ordered method, boundary/referral sections and completion checklist. Source dates now identify actual freshly read provisions. Full no-loss destinations cover all66 original populated lines, including compound claims and allfive old prohibitions. No topic moved into another file; unchanged owners remain explicit dependencies for complete tax/VAT/contribution/payroll and cross-border work.

## Actual source scope and holds

Read READ-SCOPES.md and SOURCE-SCOPES.json before using the ledger. Seven operative official sources and two official index bodies were actually read within stated scopes; full PDFs/captures and eight visually inspected page images are preserved locally. The supplementary presidential native request was refused403 and is not claimed read; the official amending PDF supplies its promulgation recital. These are official law/instruction copies, not private summaries or bills. No exact Gazette day, all-page/full-country review, source-freshness promise beyond this reading, or accountant approval is claimed.

**Narrow real hold:** statutoryart.12/Annex1 use services only to non-residents OR only to entities without an Albanian PE. Instruction12.9 describes non-residents without an Albanian PE. The candidate preserves the statute and explicitly refuses automatic treatment where a case depends on that wording difference. It also keeps the four original holds: exact anti-fragmentation aggregation provision; multiple activities of one person for gross eligibility; own-contribution deductibility; future extension beyond expiry. No usable tax recommendation is based on those unknowns. Salary and special coverage questions remain outside the simplified comparison and require the owner/fact review.

## Review units

- RULE-LEDGER.json/.md:47 groups,79 exact native quote/hash bindings with official URL, read date and relevant complete extract.
- OLD-LINE-DESTINATIONS.json and OLD-TOPICS-DESTINATIONS.md: all66 original populated lines, with semantic explanation and exact candidate destinations, not heading-only matching.
- CANDIDATE-ITEMS.json: all160 populated candidate lines classified; structure is separated from operative prose, conditions, arithmetic, sources and holds.
- CASE-RECOMPUTATION.json: source-qualified eligibility and manual Decimal recomputation for both cases/all19 outputs, independent of the oa-check interpreter but performed by the writer, not a separate reviewer.
- PROTECTED-CONTINUITY.json: allnine country-file before/after bindings and eight unchanged siblings/README.
- COMMIT-RECEIPT.json/candidate.diff: exact clean one-file local checkpoint and original main.

## Checks and limits

The targeted19-check standard, required two-case checker, changed-only validation(one guide,zero warnings), direct origin/main strict version/metadata integrity(one guide,zero errors/warnings/notices), calculator quotes and whitespace checks pass. Live row sources:8 rows,0 MISS,0 UNREADABLE. Unmodified-checker replay of preserved native bodies also8/0/0. These results do not replace review of every operative claim and neighbouring exception.

CHECK-RESULTS.json points to terminal logs. Initial missing-PyYAML attempts and missing-origin/main invocation/fallback are preserved in checks/SETUP-ISSUES.md and the original logs. Reusing the existing pinned venv and fetching the correct official base fixed the setup without guide/checker waivers. No full repository suite was repeated for this one-file content change; required hosted CI remains. Root should assign a fresh independent full review of this rewritten guide and its scoped dependencies before any push/PR.
