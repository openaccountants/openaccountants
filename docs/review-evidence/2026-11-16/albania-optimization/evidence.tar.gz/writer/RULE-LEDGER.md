# Albania optimization rule ledger

Every operative group below binds exact native words to a hashed body and a candidate destination. Repetition in the answer layer shares the same group. Workflow, arithmetic and held issues are explicitly separated. A source quote is not a claim that the whole law was reviewed.

## AL01 — Calendar tax year; ordinary resident comparison only; ALL currency is a document convention.
Candidate lines: 24. Disposition: usable.
- [income-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligj-Nr.-29-2023-Per-Tatimin-mbi-te-Ardhurat-i-ndryshuar.pdf), `read-scopes/income-art6.txt`, native quote `b1307a4dfbbb5badf041990e9a49e738c1fdc24e695910eba883f4a864bc6281`: “Viti tatimor fillon më 1 janar dhe përfundon më 31 dhjetor të çdo viti kalendarik.” (read 2026-11-16).

## AL02 — Eligible traders/self-employed/entities, gross income at most14m, zero business tax to31Dec2029; no profession distinction added.
Candidate lines: 30. Disposition: usable.
- [income-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligj-Nr.-29-2023-Per-Tatimin-mbi-te-Ardhurat-i-ndryshuar.pdf), `read-scopes/income-art69.txt`, native quote `b1f26aa8577ab2e21bd94da70446dee3d020618ad0efffc43e7bf4e69c724946`: “me të ardhura bruto deri 14 milionë lekë në vit, norma e tatimit mbi të ardhurat 0% do të aplikohet deri më 31 dhjetor 2029.” (read 2026-11-16).

## AL03 — Failing gross-income eligibility removes whole concession; 14m gross test differs from taxable-profit band.
Candidate lines: 31. Disposition: usable.
- [income-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligj-Nr.-29-2023-Per-Tatimin-mbi-te-Ardhurat-i-ndryshuar.pdf), `read-scopes/income-art69.txt`, native quote `45b902705208e1935646021da4b4aa56a65d564052fcdad5f872d4247146ae65`: “me të ardhura bruto deri 14 milionë lekë në vit” (read 2026-11-16).
- [income-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligj-Nr.-29-2023-Per-Tatimin-mbi-te-Ardhurat-i-ndryshuar.pdf), `read-scopes/income-art24.txt`, native quote `f9a80ef5f46ea1599bf4d792704925f4b7758ad35160c0de69b4ef17254de60e`: “Të ardhurat neto të tatueshme (fitimi i tatueshëm) nga biznesi” (read 2026-11-16).

## AL04 — Individual ordinary15% taxable-profit up to14m and23%excess.
Candidate lines: 31. Disposition: usable.
- [income-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligj-Nr.-29-2023-Per-Tatimin-mbi-te-Ardhurat-i-ndryshuar.pdf), `read-scopes/income-art24.txt`, native quote `8abb307c5022282981cfd16129cbcb469c9cee59766815d003d2db68fdf33e1d`: “0 – 14 000 000 lekë 15% Mbi 14 000 000 lekë 23%” (read 2026-11-16).

## AL05 — Ordinary corporate15% taxableprofit, no corporategross-band treatment.
Candidate lines: 67. Disposition: usable.
- [income-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligj-Nr.-29-2023-Per-Tatimin-mbi-te-Ardhurat-i-ndryshuar.pdf), `read-scopes/income-art41.txt`, native quote `af324ec62602d448b14d9c57de2c7995d16cd357cef7b31e9448efa586132f63`: “Norma e tatimit mbi të ardhurat e korporatave është 15%.” (read 2026-11-16).

## AL06 — 80%or more direct/indirectsingleclient test;90%or more total fewerthan3.
Candidate lines: 32. Disposition: usable.
- [income-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligj-Nr.-29-2023-Per-Tatimin-mbi-te-Ardhurat-i-ndryshuar.pdf), `read-scopes/income-art12.txt`, native quote `9655968ab2d62fa681ecd812aa72efaa26d6a1128f827fd512f604156456663e`: “80 për qind ose më shumë e të ardhurave të fituara merren direkt ose indirekt nga një klient i vetëm; ose” (read 2026-11-16).
- [income-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligj-Nr.-29-2023-Per-Tatimin-mbi-te-Ardhurat-i-ndryshuar.pdf), `read-scopes/income-art12.txt`, native quote `8d813d53f1ed12e76ef35af453588f1deb9b8b50c3906e7bc3e6995f1ee5dc79`: “90 për qind ose më shumë e të ardhurave totale të fituara merren nga më pak se 3 klientë.” (read 2026-11-16).

## AL07 — Actual employment independently taxable; director/partner work not automatically business.
Candidate lines: 50. Disposition: usable.
- [income-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligj-Nr.-29-2023-Per-Tatimin-mbi-te-Ardhurat-i-ndryshuar.pdf), `read-scopes/income-art12.txt`, native quote `9fbe0c248d95aa1a5068ddba4c3d45104f1be37c0756eadf348b57b596514fd7`: “tatimpaguesi është i detyruar të ndjekë udhëzimet e paguesit” (read 2026-11-16).
- [income-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligj-Nr.-29-2023-Per-Tatimin-mbi-te-Ardhurat-i-ndryshuar.pdf), `read-scopes/income-art12.txt`, native quote `72ea47d72665ecd225bb500bcc1f5c83eca4b7c513087013a3bc47c4938d785a`: “shpërblimet dhe përfitimet e paguara nga shoqëria për ortakun e saj për punën e kryer për këtë shoqëri;” (read 2026-11-16).

## AL08 — Business category excludesart12employment; documentedlawfulbusinesscosts; resolveadjustments in owner.
Candidate lines: 50. Disposition: usable.
- [income-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligj-Nr.-29-2023-Per-Tatimin-mbi-te-Ardhurat-i-ndryshuar.pdf), `read-scopes/income-art13.txt`, native quote `db5f484a7d62a02b5eed7749c401f52f5dcfb31cd6b0e01eccb9e695a28dd7e1`: “nëse nuk janë përcaktuar si të ardhura nga punësimi sipas nenit 12 të këtij ligji:” (read 2026-11-16).
- [income-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligj-Nr.-29-2023-Per-Tatimin-mbi-te-Ardhurat-i-ndryshuar.pdf), `read-scopes/income-art13.txt`, native quote `c3512f4e9f08eb0321babb32dcd3e4fc47021132785fe4b1bc613999941629ea`: “pakësuar me shpenzimet përkatëse të dokumentuara dhe të kryera me qëllim fitimin, ruajtjen dhe sigurimin e të ardhurave.” (read 2026-11-16).

## AL09 — Fact-supported Annex1selfdeclarationregionalofficeaccompaniesannualbusinessreturn.
Candidate lines: 54. Disposition: usable.
- [income-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligj-Nr.-29-2023-Per-Tatimin-mbi-te-Ardhurat-i-ndryshuar.pdf), `read-scopes/income-art12.txt`, native quote `8e9d3d1266cc1640a570cabef601a9d5c7801ce7718ff2f1069c092a1f5902ba`: “vetëdeklaron, në deklaratën e statusit të vetëpunësuarit, pranë drejtorisë tatimore rajonale ku është i regjistruar” (read 2026-11-16).
- [income-instruction](https://tatime.gov.al/wp-content/uploads/2026/09/Udhezimi-nr-26-date-8.9.2023-Per-tatimin-mbi-te-ardhuart.pdf), `read-scopes/instruction-12.7-12.9.txt`, native quote `769ebdd58557ca5dcba39254f0289e0aaa6bd55b34c219d92414aaf3312386f7`: “e cila dorëzohet pranë drejtorisë tatimore rajonale ku është i regjistruar tatimpaguesi” (read 2026-11-16).

## AL10 — Following-yearMarchtiming, includingexplicit31Mar2026for2025in instruction; no isolatedstatuteMarchshortcut.
Candidate lines: 54, 175. Disposition: usable.
- [income-instruction](https://tatime.gov.al/wp-content/uploads/2026/09/Udhezimi-nr-26-date-8.9.2023-Per-tatimin-mbi-te-ardhuart.pdf), `read-scopes/instruction-12.7-12.9.txt`, native quote `ad6f4ae4f4f39522e83e71fc7513ed740087207a6ae8c0a6f13cedbc100ea033`: “që dorëzohet brenda muajit mars të vitit pasardhës, përfshirë edhe deklaratën e tatimit mbi të ardhurat personale nga biznesi që do të dorëzohet brenda datës 31 mars 2026.” (read 2026-11-16).

## AL11 — Statusformassessmenttoolnotconclusive;false/taxavoidancecanbereclassified.
Candidate lines: 54. Disposition: usable.
- [income-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligj-Nr.-29-2023-Per-Tatimin-mbi-te-Ardhurat-i-ndryshuar.pdf), `read-scopes/income-art12.txt`, native quote `db67d396721658c42d4d001032792774278b918e78f08cc56ad9ae22fd667d96`: “Kjo deklaratë shërben si mjet vlerësimi nga administrata tatimore” (read 2026-11-16).
- [income-instruction](https://tatime.gov.al/wp-content/uploads/2026/09/Udhezimi-nr-26-date-8.9.2023-Per-tatimin-mbi-te-ardhuart.pdf), `read-scopes/instruction-12.7-12.9.txt`, native quote `ee26ce7c30cde8e5a90a8a8c1f757904bf1def37ccaddd08abb43debe00318d8`: “Administrata tatimore ka të drejtën e rikarakterizimit të të ardhurave në rast se deklarimi është i pasaktë.” (read 2026-11-16).

## AL12 — ForeignexceptionstatutoryORallnonresidentsorallentitieswithoutPE;Annexnofiling.
Candidate lines: 55. Disposition: usable.
- [income-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligj-Nr.-29-2023-Per-Tatimin-mbi-te-Ardhurat-i-ndryshuar.pdf), `read-scopes/income-art12.txt`, native quote `162665d7a078c72efafc03b4a0a5fd4f6d6cd27a284aa8843faee86c02997cba`: “vetëm për persona jorezidentë në Republikën e Shqipërisë apo vetëm për entitete që nuk kanë një seli të përhershme në Republikën e Shqipërisë.” (read 2026-11-16).
- [income-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligj-Nr.-29-2023-Per-Tatimin-mbi-te-Ardhurat-i-ndryshuar.pdf), `read-scopes/income-art72.txt`, native quote `2132ba6ef4820e917eff9b1322644dcc727bae6583020778f13b23fa94c5da6b`: “Ky formular nuk plotësohet nëse individi i vetëpunësuar ofron shërbime vetëm për persona jorezidentë” (read 2026-11-16).

## AL13 — Instruction12.9narrowerdescription;case depending on difference held, not law replaced by instruction.
Candidate lines: 55. Disposition: limited: statutory wording preserved; disputed application held.
- [income-instruction](https://tatime.gov.al/wp-content/uploads/2026/09/Udhezimi-nr-26-date-8.9.2023-Per-tatimin-mbi-te-ardhuart.pdf), `read-scopes/instruction-12.7-12.9.txt`, native quote `5d45bab84a44b08b8c1aed2af030e589b74f13baec5e74b991990b0f7b96c32f`: “100 për qind të shërbimeve vetëm për persona jorezidentë, të cilët nuk kanë seli të përhershme në Shqipëri” (read 2026-11-16).

## AL14 — Mixedclientreceiptsandstaffdonotdefeatconcentrationrule; calculateboth;notuniversalselfemploymentcountsafeharbor.
Candidate lines: 55. Disposition: usable.
- [income-instruction](https://tatime.gov.al/wp-content/uploads/2026/09/Udhezimi-nr-26-date-8.9.2023-Per-tatimin-mbi-te-ardhuart.pdf), `read-scopes/instruction-12.7-12.9.txt`, native quote `070d43064476882bb3af6d0ada300f148269b6364a9e5c1faf806f3bd5e45e65`: “Rregulli sipas këtij paragrafi zbatohet dhe nëse i vetëpunësuari ka marrë ndonjë pagesë edhe nga ndonjë klient jorezident tatimor shqiptar.” (read 2026-11-16).
- [income-instruction](https://tatime.gov.al/wp-content/uploads/2026/09/Udhezimi-nr-26-date-8.9.2023-Per-tatimin-mbi-te-ardhuart.pdf), `read-scopes/instruction-12.7-12.9.txt`, native quote `c014e1ee9268ebc65534bf2baeea2478fc6764673114de0369ea7d03bf275283`: “Ky paragraf zbatohet pavarësisht nëse i vetëpunësuari ofron shërbime i vetëm apo ka edhe punonjës të papaguar të familjes, apo ka edhe të punësuar.” (read 2026-11-16).

## AL15 — Reclassificationusesnetbaseafterlawfulcostsandart22/23deductionsnotgrossinvoices;employment13%first2.04m23%above.
Candidate lines: 56. Disposition: usable.
- [income-instruction](https://tatime.gov.al/wp-content/uploads/2026/09/Udhezimi-nr-26-date-8.9.2023-Per-tatimin-mbi-te-ardhuart.pdf), `read-scopes/instruction-12.7-12.9.txt`, native quote `f6a7ec423f99683fdef2a476c9528d5908eb687cdc952668dbdf0c3eef154554`: “të ardhura të faturuara minus shpenzimet e zbritshme të biznesit” (read 2026-11-16).
- [income-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligj-Nr.-29-2023-Per-Tatimin-mbi-te-Ardhurat-i-ndryshuar.pdf), `read-scopes/income-art24.txt`, native quote `482918f07cd0c3ea042802cb5436ff805f880ebfad707d2a5cb9ce0ed2a869ed`: “0 – 2 040 000 lekë 13% Mbi 2 040 000 lekë 23%” (read 2026-11-16).

## AL16 — Annexfacts required:business/invoicing,duties,duration,controlsubstitutionmarketing,assetslocationhours,feesriskpenalties.
Candidate lines: 58. Disposition: usable.
- [income-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligj-Nr.-29-2023-Per-Tatimin-mbi-te-Ardhurat-i-ndryshuar.pdf), `read-scopes/income-art72.txt`, native quote `3e4da4f2394cf01b0e2f15dec3d27e96376864e447dae59e24a9a86fc9b7c239`: “Vlera e faturimit pa TVSH të kontraktuesit për individin e vetëpunësuar:” (read 2026-11-16).
- [income-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligj-Nr.-29-2023-Per-Tatimin-mbi-te-Ardhurat-i-ndryshuar.pdf), `read-scopes/income-art72.txt`, native quote `e896939ca2b83fc60072f6ad5f5890f593ccefce6a51cda2075adf2ff935aef5`: “A është e mundur që i vetëpunësuari të punësojë zëvendësues apo ndihmës” (read 2026-11-16).
- [income-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligj-Nr.-29-2023-Per-Tatimin-mbi-te-Ardhurat-i-ndryshuar.pdf), `read-scopes/income-art72.txt`, native quote `0f9c76c4ede92c93668494fb2c2cb57e500e8426d735231d73b73f59637e3def`: “A është e mundur që i vetëpunësuari të pësojë humbje financiare” (read 2026-11-16).

## AL17 — Own equipment alone not sufficient, no checklist score.
Candidate lines: 54. Disposition: usable.
- [income-instruction](https://tatime.gov.al/wp-content/uploads/2026/09/Udhezimi-nr-26-date-8.9.2023-Per-tatimin-mbi-te-ardhuart.pdf), `read-scopes/instruction-12.7-12.9.txt`, native quote `f35a72e5fed5f50954bc2fa8e04d8cb6847b33229e3339b988d34fe0aded0a10`: “Pavarësisht se ai përdor mjetet e tij personale në kryerjen e punës dhe faturon kompaninë” (read 2026-11-16).

## AL18 — Taxbase incomeminuslawfulexpenses;financialstatement adjustments forcompany;no automaticcontributiondeduction.
Candidate lines: 62. Disposition: usable.
- [income-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligj-Nr.-29-2023-Per-Tatimin-mbi-te-Ardhurat-i-ndryshuar.pdf), `read-scopes/income-art43.txt`, native quote `7f3a69aef9e132d8c566ccd186b7b2728013bcdb9767cdf03ca73464a73cf880`: “duke zbritur shpenzimet e zbritshme.” (read 2026-11-16).
- [income-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligj-Nr.-29-2023-Per-Tatimin-mbi-te-Ardhurat-i-ndryshuar.pdf), `read-scopes/income-art48.txt`, native quote `a91c2f861f4b3e057493488ae1bbe5b67d38e5bf42c9594ccd9950f4952bd73c`: “kryhen realisht për qëllim të realizimit të fitimit dhe në interes të biznesit, që janë të dokumentuara nga tatimpaguesi dhe që nuk janë objekt i ndonjë kufizimi” (read 2026-11-16).

## AL19 — Individualpersonal deductiondependsotherincome/threshold;onceonly;cases360kwhenannualincome>720k,nochild.
Candidate lines: 66. Disposition: usable.
- [income-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligj-Nr.-29-2023-Per-Tatimin-mbi-te-Ardhurat-i-ndryshuar.pdf), `read-scopes/income-art22.txt`, native quote `307623482f8a8f667ea6f8cf5243d54bfdd470699d902f67f72f7de9feda3257`: “një shumë prej 360 000 lekësh nëse të ardhurat vjetore janë mbi 720 000 lekë” (read 2026-11-16).
- [income-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligj-Nr.-29-2023-Per-Tatimin-mbi-te-Ardhurat-i-ndryshuar.pdf), `read-scopes/income-art23.txt`, native quote `439b038acd38bd4be35d5cca570132871a60240e95926ae76baa0daa0148bd8d`: “Zbritja personale mund të pretendohet vetëm një herë në një vit tatimor.” (read 2026-11-16).

## AL20 — Residentindividualdividend8%gross,nocostdeductionabsentstatutoryexception,withholding8%.
Candidate lines: 67. Disposition: usable.
- [income-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligj-Nr.-29-2023-Per-Tatimin-mbi-te-Ardhurat-i-ndryshuar.pdf), `read-scopes/income-art24.txt`, native quote `89556d63676d10ec8466e634de03e599b88190b46ef0cbb21fbf24e8ee0caf84`: “të ardhurat nga dividentët 8%;” (read 2026-11-16).
- [income-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligj-Nr.-29-2023-Per-Tatimin-mbi-te-Ardhurat-i-ndryshuar.pdf), `read-scopes/income-art24.txt`, native quote `67acb5bdf80eaa9f2b1cd9a6c2928b41bb43e630084998cbbd0fd1a7d06cdd56`: “Përveçse kur parashikohet ndryshe në këtë ligj, asnjë kosto nuk zbritet kundrejt të ardhurave nga investimi.” (read 2026-11-16).
- [income-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligj-Nr.-29-2023-Per-Tatimin-mbi-te-Ardhurat-i-ndryshuar.pdf), `read-scopes/income-art59.txt`, native quote `864001c642e1391a385833bbea1ad98068ef1af702150c48472a435b8cc3b2af`: “Norma e mbajtjes së tatimit në burim mbi dividendët është 8%.” (read 2026-11-16).

## AL21 — Corporatetax separatefromshareholderdistributiontax;retainedfundsnotpersonalcash;ownerworkremunseparate.
Candidate lines: 68. Disposition: usable.
- [income-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligj-Nr.-29-2023-Per-Tatimin-mbi-te-Ardhurat-i-ndryshuar.pdf), `read-scopes/income-art3.txt`, native quote `b50f29f1595894a73f103a7de115faad6dea372523c1f78afb4893b70a86f5b0`: “të ardhurat nga aksionet ose kuotat në çdo shoqëri” (read 2026-11-16).
- [income-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligj-Nr.-29-2023-Per-Tatimin-mbi-te-Ardhurat-i-ndryshuar.pdf), `read-scopes/income-art12.txt`, native quote `af4c3c3e724d54b092f196977c000d004606a8747fb71f2cfeaba077bad14b8d`: “shpërblimet dhe përfitimet e paguara nga shoqëria për ortakun e saj për punën e kryer” (read 2026-11-16).
- [income-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligj-Nr.-29-2023-Per-Tatimin-mbi-te-Ardhurat-i-ndryshuar.pdf), `read-scopes/income-art40.txt`, native quote `8b7c1199452bdab374c6ff5df662b7d78887b8250f971f7042b89baaea9e08e4`: “Tatimi i pagueshëm mbi të ardhurat e korporatave llogaritet duke aplikuar normat” (read 2026-11-16).

## AL22 — OldsimplifiedprofitrepealLaw9632chapterIII;forms2024only;no currentcontinuation.
Candidate lines: 70. Disposition: usable.
- [income-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligj-Nr.-29-2023-Per-Tatimin-mbi-te-Ardhurat-i-ndryshuar.pdf), `read-scopes/income-art71.txt`, native quote `1ec761fa51ed2ac84ad9fafd75a5afa868807c4d2b868fb729c35a9ef03a9576`: “kreu III i ligjit nr. 9632” (read 2026-11-16).
- [income-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligj-Nr.-29-2023-Per-Tatimin-mbi-te-Ardhurat-i-ndryshuar.pdf), `read-scopes/income-art69.txt`, native quote `55740269d38e89ef0df72a10446a2e25ca7665a84229effb0ce67eb69fc52c5a`: “për efekt të periudhës tatimore 2024, do të përdoren formularët dhe përgjegjësitë tatimore” (read 2026-11-16).

## AL23 — Sunset31Dec2029,ordinarycurrentrulesprojectiononlynofutureextensionpromise.
Candidate lines: 70. Disposition: usable.
- [income-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligj-Nr.-29-2023-Per-Tatimin-mbi-te-Ardhurat-i-ndryshuar.pdf), `read-scopes/income-art69.txt`, native quote `52923004dae036cdace44b3bbfb32ac5f11606fee8e415e2a17792466dd3d4fb`: “deri më 31 dhjetor 2029.” (read 2026-11-16).
- [income-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligj-Nr.-29-2023-Per-Tatimin-mbi-te-Ardhurat-i-ndryshuar.pdf), `read-scopes/income-art24.txt`, native quote `f9a80ef5f46ea1599bf4d792704925f4b7758ad35160c0de69b4ef17254de60e`: “Të ardhurat neto të tatueshme (fitimi i tatueshëm) nga biznesi” (read 2026-11-16).
- [income-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligj-Nr.-29-2023-Per-Tatimin-mbi-te-Ardhurat-i-ndryshuar.pdf), `read-scopes/income-art41.txt`, native quote `af324ec62602d448b14d9c57de2c7995d16cd357cef7b31e9448efa586132f63`: “Norma e tatimit mbi të ardhurat e korporatave është 15%.” (read 2026-11-16).

## AL24 — StandardVATcalendar10m,rolling12crossingearlier15dayendmonthapplication.
Candidate lines: 76. Disposition: usable.
- [vat-decision](https://tatime.gov.al/wp-content/uploads/2026/09/VKM-Nr.953-date-29.12.2014-i-ndryshuar.pdf), `read-scopes/vat-decision-art11.txt`, native quote `602d0da055044f9bb460204b075412de708517c8e98ce10d9589aa76328633c3`: “qarkullimi prej 10 000 000 (dhjetë milionë) lekësh në një vit kalendarik.” (read 2026-11-16).
- [vat-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligji-Nr.-92-2014-Per-tatimin-mbi-vleren-e-shtuar-ne-Republiken-e-Shqiperise-i-ndryshuar.pdf), `read-scopes/vat-117-122.txt`, native quote `3cead084da64d2fc7f25b0dc2195fc4e9f2f972d4d31ac9cb6a24695806e9a0d`: “gjatë 12 muajve të njëpasnjëshëm tejkalon kufirin minimal” (read 2026-11-16).
- [vat-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligji-Nr.-92-2014-Per-tatimin-mbi-vleren-e-shtuar-ne-Republiken-e-Shqiperise-i-ndryshuar.pdf), `read-scopes/vat-117-122.txt`, native quote `de0d6689a84accc28f8688c136bc626223b4c69dbcf6e37e10d995d8e27daf34`: “brenda 15 ditëve nga data e kalimit të kufirit.” (read 2026-11-16).
- [vat-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligji-Nr.-92-2014-Per-tatimin-mbi-vleren-e-shtuar-ne-Republiken-e-Shqiperise-i-ndryshuar.pdf), `read-scopes/vat-117-122.txt`, native quote `73428368dd9693e1389640514ce6c56e92ba538130a7c74ce91a71b7df19a257`: “dita e fundit e muajit kalendarik” (read 2026-11-16).

## AL25 — Notariesstate/privatebailiffszerothreshold incl exemptactivities;nonexhaustiveprofessionsnoblanketotherrule.
Candidate lines: 76. Disposition: usable.
- [vat-decision](https://tatime.gov.al/wp-content/uploads/2026/09/VKM-Nr.953-date-29.12.2014-i-ndryshuar.pdf), `read-scopes/vat-decision-art11.txt`, native quote `19a3e18196202f3acd71bf1c3f1602a675962cffc8c6c186e75d134f5c1fac4e`: “noter, përmbarues gjyqësor shtetëror dhe privat” (read 2026-11-16).
- [vat-decision](https://tatime.gov.al/wp-content/uploads/2026/09/VKM-Nr.953-date-29.12.2014-i-ndryshuar.pdf), `read-scopes/vat-decision-art11.txt`, native quote `34314c744c80ebb891e464b578dac5caa9a7e046ec1c144070ae2f0367c9a2b7`: “është zero, pavarësisht nga qarkullimi vjetor i tyre.” (read 2026-11-16).
- [vat-decision](https://tatime.gov.al/wp-content/uploads/2026/09/VKM-Nr.953-date-29.12.2014-i-ndryshuar.pdf), `read-scopes/vat-decision-art11.txt`, native quote `8694bce7b4ccc61a844af494b9d83262788ec34d230835f4314dfb09b96b0a9f`: “edhe nëse kryejnë veprimtari të përjashtuara sipas ligjit.” (read 2026-11-16).

## AL26 — VATturnoveralltaxablesuppliesinclspecifiedzeroratedwithoutVAT;notidenticalgrossincometest.
Candidate lines: 77. Disposition: usable.
- [vat-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligji-Nr.-92-2014-Per-tatimin-mbi-vleren-e-shtuar-ne-Republiken-e-Shqiperise-i-ndryshuar.pdf), `read-scopes/vat-117-122.txt`, native quote `e5d4340ec42bb00b51addf46e0019ffef022f221d26e32e35419c547850fa67a`: “përfshin qarkullimin e realizuar nga të gjitha furnizimet e tatueshme” (read 2026-11-16).
- [vat-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligji-Nr.-92-2014-Per-tatimin-mbi-vleren-e-shtuar-ne-Republiken-e-Shqiperise-i-ndryshuar.pdf), `read-scopes/vat-117-122.txt`, native quote `dd057f77c1fc6f3ced9238a40dc3ad7a5ab1220e915d2bed93952d08477cd7d0`: “pa përfshirë TVSH-në.” (read 2026-11-16).

## AL27 — VATinvestmentasset and incidentalfinancial/propertyexcluded;mainfinancial/propertycount.
Candidate lines: 77. Disposition: usable.
- [vat-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligji-Nr.-92-2014-Per-tatimin-mbi-vleren-e-shtuar-ne-Republiken-e-Shqiperise-i-ndryshuar.pdf), `read-scopes/vat-117-122.txt`, native quote `46ead530ed9b86e3b832a14192ebb000aec166bc022915ca23bd088dafab6db3`: “aktive të investimit dhe nuk mbahen me qëllim për t’u shitur;” (read 2026-11-16).
- [vat-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligji-Nr.-92-2014-Per-tatimin-mbi-vleren-e-shtuar-ne-Republiken-e-Shqiperise-i-ndryshuar.pdf), `read-scopes/vat-117-122.txt`, native quote `572d1109038784b4a2d28cd6d398945932ca40046ff7aa1861e9de8e6c6bfce6`: “por janë veprime aksesore;” (read 2026-11-16).
- [vat-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligji-Nr.-92-2014-Per-tatimin-mbi-vleren-e-shtuar-ne-Republiken-e-Shqiperise-i-ndryshuar.pdf), `read-scopes/vat-117-122.txt`, native quote `71c5eb29d5dda157f085a867400ff1793eeb43f8748e1cf339b91168e54f96b4`: “kur krijohen si rezultat i veprimtarisë ekonomike kryesore, bëjnë pjesë në qarkullimin vjetor” (read 2026-11-16).

## AL28 — NewregistrantsVATproportionateperiodthreshold.
Candidate lines: 77. Disposition: usable.
- [vat-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligji-Nr.-92-2014-Per-tatimin-mbi-vleren-e-shtuar-ne-Republiken-e-Shqiperise-i-ndryshuar.pdf), `read-scopes/vat-117-122.txt`, native quote `482719d7ce5bbb07bc194fb3b8eb8591877ba8ca95c4fc407670a3ef1da4348c`: “llogaritet në mënyrë proporcionale me periudhën nga data e krijimit (regjistrimit) deri në fund të vitit fiskal.” (read 2026-11-16).

## AL29 — VATsmallbusiness exclusions occasionalpropertyagricultureschemenonestablishedAlbanianservices,evasion.
Candidate lines: 77. Disposition: usable.
- [vat-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligji-Nr.-92-2014-Per-tatimin-mbi-vleren-e-shtuar-ne-Republiken-e-Shqiperise-i-ndryshuar.pdf), `read-scopes/vat-117-122.txt`, native quote `8eafb4cc3e6d805ea0bd952089b783ccc7ec9b6ba4bf7263a61cef0d8bc0e1e8`: “veprimtari ekonomike që përbën evazion fiskal” (read 2026-11-16).
- [vat-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligji-Nr.-92-2014-Per-tatimin-mbi-vleren-e-shtuar-ne-Republiken-e-Shqiperise-i-ndryshuar.pdf), `read-scopes/vat-117-122.txt`, native quote `cd77223a7655e3e53312241b21d82fabdbd29d20069e0e63880ffac434ab2ed5`: “furnizimet e kryera në mënyrë rastësore të pasurive të paluajtshme;” (read 2026-11-16).
- [vat-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligji-Nr.-92-2014-Per-tatimin-mbi-vleren-e-shtuar-ne-Republiken-e-Shqiperise-i-ndryshuar.pdf), `read-scopes/vat-117-122.txt`, native quote `031f0a98f534bcc3dd251bd51b97c4611c4fad683f46b36ee410c54568e2cc8f`: “aktivitetet e përfshira në skemën e prodhuesve bujqësorë;” (read 2026-11-16).
- [vat-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligji-Nr.-92-2014-Per-tatimin-mbi-vleren-e-shtuar-ne-Republiken-e-Shqiperise-i-ndryshuar.pdf), `read-scopes/vat-117-122.txt`, native quote `ea9e16d105f08680b1da7d9a73c5d01c95b9887f92f103a5878b20a54757306d`: “nuk është i vendosur në Republikën e Shqipërisë” (read 2026-11-16).

## AL30 — VoluntaryVATavailableonlyannualturnover>5m;2calendaryearlock;6monthsafterrequestexit.
Candidate lines: 78. Disposition: usable.
- [vat-decision](https://tatime.gov.al/wp-content/uploads/2026/09/VKM-Nr.953-date-29.12.2014-i-ndryshuar.pdf), `read-scopes/vat-decision-art11.txt`, native quote `4fd2e3311fa165ba3bcfab60918838bbe7b7b631c3f8e689ae84b2db05d412d1`: “nëse qarkullimi vjetor është më i madh se 5 000 000 (pesë milionë) lekë.” (read 2026-11-16).
- [vat-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligji-Nr.-92-2014-Per-tatimin-mbi-vleren-e-shtuar-ne-Republiken-e-Shqiperise-i-ndryshuar.pdf), `read-scopes/vat-117-122.txt`, native quote `e04cbb1db3dc9d908bfba513645974a4e8bed45d69ede7c3755fcf20d84cf095`: “jo më pak se 2 vjet kalendarikë.” (read 2026-11-16).
- [vat-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligji-Nr.-92-2014-Per-tatimin-mbi-vleren-e-shtuar-ne-Republiken-e-Shqiperise-i-ndryshuar.pdf), `read-scopes/vat-117-122.txt`, native quote `33b735046d43bbdb4f94f7ea11e9c70b81e464983786a6717001a7b9e94ad6e1`: “hyn në fuqi 6 muaj pas datës së paraqitjes së kërkesës.” (read 2026-11-16).

## AL31 — SmallbusinessVATnoinputcreditnochargetax;donotmodelwithout prices/credits.
Candidate lines: 78. Disposition: usable.
- [vat-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligji-Nr.-92-2014-Per-tatimin-mbi-vleren-e-shtuar-ne-Republiken-e-Shqiperise-i-ndryshuar.pdf), `read-scopes/vat-117-122.txt`, native quote `6b26809fa1f7c5075786e95e0ae8b721141dd8e272168346456b41c6249c58ea`: “nuk gëzojnë të drejtën e kreditimit të TVSH-së” (read 2026-11-16).
- [vat-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligji-Nr.-92-2014-Per-tatimin-mbi-vleren-e-shtuar-ne-Republiken-e-Shqiperise-i-ndryshuar.pdf), `read-scopes/vat-117-122.txt`, native quote `d5054e7cc616fc8d144bd183e57076ba7e62154648d1a62f1e4c9e64996b51b8`: “Këta persona nuk kanë të drejtë të llogaritin TVSH-në në faturë.” (read 2026-11-16).

## AL32 — Ordinarynonagriselfemploymentmandatory23%socialchosenbase>=min<=max;notprofit/incometaxlinked.
Candidate lines: 79. Disposition: usable.
- [contribution-decision](https://www.issh.gov.al/wp-content/uploads/2026/08/VENDIM-NR.-77-DATE-28.1.2015-PER-KONTRIBUTET-E-DETYRUESHME-DHE-PERFITIMET-NGA-SISTEMI-I-SIGURIMEVE-SHOQERORE-DHE-SIGURIMI-I-KUJDESIT-SHENDETESOR.pdf), `read-scopes/contribution-III-1-9.txt`, native quote `e2e43f1789178728d971576e4cc56e302672ef6d492d0c4df15579ea3f2830ee`: “me përjashtim të të vetëpunësuarit në bujqësi” (read 2026-11-16).
- [contribution-decision](https://www.issh.gov.al/wp-content/uploads/2026/08/VENDIM-NR.-77-DATE-28.1.2015-PER-KONTRIBUTET-E-DETYRUESHME-DHE-PERFITIMET-NGA-SISTEMI-I-SIGURIMEVE-SHOQERORE-DHE-SIGURIMI-I-KUJDESIT-SHENDETESOR.pdf), `read-scopes/contribution-III-1-9.txt`, native quote `0d8917d7feb70665ba43cb26e07a271eba2579e4edd4a999fac54290008697ab`: “në masën 23% të pagës, por jo më pak se paga minimale mujore” (read 2026-11-16).
- [contribution-decision](https://www.issh.gov.al/wp-content/uploads/2026/08/VENDIM-NR.-77-DATE-28.1.2015-PER-KONTRIBUTET-E-DETYRUESHME-DHE-PERFITIMET-NGA-SISTEMI-I-SIGURIMEVE-SHOQERORE-DHE-SIGURIMI-I-KUJDESIT-SHENDETESOR.pdf), `read-scopes/contribution-III-1-9.txt`, native quote `739cf5b1bce773ebf694c3c947837ce16df8e8ebf695d3f84e4536c1accf1112`: “sipas përcaktimit të vetë personit, deri në nivelin e pagës maksimale” (read 2026-11-16).

## AL33 — Health3.4%doublemin;2026base50000and100000,Jan1effective;oldcurrencyfiguresnotcurrent.
Candidate lines: 79. Disposition: usable.
- [contribution-decision](https://www.issh.gov.al/wp-content/uploads/2026/08/VENDIM-NR.-77-DATE-28.1.2015-PER-KONTRIBUTET-E-DETYRUESHME-DHE-PERFITIMET-NGA-SISTEMI-I-SIGURIMEVE-SHOQERORE-DHE-SIGURIMI-I-KUJDESIT-SHENDETESOR.pdf), `read-scopes/contribution-III-1-9.txt`, native quote `74e4a7aedcfc97b072c341dcfbd5ee621145cdc7c01133475c869899980a1c3a`: “në masën 3.4% të dyfishit të pagës minimale mujore” (read 2026-11-16).
- [contribution-2026](https://tatime.gov.al/nga-1-janari-2026-rritet-paga-minimale-dhe-maksimale/), `sources/contribution-2026.txt`, native quote `4aa0069258939119c1e8f299562ebcea553d35cd2acfcc81a9f0ec0be6e4146d`: “duke filluar nga data 1 janar 2026, është 50,000 lekë.” (read 2026-11-16).
- [contribution-2026](https://tatime.gov.al/nga-1-janari-2026-rritet-paga-minimale-dhe-maksimale/), `sources/contribution-2026.txt`, native quote `019596634c1fab8c7fd1165f8610a37feb49c464896242c7b72968a8114bf9cc`: “Sa dyfishi i pagës minimale, prej 100,000 lekë, për personat e vetëpunësuar” (read 2026-11-16).

## AL34 — Floor11500+3400=14900derived;zero taxnotzeroinsurance;specialcoverageexcludedfromexample.
Candidate lines: 79. Disposition: usable.
- [contribution-decision](https://www.issh.gov.al/wp-content/uploads/2026/08/VENDIM-NR.-77-DATE-28.1.2015-PER-KONTRIBUTET-E-DETYRUESHME-DHE-PERFITIMET-NGA-SISTEMI-I-SIGURIMEVE-SHOQERORE-DHE-SIGURIMI-I-KUJDESIT-SHENDETESOR.pdf), `read-scopes/contribution-III-1-9.txt`, native quote `e22b0a8d2097d64a93fa6859445cc3dbbf552a295e2a2e3355c3cade73ca9adb`: “të paguajë për vete një kontribut të detyrueshëm për sigurimet shoqërore” (read 2026-11-16).
- [contribution-2026](https://tatime.gov.al/nga-1-janari-2026-rritet-paga-minimale-dhe-maksimale/), `sources/contribution-2026.txt`, native quote `85bbc10fd5f10d9b43f04449003a0bc57eb13d864428534aed66749547677a38`: “paga minimale prej 50,000 lekë do të shërbejë edhe për llogaritjen e kontributeve” (read 2026-11-16).

## AL35 — Annualreturn31Marchfollowingyear;zero-income-taxbusinessstillreturn.
Candidate lines: 175. Disposition: usable.
- [income-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligj-Nr.-29-2023-Per-Tatimin-mbi-te-Ardhurat-i-ndryshuar.pdf), `read-scopes/income-art61.txt`, native quote `3478be6cbb81dc4ba63731be96a94031a24910bf8571901dcd22d1fb8f92edfb`: “jo më vonë se data 31 mars e vitit pasardhës” (read 2026-11-16).
- [income-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligj-Nr.-29-2023-Per-Tatimin-mbi-te-Ardhurat-i-ndryshuar.pdf), `read-scopes/income-art67.txt`, native quote `c040926dbc06a43ef78953a53b60eb76e48c0fb869640090e9c78a5de4b062d7`: “Çdo person fizik që kryen veprimtari ekonomike është i detyruar të dorëzojë deklaratën tatimore vjetore për të ardhurat nga biznesi.” (read 2026-11-16).

## AL36 — 2026return31March2027calendarapplication,notnewpromisedlawdate.
Candidate lines: 175. Disposition: usable.
- [income-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligj-Nr.-29-2023-Per-Tatimin-mbi-te-Ardhurat-i-ndryshuar.pdf), `read-scopes/income-art61.txt`, native quote `3478be6cbb81dc4ba63731be96a94031a24910bf8571901dcd22d1fb8f92edfb`: “jo më vonë se data 31 mars e vitit pasardhës” (read 2026-11-16).

## AL37 — CurrentconsolidationbaseeffectJan2024,newart22-24employmentJan2025;amend81statuspromulgatedJan2026Gazette+15days;nospecificJan1statusclaim.
Candidate lines: 194. Disposition: usable.
- [income-law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligj-Nr.-29-2023-Per-Tatimin-mbi-te-Ardhurat-i-ndryshuar.pdf), `read-scopes/income-art72.txt`, native quote `8aafa8610af7237b591373b0f8285065f097d7664930ba660e783efe703733c9`: “i shtrin efektet nga data 1 janar 2024” (read 2026-11-16).
- [income-amendment-81](https://tatime.gov.al/wp-content/uploads/2026/10/Ligj-Nr-81-2025-Per-disa-ndryshime-dhe-shtesa-ne-ligjin-nr.-29-2023-Per-tatimin-mbi-te-ardhurat-i-ndryshuar.pdf), `sources/income-amendment-81.txt`, native quote `7efed3ec8d32363ef4a47772d190c822815caa3309a982534778acf4abeed905`: “Ky ligj hyn në fuqi 15 ditë pas botimit në Fletoren Zyrtare.” (read 2026-11-16).
- [income-amendment-81](https://tatime.gov.al/wp-content/uploads/2026/10/Ligj-Nr-81-2025-Per-disa-ndryshime-dhe-shtesa-ne-ligjin-nr.-29-2023-Per-tatimin-mbi-te-ardhurat-i-ndryshuar.pdf), `sources/income-amendment-81.txt`, native quote `dc18dcf39bd1e9bee3718980653868361fe7d86ef120704e609cd8a10b38dc5d`: “Shpallur me dekretin nr. 18, datë 12.1.2026” (read 2026-11-16).

## AL38 — Artificialfragmentation prohibitedasplanningcaution;preciseLaw9920aggregationarticleunconfirmed
Candidate lines: 85. Disposition: held/not operative.

## AL39 — Samepersonmulti-activitygrossaggregationnotusablewithoutconfirmation
Candidate lines: 85. Disposition: held/not operative.

## AL40 — Own-contributiondeductibilityheld;casesagreedlawfulprofitdoesnotassumeanswer
Candidate lines: 87. Disposition: held/not operative.

## AL41 — Noextensionafter2029known;futurechangeunconfirmed
Candidate lines: 201. Disposition: held/not operative.

## AL42 — Residence/treaty/sectorincentivesoutsideordinarydecision,routetodedicatedowners
Candidate lines: 86. Disposition: workflow/scope/arithmetic, not independent law.

## AL43 — Maintainallfiveoldprohibitionsplusnoshamexpenses/contracts;licensedlocalreviewbeforeaction
Candidate lines: 167. Disposition: workflow/scope/arithmetic, not independent law.

## AL44 — Noapprovalclaimed,humancreditretained,originaldisclaimerpersistsunderrefusal
Candidate lines: 171. Disposition: workflow/scope/arithmetic, not independent law.

## AL45 — Askfactsandmethodcompletionsareworkflowrequirementsnotnewstatutoryduties
Candidate lines: 39. Disposition: workflow/scope/arithmetic, not independent law.

## AL46 — Case1eligibilityassumptionsandall7recomputedoutputs
Candidate lines: 91. Disposition: workflow/scope/arithmetic, not independent law.

## AL47 — Case2eligibilityassumptionsandall12recomputedoutputs;retainedvsdistributedcomparisonnotfullcostranking
Candidate lines: 123. Disposition: workflow/scope/arithmetic, not independent law.
