# Complete old-topic and populated-line destinations

All 66 populated original lines are mapped in OLD-LINE-DESTINATIONS.json. No original worked cases, oa-check blocks or case inputs existed. All old substantive rules and five prohibitions remain, with two unsupported rhetorical rankings removed and gross-threshold/company-profit ambiguity corrected. All four original research gaps remain unusable.

| Original lines | Topic and semantic destination | Disposition |
|---|---|---|
| 1 | YAML structural fences remain. Candidate 1, 18, 29, 53, 65, 75, 84, 192. | preserved/restructured |
| 2 | Exact original identity/place/year/category/license/tier/domain value retained. Candidate 2, 98, 132. | preserved/restructured |
| 3 | Same planning job, triggers and out-of-scope owner jobs retained; operative numeric claims moved from metadata into cited answer/method rows. Candidate 3, 22, 46. | preserved/restructured |
| 4 | Version0.4to0.5 and actualread/update date advanced for substantive one-file rewrite. Candidate 4, 8. | updated metadata |
| 5 | Exact original identity/place/year/category/license/tier/domain value retained. Candidate 6. | preserved/restructured |
| 6 | Exact original identity/place/year/category/license/tier/domain value retained. Candidate 7. | preserved/restructured |
| 7 | Version0.4to0.5 and actualread/update date advanced for substantive one-file rewrite. Candidate 4, 8. | updated metadata |
| 8 | Exact original identity/place/year/category/license/tier/domain value retained. Candidate 14. | preserved/restructured |
| 9 | Exact original identity/place/year/category/license/tier/domain value retained. Candidate 15. | preserved/restructured |
| 10 | Exact original identity/place/year/category/license/tier/domain value retained. Candidate 16. | preserved/restructured |
| 11 | Exact original identity/place/year/category/license/tier/domain value retained. Candidate 17. | preserved/restructured |
| 12 | YAML structural fences remain. Candidate 1, 18, 29, 53, 65, 75, 84, 192. | preserved/restructured |
| 14 | Title/job/year retained; duplicate legacy skill/version headings replaced by canonical body and versionmetadata. Candidate 20, 7, 4. | consolidated duplicate headings |
| 16 | Title/job/year retained; duplicate legacy skill/version headings replaced by canonical body and versionmetadata. Candidate 20, 7, 4. | consolidated duplicate headings |
| 18 | Title/job/year retained; duplicate legacy skill/version headings replaced by canonical body and versionmetadata. Candidate 20, 7, 4. | consolidated duplicate headings |
| 20 | Tier2/notapproved/localadviser requirement retained, owner reconciliation explicit, actual source scopes and freshread dates in Sources replace oversized intro. Candidate 24, 35, 187. | preserved/restructured |
| 22 | Quick answer table retained in Scope, tableheader/separator structural only. Candidate 26. | preserved/restructured |
| 24 | Quick answer table retained in Scope, tableheader/separator structural only. Candidate 26. | preserved/restructured |
| 26 | Quick answer table retained in Scope, tableheader/separator structural only. Candidate 26. | preserved/restructured |
| 27 | Quick answer table retained in Scope, tableheader/separator structural only. Candidate 26. | preserved/restructured |
| 28 | Albania,ALLlek,calendaryear2026 retained explicitly. Candidate 24. | preserved/restructured |
| 29 | Albania,ALLlek,calendaryear2026 retained explicitly. Candidate 24. | preserved/restructured |
| 30 | Albania,ALLlek,calendaryear2026 retained explicitly. Candidate 24. | preserved/restructured |
| 31 | All eligiblepersonclasses,gross<=14m,wholeprofitzero,31Dec2029sunset andthresholdnotband retained withclassification restriction. Candidate 30, 62. | preserved/restructured |
| 32 | Whole ordinaryindividual15/23profitbands andcompany15 aftergrosslimitfail retained; nozero slice. Candidate 31, 66, 67. | preserved with ambiguity corrected |
| 33 | VATstandard10m,electiononly>5m retained; neighbouring conditions added. Candidate 76, 78. | preserved/restructured |
| 34 | All23%,50k,11500,3.4%,100k,3400,14900monthly inputs andoutputs retained, coverageandcalculation explicit. Candidate 79. | preserved/restructured |
| 35 | 31Marchfollowingyearretained andcalendarapplication2027 added. Candidate 175. | preserved/restructured |
| 36 | Singleclient80%direct/indirect,fewerthan3at90%,bothinclusive tests retained; actualemploymentrestrictionadded. Candidate 32, 48. | preserved/restructured |
| 38 | All eligiblepersonclasses,gross<=14m,wholeprofitzero,31Dec2029sunset andthresholdnotband retained withclassification restriction. Candidate 30, 62. | preserved/restructured |
| 40 | All eligiblepersonclasses,gross<=14m,wholeprofitzero,31Dec2029sunset andthresholdnotband retained withclassification restriction. Candidate 30, 62. | preserved/restructured |
| 42 | All eligiblepersonclasses,gross<=14m,wholeprofitzero,31Dec2029sunset andthresholdnotband retained withclassification restriction. Candidate 30, 62. | preserved/restructured |
| 43 | RepealofchapterIII9632and2024-onlyforms retained withcurrent-law citations. Candidate 70. | preserved/restructured |
| 44 | Whole ordinaryindividual15/23profitbands andcompany15 aftergrosslimitfail retained; nozero slice. Candidate 31, 66, 67. | preserved with ambiguity corrected |
| 45 | Corporate15% onentiretaxableprofitwhengrossconcessionfails, individualgrossdividend8%andnocostdeduction retained; ambiguousoldprofitabove threshold phrasingcorrected. Candidate 67, 68. | preserved/restructured |
| 46 | Sunset/futureordinaryratesprojectionconditionalonlawchange retained; noextensionpromise. Candidate 70, 185. | preserved/restructured |
| 48 | Substantivezero-business-taxopportunity retained; VAT/contribution burdens retained. Unsourced promotional extremelyefficient phrase removed. Candidate 33, 72. | unsupported rhetoric removed, rules preserved |
| 50 | Singleclient80%direct/indirect,fewerthan3at90%,bothinclusive tests retained; actualemploymentrestrictionadded. Candidate 32, 48. | preserved/restructured |
| 52 | Singleclient80%direct/indirect,fewerthan3at90%,bothinclusive tests retained; actualemploymentrestrictionadded. Candidate 32, 48. | preserved/restructured |
| 53 | Singleclient80%direct/indirect,fewerthan3at90%,bothinclusive tests retained; actualemploymentrestrictionadded. Candidate 32, 48. | preserved/restructured |
| 54 | Annex1fact-supporteddeclaration,regionalofficeannualreturnMarch,assessmenttoolreclassificationrisk retained andfollowingyearclarified. Candidate 54, 58. | preserved/restructured |
| 55 | Statutorydisjunctiveforeign-onlyexception retained; explicitlimitedhold forinstructionwordingdifference added, not silentlydiscarded. Candidate 55. | preserved/restructured |
| 57 | Employment13/23scale2.04m,not0,ownhours/equipment/risk evidence andMarchfacts retained. Unsourced primarytarget assertion replaced withgroundedtest. Candidate 56, 58, 54. | risk rule preserved, unsupported ranking removed |
| 59 | Alloldredlines/prohibitiontopics nowcanonicalrefusalsandboundaries. Candidate 165, 81. | preserved/restructured |
| 61 | Singleclient80%direct/indirect,fewerthan3at90%,bothinclusive tests retained; actualemploymentrestrictionadded. Candidate 32, 48. | preserved/restructured |
| 62 | Calendarandrolling12month10m,15daysendcrossingmonth,notary/bailiffregardless retained; neighbouring exclusions added. Candidate 76. | preserved/restructured |
| 63 | Sunset/futureordinaryratesprojectionconditionalonlawchange retained; noextensionpromise. Candidate 70, 185. | preserved/restructured |
| 64 | Noartificialsplittingwithoutsubstance retained asplanningcautionnotunsupportedstatutoryarticle. Candidate 85, 169. | preserved/restructured |
| 66 | Alloldredlines/prohibitiontopics nowcanonicalrefusalsandboundaries. Candidate 165, 81. | preserved/restructured |
| 68 | Firstoldprohibitioncap/sunset retained. Candidate 167. | preserved/restructured |
| 69 | Secondoldprohibitionnosafesingleclientretainedwithqualifiedexceptionsandnofiling-onlysafeharbor. Candidate 167, 54, 55. | preserved/restructured |
| 70 | ThirdoldprohibitionVAT/contributions retained, fullfigures stillmethod. Candidate 168, 72. | preserved/restructured |
| 71 | Fourtholdprohibitionpreserved asprimary-lawreconciliationduty, notblindlyfollowingstaleowner. Candidate 170, 35. | preserved/restructured |
| 72 | Fiftholdprohibitiongapsnotusableandlocaladviserreviewretained. Candidate 170, 24. | preserved/restructured |
| 74 | Sourcessectionandtable retained withactualreadscopes. Candidate 187, 191. | preserved/restructured |
| 76 | Sourcessectionandtable retained withactualreadscopes. Candidate 187, 191. | preserved/restructured |
| 77 | Sourcessectionandtable retained withactualreadscopes. Candidate 187, 191. | preserved/restructured |
| 78 | ExactofficialURLretained;newscopedreadactuallycompleted16Nov,oldoriginaldatepreservedinoriginal.md. Candidate 193. | preserved/restructured |
| 79 | ExactofficialURLretained;newscopedreadactuallycompleted16Nov,oldoriginaldatepreservedinoriginal.md. Candidate 196. | preserved/restructured |
| 80 | ExactofficialURLretained;newscopedreadactuallycompleted16Nov,oldoriginaldatepreservedinoriginal.md. Candidate 197. | preserved/restructured |
| 81 | ExactofficialURLretained;newscopedreadactuallycompleted16Nov,oldoriginaldatepreservedinoriginal.md. Candidate 198. | preserved/restructured |
| 82 | ExactofficialURLretained;newscopedreadactuallycompleted16Nov,oldoriginaldatepreservedinoriginal.md. Candidate 199. | preserved/restructured |
| 84 | All4oldunknownspreservedasnonusableholds:fragmentationarticle,samepersonactivityaggregation,owncontributiondeductibility,futureextension. Foreignexceptionwordingholdadded. Candidate 201, 85, 87. | preserved/restructured |
| 86 | Fullmaterialinformational/computationalnotadvice,noliability,professionalreview/signoff disclaimerretained undercanonicalrefusalheading. Candidate 171. | preserved/restructured |
| 88 | Fullmaterialinformational/computationalnotadvice,noliability,professionalreview/signoff disclaimerretained undercanonicalrefusalheading. Candidate 171. | preserved/restructured |
| 90 | Humancreditexactbytepreserved. Candidate 203. | exact protected credit |
