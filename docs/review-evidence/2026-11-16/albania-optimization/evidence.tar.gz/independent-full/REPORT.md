# Albania optimization: complete independent one-file review

**HOLD for one precise metadata term at `33152686ace007ffc7b3c51ed2f82d70c7c4a42b`. The complete operative body, source conditions, preservation and both cases otherwise pass.** No incorrect rate or arithmetic result was found. The correction below needs a small description-only review, not another full source or case audit.

Base: `bbab4f1a6d82cace432e6ca8eda89c98ffb1c038`. Candidate: `skills/albania/albania-tax-optimization.md`, SHA256 `361fd99eecdb5bfeeb6af1a630906723ab380856b524840bfa0021f776ea7cb0`. Review date: 16 November 2026. Reviewer: `/root/maldives_full_review_nov16`, independent of this guide's writer. This is source/no-loss/arithmetic review, not accountant approval or comprehensive Albania coverage.

## C01: use the gross-income condition in the separately served description

Line 3 says **“Includes the turnover cliff”**. Replace that phrase with **“Includes the gross-income cliff”**.

The actual [Income Tax Law](https://tatime.gov.al/wp-content/uploads/2026/09/Ligj-Nr.-29-2023-Per-Tatimin-mbi-te-Ardhurat-i-ndryshuar.pdf), art. 69(1)(dh), uses annual gross income for the concession. Article 3(11) separately defines turnover as sales of goods/services excluding VAT; art. 13 includes other business receipts. The operative guide correctly distinguishes income-tax gross income from VAT turnover. Its description can be served on its own by MCP/search, so that condition should remain equally precise there. This finding does not mean the guide's legal method or case arithmetic uses the wrong population. The exact source bodies and complete native provisions were read; no new rate or unsupported threshold interpretation is proposed.

## Complete population and source review

All 47 writer ledger groups were independently examined, including their conditions and neighboring provisions. All 79 native quote spans, quote hashes, extract hashes and official body hashes match; the complete extracts also belong to their native source text. This is not a sample or a lexical figure check. All 160 populated candidate lines were examined and bound to the frozen candidate, including metadata, scope, refusals, cases, source descriptions and credit.

The actual reading covered 26 relevant complete native extract units, the actual amending-law/Annex text, the full contribution notice and the two official index scopes. Eight preserved native PDF page images were actually viewed. Nine official bodies supplied those scoped reads: seven operative law/instruction/decision/notice sources and two legislation indexes. Cached official bodies were used directly; there was no repeat network-download exercise. Full primary texts, images and extracts remain at their existing local evidence paths and are not copied into this review.

Important checked conditions include:

- The gross-income concession covers the stated person classes, uses the complete annual gross-income limit, ends on the statutory date and has no zero-rate profit slice after eligibility fails. Ordinary individual taxable-profit bands and company tax apply to the correct bases.
- Actual employment, director/partner work, both inclusive concentration tests, the factual declaration, Annex 1 and reassessment powers are retained. Own tools or an invoice do not establish independent business status.
- The statute's disjunctive foreign-customer exception and the instruction's narrower wording are both preserved. A result depending on that difference remains explicitly non-usable. No resolution was invented.
- The declaration's same-period-with-business-return wording, the law's annual-return deadline and the instruction's express following-year procedure were examined together. The candidate expressly discloses the isolated statutory March wording rather than silently changing it. No exact Gazette date or first-day-of-year commencement for the new status provision is asserted.
- Company tax and resident individual dividends are separate; retained company money is distinguished from shareholder cash. Remuneration, costs, coverage and ordinary-resident assumptions limit the comparison.
- VAT calendar/rolling tests, month-end crossing date, registration period, non-exhaustive profession wording, turnover exclusions, proportionate initial period, election commitment/exit and no-input-credit restrictions were checked against the complete applicable law and decision provisions.
- The contribution percentages, non-agricultural coverage and chosen-base conditions were checked against the decision and the actual effective-2026 notice. Old printed fixed amounts are not treated as current. The minimum contribution calculation is correct.

The complete dispositions appear in `all47-independent-rule-review.json`. The four original research holds and the added foreign-customer wording hold remain non-usable. None was disguised as confirmed advice to obtain a pass.

## Preservation, identity and cases

All 66 original populated lines, including frontmatter/structure, have verified final destinations. Each substantive old rule, source URL, refusal, unknown and compound condition was checked for meaning. The only discarded material is explicitly reported unsupported promotional rhetoric and redundant legacy structure. Original corporate “profit above the threshold” ambiguity is corrected without dropping the company route. All five original prohibitions and the disclaimer's material protections remain.

The exact Michael Cutajar contribution line remains. The identity, jurisdiction, tax year, category, licence, tier and domain are unchanged; no review/approval field is added. All eight other country files are byte-identical. There were no original executable cases or inputs to remove.

Both new cases were independently recomputed using explicit Decimal arithmetic from their actual inputs, separate from the writer's recomputation and the oa-check interpreter. All 19 expected outputs match. Gross-income eligibility, the personal deduction, rate bands, ordinary contribution month and full lawful dividend assumptions were checked against the actual provisions. The results correctly distinguish retained and distributed company profit and avoid deciding the held own-contribution deduction. `independent-cases.json` contains every output and scope.

## Checks and disposition

The writer's complete 83-artifact seal was verified against final-manifest SHA256 `c02c91df762fe21f0789074d5d5ea1e4797fb2388f1c0efc4df81421503164b8`. The exact-head terminal logs show targeted standard checks passing, one-guide validation with zero warning groups, one-guide strict sync with zero errors/warnings/notices, both required cases with zero failures/missing, and passing calculator quotations/whitespace checks. Live stock and preserved-body replay each report eight eligible rows, zero MISS and zero UNREADABLE. Those eight numeric rows are smaller than the complete 47-group review population.

Completed repository suites and network checks were not repeated. The source/condition review, all original-line destinations and both case computations were independently completed here. Final composed hosted CI remains the publisher's required gate. C01 is the sole open finding; its exact description-only correction can reuse all unchanged completed work.

No candidate, prior record, source, author worktree, approval, PR or service was changed, and no commit, push, publication, merge or release was performed by this reviewer.
