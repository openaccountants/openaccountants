from pathlib import Path
from decimal import Decimal as D
import re,yaml,json,hashlib
R=Path('/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-resume-2026-11-16');W=R.parent/'world-finish-2026-11-14/lane-6/repository-philippines/skills/philippines';O=Path(__file__).parent
prior={x['name']:x for x in json.loads((R/'review-philippines-citation-d75ceb5d/independent-cases-11.json').read_text())['cases']}
def annual_tax(n):
 for floor,fixed,rate in [(8000000,2202500,'.35'),(2000000,402500,'.30'),(800000,102500,'.25'),(400000,22500,'.20'),(250000,0,'.15')]:
  if n>D(floor):return D(fixed)+(n-D(floor))*D(rate)
 return D(0)
out=[]
for f in sorted(W.glob('*.md')):
 if f.name in ['ph-income-tax.md','philippines-vat.md']:continue
 for raw in re.findall(r'```oa-check\s*\n(.*?)```',f.read_text(),re.S):
  c=yaml.safe_load(raw);name=c['name'];i={k:D(str(v)) for k,v in c['inputs'].items()}
  if name.startswith('Foreign domestic-market'):
   v={'filipino_share':i['filipino_employees']/i['direct_employees'],'alternative_share':i['alternative_filipino_employees']/i['direct_employees'],'capital_difference':i['general_capital']-i['qualifying_capital']}
  elif name.startswith('Capital increase'):
   sub=i['capital_increase']*D('.25');pay=sub*D('.25');v={'minimum_subscription':sub,'minimum_payment':pay,'unpaid_subscription':sub-pay}
  elif name.startswith('Domestic reduced-rate'):
   low=i['taxable_income']*D('.20');high=i['taxable_income']*D('.25');v={'income_headroom':i['income_limit']-i['taxable_income'],'asset_headroom':i['asset_limit']-i['qualifying_assets'],'alternative_excess':i['alternative_assets']-i['asset_limit'],'qualifying_tax':low,'alternative_tax':high,'tax_difference':high-low}
  elif name.startswith('MCIT age'):
   ordinary=i['taxable_income']*D('.25');minimum=i['mcit_gross_income']*D('.02');v={'first_mcit_year':i['commencement_year']+4,'following_year_count':i['taxable_year']-i['commencement_year'],'ordinary_tax':ordinary,'mcit':minimum,'tax_before_credits':max(ordinary,minimum),'excess_mcit':max(D(0),minimum-ordinary),'last_carryforward_year':i['taxable_year']+3}
  elif name.startswith(('Thirty thousand','Fifteen thousand')):
   s=i['msc']*D('.15')+i['ec'];h=i['income']*D('.05');both=s+h+D(400);other=s+h+D(200);v={'sss':s,'philhealth':h,'monthly_both':both,'annual_both':both*12,'monthly_other':other,'annual_other':other*12}
   if name.startswith('Thirty thousand'):v.update(pagibig_both=D(400),pagibig_other=D(200))
  elif name.startswith('Contribution ceilings'):
   s=i['max_msc']*D('.15')+30;h=i['health_cap']*D('.05');mandatory=s+h+400;optional=s+h+i['optional_pagibig'];v={'sss':s,'philhealth':h,'mandatory_monthly':mandatory,'mandatory_annual':mandatory*12,'optional_monthly':optional,'optional_annual':optional*12,'extra_savings':i['optional_pagibig']-400,'other_group_monthly':s+h+200}
  elif name.startswith('Resident citizen'):
   citizen=i['philippine_taxable_income']+i['foreign_taxable_income'];alien=i['philippine_taxable_income'];v={'citizen_base':citizen,'alien_base':alien,'citizen_tax':annual_tax(citizen),'alien_tax':annual_tax(alien),'tax_difference':annual_tax(citizen)-annual_tax(alien)}
  elif name.startswith('VAT-inclusive'):
   gross=i['quoted_price'];rate=i['vat_rate'];net=gross/(D(1)+rate);v={'inclusive_net':net,'inclusive_vat':gross-net,'exclusive_vat':gross*rate,'exclusive_total':gross*(D(1)+rate)}
  elif name.startswith('CPA fee'):
   fee=i['fee_base'];lo=fee*D('.05');hi=fee*D('.10');v={'lower_withholding':lo,'lower_cash':fee-lo,'default_withholding':hi,'default_cash':fee-hi,'cash_difference':hi-lo}
  elif name.startswith('Corporate professional'):
   fee=i['fee_base'];lo=fee*D('.10');hi=fee*D('.15');v={'higher_withholding':hi,'higher_cash':fee-hi,'qualifying_lower_withholding':lo,'qualifying_lower_cash':fee-lo,'withholding_difference':hi-lo}
  else:raise AssertionError(name)
  expected={k:D(str(n)) for k,n in c['expected'].items()};assert v==expected
  p=prior[name];assert hashlib.sha256(raw.encode()).hexdigest()==p['block_sha256'] and v=={k:D(n) for k,n in p['independent_recomputed'].items()}
  out.append({'file':f.name,'name':name,'raw_block_sha256':hashlib.sha256(raw.encode()).hexdigest(),'inputs':c['inputs'],'independent_values':{k:str(n) for k,n in v.items()},'expected_values':c['expected'],'pass':True,'prior_case_and_eligibility_continuity':'Entire raw block and surrounding parent prose unchanged by exact five-edit reconstruction; existing classifications retained, no new assumption.'})
assert len(out)==11 and sum(len(x['independent_values']) for x in out)==60
(O/'independent-cases-11.json').write_text(json.dumps({'head':'20e1ffff9af0e18ee09d0d214c38a2ebbe010b9c','method':'Fresh Decimal computation directly from all stated inputs and prior actually reviewed legal methods, including general six-band annual tax function; no candidate step evaluation.','cases':out,'case_count':11,'expected_outputs':60,'all_pass':True},indent=2)+'\n')
print('PASS:11cases/60intermediate-and-resultvalues')
