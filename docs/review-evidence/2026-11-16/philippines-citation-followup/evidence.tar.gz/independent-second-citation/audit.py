from pathlib import Path
import hashlib,json,re,subprocess,copy
R=Path('/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-resume-2026-11-16');W=R.parent/'world-finish-2026-11-14/lane-6/repository-philippines';E=R/'evidence-philippines-second-citation-delta';P=R/'review-philippines-citation-d75ceb5d';F=R/'review-philippines/delta-ffb2ef90';D=R/'philippines-hosted-figures-diagnostic';O=Path(__file__).parent
H='20e1ffff9af0e18ee09d0d214c38a2ebbe010b9c';B='d75ceb5d52047bd5921bde118483da7a21ec44c4';BASE='2844c309238b4fdb63be0a3d0ad9ae99a8ea89c8'
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_text())
def save(n,d):(O/n).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def git(*a):return subprocess.check_output(['git','-C',str(W),*a])
assert git('rev-parse','HEAD').decode().strip()==H and git('rev-parse','HEAD^').decode().strip()==B and not git('status','--porcelain').strip()
mf=load(E/'FINAL-MANIFEST.json');current=[]
for p,h in mf['files'].items():assert sha(Path(p).read_bytes())==h;current.append({'path':p,'sha256':h})
assert git('diff',B,H).decode()==(E/'committed-citation-only.patch').read_text()
assert git('diff','--name-only',B,H).decode().splitlines()==['skills/philippines/ph-tax-overview.md','skills/philippines/ph-withholding.md']
edits=load(E/'precise-edits.json')['edits'];assert len(edits)==5
appends={x['old_row']:x['new_row'] for x in edits if 'old_row' in x};inserts={x['new_source_row'] for x in edits if 'new_source_row' in x};assert len(appends)==3 and len(inserts)==2
files=[];old={};new={};lm={};alllines=[];recon=[]
for p in sorted((W/'skills/philippines').glob('*.md')):
 path=str(p.relative_to(W));a=git('show',B+':'+path);b=p.read_bytes();base=git('show',BASE+':'+path)
 assert b==git('show',H+':'+path) and a==(E/'before'/path).read_bytes() and sha(b)==mf['candidate_files'][path]
 old[p.name]=a;new[p.name]=b;aa=a.decode().splitlines();bb=b.decode().splitlines();j=0;mapping={};reconstructed=[]
 for i,t in enumerate(aa,1):
  while j<len(bb) and bb[j] in inserts:j+=1
  expected=appends.get(t,t);assert bb[j]==expected,(path,i)
  mapping[i]=j+1;alllines.append({'file':path,'parent_line':i,'current_line':j+1,'parent_text':t,'current_text':bb[j],'parent_sha256':sha(t.encode()),'current_sha256':sha(bb[j].encode()),'change':'precise citation append only' if expected!=t else 'exact unchanged text'})
  reconstructed.append(t);j+=1
 while j<len(bb) and bb[j] in inserts:j+=1
 assert j==len(bb)
 assert ('\n'.join(reconstructed)+'\n').encode()==a
 assert a.split(b'\n---',1)[0]==b.split(b'\n---',1)[0]
 assert re.findall(rb'```oa-check\s*\n.*?```',a,re.S)==re.findall(rb'```oa-check\s*\n.*?```',b,re.S)
 lm[p.name]=mapping
 files.append({'file':path,'parent_sha256':sha(a),'current_sha256':sha(b),'original_base_sha256':sha(base),'unchanged':a==b,'parent_reconstructed_exactly':True,'frontmatter_cases_people_disclaimers_holds_exact_except_five_citation_edits':True})
assert len(files)==8 and sum(x['unchanged'] for x in files)==6 and len(alllines)==1936
assert len([x for x in alllines if x['change']!='exact unchanged text'])==3
writerlm=load(E/'complete-parent-line-map.json')['rows'];assert len(writerlm)==1936
for x,y in zip(alllines,writerlm):assert (x['file'],x['parent_line'],x['current_line'],x['parent_text'],x['current_text'])==(y['file'],y['old_line'],y['new_line'],y['original_text'],y['destination_text'])
save('all-1936-parent-lines.json',alllines);save('all-eight-country-and-protected.json',{'head':H,'parent':B,'files':files,'method':'Full actual Git diff, exact reverse of3URLappends/2Sourcesinsertions, and exhaustive no-heuristic parent relocation, not field regex alone.'})
prior=[]
def verify(x,bucket):
 p=Path(x['path']);expected=x['sha256'];b=p.read_bytes();method='exact current physical evidence'
 if sha(b)!=expected:
  if p.is_relative_to(W/'skills/philippines'):
   matches=[]
   for head in [B,'ffb2ef90c95ba336b8bbc230999704f2000ac94f','dfde0b77c03702db11ea1578558c546e15b3d0f7']:
    blob=git('show',head+':'+str(p.relative_to(W)))
    if sha(blob)==expected:matches.append(head)
   assert matches,(bucket,str(p));method='exact prior Git blob at'+matches[0]
  elif p.name=='status.json':
   status=json.loads(b);status.pop('merge_clearance_notification');reconstructed=(json.dumps(status,indent=2)+'\n').encode();assert sha(reconstructed)==expected;method='same previously disclosed operational notification only; removal exactly reconstructs old status bytes'
  else:raise AssertionError((bucket,str(p),expected,sha(b)))
 prior.append({'bucket':bucket,'path':str(p),'expected_sha256':expected,'observed_sha256':sha(b),'method':method})
pm=load(P/'MANIFEST.json')
for x in pm['review_artifacts']:verify(x,'d75 independent artifact')
for x in pm['candidate_files']:verify(x,'d75 candidate')
chain=load(P/'prior-evidence-hash-continuity.json')
for x in chain['verified_bindings']:verify(x,x.get('continuity_bucket',x.get('bucket')))
assert sha((R/'review-philippines/manifest.json').read_bytes())=='c1b2c3f676877fed5af41b094580dc5a8df1c7918ce8751386c3f4b77fcfa5b8'
for x in load(D/'FINAL-MANIFEST.json')['files'].items():verify({'path':x[0],'sha256':x[1]},'preceding actual source diagnostic')
save('complete-prior-review-chain.json',{'head':H,'prior_manifest_sha256':sha((P/'MANIFEST.json').read_bytes()),'verified_bindings':prior,'prior_actual_scopes':load(R/'review-philippines/source-scopes.json'),'method':'Complete dfde full HOLD, ffb2 R1-R9 closure/held boundaries and d75 full citation-continuity reports read. Actual declared artifacts, bodies/images and population chains verified; no fresh291source reading claimed.'})
rule=load(P/'rule-continuity-291.json')['rows'];writer=load(E/'rule-bindings-291.json')['rows'];assert len(rule)==len(writer)==291
updated=[]
for x,y in zip(rule,writer):
 f=x['file'];assert y['file']=='skills/philippines/'+f and x['id']==y['id'] and sha(old[f])==x['candidate_sha256'] and sha(new[f])==y['new_candidate_sha256']
 z=copy.deepcopy(x);z['candidate_sha256']=sha(new[f]);z['head']=H;z['independent_second_citation_verdict']='PASS precise citation delta, complete prior substantive context preserved'
 z['additional_second_corroboration']=y['new_corroborating_source'];updated.append(z)
assert sum(x['additional_second_corroboration'] is not None for x in updated)==3
save('all-291-rule-continuity.json',{'head':H,'count':291,'rows':updated})
ol=[]
for x in load(P/'old-line-continuity-589.json')['rows']:
 f=x['file'];z=copy.deepcopy(x);assert git('show',BASE+':skills/philippines/'+f).decode().splitlines()[x['original_line']-1]==x['original_text']
 dest=[]
 for d in x['candidate_destination_actual_lines']:
  n=d['line'];assert old[f].decode().splitlines()[n-1]==d['text'];nn=lm[f][n];t=new[f].decode().splitlines()[nn-1]
  assert t==appends.get(d['text'],d['text']);dest.append({'parent_line':n,'line':nn,'text':t,'sha256':sha(t.encode())})
 z['candidate_destination_actual_lines']=dest;z['candidate_destination_start_lines']=[lm[f][n] for n in x['candidate_destination_start_lines']];z['candidate_sha256']=sha(new[f]);z['head']=H;z['second_citation_continuity']='Same actual substantive destination through exhaustive exact parent reconstruction; citation-only append where applicable, no fresh full original semantic review claimed.';ol.append(z)
assert len(ol)==589;save('all-589-original-line-continuity.json',{'head':H,'count':589,'rows':ol})
topics=load(P/'old-topic-continuity-120.json')['groups'];assert len(topics)==120
for x in topics:
 f=x['file'];assert sha(old[f])==x['candidate_sha256'];x['candidate_sha256']=sha(new[f]);x['head']=H;x['second_citation_continuity']='Prior full actual topic/hold interpretation preserved by exact reconstruction of every parent line, not a new heading-only inference.'
save('all-120-original-topic-continuity.json',{'head':H,'count':120,'groups':topics})
log=[]
for n in ['standards.json','validate.txt','examples.txt','sync.txt','calculator-quotes.txt','row-sources.txt','row-sources.exit']:
 p=E/n;log.append({'path':str(p),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size,'inspected':True})
assert load(E/'row-sources-summary.json')['rows']==93 and load(E/'row-sources-summary.json')['unreadable']==41 and load(E/'row-sources-summary.json')['miss']==0
assert (E/'row-sources.exit').read_text().strip()=='0'
save('inspected-local-checks.json',{'head':H,'logs':log,'source_summary':load(E/'row-sources-summary.json'),'method':'Exact current writer logs completely read/hash-bound, not redundantly rerun. Root separate hosted/live gates unclaimed.'})
save('SUMMARY.json',{'head':H,'parent':B,'writer_artifacts':len(current),'country_files':8,'unchanged_siblings':6,'parent_lines':1936,'citation_appends':3,'source_row_insertions':2,'prior_bindings_verified':len(prior),'rules':291,'original_topics':120,'original_nonblank_lines':589,'current_rules_or_figures_changed':0})
print(json.dumps(load(O/'SUMMARY.json')))
