from pathlib import Path
import json,hashlib,subprocess
R=Path('/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-resume-2026-11-16');W=R.parent/'world-finish-2026-11-14/lane-6/repository-philippines';O=Path(__file__).parent
V='c2e33e4e503901e4cdd2ab1d9940a77389c20bbe';I='20e1ffff9af0e18ee09d0d214c38a2ebbe010b9c';P='d75ceb5d52047bd5921bde118483da7a21ec44c4';M='81a11a1c5bc8624bed954b9e67118fa2f501cd29'
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git','-C',str(W),*a])
assert sha((R/'review-philippines-second-citation-20e1ffff9/MANIFEST.json').read_bytes())=='240d8006cd5cf22e98f31611ef056ee6fbbc46202bad7b93d5be4c1d49e742ad'
files=[];allchanges=[]
for path in git('ls-tree','-r','--name-only',V,'skills/philippines').decode().splitlines():
 a=git('show',I+':'+path);b=git('show',V+':'+path);main=git('show',M+':'+path);published=git('show',P+':'+path)
 assert main==published
 if b!=a:
  assert path in ['skills/philippines/ph-tax-overview.md','skills/philippines/ph-withholding.md']
  aa=a.decode().splitlines();bb=b.decode().splitlines();assert len(aa)==len(bb)
  changes=[{'path':path,'line':n,'old':x,'new':y} for n,(x,y) in enumerate(zip(aa,bb),1) if x!=y]
  assert len(changes)==2
  for c in changes:assert c['new']==c['old'].replace('version: 1.1','version: 1.2').replace('; version 1.1.','; version 1.2.')
  assert a==b.replace(b'version: 1.2',b'version: 1.1').replace(b'; version 1.2.',b'; version 1.1.')
  allchanges.extend(changes)
 files.append({'path':path,'reviewed_content_sha256':sha(a),'versioned_sha256':sha(b),'main_original_sha256':sha(main),'published_parent_sha256':sha(published),'main_original_exact_published_parent':True,'version_only':b!=a,'all_other_bytes_exact':True})
assert len(files)==8 and len(allchanges)==4
proof={'version_head':V,'reviewed_content_head':I,'published_parent':P,'verified_main_original_head':M,'files':files,'four_exact_version_changes':allchanges,'method':'Actual immutable Git blobs, all8main originals equal d75, all8c2 files equal20e after exact4version-string reversal. No law/case reread or branch/main merge approval inferred.','status':'Frozen version/main-original rebind PASS; final branch merge/checks to be bound separately.'}
(O/'FROZEN-VERSION-BINDING.json').write_text(json.dumps(proof,indent=2)+'\n')
print('PASS frozen version/main-original rebind:8files,4exactversionstrings')
