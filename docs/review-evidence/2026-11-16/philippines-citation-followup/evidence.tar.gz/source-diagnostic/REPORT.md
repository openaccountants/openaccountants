# Philippines hosted figure failures: exact diagnosis

Candidate: `d75ceb5d52047bd5921bde118483da7a21ec44c4`. Hosted run: `43892034388`, 16 November 2026. **No wrong figure or newly unsupported legal condition was found in the four reported misses. Three withholding misses have an exact source-loss explanation proven by the hosted log. The top-band response failure is only partly identifiable because that run did not save its response bodies.** Two narrowly scoped official corroborating citations are now actually read and available for root's correction.

This is a read-only diagnosis of these four misses, not a new full-country review, a green CI result or permission to merge. The hosted result remains **93 rows, 4 MISS, 58 UNREADABLE**. The previous local result at the same head was **93/0/41**. I did not randomly rerun the whole live country check or weaken the checker.

## Exact hosted withholding cause

The hosted ordinary-surcharge and fraud rows each link only to the Supreme Court's original NIRC and the ONAR RR6 scan. Both rows are reported UNREADABLE. Under the unchanged `check_text` implementation, that is possible only when **neither URL supplied readable text** for this run. These are the exact same URLs used on the section250 row.

The section250 row adds one source: the official BIR RR6 digest. That row is readable but misses 1,000 and 25,000. Therefore the digest was its sole readable source. Its actual complete text correctly contains **500 and 12,500**, for covered micro/small taxpayers, and does not contain the general 1,000/25,000 amounts. This is not evidence that the general amounts are wrong.

The missing2307 row also cites RR11. Whether RR11 was readable on that hosted run is not independently identified by the log, but its actual preserved text does not supply 1,000. With the same NIRC/ONAR losses, the checker also flags the **expressly rejected old universal 1,000 shortcut** as though it were a positive operative figure. That row does not impose an unconditional 1,000 assessment.

`exact-row-replay.json` reproduces all three exact misses with the actual current source texts, setting only the two log-proven unavailable sources to unreadable. It also reproduces the hosted UNREADABLE outcome for the two source-isolating rows. This is a deduction from actual log outputs and unchanged function semantics, not a guessed Cloudflare error or blanket permission to ignore failures.

## Actual legal reading and conditions

I freshly obtained the original NIRC through ordinary HTTPS and read the complete section250 paragraph with relevant neighboring247–251/255 provisions. Section250 covers each prescribed information return/statement/list/record/information failure, has the reasonable-cause/not-wilful-neglect exception, requires notice and demand, and sets the general **1,000 per failure / 25,000 calendar-year aggregate cap**. The historical section249 interest elsewhere in that original Act is not adopted as current.

I also read the complete actual EOPT45 from the previously recovered official Act cache: concession(d) provides the reduced500 fine for micro/small taxpayers. This is an actual cached-source reread, not an invented fresh network download. All three original RR6 pages were personally inspected as images, including scope, micro/small classification, the entire section5 paragraph, adjacent civil/interest/compromise provisions, prospective application and effectivity. The fresh ONAR PDF has exactly the earlier read hash. Section5 supplies **500 per failure / 12,500 calendar-year cap**, on notice and demand; section2 limits covered taxpayers by gross-sales classification. The ordinary and reduced branches are correctly distinguished in the skill.

RR11's complete 2.58(B) certificate paragraph and adjacent annual-information-return provision were read from the actual freshly retrieved body. Form2307 is the required CWT statement, with the source's furnishing and request conditions. This supports correcting/recovering the statement. It does not establish that every missing certificate receives a universal1,000 fee regardless of classification, offence or reasonable cause. The candidate's refusal of that shortcut is appropriate.

`actual-native-read-scopes.json` preserves full operative paragraphs and precise read boundaries, with source URLs/hashes and the RR6 image bindings. Fresh ordinary requests for all six originally relevant URLs succeeded locally. That does not retroactively claim they succeeded on the hosted runner.

## Top band: correct amount, partially observable transport failure

The actual RR8 PDF's complete page4 image was personally read, including the earlier2018–2022 table, section3 scope and full2023-onwards table. The current top band clearly prints **2,202,500 plus35% of the excess over8,000,000**. Its defective text layer does not yield that amount to the unchanged parser. The fresh PDF hash is the same as the previously diagnosed body. This is an actual visual/text-layer mismatch, not a proposed change to the tax figure.

The live official1701Q HTML currently supplies the same complete Table2 and the stock parser finds the amount. My direct ordinary GET succeeded while the separate web transport returned502. The hosted log did not save per-URL status/body/hash, so it does **not** establish whether its live-form request failed entirely or returned different text. I do not claim to know that lost response. An RR8-only replay precisely reproduces its single2,202,500 MISS; this establishes a sufficient mechanism, not the exact unsaved hosted response.

## Minimal truthful citation correction

No tax amount, computation, refusal or penalty condition needs changing. No figure should be rewritten in words, removed from the legacy warning merely to silence the check, or marked derived when it is directly printed law.

1. Add the actual [static official BIR1701Q PDF](https://bir-cdn.bir.gov.ph/local/pdf/1701Q%20Jan%202018.pdf) as corroboration on the overview top-band row. Preserve RR8's original regulatory citation and its visual evidence. I downloaded the blank public PDF, rendered/read complete page2 and both full six-band tables, and verified its text layer. Table2 is explicitly effective1January2023 onwards. The narrow scope is the top-band amount/rate/excess threshold, not new eligibility or filing instructions. Static PDF SHA256: `fdcce0ff83660bb831e8d95a5054a0fc7b924f049097b2ece6667318baaa49f5`.
2. Add the [BIR penalties page's complete NIRC250 reproduction](https://www.bir.gov.ph/penalties?q=penalties) as corroboration on the general information-return and missing2307 rows. Preserve the actual statute and RR6 sources, classification and reasonable-cause/notice conditions. I read the full250 paragraph and neighboring255-compromise/275 distinctions. The page's old20% interest elsewhere is explicitly outside this source's permitted scope and must not be used as current law. Body SHA256: `57cdb55756c5f59f3e2980675ee88025ba0f98108fc101daa4275ba5e6005399`.

Add honest Sources rows with actual16November read dates and those narrow scopes, update affected source/rule bindings, then obtain an exact citation-delta review. These are genuine independent official corroborations of already supported claims. They are not unrelated pages selected merely because they happen to contain the same numerals.

I tested the three proposed citation additions **in memory only**, using the unchanged candidate checker and keeping both proven-unreadable sources and the live form unavailable. All four target figure misses disappear, with every amount and condition unchanged. That result is limited to these three target rows; it is not a prediction that a future hosted run will have no network failures or that all58 unreadable rows are freshly cleared. Root must inspect the actual next hosted result.

## Evidence, privacy and integrity

The diagnostic directory contains ordinary-fetch metadata, exact source/extraction hashes, preserved raw bodies, image/read bindings, full native scope and the deterministic current/source-loss/proposed-citation replays. The official printer-friendly statute was also read and extracted successfully as an alternate view of the same full250 clause; it is not needed for the recommended two-source correction.

All raw response headers and live1701Q HTML/extraction remain **local-only**, because the form response may contain anonymous session/view identifiers. Do not attach those raw files to public comments. Public evidence can use this report, stable source URLs, source hashes, the static blank public PDF page, bounded native statements and the sanitized replay summary. No live form was filled, submitted or used to authenticate, and no session identifier is copied into this report.

The existing full original review, ffb2 R1–R9 closure and d75 citation-delta review were read as context. Their bounded source and non-operative hold conclusions remain intact. No current comprehensive coverage, new professional approval or new review of all291 groups is inferred from this four-miss diagnosis.

Only this new diagnostic directory was written. Candidate skills/code, prior source evidence, review records, Git state, approvals, database and live service remain unchanged. No push, PR, publication, merge, release or external message was sent.
