# Philippines final independent delta review

**PASS for the bounded source, content and no-loss review of `ffb2ef90c95ba336b8bbc230999704f2000ac94f`.** The nine findings from the original full review are resolved. Genuine source gaps remain explicitly non-operative, as allowed by the brief. This is not accountant approval, comprehensive Philippines coverage, or permission to merge/release or waive a required CI gate.

The stock figure checker remains exit 1: 93 rows, one disclosed OCR false MISS and 41 UNREADABLE. Its result is not called green. Actual source/image review supports the figures, as described below. Root must retain that evidence and respect the applicable publication checks.

## Exact scope and continuity

This is the same independent reviewer continuing the full `dfde0b77` review. I read all substantive changed paragraphs, every one of the 56 affected rule bindings and their applicable source/neighbor conditions, including all five new groups. The 235 unchanged groups reuse the prior actual source reading only after verifying exact source bytes, same read date and unchanged rule context. This is not represented as 291 fresh source openings.

The complete current population is **291 rule groups, 120 original-topic groups and 589 nonblank original lines**. Every topic and line destination was rebound to actual current candidate bytes. I checked the substantive destination changes, not just their existence or similarity. The original SSS criminal-registration topic now has a real destination; the B-2 lower-rate role is preserved; the PHP 15,000 case correctly maps to Case B. The original line-map's single invalid formation destination has been replaced with actual foreign-capital and historical-effectivity destinations, with the original report left intact.

Continuity checks independently confirmed:

- Original full review manifest remains `c1b2c3f676877fed5af41b094580dc5a8df1c7918ce8751386c3f4b77fcfa5b8`. All its reviewer artifacts remain unchanged.
- All **167 prior actually read source-artifact bindings** match. These include the recovered official Acts, agency PDF/text bodies and actual rendered tables. The 22-file before archive and every current writer-manifest binding match.
- Exactly five assigned skill files changed. README, `ph-income-tax.md` and `philippines-vat.md` remain byte-identical. All frontmatter, human fields, credits, both original full disclaimers, all 11 case blocks and inputs are unchanged from the previous reviewed candidate.
- No private Lawphil/taxcode operative URLs remain in the five corrected files. No new person or approval is added. The retired trust phrase is removed; “Not yet approved” is used.

Details are in `continuity-and-invariants.json`, `rule-review-291.json`, `old-topic-continuity-120.json` and `old-line-continuity-589.json`.

## R1–R9 closure

| Finding | Current location and independently checked closure |
|---|---|
| R1, stale AFS date | Formation 92 correctly uses FY ended 31 December 2025, general **15 June 2026**, precise domestic/foreign-office coverage, and separate **15 May 2026** 52-AR/issuer/public-company annual reports. Actual government PNA and later PIA bodies support that scope. Other fiscal-year 120 days has its separate actual government body; no 2027 deadline is invented. |
| R2, lost registration topic | Social 63 restores criminal failure/refusal of a covered SE person to register. Actual SSS body and RA11199 24(A)/28(e), with neighboring text, support it. It is distinct from contribution gaps; no new numeric criminal penalty is added. |
| R3, age-55 exception | Social 61 now includes the last-posted **immediately previous maximum** prerequisite, plus the under-55 rule, minimum floor and decrease conditions. The actual SSS operative paragraphs match. |
| R4, B-2 declaration | Withholding 79 restores eligible B-2/COR **5%** use separately from the lone-payer **PHP 250,000** exemption; the VAT override remains. The valid-exemption threshold-crossing rule applies withholding to the **excess**, with absent-declaration treatment retained. Actual RR11 professional declaration/excess paragraph and worked illustration, and actual RMC50 Q37 image, support the boundaries. |
| R5, GPP | Withholding 69–72 excludes a GPP's own professional receipts from both broad fee rows and separates partners' distributions/tax. Actual RMC50 Q35 image supports the exception. Corporate rates and case numbers remain unchanged. |
| R6, private sources | Five Act branches now cite actual official Supreme Court/PhilHealth bodies. TRAIN band/OSD/filing claims use the read official RR8/RR4 and applicable original NIRC; ordinary VAT uses actual EOPT17/19. Unavailable SEC and RA9679 branches remain explicitly unusable, preserving old topics. Current interest rates use actual RR6; the unsupported attribution of the interaction formula is removed and that original topic is held. See the precise residual scope below. |
| R7, case map | Original social 326–338 now maps to actual **Case B**, current 198–222, not Case A. All case figures and inputs are unchanged and independently recomputed. |
| R8, article reference | Withholding 146 correctly distinguishes original **24(D)(1)** charge/base from **24(D)(2)** principal-residence exemption, with current CMEPA24(B)(4). Actual full original paragraphs and renumbering support it; no rate changed. |
| R9, retired label | Current candidate introductions and formation refusal use “Not yet approved”. The two original full disclaimers and all named credits remain intact. Source-defined signed/attested income evidence was not blindly removed. |

I re-read the relevant cached source scopes for the changed conditions, including SSS change/registration paragraphs and criminal clause, RR11 B-2/excess provisions, official RR6 interest digest, EOPT17/19 and CREATE branch-numbering context. The newly used RR8 section10 business-filing paragraph was read with its neighbors. The full RR8 actual page4 table had already been independently viewed; its exact image bytes remain unchanged.

## Explicit source gaps, not operative instructions

The following gaps do not receive a legal/source PASS. They are acceptable only as clearly stated non-operative preservation:

- **SEC MC4/MC9:** formation 93/98/177 refuses to apply the unavailable audit/SMR rules. The held archive preserves the proposed 3-million asset-or-liability boundary, at/below SMR route, fiscal-year start, public-interest exclusions, SEC powers, ordinary/OPC signatories and delegation exception, foreign-office audit-test locator, foreign GIS anniversary and residual COA exceptions. The superseded 600,000 threshold is not restored as current. Actual government support for domestic GIS, other-fiscal-year 120 days and the precisely scoped June/May extension remains operative separately.
- **RA9679 section19:** social 145/284/294 does not grant a Fund/benefit/MP2 tax exemption from a private reproduction. That original topic is preserved unusable. Actual official Circulars274/460 still support the separate membership/contribution/savings rules; the government MP2 minimum/term description remains supported.
- **Interest interaction:** withholding 244 preserves the double-legal-rate formula and no-simultaneous deficiency/delinquency topic for official-source recovery. They are not falsely attributed to RR6. Actual RR6 establishes 6% as half the section249 rate; the ordinary 12% is explicitly derived, independently recomputed as 6% / 50%. A full assessment is refused without the remaining interaction/period evidence.
- The previously disclosed SEC fees, practical-capital/timing assertions, detailed Pag-IBIG487/499/500 features/channels and owner itemised-deduction questions remain held. No source recovery, quote match or source preparation is counted as comprehensive coverage.

## Calculations and validation

All **11 cases were independently recalculated again** against the current expected values, using Decimal formulas derived from the applicable legal bases rather than evaluating the candidate step expressions. Every intermediate and result agrees. The tax, fund-category, annual-income, residence, VAT-inclusive/exclusive and MCIT timing assumptions remain intact. Fresh results are in `independent-cases.json`.

Read-only checks rerun on this exact clean HEAD pass: five `skill_checks` results `{}`, changed-only validator zero warnings, 11 example blocks zero failures/missing, and strict sync zero errors/warnings/notices. Their independent logs are in this directory.

The unchanged stock figure checker was not rerun merely to repeat a known network/OCR failure. Its exact current terminal log and hash are retained. The sole MISS is **PHP 2,202,500** in the 2023-onwards top band: the actual complete official RR8 page4 image visibly prints **2,202,500.00**, 35%, excess over8,000,000; OCR emits a corrupt glyph string. The image SHA256 is `3a01c9fb92de66e3c904c281c421acdcd1691e4647721ff684328eaae1da72bd`. The 41 UNREADABLE rows reuse the prior complete actual RR7/SSS/Pag-IBIG table and government PhilHealth body review, with unchanged figures and hash-bound sources. This is source/visual reconciliation, not a clean direct-network result or checker modification.

Only independent reviewer artifacts were written. Skills, writer evidence, the original full review, Git state, PRs, database and live site were not modified. No public message, push, merge or release occurred. The attached manifest binds this exact candidate, source continuity, current writer package and independent final artifacts.
