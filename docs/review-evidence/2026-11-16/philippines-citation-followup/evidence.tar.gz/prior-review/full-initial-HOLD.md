# Philippines independent pack review, 16 November 2026

**Verdict: HOLD on exact candidate `dfde0b77c03702db11ea1578558c546e15b3d0f7`.** The calculations and mechanical checks pass. There are content, no-loss and official-source admission corrections below. This is independent AI source review, not accountant approval or a claim that the Philippines has comprehensive coverage.

## Scope and evidence

All eight original Philippines files were read, including README and the two Ryan PR #1336 paths. All five complete candidates, all 286 writer claim groups and all 120 old-topic groups were compared. `old-line-review-589.json` accounts for all 589 nonblank original lines in the five changed files. The line map is a semantic section map after manual comparison, not an automated claim that matching words proves no loss.

- `protected-and-originals.json` binds all eight originals and candidates. README, `ph-income-tax.md` and `philippines-vat.md` are byte-identical to the base. No `reviewed_by` or human identity was added or removed. Jonathan I. Ruiz's credit occurrences are preserved, including all three formation credits and both each in corporate, social and withholding. The two original full disclaimers are verbatim. There were no original calculator or CTA blocks.
- `claim-review-286.json` records a separate content and provenance disposition for every writer group. `old-topic-review-120.json` records every original-topic group, including the two no-loss defects and the case-map error.
- `source-scopes.json` records actual bounded reading and hashes. It separates full legal provisions, official agency digests, actual scanned pages/tables, government cached/indexed article bodies, private-host copies and failures. A downloaded file or matching numeral is not a source review.
- `independent-cases.json` contains all 11 independent Decimal recomputations and their classification conditions. Candidate step expressions were not executed to produce the independent answers. All 11 agree.
- The five files all grew in bytes, so the more-than-25-percent shrink rule does not trigger. All have 2026 scope, 16 November update dates, type and version 1.1. None of the changed files has a `reviewed_by` field.

## Required corrections

### R1. AFS deadline was extended, not 29 May

**Formation candidate line 92; writer F33.** The current row presents 29 May 2026 as the deadline for the 2026 filing cycle. A later SEC notice changed FY 31 December 2025 AFS to **15 June 2026**. The related listed/public issuer annual-report and broker/dealer 52-AR deadlines were moved to **15 May 2026**. The ordinary statutory income-tax dates elsewhere in the pack remain clearly labelled ordinary dates or 2026-income future filing, so they should not all be changed to the temporary 2025-income extension.

Actual government article bodies were read through the web tool's indexed/cached result: [PNA, 16 April 2026](https://www.pna.gov.ph/index.php/articles/1273093), reporting the SEC news release, and [PIA, 13 October 2026](https://pia.gov.ph/news/sec-guides-public-on-online-services-protection-against-lending-abuses/), reporting the SEC-CDO officer's confirmation. PNA identifies the exact FY, covered domestic/foreign offices, old and new dates and special classes. PIA independently confirms the June deadline and 30-day meeting-based GIS rule. Direct fetches failed, so these are not called fresh direct-body captures.

The signed SEC extension hosted by PSE is discovery/provenance only. It does not meet the brief's official-host requirement by itself. Use the actual government bodies for their exact supported scope, and keep any residual unavailable SEC-only conditions held if they cannot be recovered.

### R2. Restore the SSS criminal non-registration topic

**Social original line 137, original topic 130-139; candidate has no destination.** The original explicitly warns of criminal liability for non-registration. Replacing the incorrect blanket 2-percent arrears cure with the correct no-retroactive-gap rule does not preserve that separate registration obligation and exposure.

The actual [SSS self-employed body](https://www.sss.gov.ph/self-employed/) expressly retains potential fine/imprisonment for failure/refusal to register. The official [RA 11199 booklet](https://www.sss.gov.ph/wp-content/uploads/2022/04/Booklet_SS-ACT-OF-2018_05172019_2.pdf), sections 24(A) and 28(e), was read with its neighbors. Add one narrow registration/compliance sentence. There is no need to introduce numeric criminal penalties the old skill did not give. Repair the writer's no-loss destination for original line 137.

### R3. State the prerequisite for the age-55 SSS exception

**Social candidate line 61; writer S009.** The candidate says there is an exception when the maximum MSC increases but omits who qualifies. Actual SSS guidance permits the jump only when the member's **last posted MSC was the maximum under the immediately preceding schedule**. The rest of the one-bracket, once-per-calendar-year rule checks out. Add this prerequisite next to the exception. Both actual SSS SE and payment bodies were read, including the adjacent under-55 and decrease rules.

### R4. Preserve both roles of the lone-payer declaration

**Withholding original line 72 and original topic 64-76; candidate lines 76-79; writer W015.** The old requirements table includes B-2 for a single payer's lower-rate declaration. The candidate gives B-1 and B-3 their lower-rate roles but describes B-2 only as evidence for the distinct PHP 250,000 lone-payer exemption. That loses a valid use of B-2.

Actual [RR 11-2018](https://bir-cdn.bir.gov.ph/local/pdf/RR%20No.%2011-2018.pdf), page 7, last professional-fee declaration paragraph, explicitly uses B-2 plus COR for a professional with one payer. Actual [RMC 50-2018](https://bir-cdn.bir.gov.ph/local/pdf/RMC%20No%2050-2018.pdf) Q37 confirms its qualifying 5-percent use; page 11 was rendered and read. RR 14-2018's VAT-registration override still applies. Keep the valid separate exemption, and state that after a valid exempt lone-payer declaration crosses PHP 250,000, RR 11-2018 section 2.57.3 withholds the prescribed rate on the **excess**, rather than retroactively withholding on all PHP 250,000. Its full paragraph and worked illustration were read.

### R5. Exclude a GPP's own receipts from the broad non-individual fee rows

**Withholding candidate lines 69-70; writer W011-W012.** The wording “non-individual/corporate” is broad enough to sweep in a general professional partnership. Actual RMC 50-2018 Q35 states the GPP's own income is not subject to CWT; the partners' income and applicable withholding are separate. Add a short exclusion. The corporate case already distinguishes itself from a GPP distribution and remains arithmetically correct. This is a classification clarification, not a change to the supported corporate 10/15-percent rates.

### R6. Replace private-host operative citations and isolate the real remainder

The current brief prohibits private law databases. Eight Lawphil Acts and two taxcode-hosted SEC circulars are still linked as operative authority. Reading signed text on a private host does not make that host an official legislation/agency source.

Five full official bodies were recovered by root and independently read within the relevant scopes. Their actual raw/text hashes are bound in `source-scopes.json`. Substitute the URLs and repair the writer evidence without holding the supported rules:

| Private-host Act | Actual official replacement and supported scope |
|---|---|
| RA 11976 | [Supreme Court](https://elibrary.judiciary.gov.ph/thebookshelf/showdocs/2/96948): relevant sections 8-11, 17, 19, 34 and 45, including withholding proof, annual corporate deadline, service VAT, registration and classification. The vetoed micro-withholding exemption must still be rejected using actual BIR veto evidence. |
| RA 11534 | [Supreme Court](https://elibrary.judiciary.gov.ph/thebookshelf//showdocs/2/93191): relevant sections 6-7, ordinary corporate/MCIT timing and historical FCDU/tax-sparing provisions, read with later RR 7 and CMEPA. |
| RA 11223 | [PhilHealth full Act](https://www.philhealth.gov.ph/about_us/RA11223_UHC.pdf): sections 4(f), 5-10. The actual table was rendered and read; the 2026 PIA body and later 2026 circulars supply current continuation/operating conditions. |
| RA 10361 | [Supreme Court](https://elibrary.judiciary.gov.ph/thebookshelf/showdocs/2/51514): complete section 30 and PHP 5,000-and-above employee-sharing boundary. |
| RA 7160 | [Supreme Court](https://elibrary.judiciary.gov.ph/thebookshelf/showdocs/2/53542): complete sections 165-167 and adjacent local-payment rules. |

The remaining three Act-host branches can mostly use already-read official provisions rather than chasing entire inaccessible Acts:

- **TRAIN:** the complete official RR 8-2018 page 4 six-band table was independently rendered/read, and section 8 supports OSD replacement/election. RA 9504 section 3 supplies corporate OSD; RR 4-2024 supplies current business-filing boundaries; RR 6-2024 and the read TRAIN interest formula supply the current penalty analysis. Replace the private links with exact actually read official sources for their scope. Do not pretend a failed Senate request produced the whole Act.
- **RA 12023:** overview's actual operative claims are ordinary 12-percent service VAT on gross sales and eligible input credit, plus the inclusive/exclusive arithmetic. Recovered official EOPT sections 17 and 19 state those claims exactly. They can replace the private support without withdrawing the valid rate. No detailed nonresident digital-provider rule is being computed here.
- **RA 9679:** actual later official Circulars 274 and 460 independently support most registration/contribution/member categories. **The section 19 Fund/benefit tax-exemption branch remains private-host-only** in this package, especially social lines 143/157/276 and the held MP2 description's claim of a confirmed general exemption. Recover actual official section 19 support, or retain that original topic explicitly as non-operative/unconfirmed. Do not hold the independently supported 500/five-year MP2 description or contribution tables merely because section 19 is unavailable.

**SEC MC 4 and 9:** actual private-host signed bodies were read, including all six MC4 images, its fiscal-year commencement/public-interest exceptions, SMR forms, and MC9 sections 1-5. But these remain inadmissible operative sources under the brief. Government bodies support the meeting-based GIS 30 days, 120 days for other fiscal periods, and the corrected June AFS date. They do **not** prove every MC4 audit exemption/public-interest/SMR detail, the foreign GIS anniversary and foreign-office audit tests, or every MC9 special class/condition. These exact residual branches need official bodies or genuine non-operative holds, preserving originals. Do not simply restore the superseded PHP 600,000 threshold as current. If the MC4/9 SMR route is retained after recovery, include its Board-express-delegation alternative when the normal authorised signatories are absent; the private signed body contains that operative exception.

### R7. Correct the evidence map for the PHP 15,000 case

Social writer old-topic mapping 326-338 points to Case A. The actual PHP 15,000 case is **Case B, candidate 196-220**. Its numbers and original scenario are preserved. This is a writer evidence correction, not a calculation change.

### R8. Correct the real-property article reference

**Withholding candidate line 144; writer W051.** The original NIRC 6-percent charging/base clause is **24(D)(1)**, not 24(D)(2). Paragraph (2) is the principal-residence reinvestment exemption. Cite 24(D)(1)-(2) as appropriate alongside current CMEPA 24(B)(4). The supported rate/base and exemption qualification need no numerical change.

### R9. Remove the retired trust label

“Source-cited draft” remains in formation 26/151, corporate 27, social 31, overview 27 and withholding 30. Use the single current unapproved label without implying accountant approval; preserve the original full disclaimers and human credit lines. Ordinary words such as income “attested” in a signed PMRF are source-defined evidence, not a trust label, and should not be blindly removed.

## All cases and table recoveries

The 11 independent cases agree: formation 15/20 versus 10/20 and capital-increase 1m/250k/750k; corporate 800k versus 1m and MCIT160k versus ordinary100k; social monthly6,430/3,430/10,680 with the separate OEG and optional-savings alternatives; overview 277,500 versus152,500 and VAT12,000 versus13,440; withholding5,000 versus10,000 and75,000 versus50,000. Annual totals and every expected intermediate are in `independent-cases.json`.

The stock row check left **41 unreadable rows out of 94** on its direct network attempt. I independently read the actual RR7 corporate tables, complete SSS SE page3 table, all five Pag-IBIG460 pages and the actual government PhilHealth2026 premium body, including the relevant classifications. Those 41 row values and derived arithmetic check out. No OCR string search or matching anchor was treated as verification. This recovery does not clear the separate narrative/no-loss/provenance defects above, and is not called a clean direct-network row-check result.

## Validation and next step

Read-only checks were rerun on this exact clean HEAD: five `skill_checks` results `{}`, validator zero warnings, 11 example blocks zero failures/missing, and strict sync zero errors/warnings/notices. Logs are local reviewer artifacts. Source and content review still HOLDs the pack.

Only reviewer artifacts were written. No skill, writer ledger, source-writer evidence, branch, commit, PR, live database or release was modified. Root can now make the narrow corrections and return one new exact candidate for an independent delta review plus invariant/source-hold checks. The existing review evidence remains tied to this frozen HEAD and must not be relabelled PASS for a different hash.
