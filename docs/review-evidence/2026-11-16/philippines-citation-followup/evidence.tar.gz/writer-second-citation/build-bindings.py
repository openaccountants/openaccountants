from pathlib import Path
import collections,hashlib,json,re,subprocess,sys
sys.dont_write_bytecode=True
E=Path(__file__).parent;R=E.parent
W=R.parent/'world-finish-2026-11-14/lane-6/repository-philippines'
BASE='d75ceb5d52047bd5921bde118483da7a21ec44c4';HEAD='20e1ffff9af0e18ee09d0d214c38a2ebbe010b9c'
sha=lambda b:hashlib.sha256(b).hexdigest();load=lambda p:json.loads(p.read_text());dump=lambda n,x:(E/n).write_text(json.dumps(x,indent=2,ensure_ascii=False,default=str)+'\n')
git=lambda *a:subprocess.check_output(['git',*a],cwd=W)
assert git('rev-parse','HEAD').decode().strip()==HEAD and not git('status','--porcelain')
assert git('rev-parse','HEAD^').decode().strip()==BASE
assert git('diff','--name-only',BASE,HEAD).decode().splitlines()==['skills/philippines/ph-tax-overview.md','skills/philippines/ph-withholding.md']
edits=load(E/'precise-edits.json')['edits'];source_rows={x['new_source_row'] for x in edits if 'new_source_row' in x};replacements={x['old_row']:x['new_row'] for x in edits if 'old_row' in x};line_map=[];files=[];cases=[]
for p in sorted((E/'before/skills/philippines').glob('*.md')):
 rel=str(p.relative_to(E/'before'));old=p.read_text();new=(W/rel).read_text();assert p.read_bytes()==git('show',BASE+':'+rel)
 reconstructed=new
 for x in edits:
  if x['file']!=rel:continue
  if 'new_row' in x:assert reconstructed.count(x['new_row'])==1;reconstructed=reconstructed.replace(x['new_row'],x['old_row'],1)
  else:assert reconstructed.count(x['new_source_row']+'\n')==1;reconstructed=reconstructed.replace(x['new_source_row']+'\n','',1)
 assert reconstructed==old,(rel,'Non-citation delta')
 oldlines=old.splitlines();newlines=new.splitlines();j=0
 for i,line in enumerate(oldlines,1):
  while j<len(newlines) and newlines[j] in source_rows:j+=1
  target=replacements.get(line,line);assert newlines[j]==target,(rel,i,j)
  line_map.append({'file':rel,'old_line':i,'new_line':j+1,'old_sha256':sha(line.encode()),'new_sha256':sha(newlines[j].encode()),'change':'citation append only' if line in replacements else 'exact text','original_text':line,'destination_text':newlines[j]});j+=1
 while j<len(newlines) and newlines[j] in source_rows:j+=1
 assert j==len(newlines)
 oldfm=old.split('---',2)[1];newfm=new.split('---',2)[1];assert oldfm==newfm
 blocks=lambda t:re.findall(r'```oa-check\s*\n(.*?)\n```',t,re.S)
 assert blocks(old)==blocks(new)
 for i,b in enumerate(blocks(new),1):cases.append({'file':rel,'case':i,'sha256':sha(b.encode()),'all_inputs_steps_expected_eligibility_block_unchanged':True})
 olds=set(re.findall(r'https?://[^\s|>\]]+',old));news=set(re.findall(r'https?://[^\s|>\]]+',new));assert olds<=news
 for credit in ['Corrected by Jonathan I. Ruiz (CPA, Philippines)','Contributed by']:
  assert old.count(credit)==new.count(credit)
 # Complete disclaimers/refusals/holds retain identity because whole-file
 # reconstruction above proves the three URL additions and two new source rows.
 files.append({'file':rel,'old_sha256':sha(old.encode()),'new_sha256':sha(new.encode()),'old_git_blob':git('rev-parse',BASE+':'+rel).decode().strip(),'new_git_blob':git('rev-parse',HEAD+':'+rel).decode().strip(),'frontmatter_byte_exact':True,'human_fields_credits_exact':True,'all_original_URLs_retained':True,'case_blocks_exact':True,'all_rule_figures_conditions_disclaimers_refusals_holds_retained':True,'whole_file_reconstruction_proof':True,'changed':old!=new})
assert len(files)==8 and len(cases)==11
dump('complete-parent-line-map.json',{'base':BASE,'head':HEAD,'population':len(line_map),'rows':line_map,'all_parent_lines_have_exact_or_citation_append_destination':True,'no_similarity_matching':True})
dump('protected-and-no-loss.json',{'base':BASE,'head':HEAD,'country_files':files,'cases':cases,'case_count':11,'unchanged_siblings':6,'delta':'Three URL appends and two new Sources rows only; reversing precisely those insertions reproduces all eight base files byte-for-byte. No new interpretation or rule.'})
prior=load(R/'review-philippines/delta-ffb2ef90/rule-review-291.json');rows=[]
for x in prior['rows']:
 f='skills/philippines/'+x['file'];changed=(x['file'],str(x['id'])) in [('ph-tax-overview.md','18'),('ph-withholding.md','W057'),('ph-withholding.md','W059')]
 rows.append({'file':f,'id':str(x['id']),'new_candidate_sha256':sha((W/f).read_bytes()),'prior_exact_rule_review':{'path':str((R/'review-philippines/delta-ffb2ef90/rule-review-291.json').resolve()),'row_id':str(x['id']),'original_rule_text_unchanged':True},'new_corroborating_source':('https://bir-cdn.bir.gov.ph/local/pdf/1701Q%20Jan%202018.pdf' if x['file']=='ph-tax-overview.md' else 'https://www.bir.gov.ph/penalties?q=penalties') if changed else None,'citation_delta_requires_separate_independent_review':changed,'writer_not_independent_approval':True})
assert len(rows)==291 and sum(bool(z['new_corroborating_source']) for z in rows)==3
dump('rule-bindings-291.json',{'head':HEAD,'total':291,'three_corroboration_groups':[('ph-tax-overview.md','18'),('ph-withholding.md','W057'),('ph-withholding.md','W059')],'new_rules':0,'independent_verdict_not_claimed':True,'rows':rows})
diag=R/'philippines-hosted-figures-diagnostic';proof=load(diag/'actual-native-read-scopes.json');sources=[z for z in proof if z['source_url'] in ['https://bir-cdn.bir.gov.ph/local/pdf/1701Q%20Jan%202018.pdf','https://www.bir.gov.ph/penalties?q=penalties']]
assert len(sources)==2
dump('new-corroboration-read-bindings.json',{'head':HEAD,'source_read_date':'2026-11-16','provenance':'Actual preceding independent source-diagnosis reads; exact bytes retained, not another invented download or new full-country review. This writer is not independent reviewer of own citation delta.','sources':sources,'diagnostic_manifest':{'path':str((diag/'FINAL-MANIFEST.json').resolve()),'sha256':sha((diag/'FINAL-MANIFEST.json').read_bytes())},'raw_live_form_sessions_local_only':True})
(E/'committed-citation-only.patch').write_bytes(git('diff',BASE,HEAD,'--','skills/philippines'))
dump('git-binding.json',{'base':BASE,'head':HEAD,'branch':git('branch','--show-current').decode().strip(),'commit_identity':git('show','-s','--format=%an <%ae>%n%cn <%ce>%n%B',HEAD).decode(),'worktree_clean':True,'no_push':True})
print(json.dumps({'head':HEAD,'files':len(files),'mapped_parent_lines':len(line_map),'unchanged_cases':len(cases),'groups':len(rows),'new_source_groups':3,'candidate_clean':True},indent=2))
