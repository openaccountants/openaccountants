# Sweden precise review-correction handoff

Frozen clean candidate: **807ffce8185c7fbc859ec95605282c20eb44ef27**. Parent/full-review HOLD:426f7419baeff22e8132e1526514f478fe0d508d. Base:2844c309238b4fdb63be0a3d0ad9ae99a8ea89c8. Branch:world/codex-sweden-2026-11-16; worktree:../wt-sweden.

This is writer evidence for exactly the seven independent findings, **not independent clearance**. The previous HANDOFF.md remains historical for the prior head; this document is the current handoff. No push, PR, publication, merge, release, database work or external message occurred. Root remains the publication coordinator.

## Immutable before packet

Before any edit, the whole writer packet and full independent HOLD were copied to ../sweden-before-corrections-426f7419/. Its archive manifest binds 235 files, all rechecked after correction. The archived writer final manifest remains SHA256 b36bcfb6401c0e3d9a6c7bff917bf7e5a4e30c7f4b1c1a6f040f2631fec85f63. The actual original independent ../review-sweden/MANIFEST.json remains SHA256 cbc188fa76ca0847139de07532fe66a3f5c54bb2a4e6a63aff92d43e9a91ba44. Original HOLD findings and failed check logs are preserved.

## Precise corrections

| Finding | Writer correction and actual native support |
|---|---|
| SE-CG-01 | Capital gains line 104 retains the full deferral paragraph and adds IL 47:2's foreign-credit restriction: only the gain portion attributable to tax not credited can receive deferral. Actual complete native 47:2 and 3–5 neighbors read; normal official HTML reconfirms the final paragraph. Obtain credit allocation before quantifying that branch. |
| SE-XB-01 | Cross-border line 121 retains the ordinary non-CSD declaration rule and adds 14 § mandatory withholding for payment abroad. Payer withholding is separate from final liability/refund. Actual Kupong 13–16 and 27 context retained; complete 14 and neighbors read again and freshly confirmed in official HTML. |
| SE-CR-01 | Crypto line 122 now says resident abroad **or habitually staying abroad**, preserving May31/weekend, the dated 2026 authority example and held future age policy. Actual SFL 48:3 and 1–7 context read; official HTML confirms stadigvarande. |
| SE-XB-02 | Cross-border line 96 qualifies the one-year registration rule by 3 §'s express 4/5/5a exceptions, required residence status and special categories. Individual eligibility is held if unresolved. Its Sources row names those actual read exceptions. Complete native 3–5a and neighbors read; ordinary HTML confirms relevant current text. No individual immigration eligibility is guessed. |
| SE-XB-03 | Cross-border line 110 ends high interest through the day the relevant collection/security-execution decision is registered at Kronofogden; base interest applies afterwards. Actual SFL 65:13 and 11–15 neighbors read; normal HTML confirms it. Rate figures and dated rate source are unchanged. |
| SE-EV-01 | Original cross-border line 199 maps to actual scoped source-table body 204–224, with the old read-date inventory archived. Original line 221 maps to the full retained/extended non-operative hold at 226. Neither maps only to the Sources heading. JSON maps and ledger regenerated. |
| SE-EV-02 | Six anchors now bind relevant paragraphs: BFL 3:6 permission and both exceptions; real SFL 49:14 unused-deficit paragraph; actual BFNAR2025:2 transition on physical PDF 334; actual K-project selection paragraph plus separately bound K2 1.4/1.5/1.6 whole-framework support on physical PDF 22–23; Kvittning WEB46L146–149; mining WEB01L410–411. SFL 49:12 is explicitly **repealed/non-operative**. All generated current ledgers/read manifests contain the corrected scopes and secondary K2 support. |

correction-content-delta.json records all six exact text replacements: five conditions plus one precise Sources scope. Git changes only three assigned files, six existing lines. correction-source-group-delta.json records 12 changed groups: five expanded condition scopes and seven evidence/repeal corrections. The other 228 group records are unchanged. All 240 group identities and 43 official URLs remain. Supplemental K2 support is inside the existing BFN-framework group, not a new tax topic.

## Actual reading

Relevant complete native provisions, exceptions and neighbors were actually read from preserved official bodies. Fresh normal HTTPS GETs of four Riksdagen HTML statutes returned200; actual bodies, normalized text, precise read contexts and hashes are under correction-read/. These fresh reads confirm only corrected conditions, not another full reading of 240 groups or entire Acts. Valid unchanged scopes can reuse the complete immutable independent review and its 16 November dates after hash verification.

The official BFN K2 PDF remains identical. Physical pages 22, 23, 334 were extracted, rendered and **displayed/read**, including whole-framework 1.4, merger exceptions 1.5/1.6, 1.7 context and the full BFNAR2025:2 transition with extended-first-year and comparative-valuation conditions. correction-read/K2-pages22-23-334.txt, the three pdf-views/K2-correction-* images and pdf-visual-inspection.json bind that scope. No Firecrawl, private source, paid service or challenge bypass was used.

## Preserved populations and inputs

- 240 indexed groups, 43 official URLs, 948 classified candidate items, 295 body rows, 608 original populated lines, 71 old headings and 20 cases remain. One indexed group is an explicit repeal check, not an operative provision.
- All maps, candidate inventory, population, cases and six markdown ledgers were regenerated against actual candidate bytes. Every original line identity and destination text was enumerated in correction-invariants.json. The writer changed/structural category is now 93, not a claim that the independent full review's 138 nonexact records disappeared.
- All 20 current case blocks and all five original executable blocks are byte-identical. No raw input, formula, expected value or original prose scenario changed. The full independent review's 69 expected-output recomputations remain immutable; current executable checks pass all 20 cases. No new independent recomputation is claimed by this writer.
- All 16 country files' frontmatter is byte-identical to the prior candidate. No extra version/date bump, name, approval, tier, credit, CTA or calculator-quoted-line change. Ten passing siblings remain identical to base. Within this correction, 13 of 16 files are unchanged, including bookkeeping, references and README.
- Every genuine hold remains unchanged: historical project/licensing/integration assertions, home-deferral departure uncertainty, changed-period SINK universality, treaties/tie-breakers/exit events, specialized/K3/entity closing, future filing/age policy, unclassified crypto and insolvency/FTX uncertainty. Historical FX remains dated. No held scope is silently cleared.

## Exact-head terminal checks

check-results.json binds all six terminal checks at 807ffce8185c7fbc859ec95605282c20eb44ef27: five standard results {}; six paths/five Guides/zero warning groups; 20 oa-check blocks/zero failures/zero missing; strict sync zero errors/warnings/notices; calculator quotes preserved; unchanged stock checker 26 rows/zero MISS/one UNREADABLE/exit 0.

The unreadable row is the same FSN remuneration URL. Its actual fixed-monthly-pay body and 88,801/89,401 floor conditions were read by the full independent reviewer; source bytes/values remain unchanged. Zero MISS is not legal verification and did not detect the original omitted conditions. No row bypass, figure alteration or checker patch was used.

## Required independent delta

The original reviewer should check five changed conditions, all 12 changed groups including secondary K2 support/repealed status, both semantic destination repairs, full preserved 240/608/20 populations and protected inputs. Reuse only valid unchanged exact scopes from the full immutable HOLD. Issue a new exact-head PASS/HOLD. This writer does not close the findings itself; root decides later publication/live-check steps.
