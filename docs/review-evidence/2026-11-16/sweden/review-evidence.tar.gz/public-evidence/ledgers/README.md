# Writer ledger: README.md

Original SHA256 `fb623f9555fc4f5f6f078bfb63e3dde87c933e03d13b7261c0393022c19bf3a8`. Candidate SHA256 `ac38edac0a2e2a5bf56de329bbe83aa87e9bfcb6e89c4a16bf047cfed4266d01`. Read date: 2026-11-16. This is writer evidence, not independent review.

Each row identifies the complete source-group population to inspect. A quote is an anchor to the actual article/body excerpt, not a substitute for its neighbouring conditions. Historical research claims and unresolved holds are expressly non-operative.

| Candidate line | Section / figure, rule or condition | Source groups |
|---|---|---|

## Exact original-language quote anchors

| Group | Act/article or read scope | Official URL | Exact quote | Read date | Evidence |
|---|---|---|---|---|---|

## Old topics and every original populated line

| Original line | Original topic / text | Candidate line | Disposition |
|---|---|---|---|
| 1 | --- | 1 | Retained; only normalization or official URL edition update where applicable. |
| 2 | jurisdiction: SE | 2 | Retained; only normalization or official URL edition update where applicable. |
| 3 | applicable: [IT-IND, IT-CORP, VAT, SC, PR, TP, XB] | 3 | Retained; only normalization or official URL edition update where applicable. |
| 4 | not_applicable: {} | 4 | Retained; only normalization or official URL edition update where applicable. |
| 5 | covered_by: | 5 | Retained; only normalization or official URL edition update where applicable. |
| 6 |   XB: se-cross-border | 6 | Retained; only normalization or official URL edition update where applicable. |
| 7 | --- | 1 | Retained; only normalization or official URL edition update where applicable. |
| 9 | # Sweden: tax pack | 9 | Retained; only normalization or official URL edition update where applicable. |
| 11 | Calendar tax year for individuals; companies are taxed per financial year (räkenskapsår), which may differ from the calendar year. Authority: Skatteverket. Swedish kronor (SEK). Individuals pay municipal income tax plus state income tax above a threshold, and 30% on capital income. Companies pay a single state corporate tax of 20.6% with no municipal layer. VAT (moms) follows EU rules. Employers pay arbetsgivaravgifter; the self-employed pay egenavgifter. | 11 | Retained; only normalization or official URL edition update where applicable. |
| 13 | ## Domains | 13 | Retained; only normalization or official URL edition update where applicable. |
| 15 | &#124; Tax &#124; Skill &#124; Status &#124; | 15 | Retained; only normalization or official URL edition update where applicable. |
| 16 | &#124;---&#124;---&#124;---&#124; | 16 | Retained; only normalization or official URL edition update where applicable. |
| 17 | &#124; Income tax &#124; se-employee-income-tax, se-income-tax, se-capital-gains, se-closely-held-company-312 &#124; sourced from the law &#124; | 17 | Row retained with source link; README labels use founder-approved wording. Interest row corrects PE carveout. |
| 18 | &#124; Company tax &#124; se-corporate-tax &#124; checked against the law &#124; | 18 | Row retained with source link; README labels use founder-approved wording. Interest row corrects PE carveout. |
| 19 | &#124; VAT or sales tax &#124; sweden-vat-return (2026 deep-tax) &#124; source-cited draft &#124; | 19 | Row retained with source link; README labels use founder-approved wording. Interest row corrects PE carveout. |
| 20 | &#124; Social contributions &#124; se-social-contributions, sweden-payroll, se-employee-income-tax &#124; checked against the law &#124; | 20 | Row retained with source link; README labels use founder-approved wording. Interest row corrects PE carveout. |
| 21 | &#124; Payroll &#124; sweden-payroll, se-benefits-and-allowances &#124; checked against the law &#124; | 21 | Row retained with source link; README labels use founder-approved wording. Interest row corrects PE carveout. |
| 22 | &#124; Transfer pricing &#124; se-transfer-pricing &#124; checked against the law &#124; | 22 | Row retained with source link; README labels use founder-approved wording. Interest row corrects PE carveout. |
| 23 | &#124; Cross-border &#124; se-cross-border &#124; checked against the law &#124; | 23 | Row retained with source link; README labels use founder-approved wording. Interest row corrects PE carveout. |
| 24 | &#124; Bookkeeping and annual accounts &#124; sweden-bookkeeping, sweden-financial-statements (K2 annual report for a private AB) &#124; source-cited draft &#124; | 24 | Row retained with source link; README labels use founder-approved wording. Interest row corrects PE carveout. |
| 26 | ## Official sources | 26 | Retained; only normalization or official URL edition update where applicable. |
| 28 | - Inkomstskattelag (1999:1229): https://www.riksdagen.se/sv/dokument-och-lagar/dokument/svensk-forfattningssamling/inkomstskattelag-19991229_sfs-1999-1229/ (read 2026-10-22) | 28 | Retained; only normalization or official URL edition update where applicable. |
| 29 | - Skatteförfarandelag (2011:1244): https://www.riksdagen.se/sv/dokument-och-lagar/dokument/svensk-forfattningssamling/skatteforfarandelag-20111244_sfs-2011-1244/ (read 2026-10-22) | 29 | Retained; only normalization or official URL edition update where applicable. |
| 30 | - Lag (1991:586) om särskild inkomstskatt för utomlands bosatta (SINK): https://data.riksdagen.se/dokument/sfs-1991-586.text (read 2026-10-22) | 30 | Retained; only normalization or official URL edition update where applicable. |
| 31 | - Kupongskattelag (1970:624): https://www.riksdagen.se/sv/dokument-och-lagar/dokument/svensk-forfattningssamling/kupongskattelag-1970624_sfs-1970-624/ (read 2026-10-22) | 31 | Retained; only normalization or official URL edition update where applicable. |
| 32 | - Skatteförfarandeförordning (2011:1261): https://data.riksdagen.se/dokument/sfs-2011-1261.text (read 2026-10-23) | 32 | Retained; only normalization or official URL edition update where applicable. |
| 33 | - Lag (2009:1289) and Förordning (2009:1295) om prissättningsbesked: https://data.riksdagen.se/dokument/sfs-2009-1289.text (read 2026-10-23) | 33 | Retained; only normalization or official URL edition update where applicable. |
| 34 | - Socialavgiftslag (2000:980): https://data.riksdagen.se/dokument/sfs-2000-980.text (read 2026-10-24) | 34 | Retained; only normalization or official URL edition update where applicable. |
| 35 | - Lag (1994:1920) om allmän löneavgift: https://data.riksdagen.se/dokument/sfs-1994-1920.text (read 2026-10-24) | 35 | Retained; only normalization or official URL edition update where applicable. |
| 36 | - Lag (2026:100) om särskild beräkning av arbetsgivaravgifter för unga: https://data.riksdagen.se/dokument/sfs-2026-100.text (read 2026-10-24) | 36 | Retained; only normalization or official URL edition update where applicable. |
| 37 | - Lag (2025:1334) om återbetalning av vissa avgifter till växa-företag: https://data.riksdagen.se/dokument/sfs-2025-1334.text (read 2026-10-24) | 37 | Retained; only normalization or official URL edition update where applicable. |
| 38 | - Skatteverket: https://www.skatteverket.se (read 2026-10-22) | 38 | Retained; only normalization or official URL edition update where applicable. |
