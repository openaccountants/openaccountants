# Writer ledger: references.md

Original SHA256 `c99acda905cd64d0c76acbbfb4fb1299b6902e69d391a10aee512455152b7f62`. Candidate SHA256 `f248c2ebd8811ee44b7f0310e9203063f56b061b29ffd376fe1bf7cdc9d7f2cf`. Read date: 2026-11-16. This is writer evidence, not independent review.

Each row identifies the complete source-group population to inspect. A quote is an anchor to the actual article/body excerpt, not a substitute for its neighbouring conditions. Historical research claims and unresolved holds are expressly non-operative.

| Candidate line | Section / figure, rule or condition | Source groups |
|---|---|---|
| 17 | > **General reference only.** This skill is general tax/accounting reference material for AI-assisted workflows. It has not been reviewed for any specific person's facts, documents, elections, deadlines, residency, filing status, or local procedures. Do not rely on it to file, pay, amend, or take a tax position without review by a qualified professional in the relevant jurisdiction. | BP-ISK, Catalogue, IL-3-3 |
| 21 | Use this index to select the Swedish job and its primary authority for income year 2026. This is a router, not a tax calculation or permission to reuse software/content. The historical project leads below are preserved for research continuity, not used as legal sources. | BP-ISK, Catalogue, IL-3-3 |
| 25 | Identify the taxpayer/entity, residence, income or financial year, job and the output required. Obtain the transaction documents and any actual accountant approval separately. | BP-ISK, Catalogue, IL-3-3 |
| 29 | 1. For employee or sole-trader income load [se-employee-income-tax](se-employee-income-tax.md) or [se-income-tax](se-income-tax.md), then the relevant source provisions. | BP-ISK, Catalogue, IL-3-3 |
| 30 | 2. For private disposals use [se-capital-gains](se-capital-gains.md); for cryptoasset transactions use [sweden-crypto-tax](sweden-crypto-tax.md). A project calculator does not establish cost, classification or a filing position. | BP-ISK, Catalogue, IL-3-3 |
| 31 | 3. For employer withholding and benefits use [sweden-payroll](sweden-payroll.md) and [se-benefits-and-allowances](se-benefits-and-allowances.md); for self-employed contributions use [se-social-contributions](se-social-contributions.md). | BP-ISK, Catalogue, IL-3-3 |
| 32 | 4. For companies, close-company owners, VAT, transfer pricing or crossing the border load [se-corporate-tax](se-corporate-tax.md), [se-closely-held-company-312](se-closely-held-company-312.md), [sweden-vat-return](sweden-vat-return.md), [se-transfer-pricing](se-transfer-pricing.md) or [se-cross-border](se-cross-border.md), as applicable. | BP-ISK, Catalogue, IL-3-3 |
| 33 | 5. For posting/close use [sweden-bookkeeping](sweden-bookkeeping.md), then [sweden-financial-statements](sweden-financial-statements.md) for its annual-report scope. Select the BFN edition by financial-year commencement. | BP-ISK, Catalogue, IL-3-3 |
| 34 | 6. Handoff the selected skill, applicable year, taxpayer facts, source excerpts, unresolved questions and working paper. A calculator result never replaces the official rule or named professional approval. | BP-ISK, Catalogue, IL-3-3 |
| 38 | Do not choose a figure from GitHub projects, merge code, assume a licence, publish an approval label or file a return from this index. Missing source access, uncertain legal scope and unverified licensing require the specific source/permission before use. Do not extend an archived validation claim to the present year or current repository version. | BP-ISK, Catalogue, IL-3-3 |
| 42 | Everything in the following archive, including the blanket compatibility statement, licence descriptions, rankings, validation claims and suggested integrations, is a retained historical research claim. None has been newly verified or adopted as an instruction, legal authority or reuse permission. Confirm each repository's current licence, file-level rights, version and test evidence before any reuse. The archive is not part of the routing method above. | historical-non-operative |
| 44 | OpenAccountants is AGPL-3.0. MIT and AGPL-3.0 content can be incorporated with attribution. Projects below are license-compatible unless noted otherwise. | historical-non-operative |
| 48 | - Repository: [Baltsar/kammaren-tax-engine](https://github.com/Baltsar/kammaren-tax-engine) | historical-non-operative |
| 49 | - License: AGPL-3.0 | historical-non-operative |
| 50 | - Language: Swedish / English | historical-non-operative |
| 51 | - Scope: Deterministic Swedish tax engine for income year 2026, including income tax, employer fees, municipal tax rates, and 3:12 rules for closely held companies. | historical-non-operative |
| 52 | - Why it matters: This appears to be the most carefully tested Swedish tax engine found so far. It states that its income tax output is verified against Skatteverket's official 2026 tax table row by row. | historical-non-operative |
| 53 | - Integration approach: | historical-non-operative |
| 54 |   - AGPL-3.0 is the same license family as OpenAccountants. Content can be incorporated with attribution. | historical-non-operative |
| 55 |   - Use as a validation reference and source for Swedish income tax, municipal tax, employer fees, and 3:12 rule modelling. | historical-non-operative |
| 56 |   - Tax constants and formulas verified row-by-row against SKV 433 Table 30 : strong validation target. | historical-non-operative |
| 60 | - Repository: [bambapappa/kryptoskatt](https://github.com/bambapappa/kryptoskatt) | historical-non-operative |
| 61 | - License: MIT | historical-non-operative |
| 62 | - Language: Swedish | historical-non-operative |
| 63 | - Scope: Swedish cryptocurrency tax calculator that computes capital gains and losses using the average cost method and generates K4 and T2 supporting schedules. | historical-non-operative |
| 64 | - Why it matters: It is Sweden-native, MIT licensed, and focused on practical declaration outputs for Skatteverket. | historical-non-operative |
| 65 | - Integration approach: | historical-non-operative |
| 66 |   - Reference for crypto-specific K4/T2 handling and Skatteverket-facing report structure. | historical-non-operative |
| 67 |   - Potentially useful as a future compatible workflow for crypto transaction imports. | historical-non-operative |
| 71 | - Repository: [duga3/K4Skatt](https://github.com/duga3/K4Skatt) | historical-non-operative |
| 72 | - License: MIT | historical-non-operative |
| 73 | - Language: English / Swedish | historical-non-operative |
| 74 | - Scope: Generates Swedish K4 tax forms and SRU files from Interactive Brokers trade data, including options, assignments, exercises, and pre-calculated trades. | historical-non-operative |
| 75 | - Why it matters: Practical bridge between broker exports and Skatteverket-compatible SRU files. | historical-non-operative |
| 76 | - Integration approach: | historical-non-operative |
| 77 |   - Reference for investment disposal workflows, K4 structure, and SRU output expectations. | historical-non-operative |
| 78 |   - Consider future OpenAccountants export compatibility for K4 working papers. | historical-non-operative |
| 82 | - Repository: [ebtcap/K4SRU](https://github.com/ebtcap/K4SRU) | historical-non-operative |
| 83 | - License: verify before reuse | historical-non-operative |
| 84 | - Language: Swedish | historical-non-operative |
| 85 | - Scope: Generates K4 SRU files that can be uploaded to Skatteverket and produces Excel review files. | historical-non-operative |
| 86 | - Why it matters: Strong practical focus on declaration upload files, review outputs, foreign currency accounts, and Skatteverket import workflows. | historical-non-operative |
| 87 | - Integration approach: | historical-non-operative |
| 88 |   - Reference for SRU file structure, K4 import process, and review-paper conventions. | historical-non-operative |
| 89 |   - Treat as reference-only until the license is confirmed. | historical-non-operative |
| 93 | - [jonasgroth/swe-income-tax](https://github.com/jonasgroth/swe-income-tax) : MIT JavaScript income tax calculator, useful historically but old. | historical-non-operative |
| 94 | - [jonas-johansson/SwedishEconomySDK](https://github.com/jonas-johansson/SwedishEconomySDK) : C# Swedish income tax SDK with examples validated against Skatteverket, useful as an additional reference. | historical-non-operative |
| 95 | - [tessin/SKV260](https://github.com/tessin/SKV260) : .NET library for electronic reporting of Swedish control statements to Skatteverket. | historical-non-operative |
| 105 | Not yet confirmed: every historical project's current licence, attribution/reuse permission, maintenance, tax coverage, formula accuracy, claimed official-table validation and integration compatibility, including the blanket MIT/AGPL compatibility assertion. These claims are non-operative research leads, not source evidence. This router contains no operative rates, deadlines or worked tax cases, so the router shape requires no oa-check. | unconfirmed-hold |

## Exact original-language quote anchors

| Group | Act/article or read scope | Official URL | Exact quote | Read date | Evidence |
|---|---|---|---|---|---|
| BP-ISK | 2026 ISK 3.55/1.065%, 300k and automatic deduction | https://www.skatteverket.se/privat/skatter/beloppochprocent/2026.4.1522bf3f19aea8075ba21.html | Den 30 november 2025 var statslåneräntan 2,55 procent. Schablonintäkten för inkomstår 2026 | 2026-11-16 | read-bodies/WEB-02.txt L592; SHA256 05db39a46a0a06525a06584517845c9a45b53b0e0d901643d3e67f5d83420837 |
| Catalogue | current K1/K2 editions and start dates | https://www.bfn.se/informationsmaterial/vagledningar/ | * Ett nystartat företag som inleder sin verksamhet efter den 30 juni | 2026-11-16 | read-bodies/WEB-04.txt L51; SHA256 e060cfee4923aa3e71ed2edda124fba5104d97f0ab267365732607c89c2a1830 |
| IL-3-3 | IL 3 kap. 3 § and neighbours | https://data.riksdagen.se/dokument/sfs-1999-1229.text | 3 § Följande personer är obegränsat skattskyldiga: | 2026-11-16 | law-chapters/IL-3.txt line 34; SHA256 ca165cdef7823a6dc4c34e9104ffd1973469bce5b1df20544f978d260665fa2b |

## Old topics and every original populated line

| Original line | Original topic / text | Candidate line | Disposition |
|---|---|---|---|
| 1 | --- | 1 | Retained; only normalization or official URL edition update where applicable. |
| 2 | name: sweden-references | 2 | Retained; only normalization or official URL edition update where applicable. |
| 3 | jurisdiction: SE | 3 | Retained; only normalization or official URL edition update where applicable. |
| 4 | last_updated: 2026-06-12 | 4 | Required one-step version/date update; professional approval metadata unchanged. |
| 5 | version: 1.0 | 5 | Required one-step version/date update; professional approval metadata unchanged. |
| 6 | description: Primary source references and related open-source projects for this jurisdiction. | 6 | Retained; only normalization or official URL edition update where applicable. |
| 7 | tier: 2 | 7 | Retained; only normalization or official URL edition update where applicable. |
| 8 | --- | 1 | Retained; only normalization or official URL edition update where applicable. |
| 10 | # Sweden — Related Open-Source Projects | 13 | Canonical heading/version replaces old heading; following content remains mapped separately. |
| 12 | > **General reference only.** This skill is general tax/accounting reference material for AI-assisted workflows. It has not been reviewed for any specific person's facts, documents, elections, deadlines, residency, filing status, or local procedures. Do not rely on it to file, pay, amend, or take a tax position without review by a qualified professional in the relevant jurisdiction. | 17 | Retained; only normalization or official URL edition update where applicable. |
| 14 | OpenAccountants is AGPL-3.0. MIT and AGPL-3.0 content can be incorporated with attribution. Projects below are license-compatible unless noted otherwise. | 44 | Retained; only normalization or official URL edition update where applicable. |
| 16 | ## Kammaren Tax Engine | 46 | Canonical heading/version replaces old heading; following content remains mapped separately. |
| 18 | - Repository: [Baltsar/kammaren-tax-engine](https://github.com/Baltsar/kammaren-tax-engine) | 48 | Retained; only normalization or official URL edition update where applicable. |
| 19 | - License: AGPL-3.0 | 49 | Retained; only normalization or official URL edition update where applicable. |
| 20 | - Language: Swedish / English | 50 | Retained; only normalization or official URL edition update where applicable. |
| 21 | - Scope: Deterministic Swedish tax engine for income year 2026, including income tax, employer fees, municipal tax rates, and 3:12 rules for closely held companies. | 51 | Retained; only normalization or official URL edition update where applicable. |
| 22 | - Why it matters: This appears to be the most carefully tested Swedish tax engine found so far. It states that its income tax output is verified against Skatteverket's official 2026 tax table row by row. | 52 | Retained; only normalization or official URL edition update where applicable. |
| 23 | - Integration approach: | 53 | Retained; only normalization or official URL edition update where applicable. |
| 24 |   - AGPL-3.0 is the same license family as OpenAccountants. Content can be incorporated with attribution. | 54 | Retained; only normalization or official URL edition update where applicable. |
| 25 |   - Use as a validation reference and source for Swedish income tax, municipal tax, employer fees, and 3:12 rule modelling. | 55 | Retained; only normalization or official URL edition update where applicable. |
| 26 |   - Tax constants and formulas verified row-by-row against SKV 433 Table 30 — strong validation target. | 56 | Retained; only normalization or official URL edition update where applicable. |
| 28 | ## KryptoSkatt | 58 | Canonical heading/version replaces old heading; following content remains mapped separately. |
| 30 | - Repository: [bambapappa/kryptoskatt](https://github.com/bambapappa/kryptoskatt) | 60 | Retained; only normalization or official URL edition update where applicable. |
| 31 | - License: MIT | 61 | Retained; only normalization or official URL edition update where applicable. |
| 32 | - Language: Swedish | 62 | Retained; only normalization or official URL edition update where applicable. |
| 33 | - Scope: Swedish cryptocurrency tax calculator that computes capital gains and losses using the average cost method and generates K4 and T2 supporting schedules. | 63 | Retained; only normalization or official URL edition update where applicable. |
| 34 | - Why it matters: It is Sweden-native, MIT licensed, and focused on practical declaration outputs for Skatteverket. | 64 | Retained; only normalization or official URL edition update where applicable. |
| 35 | - Integration approach: | 53 | Retained; only normalization or official URL edition update where applicable. |
| 36 |   - Reference for crypto-specific K4/T2 handling and Skatteverket-facing report structure. | 66 | Retained; only normalization or official URL edition update where applicable. |
| 37 |   - Potentially useful as a future compatible workflow for crypto transaction imports. | 67 | Retained; only normalization or official URL edition update where applicable. |
| 39 | ## K4Skatt | 69 | Canonical heading/version replaces old heading; following content remains mapped separately. |
| 41 | - Repository: [duga3/K4Skatt](https://github.com/duga3/K4Skatt) | 71 | Retained; only normalization or official URL edition update where applicable. |
| 42 | - License: MIT | 61 | Retained; only normalization or official URL edition update where applicable. |
| 43 | - Language: English / Swedish | 73 | Retained; only normalization or official URL edition update where applicable. |
| 44 | - Scope: Generates Swedish K4 tax forms and SRU files from Interactive Brokers trade data, including options, assignments, exercises, and pre-calculated trades. | 74 | Retained; only normalization or official URL edition update where applicable. |
| 45 | - Why it matters: Practical bridge between broker exports and Skatteverket-compatible SRU files. | 75 | Retained; only normalization or official URL edition update where applicable. |
| 46 | - Integration approach: | 53 | Retained; only normalization or official URL edition update where applicable. |
| 47 |   - Reference for investment disposal workflows, K4 structure, and SRU output expectations. | 77 | Retained; only normalization or official URL edition update where applicable. |
| 48 |   - Consider future OpenAccountants export compatibility for K4 working papers. | 78 | Retained; only normalization or official URL edition update where applicable. |
| 50 | ## K4SRU | 80 | Canonical heading/version replaces old heading; following content remains mapped separately. |
| 52 | - Repository: [ebtcap/K4SRU](https://github.com/ebtcap/K4SRU) | 82 | Retained; only normalization or official URL edition update where applicable. |
| 53 | - License: verify before reuse | 83 | Retained; only normalization or official URL edition update where applicable. |
| 54 | - Language: Swedish | 62 | Retained; only normalization or official URL edition update where applicable. |
| 55 | - Scope: Generates K4 SRU files that can be uploaded to Skatteverket and produces Excel review files. | 85 | Retained; only normalization or official URL edition update where applicable. |
| 56 | - Why it matters: Strong practical focus on declaration upload files, review outputs, foreign currency accounts, and Skatteverket import workflows. | 86 | Retained; only normalization or official URL edition update where applicable. |
| 57 | - Integration approach: | 53 | Retained; only normalization or official URL edition update where applicable. |
| 58 |   - Reference for SRU file structure, K4 import process, and review-paper conventions. | 88 | Retained; only normalization or official URL edition update where applicable. |
| 59 |   - Treat as reference-only until the license is confirmed. | 89 | Retained; only normalization or official URL edition update where applicable. |
| 61 | ## Older / Narrower References | 91 | Canonical heading/version replaces old heading; following content remains mapped separately. |
| 63 | - [jonasgroth/swe-income-tax](https://github.com/jonasgroth/swe-income-tax) — MIT JavaScript income tax calculator, useful historically but old. | 93 | Retained; only normalization or official URL edition update where applicable. |
| 64 | - [jonas-johansson/SwedishEconomySDK](https://github.com/jonas-johansson/SwedishEconomySDK) — C# Swedish income tax SDK with examples validated against Skatteverket, useful as an additional reference. | 94 | Retained; only normalization or official URL edition update where applicable. |
| 65 | - [tessin/SKV260](https://github.com/tessin/SKV260) — .NET library for electronic reporting of Swedish control statements to Skatteverket. | 95 | Retained; only normalization or official URL edition update where applicable. |
