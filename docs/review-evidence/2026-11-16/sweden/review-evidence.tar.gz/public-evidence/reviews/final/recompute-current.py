from pathlib import Path
import re,json,hashlib
from decimal import Decimal as D, ROUND_HALF_UP
from datetime import date,timedelta
E=Path('/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-resume-2026-11-16/evidence-sweden');O=E.parent/'review-sweden-final-807ffce81'
a=json.loads((E/'cases.json').read_text());results=[]
# Independent arithmetic written from the example facts and actual statutory/agency methods; no evaluation of writer steps.
vals=[
{'full_offset':50000,'remainder':80000-50000,'deficit':D(30000)*D('.7'),'tax_reduction':D(21000)*D('.3')},
{'standard_income':D(800000)*D('.0355'),'deduction':D(300000)*D('.0355'),'taxable_capital':D(500000)*D('.0355'),'tax':D(500000)*D('.0355')*D('.3')},
{'taxable':D(1000000)*22/30,'tax':D(1000000)*D('.22')},
{'exempt':D(1100000)/4,'taxable_earned':D(1100000)*D('.75')-17400,'state_tax':D(164600)/5,'municipal_tax':D(807600)*D('.3238'),'state_tax_without_relief':D(439600)/5,'state_tax_saved':D(275000)/5},
{'pay':60000*4,'sink_tax':D(240000)*D('.225'),'sink_tax_if_2027':D(240000)/5},
{'expense_debit':12000,'closing_supplier':12000-12000,'journal_debits':12000+12000,'journal_credits':12000+12000},
{'expense':D(24000)/2,'prepayment_asset':D(24000)/2,'reconciled_payment':24000},
{'depreciation':D(100000)/5,'carrying_value':D(100000)*D('.8')},
{'revenue':100000+20000,'year_end_receivable_debit':20000,'later_collection_new_revenue':0},
{'gain':18000-(20000+40000)/4,'remaining_cost':(20000+40000)*D('.75'),'new_cost':D(60000)*D('.75')+25000,'new_units':4,'new_average':D(70000)/4},
{'swap_gain':16000-10000,'new_cost':16000,'spending_gain':16000-16000},
{'deductible_loss':20000*D('.7'),'surplus':20000*D('.3'),'tax':20000*D('.3')*D('.3')},
{'deficit':D(150000)*D('.7'),'potential_credit':30000+D(5000)*D('.21')},
{'cost':10000+100,'net_proceeds':15000-200,'gain':15000-200-10000-100},
{'receipt_income':3000,'disposal_cost':3000,'capital_gain':4000-3000},
{'initial_gain':16000-10000,'income':1000,'claim_cost':16000+1000,'claim_gain':18000-16000-1000,'new_crypto_cost':18000},
{'alternative_cost':D(80000)/4,'gain':D(80000)*D('.75'),'taxable_gain':D(80000)*D('.75')-50000,'tax':(D(80000)*D('.75')-50000)*D('.3')},
{'carryover_cost':10000,'gain':18000-10000,'wrong_market_reset_gain':18000-16000},
{'deduction':8000,'taxable_hobby_surplus':0,'remaining_deficit':12000-8000},
{'tax':D(50000)*D('.3'),'ordinary_penalty':D(50000)*D('.3')*D('.4'),'timing_penalty':D(50000)*D('.3')*D('.1'),'own_initiative_penalty':0,'last_reconsideration_year':2023+6}]
for r,v in zip(a,vals):
 expected={k:D(n) for k,n in re.findall(r'^  ([a-z_]+): ([\d.]+)$',r['raw'].split('expected:\n')[1],re.M)}
 comparison={k:{'expected':str(n),'independent':str(D(str(v[k])).quantize(D('.01'),rounding=ROUND_HALF_UP)),'pass':D(str(v[k])).quantize(D('.01'),rounding=ROUND_HALF_UP)==n} for k,n in expected.items()}
 results.append({'file':r['file'],'case':r['case'],'name':r['raw'].split('name: ',1)[1].split('\n')[0],'raw_sha256':hashlib.sha256(r['raw'].encode()).hexdigest(),'outputs':comparison,'pass':all(x['pass'] for x in comparison.values())})
(O/'case-recomputation.json').write_text(json.dumps(results,indent=2))
extra={'filing2027':{'base':str(date(2027,5,2)),'weekday':date(2027,5,2).strftime('%A'),'adjusted':str(date(2027,5,3))},'filing2026':{'base':str(date(2026,5,2)),'weekday':date(2026,5,2).strftime('%A'),'adjusted':str(date(2026,5,4))},'AB_fee':{'base':str(date(2027,7,31)),'weekday':date(2027,7,31).strftime('%A'),'adjusted':str(date(2027,8,2)),'separate_adoption_deadline':'2027-06-15'},'BFN50days':{'February_end_plus50':str(date(2026,2,28)+timedelta(days=50)),'Q1end_plus50':str(date(2026,3,31)+timedelta(days=50)),'scope':'calendar-day examples recomputed; no newly inferred nonstatutory weekend extension'},'retention':'FY ends30June2026: seventh year after calendar2026 ends31December2033','expert_floor2026':str(59200*D('1.5')+1),'expert_floor2027':str(59600*D('1.5')+1),'K2halfPBB':str(D(59200)/2),'journals':{'correction12000':{'debit_correct_expense':12000,'credit_wrong_expense':12000,'expense_total_change':0},'unpaid_december_service':{'expense_once':12000,'accrued_liability':12000,'invoice_reclass_debit_accrual_credit_payable':12000},'K1collection':{'bank_debit':20000,'receivable_credit':20000,'new_revenue':0}}}
(O/'prose-case-recomputation.json').write_text(json.dumps(extra,indent=2))
print(json.dumps({'cases':len(results),'outputs':sum(len(r['outputs']) for r in results),'all_pass':all(r['pass'] for r in results),'extra':extra},indent=2))
