# Independent Sweden pack review — HOLD

**HOLD at `426f7419baeff22e8132e1526514f478fe0d508d`.** Five operative guidance paragraphs omit material conditions. Two evidence findings also require correction. This is a completed independent review of the full assigned five-Guide candidate and authorised README change, not a sample or a structural-check approval. The reviewer did not write this pack. No candidate or writer-evidence file was edited.

Review date: 16 November 2026. Base: `2844c309238b4fdb63be0a3d0ad9ae99a8ea89c8`. All 16 country markdown files were independently compared with HEAD and the archived base originals: six changed, ten byte-identical. The handoff and final-manifest hashes match the supplied `644bc807b74c901cbe4a372b7c0a265756132fcc23f20802608e44f2d4f2ae2b` and `b36bcfb6401c0e3d9a6c7bff917bf7e5a4e30c7f4b1c1a6f040f2631fec85f63`. All 204 declared evidence artifacts match their sizes and SHA256s. The local origin/main reference equals the base. Fetch failed because github.com DNS resolution failed; no current remote-overlap or publication clearance is claimed.

## Findings requiring correction

All five content findings were checked against complete relevant native provisions and neighboring conditions, then confirmed through ordinary official HTML access. These are conditions on rules already supplied by the candidate, not requests to add new tax topics.

1. **SE-CG-01 — capital gains, line 104: foreign tax credit limits home-sale deferral.** The EEA deferral paragraph omits IL 47:2's final restriction where foreign-tax credit has already been granted under a treaty or the Credit Act. Deferral is limited to the gain portion attributable to tax that was not credited. Add this restriction next to the deferral rule, or explicitly hold that application before calculating an amount. [Official IL 47:2](https://data.riksdagen.se/dokument/sfs-1999-1229.html).

2. **SE-XB-01 — cross-border, line 121: payment abroad overrides the ordinary non-CSD withholding exception.** The candidate says an ordinary company need not withhold where the recipient declaration clearly establishes nonliability. Kupongskattelagen 14 § ends with a mandatory withholding rule for a dividend paid abroad. Preserve that restriction and distinguish payer withholding from liability and refund. Sections 13–16 and 27 were read, so this finding does not assume that every final exemption disappears. [Official Kupongskattelagen](https://data.riksdagen.se/dokument/sfs-1970-624.html).

3. **SE-CR-01 — crypto, line 122: temporary presence abroad is insufficient for the May 31 late-fee protection.** SFL 48:3 requires residence abroad or **habitual** presence abroad at the filing deadline. The candidate's “resident or staying abroad” drops `stadigvarande`. Restore the habitual-stay condition. The separate treatment of the dated 2026 authority deadline and the held future age policy is otherwise appropriate. [Official SFL 48:3](https://data.riksdagen.se/dokument/sfs-2011-1244.html).

4. **SE-XB-02 — cross-border, line 96: population registration is conditional.** The one-year daily-rest instruction says the person must be registered without the express exceptions in 3 §. Sections 4, 5 and 5 a qualify the rule, including required residence right/permit and special protected categories. Qualify the instruction with those eligibility/exclusion conditions or hold eligibility before giving a mandatory-registration result. [Official Population Registration Act 3–5 a §§](https://data.riksdagen.se/dokument/sfs-1991-481.html).

5. **SE-XB-03 — cross-border, line 110: high interest has an enforcement endpoint.** SFL 65:13 changes high interest to base interest after the relevant enforcement/security-execution decision is registered at Kronofogden. The candidate extends the high-rate description to unpaid tax after the due date without that endpoint. State both periods. The authority's actual interest body independently confirms the endpoint as well as the current 2.5%/17.5% rates. [Official SFL 65:13](https://data.riksdagen.se/dokument/sfs-2011-1244.html), [Skatteverket interest](https://www.skatteverket.se/privat/skatter/skattekontobetalaochfatillbaka/rantapaskattekontot.4.18e1b10334ebe8bc80002582.html).

6. **SE-EV-01 — two semantic destination bindings are wrong.** In `old-line-map.json` and the cross-border ledger, original line 199 (“Read on 2026-10-22”) and line 221 (the unresolved treaty/tie-breaker/exit-deferral hold) map to candidate line 200, which is only `## Sources`. The actual source-table replacement is at 202–224; the full retained/extended hold is at 226. Correct the evidence destinations. The reviewer located the material: this is an evidence-binding defect, not a finding that the hold was deleted.

7. **SE-EV-02 — six quote anchors bind unrelated text, and a repealed section is labeled operative.** Correct these rows and every generated copy:

   | Group | Current anchor defect | Actual support independently read |
   | --- | --- | --- |
   | BFL-3-6 | Quotes the IL 6 reference within BFL 3:1 | BFL 3:6 permission rule and its exceptions |
   | SFL-49-14 | Quotes chapter contents | Actual 49:14 unused-deficit paragraph |
   | K2-commencement | Quotes part of K2 2.4 | BFNAR 2025:2 transition, physical PDF page 334 |
   | BFN-framework | Quotes navigation | Whole-framework rule, e.g. K2 1.4, physical pages 22–23 |
   | Kvittning | Quotes navigation | WEB-46 native lines 146–149 |
   | Crypto-mining | Quotes a legal-guidance link | WEB-01 native lines 408–411 |

   Also mark SFL-49-12 as repealed/non-operative; the bound text expressly says it was repealed. Every current short quote occurs in its hashed artifact, but occurrence does not establish that it is the claimed paragraph. The underlying rules above were actually read; the finding is not cured by rerunning the substring checker.

Machine-readable details and exact file locations: `findings.json`. All seven findings are P2 and remain open. This initial HOLD must be preserved if a later correction review is issued.

## Complete populations reviewed

| File | Classified candidate items found / reviewed | Body rows found / reviewed | Original populated lines found / reconciled | Executable cases found / independently recomputed |
| --- | --- | --- | --- | --- |
| references.md | 76 / 76 | 0 / 0; 10 routing, 38 historical, 1 hold | 52 / 52 | 0 / 0; router |
| se-capital-gains.md | 126 / 126 | 39 / 39 | 105 / 105 | 3 / 3 |
| se-cross-border.md | 169 / 169 | 77 / 77 | 166 / 166 | 2 / 2 |
| sweden-bookkeeping.md | 247 / 247 | 117 / 117 | 160 / 160 | 4 / 4 |
| sweden-crypto-tax.md | 298 / 298 | 62 / 62 | 93 / 93 | 11 / 11 |
| README.md | 32 / 32 | 0 / 0; inventory/labels | 32 / 32 | 0 / 0 |
| **Total** | **948 / 948** | **295 / 295** | **608 / 608** | **20 / 20** |

These are explicitly classified populations, not 948 tax rules or 295 numeric figures. Twelve YAML boundary delimiter lines account for the difference between 948 classified items and 960 nonblank candidate lines. All 71 original headings were traced to their actual new sections. The six markdown ledgers were independently checked against the complete JSON populations, source anchors and old-line records; no omitted ledger row was inferred from a sample.

All **240 source groups across 43 official URLs** were independently checked through their actual native operative contexts, exceptions and applicable commencement text. The 240 include one explicit repealed-section check; they are not 240 operative provisions. Source groups repeat across files, and the writer sometimes attaches a broad group set to a single row. Such repetition is not treated as extra source coverage. `source-bindings.json` records each group's quote/hash result, actual context read, finding and scoped disposition; `source-scope-independent.json` records every URL's scopes. No mandatory review unit remains unread within this assigned population.

## Actual source method and limits

The reviewer read the preserved actual official native bodies, rather than treating the handoff, HTTP status, extracted keyword or quoted opening as proof. Relevant whole short chapters and surrounding provisions were read for residence, capital/ISK/loans/deferral/losses, SINK, withholding, foreign credit, penalties, interest, bookkeeping and reporting. Full cited commencement items were checked, including the 2025/2026 ISK and loan transitions, SINK's 2026/2027 rates, BFL 2024:342, ÅRL 2024:1115 and BFN's current K1/K2 versions. Marked future provisions were not applied early.

For BFN, the actual three PDFs and extracted page text were used. All 11 bound page images were independently displayed and inspected, including the cross-page K1 6.38 continuation, computerized correction/completed-period distinction, and K2 scope/accrual restrictions. Additional operative text was read directly in the full PDF extraction, including the real K2 transition on page 334 and the whole-framework rule. This does not claim visual reading of all 82/120/414 manual pages. `pdf-visual-inspection.json` in the writer packet supplies the preserved source/image hashes; our manifest binds those actual files.

Most source acquisitions remain the writer's 16 November acquisitions, independently read by this reviewer on 16 November. Fresh ordinary Riksdagen HTML confirmations of the five condition findings are saved separately in `fresh-official-confirmations.json` and `fresh-IL47-confirmation.json`. Earlier failed ordinary text/human-page requests are not called successful reads. No Firecrawl, paid API, private source or challenge bypass was used. The blocked EUR-Lex directive body has not been silently cleared: the cross-border text only preserves the Swedish statute's requirement to satisfy article 2, without implementing unexamined article-2 eligibility.

## Semantic preservation, examples and invariants

The original five files and README were completely reconstructed for comparison: 470 original lines have exact destinations already read in the whole candidates; every one of the other 138 original lines was read with its complete actual destination. These include punctuation/current-edition changes, source-table conversion, restored conditions, corrected workflow outcomes and labels. This is more than the writer's 91 changed/structural classification. All 608 old identities and mapped candidate texts hash-bind correctly, but SE-EV-01 shows why that alone is not semantic proof. The reviewer supplies the actual replacement destinations without modifying the writer's records.

All five original executable blocks remain byte-exact. All 20 blocks were independently recomputed from the stated facts and actual methods, without evaluating the writer's `steps`: **69 expected outputs pass**. The original 11 crypto prose cases, eight bookkeeping workflow cases and seven journal/control rows were separately read and reconciled. The independent calculations include gain/loss fractions, available-tax caveats, pool timing, gift basis, claim/reward basis, personal-use NFT exemption, same-hobby loss limits, expert/SINK computations, journal clearing/prepayment/depreciation, 2027 filing/weekend dates and the 2033 archive endpoint. `case-recomputation.json`, `prose-case-recomputation.json` and `recompute.py` preserve the results and method.

All 16 files' human approval/name/tier/credit fields and platform lines are preserved. All 15 Guides remain tier 2; no tier-1 file or professional approval was invented. Type declarations and required version/date updates are the only five-file frontmatter changes apart from the router's shape metadata. All ten siblings, including their cases and calculator content, remain byte-identical. The sibling review was for surrounding scope, routing, dependent thresholds and integration, not a fresh full legal review of those ten owners or their numerical fixtures. In particular, the new bookkeeping scope aligns with the unchanged financial-statements K2 gate; qualified-share losses route to 3:12; payroll and residence routes remain distinct. Existing broad sibling summaries do not confer extra clearance on this candidate.

All genuine assigned holds remain explicit: historic project licence/accuracy/integration assertions; home-deferral departure uncertainty; changed-period SINK reapplication universality; country treaties/tie-breakers and unexamined exit events; specialized/K3/entity closing; future filing instructions/age policy; unclassified protocols/receipts/airdrops/forks/insolvency and later FTX distributions. The historic 11.10 FTX/USD rate is dated 2025 and is not approved as a 2026 valuation. README labels do not imply professional approval.

## Validation and disposition

The reviewer reran standards, changed-guide validation, required examples, strict sync integrity and calculator quotes at the exact frozen head. All pass: five empty standards objects, five Guides/zero warning groups, 20 example blocks/zero failures, zero sync errors/warnings/notices, and every protected quoted line retained. Logs are `check-*.txt` with hashes in `independent-local-checks.json`.

The writer's sixth terminal stock source-check result was fully inspected and hash-verified: **26 parsed rows, 0 MISS, 1 UNREADABLE**. The unreadable FSN remuneration row was independently checked through its actual native body, including fixed monthly pay and the 88,801/89,401 floors. The stock run was not rerun merely to freshen access; its zero-MISS result is not legal verification and did not detect the findings above. The initial classification failure log remains preserved in the writer packet.

**Final disposition: HOLD for the seven specified findings at the exact head above.** After precise corrections, an exact-delta review can reuse this full immutable review for unchanged material and check every changed condition, quote, destination and protected input. This is advisory source review, not accountant attestation, filing authority, publication approval or comprehensive Sweden coverage. Root remains the sole publication/merge coordinator. No commits, pushes, PRs, external messages, merge/release or database actions were performed.
