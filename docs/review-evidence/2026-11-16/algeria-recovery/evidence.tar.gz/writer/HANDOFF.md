# Algeria two-guide recovery: writer handoff

**READY FOR INDEPENDENT REVIEW. No independent PASS or accountant approval is claimed.**

- Exact clean head:`b813ce578f93865c259d2e3f0dd158ceb216c48d`.
- Main/base:`bbab4f1a6d82cace432e6ca8eda89c98ffb1c038`.
- Branch:`world/codex-algeria`; worktree:`/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-resume-2026-11-16/wt-algeria`.
- Only changed paths:`skills/algeria/algeria-payroll.md` and `skills/algeria/algeria-social-contributions.md`.
- Versions both0.2→0.3; update date16Nov reflects recovery corrections, while actual completed source reads retain15Nov dates.
- No push, PR, production action or merge. Root owns publication after the separate independent review.

## Recovery and boundaries

Read SCOPES-AND-INTEGRATION.md first. The complete applicable15Nov writer packet was recovered before editing, and allfive main country originals match its exact original hashes. It contains actual official Algerian Gazette/CNRC/AAPI/CNAS source readings and captures, full previous rule/topic inventories, conditions, earlier access failures and genuine holds. Its writer manifests explicitly say independent review pending. No completed independent approval was found or inferred from download/hash records. No broad research or suite was repeated merely for recovery.

CLEISS was replaced as authority by those actually read Algerian sources. No foreign-host waiver/checker change was used. We preserve the previous read scopes/dates and documented extraction limitations, including the Arabic logical-order transcription and lack of visual reading for the2015 French table.

## Corrected

| Original issue | Recovered candidate behavior | Actual authority |
|---|---|---|
| No declared shape; foreign CLEISS used for contribution allocation | Payroll computation/social situation-rules shapes; Algerian enacted table with25% employer,9% employee,0.5% fund,34.5% allocation | Decree15-236 art.1, JO49/2015 |
| Unsupported26%/35% headline and unqualified salary-base defaults | Description reconciled; separate documented bases, no invented universal ceiling/floor; complete FNPOS/social-works cost held |15-236;96-208; complete95-01 generalbase text remains held |
| Universal monthly/10-day/31January social deadlines | Headcount-based monthly/quarterly payment and statutory30-day annual declaration; distinct10-day affiliation/activity duties |83-14,04-17, officialCNRCconsolidation |
| Conflicting generic late-payment rates | Payment/declaration/default/affiliation sanctions distinguished; public-administration exclusions and actual agency statement required |83-14 arts.7,13–16,21,24,44;04-17 |
| CASNOS stale band and5%monthly uplift |2022/2024/2026 amendment chain, annualoriginal-language minimum, actual base ordering, multiple activities, first/thirdyear/choice and5%provisional uplift conditions |15-289,22-121,24-49,26-257,French/Arabic originals |
| Training/apprenticeship treated as identical levies | Separate qualified expenses; under20employee exemption covers training only; special declaration remains; decision worked both ways |LF2022art.56/196ter;LF2026arts.18–21 |

The bounded16Nov changes to the completed drafts are explicitly enumerated in RECOVERY-DELTA.json and RECOVERY-DELTA-LEDGER.json. They correct stale payroll metadata and contradictory base instructions, and restrict full employer/FNPOS-cost claims. They do not change a preserved case input or assert a newly verified legal rate.

## Removed and why / Moved / Not moved

No original legal topic, source-history fact, refusal, bank-pattern family, case input, credit or approval was silently discarded. Unsupported rules are corrected with primary law or retained as unusable historical holds. The original payroll A–N spreadsheet and fullHformula remain verbatim, explicitly not executable current guidance because the old26% cell, universal bases and construction-cost omissions are not safe defaults. Bank matching remains a practical cue requiring records, not proof of legal liability. Tax computation and contribution liabilities remain separate.

Recovered sources and exact current maps cover all451 original populated lines:234payroll and217social; the prior payroll all-line map also preserves its62blanklines(total296). There are33payroll+27social topic groups. Current subsection payload/hash bindings supplement the preserved semantic dispositions; heading-only matches are not a legal no-loss conclusion. DESTINATION-REPAIR.md records stale inherited payroll line positions discovered and corrected across all95groups/33topics/234populatedoldlines; all27socialtopic payloads also bind actual current text. The original15Nov maps remain immutable. No topic moved into another country file. README, income-tax and VAT are byte unchanged. The stale26%/CNAS10%+3% claims in the unchanged income-tax guide remain explicit integration contradictions, not country-wide clearance.

## Review units

- CURRENT-RULE-LEDGERS.json:188 recovered groups,248 preserved quote/capture occurrences with current candidate-line/complete-section bindings. The original full ledgers/read scopes remain in recovered-15nov-packet.
- RECOVERY-DELTA-LEDGER.json:four bounded current overlays. Read these with the prior groups; prior wording is not silently substituted for current restrictive holds.
- CURRENT-OLD-TOPIC-MAPS.json/CURRENT-OLD-LINE-MAPS.json:all60topic groups/all451populatedoldlines; originals/ contains exact main originals.
- SOURCE-CAPTURE-CONTINUITY.json:exact applicability bindings for recovered captures/quotes, not independent legal approval.
- CASE-CONTINUITY-AND-RECOMPUTATION.json:allfour original blocks/inputs exact; five current blocks exact to recovered draft;14expectedoutputs manually recomputed by recovery writer, with eligibility and holds. This is distinct from the required interpreter pass, and is not a separate independent review.
- PROTECTED-CONTINUITY.json:five-country-file before/after evidence; three other paths unchanged; identity/licence/tier/absentapprovalfields protected. No contributor footer existed or was invented.
- CURRENT-ROW-SOURCE-DISPOSITIONS.json:every current UNREADABLE occurrence mapped to complete row, recovered rule/source and prior actual source-reading record.
- COMMIT-RECEIPT.json/candidate.diff:clean exact two-file checkpoint, base and human author. Commit identity does not confer professional approval.

## Targeted verification

Standard19/19each; requiredexamples2files/5blocks/0failures; changed-only validation2guides/0warnings; directorigin/main strictmetadata/version2guides/0errors/0warnings/0notices; calculatorquote and whitespace checks all pass. Live rows:29payroll+21social,0MISS,12UNREADABLE. Unreadable native transport is not legal verification; all12occurrences are mapped to the applicable completed15Nov source read and source limitation. No stockfigure waiver, derivedannotation trick, transport repair or checker change was made. Initial missing sparse mcp dependency failures are preserved and explained in SETUP-ISSUES.md. No full Python suite repeated for content-only recovery; required hostedCI remains.

The assigned reviewer should read every applicable rule/condition and old-topic destination, independently recompute/confirm both source eligibility and allfive cases, and assess the retained source scopes/holds. The current task is limited to these two guides and their explicit dependencies; it does not approve every Algerian tax rule, resolve every legacy owner contradiction or attest as an accountant.
