from pathlib import Path
import json,hashlib,subprocess,re,ast,sys,html
from decimal import Decimal,getcontext,ROUND_HALF_UP,ROUND_FLOOR
import yaml
sys.dont_write_bytecode=True
R=Path('/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-resume-2026-11-16');W=Path('/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-4/thailand');V=W.parent/'thailand-review';E=R/'evidence-thailand-historical-warning-delta';O=R/'review-thailand-warning-736e8a95a'
H='736e8a95acd3d372cf204f3bfc014bf30f6d2340';P='37d804b454b8c703b293a4444d357ccd49811b6c';F='22063bd3ac53b789a44dd428a166e3c548e46cf3';git=lambda *a:subprocess.check_output(['git',*a],cwd=W);sha=lambda b:hashlib.sha256(b).hexdigest();load=lambda p:json.loads(p.read_text());dump=lambda n,d:(O/n).write_text(json.dumps(d,ensure_ascii=False,indent=2,default=str)+'\n')
assert git('rev-parse','HEAD').decode().strip()==H and git('rev-parse',H+'^').decode().strip()==P and not git('status','--porcelain')
pit='skills/thailand/thailand-pit.md';assert git('diff','--name-only',P,H).decode().splitlines()==[pit]
bind=load(V/'candidate-binding.json');assert bind['head']==F and len(bind['files'])==9
country=[];old={};cur={}
for x in bind['files']:
 p=x['path'];a=git('show',P+':'+p);b=(W/p).read_bytes();prior=git('show',F+':'+p)
 assert a==prior and sha(a)==x['sha256']
 if p!=pit:assert b==a
 old[Path(p).name]=a.decode();cur[Path(p).name]=b.decode();country.append({'path':p,'prior_full_review_sha256':x['sha256'],'parent_sha256':sha(a),'candidate_sha256':sha(b),'unchanged':a==b})
src=load(E/'source-and-relocation.json');row=src['old_row'];para=src['new_paragraph'];a=old['thailand-pit.md'];b=cur['thailand-pit.md']
assert a.count(row)==1 and b.count(para)==1
expected=a.replace('version: 1.1\n','version: 1.2\n',1).replace('# Thailand personal income tax v1.1\n','# Thailand personal income tax v1.2\n',1).replace(row+'\n','',1).replace('\nKeep a single retirement-cap worksheet:','\n'+para+'\n\nKeep a single retirement-cap worksheet:',1)
assert expected==b
cell=row.split('|')[2].strip(); assert cell in para and '**Social security (2026):**' in para and '[§47(1)(i)](https://www.rd.go.th/5937.html)' in para
assert 'not the old universal THB 9,000 annual cap' in para
# Every nonblank parent PIT line independently bound, not merely accepted writer map.
parent_lines=a.splitlines();final_lines=b.splitlines();line_rows=[]
def convert(n):
 if n<95:return n
 if n==95:return 99
 if n<100:return n-1
 return n+1
for i,s in enumerate(parent_lines,1):
 if not s.strip():continue
 f=convert(i);actual=final_lines[f-1]
 expected=s
 if i==4:expected='version: 1.2'
 if i==17:expected='# Thailand personal income tax v1.2'
 if i==95:expected=para
 assert actual==expected,(i,f,s,actual)
 line_rows.append({'parent_line':i,'parent_sha256':sha(s.encode()),'final_line':f,'final_sha256':sha(actual.encode()),'disposition':'complete warning cell,label,year,citation preserved as prose' if i==95 else 'required matching version bump' if i in [4,17] else 'byte exact'})
assert len(line_rows)==174
dump('complete-parent-line-bindings.json',{'head':H,'parent':P,'count':174,'rows':line_rows,'exact_delta_whitelist':True})
# Every actual existing payload and topic/old-line destination: preserve full prior semantic review, regenerate exact destination bindings.
proof=load(V/'operative-proof-by-payload.json');assert proof['head']==F and len(proof['payloads'])==404
payloads=[]
for k,x in proof['payloads'].items():
 s=x['payload'];name=x['file'];text=cur[name]
 if k=='thailand-pit-U036':assert s==row;value=para
 else:value=s
 assert value in text,k
 pos=text.index(value); start_line=text[:pos].count('\n')+1; lines=[start_line,start_line+value.count('\n')]
 assert '\n'.join(text.splitlines()[lines[0]-1:lines[1]])==value,(k,'actual full payload span')
 payloads.append({'id':k,'file':name,'prior_payload_sha256':sha(s.encode()),'candidate_payload_sha256':sha(value.encode()),'candidate_lines':lines,'provision_ids':x['provision_ids'],'same_complete_payload':k!='thailand-pit-U036','warning_relocated_verbatim_cell':k=='thailand-pit-U036'})
dump('all404-payload-bindings.json',{'head':H,'count':404,'rows':payloads,'no_new_full_source_review_claim':True})
oldmap=load(V/'old-lines-review.json');assert oldmap['found']==oldmap['reviewed']==812;rebound=[]
for x in oldmap['rows']:
 f=x['file'];par=old[f].splitlines();fin=cur[f].splitlines();dest=[]
 assert len(x['candidate_lines'])==len(x['candidate_destination_payloads']),(f,x['original_line'])
 for n,s in zip(x['candidate_lines'],x['candidate_destination_payloads']):
  assert par[n-1]==s,(f,n,'prior binding does not match')
  nn=convert(n) if f=='thailand-pit.md' else n
  actual=fin[nn-1];exp=s
  if f=='thailand-pit.md' and n==4:exp='version: 1.2'
  if f=='thailand-pit.md' and n==17:exp='# Thailand personal income tax v1.2'
  if f=='thailand-pit.md' and n==95:exp=para
  assert actual==exp,(f,n,nn)
  dest.append({'parent_line':n,'candidate_line':nn,'parent_destination_sha256':sha(s.encode()),'candidate_destination_sha256':sha(actual.encode())})
 rebound.append({'file':f,'original_line':x['original_line'],'original_payload_sha256':sha(x['original_payload'].encode()),'prior_semantic_disposition':x['independent_disposition'],'destinations':dest})
dump('all812-original-line-destinations.json',{'head':H,'prior_head':F,'count':812,'rows':rebound,'prior_complete_semantic_review_reused_for_exact_unchanged_content':True})
top=load(V/'old-topics-review.json');assert top['found']==top['reviewed']==133;rebound=[]
for x in top['rows']:
 f=x['file'];dest=[]
 for n in x['independent_candidate_lines']:
  nn=convert(n) if f=='thailand-pit.md' else n;s=old[f].splitlines()[n-1];t=cur[f].splitlines()[nn-1]
  exp=para if f=='thailand-pit.md' and n==95 else s
  if f=='thailand-pit.md' and n in [4,17]:exp=s.replace('1.1','1.2')
  assert t==exp
  dest.append({'parent_line':n,'candidate_line':nn,'parent_payload_sha256':sha(s.encode()),'candidate_payload_sha256':sha(t.encode())})
 rebound.append({'topic_id':x['topic_id'],'file':f,'prior_independent_result':x['independent_result'],'destinations':dest})
dump('all133-original-topic-destinations.json',{'head':H,'count':133,'rows':rebound,'semantic_no_loss_continuity':True})
# Entire prior official-capture/report chain and writer's immutable handoff verified without altering any byte.
chain=load(E/'prior-review-chain.json');records=[]
for pop in ['reports','captures']:
 for x in chain[pop]:
  p=Path(x['path']);assert sha(p.read_bytes())==x['sha256'];records.append({'population':pop,'path':str(p),'sha256':x['sha256']})
assert len(chain['captures'])==56
wm=load(E/'FINAL-MANIFEST.json');assert wm['head']==H and wm['parent']==P
for x in wm['files']:
 p=E/x['path'];v=p.read_bytes();assert len(v)==x['bytes'] and sha(v)==x['sha256']
vm=load(V/'review-evidence-manifest.json');assert vm['head']==F
for x in vm['files']:
 p=V/x['path'];v=p.read_bytes();assert len(v)==x['bytes'] and sha(v)==x['sha256']
dump('prior-review-and-writer-chain.json',{'head':H,'prior_full_review_head':F,'verified_reports':len(chain['reports']),'verified_source_captures':56,'prior_full_review_manifest_entries':len(vm['files']),'writer_manifest_entries':len(wm['files']),'writer_manifest_sha256':sha((E/'FINAL-MANIFEST.json').read_bytes()),'records':records,'all_hashes_exact':True,'prior_complete_source_reading_not_newly_repeated':True})
# Independent actual fresh official paragraph. Remove comments so historical commented-out provisions cannot masquerade as operative text.
fresh=O/'rd5937-fresh.html';raw=fresh.read_bytes();assert sha(raw)==src['source_body_sha256'];t=raw.decode();t=re.sub(r'(?s)<!--.*?-->',' ',t);t=re.sub(r'(?is)<(script|style)\b.*?</\1>',' ',t);t=html.unescape(re.sub('<[^>]+>',' ',t));t=re.sub(r'\s+',' ',t)
i=t.index('(ฌ) เงินสมทบที่ผู้ประกันตน');start=t.rfind('(ซ)',0,i);end=t.index('(ฎ)',i);scope=t[start:end];q=src['short_exact_native_quote'];assert q in scope and 'ตลอดปีภาษี' in scope and '(ญ)' in scope and 'ตามจำนวนที่จ่ายจริง' in scope
(O/'correct-independent-native-scope.txt').write_text(scope+'\n')
wrong=E/'social-security-native-neighbours.txt';wt=wrong.read_text();assert q not in wt and 'ประกันสังคม' not in wt
source_binding={'head':H,'date':'2026-11-16','official_url':'https://www.rd.go.th/5937.html','fresh_ordinary_GET':{'http':200,'type':'text/html; charset=utf-8','body_path':str(fresh),'bytes':len(raw),'sha256':sha(raw),'same_bytes_as_cached_body':True},'operative_provision':'Revenue Code 47(1)(ฌ), transliterated 47(1)(i)','correct_scope_path':str(O/'correct-independent-native-scope.txt'),'correct_scope_sha256':sha((O/'correct-independent-native-scope.txt').read_bytes()),'short_exact_quote':q,'read_scope':'Full actual-paid insured-person contribution paragraph, following full-year spouse paragraph, their displayed commencement notes, preceding separate mortgage allowance and following separate parent allowance. HTML comments removed before locating actual live text. No universal THB 9,000 annual cap in this contribution clause. No fresh entire Code or all 56-source reading.','rejected_writer_locator':{'path':str(wrong),'sha256':sha(wrong.read_bytes()),'reason':'Contains unrelated crypto-income context; lacks actual contribution clause and claimed neighbors. This artifact is not accepted as legal proof and was not rewritten.','resolution':'Closed by this independent actual fresh-body and correct complete-clause/neighbor record, in addition to valid unchanged prior Q010 operative review.'},'claim_or_warning_changed':False}
dump('independent-source-and-rejected-locator.json',source_binding)
# Whole frontmatter protects all keys except explicitly authorized version; all source rows/dates,holds,people,CTA,quote-bearing lines and cases exact.
blocks=lambda s:re.findall(r'```oa-check\s*\n(.*?)\n```',s,re.S)
getcontext().prec=50
prior_code=(R/'review-global-reviewed-cohort/review.py').read_text();tree=ast.parse(prior_code);funcs=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ['number','calculate']];exec(compile(ast.Module(body=funcs,type_ignores=[]),'<independent-pure-Decimal-evaluator>','exec'))
outputs=[];protections=[]
sys.path.insert(0,str(W/'scripts'));import skill_checks as sc
for name in sorted(old):
 a,b=old[name],cur[name];fa,fb=yaml.safe_load(a.split('---',2)[1]),yaml.safe_load(b.split('---',2)[1]);aa=dict(fa);bb=dict(fb)
 if name=='thailand-pit.md':assert str(aa.pop('version'))=='1.1' and str(bb.pop('version'))=='1.2'
 assert aa==bb and blocks(a)==blocks(b)
 assert a.split('## Sources',1)[-1]==b.split('## Sources',1)[-1]
 assert [s for s in a.splitlines() if re.search(r'Not yet confirmed|Contributed by|Ryan Duguid|ryanduguid|openaccountants-cta',s)]==[s for s in b.splitlines() if re.search(r'Not yet confirmed|Contributed by|Ryan Duguid|ryanduguid|openaccountants-cta',s)]
 for ix,block in enumerate(blocks(b),1):
  d=yaml.safe_load(block);env={k:number(v) for k,v in d['inputs'].items()};steps=d['steps'];steps=steps if isinstance(steps,list) else [steps]
  for step in steps:
   for k,v in step.items():env[k]=calculate(v,env)
  results=[]
  for k,v in d['expected'].items():
   ex=number(v);ok=abs(env[k]-ex)<=Decimal('0.00000000000001');assert ok,(name,ix,k,env[k],ex);results.append({'key':k,'computed':str(env[k]),'expected':str(ex),'pass':ok})
  outputs.append({'file':name,'case':ix,'name':d['name'],'block_sha256':sha(block.encode()),'inputs':d['inputs'],'results':results,'scope':'Arithmetic only, inherited legal content not newly reviewed' if name=='th-top-up-tax.md' else 'Unchanged complete prior legal/prose review retained plus fresh arithmetic'})
 shape={k:v for k,v in sc.run_checks('skills/thailand/'+name,b,fb).items() if v} if name not in ['README.md','references.md'] else None
 if shape is not None:assert not shape,(name,shape)
 protections.append({'file':name,'frontmatter_exact_except_authorized_PIT_version':True,'all_source_sections_dates_holds_and_people_exact':True,'cases_exact':True,'shape':shape})
assert len(outputs)==22
# Current PIT source-table machine check is only lexical; inspect writer terminal result rather than issue an unrequested country-wide network run.
stock=(E/'row-sources-final.txt').read_text();assert re.search(r'28 rows checked, 0 figure\(s\) not found.*0 row\(s\) whose page could not be read',stock) and (E/'row-sources-final.exit').read_text().strip()=='0'
dump('independent-all22-case-recomputation.json',{'head':H,'cases':outputs,'count':22,'rewritten':20,'inherited_arithmetic_only':2,'results':sum(len(x['results']) for x in outputs),'failures':0,'method':'Independent pure AST/Decimal evaluator; precision50, explicit half-up rounding, no repository example-engine call; all 22 raw blocks and legal/prose context exact under complete-delta whitelist.'})
dump('all9-protected-and-source-bindings.json',{'head':H,'parent':P,'prior_full_review_head':F,'country_files':country,'protections':protections,'unchanged_siblings':8,'only_authorized_version_and_warning_relocation':True,'stock':'Actual changed PIT terminal: 28 rows, 0 MISS, 0 UNREADABLE; lexical only, with no fresh whole-country network or legal claim.'})
print(json.dumps({'head':H,'files':9,'siblings_exact':8,'parent_nonblank_PIT_lines':174,'payloads':404,'old_topics':133,'old_lines':812,'source_captures':56,'reports':len(chain['reports']),'case_count':22,'case_results':sum(len(x['results']) for x in outputs),'writer_locator':'rejected; correct fresh independent clause binding supplied','status':'PASS for exact delta and prior full-review continuity'},indent=2))
