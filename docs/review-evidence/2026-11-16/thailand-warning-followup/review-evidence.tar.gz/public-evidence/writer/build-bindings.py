import hashlib
import importlib.util
import json
import pathlib
import re
import subprocess

OA = pathlib.Path('/Users/michaelcutajar/Documents/ChatGPT/OA')
R = OA / 'outputs/world-resume-2026-11-16'
L = OA / 'outputs/world-finish-2026-11-14/lane-4'
W = L / 'thailand'
P = L / 'thailand-review'
E = R / 'evidence-thailand-historical-warning-delta'
BASE = '37d804b454b8c703b293a4444d357ccd49811b6c'
PRIOR = '22063bd3ac53b789a44dd428a166e3c548e46cf3'

def git(*args):
    return subprocess.check_output(['git', '-C', str(W), *args])

def sha(b):
    return hashlib.sha256(b).hexdigest()

def save(name, value):
    (E / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def lines_for(text, payload):
    return [i for i, line in enumerate(text.splitlines(), 1) if line == payload]

head = git('rev-parse', 'HEAD').decode().strip()
old = (E / 'before/thailand-pit.md').read_text()
new = (W / 'skills/thailand/thailand-pit.md').read_text()
row = next(line for line in old.splitlines() if line.startswith('| Social security |'))
cells = [x.strip() for x in row.strip('|').split('|')]
paragraph = f'**{cells[0]} ({cells[2]}):** {cells[1]}. {cells[3]}.'
assert paragraph in new
expected = old.replace(row + '\n', '', 1).replace('\nKeep a single retirement-cap worksheet:', '\n' + paragraph + '\n\nKeep a single retirement-cap worksheet:', 1)
expected = expected.replace('version: 1.1\n', 'version: 1.2\n', 1).replace('# Thailand personal income tax v1.1\n', '# Thailand personal income tax v1.2\n', 1)
assert new == expected
files = []
for item in json.loads((P / 'candidate-binding.json').read_text())['files']:
    path = item['path']
    prior = git('show', PRIOR + ':' + path)
    base = git('show', BASE + ':' + path)
    current = (W / path).read_bytes()
    assert sha(prior) == item['sha256']
    assert prior == base == (E / 'before' / pathlib.Path(path).name).read_bytes()
    files.append({'path': path, 'prior_reviewed_sha256': sha(prior), 'current_main_sha256': sha(base), 'candidate_sha256': sha(current), 'unchanged': base == current})
assert len(files) == 9 and sum(not x['unchanged'] for x in files) == 1
spec = importlib.util.spec_from_file_location('row_checker', W / 'scripts/check-row-sources.py')
checker = importlib.util.module_from_spec(spec)
spec.loader.exec_module(checker)
raw = R / 'figures-diagnostic-2026-11-16/thai-pit-fresh.body'
page = checker.read_bytes(raw.read_bytes())
quote = '(ฌ) เงินสมทบที่ผู้ประกันตนจ่ายเข้ากองทุนประกันสังคมตามกฎหมายว่าด้วยการประกันสังคมตามจำนวนที่จ่ายจริง'
assert quote in re.sub(r'\s+', ' ', page)
start = page.index('(ฌ)')
scope = page[max(0, start - 1500): start + 1800]
(E / 'social-security-native-neighbours.txt').write_text(scope)
before = checker.check_text(row, lambda _: page)
after = checker.check_text(paragraph, lambda _: page)
assert before[1][0][0] == '9,000' and after == (0, [], [])
save('source-and-relocation.json', {'head': head, 'prior_payload_id': 'thailand-pit-U036', 'prior_provision_id': 'Q010', 'old_row': row, 'old_line': lines_for(old, row), 'new_paragraph': paragraph, 'new_line': lines_for(new, paragraph), 'full_warning_cell_retained_verbatim': cells[1] in paragraph, 'label_year_citation_retained': all(x in paragraph for x in [cells[0], cells[2], cells[3]]), 'official_url': 'https://www.rd.go.th/5937.html', 'provision': 'Revenue Code 47(1)(ฌ), English transliteration 47(1)(i)', 'short_exact_native_quote': quote, 'source_actual_read_scope': 'Complete employee actual-paid-contribution clause and immediately following full-year spouse contribution clause, with preceding mortgage and following parent clauses to distinguish their separate caps.', 'source_body_path': str(raw), 'source_body_sha256': sha(raw.read_bytes()), 'actual_capture_read_date': '2026-11-16', 'prior_source_read_date_preserved': True, 'native_scope_path': str(E / 'social-security-native-neighbours.txt'), 'cached_stock_before': before, 'cached_stock_after': after, 'not_a_new_network_read': True, 'no_new_tax_rule_or_professional_approval': True})
case_records = []
for item in files:
    path = item['path']
    prior = git('show', PRIOR + ':' + path).decode()
    current = (W / path).read_text()
    a = re.findall(r'```oa-check\n.*?```', prior, re.S)
    b = re.findall(r'```oa-check\n.*?```', current, re.S)
    assert a == b
    if a:
        case_records.append({'file': path, 'blocks': len(a), 'whole_case_block_hashes': [sha(x.encode()) for x in a], 'all_inputs_steps_expected_byte_identical': True})
save('case-continuity.json', {'head': head, 'total_cases': sum(x['blocks'] for x in case_records), 'cases': case_records, 'prior_independent_case_review': str(P / 'examples-review.json'), 'current_execution_log': str(E / 'examples.txt')})
line_map = []
for num, line in enumerate(old.splitlines(), 1):
    if not line:
        continue
    dest = line
    status = 'BYTE_IDENTICAL'
    if line == row:
        dest, status = paragraph, 'FULL_CELL_TEXT_YEAR_LABEL_AND_CITATION_RELOCATED'
    elif line == 'version: 1.1':
        dest, status = 'version: 1.2', 'REQUIRED_POST_MERGE_PATCH_VERSION'
    elif line == '# Thailand personal income tax v1.1':
        dest, status = '# Thailand personal income tax v1.2', 'MATCHING_VERSION_HEADING'
    found = lines_for(new, dest)
    assert found, (num, line)
    line_map.append({'parent_line': num, 'parent_payload': line, 'candidate_lines': found, 'candidate_payload': dest, 'status': status})
save('complete-parent-pit-line-map.json', {'head': head, 'all_nonblank_parent_lines': len(line_map), 'rows': line_map})
payloads = json.loads((P / 'operative-proof-by-payload.json').read_text())['payloads']
rebound_payloads = []
for ident, payload in payloads.items():
    text = (W / 'skills/thailand' / payload['file']).read_text()
    destination = paragraph if ident == 'thailand-pit-U036' else payload['payload']
    assert destination in text, ident
    rebound_payloads.append({'prior_payload_id': ident, 'file': payload['file'], 'prior_payload_sha256': sha(payload['payload'].encode()), 'candidate_payload': destination, 'candidate_lines': lines_for(text, destination), 'provision_ids': payload.get('provision_ids', []), 'relocated': ident == 'thailand-pit-U036', 'prior_independent_legal_review_reused_not_newly_claimed': True})
save('rebound-404-payloads.json', {'head': head, 'count': len(rebound_payloads), 'rows': rebound_payloads})
prior_artifacts = []
for name in ['FINAL-PACK-REVIEW.md', 'hosted-figures-final-review.md', 'hosted-figures-final-review.json', 'candidate-binding.json', 'review-evidence-manifest.json', 'operative-proof-by-payload.json', 'operative-provisions.json', 'operative-provisions.md', 'old-lines-review.json', 'old-topics-review.json', 'examples-review.json', 'examples-review.md', 'source-review.json', 'source-capture-binding.json', 'preservation-review.json', 'payload-review.json', 'no-loss-review.md', 'diagnostic-review.md', 'coverage.json']:
    p = P / name
    prior_artifacts.append({'path': str(p), 'sha256': sha(p.read_bytes()), 'bytes': p.stat().st_size})
capture_records = []
for item in json.loads((P / 'source-capture-binding.json').read_text())['captures']:
    matches = [p for base in [L / 'thailand-ledgers/sources', P / 'sources'] if (p := base / item['path']).exists() and sha(p.read_bytes()) == item['independent_sha256']]
    assert matches, item
    p = matches[0]
    capture_records.append({'source': item['source'], 'path': str(p), 'sha256': sha(p.read_bytes()), 'previous_independent_hash_matches': True, 'hash_check_is_continuity_not_new_legal_read': True})
save('prior-review-chain.json', {'prior_review_head': PRIOR, 'candidate_head': head, 'full_prior_review_population': {'payloads': 404, 'numeric_occurrences': 1160, 'sources': 39, 'provisions': 86, 'original_topics': 133, 'original_nonblank_lines': 812, 'rewritten_cases': 20, 'unchanged_sibling_cases_arithmetic_only': 2}, 'historical_initial_HOLD_and_four_resolved_findings': ['F01 FBA reinvestment exception', 'F02 export outbound-tour exclusion and foreign use', 'F03 half-year profit basis before bands', 'F04 domestic-water passenger transport with sea opt-in'], 'reports': prior_artifacts, 'bound_capture_count': len(capture_records), 'captures': capture_records, 'limits': ['Original full source/case/no-loss review reused for unchanged bytes; no new full country legal review claimed.', 'Not yet confirmed scopes and README partial/XB/TP gaps remain unchanged.', 'Earlier stock 3 MISS / 1 UNREADABLE report remains preserved; merged parser fixes two format errors.', 'This writer delta is not its own independent approval.']})
protected = {'all_eight_other_country_files_unchanged': sum(x['unchanged'] for x in files) == 8, 'frontmatter_only_required_patch_version': old.split('\n---', 1)[0].replace('version: 1.1', 'version: 1.2') == new.split('\n---', 1)[0], 'last_updated_tax_year_tier_licence_dependencies_people_unchanged': True, 'all_22_oa_blocks_byte_identical': sum(x['blocks'] for x in case_records) == 22, 'not_yet_confirmed_tail_byte_identical': old.split('Not yet confirmed:', 1)[1] == new.split('Not yet confirmed:', 1)[1], 'sources_section_byte_identical': old.split('## Sources', 1)[1] == new.split('## Sources', 1)[1], 'all_9000_occurrences_retained': old.count('9,000') == new.count('9,000'), 'calculator_lines': 'calculator-quotes-final.txt', 'no_checker_code_change': git('show', BASE + ':scripts/check-row-sources.py') == (W / 'scripts/check-row-sources.py').read_bytes(), 'no_new_in_words_or_derived_waiver': old.count('in words on the page') == new.count('in words on the page') and old.count('derived') == new.count('derived')}
assert all(v for v in protected.values())
save('protected-and-no-loss.json', protected)
save('git-and-country-bindings.json', {'head': head, 'parent': git('rev-parse', 'HEAD^').decode().strip(), 'branch': git('branch', '--show-current').decode().strip(), 'base_main': BASE, 'prior_reviewed_head': PRIOR, 'changed_files': git('diff', '--name-only', 'HEAD^', 'HEAD').decode().splitlines(), 'all_country_bindings': files, 'commit_identity': git('show', '-s', '--format=%an <%ae>%n%cn <%ce>', 'HEAD').decode(), 'no_push_publication_merge_or_release': True})
(E / 'minimal-relocation.patch').write_bytes(git('diff', 'HEAD^', 'HEAD', '--', 'skills/thailand/thailand-pit.md'))
print(head, 'bound', len(rebound_payloads), 'payloads;', len(capture_records), 'captures;', len(line_map), 'parent PIT nonblank lines')
