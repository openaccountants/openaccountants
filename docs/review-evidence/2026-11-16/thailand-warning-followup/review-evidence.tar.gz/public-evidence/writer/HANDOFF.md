# Thailand historical-warning follow-up

Frozen local candidate: `736e8a95acd3d372cf204f3bfc014bf30f6d2340`.
Branch: `world/codex-thailand-warning-context-2026-11-16`.
Worktree: `/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-4/thailand`.
Parent/current-main snapshot: `37d804b454b8c703b293a4444d357ccd49811b6c`.
Previous independently reviewed country candidate: `22063bd3ac53b789a44dd428a166e3c548e46cf3`.

## Exact change

Only `skills/thailand/thailand-pit.md` changes. The entire social-security warning cell is retained verbatim in a paragraph immediately below the same allowances table, including the historical THB 9,000 cap rejection, actual legally paid employee contribution requirement, payroll reference, 2026 scope and same Revenue Code citation. No alternative rule is introduced. The historical actual-payment example and every case remain unchanged.

Both original PR #2084 and software PR #2095 were already merged at the fresh ownership check. All nine Thailand files on that main snapshot matched the previously reviewed candidate exactly. No open PR touches `skills/thailand/`, verified again at closeout. Historical OWNERS assignment to Ryan is not treated as approval to edit his top-up guide, which remains byte-identical.

Because this is now a post-merge follow-up, strict sync initially rejected the unchanged version/date. Root explicitly authorised the necessary patch-version change: frontmatter `1.1` to `1.2` plus matching body heading. `last_updated: 2026-11-16` is unchanged. The raw initial sync failure remains in `sync-working.txt`; `sync-final.txt` passes. No approval/person/tier/licence or tax-period metadata changes.

## Validation at frozen head

- Seven complete country skill standards are empty; the changed skill was rerun after the version change and remains empty.
- Changed-file validation: one skill, zero warnings.
- All seven country skills: 22 recomputing cases, zero failures/missing; all complete case blocks are byte-identical to the prior independently reviewed head. The previous independent review covered 20 rewritten cases and arithmetic of two unchanged top-up cases; no new top-up legal review is claimed.
- Committed strict sync: one guide, zero errors/warnings/notices.
- Calculator quotes and diff whitespace pass.
- **Unmodified merged-main stock figure checker**, final committed PIT skill: 28 rows, zero MISS, zero UNREADABLE, exit zero. `row-sources-final.txt` is the final-head terminal run. Earlier `row-sources-pit.txt` ran the identical table content before the necessary version heading change and is retained separately.
- A cached actual-source replay using this exact stock checker reproduces the former negative-row 9,000 MISS, then zero table figures for the relocated paragraph. Separate cached replays prove that the unchanged NBT 2.75% row and RD 1,800,000 row now pass the merged parser against their preserved official bodies. Cached replays are not new network reads or fresh whole-country legal review.
- The previous image-only DBD row and original hosted 3 MISS / 1 UNREADABLE logs remain in the original evidence. No full-country fresh live figure pass is claimed by this one-skill delta.

## Source and no-loss continuity

`source-and-relocation.json` binds prior payload `thailand-pit-U036` and provision `Q010` to the relocated paragraph. Actual cached Thai law read on 16 November covers Code 47(1)(ฌ), the actual legally paid contribution wording, the following full-year spouse condition and adjacent separate allowances. `social-security-native-neighbours.txt` preserves the actual scope. This relocation does not expand any deduction condition.

`prior-review-chain.json` binds the complete prior report, initial resolved findings, clause/native records, full old-topic/line maps, case review and 56 actual source captures by their existing independent hashes. These are continuity checks, not an assertion that matching hashes verify law. `rebound-404-payloads.json` proves that every one of the 404 previously semantically reviewed payloads remains exact, except the complete warning row now represented as the same prose text/year/citation. `complete-parent-pit-line-map.json` maps all 174 nonblank parent PIT lines, including the two authorised version substitutions and exact relocation. The prior 133-topic/812-original-line semantic review remains unchanged and composes with this complete one-file delta map; it is not relabelled as a newly performed 812-line source review.

All eight other country files, all 22 `oa-check` blocks, every source row/date, all existing holds/refusals, human metadata, credits and historical fixtures are unchanged. README still records partial coverage and genuine TP/XB work. No accountant approval or comprehensive country completion is claimed.

## Next action

Root should assign a separate independent delta reviewer. This writer's source diagnostic and continuity work do not supply independent approval. No push, PR creation, external publication, merge or release has occurred. The local working tree is clean. Root owns further publication and merge decisions.
