# Liechtenstein writer handoff

Two assigned unsigned tier-2 Guides completed in place, v0.3 to v0.4, last_updated 2026-11-16. No branch, stage, commit or publication performed by writer. Baseline origin/main bbab4f1a6d82cace432e6ca8eda89c98ffb1c038. Latest full paginated open PR scan before edits checked9PRs, no overlap; reservation has no Liechtenstein.

48-row full rule ledger: ledgers/li-company-formation.md(28), ledgers/li-tax-overview.md(20). Complete old-topic and worked-input preservation map: NO-LOSS-MAP.md. Both original formation oa-check blocks byte-identical. No material removal. Protected CTA/licence remain byte-identical.

Corrections: CHF10000 reporting gate (SteV43); VAT qualifyingturnover and exceptions; employer7.385%includesVK and ALVcap; reviewwaiver unanimoussupremeorgan; separate subsistence screen/wealthyieldguard. Directofficialrowcitations,shapes,requiredinputs,scopedreadrecords added. Overview municipal endpoints now recompute20%/28%/8pp under explicit assumptions.

Checks: skill-checks.json both {}; check-examples 3blocks0failures; strictworktree sync2guides0errors0warnings; scopedworktree validator2guides0warnings. Directnative rowchecker: formation5rows,overview9rows,0misses0unreadable (row-sources-direct.log). git diff --check passes. Native changed-onlyatcommittedhead is parent task. Pytest unavailable; unittest22tests has1sparsefileerror at agent-skills/LICENSE.md for whole-repo copy rules, parent handling unchanged sparse dependencies; calculator tests pass. Honest failure traces preserved in tests.log and tests-unittest.log.

Sources: current official PGR,SteG,SteV,MWSTG,AHV PDFs directly downloaded once with escalatedurllib after sandboxDNSfailure. GmbH direct403; ordinarywebreader read5pages,sections1-12. Official registration,taxauthority,commonVATterritory substantive paragraphs read. Rawcache stays local,do not include source PDFs/text in publicevidence. Prior October full review and closure preserved byte-exact under prior-review; that prior review is historical, current48rows require fresh review.

Exact candidate hashes,sourcehashes,checks,andholds: CHECKPOINT.json. Fresh independent review pending; writer does not self-certify. No accountantapproval claimed.
