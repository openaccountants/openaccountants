# Complete old-topic and input destination map

Baseline origin/main bbab4f1a6d82cace432e6ca8eda89c98ffb1c038. All old paragraphs, tables, refusals, examples and input values mapped below. No material removed; no file is smaller. Headings were rearranged to declared shapes. No accountant/credit/CTA edits.

## li-company-formation

| Old topic/input | New destination and disposition |
|---|---|
| Description and scope | Same metadata, Scope;year2026/minimum tax/referrals retained |
| Business, founders, control, work/management, funding, address, governance, licensing, accounts, BO evidence | Scope and Ask the client first;all retained |
| Four capital rows incl each CHF/EUR/USD alternative | Capital table;added per-row direct official links |
| Nominal currency vs exchange conversion and minimum fully paid | Capital narrative unchanged |
| AG subscribed capital/per-share25%/overall minimum/higher articles | Capital narrative and AG case unchanged |
| GmbH CHF50/multiples/quotas/full payment/in-kind/free disposal | Capital narrative unchanged |
| Six ordinary preparation steps | Method steps1-6 retained verbatim apart headings |
| Qualified180a management/licence/equivalence/exceptions/foundation caveat | Management evidence retained;spacing fixed |
| 180b exclusions, EEA, registration declaration, later representation removal, five years | Management evidence retained |
| 1064 first/two-period rules/waiver not automatic | Accounts paragraph retained |
| 1063 legal form/currency/special1057/P.I.E. scope | Ordinary size workpaper retained |
| Micro580000/1160000/10 | Same row direct source added |
| Small9.2m/18.5m/50 | Same row direct source added |
| Medium32.4m/64.8m/250/exceed2small | Same row direct source added |
| Large exceed2medium | Same row direct source added |
| Jan2024commencement/equality2of3/2dates/firstapplication/nonCHF prescribed | Size narrative retained |
| Audit vs review small/specialdisclosure/noautomaticassuranceexemption | Assurance narrative retained |
| Commercial micro waiver/excluded segmented/bearerAG/unanimity/declaration/minutes/currentaccounts/registration/articles/memberdemand/authorityrecheck | All retained;decision clarified supreme organ, not management |
| 1122approvedaccounts/report/twelfthmonth/actualextension/electronicreceipt/waiverdoesnotcancelfiling/taxseparate | Same disclosure narrative retained |
| Fees/latepenalty/businesspermission not covered | Same referral paragraph |
| GmbH case narrative and exact original oa-check | Same Worked cases, inputs4000/3000/3000/10000 and outputs10000/0 byte-exact block |
| AG case narrative and exact original oa-check | Same Worked cases, inputs100000/.25/50000 and outputs25000/50000/50000 byte-exact block |
| Ask and refer full original list | When to refuse or refer, unchanged text |
| Sources and source link definitions | Same sources scoped read descriptions+actualnewreaddate;registrationref retained |
| Not yet confirmed full six topics | Same fees,timeline,latepenalty,trust/fullfoundation,nonCHF,BO list |
| Platform CTA and licence | Byte-exact protected CTA and unchanged licence |

## li-tax-overview

| Old topic/input | New destination and disposition |
|---|---|
| Description/all triggered domains | Same metadata retained |
| Start facts before routing | Ask the client first+method;all original facts retained |
| Seven topic rows and all sibling filenames | Same routing table retained |
| Tax authority, CHF, calendar/short/fiscal year | Same headline rows direct sources |
| Worldwide resident/company, nonresident property/PE/listed income | Same row plus exemption caveat |
| Six taxes plus GloBEseparateAct | Same row |
| Statebasic15855/23783/31710,0%,1%-8% | Same row, separate subsistence screen added |
| 4%wealthyield | Same row, double-counting guard added |
| Municipal150%-250%,annualsetting,noat-source,20%-28%and8%x2.5/x3.5 | Same row and added recomputing endpoint control;all original inputs preserved |
| No inheritance/gift tax;notincome;report donor/recipient/heir | Same row corrected CHF10000reportgate;all categories preserved |
| Corporate12.5%/1800credit/exclusivelycommercial/3year500000exception | Same row with handoff scope |
| No dividendinterestroyaltysourceWHT;wages/replacement/board/pensions/12%entityboard | Same row refined domestic-law scope |
| VAT8.1/2.6/3.8/100000worldwide/commonterritory | Same row;qualifying-turnover/otherexemptions/option corrected,territory primary authority added |
| Employee4.9+.5/employer7.385+.5 | Same row;VKand126000cap/partyear/otherinsurance qualified |
| 4%lateinterest | Same row |
| Authority and lawregister entrypoints | Same paragraph retained |
| No old calculation blocks | Added1derivedcontrol;no earlier examples lost |
| Sources previous five entries | Same sources, scoped actualreads;addedofficialcommonterritorypage |
| Unconfirmed2026filingdatesandactualmunicipalitysurcharges | Same Not yet confirmed |
| CTA/licence | Byte-exact protected CTA and unchanged licence |

