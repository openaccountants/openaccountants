# Liechtenstein independent assigned-pack review

Reviewed on 2026-11-16 by a fresh separate AI reviewer. This is source review, not accountant approval. Scope is the complete two-Guide assignment only; it is not a review of the other Liechtenstein Guides or comprehensive country coverage. No Guide, Git object, approval or public system was changed.

## Conclusion

PASS for the documented source-supported partial scope at the exact hashes below. All 48 ledger rows were reviewed (28 formation,20 overview), including their constituent figures, conditions, neighboring exceptions and explicit holds. No actionable legal/source correction found. Three controls independently recomputed without importing writer formulas; all pass. This conclusion does not establish actual fees, municipality rates, taxpayer facts or filing readiness.

## Exact Guide identity

- `skills/liechtenstein/li-company-formation.md`: SHA256 `15825eac18d84eac1c9bd9dedf13e4b64c33373bb8e957fc307cbf4eb7682ab3`
- `skills/liechtenstein/li-tax-overview.md`: SHA256 `d45d33d97e97c9d5d30d042e30147dfa7c8fe549b3a09cf848e789b23f846c36`

## Source provenance and reading

Read writer ledgers, CHECKPOINT, complete Guide text, complete no-loss map, baseline changes and prior 24 October review. The historical review is background evidence only; this receipt independently reads current ledger scope rather than extending its historical whole-pack certification. Reused official cached extracts for PGR (consolidated1September2026), SteG/SteV (1July2026), MWSTG (1January2026) and AHV2026 bulletin. Cached PDF identities match the writer manifest; source identity is not treated as content review. Actual operative passages and neighboring exceptions were read. PGR monetary amendment notes1952-1959 explicitly apply the changed thresholds to financial years beginning on/after1January2024.

Independently opened current official GmbH fact sheet (07/2025), read sections1-12, and current register, tax-administration responsibilities and common-VAT-territory pages through web reader on2026-11-16. Read substantive paragraphs and template-link descriptions; did not submit forms. Full official captures remain local and are not included here.

Official sources: [PGR](https://www.gesetze.li/konso/pdf/1926004000), [SteG](https://www.gesetze.li/konso/pdf/2010340000), [SteV](https://www.gesetze.li/konso/pdf/2010437000), [MWSTG](https://www.gesetze.li/konso/pdf/2009330000), [AHV2026](https://www.ahv.li/fileadmin/user_upload/Dokumente/Online-Schalter/MB/AHV-IV-FAK-MB-1-01-2026--AHV-IV-FAK-ALV-Beitraege.pdf), [GmbH sheet](https://www.llv.li/serviceportal2/amtsstellen/amt-fuer-justiz/handelsregister/merkblaetter/007_merkblatt_zur_gmbh.pdf), [registration](https://www.llv.li/de/privatpersonen/beruf-und-arbeitsplatz/handelsregister/eintragungen/gesellschaft-mit-beschraenkter-haftung), [authority](https://www.llv.li/de/landesverwaltung/steuerverwaltung), [VAT territory](https://www.llv.li/de/landesverwaltung/steuerverwaltung/mehrwertsteuer).

## Per-row outcomes

|Ledger ID|Outcome|Actual support inspected|Result and conditions|
|---|---|---|---|
|F01|PASS|PGR390(1), GmbH fact sheet1-2|Registration and authenticated articles are constitutive for GmbH; no signature-only personality.|
|F02|PASS|PGR122(1),(1a)|10,000 CHF/EUR/USD alternatives match.|
|F03|PASS|PGR122(1),(1a)|50,000 CHF/EUR/USD share-capital entity alternatives match.|
|F04|PASS|PGR122(1),(1a)|30,000 CHF/EUR/USD non-share-capital entity alternatives match.|
|F05|PASS|PGR552 section13(1)|Foundation 30,000 in each nominal currency; full foundation regime explicitly excluded.|
|F06|PASS|PGR122(1a)-(2)|Full statutory minimum payment and nominal currency distinction match.|
|F07|PASS|PGR284(1),122(2)|Full subscription, minimum25% each share, higher articles and overall minimum retained.|
|F08|PASS|PGR391(1),(3)-(6)|50 minimum, multiples/quotas and fully contributed ordinary single holding match.|
|F09|PASS|GmbH fact sheet7-8|Noncash expert report and free disposal after registration match current authority sheet.|
|F10|PASS|PGR390(5)|At most3 members, one manager, model/no deviations/authenticated signatures match.|
|F11|PASS|PGR390(2),394|Essential articles and register details supported; workflow calls for actual documents.|
|F12|PASS|PGR180a(1)-(4)|Qualified representative/licence/equivalence and supervised/trade/association exceptions retained, foundation caveat retained.|
|F13|PASS|PGR180b(1)-(6)|Specified incapacity/intentional convictions, EEA equivalents, declaration, later deletion/resignation,5years from finality match.|
|F14|PASS|PGR1063,1057|Exact entity scope and special-disclosure testing retained.|
|F15|PASS|PGR1064(1a)|580000/1160000/10; at least2 not exceeded correct.|
|F16|PASS|PGR1064(1)|9200000/18500000/50; at least2 not exceeded correct.|
|F17|PASS|PGR1064(2)|32400000/64800000/250 and two small exceeded/two medium not exceeded correct.|
|F18|PASS|PGR1064(3)|At least2 medium criteria exceeded correct.|
|F19|PASS|PGR1064(4)-(5),notes1952-1959|Two dates and first-date first application correct;2024 monetary commencement read; nonCHF held rather than converted.|
|F20|PASS|PGR1058(1)-(4)|Audit versus review and special disclosure distinguished; no automatic assurance exemption.|
|F21|PASS|PGR1058a(1)-(3)|Commercial micro eligibility, segmented/bearer exclusions, unanimous supreme organ correct.|
|F22|PASS|PGR1058a(4)-(9)|Continuing waiver/member demand, signed declaration/current evidence, registration/deletion/articles and authority recheck supported.|
|F23|PASS|PGR1122(1),(3)-(6)|Twelfth month deadline, actual extension, report waiver and electronic route correct for stated covered-company scope; special partnerships remain entity-scope screen.|
|F24|PASS|Current authority registration page|Read substantive registration paragraph and current ordinary/simplified/waiver template links; no submission acceptance inferred.|
|F25|PASS|SteG62(1)-(3)|1800minimum and actual commercial/three-year500000exception supported.|
|F26|PASS|PGR122,391; assumed facts|4000+3000+3000=10000;10000minimum yields0shortfall; no registration conclusion.|
|F27|PASS|PGR122,284; assumed facts|100000quarter=25000;50000overall minimum dominates;50000unpaid; share-wise condition retained.|
|F28|PASS|Guide scope/Sources/referrals|Every listed hold/referral is non-usable, not an invented exemption.|
|O01|PASS|Seven local sibling files|All seven paths exist; router delegates detailed eligibility and calculation.|
|O02|PASS|Tax administration responsibilities paragraph|Current authority page expressly states SteG and MWSTG responsibility.|
|O03|PASS|SteG14(5),47(6),19|CHF denomination and calendar/short-year/ended-financial-year rules supported.|
|O04|PASS|SteG6,44; adjacent45/48|Worldwide resident/seat/management rule and listed domestic nonresident scope match; exemptions expressly reserved.|
|O05|PASS|SteG1|Listed taxes and separate minimum-tax act reservation match.|
|O06|PASS|SteG19(1),15(2)(i)|15855/23783/31710zero bands and1%-8% correct; distinct subsistence gate now referred before calculation.|
|O07|PASS|SteG5,14(2)(l),15(1)|4%standard return correct; actual yield double-count guard supported.|
|O08|PASS|SteG75,19|150%-250%annual council surcharge, source-tax exception and20%-28%derived endpoints correct.|
|O09|PASS|SteG1,15(2)(c),96;SteV43|No separate listed inheritance/gift tax; one-off gains income-exempt; donor/recipient reporting from10000 correct.|
|O10|PASS|SteG61-62|12.5%,1800credit and exclusive-commercial three-year average<=500000exception match; short period delegated.|
|O11|PASS|SteG24-25,44(3)(d),63a|No general source tax for listed investment payment categories under inspected provisions; positive wage/board/pension categories and12%entity-board gross match.|
|O12|PASS|MWSTG25(1)-(4)|8.1/2.6/3.8match; reduced classification and restaurant/takeaway/accommodation neighboring rules read, detailed supply classification delegated.|
|O13|PASS|MWSTG10-11|Strictly below100000worldwide qualifying turnover, excluded21(2)supplies, other exceptions and option supported.|
|O14|PASS|Current VAT authority substantive paragraph|Common Swiss/LI VAT territory explicitly confirmed by treaty explanation.|
|O15|PASS|2026AHVbulletin2-6|Employee4.025+.675+.2=4.9%;ALV.5 separate;age/status gates delegated.|
|O16|PASS|2026AHVbulletin5-6|Employer4.225+.675+1.9+.585=7.385%;VKincluded;ALV.5separate; other insurance separate.|
|O17|PASS|2026AHVbulletin6|126000each employment and350/day part-year basis read; Guide correctly warns part-year adjustment.|
|O18|PASS|SteV45;SteG114(3)|4%tax late interest supported; no universalVAT assertion.|
|O19|PASS|SteG19,75;derived arithmetic|8%state+150%of8%=20%;+250%of8%=28%;difference8percentagepoints correct.|
|O20|PASS|Router/Sources/referrals|No standalone liability;special regimes and current municipality/return dates held rather than asserted.|

## Arithmetic and preservation

Independent arithmetic from original inputs: GmbH4000+3000+3000=10000, statutory shortfall0. AG100000/4=25000;50000statutory minimum requires another25000beyond the quarter and leaves50000unpaid subscription. Overview8+12=20% and8+20=28%, a difference8percentagepoints. These are conditional arithmetic screens, not eligibility certifications.

Compared both baseline Guide blobs at `bbab4f1a6d82cace432e6ca8eda89c98ffb1c038` with candidate and checked every no-loss-map destination. Formation's two original oa-check blocks are byte-identical; every old input, contribution rule, six preparation steps, management exception, size/assurance/disclosure condition and refusal remains. Router retains all seven routes and former headline topics; new qualifications correct missing conditions without narrowing the old scope. The new overview control uses all previously stated endpoint factors. No material topic removed; neither file shrank. Protected CTA suffixes remain byte-identical and tier2 remains.

## Holds and workflow boundary

Existing non-usable holds remain: registry fees/duration/late-account penalties, trusts/full foundation regime, nonCHF size thresholds, beneficial-owner particulars; actual2026municipal rates and individual/corporate return deadlines. Specialist tax regimes, treaties, management/residence disputes and complete annual-account/sustainability calculations are referred. The broad company-formation introduction is read within its expressly GmbH-centred scope, not as proof that every foundation requires constitutive registration.

This reviewer did not rerun repository validation/tests or certify publication packaging; writer/parent owns actual-head gates. An inherited `domain: formation` in the formation Guide is outside the declared domain vocabulary (Finland corrects the analogous metadata); this is a metadata clean-up observation, not a legal finding or this source-review blocker. Any changed legal claim, source applicability or worked input needs focused re-review; wrapper/hash-only movement does not renew this review.
