# San Marino independent scoped country review, 16 November 2026

Reviewer: fresh agent `/root/review_sm`, separate from the writer. Scope: only `skills/san-marino/sm-company-formation.md` v0.4 and `sm-tax-overview.md` v0.7. Both remain tier 2. No Guide edits, Git mutations, publication, merge, portal operation or professional approval by this reviewer.

Outcome: one P2 finding corrected and closed; no blocking finding remains within the expressly partial selected-method scope. Keep the country PR draft while the complete post-November-2024 company/licensing amendment chain remains genuinely unconfirmed. This review does not establish comprehensive 2026 incorporation readiness.

## Exact receipt

Initial reviewed SHA256s: formation `62a67ffc54e1ba02b81564012e0913d2a46878cc1edf932526db61eb03a0175d`; overview `03f5825858149d5481a3d9ebce913c1e61e38cd0171a1dc0e859e99384e2238d`.

Closed formation SHA256: `1c3cd501dc471cc9ee6926d409600cfc109ef4582ea8b37e9248f5b460f98df0`; overview unchanged. `REVIEWED-MANIFEST.json` identifies final exact bytes and preservation counts. A later branch/hash/report-wrapper change does not reopen unchanged source review.

All 50 ledger rows are inventoried individually in `ROW-OUTCOMES.json`, with article, URL, rule, review method, outcome and actual read inputs. Thirty rows reuse completed independent primary-source review after one applicability check; twenty receive a new independent delta/dependency read. Reuse is the substantive October full-pack selected-law review and exact correction closure in `san-marino/prior-pack-review.md`, not successful downloads or green checks. The eight material retained source bodies (company and IGR archives, Law80/2022, Law141/2025, DD156/2026, DD133/2026, DD183/2011 and revised ISS circular) were hashed locally and all identities occur in that prior independent record. The current unchanged baseline claims and their express holds were compared with the old/current Guides. The prior review remains historical, with its original date and scope; it was not silently redated.

New independent reads cover declaration alternatives; DD43/2025 reserved-activity/transition/repeal provisions; registration articles and UAE pp17-18; AIF sections1/3 with neighboring exceptions; the full art50(2) remote-board provision; Law80 commencement; IGR93 deadline/closure,2(d) authority,73 incentive deferral/maintenance and102-104 withholding conditions; DD50 listed final-customer scope/exclusions; and DD133 arts1-2/11 boundary/commencement. Currency was independently opened and read at [Foreign Affairs, Monetary Agreement](https://www.esteri.sm/pub2/EsteriSM/en/UE/Altri-accordi.html), section lines122-131 on 16 November 2026; the writer's empty `cache/euro` is not evidence. The page expressly identifies euro as official currency and the agreement's 1 September 2012 entry into force.

## Finding and focused closure

P2-1, F25: the expanded remote-board paragraph omitted the operative condition that statutes must not expressly prohibit remote audio/video meetings. Law47/2006 art50(2), retained `cache/companies0.pdf.txt` lines1636-1660, requires that switch. The source also assigns complete audiovisual recording and at-least-two-year retention duties differently depending on the chair's location.

The parent corrected only that paragraph. I read the resulting paragraph at line 75 and compared it with the complete art50(2) provision. It now states the statutory-prohibition switch, audiovisual form, secretary's full recording, president's two-year retention when in San Marino and notary-secretary's corresponding duty when the chair is abroad. P2-1 is closed at the final hash above. The source's other applicable minute/statute requirements remain expressly routed to art50 and the Guide's referral paragraph; this is a summary, not remote-meeting execution advice.

## Preservation and independent controls

Every old nonblank line has a destination:107 formation lines and 69 overview lines, zero missing numbered destinations. I compared old/current content and destination maps for retained topics, exclusions, all seven original specialist routes, source provenance and case values. No protected contributor/approval/CTA content existed in these two old files. Both original formation scenarios retain all input/output values; the alternative-SRL decision adds comparison outputs. Neither Guide shrank 25%.

All three controls independently recompute using separate Decimal formulas, without evaluating Guide step strings or importing the repository checker. `INDEPENDENT-CONTROLS.json` records exact inputs and derived outputs. Ordinary SRL: 15300/10200 subscriptions, 7650/5100 initial, 12750 total/remainder. Alternative SRL: 9000 required, 4500 shortfall, 12750 ordinary initial, 16500 subscription difference. Conditional 100000 profit: 18000 ordinary tax, 9% conditional rate, 9000 conditional tax and9000 difference. Arithmetic does not establish incentive entitlement.

## Limits and retained holds

The complete later company/licensing amendment chain remains open; DD43, the 2025 service charter and 2026 AIF FAQ are selected updates, not a complete current consolidation. Fees, audit thresholds, full accounts filing, special regimes and full RegTE fields/sanctions/correction procedures remain explicit unconfirmed items. The overview retains actual 2027 office-opening/later-extension uncertainty, treaty/rate/procedure handoff and exact-equality e-invoice persistence uncertainty. These are non-usable holds, not inferred rules or source-review passes.

This reviewer did not rerun unchanged writer check suites. Exact committed-country-head schema, example, strict sync, row-source and required CI gates remain the parent's publication responsibility. A read-only old Git object lookup could not retrieve a missing promisor object because sandbox DNS to GitHub failed; no historical exact-Guide identity is invented from that attempt. Retained actual source identities, dated substantive review and old/current rule comparison establish the limited reuse recorded here. Raw PDFs, archives, scans and extracted full texts remain local under the writer cache and are excluded from public review outputs.

Written by Codex (world wave). Not reviewed by an accountant.
