# San Marino writer handoff, 16 November 2026

Scope: `skills/san-marino/sm-company-formation.md` (0.3 to 0.4) and `skills/san-marino/sm-tax-overview.md` (0.6 to 0.7), both tier 2. No branch, stage, commit, push, PR, deployment or production action was performed by this writer. Main observed: `bbab4f1a6d82cace432e6ca8eda89c98ffb1c038`.

The pre-edit reservation and complete paginated file check found nine current open PRs, no assigned-file overlap and no Claude reservation overlap. Records: `pre-edit-open-pr-files.json`, `current-open-pr-numbers.txt`. The writer read the common brief, repository AGENTS.md and entire skill-template. Existing October source retrieval, reconciliation and independent review were recovered byte-exact as `prior-*`. That prior review covered older versions and is provenance only, not current review approval.

## Corrected

| Old | New | Authority |
|---|---|---|
| Payment proof described only as sworn notarised declaration | Statutory declaration forms or notarised oath, within 30 days | Law 47/2006 art 10(5), F12 |
| Generic notary registration | OPEC case names, documentary attachments, 15-day filing and ordinary three-working-day response, electronic confirmation/refusal | Law 47/2006 arts 6/20; July 2025 UAE service charter pp 17-18, F20-F21 |
| Beneficial-owner procedure wholly open; article 17 treated broadly | RegTE legal representative/delegate route, first/change 30 days and annual confirmation from 2026; article 17 correctly limited to fiduciaries | AIF March 2026 FAQ sections 1-3, Law 92/2008 art 23-quater; F23-F24 |
| Only pre-November 2024 permission reference | Later DD 43/2025 reserved-activity screen added; full amendment chain still open | DD 43/2025 arts 1, 4-6; F18 |
| Remote board rule too brief | Chair-in-country and chair-abroad secretary/minute/recording distinction | Law 47/2006 art 50(2), F25 |
| Overview promises 31 July 2027 without closure condition | Statutory date qualified by next office-opening rule | IGR art 93(1), (4)-(5), O01 |
| Currency row uncited | Official Foreign Affairs monetary-agreement source on row | O02 |
| Overview lumps withholding rates into universal payment categories | Capital source/rate exclusions, recipient/category/territorial conditions and treaty handoff stated | IGR arts 5, 102-104, O13-O16 |
| Domestic e-invoice threshold compressed | COE domestic scope, exact-equality annual boundary and distinct continuing-use rule | DD 133/2026 arts 1-2, 11; O17-O18 |
| No declared shapes and no overview example | situation-rules/router; two retained formation controls and one new conditional-rate router control | Template standard; O07-O08/F07-F10 |

## Preservation and evidence

`LEDGER.md` and `ledger.json` inventory 50 source-backed rule/figure rows, operative articles, official URLs, native snippets and actual 16 November read date. Every old nonblank line, including sources, exclusions, metadata and every original worked-case input/output, is mapped in `NO-LOSS-sm-company-formation.md` and `NO-LOSS-sm-tax-overview.md`. The two old Guides are frozen in `old-sm-*.md`. No topic or original scenario value was removed, no protected credits/CTA existed, and neither file shrank by 25%. Reference-link syntax was converted to inline URLs for row checking. The unsupported `domain: formation` was removed, retaining category formation.

`guide-manifest.json` binds the current draft SHA256s and byte sizes. Raw authority PDFs/ZIPs/scans and page images remain under local-only `cache/` and must not go into public evidence. `retrieval.json` records the original twelve re-fetches; the company/IGR archive and the six old direct-source hashes matched prior retained identities. `cache-manifest.json` records actual retained cache identities, including later DD 43. Read scope is limited to the article/page descriptions in the Guides and ledger. ISS pages 1 and 10 were visually read for the overview rates, with pages 4-5 also inspected in preparation. No live OPEC/RegTE/filing form was opened or submitted. One attempted EUR-Lex PDF returned an empty stream; currency instead uses the official Foreign Affairs page actually opened and read.

## Checks

- `skill-checks.json`: both exact files return `{}` across all checks.
- `examples.txt`: 2 files, 3 controls, zero failures or missing controls.
- `check-row-sources.txt`: zero misses, two ISS scan rows unreadable to the parser. Both are resolved substantively by visual inspection of ISS circular pages 1/10; this is not represented as parser text extraction.
- `tests.txt`: 22 calculator-quote/copy-rule tests pass.
- `sync-integrity.txt`: working-tree audit against origin/main, strict metadata, zero errors/warnings (shared checkout presently includes other country writers, so this is not an isolated committed-head result).
- `scoped-worktree-validation.txt`: real validator invoked through a disclosed worktree preview harness selecting the two assigned paths, zero warnings/errors. It is not the final actual-head CLI gate: the writer was instructed not to commit, and validate-guides' changed-only implementation uses origin/main...HEAD. Parent must run the exact CLI against the actual country branch/head before publication.
- `git diff --check -- skills/san-marino/sm-company-formation.md skills/san-marino/sm-tax-overview.md`: passed.

Initial failed attempts are retained in `INITIAL-FAILURES.md`. No scripts or tests were changed. Missing unchanged copy-test dependencies were restored by another concurrent lane before the retry (the writer's materialisation pass found zero missing).

## Holds and next step

A fresh independent reviewer must check all 50 ledger rows, all old-line maps and recompute all three controls. This writer cannot self-certify. The complete later company/licensing amendment chain after 27 November 2024 remains unconfirmed beyond the selected DD 43/2025 screen, service charter and AIF procedure. Other explicit inherited holds remain: special regimes, fees, audit thresholds, complete account filing and beneficial-owner fields/fees/sanctions; actual 2027 office opening/any later return extension; treaty outcomes and e-invoice equality persistence. No comprehensive current-company-law claim is made. Draft PR is appropriate if the full required current-law scope cannot be closed by the fresh review.

Parent owns one country PR, deterministic indexed public-safe evidence package and final actual-head checks. Do not package `cache/`, raw live responses or this working helper script as legal evidence. Preserve the `prior-*` records byte-exact if included, with their old scope clearly labelled.

Written by Codex (world wave). Not reviewed by an accountant.
