# Initial checks and preparation failures

These attempts were superseded; none is claimed as a passing actual-head check.

1. First skill_checks formation run: `(c) rates_rows_sourced FAIL no rates table`. Resolved by naming the actual capital table's amount/rule column and putting official URLs inline. All content checks now pass.
2. Running `validate-guides.py --help` did not show help: this script uses direct flag parsing and performed full sparse-corpus validation, reporting stale generated index plus inherited whole-corpus warnings. No index was edited. The final scoped worktree preview passes; exact committed-head check remains parent responsibility.
3. First calculator/copy unittest run: `FileNotFoundError: .../agent-skills/LICENSE.md`; 22 tests, one error. The sparse missing unchanged tracked dependency was materialised by another lane before the retry. Final 22 tests pass.
4. EUR-Lex Italian PDF request returned an empty body (`pdftotext: Document stream is empty`). Not used as legal authority or dated as read. The official Foreign Affairs Monetary Agreement page was opened/read instead and cited for currency.
5. An initial inline-link conversion command used the workspace-relative path while its cwd was already the isolated clone; it raised FileNotFoundError before mutation. Corrected cwd-relative conversion completed successfully.
