# Complete old-content destination map: sm-tax-overview

Each nonblank old source line is indexed below. The map includes the two original worked-case inputs and outputs. No contributed credit or CTA was present. No topic is silently deleted.

| Old line | Old content | New destination / disposition |
|---|---|---|
| 1 | --- | Frontmatter/H1; version/date advanced, type added; unsupported domain: formation removed in formation only; other keys preserved |
| 2 | name: sm-tax-overview | Frontmatter/H1; version/date advanced, type added; unsupported domain: formation removed in formation only; other keys preserved |
| 3 | description: > | Frontmatter/H1; version/date advanced, type added; unsupported domain: formation removed in formation only; other keys preserved |
| 4 |   Overview of the San Marino tax system for 2026 and a router to the detailed San Marino skills. Covers the tax year, currency and authorities, residence and worldwide taxation, the IGR income tax with eight bands from 9% to 35%, the 18% rate for companies and for business and professional income in tax years 2026 to 2030 (17% statutory), the 50% new-company rate cut, the single-stage import tax (monofase) at 17% in place of VAT, ISS social contributions and FONDISS, withholding on payments abroad, the 31 July return deadline, and the 2026 reforms (Law 141/2025, Delegated Decree 156/2026, domestic e-invoicing from 2027). Use for a first answer on San Marino tax, comparing San Marino with Italy, or choosing which San Marino skill to load. | Frontmatter/H1; version/date advanced, type added; unsupported domain: formation removed in formation only; other keys preserved |
| 5 | jurisdiction: SM | Frontmatter/H1; version/date advanced, type added; unsupported domain: formation removed in formation only; other keys preserved |
| 6 | tax_year: 2026 | Frontmatter/H1; version/date advanced, type added; unsupported domain: formation removed in formation only; other keys preserved |
| 7 | last_updated: 2026-10-30 | Frontmatter/H1; version/date advanced, type added; unsupported domain: formation removed in formation only; other keys preserved |
| 8 | license: AGPL-3.0-or-later (code) / OpenAccountants Guide License v1.0 (content) | Frontmatter/H1; version/date advanced, type added; unsupported domain: formation removed in formation only; other keys preserved |
| 9 | category: international | Frontmatter/H1; version/date advanced, type added; unsupported domain: formation removed in formation only; other keys preserved |
| 10 | version: 0.6 | Frontmatter/H1; version/date advanced, type added; unsupported domain: formation removed in formation only; other keys preserved |
| 11 | tier: 2 | Frontmatter/H1; version/date advanced, type added; unsupported domain: formation removed in formation only; other keys preserved |
| 12 | --- | Frontmatter/H1; version/date advanced, type added; unsupported domain: formation removed in formation only; other keys preserved |
| 14 | # San Marino tax overview v0.6 | Frontmatter/H1; version/date advanced, type added; unsupported domain: formation removed in formation only; other keys preserved |
| 16 | ## Section 1: Scope | Scope |
| 18 | A one-page map of San Marino tax for 2026, with the headline figures and which skill to load for the detail. It does no calculation of its own. | Scope |
| 20 | ## Section 2: Key facts | Quick reference |
| 22 | \| Item \| 2026 position \| Source \| | Quick reference |
| 23 | \|---\|---\|---\| | Quick reference |
| 24 | \| Tax year \| Calendar year; returns for 2026 due 31 July 2027 \| [IGR art 93(1)][igr] \| | Quick reference; retains statutory date and adds next-opening qualification, O01 |
| 25 | \| Currency \| Euro \| \| | Quick reference |
| 26 | \| Tax authority \| UO Ufficio Tributario, Dipartimento Finanze e Bilancio \| [Finance department][finance] \| | Quick reference |
| 27 | \| Social security \| ISS (Istituto per la Sicurezza Sociale) and the FONDISS supplementary pension \| [ISS circular 2187/UC/2026][iss] \| | Quick reference |
| 28 | \| Residence \| Individuals: registered residence or actual stay for most of the year, or centre of vital interests. Companies: registered office or effective management for most of the year \| [IGR arts 10, 42][igr] \| | Quick reference |
| 29 | \| Scope \| Residents on worldwide income; non-residents on San Marino-source income \| [IGR arts 1, 5][igr] \| | Quick reference |
| 30 | \| Personal income tax (IGR) \| Eight bands, 9% to 35% (top band over 80,000) \| [IGR Annex C][igr] \| | Quick reference |
| 31 | \| Business and professional income of individuals \| 18% separate rate for 2026 to 2030 \| [Law 141/2025, art 54(6)][l141] \| | Quick reference |
| 32 | \| Corporate IGR \| 18% for 2026 to 2030 (statutory 17%) \| [Law 141/2025, art 54(6)][l141]; [IGR art 43][igr] \| | Quick reference |
| 33 | \| New-activity incentive \| 50% rate cut for five tax periods for a qualifying new company, sole trader or professional that opts in (9% in 2026) \| [IGR art 73][igr] \| | Quick reference |
| 34 | \| VAT \| None. Single-stage import tax (monofase), ordinary rate 17%; a separate services tax (imposta complementare sui servizi) applies to listed services supplied to private customers \| [DD 183/2011, art 1][dd183]; [DD 50/2011, arts 2-3][dd50] \| | Quick reference |
| 35 | \| Employee social contributions \| 7.80% ISS plus 2.50% FONDISS \| [ISS circular 2187/UC/2026][iss] \| | Quick reference |
| 36 | \| Employer pension and FONDISS \| 17.60% plus 2.50% (other employer funds on top) \| [ISS circular 2187/UC/2026][iss] \| | Quick reference |
| 37 | \| Withholding on payments abroad \| 13% interest, 5% dividends to individuals, 20% professional services, royalties and directors' fees, 10% equipment rentals \| [IGR arts 102-104][igr] \| | Quick reference; rates preserved with source/category/treaty limits, O13-O16 |
| 38 | \| Domestic e-invoicing \| Optional from 1 October 2026; required from 1 January 2027 for operators with prior-year revenue of 100,000 or more \| [DD 133/2026, arts 2, 11][dd133] \| | Quick reference |
| 40 | The 2026 reform: Law 141/2025 applies from tax year 2026 ([Law 141/2025, art 54(1)][l141]); Delegated Decree 156/2026 of 12 October 2026 corrected it, also from 2026 ([DD 156/2026, art 19][dd156]). | Quick reference |
| 42 | ## Section 3: Which skill to load | The method, step by step / Which Guide to load |
| 44 | \| Question \| Skill \| | The method, step by step / Which Guide to load |
| 45 | \|---\|---\| | The method, step by step / Which Guide to load |
| 46 | \| Individual income tax, wages, pensions, self-employed income, SMaC credit, family credits \| `sm-income-tax` \| | The method, step by step / Which Guide to load |
| 47 | \| Company tax, losses, new-company incentive, advances \| `sm-corporate-income-tax` \| | The method, step by step / Which Guide to load |
| 48 | \| Import tax (monofase), trading with Italy, e-invoicing \| `sm-vat-gst` \| | The method, step by step / Which Guide to load |
| 49 | \| Payroll withholding, ISS and FONDISS contributions, self-employed contributions \| `sm-payroll-social` \| | The method, step by step / Which Guide to load |
| 50 | \| Related-party pricing and advance agreements \| `sm-transfer-pricing` \| | The method, step by step / Which Guide to load |
| 51 | \| Non-residents, withholding on payments abroad, foreign tax credit, permanent establishment \| `sm-cross-border` \| | The method, step by step / Which Guide to load |
| 52 | \| Setting up an SRL or SPA \| `sm-company-formation` \| | The method, step by step / Which Guide to load |
| 54 | ## Section 4: Ask the client first | Ask the client first |
| 56 | 1. Is the client an individual, sole trader, professional or company? | Ask the client first |
| 57 | 2. Resident in San Marino in 2026, and where else they have ties? | Ask the client first |
| 58 | 3. Which income or transactions: wages, business, property, imports, payments abroad? | Ask the client first |
| 59 | 4. Any link with Italy (frontier work, Italian customers or suppliers)? | Ask the client first |
| 61 | ## Sources | Sources |
| 63 | \| Source \| URL \| Read on \| | Sources |
| 64 | \|---\|---\|---\| | Sources |
| 65 | \| Law 166/2013 (IGR), official coordinated text updated to 22 December 2025 \| https://www.consigliograndeegenerale.sm/on-line/documento17086436.html \| 2026-10-30 \| | Sources |
| 66 | \| Law 141/2025 of 12 November 2025, art 54 \| https://www.consigliograndeegenerale.sm/on-line/home/archivio-leggi-decreti-e-regolamenti/documento17155359.html \| 2026-10-30 \| | Sources |
| 67 | \| Delegated Decree 156/2026 of 12 October 2026 \| https://www.bollettinoufficiale.sm/on-line/RicercaBU?operation=getDocBU&id=9c3a0dfeb72a7aeab52d1c5c0440879b4cf2ad33 \| 2026-10-30 \| | Sources |
| 68 | \| Delegated Decree 183/2011 (import tax 17%) \| https://www.consigliograndeegenerale.sm/on-line/home/documento17046854.html \| 2026-10-30 \| | Sources |
| 69 | \| Delegated Decree 50/2011 (imposta complementare sui servizi) \| https://www.consigliograndeegenerale.sm/on-line/home/archivio-leggi-decreti-e-regolamenti/documento17027521.html \| 2026-10-30 \| | Sources |
| 70 | \| Delegated Decree 133/2026 (domestic e-invoicing) \| https://www.bollettinoufficiale.sm/on-line/RicercaBU?operation=getDocBU&id=4d7f1ffcf645b166ffc567d328d888e43fcdd538 \| 2026-10-30 \| | Sources |
| 71 | \| ISS circular 2187/UC/2026 of 22 April 2026 \| https://www.iss.sm/on-line/home/menudestra/area-modulistica/modulistica-ufficio-contributi/documento49158490.html \| 2026-10-30 \| | Sources |
| 72 | \| San Marino Finance department, national taxation page \| https://www.finanze.sm/pub2/FinanzeSM/FISCALITA-NAZIONALE.html \| 2026-10-24 \| | Sources |
| 74 | Not yet confirmed: nothing in this overview beyond what the linked skills list. | Sources |
| 76 | [igr]: https://www.consigliograndeegenerale.sm/on-line/documento17086436.html | Inline citations throughout same sections; link-reference definition removed as duplicate syntax only |
| 77 | [l141]: https://www.consigliograndeegenerale.sm/on-line/home/archivio-leggi-decreti-e-regolamenti/documento17155359.html | Inline citations throughout same sections; link-reference definition removed as duplicate syntax only |
| 78 | [dd156]: https://www.bollettinoufficiale.sm/on-line/RicercaBU?operation=getDocBU&id=9c3a0dfeb72a7aeab52d1c5c0440879b4cf2ad33 | Inline citations throughout same sections; link-reference definition removed as duplicate syntax only |
| 79 | [dd183]: https://www.consigliograndeegenerale.sm/on-line/home/documento17046854.html | Inline citations throughout same sections; link-reference definition removed as duplicate syntax only |
| 80 | [dd50]: https://www.consigliograndeegenerale.sm/on-line/home/archivio-leggi-decreti-e-regolamenti/documento17027521.html | Inline citations throughout same sections; link-reference definition removed as duplicate syntax only |
| 81 | [dd133]: https://www.bollettinoufficiale.sm/on-line/RicercaBU?operation=getDocBU&id=4d7f1ffcf645b166ffc567d328d888e43fcdd538 | Inline citations throughout same sections; link-reference definition removed as duplicate syntax only |
| 82 | [iss]: https://www.iss.sm/on-line/home/menudestra/area-modulistica/modulistica-ufficio-contributi/documento49158490.html | Inline citations throughout same sections; link-reference definition removed as duplicate syntax only |
| 83 | [finance]: https://www.finanze.sm/pub2/FinanzeSM/FISCALITA-NAZIONALE.html | Inline citations throughout same sections; link-reference definition removed as duplicate syntax only |

## Removed and why

No substantive topic or original worked input/output removed. Duplicate reference-link definitions became inline citations so row-source checks can read each official link. Older heading prefixes became canonical shape headings. The invalid domain `formation` was removed from the formation Guide; category remains `formation`. No file shrank by 25%. The overview replaces the unqualified “no calculation” scope wording with the actual router-and-control scope.

Old UTF-8 bytes: 6798; new UTF-8 bytes: 11898.
