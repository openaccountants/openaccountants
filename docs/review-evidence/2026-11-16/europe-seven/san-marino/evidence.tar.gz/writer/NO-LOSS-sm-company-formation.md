# Complete old-content destination map: sm-company-formation

Each nonblank old source line is indexed below. The map includes the two original worked-case inputs and outputs. No contributed credit or CTA was present. No topic is silently deleted.

| Old line | Old content | New destination / disposition |
|---|---|---|
| 1 | --- | Frontmatter/H1; version/date advanced, type added; unsupported domain: formation removed in formation only; other keys preserved |
| 2 | name: sm-company-formation | Frontmatter/H1; version/date advanced, type added; unsupported domain: formation removed in formation only; other keys preserved |
| 3 | description: > | Frontmatter/H1; version/date advanced, type added; unsupported domain: formation removed in formation only; other keys preserved |
| 4 |   Forming a company in San Marino in 2026 under Law 47/2006 on companies as amended by Law 80/2022: choice between general partnership (società in nome collettivo), SRL and SPA, minimum capital of EUR 25,500 for an SRL and EUR 77,000 for an SPA, the EUR 9,000 SRL paid in full within 60 days, contribution timing (half within 120 days, all within three years), cash deposit or bank guarantee, sole-member rules, the notarial deed and its contents, registration with the Economic Activities Office, legal personality on registration, directors and remote board meetings, beneficial owners and the link to tax residence and the new-company tax incentive. Use for setting up a San Marino SRL or SPA, capital requirements, incorporation steps and director questions. Regulated activities and licences need their own law. | Frontmatter/H1; version/date advanced, type added; unsupported domain: formation removed in formation only; other keys preserved |
| 5 | jurisdiction: SM | Frontmatter/H1; version/date advanced, type added; unsupported domain: formation removed in formation only; other keys preserved |
| 6 | tax_year: 2026 | Frontmatter/H1; version/date advanced, type added; unsupported domain: formation removed in formation only; other keys preserved |
| 7 | last_updated: 2026-10-30 | Frontmatter/H1; version/date advanced, type added; unsupported domain: formation removed in formation only; other keys preserved |
| 8 | license: AGPL-3.0-or-later (code) / OpenAccountants Guide License v1.0 (content) | Frontmatter/H1; version/date advanced, type added; unsupported domain: formation removed in formation only; other keys preserved |
| 9 | category: formation | Frontmatter/H1; version/date advanced, type added; unsupported domain: formation removed in formation only; other keys preserved |
| 10 | version: 0.3 | Frontmatter/H1; version/date advanced, type added; unsupported domain: formation removed in formation only; other keys preserved |
| 11 | tier: 2 | Frontmatter/H1; version/date advanced, type added; unsupported domain: formation removed in formation only; other keys preserved |
| 12 | domain: formation | Frontmatter/H1; version/date advanced, type added; unsupported domain: formation removed in formation only; other keys preserved |
| 13 | --- | Frontmatter/H1; version/date advanced, type added; unsupported domain: formation removed in formation only; other keys preserved |
| 15 | # San Marino company formation and entity choice v0.3 | Frontmatter/H1; version/date advanced, type added; unsupported domain: formation removed in formation only; other keys preserved |
| 17 | The company-law text used is the official coordinated collection updated to 27 November 2024, read with Law 80/2022. Amendments to company and licensing law made in 2025 and 2026 are not covered (see the end of Sources). | Frontmatter/H1; version/date advanced, type added; unsupported domain: formation removed in formation only; other keys preserved |
| 19 | ## Section 1: Scope | Scope |
| 21 | This skill covers: | Scope |
| 23 | - Choosing between a general partnership, an SRL (società a responsabilità limitata) and an SPA (società per azioni). | Scope |
| 24 | - Capital, contributions and their timing. | Scope |
| 25 | - The incorporation deed, registration and the start of legal personality. | Scope |
| 26 | - Directors, ownership disclosure and the link to tax. | Scope |
| 28 | It does not cover: regulated financial, insurance, fiduciary, cooperative, professional-company or technology regimes; activity licences; residence permits; fees. | Scope |
| 30 | ## Section 2: Entity choice | The method, step by step / Entity choice |
| 32 | - **General partnership:** partners are jointly and without limit liable ([Law 47/2006, art 4][companies]). Profit is taxed in the partners' hands ([IGR art 10(3)][igr]). | The method, step by step / Entity choice |
| 33 | - **SRL and SPA (capital companies):** company obligations belong to the company, subject to special liability rules. Individuals and legal persons can hold shares ([Law 47/2006, arts 2, 4][companies]). | The method, step by step / Entity choice |
| 34 | - **Sole member:** a capital company can have one member, at formation or later. Sole-member status must be registered. If the company becomes insolvent, the sole member is liable without limit for debts arising while they held all the shares, where registration of sole-member status was late, or (for a company formed by unilateral act) capital was not paid half within 120 days and in full within three years ([Law 47/2006, art 12, as amended by Law 80/2022][companies]). | The method, step by step / Entity choice |
| 35 | - **Professional companies** have their own eligibility and activity limits ([Law 47/2006, art 3][companies]). | The method, step by step / Entity choice |
| 36 | - Sole traders and professionals register as economic operators under the activity laws, not company law. | The method, step by step / Entity choice |
| 38 | ## Section 3: Capital and contributions | The method, step by step / Capital and contributions |
| 40 | \| Item \| Rule \| Source \| | The method, step by step / Capital and contributions |
| 41 | \|---\|---\|---\| | The method, step by step / Capital and contributions |
| 42 | \| Minimum capital, SRL \| 25,500 \| [Law 47/2006, art 13(1)][companies] \| | The method, step by step / Capital and contributions |
| 43 | \| Minimum capital, SPA \| 77,000 \| [Law 47/2006, art 13(1)][companies] \| | The method, step by step / Capital and contributions |
| 44 | \| Alternative SRL capital \| 9,000, all paid within 60 clear days after registration, in cash at a San Marino bank and blocked as security for company debts until liquidation, or by bank guarantee \| [Law 47/2006, art 13(1-bis), added by Law 80/2022, art 4][amendment] \| | The method, step by step / Capital and contributions |
| 45 | \| Ordinary payment timing \| At least half within 120 clear days after registration; all within three years \| [Law 47/2006, art 10(3)-(4), as amended by Law 80/2022, art 2][amendment] \| | The method, step by step / Capital and contributions |
| 46 | \| Form of cash contributions \| Deposit at a San Marino bank, or a bank guarantee to the company valid for at least three years \| [Law 47/2006, art 10(8)][companies] \| | The method, step by step / Capital and contributions |
| 47 | \| Proof of payment \| Directors file a sworn, notarised declaration with the Economic Activities Office within 30 days \| [Law 47/2006, art 10(5)][companies] \| | The method, step by step / Capital and contributions; corrected statutory declaration alternatives, F12 |
| 48 | \| Contributions in total \| Not less than share capital; in cash unless the statutes allow otherwise; in kind needs valuation evidence \| [Law 47/2006, art 10(1)-(2), (7)][companies] \| | The method, step by step / Capital and contributions |
| 50 | Failure to pay contributions on time is a cause of dissolution and liquidation; the court can give directors up to 60 days to regularise ([Law 47/2006, art 10(6)][companies]). If a guarantee is not renewed or replaced by cash 30 days before it expires, the guarantee is enforced ([Law 47/2006, art 10(8)][companies]). Services and personal-use rights are not contributable assets. | The method, step by step / Capital and contributions |
| 52 | ## Section 4: Incorporation steps | The method, step by step / Incorporation steps |
| 54 | 1. **Owners and managers.** Check each owner, beneficial owner and director against the eligibility and certification rules; collect certificates and translations ([Law 47/2006, definitions and arts 16-17][companies]). | The method, step by step / Incorporation steps |
| 55 | 2. **Seat, object and permissions.** The registered office must be in San Marino ([Law 47/2006, art 8][companies]). | The method, step by step / Incorporation steps |
| 56 |    Fix a lawful, possible and determined object ([Law 47/2006, art 9][companies]). Some activities or types need special-law authorisation or a Congress of State clearance ([Law 47/2006, art 16][companies]). | The method, step by step / Incorporation steps |
| 57 | 3. **Deed.** A public deed under article 18 with the article 19 particulars: type and name, term, registered office, object, capital, owners and their contributions, governance and representation, first appointments and statutes ([Law 47/2006, arts 18-19][companies]). | The method, step by step / Incorporation steps |
| 58 | 4. **Registration.** The notary files with the Economic Activities Office ([Law 47/2006, arts 6, 20][companies]). The company acquires legal personality on registration; acts done before registration make the persons who did them jointly and without limit liable ([Law 47/2006, art 21][companies]). | The method, step by step / Incorporation steps |
| 59 | 5. **After registration.** Licence for the activity, tax registration, and ISS registration when hiring. | The method, step by step / Incorporation steps |
| 61 | ## Section 5: Directors, disclosure and ongoing duties | The method, step by step / Directors, disclosure and ongoing duties |
| 63 | - Directors and their representation powers follow articles 48-52 and the statutes ([Law 47/2006, arts 48-52][companies]). Board meetings can be held remotely under article 50; where the chair is not in San Marino, a San Marino notary acts as secretary ([Law 47/2006, art 50][companies]). The company-law text read sets no general rule that a director must be resident in San Marino. | The method, step by step / Directors, disclosure and ongoing duties |
| 64 | - Owners, directors, powers and sole-member status are registered ([Law 47/2006, art 6][companies]); beneficial owners are disclosed under article 17 and the anti-money-laundering rules. | The method, step by step / Directors, disclosure and ongoing duties |
| 65 | - Books, accounts and financial statements: articles 72 onward ([Law 47/2006][companies]). | The method, step by step / Directors, disclosure and ongoing duties |
| 66 | - **Tax residence** is a separate test: a company is resident if its registered office or effective management is in San Marino for most of the tax period ([IGR art 42(2)][igr]). | The method, step by step / Directors, disclosure and ongoing duties |
| 67 | - **New-company incentive:** registration alone does not give the 50% rate cut. The company must opt in and meet the shareholder and hiring conditions of IGR article 73 (9% instead of 18% for 2026). See `sm-corporate-income-tax`. | The method, step by step / Directors, disclosure and ongoing duties |
| 69 | ## Section 6: Worked examples | Worked cases |
| 71 | ### Example 1: two-owner ordinary SRL | Worked cases |
| 73 | Capital 25,500, owners 60% and 40%. Subscriptions 15,300 and 10,200. Paying half within 120 days: 7,650 and 5,100, total 12,750; the remaining 12,750 within three years. | Worked cases |
| 75 | ```oa-check | Worked cases |
| 76 | name: San Marino ordinary SRL capital split and first half | Worked cases |
| 77 | inputs: | Worked cases |
| 78 |   srl_capital: 25500 | Worked cases |
| 79 |   first_owner_fraction: 0.60 | Worked cases |
| 80 |   second_owner_fraction: 0.40 | Worked cases |
| 81 |   initial_fraction: 0.50 | Worked cases |
| 82 | steps: | Worked cases |
| 83 |   first_owner_subscription: srl_capital * first_owner_fraction | Worked cases |
| 84 |   second_owner_subscription: srl_capital * second_owner_fraction | Worked cases |
| 85 |   first_owner_initial: first_owner_subscription * initial_fraction | Worked cases |
| 86 |   second_owner_initial: second_owner_subscription * initial_fraction | Worked cases |
| 87 |   initial_total: first_owner_initial + second_owner_initial | Worked cases |
| 88 |   remaining_total: srl_capital - initial_total | Worked cases |
| 89 | expected: | Worked cases |
| 90 |   first_owner_subscription: 15300 | Worked cases |
| 91 |   second_owner_subscription: 10200 | Worked cases |
| 92 |   first_owner_initial: 7650 | Worked cases |
| 93 |   second_owner_initial: 5100 | Worked cases |
| 94 |   initial_total: 12750 | Worked cases |
| 95 |   remaining_total: 12750 | Worked cases |
| 96 | ``` | Worked cases |
| 98 | ### Example 2: 9,000 SRL is paid in full (edge case) | Worked cases |
| 100 | An SRL using the 9,000 route must pay all 9,000 within 60 clear days. Paying only half (4,500), as on the ordinary route, leaves 4,500 missing. | Worked cases |
| 102 | ```oa-check | Worked cases |
| 103 | name: San Marino 9,000 SRL full payment requirement | Worked cases |
| 104 | inputs: | Worked cases |
| 105 |   alternative_srl_capital: 9000 | Worked cases |
| 106 |   required_fraction: 1 | Worked cases |
| 107 | steps: | Worked cases |
| 108 |   required_contribution: alternative_srl_capital * required_fraction | Worked cases |
| 109 |   shortfall_if_half_paid: required_contribution - alternative_srl_capital * 0.50 | Worked cases |
| 110 | expected: | Worked cases |
| 111 |   required_contribution: 9000 | Worked cases |
| 112 |   shortfall_if_half_paid: 4500 | Worked cases |
| 113 | ``` | Worked cases |
| 115 | ## Section 7: Ask the client first | Ask the client first |
| 117 | 1. What will the company do, and is the activity regulated? | Ask the client first |
| 118 | 2. Owners and beneficial owners, their nationality and residence, and any similar business in the last twelve months (for the tax incentive). | Ask the client first |
| 119 | 3. Proposed directors and where the board will meet. | Ask the client first |
| 120 | 4. Capital route (25,500 SRL, 9,000 SRL or SPA) and cash or guarantee. | Ask the client first |
| 121 | 5. Premises and hiring plan. | Ask the client first |
| 123 | ## Sources | Sources |
| 125 | \| Source \| URL \| Read on \| | Sources |
| 126 | \|---\|---\|---\| | Sources |
| 127 | \| Official coordinated collection on companies and business (Law 47/2006 and related laws), updated to 27 November 2024: arts 2-6, 9-21, 48-52 \| https://www.consigliograndeegenerale.sm/on-line/documento17113696.html \| 2026-10-30 \| | Sources |
| 128 | \| Law 80/2022 (amendments to company capital and registration), arts 1-7 \| https://www.consigliograndeegenerale.sm/on-line/home/archivio-leggi-decreti-e-regolamenti/documento17132480.html \| 2026-10-30 \| | Sources |
| 129 | \| Law 166/2013 (IGR), official coordinated text updated to 22 December 2025: arts 10, 42, 73 \| https://www.consigliograndeegenerale.sm/on-line/documento17086436.html \| 2026-10-30 \| | Sources |
| 131 | Not yet confirmed: company and licensing amendments after 27 November 2024; the earlier version's statement that an SPA's capital is deposited in full before incorporation; registration and licence fees; audit and statutory-auditor thresholds; financial-statement filing dates; beneficial-owner register procedure. | Sources; selected route/deadline closed by F23/F24; full fields/fees/sanctions remain Not yet confirmed |
| 133 | [companies]: https://www.consigliograndeegenerale.sm/on-line/documento17113696.html | Inline citations throughout same sections; link-reference definition removed as duplicate syntax only |
| 134 | [amendment]: https://www.consigliograndeegenerale.sm/on-line/home/archivio-leggi-decreti-e-regolamenti/documento17132480.html | Inline citations throughout same sections; link-reference definition removed as duplicate syntax only |
| 135 | [igr]: https://www.consigliograndeegenerale.sm/on-line/documento17086436.html | Inline citations throughout same sections; link-reference definition removed as duplicate syntax only |

## Removed and why

No substantive topic or original worked input/output removed. Duplicate reference-link definitions became inline citations so row-source checks can read each official link. Older heading prefixes became canonical shape headings. The invalid domain `formation` was removed from the formation Guide; category remains `formation`. No file shrank by 25%. The overview replaces the unqualified “no calculation” scope wording with the actual router-and-control scope.

Old UTF-8 bytes: 10104; new UTF-8 bytes: 16283.
