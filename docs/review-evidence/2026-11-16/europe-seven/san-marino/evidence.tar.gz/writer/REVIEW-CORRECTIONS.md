# Focused independent-review correction

Formation art.50(2): remote audio/video board meetings require statutes not expressly prohibiting that mode. The secretary records the full meeting. Retention for at least two years rests with the chair when present in San Marino and with the San Marino notary acting as secretary when the chair is abroad. The final Guide now states those switches explicitly.

Official source: Law47/2006 consolidated art.50(2), https://www.consigliograndeegenerale.sm/on-line/documento17113696.html. Native operative wording read16November2026: “qualora tale modalità non sia espressamente vietata dallo statuto sociale”; “conservarla per almeno due anni”. Detailed independent closure and final exact hashes are in the separate review receipt. The writer's initial checkpoint is preserved as historical evidence, not misrepresented as the final source identity.

No case inputs, formulas, scope, protected credits or approvals changed. The genuine later-amendment-chain hold remains; publish as draft only.
