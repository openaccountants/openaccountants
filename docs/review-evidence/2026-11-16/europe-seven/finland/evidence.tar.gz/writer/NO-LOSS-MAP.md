# Finland formation complete no-loss map

Baseline: current origin/main Guide v0.2. Destination: v0.3. No old topic removed. Source list converted from reference links to inline row URLs and dated table.

| Old topic/input | New destination | Preservation |
|---|---|---|
| Who this applies to | Scope | All Oy/Oyj, sole trader, Ay/Ky, cooperative/referral, sibling links and separate tax/residence tests retained. |
| Current PRH setup routes and fees | Scope quick reference; Method 1 | Both prices, all eligibility criteria, 2026 language/online restriction, capital-vs-fee distinction retained. |
| Board and residence screen | Method 2 | 1–5, under-3 deputy, chair, separate ordinary/deputy, CEO/deputy, citizenship and permit conditions retained. |
| Incorporation documents and deadline | Method 3 | Three-month lapse, full payment, noncash auditor statement, documents, Virre, registration extract, no promised duration retained. |
| Audit-size test | Method 4 | 100k/200k/3, each period, strict exceedance, startup, articles, securities/significant influence, group/other law retained. |
| Annual filing and consequences | Filing and payment | Double-entry, annual accounts, six-month meeting, two-month adoption clock, eight-month PRH free filing, separate Vero/VAT/payroll, 150/600/doubling and decision conditions, inactivity retained. Added four-month preparation deadline. |
| Cross-border and other boundaries | When to refuse or refer | Ownership, residence, immigration, banking and regulation kept distinct. |
| Worked controls 1 | Worked cases 1 | Original inputs/steps/expected unchanged. |
| Worked controls 2 | Worked cases 2 | Original six trigger inputs and expected results unchanged; original six raw monetary/staff values now also in block. No simplification. |
| Ask the client first | Ask the client first | All six questions preserved. |
| Sources and review limits | Sources | All original source URLs retained, operative read scope refreshed; all substantive confirmation limits retained. Historical source review is identified honestly. |
| Contributor line | Closing contributor line | Byte-exact preserved. |

## Removed and why

No topic, edge case, refusal, worked input, contributor or protected CTA removed. Historical 23/27 October source-read narration is replaced with actual 16 November scoped reads; prior research/review records remain untouched in recovery checkout. Version heading and date advance. Invalid legacy `domain: formation` replaced by declared `type: filing-howto`; category remains formation.

Old bytes: 11831; new bytes: 18188. No size-reduction justification needed.
