# Finland formation figure and rule ledger

Writer read date: 2026-11-16. Every Guide rule and figure is inventoried below. Native Finnish statutory quotes are short extracts from operative consolidated provisions; English authority pages are quoted in their published language. Source documents and public server-rendered captures remain in local cache only. This ledger is writer evidence, not independent review.

| ID | Destination | Figure/rule and conditions | Act/article or official paragraph | Official URL | Short exact native quote | Read on |
|---|---|---|---|---|---|---|
| FI-01 | Scope | Oy separate person on registration | 1:2; 2:9 | https://www.finlex.fi/fi/lainsaadanto/2006/624 | erillinen oikeushenkilö, joka syntyy rekisteröimisellä | 2026-11-16 |
| FI-02 | Scope | Oyj minimum EUR 80,000 | 1:3 | https://www.finlex.fi/fi/lainsaadanto/2006/624 | Julkisen osakeyhtiön vähimmäisosakepääoma on 80 000 euroa. | 2026-11-16 |
| FI-03 | Scope | Oy no minimum, PRH records EUR 0 | opening paragraphs | https://www.prh.fi/en/companiesandorganisations/yrityksen_perustaminen/osakeyhtio.html | If the company has no share capital | 2026-11-16 |
| FI-04 | Scope | Private trader personal liability | Who is responsible for debts | https://www.suomi.fi/company/changes-and-crisis-situations/closing-down-a-business/guide/bankruptcy/closing-down-a-company-in-bankruptcy-proceedings | A private trader is responsible for all the debts and commitments | 2026-11-16 |
| FI-05 | Scope | Ay and general Ky partners full personal liability; limited partner differs | 1:1 | https://www.finlex.fi/fi/lainsaadanto/1988/389 | vastaavat yhtiön velvoitteista niiden täyteen määrään niin kuin omasta velastaan | 2026-11-16 |
| FI-06 | Scope | Other entity routes and tax/residence/YEL/payroll analysis distinct | company and private trader sections | https://www.prh.fi/en/companiesandorganisations/ulkomaalaisluvat.html | The person’s citizenship does not decide whether a permit is needed | 2026-11-16 |
| FI-07 | Method 1 | Guided fee EUR 300 | Alternative A | https://www.prh.fi/en/companiesandorganisations/yrityksen_perustaminen/osakeyhtio.html | The handling fee is 300 euros. | 2026-11-16 |
| FI-08 | Method 1 | Guided no subscription price and EUR 0 capital | Alternative A bullet 1 | https://www.prh.fi/en/companiesandorganisations/yrityksen_perustaminen/osakeyhtio.html | There is no subscription price for the shares | 2026-11-16 |
| FI-09 | Method 1 | All shareholders adults | Alternative A bullet 2 | https://www.prh.fi/en/companiesandorganisations/yrityksen_perustaminen/osakeyhtio.html | All the shareholders are adults. | 2026-11-16 |
| FI-10 | Method 1 | Finnish identity codes for shareholders and all specified officers | Alternative A bullet 3 | https://www.prh.fi/en/companiesandorganisations/yrityksen_perustaminen/osakeyhtio.html | The persons you have filed have Finnish person identity codes | 2026-11-16 |
| FI-11 | Method 1 | Standard articles sufficient, documents service-created | Alternative A bullet 4 and following paragraph | https://www.prh.fi/en/companiesandorganisations/yrityksen_perustaminen/osakeyhtio.html | Standard articles of association are sufficient. | 2026-11-16 |
| FI-12 | Method 1 | Drafted-document route EUR 400 | Alternative B | https://www.prh.fi/en/companiesandorganisations/yrityksen_perustaminen/osakeyhtio.html | The handling fee is 400 euros. | 2026-11-16 |
| FI-13 | Method 1 | B for share capital, entity shareholders, missing identity code, tailored articles or public company | Alternative B eligibility bullets | https://www.prh.fi/en/companiesandorganisations/yrityksen_perustaminen/osakeyhtio.html | The shareholders include companies or other organisations. | 2026-11-16 |
| FI-14 | Method 1 | Online only from 1 January 2026, Finnish or Swedish | How to start | https://www.prh.fi/en/companiesandorganisations/yrityksen_perustaminen/osakeyhtio.html | From 1 January 2026, it is not possible to file notifications on paper forms. | 2026-11-16 |
| FI-15 | Method 2 | Board one to five unless articles otherwise | 6:8 | https://www.finlex.fi/fi/lainsaadanto/2006/624 | yhdestä viiteen varsinaista jäsentä | 2026-11-16 |
| FI-16 | Method 2 | Under three directors at least one deputy | 6:8 | https://www.finlex.fi/fi/lainsaadanto/2006/624 | vähemmän kuin kolme jäsentä | 2026-11-16 |
| FI-17 | Method 2 | More than one director requires chair | 6:8 | https://www.finlex.fi/fi/lainsaadanto/2006/624 | Jos hallituksessa on useita jäseniä, sille on valittava puheenjohtaja. | 2026-11-16 |
| FI-18 | Method 2 | Board and deputy EEA-residence groups tested separately | ordinary/deputy board table | https://www.prh.fi/en/companiesandorganisations/ulkomaalaisluvat.html | separately for the part of ordinary members and deputy members | 2026-11-16 |
| FI-19 | Method 2 | At least one ordinary/deputy EEA resident otherwise permits; nationality not test | 6:8 and 6:10 | https://www.finlex.fi/fi/lainsaadanto/2006/624 | Vähintään yhdellä hallituksen jäsenellä on oltava asuinpaikka Euroopan talousalueella | 2026-11-16 |
| FI-20 | Method 2 | CEO and substitute EEA resident or permit | 6:19 | https://www.finlex.fi/fi/lainsaadanto/2006/624 | Toimitusjohtajan asuinpaikan on aina oltava Euroopan talousalueella | 2026-11-16 |
| FI-21 | Method 3 | Three-month signed-memorandum filing deadline or lapse | 2:8 | https://www.finlex.fi/fi/lainsaadanto/2006/624 | kolmen kuukauden kuluessa perustamissopimuksen allekirjoittamisesta | 2026-11-16 |
| FI-22 | Method 3 | Only fully paid shares submitted; officer declarations and payment proof | 2:8 | https://www.finlex.fi/fi/lainsaadanto/2006/624 | Vain osakkeet, jotka on täysin maksettu, voidaan ilmoittaa rekisteröitäviksi. | 2026-11-16 |
| FI-23 | Method 3 | Noncash subscription supporting auditor statement always needed | 2:6 and 2:8 | https://www.finlex.fi/fi/lainsaadanto/2006/624 | rekisteri-ilmoitukseen on lisäksi aina liitettävä tilintarkastajan lausunto | 2026-11-16 |
| FI-24 | Method 3 | Monitor in Virre; extract establishes registered data; no processing promise | Monitor progress and Register extracts | https://www.prh.fi/en/companiesandorganisations/muutokset_rekisteritietoihin/yleisohje.html | You can monitor the progress of your notification | 2026-11-16 |
| FI-25 | Method 3 | PRH and Vero register parts separately processed | How to start | https://www.prh.fi/en/companiesandorganisations/yrityksen_perustaminen/osakeyhtio.html | the Finnish Tax Administration will process the parts that apply to its own registers | 2026-11-16 |
| FI-26 | Method 3 | Officers, contact and beneficial-owner details kept current | A limited liability company involves obligations | https://www.prh.fi/en/companiesandorganisations/yrityksen_perustaminen/osakeyhtio.html | Details of actual beneficial owners | 2026-11-16 |
| FI-27 | Method 4 | At most one exceedance in each concluded and immediately previous period | 2:2(2) | https://www.finlex.fi/fi/lainsaadanto/2015/1141 | sekä päättyneellä että sitä välittömästi edeltäneellä tilikaudella | 2026-11-16 |
| FI-28 | Method 4 | Balance-sheet total over EUR 100,000 | 2:2(2)(1) | https://www.finlex.fi/fi/lainsaadanto/2015/1141 | taseen loppusumma ylittää 100 000 euroa | 2026-11-16 |
| FI-29 | Method 4 | Revenue over EUR 200,000 | 2:2(2)(2) | https://www.finlex.fi/fi/lainsaadanto/2015/1141 | liikevaihto tai sitä vastaava tuotto ylittää 200 000 euroa | 2026-11-16 |
| FI-30 | Method 4 | Average employees over three; equality does not exceed | 2:2(2)(3) | https://www.finlex.fi/fi/lainsaadanto/2015/1141 | palveluksessa on keskimäärin yli kolme henkilöä | 2026-11-16 |
| FI-31 | Method 4 | Startup omission unless obviously ineligible | 2:2(3) | https://www.finlex.fi/fi/lainsaadanto/2015/1141 | jollei ole ilmeistä, ettei edellytyksiä | 2026-11-16 |
| FI-32 | Method 4 | Securities-holding/significant-influence exception; articles and other law may mandate | 2:2(4)-(6) | https://www.finlex.fi/fi/lainsaadanto/2015/1141 | tilintarkastaja on aina valittava yhteisössä | 2026-11-16 |
| FI-33 | Filing | Oy double-entry books and annual financial statements | 1:1-2; 3:1 | https://www.finlex.fi/fi/lainsaadanto/1997/1336 | kirjanpitovelvollisia ovat | 2026-11-16 |
| FI-34 | Filing | Financial statements and required report within four months | 3:6 | https://www.finlex.fi/fi/lainsaadanto/1997/1336 | neljän kuukauden kuluessa tilikauden päättymisestä | 2026-11-16 |
| FI-35 | Filing | Ordinary meeting within six months; adoption and profit-use decision | 5:3 | https://www.finlex.fi/fi/lainsaadanto/2006/624 | kuuden kuukauden kuluessa tilikauden päättymisestä | 2026-11-16 |
| FI-36 | Filing | Register accounts/report within two months of adoption | 8:10 | https://www.finlex.fi/fi/lainsaadanto/2006/624 | kahden kuukauden kuluessa tilinpäätöksen vahvistamisesta | 2026-11-16 |
| FI-37 | Filing | PRH eight-month outer timetable, timely filing free | When to file; Fees | https://www.prh.fi/en/companiesandorganisations/financial_statements/limited_liability_companies_co-operatives_and_other_companies/digital.html | within eight months of the end of the financial period | 2026-11-16 |
| FI-38 | Filing | Separate Vero deadline four months from final calendar month | By when return submitted | https://www.vero.fi/en/businesses-and-corporations/taxes-and-charges/limited-companies-and-cooperatives/tax-return/ | within 4 months after the end of the last calendar month | 2026-11-16 |
| FI-39 | Filing | PRH late fee minimum EUR 150; over four months EUR 600 | fee paragraphs | https://www.prh.fi/en/presentation_and_duties/uutislistaus/news/2026/financial-statements-submitted-late-27.5.2026.html | The fee for late submission is at least 150 euros. | 2026-11-16 |
| FI-40 | Filing | Double fee two or more consecutive periods; reminder then decision | fee and reminder paragraphs | https://www.prh.fi/en/presentation_and_duties/uutislistaus/news/2026/financial-statements-submitted-late-27.5.2026.html | The fee is doubled if the financial statements are not filed | 2026-11-16 |
| FI-41 | Filing | Inactive company still files accounts | obligations bullet | https://www.prh.fi/en/companiesandorganisations/yrityksen_perustaminen/osakeyhtio.html | Approved financial statements for each financial period, even if the company is not active. | 2026-11-16 |
| FI-42 | Referral | Ownership, immigration, bank and regulatory approval separate from officer residence | opening paragraphs and shareholder table | https://www.prh.fi/en/companiesandorganisations/ulkomaalaisluvat.html | For information on residence permits needed in business, please contact the Finnish Immigration Service. | 2026-11-16 |

## Worked inputs and independent recomputation required

| Case | Inputs preserved | Expected result |
|---|---|---|
| Original capital/fee | EUR 10,000 agreed capital; EUR 400 fee | EUR 10,400 total; EUR 400 fee only |
| Original audit | Current EUR 110,000, EUR 190,000, 4 staff; previous EUR 90,000, EUR 150,000, 2 staff; all original trigger flags | 2 current; 0 previous; max 2; omission condition fails |
| Added eligible-route decision | EUR 300 guided; EUR 400 drafted; EUR 0 agreed capital; every guided condition established | EUR 300 vs EUR 400; EUR 100 difference |

Example figures are hypothetical inputs except published PRH fees and statutory audit thresholds, which are covered above. No legal outcome follows from arithmetic alone.
