# Finland formation writer report

Writer checkpoint: `skills/finland/fi-company-formation.md`, version 0.3, Git blob `6a2f3902fa4febad370eaabaa5a36baa46caa3e2`, SHA-256 `ef14b3f9e99a12df67d5c893c04704c854791bf0bdd6928610d12deec7034183`. Based on actual main blob `e1432cc19f6a897d0089810e204c29c8bcdb45de`. Writer stopped at this checkpoint for fresh independent review.

Recovered the existing formation draft and October research/review before editing. Preserved every old topic, both worked examples and every input, all boundaries and the contributor line. The Guide remains tier 2. No approval, named professional credential, protected CTA, other country file, commit or remote branch was changed by this writer.

## Corrected

| Previous | Current | Official source |
|---|---|---|
| Sources heading and reference-only table URLs failed current fixed-core checks | Canonical method headings, inline row URLs and scoped dated Sources table | Repository writing standard |
| No declared shape | filing-howto, with route preparation and completion controls | Repository writing standard |
| Accounts preparation deadline unstated | Four months after period end, distinct from meeting, adoption filing and tax clocks | Accounting Act 1336/1997 ch. 3 s. 6, https://www.finlex.fi/fi/lainsaadanto/1997/1336 |
| Audit raw case data present only in prose | Same six values also preserved in executable block; classified flags retained | Auditing Act 1141/2015 ch. 2 s. 2, https://www.finlex.fi/fi/lainsaadanto/2015/1141 |
| No numerical guided/drafted choice case | Eligible zero-capital case compares EUR 300 with EUR 400 and EUR 100 difference | PRH startup alternatives, https://www.prh.fi/en/companiesandorganisations/yrityksen_perustaminen/osakeyhtio.html |

No verified pre-existing numerical rate was changed: 300/400, 80,000, 100,000/200,000/3, 150/600 and all old clocks remain source-supported. No topic was deleted. See NO-LOSS-MAP.md for every old destination and all worked inputs.

## Evidence and verification

- LEDGER.md inventories 42 rule/figure rows, exact article/paragraph, official URL, short native quote and actual read date. Sources were read as operative paragraphs, including conditions and neighbors.
- PRH startup/permit/filing/accounts/late-fee pages and Finlex statutory HTML are cached locally. Finlex law is embedded in public server-rendered records; parsing only the shell would miss it. Finlex records were reconstructed and read, with long string chunks joined before parsing.
- Suomi.fi direct download returned 403. Its official page was successfully opened through the web tool and the private-trader liability paragraph read. No access bypass occurred; only a short ledger quote is retained publicly.
- skill_checks: all checks pass. Required examples: 3 blocks, zero failures. Scoped validator `check_guides` on the exact assigned file: zero errors and warnings. Strict worktree sync: zero errors/warnings across lane's currently edited source guides. Row sources: 2 numeric rows checked, zero misses/unreadable; this is parser scope, not verification of every legal row.
- Calculator quote tests: 20 pass under unittest. Initial pytest attempts failed because pytest is not installed; the tests are unittest tests and run correctly without it.
- Copy rules test initially failed because sparse checkout omitted agent-skills/LICENSE.md. Parent is expanding unchanged prose dependencies and must rerun before publication.
- Actual `validate-guides --changed-only --no-index-check` on unstaged worktree saw zero committed changed files, so that invocation is not claimed as content verification. Parent must run the command on the committed country head. The explicit scoped check above did inspect the edited Guide and passed.
- Historical prior full-pack review is preserved byte-exact as PRIOR-REVIEW.md. Its scope and earlier blobs are explicit; it does not approve this new revision.

## Removed and why

No substantive content removed. Historical read narration was superseded by actual current scoped reads; originals remain intact in recovered evidence. New Guide is larger. Platform licence and contributor line preserved.

## Moved

Existing topics moved into canonical method headings as mapped in NO-LOSS-MAP.md.

## Not moved

No sibling Guide, other country, generated output, website file or live service was edited. Parent owns commit, fresh independent review, packaging and one-country PR.

## Holds

Fresh independent review and final committed-head validations remain required. Specialist entity comparison, all permit exemptions, beneficial-owner details, group/sustainability rules, full fee-law chain and live filing remain explicitly outside confirmed coverage. No claim of full country completion or professional approval.

Written by Codex (world wave). Not reviewed by an accountant.
