# Finland independent assigned-Guide review

Reviewed on 2026-11-16 by fresh independent AI reviewer /root/review_li_fi, separate from the writer. This is legal/source and preservation review, not accountant approval. No Guides or Git state were modified.

PASS within the expressly partial ordinary-Oy scope. All42ledger rows inventoried and checked against the current cached official operative text/paragraphs; no actionable source/legal finding. Three examples independently recomputed from raw assumptions and statutory criteria, not imported writer formulas. Complete formation/fee-law chains and taxpayer-specific filing remain held.

Exact Guide: `skills/finland/fi-company-formation.md`

SHA256: `ef14b3f9e99a12df67d5c893c04704c854791bf0bdd6928610d12deec7034183`

## Provenance and proportionate reuse

Read the entire prior23October independent review including its final closure at c83ca9f5455b9560937c797c20ecd1b7b102b363 and final formation blob7f1771a51549e93c169a1fe8b12816d8d60ff94b. That blob is absent in both available local object stores; one attempted promisor retrieval failed DNS. Therefore this receipt does not claim exact-blob reuse or extend the old review. The prior record is background. Current writer source captures and selected extracts were already available and read once; no source was redownloaded for unchanged law.

Read the entire current Guide, writer42row ledger, source manifest, no-loss map and full diff from the exact old-guide bytes. The old-guide bytes independently match baseline bbab4f1a6d82cace432e6ca8eda89c98ffb1c038. Reviewed meaningful deltas: four-month preparation deadline, separate PRH/Vero processing and ongoing-detail duties, added direct sole-trader authority, complete raw audit inputs and new300/400decision case. Shape/citation/checklist edits preserve old content.

For Finlex, reused cached actual public server-rendered operative body records, not navigation-only web shells. Inspected selected Finnish Companies1:2-3,2:6/8-9,5:3,6:8/10/19,8:10; Auditing2:2with all conditions; Accounting1:1-2,3:1/6and annual-report exceptions; Partnerships1:1. The extraction includes cosmetic booleanFalse nodes, but quoted native provision text and numeric children are retained; raw captures contain operative wording. No future amendment substituted for current rules.

PRH cached startup, permit, filing, statements and27May2026late-fee substantive paragraphs read, including all eligibility bullets and neighboring exceptions. Vero current cached corporate-return paragraph confirms the final-calendar-month clock. Independently opened/read current official Suomi.fi debt liability paragraph on2026-11-16. No client form/session was submitted. Raw/full-source captures remain local and are excluded from this receipt.

Sources: [Companies](https://www.finlex.fi/fi/lainsaadanto/2006/624), [Auditing](https://www.finlex.fi/fi/lainsaadanto/2015/1141), [Accounting](https://www.finlex.fi/fi/lainsaadanto/1997/1336), [Partnerships](https://www.finlex.fi/fi/lainsaadanto/1988/389), [PRHstartup](https://www.prh.fi/en/companiesandorganisations/yrityksen_perustaminen/osakeyhtio.html), [permits](https://www.prh.fi/en/companiesandorganisations/ulkomaalaisluvat.html), [filing](https://www.prh.fi/en/companiesandorganisations/muutokset_rekisteritietoihin/yleisohje.html), [statements](https://www.prh.fi/en/companiesandorganisations/financial_statements/limited_liability_companies_co-operatives_and_other_companies/digital.html), [late fees](https://www.prh.fi/en/presentation_and_duties/uutislistaus/news/2026/financial-statements-submitted-late-27.5.2026.html), [Vero](https://www.vero.fi/en/businesses-and-corporations/taxes-and-charges/limited-companies-and-cooperatives/tax-return/), [Suomi.fi](https://www.suomi.fi/company/changes-and-crisis-situations/closing-down-a-business/guide/bankruptcy/closing-down-a-company-in-bankruptcy-proceedings).

## Per-row outcome

|ID|Outcome|Support read|Result|
|---|---|---|---|
|FI-01|PASS|Companies1:2,2:9|Separate legal person on registration matches.|
|FI-02|PASS|Companies1:3|Public-company80000minimum confirmed; private capital distinction preserved.|
|FI-03|PASS|PRHstartup opening|Zero capital permitted and recorded0; correct.|
|FI-04|PASS|Suomi.fi debt-liability paragraph|Personal-property liability independently read current official page; supports private trader statement.|
|FI-05|PASS|Partnerships1:1|Full general partner liability and limited silent-partner distinction confirmed.|
|FI-06|PASS|PRHpermits|Entity/worker/tax/residence decisions kept separate; no blanket foreign-owner prohibition.|
|FI-07|PASS|PRHstartup AlternativeA|300guided handling fee confirmed.|
|FI-08|PASS|PRHstartup AlternativeA|No subscription price and0capital conditions confirmed.|
|FI-09|PASS|PRHstartup AlternativeA|All shareholders adult condition confirmed; minor special route not generalized.|
|FI-10|PASS|PRHstartup AlternativeA|Finnish codes apply to shareholders/board and optional CEO/auditor/procurists/representatives; Guide refers to specified people and current source.|
|FI-11|PASS|PRHstartup AlternativeA|Standard articles and service-created memorandum/articles confirmed.|
|FI-12|PASS|PRHstartup AlternativeB|400drafted-document handling fee confirmed.|
|FI-13|PASS|PRHstartup AlternativeB|Share capital, company shareholders, missing codes, tailored articles, public-company triggers confirmed.|
|FI-14|PASS|PRHstartup How to start|1January2026online-only and Finnish/Swedish confirmed for company scope.|
|FI-15|PASS|Companies6:8|One-fiveordinary unless articles otherwise confirmed.|
|FI-16|PASS|Companies6:8|Below3requires at least1deputy confirmed.|
|FI-17|PASS|Companies6:8|Multiple board members require chair confirmed.|
|FI-18|PASS|PRHpermits table|Ordinary and deputy EEA-residence groups tested separately confirmed.|
|FI-19|PASS|Companies6:8/10;PRHpermits|EEA residence or PRHpermit; citizenship not decisive; distinct groups retained.|
|FI-20|PASS|Companies6:19;PRHpermits|CEO/substitute EEAresidence or permit confirmed.|
|FI-21|PASS|Companies2:8|3months from signed memorandum or lapse confirmed.|
|FI-22|PASS|Companies2:8|Only fully paid shares; declaration/payment-evidence requirements match.|
|FI-23|PASS|Companies2:6/8|Noncash own valuation and mandatory auditor statement supported; full valuation method remains referred.|
|FI-24|PASS|PRHgeneral filing|Virre tracking and resulting register extract supported; no fixed processing promise.|
|FI-25|PASS|PRHstartup How to start|New explicit PRHTradeRegister versus Veroown-register processing distinction confirmed.|
|FI-26|PASS|PRHstartup obligations|New explicit current officers/contact/beneficial-owner details obligation supported; particulars remain held.|
|FI-27|PASS|Auditing2:2(2)|At most1condition in each of concluded and preceding periods confirmed.|
|FI-28|PASS|Auditing2:2(2)(1)|Strict balance>100000confirmed.|
|FI-29|PASS|Auditing2:2(2)(2)|Strict revenue>200000confirmed.|
|FI-30|PASS|Auditing2:2(2)(3)|Average employees>3confirmed; equality not exceedance.|
|FI-31|PASS|Auditing2:2(3)|Startup rule absent periods unless obviously ineligible confirmed.|
|FI-32|PASS|Auditing2:2(4)-(6)|Securities/significant influence mandatory case, articles/other-law exceptions supported and retained.|
|FI-33|PASS|Accounting1:1-2,3:1|Oybooks double-entry and statements each period supported.|
|FI-34|PASS|Accounting3:6;3:1scope|New4month preparation deadline confirmed in operative Finnish text; annual report conditional on being required.|
|FI-35|PASS|Companies5:3|6monthmeeting/adoption/profit-use correct.|
|FI-36|PASS|Companies8:10|2months after adoption correct, retained even if earlier than outer timetable.|
|FI-37|PASS|PRHstatements When to file/Fees|8monthouter timetable and free timely filing supported; does not erase2monthadoptionclock.|
|FI-38|PASS|Vero corporate return By when|4months from end of lastcalendar month confirmed; not4months from midmonth period-end.|
|FI-39|PASS|PRH27May2026notice|Minimum150and>4months600supported; actual cases held.|
|FI-40|PASS|PRH27May2026notice|Consecutive2+periods doubling and reminder/decision process supported.|
|FI-41|PASS|PRHstartup obligations/late notice|Inactive companies still file annual accounts supported.|
|FI-42|PASS|PRHpermits opening/table|Officer residence, ownership, immigration, bank and regulation kept distinct; specialist outcomes not invented.|

## Independent arithmetic and no loss

Case1:10000capital+400fee=10400funding; deducting10000companycapital leaves400authorityfee. Original calculation block is byte-identical.

Case2: current110000>100000true,190000>200000false,4>3true, yielding2; previous90000>100000false,150000>200000false,2>3false, yielding0. Largest count2; ordinary omission fails because each period must have at most1. All six original flags and expected outputs preserved; all six original raw facts and three statutory thresholds now explicit in the block.

Case3:zero agreed capital gives300and400cash requirements; difference100. Narrative assumes every guided condition and refuses fee saving as a substitute for eligibility.

Every no-loss-map destination checked against baseline. Existing entity routes, board/deputy/chair and separate permit tests, incorporation deadline, full-payment/noncash screen, Virre/no-duration rule, audit exceptions, annual accounts/adoption/filing clocks, separate tax/VAT/payroll timing, fee caveats, inactivity rule, six intake questions and all original examples/inputs remain. Contributor suffix is byte-identical; no tier1 or professional approval added. File grows11831to18188bytes, no substantive removal.

## Holds and completion boundary

Retain explicit holds for complete company/accounting/Trade Register/fee-law chains; entity comparisons/share rights/full noncash procedure; foreign-person exceptions; beneficial-owner specifics; group/sector audit/sustainability; actual fee cases/live filing and named Finnish accountant review. Sources support only the stated ordinary route and headline controls. Other Finnish Guides were not reviewed in this assignment. Repository tests, actual-head validation, evidence packaging and publication are parent/writer gates, not certified by this receipt. A later unchanged wrapper/hash does not require this source review to restart.
