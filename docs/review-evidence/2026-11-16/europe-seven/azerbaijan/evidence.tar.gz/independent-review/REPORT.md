# Independent review: Azerbaijan formation and tax planning

PASS for the exact two versions below, subject to their explicit nonusable holds. Fresh independent Codex reviewer `/root/review_az`, 16 November 2026. This is an AI source review, not accountant approval, and does not cover the other Azerbaijan Guides.

Checked all **72 grouped ledger rows**: 30 formation and 42 planning. [row-results.json](row-results.json) records every row, article, official URL and result. Read the operative official text in the writer's cached web-reader captures, including neighboring exceptions and commencement annotations. The prior eight-Guide review expressly excluded these files and was not used as approval. Independently opened missing Tax Code arts. 219.1, 218-1.1.4, 178 and the second paragraph of 227.4.2. Read Social Insurance Law art. 14-1 for the additional subsidy referral; the final Guide makes no entitlement or subsidy computation.

The writer applied the review corrections; this reviewer changed no Guide or Git state. Targeted closure checked only those changes and dependencies against the initial full read.

| Correction closed | Official authority |
|---|---|
| Simplified base includes property proceeds and excludes income already taxed at source | [Tax Code art. 219.1](https://frameworks.e-qanun.az/46/f_46948.html) |
| Catering regime is elected; written election within 10 days from the first of the month after exceeding weighted threshold; 8% / qualifying integrated-POS 6% preserved | [STS 2026 FAQ, printed p. 13](https://www.taxes.gov.az/uploads/2026/faq/FAQ2026.pdf), Tax Code arts. 218.1.2, 220.1-1 |
| Asset-exclusion exceptions, special transport/fixed-activity service exceptions, gold-specific jewellery wording and mixed goods/work/services retention tests made explicit | [Tax Code arts. 218.5.6, 218.5.10-13, 218.6](https://frameworks.e-qanun.az/46/f_46948.html) |
| Micro exit credit confined to a company failing relief conditions then changing size category in the following reporting year; separate micro property exemption retained | [Tax Code arts. 106.1.20, 199.14](https://frameworks.e-qanun.az/46/f_46948.html) |
| Budget-funded contractor supplies excluded except resident local production; local nonproducing contractor still excluded; production sales outside/export allowed | [Tax Code arts. 226.3.3, 227.4.1-2](https://frameworks.e-qanun.az/46/f_46948.html) |
| Valid actual certificates required; six-year industrial-activity relief explicitly unusable until activity list and resident status verified; subsidy becomes eligibility referral only | [Tax Code arts. 106.1.13-2, 13.2.52-53](https://frameworks.e-qanun.az/46/f_46948.html), [Social Insurance Law art. 14-1](https://frameworks.e-qanun.az/3/f_3813.html) |
| Individual-founder speedy route, corporate founder TIN and unconditional AZ residence requirements for local electronic officers stated explicitly | [Registration Law arts. 5-2.3-5-2.5](https://frameworks.e-qanun.az/5/f_5403.html) |
| Founder/state-body registry-copy exemption correctly limits the nonexempt extract example | [State Duty Law art. 20-1.2](https://frameworks.e-qanun.az/2/f_2860.html) |

Preservation: independently compared both originals and the topic map. The line inventory matches every nonempty original line exactly: formation 40, planning 98. All original topics, refusals, open questions and case inputs survive or have an explained correction. Original planning `oa-check` is byte-exact; neither Guide shrank. No original protected credit, approval or CTA existed.

Four worked cases independently recomputed:

- MMC: electronic 1,000 + 18 = **1,018**; paper 1,000 + 15 + 2 × 3 = **1,021**.
- Branch: 300 + 3 × 3 = **309**; nonexempt four-page extract 4 × 2 = **8**, total **317**. Founder copy is exempt.
- Original planning case: 150,000 − 120,000 = **30,000** profit; simplified **3,000**, ordinary **6,000**, qualifying micro **1,500**.
- Added low-margin case: 150,000 − 140,000 = **10,000** profit; simplified **3,000**, ordinary **2,000**, ordinary saving **1,000**.

Unconfirmed and nonusable: full Decision 556/new-business classification; full startup Decision 20; park certificate implementing rules and specified activity list; current regulator confirmation beyond STS capital illustrations; accounting framework/financial-statement deadline; name reservation/seal and practical legalisation timing; subsidy schedule not computed; future 2027 amendments not applied. The Guide guards prevent inferring certificates or claiming the unidentified six-year activity relief. The ordinary micro size facts come from KOBIA's read current FAQ, not an unread register copy. This review does not certify completeness of those held topics.

Automated repository gates, live ownership/PR checks and publishing remain the coordinator's work. Reviewer `git fetch origin` failed DNS and was not represented as successful. No redundant test suite was run for this legal review. Raw source captures remain local, outside this review folder.

Exact reviewed files:

| Path | SHA-256 | Git blob |
|---|---|---|
| `skills/azerbaijan/az-company-formation.md` | `45bd960f4b2ff0abcd4db4fd184d6d8d53bae23bad4b55d5044d086c7bb70ef7` | `45c60e38ce4c3b8b2885cb2954b726dc8a817e1c` |
| `skills/azerbaijan/azerbaijan-tax-optimization.md` | `fc1f2e2b32666413a52d4c9e623b0e586f19314fa19acfb5dc10a5e4404b9ee4` | `d56e0f51e244cb6f9699ae001c6c303d6ff7b671` |

See [RECEIPT.json](RECEIPT.json) for machine-readable scope and hashes. No merge or publish was performed.
