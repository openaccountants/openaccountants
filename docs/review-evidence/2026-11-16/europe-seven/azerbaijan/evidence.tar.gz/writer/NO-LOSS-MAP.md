# Azerbaijan complete topic destination map

The JSON old-line-destinations.json inventories every nonempty original line, including metadata, old warnings, refusals and the complete original case block. These topic destinations explain substantive edits.

| Old topic | Final destination and treatment |
|---|---|
| Formation entity types, personal risk, all sector capital amounts | Method1, same amounts; authority illustrations distinguished from regulator verification |
| MMC creditor floor, prepayment/deferred3months/venture-fund exception,5daynotice | Quick reference and Method1, retained |
| STS authority,local/foreign electronic/paper processing,founderforeignlegalisation | Method2 + boundary; local officer/signature conditions added |
| Every duty/re-registration/duplicate/extract/notary/signaturecost | Quick reference and Method2; founder/state-body extract exemption added |
| Applicationfields,charter,beneficialowner,firstemployment,premises/bank/cashregister,SSPF | Method2/3; current payroll procedure handoff qualifies legacy notification wording |
| Simplified election2%/200000/exclusions;profitannual/advance;VAT/payroll;late40 | Method3; POS weighting and alternative/firstyear advance caveats added |
| Accounting/standards,unconfirmedname/seal/framework/statementsdate/legalisationtime/2027law | Method3/referral/Sources; retained as supported duty or unresolved topic |
| Planningquickreference2%,75%,3year,20%,200000,8%/6%,5%,30% | Quick reference/Method; unsupported warning removed after actual operative reading; URLs added |
| Simplifiedbase,nondeductiblecost,10%breakeven,propertytaxnotreplaced | Method1; catering exception/weighted threshold corrected; separate micro property relief restored |
| Every218.5 exclusion,30%quartertest/effective loss date,foreign invoices | Method1 + refusal; denominator excludes nonsales; mixed operations retained through source |
| Elections/filing/smallcompanydividend/socialcredit/standardrates | Method1; retained with URLs;20April andquarter20 unchanged |
| Original case150000/120000 andallformulas/results | Workedcases first case, unchanged oa-check; second lowmargin decision added |
| Micro75%/3workers/nodebt/headcount/3yearcredit/shamtransactions | Method2; credit corrected to statutory conditional exit rather than automatic growth rebate |
| Listedservices45000/75%/50%/formeremployer1year | Method2 retained, individualGuide routing retained |
| Startupdefinitions/certificate/3years/KOBIA/49% | Method2 retained; fullDecision20 remains unconfirmed |
| Liberatedterritory/Nakhchivanperiods,taxes,dividends/exclusions/activitygeography/separatebooks | Method2 retained; no importVAT expansion asserted |
| Industrial/technologypark10years/offparksoftware/dividend/property/land/certificates;specified6year;specialist5%7year;cluster7year | Method2 retained; commencement and qualification explicit, unidentifiedactivitylistsheld |
| Employer subsidy | Method2 referral only, no new entitlement/amount asserted; unresolved schedule retained |
| Dividend5%/no secondtax/deemeddividend/loanexception/exempt routes | Method3 retained |
| All redlines and five prohibitions | When to refuse or refer, retained; obsolete sibling-wins prohibition changed to reconcile law and linked Guides |
| No micro property relief found | Corrected to operative art199.14 relief subject1million residualassetexception; the old false uncertainty is explained in corrections |
| Remaining source gaps and disclaimer | Sources and scope/refusal; retained with no invented confirmation |

No contributed credits, approval or protected CTA existed in these two originals. Neither file shrank; every substantive removal is a correction of an erroneous statement or duplicate heading/warning. No original hypothetical value or refusal was discarded.
