# Azerbaijan writer and focused-correction record

Two assigned unsigned tier2 Guides updated for16November2026: formation0.2→0.3 and planning0.3→0.4. Recovered the current drafts and historical October research before writing; the historical independent review explicitly excluded these two files, so it was not reused as their approval.

All original formation topics, sector-capital illustrations, filing clocks, fee amounts and open topics are preserved. All planning reliefs, refusals and original150000/120000 case inputs/formulas are preserved. Added two formation funding examples and one low-margin planning decision. Neither file shrank; no credit, approval, licence or protected CTA was added/removed.

## Corrected with official support

| Previous claim | Final rule | Official source |
|---|---|---|
| Micro property exemption not found | Restored, except owned fixed assets aboveAZN1million start-year residual | TaxCode199.14, https://frameworks.e-qanun.az/46/f_46948.html |
| Automatic micro growth credit | Company-only conditional exit credit where relief conditions failed and category changes nextyear | TaxCode106.1.20, same official Code |
| Simplified threshold/base too broad | Weightedthreshold; post1Jan2026POS; property proceeds included; source-taxed income excluded | TaxCode218.1-1,219.1;Law297-VIIQD18.1, https://www.taxes.gov.az/uploads/2026/faq/FAQ2026.pdf |
| Catering described automatic | Eligible election, written10days fromfirstfollowingmonth afterthreshold;8%/qualifying6% retained | STS2026FAQprintedp13;TaxCode220.1-1 |
| Regime exclusions compressed | Asset-category exceptions,special-service exceptions,gold-specific goods,mixed-operation retention tests explicit | TaxCode218.5-218.7 |
| Territorial contractor rule broad | Budget-funded supplies excluded except resident production contractors; production exports permitted | TaxCode226.3.3,227.4.1 |
| Registry-copy fee universal | Founder/state-body exemption preserved;nonexempt case labelled | StateDutyLaw20-1.2, https://frameworks.e-qanun.az/2/f_2860.html |
| Electronic eligibility vague | Individual-founder speedy route,corporateTIN,resident officers and separate-signatory rule explicit | RegistrationLaw5-2,7-1, https://frameworks.e-qanun.az/5/f_5403.html |

The72-row grouped ledger inventories rules,figures,article,URL,native quote andactualread date. Source extracts were read in the web reader and cached locally after direct.az DNS failures. Retrieval alone is not claimed as law reading. CurrentCode operative paragraphs and future2027 annotations were distinguished. Full rawsource captures stay local. Complete no-loss map andevery oldnonempty line are indexed. Reviewer closed legalconditions,referral wording andtable-layout findings; exactfinal hashes in itsreceipt control over the preserved initialwriter checkpoint.

Allskillchecks return{},fourcases pass;rowchecker reports0misses but several official.az rows unreadable toitsdirect transport. Independentcachedwebtext review covers those rows;parser availability is notrepresented as sourceconfirmation. Shared22calculator/copytests passed. Required countrycommitted-content validator andstrictsync outputs includedaftercommit. No othercountry,website,generatedoutput orlive system changed.

## Holds

Full Decision556register/newbusiness classification, fullstartup implementingcriteria, park activity/certificate eligibility, currentsectorregulator capitalconfirmation and accountingframework/filingdetails remain nonusable holds/referrals. Actualvalid certificates are required; a summary is not an eligibility award. No claim ofcompletecountrycoverage oraccountantapproval.

Written by Codex (world wave). Not reviewed by an accountant.
