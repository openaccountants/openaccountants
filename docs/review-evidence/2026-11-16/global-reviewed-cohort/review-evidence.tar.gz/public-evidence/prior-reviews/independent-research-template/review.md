# Independent review of two root-authored files

Reviewed 2026-11-15 by the financial-topics writer acting solely as independent second reader for these two files. I did not author or edit either file. Original source base: 9397a0b792793cfe943946509e3132693867b5b5. Frozen review checkpoint: f13d66eccc6c9edf7fa1df480f6df956745104e9. Both working files remain byte-identical to that checkpoint.

## Verdict

DTT template: PASS for its expressly limited authoring/router job, SHA256 3f2c19464a8f5f57d119ee324c2a752a537acc7d4cd26dbf372217c666dff142. All 73 ledger groups and 61 original body atoms / 29 headings reviewed. All three cited sources independently opened and their operative scopes read. No bilateral treaty, rate, taxpayer entitlement or national procedure is approved.

Tax-research protocol: HOLD for independent source completion, SHA256 dc50df538877c7a6c9ef85887e6e1bcb65529fd7a347b59815042f26902638fb. All 38 groups and 95 original body atoms / 16 headings inspected. No substantive contradiction found in the independently recovered text. Four official sources remain inaccessible to this reviewer: PS LA 2008/4 identified May2025 PDF, PS LA 2009/9 paragraphs187–200, GSTR2000/10 withdrawal paragraphs1–4, and GSTR2026/D2 notice/1–9/57. Web returns403; ordinary Brave denies the last three, and the PDF did not yield readable text before native observation timed out/reset. IAB unavailable. These are not successful source reads. Parent's browser log is not substituted for independent reading. Ledger rows4/5/6/8 and dependent groups16/22/29/30/31/33 are held. A separate independent reader with actual source access must complete them before full topic approval. No change to either frozen file made.

## Scope and preservation

The complete row-by-row record is ledger-row-review.json (111 entries). Original hashes and mechanical nonblank-line accounting are in old-map-completeness.json. All 156 substantive original body atoms have individually recorded destinations and review in old-atom-review.json. DTT's seven omitted horizontal separator lines are formatting only. Each original DTT category, article, TRC/MAP/contact/upstream field survives; unsupported generic defaults are specifically reserved. Tax research retains all seven method steps, all file-note fields, three traps and three original scenarios; former automatic-live-check and professional-assignment assurances are explicitly reserved. Lost content restored: 0. Neither draft shrinks; no duplicate deletion.

Ryan Duguid credit and original licence in tax research are exact. Original DTT general-reference disclaimer exact. No original CTA exists in either. No reviewed_by added; both remain tier2. No accountant/professional attestation claimed.

## Qualitative cases independently executed

DTT blank dividend-cap slot: missing bilateral text prevents treating domestic rate as treatycap or zero. Pass.
DTT MLI signatures only: force, paircoverage, positions/compatibility and effect remain required. Pass against MLI1–2/28/34–36 and toolkit.
Tax inaccessible subsection: retain exact dependency; no invented wording or confirmation. Pass.
Tax August2026 RCTI: retrieval/version/draft route is appropriate; own determination1–9 read and latest/inforce version identified, but withdrawal and draftnotice facts remain source-held. No RCTI eligibility or credit approved.
Tax no reviewerdecision: conditional position with pendingreview, no invented signoff. Pass.
No original monetary cases or actual rates; no dummy arithmetic. The date calculation day-after14June2023registration=15June2023 is independently checked; August2026 is later. No recomputing oa-check blocks required for these bounded routers under current shape rules.

## Verification and remaining boundary

Own filtered skill_checks results {} for both; required-example commands each exit0, 0blocks/0failures/0missing. Both exact frozen hashes independently recomputed. gitdiffcheck for both paths clean. See checks.json. Full CI/changed pack validation remains root's publication gate. This is complete inspection of all listed groups/topics, with explicit unresolved independent-source gaps, not a complete approval of tax research.

source-review.json records all13 independently attempted sources and operative scopes. Source HTML/text in sources/ are independent downloads; own web/browser observations are identified in that register. Sources blocked here must not be marked independently verified based on search snippets or HTTPstatus. Parent's cached PS2008/4 text was inspected only as audit context and not treated as an independent official-source open. Current TR2006/10 and PCG2016/1 were independently recovered through ordinary native Brave; no challenge/security bypass, account or paidAPI used.
