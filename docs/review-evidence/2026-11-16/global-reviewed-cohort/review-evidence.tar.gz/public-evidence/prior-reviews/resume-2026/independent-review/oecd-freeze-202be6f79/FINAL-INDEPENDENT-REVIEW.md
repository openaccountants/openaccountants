# Independent review: PASS, one exact Guide only

Candidate commit `202be6f79b7a480a1a633665c9500e825a6e0c1a`, Guide SHA256 `c8b0711d591bba0d0862faa8c28124697252db5193efbf27cd1f8824451e9b07`. Original SHA256 `a7106293779b9b897ea8a45398b9699ef54f1bba069930ecf8b1504ddf2fcf06` matches current origin/main. This verdict is advisory source review, not accountant attestation. It does not pass any other Guide or pack.

Read the entire original and candidate; checked all180ledger rows, all91native-source units and1035short exact fragments. Native fragments reproduce the complete cited operative scopes, are individually at most25words, have exact official source locators and honest dates, and literally match independently extracted source text after whitespace/Unicode normalization. Personally read the actual operative paragraphs and neighbouring exceptions, rather than relying on the ledger.

Primary reading: OECD current Model arts1–5,7–13,15–19,23A–B,25,29 and effective-date neighbours; Commentary4 paras12–20,5 paras6–18/28–34/52–55,12 paras11.6/12–17.4, deleted14 opening,15 paras4–6.2 with neighbours; update44.1–44.21 including examplesA–E; UN2021arts5/12/12A/13/14; actual UK–Germany arts14–20 and23. Sixteen numeric-condition pages independently rendered and visually inspected. Full Model fresh web read failed on size; shell DNS failed; the hash-bound dated official full PDF was actually read. Update, UN2021 and UK–Germany opened through the web tool. UN2025 returned403 and remains explicitly unread. No whole-PDF or current-national-law reading is claimed.

All238original heading/body entries were compared with actual new-body destinations, including each condition, exception, refusal, cross-Guide handoff and monetary/day scenario. The one no-loss finding was closed by14individually identified, explicitly unconfirmed/unusable legacy items. The final map binds the actual line text, not just topic names.

Recomputed both numeric blocks: exemption1000combined; ordinarycredit1000plus3000residual=4000combined; creditceiling1000withzeroresidualand3000uncredited=4000combined. Walked through150/190-day employment cases and both other exemption gates under actual UK–Germany14; no domestic-rate or payroll conclusion inferred.

All five checks resolved:19structural checks pass; targeted validation1Guide0warnings;2example blocks pass; calculator quotes preserved; row-source helper8rows0MISS8UNREADABLE with each manually cleared by actual primary clauses (separate clearance file). The writer live8/0/0result is retained as writer evidence only. Git diff check passes. No full CI claim.

Licence, platform identity, original disclaimer liability/signoff requirements and honest tier2 preserved; no human author/licence/attestation or commercial CTA existed to lose. Sources remain last. UN2025, unsupported national classifications/relief, generic treaty ranges and timing estimates remain unusable and individually explicit.
