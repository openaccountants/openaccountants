# Egypt–Saudi corridor independent exact-hash review

**PASS**, 16 November 2026, local checkpoint `7152b7654bd11470a24611f901f396f4175ded7c`.

Guide SHA256: `8eec81cc6c98144479d2773f1aa3f2cf5e0f9bf2809e9dc461bbbb495d05441d`.
Ledger SHA256: `745f718cc66747708b867c9eb7e6ca0f0c41f141e636cfbd1bbbd464f2e8ccb4`.
Old-topic map SHA256: `c61aced25e0b1ca9b12121be366b4c5a365f068fef82cffa7ce4e198a650170e`.
Source register SHA256: `b95218ee6d9db58f8194cdcd606b486f4e924256900148d2838e36e0641f57d5`.

The complete original and candidate, all 227 ledger groups, all 551 final short native fragments, all 44 original headings and 205 non-heading entries were independently reviewed. All 249 map entries bind exact original text to actual current destinations; multi-topic old rows have multiple operative destinations. Four original cases, their alternatives, the new employment case and numerical boundary conditions were independently recomputed in 16 recorded scenarios. Preserved named entities, SA Co/EG HoldCo/EG Co/SA Bank/SA Tech/SA Build facts, Ahmed Hassan credit,professional-state limitations and cross-reference/licence/platform text were checked.

Actual source reading includes all 32 Arabic treaty/Protocol page visually, full relevant MLI clauses and precise pair positions/reservations/notifications, official Egyptian Gazette legislation/amendments/corrigendum images, the ETA international-agreements procedures, Saudi WHT/DTA procedures, the dated law reprint and current amended Zakat/base/rate provisions. The manual Arabic extracts and Zakat formula were visually checked. Source-read scopes, dates, hashes and failed ordinary retrievals are explicit in the baseline source-read record. The English synthesis is guidance and does not displace authentic Arabic. No search snippet or HTTP success substitutes for operative text.

All first-pass findings are closed: 18 native rows repaired with 27 precise clauses and 44 short fragments; 209 other groups are unchanged; six old personal-income domestic labels now individually reserved as unconfirmed and unusable. The complete map now routes substantive atoms to actual body paragraphs, including the interest-definition and entry-force corrections. The final Guide differs only at the existing Sources reservation paragraph; all operative numerical rows, cases and names remain identical to the fully read first-pass candidate.

All five applicable checks were independently rerun at the exact final candidate: 19 structural checks clear; targeted validation has 0 errors and 0 warnings; two oa-checks pass; preserved calculator quotes and diff checks pass. The source helper returned 12 UNREADABLE and 0 MISS because ordinary CLI DNS failed. Each row was individually cleared through actual primary paragraphs/images in `../egsa-freeze-2c5de0e2/independent-row-source-manual-closures.json`. The writer’s prior 22.5% text-layer MISS was likewise independently cleared through the actual Gazette Article 49 image. This is not an automated-all-green claim.

This is an independent content review of the specified source-cited draft, not accountant attestation or taxpayer-specific advice. The express current Egypt MAP, decree, TRC, nondiscrimination, domestic asset and personal-income uncertainties remain outside usable guidance. Root must refresh current main and overlap before any separately authorised publication. No unresolved independent findings remain for these exact bytes.
