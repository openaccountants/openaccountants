# PASS — independent source review of two EU Guides

Exact reviewed commit: `289ea8e8eeff7b1eca7d218233e33ca0b8f44646`.

Actual source read and review date: **14 November 2026**. Reviewer is independent of the writer. This is source-review clearance of the two files below, with their stated referral boundaries. It is not accountant attestation, publication/merge permission, or approval of the 53-file global pack.

| File | SHA256 | Grouped ledger rows | Original headings | Original bullet/table rows |
|---|---|---:|---:|---:|
| skills/global/cross-border/eu-reverse-charge.md | d309db4296b3c9a4b2ca8c5a7aa9333263e5a2c9492262ba6adfbaa9a2c9d745 | 63 | 38 | 84 |
| skills/global/cross-border/eu-oss-digital.md | 8ee9e414bfc1f796c53edf3d5094fc16bb1b5350815812a9c725f7b77a77320b | 102 | 43 | 115 |

The working bytes match the committed blobs. Both ledgers and both old-topic maps name these exact current hashes and the independently checked original hashes at base `9397a0b792793cfe943946509e3132693867b5b5`. All ledger IDs are present and consecutive. Original inventories independently regenerated from `git show` match every mapped line: **81 headings and 199 bullet/table rows**, with no missing or extra atoms. All original scenario prose was separately compared. No substantive old-topic loss remains; no additional restoration required at final review.

**Full rule/figure coverage:** all **165 grouped ledger rows** checked, comprising **163 supported groups** and **2 explicitly reserved historical-claim groups**. These counts group repeated figures and rules; they are not a claim that a numerical token counter is a legal review. All 27 standard-rate country rows and all 9 original explicit reduced-publication country topics were independently researched in opened official sources. Every current operative figure/rule was checked with its neighboring conditions and exceptions. Exact short quotations were checked, distinguishing official table-cell transcriptions and whitespace normalization. Literal quote defects identified in earlier reviews are corrected. Row-by-row outcomes are saved in `final-row-verdicts.json`.

Source scopes, URLs, provenance and failed-retrieval limitations are recorded in `source-read-scope.md` and `source-read-scope-addendum.md`; earlier findings and arithmetic are preserved. Directive Article203 was additionally read in full, supporting RC Prohibition7 and the corrected ledger row24. Its invoice liability is separate from Article196 and national correction procedures. C647/17 evidence is the complete successful official parsed-PDF response saved locally; the HTML file bearing a .pdf suffix is explicitly not legal proof. No fresh judgment-PDF byte retrieval is claimed.

Italy's 4% digital-publication treatment has the actual 2016 circular conditions, the reopened official former TableA II18 category/exclusions, and the 2026 Gazzetta recodification's continuity/2027 commencement corroboration. The latter is not applied as a 2026-operative replacement. Both genuine PDFs, retrieval URLs, byte counts/hashes and read scopes are preserved. Current Guide citations and ledger rows101–102 accurately describe that boundary.

**Examples and checks:** independently reviewed all **18 original prose scenarios** (RC8 examples plus5 tests; OSS5 tests), all10 original edge-case discussions, and all **4 added executable examples**. All arithmetic recomputed, including partial deduction950/380/570, the entire crossing supply500/100/600, and net ebook15×5.5%=0.825→0.83 versus the gross-price comparison0.78. Legal assumptions, net/gross prices, illustrative turnover/customer counts and deduction fractions are explicit. Final-head local example checker returned: `checked 2 files, 4 oa-check blocks, 0 failures, 0 missing`. Independent Decimal calculations also pass; details in `final-arithmetic.json`.

The new source/evidence fixes, upfront quick references, Article31a property condition, Article18 pending-ID versus invoice-content distinction, zero-rated OSS exclusion, and final Irish zero-rate words-on-page annotation were checked against the exact final diff. Passing source-file siblings were not edited. Relative to the original base, this checkpoint changes only the two named files.

**Limits retained:** no clearance for exhaustive national relief/product classifications across all27 countries; current Malta return boxes; Italian annual boxes for2026 transactions; local penalties, VAT groups, use/enjoyment or SME implementation; or exact national portal/remedy workflows. Historical unsupported claims remain under Not yet confirmed, outside usable instructions. Italian IVA2026 form mappings expressly concern tax period2025. Professional review remains required; the tier2 metadata makes no human-attestation claim.

This review did not rerun the whole-repository validation suite or paid review APIs. An exploratory `validate-guides.py --help` invocation began broader validation rather than displaying help and was stopped (exit130); it supplies no passing validation evidence. The explicit two-file four-case check above completed successfully. The writer's broader checks are separate evidence, not represented here as independently rerun.

**Final verdict: PASS for these two exact Guide blobs and their explicit scope boundaries.** Reconcile hashes again if a later pack head changes either file. No unresolved substantive source, arithmetic, quotation or no-loss finding remains within this two-file review.
