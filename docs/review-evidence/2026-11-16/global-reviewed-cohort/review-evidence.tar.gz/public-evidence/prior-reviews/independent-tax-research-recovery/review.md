# Independent tax-research source recovery

2026-11-15. Frozen Guide SHA256 `dc50df538877c7a6c9ef85887e6e1bcb65529fd7a347b59815042f26902638fb`, independently recomputed unchanged. No Guide edit, commit, index, publication or merge.

**HOLD: three of the four independent source-access gaps remain.** This is a source-recovery delta to the prior full review at `../independent-research-template/review.md`, not a claim that this reader repeated all 38 ledger groups or the whole no-loss audit.

## Source cleared

PS LA 2009/9: independently opened the actual official source in ordinary native Brave and personally read paragraphs184–203 inclusive, the authority/reliance notice and history. Every requested paragraph187–200 and201 was read, including operative purpose, appeals/finality context, affected ATO views, no proxy amendment and no public-ruling status. Exact URL, native extracts, scope and version context are in `psla2009-9-observation.md`. This supports ledger5/30 and the DIS component of16. No substantive contradiction with the frozen Guide was found in this recovered scope. No general litigation-procedure approval.

## Sources still held

- PS LA2008/4: own ordinary browser download of the identified official PDF completed, but content was not exposed for reading. A successful download is not a successful read. Clicking it twice yielded browser user-control interruptions; no local file path was actually returned or observed. Fresh ordinary direct HTTP and web requests returned403. Sections1–2 and7 plus neighbors remain independently unread. Rows4/29 and the edited-private-advice component of16 remain held.
- GSTR2000/10 withdrawal: direct own web returned403/cache miss and ordinary curl returnedHTTP403 (exit56). Required paragraphs1–4 remain independently unread. Rows6/31 and the withdrawal component of22 remain held.
- GSTR2026/D2: own web and ordinary curl returnedHTTP403 (exit56). An official ATO public-content lead also returned403; its search snippet was not treated as source proof. Required reliance notice/paragraphs1–9/57 plus neighbors remain independently unread. Rows8/33 and the draft component of22 remain held.

The active native browser had returned to an unrelated user chat with prompt focused, so UI actions stopped rather than contest user focus. No challenge/security bypass, changed account/model, paidAPI, filing or contact was attempted. Parent's own prior source logs and another reader's excerpts were not substituted for actual independent source access.

Evidence: `status.json`, `web-attempts.json`, `gstr-web-attempts.json`, `final-http-attempts.json`, `psla2009-9-observation.md`. Ordinary CLI403 failures are recorded precisely in status and this report; failed downloads yielded no source bytes.

A complete source-bound approval requires actual independent reading of the remaining three sources and comparison against the frozen Guide. The access failures are not substantive contradictions, and they are not source clearances.

## Recovery delta: actual PS LA2008/4 PDF read

The previously unread own download has now been located and personally read, including cover and sections1–8/printedpages1–3, with visual inspection of both operative two-column pages. See psla2008-4-observation.md for exact source path, SHA256, own download provenance, native extracts and scopes. Rows4/29 and the remaining component of16 clear for this identified version. **Updated verdict: HOLD, two source-access gaps remain**, solely GSTR2000/10W and GSTR2026/D2. The earlier failed-access history above is preserved, not relabelled as a read.

## Recovery delta: actual GSTR2026/D2 PDF read

Personally read the newly recovered actual official PDF notice/paragraphs1–16+footnotes and54–58. Renders visually confirm reliance notice andproposeddate. Exacthash/provenance/scope/quotes in gstr2026d2-observation.md. Rows8/33 and draftcomponent22 clear. **Updated verdict HOLD: only GSTR2000/10W withdrawal notice remains independently unread.** Earlier sourcefailures remain historical evidence.

## Final source-bound recovery verdict

**PASS for the bounded tax-research protocol at unchanged SHA256 `dc50df538877c7a6c9ef85887e6e1bcb65529fd7a347b59815042f26902638fb`.** The four independent access holds identified in the prior complete review are now all cleared by actual personal source reads. The final withdrawal PDF was independently read in full, including both pages and all paragraphs1–4, and visually checked. See `gstr2000-10w-observation.md` for exact source and PDF hash. The frozen scenario matches withdrawal29July2026, retained application through14June2023 and exclusion from15June2023. No substantive contradiction found in any of the four recovered scopes.

This completes the prior separate full38-group,95-body-atom/16-heading, qualitative-case independent review by resolving its explicitly bounded source dependencies. It does not claim this recovery reader repeated the other34 groups or no-loss audit; their preserved complete record is `../independent-research-template/review.md` and its row/atom files. No Guide edit, professional attestation, transaction/RCTI eligibility approval, publication or merge. Earlier failed-access evidence is retained. Whole-pack review and sync no-merge hold remain root’s responsibility.
