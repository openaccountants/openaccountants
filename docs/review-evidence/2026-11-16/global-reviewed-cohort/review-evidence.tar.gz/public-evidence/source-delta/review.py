from pathlib import Path
import sys,json,hashlib,subprocess,re,difflib,ast
from decimal import Decimal,getcontext,ROUND_HALF_UP,ROUND_FLOOR
import yaml
sys.dont_write_bytecode=True
R=Path('/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-resume-2026-11-16');W=R/'wt-global-reviewed-cohort';O=R/'review-global-source-delta-277b0bad2';D=R/'global-figures-diagnostic';L=Path('/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1')
P='1e622bc001979ed514d8b0827e4bb7705c81d2b3';H='277b0bad2c2a15750f2b1b6105068eaf684dc6e4'
git=lambda *a:subprocess.check_output(['git',*a],cwd=W)
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(p.read_text())
dump=lambda n,d:(O/n).write_text(json.dumps(d,ensure_ascii=False,indent=2,default=str)+'\n')
assert git('rev-parse','HEAD').decode().strip()==H and git('rev-parse',H+'^').decode().strip()==P
assert not git('status','--porcelain')
bind=load(R/'review-global-reviewed-cohort/exact-bindings.json'); paths=[x['path'] for x in bind['files']]; assert len(paths)==20
changed=git('diff','--name-only',P,H).decode().splitlines(); assert len(changed)==3
urlmap=load(D/'proposed-source-mapping.json'); rev={x['actual_official_representation_url']:x['old_url'] for x in urlmap}
norm=lambda t: __import__('functools').reduce(lambda s,kv:s.replace(*kv),rev.items(),t)
old={p:git('show',P+':'+p).decode() for p in paths};new={p:(W/p).read_text() for p in paths}
assert all(sha(old[x['path']].encode())==x['composed_sha256'] for x in bind['files'])
# Exact whitelist of all changes, not a textual similarity threshold.
cb=next(p for p in paths if p.endswith('/cbam-carbon-border-adjustment.md'));va=next(p for p in paths if p.endswith('/cross-border-vat-gst.md'));eg=next(p for p in paths if p.endswith('/eg-sa/dtt-summary.md'))
new_cb_source=next(s for s in new[cb].splitlines() if s.startswith('| Direct official DOC_1 representations'))
assert norm(new[cb]).replace(new_cb_source+'\n','',1)==old[cb]
assert new_cb_source in new[cb] and new[cb].count(new_cb_source)==1
assert all(new[cb].count(k)==old[cb].count(v) for k,v in rev.items())
historical='5% for 2026, replacing the original 7.5% row.'
assert old[va].count(historical)==1 and new[va].count(historical)==1
reconstructed=new[va].replace('\n'+historical+'\n','',1).replace('| Turkey | 5% for 2026.','| Turkey | '+historical,1)
assert reconstructed==old[va]
eg_source=next(s for s in new[eg].splitlines() if s.startswith('| [ETA resident-corporate explanation,'))
eg_add='; [ETA dated resident-corporate amount corroboration](https://eta.gov.eg/en/node/242)'
assert new[eg].replace(eg_source+'\n','',1).replace(eg_add,'',1)==old[eg]
assert new[eg].count(eg_add)==1
# Every parent line: exact or explicit source/prose transformation; no lost line.
line_maps=[]
for p in changed:
 a=old[p].splitlines(); b=new[p].splitlines(); bn=[norm(s) for s in b]; maps=[]
 for i,s in enumerate(a,1):
  if p==va and s.startswith('| Turkey | '):
   n=next(j+1 for j,x in enumerate(b) if x.startswith('| Turkey | '));hist=b.index(historical)+1
   maps.append({'parent_line':i,'parent_line_sha256':sha(s.encode()),'final_lines':[n,hist],'kind':'same complete operative row, historical sentence separately preserved verbatim'});continue
  if p==eg and 'Egyptian ordinary corporate-profit rate:22.5%' in s:
   n=next(j+1 for j,x in enumerate(b) if 'Egyptian ordinary corporate-profit rate:22.5%' in x)
   assert b[n-1].replace(eg_add,'')==s
   maps.append({'parent_line':i,'parent_line_sha256':sha(s.encode()),'final_lines':[n],'kind':'same full row, narrow added official citation only'});continue
  matches=[j+1 for j,x in enumerate(bn) if x==s]
  assert matches,(p,i,s)
  # For repeated blank/table separator lines record all true matches; content/topic ambiguity is not invented.
  maps.append({'parent_line':i,'parent_line_sha256':sha(s.encode()),'final_lines':matches,'kind':'exact after three allowed same-body URL substitutions' if p==cb else 'byte exact'})
 line_maps.append({'path':p,'parent_lines':len(a),'final_lines':len(b),'rows':maps,'all_parent_lines_accounted':True})
dump('all-parent-lines-to-final.json',{'head':H,'parent':P,'files':line_maps,'parent_lines':sum(len(x['rows']) for x in line_maps),'no_loss':True})
# Precise old-topic map destination rebinding at final bytes.
prior_maps=[]; failures=[]
# CBAM: all125 entries, heading/prefix evidence checked against actual final headings/body.
m=load(L/'cbam-writer/old-topic-map.json')
cb_rows=m['all_old_headings']+m['all_old_nonblank_body_lines'];assert len(cb_rows)==125
out=[];b=new[cb].splitlines()
for row in cb_rows:
 ev=[]
 for x in row['actual_destination_evidence']:
  li=x['actual_line']; fi=li if li<266 else li+1; expected=x['actual_heading']; actual=b[fi-1]
  # Existing Sources heading remains on260; all original body headings precede inserted source row.
  ok=actual.lstrip('# ').strip()==expected.strip()
  assert ok,(li,expected,actual)
  following=x['actual_following_text']; normalized=norm('\n'.join(b[fi:fi+8]))
  assert following in normalized,('cb_follow',li,following)
  ev.append({'prior_heading_line':li,'final_heading_line':fi,'heading':expected,'unchanged_original_following_text_verified_with_only_representation_substitution':True})
 out.append({'old_line':row['old_line'],'destinations':ev})
prior_maps.append({'path':cb,'prior_map':str(L/'cbam-writer/old-topic-map.json'),'sha256':sha((L/'cbam-writer/old-topic-map.json').read_bytes()),'original_entries':125,'rebinding':out})
# VAT/GST191 old heading/body entries. Each prior numeric destination is re-bound through full parentline proof.
mp=L/'cross-border-vat-writer/cross-border-vat-gst-old-topics.md';out=[]
for s in mp.read_text().splitlines():
 if not re.match(r'^\| \d+:',s):continue
 cols=s.split('|'); oldline=int(re.match(r'\s*(\d+):',cols[1])[1]); dest=re.search(r'\[([\d, ]+)\]',cols[2]);assert dest
 ns=[int(v.strip()) for v in dest[1].split(',')];ev=[]
 for n in ns:
  final=n if n<149 else n+2
  parent=old[va].splitlines()[n-1];now=new[va].splitlines()[final-1]
  if n==145:
   assert now.replace('5% for 2026.',historical,1)==parent
  else:assert now==parent,(n,final)
  ev.append({'parent_line':n,'final_line':final,'parent_destination_sha256':sha(parent.encode()),'final_destination_sha256':sha(now.encode()),'history_also_at_final_line':149 if n==145 else None})
 out.append({'old_line':oldline,'destinations':ev})
assert len(out)==191
prior_maps.append({'path':va,'prior_map':str(mp),'sha256':sha(mp.read_bytes()),'original_entries':191,'rebinding':out})
# Egypt249 old entries: all stored exact destination paragraphs, incl multiple destinations, advance after new Sources273.
mp=L/'resume-2026/independent-review/egsa-complete-delta-8eec81cc/old-topic-map.json';m=load(mp);out=[]
for row in m['rows']:
 ev=[]
 for x in row.get('destinations',[]):
  n=x['line'];f=n if n<273 else n+1;par=old[eg].splitlines()[n-1];now=new[eg].splitlines()[f-1]
  assert x['exact_text']==par,(row['old_line'],n)
  assert now.replace(eg_add,'')==par,(row['old_line'],n,f)
  ev.append({'parent_line':n,'final_line':f,'parent_destination_sha256':sha(par.encode()),'final_destination_sha256':sha(now.encode()),'role':x.get('role')})
 out.append({'old_line':row['old_line'],'destinations':ev})
assert len(out)==249
prior_maps.append({'path':eg,'prior_map':str(mp),'sha256':sha(mp.read_bytes()),'original_entries':249,'rebinding':out})
dump('all-old-topic-destinations.json',{'head':H,'entries':565,'files':prior_maps,'errors':[],'scope':'Final destination identity/offsets checked for all preexisting complete original-topic maps; prior full semantic no-loss decisions retained, not replaced by shallow heading matches.'})
# Immutable prior report and evidence chain reverified, without copying native material.
chain=load(R/'review-global-reviewed-cohort/review-chain-fingerprints.json');verified=[]
for pop in ['sealed_artifacts','prior_review_artifacts']:
 for x in chain[pop]:
  p=Path(x['path']);actual=sha(p.read_bytes());assert actual==x['sha256'],str(p)
  verified.append({'population':pop,'path':str(p),'sha256':actual})
manifest=load(R/'review-global-reviewed-cohort/final-review-manifest.json');mverified=[]
for name,s in manifest['files'].items():
 p=Path(name);actual=sha(p.read_bytes());assert actual==s
 mverified.append({'path':name,'sha256':actual})
dump('immutable-review-continuity.json',{'head':H,'parent':P,'sealed_count':len(chain['sealed_artifacts']),'reference_count':len(chain['prior_review_artifacts']),'artifacts':verified,'prior_final_manifest_artifacts':mverified,'errors':[]})
# All20 metadata, cases, holds, credits and CTA exact,17 siblings exact.
blocks=lambda t:re.findall(r'```oa-check\s*\n(.*?)\n```',t,re.S)
sys.path.insert(0,str(W/'scripts'));import skill_checks as sc
prot=[];case_rows=[];getcontext().prec=50
# Reuse only the prior independent pure AST evaluator, not its stateful task code or repository example engine.
prior_code=(R/'review-global-reviewed-cohort/review.py').read_text();tree=ast.parse(prior_code); funcs=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ['number','calculate']];exec(compile(ast.Module(body=funcs,type_ignores=[]),'<prior-pure-independent-evaluator>','exec'))
for p in paths:
 a,b=old[p],new[p];assert a.split('---',2)[1]==b.split('---',2)[1],p
 assert blocks(a)==blocks(b),p
 holds=lambda t:[s for s in t.splitlines() if 'Not yet confirmed:' in s]
 assert holds(a)==holds(b),p
 credits=lambda t:[s for s in t.splitlines() if re.search(r'Contributed by|Artin|ar-gen-tin|Ahmed Hassan|Ryan Duguid|openaccountants-cta|calculator',s,re.I)]
 assert credits(a)==credits(b),p
 findings={k:v for k,v in sc.run_checks(p,b,sc.read_frontmatter(b)).items() if v};assert not findings,(p,findings)
 count=0
 for idx,block in enumerate(blocks(b),1):
  d=yaml.safe_load(block);env={k:number(v) for k,v in d['inputs'].items()};steps=d['steps'];steps=steps if isinstance(steps,list) else [steps]
  for step in steps:
   for k,v in step.items():env[k]=calculate(v,env)
  results=[]
  for k,v in d['expected'].items():
   expected=number(v);ok=abs(env[k]-expected)<=Decimal('0.00000000000001');assert ok,(p,idx,k)
   results.append({'key':k,'computed':str(env[k]),'expected':str(expected),'pass':ok})
  case_rows.append({'path':p,'index':idx,'name':d['name'],'block_sha256':sha(block.encode()),'all_inputs_steps_expected_eligibility_block_exact_to_parent':True,'results':results});count+=1
 prot.append({'path':p,'parent_sha256':sha(a.encode()),'final_sha256':sha(b.encode()),'byte_exact':a==b,'frontmatter_byte_exact':True,'holds_byte_exact':True,'human_credits_CTA_calculator_mentioned_lines_exact':True,'case_blocks_exact':True,'cases':count,'shape_findings':findings})
assert len(case_rows)==32 and sum(len(x['results']) for x in case_rows)==141
assert sum(x['byte_exact'] for x in prot)==17
dump('all20-protections-and-shape.json',{'head':H,'parent':P,'files':prot,'unchanged_siblings':17,'all_frontmatter_case_hold_credit_CTA_protections':True})
dump('independent-decimal-cases.json',{'head':H,'method':'Prior independent pure AST/Decimal evaluator reused, precision50 and half-up rounding, executed anew on all32 final byte-identical case blocks. No repository example-engine import or call. Legal assumptions remain bound to prior full reviews and unchanged surrounding narrative via exact allowed-delta proof.','cases':case_rows,'count':32,'results_checked':141,'failures':0})
# Source packet current integrity, actual source read scopes and hashes independently re-bound.
diagman=load(D/'FINAL-MANIFEST.json')
for x in diagman['artifacts']:assert sha(Path(x['path']).read_bytes())==x['sha256']
sources=load(D/'ordinary-fetches.json'); continuity=load(D/'prior-body-continuity.json')
for x in continuity: assert sha(Path(x['prior_path']).read_bytes())==x['prior_sha256']==x['fresh_sha256']
for x in sources:assert sha((D/(x['key']+'.body')).read_bytes())==x['sha256']
dump('source-continuity.json',{'head':H,'diagnostic_manifest_sha256':sha((D/'FINAL-MANIFEST.json').read_bytes()),'all50_diagnostic_artifact_hashes_verified':True,'actual_bodies':sources,'same_operative_doc1_bodies':continuity,'newly_read_scope_binding':{'path':str(D/'actual-scoped-read-contexts.json'),'sha256':sha((D/'actual-scoped-read-contexts.json').read_bytes())},'visual_reopened_this_review':['eg96-page-2.png','turkey-current-page-1.png','turkey-note-page-1.png'],'limits':'Read the actual saved16Nov ordinary official bodies and relevant native contexts. Three PDF views personally reopened. No new fresh GET or complete20-law reread claimed.'})
dump('exact-delta-summary.json',{'head':H,'parent':P,'changed':changed,'cbam_substitution_counts':[{ 'old':v,'new':k,'occurrences':old[cb].count(v)} for k,v in rev.items()],'cbam_source_row_added':new_cb_source,'turkey_history_exact':historical,'history_final_line':new[va].splitlines().index(historical)+1,'egypt_row_citation_addition':eg_add,'egypt_source_row_added':eg_source,'exact_whitelisted_transformations_reconstruct_every_parent_byte':True,'clean':not git('status','--porcelain')})
print(json.dumps({'head':H,'files':20,'delta_files':3,'unchanged':17,'all_parent_lines':sum(len(x['rows']) for x in line_maps),'old_map_entries':565,'sealed':len(chain['sealed_artifacts']),'references':len(chain['prior_review_artifacts']),'cases':32,'results':141,'failures':0},indent=2))
