# Global cohort figures: bounded source-format diagnostic

Completed 16 November 2026. Candidate unchanged and clean at `1e622bc001979ed514d8b0827e4bb7705c81d2b3`. This is a diagnostic of ten machine misses in three files, not a fresh full twenty-file source review, accountant approval, release approval or production check.

## Result

The ten misses have three different causes: eight PubOffice metadata representations, one intentionally rejected historical Turkish rate in an operative-rate table, and one Egyptian custom-font PDF extraction failure. The actual rates checked here are supported within the precise existing or narrowly corroborated scopes below. No numerical tax rule correction is proposed.

The original terminal cohort result remains **121 rows, 10 MISS, 8 UNREADABLE**. In-memory replay using the unchanged stock checker and locally saved actual HTTP bodies gives:

| Diagnostic input | Rows | MISS | UNREADABLE |
|---|---:|---:|---:|
| CBAM rows linked to the three original aliases, metadata as actually returned | 12 | 8 | 0 |
| Same 12 rows, same operative official DOC_1 bodies | 12 | 0 | 0 |
| Original Turkey row | 1 | 1 (7.5%) | 0 |
| Proposed Turkey operative row, with historical sentence preserved separately | 1 | 0 | 0 |
| Original Egypt row, actual law PDF text layer | 1 | 1 (22.5%) | 0 |
| Proposed same Egypt row plus narrow dated ETA corroborating source | 1 | 0 | 0 |

These are selected-row proofs (`target-row-proofs.json`), not a whole-cohort rerun or hosted check. The eight original UNREADABLE rows were outside this ten-miss diagnostic and remain unresolved by it. No annotation or bypass was added. No candidate, script, prior evidence or source ledger was modified.

## CBAM: three exact official representations

The CELEX alias URLs return HTTP 200 `application/rdf+xml` metadata through an RDF endpoint. The checker strips tags and treats the resulting 9,862 / 12,823 / 22,705 characters as readable under its 400-character heuristic. This is metadata, not an operative law body. Some unrelated metadata numbers accidentally satisfy other figures, so a passing lexical lookup on these responses is not source verification.

Ordinary direct HTTPS requests to the following official representations return HTTP 200 XHTML. Their full SHA256 values exactly equal the prior independent CBAM review's `reopened` bodies (`prior-body-continuity.json`). No authentication, bypass or changed software was needed.

| Baseline file row(s) | Operative provision / exact newly read scope | Actual official representation |
|---|---|---|
| `cbam-carbon-border-adjustment.md:35` | 2023/956 Art 22(2), (2a), preceding 22(1), following 22(3) and 23. From 2027, at least 50% at quarter end; statutory defaults without markup or qualifying prior-year same CN/origin route, free-allocation adjustment, threshold-crosser following quarter. Commencement cross-reference retained. | [2023/956](https://publications.europa.eu/resource/cellar/a61c0d38-bf6a-11f0-a612-01aa75ed71a1.0007.02/DOC_1) |
| `cbam-carbon-border-adjustment.md:91` | 2025/2621 Arts 1–2 and corrected Annex I opening. Applicable total emissions increased 10% in 2026, 20% in 2027, 30% from 2028 for listed sectors; fertiliser 1% is separate; missing-country/value and route-benchmark rules read. Applies 1 January 2026; header includes 2026/1740 correction. No complete product/country numeric table newly read. | [2025/2621](https://publications.europa.eu/resource/cellar/c606a88b-a0ac-11f1-b25c-01aa75ed71a1.0004.02/DOC_1) |
| `cbam-carbon-border-adjustment.md:110–114,116` | 2003/87 Art 10a(1a), full schedule and neighboring allocation context: 97.5% / 95% / 90% / 77.5% / 51.5% / 39% / 26.5% / 14% for 2026–2033. Comma decimals in the law already parse correctly. These are free-allocation factors, not flat tax on gross emissions. | [2003/87](https://publications.europa.eu/resource/cellar/1c8a1afb-f104-11ee-8e14-01aa75ed71a1.0006.02/DOC_1) |

Minimum proposed change: use those direct representation URLs on the affected rows and corresponding Sources entries at baseline lines 266, 269, 272. Replacing every occurrence of each of these same three aliases in this one file would also avoid misleading metadata results on its other rows, without changing the referenced law or wording. Preserve the existing 15 November complete-review dates/scopes; record the 16 November representation/limited-clause reread honestly, rather than claiming a new full body review. Exact mapping, raw hashes and actual relevant native bodies are in the JSON artifacts.

For a short clause anchor, Art 22 says “at least 50 %”; Annex I says “the mark-up shall be 10 % for the year 2026”. Article 10a prints “97,5 % in 2026”. Full surrounding operative paragraphs were read and locally preserved in `actual-scoped-read-contexts.json`.

Tested alternative: standard `Accept: text/html` plus `Accept-Language: en` against all three alias URLs returned HTTP 404. That header change is not a supported fix. No software header change is recommended on this evidence. The already separate software repair is outside this diagnostic.

## Turkey: historical negative statement inside a rates row

`cross-border-vat-gst.md:145` correctly says 5% for 2026 and 2.5% from 2027. The whole current GIB one-page table and whole Decision 10767 explanatory note were freshly read as text and actual page images. They support the covered service categories and dual exemption condition: exemption applies unless both Turkish in-scope receipts exceed TRY 20 million and worldwide in-scope receipts exceed EUR 750 million. The note is dated 24 December 2025, refers to Gazette 33118 dated 25 December 2025, and gives the two January commencement dates. Neither current document prints 7.5%.

The stock checker cannot distinguish a rejected historical number from an operative number in the same table cell. Minimum proposed edit: replace only the first sentence in row 145 with `5% for 2026.`; preserve every following condition, future-year statement and citation exactly. Insert the complete old sentence verbatim immediately after the DST table and before the existing Kenya paragraph:

> 5% for 2026, replacing the original 7.5% row.

This is a preserved historical correction statement outside the operative rates table, not a removed rule or a numerical rewording to evade the checker. Existing GIB Sources rows 328–329 remain the same documents. Current table and explanatory note hashes and the actual two viewed pages are preserved. A later writer and independent delta reviewer must bind the relocated sentence and unchanged remaining row before publication.

## Egypt: actual visible law, unusable font extraction, narrow dated corroboration

`dtt-summary.md:92` links to Law 96/2015. The fresh PDF is byte-identical to the prior reviewed primary. PDF page 2, printed Gazette page 4, Art 1's replacement of Art 49 first paragraph visibly gives ordinary corporate annual net profit at 22.5%, with the taxable base rounded down to the nearest EGP 10. This was read from the actual rendered image, with preceding Art 46 bis (6) and following Art 56 bis context, not inferred from a nearby personal-rate bracket. The personal 22.5% bracket higher on the same page is a separate historical provision and is not the corporate authority.

`pdffonts` finds three embedded Custom Type 3 fonts, each without a Unicode map. `pdftotext` yields 7,918 characters of corrupted text. No Arabic-Indic/Eastern Arabic digits or Arabic decimal separator explain the failure; NFKC normalization does not recover literal 22.5. The visible rate's extracted glyphs are corrupted. The checker incorrectly calls the page readable because its garbled text exceeds 400 characters. No speculative OCR implementation or new dependency is proposed.

An ordinary GET to [ETA official article](https://eta.gov.eg/en/node/242) returned actual readable HTML. The article is dated **4 April 2022**, not 2026. It distinguishes a resident legal person/company from a natural person, expressly states corporate net profit at 22.5%, and discusses foreign profit and a controlled foreign-tax deduction. The short exact relevant phrase is: `بسعر نسبى 22.5%من صافي الربح`.

Minimum proposed change: retain the primary Law 96/2015 citation and all Art 49, rounding, ordinary-assessment, asset, exemption and special-sector qualifications in row 92; add this dated official ETA article solely as readable corroboration of the **22.5% resident-corporate net-profit amount**, with a Sources row explicitly naming its 4 April 2022 publication date and 16 November 2026 read date. Do not use it to establish rounding, an asset disposal/WHT/treaty rule, universal application, updated 2026 legislation, or any personal-tax bracket. Existing scenario line 217, original laws Sources row 272, and all legal holds remain unchanged. A subsequent independent source/continuity delta review is still required.

## Frozen evidence and limits

`ordinary-fetches.json` binds all ten ordinary HTTP bodies to stable URLs, final response type, bytes and SHA256; `actual-scoped-read-contexts.json` binds the newly read operative paragraph contexts to those exact body hashes and 16 November read date. `input-bindings.json` binds the exact candidate, unchanged checker, existing terminal stock log and earlier full-cohort composition report. `proposed-source-mapping.json` maps every missing CBAM row to its actual source/provision. `stock-reader-comparison.json` records actual extraction length and lexical matches. `ordinary-content-negotiation.json` retains the failed standard header experiment. `target-row-proofs.json` records every original missing figure and its unchanged-checker replay.

No fresh full twenty-file legal review is claimed. The earlier independent full pack/composition review and preserved original rules, scenarios and source holds are not replaced by this diagnostic. All candidate files remain unchanged; no accountant approval, publishing or merging occurred. Only the parent writer may prepare the minimal changes, refresh their precise destination/source bindings, obtain the independent delta review and run the complete real checks.
