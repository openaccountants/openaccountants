# Setup failures and resolution

These are captured excerpts from actual initial command outputs, before required dependencies were present. They are not unresolved validation failures.

- Initial fetch in the unrelated website checkout failed: `error: cannot open .git/FETCH_HEAD: Operation not permitted`. No website files were edited; assigned isolated clone used.
- Initial network-restricted clone failed: `fatal: unable to access https://github.com/openaccountants/openaccountants.git/: Could not resolve host: github.com`. Platform-authorized network execution created the isolated sparse clone.
- Initial HTML extraction failed: `ModuleNotFoundError: No module named bs4`. Replaced local extraction with Python standard-library HTMLParser; no package installed.
- Initial skill-check import failed: `ModuleNotFoundError: No module named openaccountants_mcp`. Populated the repository's exact unchanged mcp library.
- The exploratory validator invocation with `--help` ran the validator (that script has no help flag), reporting a missing `income-tax-workflow-base` dependency. Exact unchanged source dependencies were materialized. No validator code was edited.
- First prerequisite population attempted to parse an ordinary README as frontmatter: `frontmatter root must be a mapping, got str`. Limited parsing to frontmatter-delimited files; no source content changed.

The precommit changed-only validator log reports zero changed Guides because no content commit existed yet. It is retained only as an invocation checkpoint, not as final validation evidence. Final validation must use the actual committed diff against the main merge base.

- Initial evidence staging stopped at Git sparse-checkout guard: `paths matched paths that exist outside of your sparse-checkout definition, so will not be updated in the index`. Used targeted `git add --sparse` for the assigned evidence path; no sparse tree expansion or unrelated file staging.
