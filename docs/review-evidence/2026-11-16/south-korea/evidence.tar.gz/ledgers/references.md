# References rule and provenance ledger

Read date 2026-11-16. This is a routing/software inventory, no rates or filing deadlines. Native quotations below from the actual primary documents read. Software README metadata establishes advertised scope only; it is never tax authority. No code, rates or third-party standards redistributed.

| ID | Destination | Rule/provenance | Source section | URL | Short exact native quote | Read date |
|---|---|---|---|---|---|---|
| R01 | Method1 | Law-first classification; dates and neighboring exceptions | VAT Act53-2 heading and paragraphs | https://www.law.go.kr/LSW/lsLinkCommonInfo.do?lsJoLnkSeq=1031740015 | 시행 2026. 1. 2. | 2026-11-16 |
| R02 | Method1,3 | NTS official source navigation and simplified HomeTax route | NTS homepage banner | https://www.nts.go.kr/english/main.do | Simplified Business Operator Registration & Filing Value Added Tax | 2026-11-16 |
| R03 | Method3 | Electronic services governed by statute/decree rather than code constants | Decree96-2(3)-(7) | https://www.law.go.kr/LSW/lsLinkCommonInfo.do?lspttninfSeq=112680 | 간편사업자등록을 해야 한다 | 2026-11-16 |
| R04 | Method2 | Existing pack files and exact scope handoffs | Git main skills/south-korea inventory | https://github.com/openaccountants/openaccountants/tree/main/skills/south-korea | kr-social-insurance.md | 2026-11-16 |
| R05 | tax-ui-kr | Korean PDF year-end parsing/chat, deductions/credits/receipt visualisation | Own README 기능, API repository metadata | https://github.com/kimtoma/tax-ui-kr | 소득공제/세액공제 내역을 한눈에 파악할 수 있는 웹 앱 | 2026-11-16 |
| R06 | tax-ui-kr | No licence identified by GitHub metadata, actual reuse held | Own GitHub metadata license field | https://api.github.com/repos/kimtoma/tax-ui-kr | "license": null | 2026-11-16 |
| R07 | korean-tax-calc | README advertises2026 severance, employee insurance, annual gross-net; npm JavaScript package | Own README introduction/API | https://github.com/chapoleon/korean-tax-calc | Korean tax and salary calculator (2026 rates) | 2026-11-16 |
| R08 | korean-tax-calc | Annual simplified estimate is not monthly withholding; not self-employed method | Own README calcNetSalary | https://github.com/chapoleon/korean-tax-calc | not the monthly withholding table | 2026-11-16 |
| R09 | korean-tax-calc | README saysMIT, GitHub licence unidentified; reuse still held | README License and GitHub metadata | https://github.com/chapoleon/korean-tax-calc | MIT | 2026-11-16 |
| R10 | KoSimpleTax | Python NTS-withholding and employee insurance scope incl monthly/annual/dependants | Own Korean README | https://github.com/hyeonki-min/kosimpletax | 근로 소득 간이 세금 계산 | 2026-11-16 |
| R11 | KoSimpleTax | Metadata identifiesMIT; no blanket compatibility conclusion | GitHub repository metadata license | https://api.github.com/repos/hyeonki-min/kosimpletax | "spdx_id": "MIT" | 2026-11-16 |
| R12 | KoSimpleTax | Historical example module does not establish2026 coverage | Own README examples | https://github.com/hyeonki-min/kosimpletax | from kosimpletax.y2018 import tax_calculator | 2026-11-16 |
| R13 | Refusal/Sources | No project current-year correctness/security or rights certified; former blanket incorporation statement withdrawn | Explicit evidence limit | none | No audit or licence compatibility review performed | Not confirmed |
| R15 | Refusal | Software and Guide content licence mapping differs; no reuse compatibility certified | LICENSING Scope table | https://github.com/openaccountants/openaccountants/blob/main/LICENSING.md | Software (AGPL-3.0-only) | 2026-11-16 |
| R14 | Method3 | NPS/NHIS are navigation handoffs, not legal-content reads of landing pages | Scope limitation | none | No claim of landing-page legal read | Not a tax figure |

## Complete old-topic destination map

| Old topic | Destination | Disposition |
|---|---|---|
| Related open-source project inventory | All three named project subsections | Retained, official tax source router added |
| Blanket AGPL and compatibility claim | When to refuse or refer, Not yet confirmed | Corrected: software/content distinction; no blanket attribution-only incorporation grant |
| tax-ui-kr repository | tax-ui-kr | Same URL retained |
| tax-ui-kr unknown licence | tax-ui-kr/Not yet confirmed | Retained, current metadata read |
| Korean year-end PDF/AI chat/receipt/deduction/credit visualisation | tax-ui-kr | All topics retained, attributed advertised scope |
| tax-ui-kr integration/document structure/parsing | tax-ui-kr | Retained subject document-year review |
| korean-tax-calc repository | korean-tax-calc | Same URL retained |
| Unverified licence | korean-tax-calc/Not yet confirmed | README MIT claim distinguished from unknown metadata; actual grant not inferred |
| Korean/English2026 payroll severance/insurance/PIT/gross-net/npm | korean-tax-calc | Topics retained, employee scope and annual estimate limits corrected |
| Payroll cycle and insurance/PIT/severance integration | korean-tax-calc | Retained subject official verification |
| KoSimpleTax repository | KoSimpleTax | Same URL retained |
| MIT | KoSimpleTax | Metadata confirmed; broad direct reuse conclusion withdrawn |
| Korean/English Python NTS simplified withholding | KoSimpleTax | Python Korean documented scope retained; no localization guarantee |
| Monthly withholding/table structure and integration | KoSimpleTax | Retained, historical module caveat added |
| Directly usable schedules and logic | Refusal and KoSimpleTax | Not established; explicit year/licence/dependency checks replace overclaim |
| Original worked cases or protected credits | none originally | No values or credit lines deleted |

## Removed and why

No project or workflow topic deleted. Blanket licence compatibility and current direct usability were unsupported and are explicitly named holds. File expanded; no >25% cut. Main and targeted local recovery found no prior South Korea research ledger/review. No accountant approval claimed.
