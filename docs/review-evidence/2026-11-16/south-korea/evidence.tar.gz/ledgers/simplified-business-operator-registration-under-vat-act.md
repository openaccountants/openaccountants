# VAT registration figure and rule ledger

Read date for actual sources: 2026-11-16. Raw cache is local only. V25 is an explicit source hold, not a verified rule. Current law headings and all paragraphs of Act53-2/Decree96-2 were read; selected neighboring provisions are scoped below.

| ID | Destination | Figure/rule | Act/article | Official URL | Short exact native quote | Read date |
|---|---|---|---|---|---|---|
| V01 | Scope, liability | Foreign digital-service supplier; registered-business taxable and exempt supplies excluded | VAT Act 53-2(1) | https://www.law.go.kr/LSW/lsLinkCommonInfo.do?lsJoLnkSeq=1031740015 | 등록사업자”라 한다)의 과세사업 또는 면세사업에 대하여 용역을 공급하는 경우는 제외한다 | 2026-11-16 |
| V02 | Quick ref registration | 20 days from commencement, no turnover threshold in special rule | VAT Act 53-2(1) | https://www.law.go.kr/LSW/lsLinkCommonInfo.do?lsJoLnkSeq=1031740015 | 사업의 개시일부터 20일 이내에 | 2026-11-16 |
| V03 | Method1/Boundary | Open-market/platform supplier; receiving payment and paying seller; exceptions B2B and art53 | VAT Act 53-2(2) | https://www.law.go.kr/LSW/lsLinkCommonInfo.do?lsJoLnkSeq=1031740015 | 구매자로부터 거래대금을 수취하여 판매자에게 지급하는 자 | 2026-11-16 |
| V04 | Method2 | Digitally processed or streamed games/audio/video/e-documents/software and improvements | Decree96-2(1) | https://www.law.go.kr/LSW/lsLinkCommonInfo.do?lspttninfSeq=112680 | 저장되지 아니하고 실시간으로 사용할 수 있는 것으로서 | 2026-11-16 |
| V05 | Method2 | Advertising, cloud and prescribed intermediation | VAT Act53-2(1)(2)-(4) | https://www.law.go.kr/LSW/lsLinkCommonInfo.do?lsJoLnkSeq=1031740015 | 광고를 게재하는 용역 | 2026-11-16 |
| V06 | Method2/Boundary | Domestic intermediation categories and fee-in-other-supply exception | Decree96-2(2) | https://www.law.go.kr/LSW/lsLinkCommonInfo.do?lspttninfSeq=112680 | 중개 용역의 대가가 포함되어 법 제3조에 따른 납세의무자가 부가가치세를 신고하고 납부하는 경우는 제외한다 | 2026-11-16 |
| V07 | Method1,3 | Foreign taxpayer domestic establishment/attribution and agency context require separate classification | VAT Act52-53 | https://www.law.go.kr/LSW/lsLinkProc.do?chrClsCd=010202&joLnkStr=%EB%B2%95+%EC%A0%9C8%EC%A1%B0&lsNm=%EB%B6%80%EA%B0%80%EA%B0%80%EC%B9%98%EC%84%B8%EB%B2%95&mode=10 | 국내사업장과 관련없이 용역등을 공급하는 경우 | 2026-11-16 |
| V08 | Inputs/Method4 | Names, contacts, trading name, foreign registration, service category and Korean commencement | Decree96-2(3) | https://www.law.go.kr/LSW/lsLinkCommonInfo.do?lspttninfSeq=112680 | 사업자 및 대표자의 이름과 전화번호, 우편주소, 이메일 주소 및 웹사이트 주소 등의 연락처 | 2026-11-16 |
| V09 | Inputs/Method4 | Tax manager identity, resident/business number, address, telephone; refund account if opened | Rule66-2(1) | https://law.go.kr/LSW/lsLinkCommonInfo.do?chrClsCd=010202&lspttninfSeq=74183 | 납세관리인의 성명, 주민등록번호 또는 사업자등록번호, 주소 또는 거소 및 전화번호 | 2026-11-16 |
| V10 | Method4 | NTS assigns simplified number and notifies business incl appointed manager | Decree96-2(4) | https://www.law.go.kr/LSW/lsLinkCommonInfo.do?lspttninfSeq=112680 | 간편사업자등록번호를 부여하고 | 2026-11-16 |
| V11 | Method4 | Current NTS banner links English HomeTax simplified-business service | NTS English homepage | https://www.nts.go.kr/english/main.do | Simplified Business Operator Registration & Filing Value Added Tax | 2026-11-16 |
| V12 | Method5 | Supply time is earlier of provision or completed payment | Decree96-2(11) | https://www.law.go.kr/LSW/lsLinkCommonInfo.do?lspttninfSeq=112680 | 다음 각 호의 시기 중 빠른 때로 한다 | 2026-11-16 |
| V13 | Quick ref/Method5/Example | Base excludes VAT; VAT-inclusive unclear price uses100/110 | VAT Act29(3),(7) | https://www.law.go.kr/LSW/lsLinkProc.do?chrClsCd=010202&joLnkStr=%EB%B2%95+%EC%A0%9C8%EC%A1%B0&lsNm=%EB%B6%80%EA%B0%80%EA%B0%80%EC%B9%98%EC%84%B8%EB%B2%95&mode=10 | 110분의 100을 곱한 금액을 공급가액으로 한다 | 2026-11-16 |
| V14 | Quick ref/Method6/Example | VAT rate10% | VAT Act30 | https://www.law.go.kr/LSW/lsLinkProc.do?chrClsCd=010202&joLnkStr=%EB%B2%95+%EC%A0%9C8%EC%A1%B0&lsNm=%EB%B6%80%EA%B0%80%EA%B0%80%EC%B9%98%EC%84%B8%EB%B2%95&mode=10 | 부가가치세의 세율은 10퍼센트로 한다 | 2026-11-16 |
| V15 | Method5/Boundary | Period-end basic exchange rate permitted; NTS notifies or publishes | Decree96-2(7) | https://www.law.go.kr/LSW/lsLinkCommonInfo.do?lspttninfSeq=112680 | 기준환율을 적용하여 환가한 금액을 과세표준으로 할 수 있다 | 2026-11-16 |
| V16 | Method6/Example | Only business-related documented eligible input VAT, art39 exclusions | VAT Act38-39 | https://www.law.go.kr/LSW/lsLinkProc.do?chrClsCd=010202&joLnkStr=%EB%B2%95+%EC%A0%9C8%EC%A1%B0&lsNm=%EB%B6%80%EA%B0%80%EA%B0%80%EC%B9%98%EC%84%B8%EB%B2%95&mode=10 | 사업자가 자기의 사업을 위하여 사용하였거나 사용할 목적으로 공급받은 | 2026-11-16 |
| V17 | Quick ref/Method6 | Special regime allows only electronic-supply art38/39 input credits; no other output/payable credits | VAT Act53-2(5) | https://www.law.go.kr/LSW/lsLinkCommonInfo.do?lsJoLnkSeq=1031740015 | 제38조 및 제39조에 따라 공제되는 매입세액 외에는 | 2026-11-16 |
| V18 | Method7 | Electronic preliminary/final fields business name, simplified number, supply/input/payable | Decree96-2(5) | https://www.law.go.kr/LSW/lsLinkCommonInfo.do?lspttninfSeq=112680 | 총 공급가액, 공제받을 매입세액 및 납부할 세액 | 2026-11-16 |
| V19 | Method8 | Payment by designated foreign-exchange bank account | Decree96-2(6) | https://www.law.go.kr/LSW/lsLinkCommonInfo.do?lspttninfSeq=112680 | 외국환은행의 계좌에 납입하는 방식 | 2026-11-16 |
| V20 | Filing table | Jan-Mar/Jul-Sep prelim periods,25 days afterward, payment with filing | VAT Act48(1)-(2) | https://www.law.go.kr/LSW/lsLinkProc.do?chrClsCd=010202&joLnkStr=%EB%B2%95+%EC%A0%9C8%EC%A1%B0&lsNm=%EB%B6%80%EA%B0%80%EA%B0%80%EC%B9%98%EC%84%B8%EB%B2%95&mode=10 | 예정신고기간”이라 한다)이 끝난 후 25일 이내에 | 2026-11-16 |
| V21 | Filing table/Example | Final25 days after taxable period; exclude already reported prelim supplies | VAT Act49(1)-(2) | https://www.law.go.kr/LSW/lsLinkProc.do?chrClsCd=010202&joLnkStr=%EB%B2%95+%EC%A0%9C8%EC%A1%B0&lsNm=%EB%B6%80%EA%B0%80%EA%B0%80%EC%B9%98%EC%84%B8%EB%B2%95&mode=10 | 이미 신고한 과세표준과 납부한 납부세액 또는 환급받은 환급세액은 신고하지 아니한다 | 2026-11-16 |
| V22 | Records | Five years after final-return deadline including excluded registered-business supplies | VAT Act53-2(6) | https://www.law.go.kr/LSW/lsLinkCommonInfo.do?lsJoLnkSeq=1031740015 | 확정신고 기한이 지난 후 5년간 보관하여야 한다 | 2026-11-16 |
| V23 | Boundary | Requested transaction statement due60 days; prescribed form37-3 and electronic substitution | VAT Act53-2(7)-(8),Rule66-2(2)-(3) | https://www.law.go.kr/LSW/lsLinkCommonInfo.do?lsJoLnkSeq=1031740015 | 요구를 받은 날부터 60일 이내에 | 2026-11-16 |
| V24 | Records | Electronic records permissible; service/supply/VAT/timing/customer particulars | Decree96-2(8)-(9) | https://www.law.go.kr/LSW/lsLinkCommonInfo.do?lspttninfSeq=112680 | 정보처리장치 등의 전자적 형태로 보관할 수 있다 | 2026-11-16 |
| V25 | Sources holds | General KRW payment rule, USD option, SMBS/holiday FX, emailed account/basic location, charges and current authenticated UI are held | Not source-confirmed | none | No operative paragraph read proves these administrative specifics | not confirmed |
| V26 | Scope period | Act effective2026-01-02; Decree/Rule effective2026-04-01 | Official headings | https://www.law.go.kr/LSW/lsLinkCommonInfo.do?lspttninfSeq=112680 | 시행 2026. 4. 1. | 2026-11-16 |
| V27 | Worked case | 11m VAT-inclusive ->10m base,1m output minus50k documented input ->950k payable | Derived fromV13,V14,V16,V17 | https://www.law.go.kr/LSW/lsLinkProc.do?chrClsCd=010202&joLnkStr=%EB%B2%95+%EC%A0%9C8%EC%A1%B0&lsNm=%EB%B6%80%EA%B0%80%EA%B0%80%EC%B9%98%EC%84%B8%EB%B2%95&mode=10 | Example inputs hypothetical; arithmetic independently recomputable | 2026-11-16 |

| V28 | Filing and payment | Half-year taxable periods Jan1-Jun30 and Jul1-Dec31; final only unreported remainder under49 | VAT Act5(1) period table | https://www.law.go.kr/LSW/lsLinkProc.do?chrClsCd=010202&joLnkStr=%EB%B2%95+%EC%A0%9C8%EC%A1%B0&lsNm=%EB%B6%80%EA%B0%80%EA%B0%80%EC%B9%98%EC%84%B8%EB%B2%95&mode=10 | 1월 1일부터 6월 30일까지 | 2026-11-16 |

## Complete old-topic destination map

| Old topic | New destination | Disposition |
|---|---|---|
| Title/description, foreign registration and return | Scope and canonical method | Retained; 2026 scope explicit |
| Direct B2C supplier liability | Method1, quick reference | Retained |
| Intermediary deemed liability | Method1, boundary | Retained with statutory conditions |
| B2B taxable/exempt-business exclusion | Method3, boundary | Retained and evidence/other-rule limit explicit |
| Digital products and enhancement | Method2 | Retained |
| Online advertising | Method2 | Retained |
| Cloud computing | Method2 | Retained |
| Domestic intermediation services | Method2, boundary | Retained with neighboring fee inclusion exception |
|20-day registration deadline| Quick reference, Method4 | Retained; duplicate word days removed |
| Registration contact and representative details incl trading name | Inputs, Method4 | Retained |
| Home-country registration/address/number, types and commencement | Inputs, Method4 | Retained |
| Tax manager name and resident/tax number, telephone, email | Inputs, Method4, Sources holds | Statutory identity/address/telephone retained; email not confirmed in implementing rule and held |
| Return account/ID/password/simplified number | Method7 and Sources holds | Simplified route/number statutory confirmed; actual2026 auth labels/password flow held |
| Four quarterly period/deadline rows | Filing and payment | All retained as nominal schedule; avoid false2026 adjusted-date claim |
| Return supply/input/payable fields | Method7 | Retained |
| Foreign currency period-end basic rate | Method5 | Retained; NTS notification source replaces unproven private default |
| SMBS and preceding-business-day FX | Sources holds, Completion checklist | Not lost; named unconfirmed administrative convention |
| Only art38/39 input credits and no other offsets | Method6, quick reference | Retained with document/business-purpose conditions |
| Designated foreign exchange bank payment | Method8 | Retained |
| Emailed account/Basic Information lookup, KRW/USD and fees | Sources holds, Completion checklist | All named, not usable pending current NTS notice |
| Contributor Yeong Min Lee,16491 | Contributor | Exact original line preserved, no additional identifier occurrence in Guide |
| Original worked examples | none originally | One new hypothetical example added; no prior inputs deleted |

## Removed and why

No topic removed. Unverified administrative details moved to named Not yet confirmed holds. Duplicate heading, repeated sentence fragments and repeated word days replaced by canonical structure. File expanded; no >25% cut.

## Recovery and ownership

Read assigned original at current-main bbab4f1a6d82cace432e6ca8eda89c98ffb1c038; no matching main docs/research or docs/ledgers entries. Targeted output recovery pruned mutable/generated copies and found no prior South Korea research/evidence directory. Current open PRs and complete file lists queried before editing; no overlap for assigned four. Held income files untouched. No accountant approval claimed.
