# Crypto citation, arithmetic and warning placement delta

Base commit: `8569329b064aa706646ad3c36ee29d072031c764`. Source file: `skills/south-korea/south-korea-crypto-tax.md`.

Before SHA256: `8c34fe118cf1ba4610341538d032cc981f1dc3e7d558a21df7d0dbb7e5ed091d`. After SHA256: `a1d3180b5d54ad730d1c4c9dfa2d9900dbd3d88664824f4be347012782884fc9`.

Scope: citation corroboration and presentation only. No tax rate, threshold, legal conclusion, original case input/result or held topic changes. No scripts changed. No source refetch/full legal rereview was needed. No commit or archive created by the writer.

The original country review, canonical 61-row crypto ledger and no-loss map, 56-MISS checker log and its original exact inventory remain unchanged. This addendum explains only the delta. Source captures remain local; this file provides short native excerpts and references, not raw source redistribution.

| Delta | Existing claim IDs | Old location | Current destination and preservation | Already-read official source |
| --- | --- | --- | --- | --- |
| D1: actual article-body routes | C001-C016, C037-C041, C053-C061 as applicable | Law viewer lsInfoP links in quick/rates/deadline tables and Sources | Table citations now point to the same consolidation's already-read lsInfoR body. Sources retains stable lsInfoP and adds actual body corroboration for seven official laws/decrees. Future decree text remains labelled future; current art88 deletion/commencement qualification unchanged. | [Income Tax Act body](https://www.law.go.kr/LSW/lsInfoR.do?lsiSeq=280405&efYd=20260701&chrClsCd=010202), [Local Tax Act body](https://www.law.go.kr/LSW/lsInfoR.do?lsiSeq=282559&efYd=20260701&chrClsCd=010202), [published future Decree body](https://www.law.go.kr/LSW/lsInfoR.do?lsiSeq=280865&efYd=20260102&chrClsCd=010202); cache names and hashes in canonical ledger. |
| D2: two rejected legacy allowances | C029-C031 | Spouse table cell included rejected50m; other-relative cell included rejected20m | Current table contains only current600m/10m with all relation/10yr conditions. Immediately adjacent full warning preserves rejected spouse50m, rejects lifetime interpretation, retains600m/preceding10yr/resident scope; rejects other-relative20m and keeps10m/degrees; explains20m minor/ascendant versus50m adult rule and prior-deduction aggregation. No old topic removed. | [Act53 complete body](https://www.law.go.kr/lsLinkCommonInfo.do?chrClsCd=010202&lsJoLnkSeq=1017648003), native6억원/5천만원/2천만원/1천만원, opening10yr rule. |
| D3: computed combined22% | C005-C007 | Quick row mixed20%,2%,22%,2.5m | Quick row now only computed22%, followed by explicit20%+2% equation on the same positive annual post-deduction amount. Separate statutory table still carries2.5m/20%/2% and complete conditions/actual-body citations. Neither statutory rate is treated as a derived skip. | [Art64-3(2)](https://www.law.go.kr/LSW/lsInfoR.do?lsiSeq=280405&efYd=20260701&chrClsCd=010202), native100분의20 and250만원; [Local93(18)](https://www.law.go.kr/LSW/lsInfoR.do?lsiSeq=282559&efYd=20260701&chrClsCd=010202), native1천분의20. |
| D4: statutory table versus equivalent quick-deduction arithmetic | C053-C060 | Eight rows combined statutory bands/rates with equivalent deductions | First eight-row table retains all statutorybounds/rates and cites actual body plus actual table image. Adjacent table retains all eight equivalent deductions and spells out L×r−A equations from statutory cumulative bases. No blanket computed/derived marking on statutory rows. | [Art55 actual table](https://www.law.go.kr/LSW/flDownload.do?flSeq=123278409), already viewed local `cache/crypto-income-rate-table.gif`; [article body](https://www.law.go.kr/LSW/lsInfoR.do?lsiSeq=280405&efYd=20260701&chrClsCd=010202). |

## Arithmetic checked by writer

Combined20%+2%=22%. The eight equivalent deductions are0;1,260,000;5,760,000;15,440,000;19,940,000;25,940,000;35,940,000;65,940,000KRW. Their independent algebraic inputs/results are in `crypto-delta-arithmetic.json`. Underlying statutory cumulative amounts are0;840,000;6,240,000;15,360,000;37,060,000;94,060,000;174,060,000;384,060,000KRW. Rates/boundaries remain separately statutory evidence.

All four original oa-check blocks are byte-identical before/after; hashes are in the arithmetic JSON. `check-examples --require` again reports4blocks/0failures/0missing; output saved as `crypto-delta-examples.log`. This writer arithmetic check does not replace independent delta review.

## Independent delta review requested

Review only actual-body/source binding, warning placement/conditions, arithmetic separation and preservation. Reuse the completed full review for unchanged claims. Reviewer decision pending at writer handoff.
