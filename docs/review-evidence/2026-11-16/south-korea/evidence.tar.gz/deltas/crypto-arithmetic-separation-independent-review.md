# Independent narrow review: crypto arithmetic separation

Review date: 2026-11-16. Separate reviewer, not writer or accountant approver. **PASS for this exact arithmetic-presentation delta.** The completed144-entry pack review,61-entry crypto legal review, prior arithmetic review and HTML/image binding review are reused; no new legal research, source scan or full test run was performed.

Before commit: `10d87df3762f643c542cd7ead6a7b6653b210fdc`.
Before Guide SHA-256: `38c87a80003d16d6ccf29a705a8563177a77bb2eebd5391cb136dae143def188`.
After Guide SHA-256: `6d14f07fcdee021f649b75e936cced01bdeb3a68c5032c7231d95c520e4aeeee`.

I read the complete actual diff and writer checks, then independently compared the actual before commit and current file. The only changed section is the arithmetic paragraph/table between the statutory band table and The base. The entire preceding text, including all eight statutory band/rate rows and their existing same-edition citations, is byte-identical. Everything from The base onward is byte-identical, including operative methods/conditions, every case/input/result, Sources and held topics. No legal rule or original example was changed.

The new eight-row output table contains only computed cumulative tax A and equivalent quick deduction D, with each row explicitly marked computed. It includes no numeric statutory bound or rate. The statutory bounds/rates remain separately source-cited and are not marked computed or derived. No mixed statutory row has been relabeled to skip its legal figures. This conclusion concerns actual document content; it does not certify a new scanner run.

I independently recomputed the recurrence A(next)=A(previous)+(L(next)−L(previous))×r(previous), starting A=0 at L=0, and all eight D=L×r−A results with Decimal arithmetic. All sixteen output values match:

| Band | Computed cumulative A, KRW | Computed quick deduction D, KRW |
|---|---|---|
| First | 0 | 0 |
| Second | 840,000 | 1,260,000 |
| Third | 6,240,000 | 5,760,000 |
| Fourth | 15,360,000 | 15,440,000 |
| Fifth | 37,060,000 | 19,940,000 |
| Sixth | 94,060,000 | 25,940,000 |
| Seventh | 174,060,000 | 35,940,000 |
| Eighth | 384,060,000 | 65,940,000 |

The unchanged already-reviewed lower bounds are0/14m/50m/88m/150m/300m/500m/1bn and statutory rates6/15/24/35/38/40/42/45%. Every original quick-deduction equation remains in adjacent bullets, now with its cumulative-input recurrence shown. The top cumulative base is explicitly174,060,000+(1,000,000,000−500,000,000)×42%=384,060,000; its quick deduction is1,000,000,000×45%−384,060,000=65,940,000. These figures follow from sourced unchanged bounds/rates without relying on the missing top cumulative text in the HTML alt.

The direct official image remains explicit additional read evidence for cumulative amounts, and the known top-band alt omission remains expressly acknowledged. No complete-image/alt identity is claimed. The actual Income Tax Act URL retains lsiSeq280405/efYd20260701/chrClsCd010202. All eight original equations, values, case inputs and holds are preserved; nothing was silently removed.

Independent exact bindings and all eight recurrence/output checks are in crypto-arithmetic-separation-independent-checks.json. Original canonical legal reviews and historical scanner evidence were not edited. No unresolved defect was found in this narrow delta. Parser behavior/current automated results belong to the coordinator; no repository or checker-script edits, accountant approval, commit, push or merge were performed by this reviewer.
