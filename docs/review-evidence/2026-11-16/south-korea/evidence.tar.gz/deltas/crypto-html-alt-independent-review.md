# Independent citation-only review: crypto HTML alt binding

Review date: 2026-11-16. Separate reviewer, not writer or accountant approver. **PASS for the adjusted exact citation delta.** The completed 144-entry pack review, 61-entry crypto legal review and prior eight-equation arithmetic review are reused. No new full legal review, example recomputation, checker scan or test run was performed.

Before Guide SHA-256: `a1d3180b5d54ad730d1c4c9dfa2d9900dbd3d88664824f4be347012782884fc9`.
Final Guide SHA-256: `38c87a80003d16d6ccf29a705a8563177a77bb2eebd5391cb136dae143def188`.

## Exact scope and edition binding

I read the requested diagnostic REPORT.md and statutory-image-alt-binding.json, the entire actual citation diff and the original already-read cached article HTML, limited to image/alt/source representation. The final Guide was independently compared with the before copy by applying only the stated citation transformations. All eight statutory-band/rate rows drop their secondary direct-GIF link while retaining the same actual Income Tax Act body. All eight equation-input citations now use that same body; the eighth additionally retains the direct image as explicit cumulative-base corroboration. Direct image access remains in Sources. Link labels say statutory-table text, without claiming completeness. No other Guide bytes change.

The actual HTML route retains exactly lsiSeq280405, efYd20260701 and chrClsCd010202: the already-reviewed July2026 edition, not a current-law redirect or different consolidation. Cached HTML SHA-256 is `bebf32ba8208ff1839c553fbdedf919514802f986c192e44fb102395ad07cc08`. Its actual image element points to `/LSW/flDownload.do?flSeq=123278409`. The corresponding already-read image SHA-256 is `dc4b5dbc3860b83da1c53971893e5d9adfbba49b16da3f6b9e4f8edefc30bb0b`.

## Independent finding and precise correction

I extracted the actual image element's alt through an HTML parser: all559characters are retained, UTF-8 SHA-256 `b4a4f18337b5ca10f993f1f530d95e16aa79098ac880d28aab869ab5380d86a5`, matching the diagnostic binding. I independently viewed the actual frozen image and compared every band to its alt representation. All eight statutory bounds and marginal rates match; the first seven cumulative formulas match. **The alt is not a complete reproduction of the image:** the top-band alt omits the image's cumulative base `3억8,406만원` (KRW384,060,000), giving only the45% excess formula. Keeping all559characters does not cure that source omission.

The intermediate Guide hash `0d56a95f7d72f6307941965d5371fe04f38171fe17e2ae1118faa09ecbabf5d2` therefore could not support a claim of complete HTML/image identity or HTML-only corroboration of the eighth deduction equation. I reported this mismatch. The coordinator corrected the eighth equation citation to include the direct official image specifically for its cumulative base and removed complete-table assertions from the changed link labels. I checked that adjusted exact line and final hash. All other seven equations can use the actual HTML text; all eight statutory bands/rates remain represented there. No legal figure or arithmetic was corrected because none changed.

## Preservation and limits

Every statutory bound/rate, formula input/result, caveat and gift warning is unchanged. Everything from the next heading, The base, through the entire remainder of the Guide is byte-identical, including all methods, cases, completion fields, Sources scopes and explicit holds. Prior arithmetic and example checks therefore remain the same work; no full scan was repeated merely to bind a new hash. Original canonical reviews and historical56-MISS evidence were not edited. Machine-readable exact bindings and decisions are in crypto-html-alt-independent-checks.json.

No unresolved Guide citation defect remains in this adjusted scope. The diagnostic owner's REPORT completeness assertion must be qualified to acknowledge the top-band cumulative omission; the coordinator explicitly retains that follow-up with the root owner of the diagnostic directory. This reviewer did not edit that directory, the repository or checker scripts. This source-binding PASS does not certify parser behavior or any new automated result. No accountant approval, commit, push or merge was performed.
