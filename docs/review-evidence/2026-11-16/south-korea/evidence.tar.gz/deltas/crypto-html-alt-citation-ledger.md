# Citation-only HTML/table-text delta, 16 November 2026

Reuses all 144 original ledger entries and the prior citation/layout/arithmetic delta review. No legal rule, figure, equation, original example, case input, hold or refusal changes.

| Changed population | Before | After | Binding / reason |
|---|---|---|---|
| Eight statutory band/rate rows | Same-edition HTML plus direct GIF | Same-edition HTML | HTML already contains the official image alt; remove secondary GIF from row evidence. |
| First seven quick-deduction equation input citations | Direct GIF | `https://www.law.go.kr/LSW/lsInfoR.do?lsiSeq=280405&efYd=20260701&chrClsCd=010202` | Exact previously read Act 21221 consolidation; 559-character official alt names the bounds and marginal rates, and the first seven bands' cumulative inputs. |
| Sources image reference | Direct statutory GIF | Unchanged | Retained as secondary image reference, `flSeq=123278409`. |

Short source excerpt (original language): “종합소득 과세표준 세율 / 1,400만원 이하 과세표준의 6퍼센트”. Source read 2026-11-16. Actual article-body SHA-256: `bebf32ba8208ff1839c553fbdedf919514802f986c192e44fb102395ad07cc08`; full alt SHA-256: `b4a4f18337b5ca10f993f1f530d95e16aa79098ac880d28aab869ab5380d86a5`. The full raw HTML/image stays local. Exact retained alt, edition and the top-band omission are independently checked in the adjacent scoped review; prior legal and arithmetic conclusions are reused.

Before Guide SHA-256 `a1d3180b5d54ad730d1c4c9dfa2d9900dbd3d88664824f4be347012782884fc9`; after `38c87a80003d16d6ccf29a705a8563177a77bb2eebd5391cb136dae143def188`. Exact diff and before copy accompany this record. No new country source scan or full test suite; no checker/fetch code changed. Stock advisory figures remain red at the previously published head; current-head CI results must be reported as observed, never inferred from the proposed parser patch.

Limited review found a real omission in the official alt: the top band omits the image's `3억8,406만원 +` cumulative base (KRW384,060,000). The eighth equation therefore cites both the same-edition HTML and the actual table image; the direct image is necessary operative corroboration there. No claim of complete image/alt textual identity is made. The root-owned diagnostic's earlier completeness assertion needs correction by its owner; this lane does not edit that directory.
