# Arithmetic-output separation, 16 November 2026

No new legal source read. Reuses the144-entry pack review, original C053-C060 band/rate review and prior8quick-deduction arithmetic review. The same-edition article HTML confirms all8statutory boundaries/rates; the actual image is preserved as additional read evidence, without claiming its incomplete alt contains the final cumulative constant.

| Dependency / changed presentation | Treatment |
| --- | --- |
| Statutory8band boundaries and8marginal rates | Exact existing table/citations remain byte-identical and source-checked; no derived/computed row marker added there. |
| Cumulative tax at lower boundary A | Separately computed from completed band widths/rates, startingA=0. Each new output row contains only computedA and computedquickD, with no numeric statutory input repeated there. |
| Quick deduction D | D=L*r-A, same8originalequations and values retained explicitly in adjacent bullets. |
| Every numeric input, operative condition, worked case, hold | Preserved. Everything from The base onward byte-identical; preceding classification caveat untouched. |
| Top cumulative384,060,000 | 174,060,000+(1,000,000,000-500,000,000)*42%=384,060,000. It is an explicit arithmetic result from sourced bands, corroborated by actual image; no claim that HTMLalt contains it. |

The adjacent writer JSON supplies exact per-band inputs/results and hashes. The independent delta review checks the recurrence and no-loss proof only. Original legal review/source captures/canonical records are not repeated or rewritten. Local19structural checks pass; actual committed-diff validator and sync checks are recorded separately. No country source scan or full tests locally, no parser/fetch/extraction edit, no mixed statutory row marked derived. Public CI results are observed separately and not inferred from root's parser proposal. Keep draft while figures red.
