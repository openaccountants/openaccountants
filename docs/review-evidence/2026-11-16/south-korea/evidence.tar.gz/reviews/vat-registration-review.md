# Independent source review: South Korea foreign electronic-services VAT registration

Review date:2026-11-16. Reviewer: fresh independent Codex agent, not writer or accountant approver. Scope: skills/south-korea/simplified-business-operator-registration-under-vat-act.md only. Canonical record, preserve byte-exact.

Result: PASS for confirmed-law scope after one preservation fix. Administrative details explicitly held below are not certified.

Reviewed Guide SHA-256: `95658316fc098c7ea935ef182239db49e271d916d3b1317a5f1ae0cbff3efab0`
Original compared in full with `git show HEAD:skills/south-korea/simplified-business-operator-registration-under-vat-act.md`, base bbab4f1a6d82cace432e6ca8eda89c98ffb1c038. Complete common brief, AGENTS and skill-template read. Complete writer ledger and old-topic map read before certification.

Full inventory checked:28 entries, V01-V27 plus completeness addition V28.27 substantive legal/derived/source checks and1 hold-boundary check V25. No sampling. Each bundled row's conditions and all values were checked. Repeated figures in separate Guide locations were checked for consistency.

| ID | Entire rule/figure checked | Actual independently read source | Result |
|---|---|---|---|
| V01 | Foreign supplier and registered-business taxable/exempt exclusion | Act53-2(1) | Pass |
| V02 | 20 days from commencement and no special-rule turnover threshold | Act53-2(1) | Pass |
| V03 | Platform/deemed-supplier conditions, payment intermediaries and B2B/art53 exclusions | Act53-2(2) | Pass |
| V04 | Stored/streamed digital products, electronic documents and enhancements | Decree96-2(1) | Pass |
| V05 | Advertising/cloud/prescribed intermediation categories | Act53-2(1) | Pass |
| V06 | Domestic goods/place/service intermediation and fee-in-other-taxed-supply exception | Decree96-2(2),Act3 | Pass |
| V07 | Domestic establishment/attribution and agency context; B2B exclusion does not settle reverse charge | Act52-53 | Pass |
| V08 | All legal registration contact/trading/foreign registration/type/commencement fields | Decree96-2(3) | Pass |
| V09 | Manager name, resident or business number, address/telephone, refund account when opened | Rule66-2(1) | Pass |
| V10 | Number assignment and notice including appointed manager | Decree96-2(4) | Pass |
| V11 | NTS English banner and exact HomeTax link | NTS homepage HTML href | Pass |
| V12 | Earlier of provision and completed payment supply time | Decree96-2(11) | Pass |
| V13 | VAT-exclusive base and100/110 extraction | Act29(1),(3),(7),31 | Pass |
| V14 | 10% rate | Act30 | Pass |
| V15 | Permitted period-end exchange rate and required NTS notification/publication | Decree96-2(7),neighbor59 override | Pass |
| V16 | Business purpose, tax-invoice documentation and blocked inputs | Act38-40 | Pass |
| V17 | Special regime only allows related arts38/39 inputs, no other output/payable credits | Act53-2(5) | Pass |
| V18 | Preliminary/final electronic returns and business/simplified number/supply/input/payable fields | Decree96-2(5) | Pass |
| V19 | NTS-designated foreign-exchange bank account payment | Decree96-2(6) | Pass |
| V20 | Jan-Mar/Jul-Sep preliminary periods,25 days, payment with filing | Act48(1)-(2), image alt text in official HTML | Pass |
| V21 | Final25-day deadlines and excluding already declared preliminary supplies | Act49(1)-(2) | Pass |
| V22 | Five years after final-return deadline, including excluded B2B transactions | Act53-2(6) | Pass |
| V23 | NTS request,60 days, form37-3, discretionary electronic-record substitution | Act53-2(7)-(8),Rule66-2(2)-(3) | Pass |
| V24 | Electronic records; service/base/VAT/supply and payment timing/customer fields | Decree96-2(8)-(9) | Pass |
| V25 | Legacy admin specifics expressly held, including restored general KRW payment claim | Guide holds compared with source limitations | Pass |
| V26 | Act2026-01-02 and Decree/Rule2026-04-01 official effective headings | All three official current headings | Pass |
| V27 | Every new hypothetical example input and output | Independent Decimal recomputation plusV13,V14,V16,V17 | Pass |
| V28 | Underlying Jan-Jun/Jul-Dec taxable periods supporting final-quarter accounting | Act5(1)(2), actual official image table read visually | Pass |

Source method and scope: independently read the actual cached full VAT Act arts3,5,29-31,38-40,48-49,52-53 and complete53-2, complete Decree96-2 and Rule66-2 with neighboring66, NTS homepage text and actual banner href. Official headings and provision-level amendment annotations read for effective context. Live official decree was also opened. The current decree/rule heading is2026-04-01; substantive electronic-service paragraphs carry older amendment dates, not a newly invented April commencement. The Guide states the specific versions inspected and uses an April-June example.

Official URLs: [full Act](https://www.law.go.kr/LSW/lsLinkProc.do?chrClsCd=010202&joLnkStr=%EB%B2%95+%EC%A0%9C8%EC%A1%B0&lsNm=%EB%B6%80%EA%B0%80%EA%B0%80%EC%B9%98%EC%84%B8%EB%B2%95&mode=10), [Act53-2](https://www.law.go.kr/LSW/lsLinkCommonInfo.do?lsJoLnkSeq=1031740015), [Decree96-2](https://www.law.go.kr/LSW/lsLinkCommonInfo.do?lspttninfSeq=112680), [Rule66-2](https://law.go.kr/LSW/lsLinkCommonInfo.do?chrClsCd=010202&lspttninfSeq=74183), [NTS](https://www.nts.go.kr/english/main.do), [Act5 period image](https://www.law.go.kr/flDownload.do?flSeq=22218837). Independent actual read date2026-11-16. Source cache local only; no raw response redistributed. The full Act's5(1)(2) table is an image, not readable text; I downloaded the official GIF once and visually read Jan1-Jun30 / Jul1-Dec31. The direct48 HTML alt text supplies Jan1-Mar31 / Jul1-Sep30. This avoids treating incomplete plain-text extraction as proof.

Arithmetic: original file had no worked cases. The new filing-howto needs1 and supplies1. Independently recomputed all inputs without substitution: KRW11,000,000 VAT-inclusive receipts, KRW50,000 eligible input VAT, all-consumer direct software supplies, no relevant Korean establishment/deemed intermediary, April-June2026. Base11,000,000*100/110=10,000,000; output10,000,000*0.10=1,000,000; payable1,000,000-50,000=950,000. Both prose and oa-check match. The taxable final period is Jan-Jun with already-filed preliminary supplies excluded, as stated, not an invented standalone legal quarter.

Fixes required and checked: the old general KRW payment rule was missing from the new explicit holds despite the map claiming KRW/USD preservation. Writer restored it to Completion checklist and Not yet confirmed; independently verified the corrected actual bytes. Lost content restored:1. Also requested ledger V28 for the already correct final taxable periods after reading Act5's actual table.

Preservation: compared every original paragraph, table row, registration field and payment bullet against the new Guide and complete map. Supplier/platform/B2B distinctions, four service categories,20-day deadline, contact/representative/trading/foreign-registration/service-start data, tax-manager fields, four deadline periods, return fields, currency method, input-credit restriction and designated bank payment remain. Legacy current UI/password, manager email, SMBS, preceding-business-day FX, general KRW and overseas USD methods, emailed account/basic-info location and bank charges are named holds. Exact original contributor line preserved; this review does not validate its identifier or create accountant approval. No original case input values existed to lose. File expanded, no25% cut.

Still not confirmed: authenticated2026 HomeTax labels, account/password steps and receipt format; legacy general KRW/USD remittance specifics, SMBS/default/holiday FX, email/basic-info account lookup, manager email and bank-charge allocation; actual holiday-adjusted calendar and taxpayer-specific extensions. Guide supplies no generic penalty calculation. These limitations are explicit in Sources and are not represented as operative law. Ordinary deadline dates are correctly labelled nominal, not an adjusted2026 calendar.

No Guide edits by reviewer. No accountant approval. Automated validations and final pack integration remain separate tasks; this record certifies only the exact SHA above.
