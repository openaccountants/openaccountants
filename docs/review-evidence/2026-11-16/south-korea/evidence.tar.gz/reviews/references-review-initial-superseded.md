# Independent source review: South Korea references

Review date: 2026-11-16. Reviewer: fresh independent Codex agent, not a writer or accountant approver. Scope: skills/south-korea/references.md only. This is a canonical review record; preserve these bytes unchanged in the public-safe archive.

Result: PASS for source-routing and software-provenance scope, with explicit limitations below. This does not certify any third-party implementation or its tax calculations.

Reviewed Guide 8d0c9490482692c5217f494fe942cb4111b9a69c0c4ece60c7efe0176ccf6671-256: `8d0c9490482692c5217f494fe942cb4111b9a69c0c4ece60c7efe0176ccf6671`
Original compared: `git show HEAD:skills/south-korea/references.md`, base bbab4f1a6d82cace432e6ca8eda89c98ffb1c038. Whole original and new Guide read. AGENTS.md, complete docs/skill-template.md and common brief read before review. Writer ledger and complete old-topic destination map read before certification.

Full inventory checked: 15 entries, R01-R14 plus one completeness addition R15. 12 positive factual/provenance checks and 3 evidence/scope limitations. No sampling. All tax-figure counts here are zero because the router supplies no rate or filing deadline.

| ID | Entire rule/provenance checked | Source independently read | Result |
|---|---|---|---|
| R01 | Korean law first; operative period and nearby exceptions | Cached full VAT Act and art53-2, current headings | Pass, routing convention does not create a figure |
| R02 | Official NTS navigation and HomeTax banner | Actual cached English homepage HTML/text, including href | Pass |
| R03 | Electronic-service statute/decree versus code constants | Actual art53-2 and full Decree96-2; live official decree also opened | Pass |
| R04 | Pack slugs and workflow separation | Actual skills/south-korea files and Git tree | Pass |
| R05 | tax-ui-kr advertised Korean PDF parsing, chat, deductions, credits, annual comparison and receipts | Entire cached own README and repository metadata | Pass as attributed scope only |
| R06 | tax-ui-kr unknown licence metadata | Own repository metadata license=null | Pass, no reuse grant inferred |
| R07 | korean-tax-calc advertised2026, JS/npm, severance, employee insurance and annual gross/net | Entire own README plus own metadata language | Pass as advertised scope only |
| R08 | Annual model differs from monthly withholding; industrial accident excluded from employee deductions; not self-employed | README API and assumptions | Pass |
| R09 | README MIT versus unknown GitHub licence metadata | README License plus own metadata license=null | Pass, contradiction expressly bounded |
| R10 | KoSimpleTax Python NTS simplified withholding, employee insurance, annual/monthly and dependants | Entire own Korean README and metadata | Pass |
| R11 | KoSimpleTax MIT identification only | Own metadata MIT spdx_id | Pass, no legal-compatibility assurance |
| R12 | Historical year module does not prove2026 | README y2018 imports and both examples | Pass; README example figures are not imported into Guide |
| R13 | No current calculation, security or reuse-right audit | New text against inspected evidence scope | Pass as limitation, not confirmed tax law |
| R14 | NPS/NHIS navigation only | Exact Guide source-scope statement | Pass as limitation, no landing-page legal-content read asserted |
| R15 | Repository separates software and Guide licensing | Actual LICENSING.md, whole file, software/content mapping and third-party exceptions | Pass; writer ledger addition requested |

Source locators: [VAT Act53-2](https://www.law.go.kr/LSW/lsLinkCommonInfo.do?lsJoLnkSeq=1031740015), [Decree96-2](https://www.law.go.kr/LSW/lsLinkCommonInfo.do?lspttninfSeq=112680), [NTS](https://www.nts.go.kr/english/main.do), [tax-ui-kr](https://github.com/kimtoma/tax-ui-kr), [korean-tax-calc](https://github.com/chapoleon/korean-tax-calc), [KoSimpleTax](https://github.com/hyeonki-min/kosimpletax), [licensing mapping](https://github.com/openaccountants/openaccountants/blob/main/LICENSING.md). Read date for actual independent cached-document reads:2026-11-16. Raw captures remain local. Live Act53-2 fetch returned cache miss, but independently readable cached operative text and full Act were available; this is not a source hold on the reviewed text.

Preservation: independently compared every old paragraph and bullet with the complete destination map. All three projects, repository URLs, Korean workflows, payroll/insurance/PIT/severance topics, withholding-table structure and licence uncertainties remain. Unsafe blanket licence compatibility and immediate usability were expressly withdrawn/held, not silently omitted. No original tax worked cases or protected credit lines existed. Lost content restored:0. File expanded, so no25% reduction issue.

Examples:0 required and0 present for this routing-only shape. No source README example inputs are promoted to tax guidance. No code installed or executed.

Fixes: no Guide fix required by this review. Added ledger-completeness request R15 for the already accurate mixed-licence statement.

Still not confirmed: actual reuse rights/dependencies of tax-ui-kr and korean-tax-calc, current-year accuracy/security/completeness of all three projects and2026 withholding coverage in KoSimpleTax. These are explicit holds, not usable tax figures. No accountant approval claimed. Automated checks are separate from this source review.
