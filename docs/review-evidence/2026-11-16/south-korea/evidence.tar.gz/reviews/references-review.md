# Independent final delta review: South Korea references

Review date:2026-11-16. Fresh independent reviewer, no writing or accountant approval.

Result: PASS for exact Guide SHA-256 `d2035db583a92b9e8f340d312ea79461e3d356c577922e3ce3d4f53764f7a429`. This final record supersedes the initial record's premature PASS for R04. The initial canonical record is preserved byte-exact as `references-review-initial-superseded.md`, SHA-256 `7060016e7d8ffd43be66309bdb337fac80286094b485e5c784f1cf7d013eae80`. All unchanged primary-source checks, their complete inventory and limitations remain in that record and are reused rather than repeated.

Full checked inventory:15 entries, R01-R15. R01-R03 and R05-R15 are unchanged from the complete initial source read and review. R04 was checked again against the actual Git tree because its routing claim changed. This is a full scoped review supported by the initial full inventory plus the following substantive correction, not a new law review inferred from a hash.

R04 finding and fix: the original new draft called `kr-income-tax-reference` an existing main file, but `git ls-tree -r --name-only HEAD skills/south-korea` has no such file. Writer removed that phantom handoff. Independently read the final route: only existing `kr-income-tax` and `south-korea-vat` are named as separate jobs alongside the three assigned workflows. Those slugs exist. No underlying tax-law content changed.

R15 completeness: writer ledger now records the software/Guide licensing distinction independently read in the actual LICENSING.md. No additional licence grant or compatibility claim added.

Complete old-topic map checked as in initial record; no project, repository, workflow topic or protected credit removed. Original had no worked cases and router requires none. Lost content restored:0; incorrect added route removed:1. Source dates, project-year and licence limitations remain unchanged. No tax figures supplied or third-party calculations validated.

Still not confirmed: actual reuse rights/dependencies for tax-ui-kr and korean-tax-calc, current-year accuracy/security/completeness of all three projects, and2026 withholding-table coverage in KoSimpleTax. These remain explicit holds. No accountant approval. Automated checks remain separate.
