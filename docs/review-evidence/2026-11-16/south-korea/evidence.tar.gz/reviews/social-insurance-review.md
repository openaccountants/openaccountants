# Independent source review: South Korea social insurance

Review date:2026-11-16. Fresh separate reviewer, not writer or accountant approver. Scope: skills/south-korea/kr-social-insurance.md only. Canonical record, preserve byte-exact.

Result: PASS for the confirmed scope after two substantive corrections and one citation refinement. Guide SHA-256: `25298d6f182bd52040784552dedec07091078c774a7990c2458c5a7d8f3101ad`.

Complete original read via git show HEAD:skills/south-korea/kr-social-insurance.md at base bbab4f1a6d82cace432e6ca8eda89c98ffb1c038. Complete new Guide, writer ledger40 rows and complete old-topic map read. All40 ledger rows independently checked against actual operative authority, native text, neighboring exceptions and dates, not sampled. Repeated table/prose occurrences checked. Workflow-only bank labels/refusal/escalation fields checked separately as instructions, not legislated classifications. Writer's validations are not a substitute for these reads.

| ID | Full checked figure/rule | Actual authority paragraph read | Official source | Result |
|---|---|---|---|---|
| SI01 | Ordinary NPS 18 to under60; no automatic coverage from job label | FAQ 가입연령 도달, 취업 | [faq](https://www.nps.or.kr/pnsinfo/ntpsklg/getOHAF0097M0.do) | Pass |
| SI02 | NHIS domestic insured/dependent and exclusions | NHIS Act arts5-6 | [act](https://www.law.go.kr/LSW/lsPdfPrint.do?ancYnChk=0&bylChaChk=N&efGubun=Y&efYd=20261008&joAllCheck=Y&joEfOutPutYn=on&lsiSeq=285273&mokChaChk=N) | Pass |
| SI03 | NPS full regional share in 2026 is9.5%, workplace half not regional | FAQ 취업; premium regional rate | [faq](https://www.nps.or.kr/pnsinfo/ntpsklg/getOHAF0097M0.do) | Pass |
| SI04 | NPS discard sub1000 of monthly income | Premium amount, standard monthly income | [nps](https://www.nps.or.kr/pnsinfo/ntpsklg/getOHAF0038M0.do) | Pass |
| SI05 | Jan-Jun 2026 base400000 to6370000 | Dated 2025.7.1-2026.6.30 base table | [nps](https://www.nps.or.kr/pnsinfo/ntpsklg/getOHAF0038M0.do) | Pass |
| SI06 | Jul-Dec 2026 base410000 to6590000 continuing throughJun 2027 | Dated 2026.7.1-2027.6.30 base table | [nps](https://www.nps.or.kr/pnsinfo/ntpsklg/getOHAF0038M0.do) | Pass |
| SI07 | 2025 9%; Jan-Jun390000/6170000 and Jul-Dec400000/6370000 | Historical base table; regional rate section | [nps](https://www.nps.or.kr/pnsinfo/ntpsklg/getOHAF0038M0.do) | Pass |
| SI08 | Annual rate increments0.5pp from 2026 to13% in2033 | Regional rate section | [nps](https://www.nps.or.kr/pnsinfo/ntpsklg/getOHAF0038M0.do) | Pass |
| SI09 | 2026 NHIS income7.19%; property score211.5 | 2026 operative notice formula | [nhis](https://edi.nhis.or.kr/portal/images/popup/20251204_pop01longdesc.html) | Pass |
| SI10 | January-October 2026 LTCI exact 0.9448/7.19 ratio; 13.14% explicitly a computed approximation | 2026 operative notice LTCI formula | [nhis](https://edi.nhis.or.kr/portal/images/popup/20251204_pop01longdesc.html) | Pass |
| SI11 | LTCI relief may differ from health | LTCI Act art9(1)-(3) | [ltci](https://law.go.kr/LSW/lsLinkCommonInfo.do?chrClsCd=010202&lsJoLnkSeq=1031056547) | Pass |
| SI12 | 2025 health7.09%, point208.4, exactLTCI0.9182/7.09 | NHIS bookletp48 2025 formula | [hist](https://www.nhis.or.kr/upload/e-book/promotion/files/basic-html/page48.html) | Pass |
| SI13 | 2026 NHIS community lower20160 and upper4591740 beforeLTCI | NHIS 2026 leaflet qualification/collection section | [limits](https://www.nhis.or.kr/renewal_popup/poster/20260204_poster_longdesc_1.html) | Pass |
| SI14 | Property basic deduction100m; vehicle charge abolishedFeb 2024 | NHISMarch 2024 implementation paragraph | [vehicle](https://www.nhis.or.kr/static/alim/paper/oldpaper/202403/sub/section4_0.html) | Pass |
| SI15 | Ordinary NHIS amounts truncated below10 won | NHIS Act art107; Treasury Act47 | [act](https://www.law.go.kr/LSW/lsPdfPrint.do?ancYnChk=0&bylChaChk=N&efGubun=Y&efYd=20261008&joAllCheck=Y&joEfOutPutYn=on&lsiSeq=285273&mokChaChk=N) | Pass |
| SI16 | 10 won truncation law and delegated exception | Treasury Act47(1) | [round](https://www.law.go.kr/lsLinkCommonInfo.do?chrClsCd=010202&lsJoLnkSeq=1031453575) | Pass |
| SI17 | Qualifying own pension deduction, aggregate-income limit | Income Tax Act51-3(1),(3),p39 | [it](https://www.law.go.kr/LSW/lsPdfPrint.do?ancYnChk=0&bylChaChk=N&efGubun=Y&efYd=20260701&joAllCheck=Y&joEfOutPutYn=on&lsiSeq=280405&mokChaChk=N) | Pass |
| SI18 | Own community NHIS/LTCI business expense, not12%credit | IncomeTaxDecree55(1)(11-3),p49 | [itd](https://www.law.go.kr/LSW/lsPdfPrint.do?ancYnChk=0&bylChaChk=N&efGubun=Y&efYd=20260701&joAllCheck=Y&joEfOutPutYn=on&lsiSeq=286211&mokChaChk=N) | Pass |
| SI19 | Employee NHIS/EI/LTCI special income deduction; no double relief | IncomeTaxAct52(1),p39 | [it](https://www.law.go.kr/LSW/lsPdfPrint.do?ancYnChk=0&bylChaChk=N&efGubun=Y&efYd=20260701&joAllCheck=Y&joEfOutPutYn=on&lsiSeq=280405&mokChaChk=N) | Pass |
| SI20 | Employer, own workplace NHIS/LTCI, self-employedEI and owneraccident expense categories | IncomeTaxDecree55(1)(11)-(11-5),p49 | [itd](https://www.law.go.kr/LSW/lsPdfPrint.do?ancYnChk=0&bylChaChk=N&efGubun=Y&efYd=20260701&joAllCheck=Y&joEfOutPutYn=on&lsiSeq=286211&mokChaChk=N) | Pass |
| SI21 | Voluntary ownerEI solo or fewerthan50 workers; approval application | MOEL self-employed scheme entry/application | [ei](https://ei.work24.go.kr/ei/eim/eg/ei/eiEminsr/retrievePb0206Info.do) | Pass |
| SI22 | Seven reference-earnings grades; grade selects base, not varying rate | MOEL scheme computation | [ei](https://ei.work24.go.kr/ei/eim/eg/ei/eiEminsr/retrievePb0206Info.do) | Pass |
| SI23 | Onepaidyear within24 months, involuntaryclosure, active reemployment and restrictions | Work24 applicationqualification1)-3) | [eibenefit](https://www.work24.go.kr/cm/c/f/1100/selecSystInfo.do?systClId=SC00000258&systId=SI00000347) | Pass |
| SI24 | Voluntary owneraccident scope under300 workers; solo excludeslabourprovider | IADecree122(1)-(3) | [ia](https://law.go.kr/lsLinkCommonInfo.do?chrClsCd=010202&lspttninfSeq=75327) | Pass |
| SI25 | NPS workplace coverage replaces regional category | NPSFAQ 취업 regional-to-workplace conversion | [faq](https://www.nps.or.kr/pnsinfo/ntpsklg/getOHAF0097M0.do) | Pass |
| SI26 | NHIS non-pay income threshold20m notbusiness turnover | NHISAct71(1); Decree41(4); officialeasylaw | [side](https://www.easylaw.go.kr/CSP/CnpClsMainPreview.laf?ccfNo=4&cciNo=1&cnpClsNo=1&csmSeq=1063&popMenu=ov) | Pass |
| SI27 | No-income pension exception application and statutory exclusions distinct | NPSFAQ 가입연령도달/noincome | [faq](https://www.nps.or.kr/pnsinfo/ntpsklg/getOHAF0097M0.do) | Pass |
| SI28 | Age60loss rule; voluntarycontinuation before65 subjectexcludedgroups | NPSAct12(2),13 | [age](https://www.law.go.kr/LSW/lsLawLinkInfo.do?chrClsCd=010202&lsJoLnkSeq=1000829747) | Pass |
| SI29 | NPS finalperiod throughmonth containingdaybeforeloss | NPS premium contributionperiod | [nps](https://www.nps.or.kr/pnsinfo/ntpsklg/getOHAF0038M0.do) | Pass |
| SI30 | Report actualincome; adjustment needs decision, not inventedfloor | NPSFAQ income reporting/adjustment | [faq](https://www.nps.or.kr/pnsinfo/ntpsklg/getOHAF0097M0.do) | Pass |
| SI31 | NPS equalcoverage/reciprocity andagreementprecedence | NPS terms reciprocity/socialsecurityagreement | [treaty](https://www.nps.or.kr/pnsinfo/ntpsklg/getOHAF0110P0.do) | Pass |
| SI32 | ForeignNHIS status/residence/registration/exclusion andpreceding25th specialrule | NHISAct109(2)-(9),pp51-52 | [act](https://www.law.go.kr/LSW/lsPdfPrint.do?ancYnChk=0&bylChaChk=N&efGubun=Y&efYd=20261008&joAllCheck=Y&joEfOutPutYn=on&lsiSeq=285273&mokChaChk=N) | Pass |
| SI33 | ForeignNHIS averagefloormayoverridegeneralregionalminimum | NHISEnglishforeignguidance | [foreign](https://www.nhis.or.kr/english/wbheaa02900m01.do) | Pass |
| SI34 | Staffcanputownerinworkplacecategory | NHISAct6(2); NPSworkplaceregistrationFAQ | [act](https://www.law.go.kr/LSW/lsPdfPrint.do?ancYnChk=0&bylChaChk=N&efGubun=Y&efYd=20261008&joAllCheck=Y&joEfOutPutYn=on&lsiSeq=285273&mokChaChk=N) | Pass |
| SI35 | NHISformalobjection90 daysknowledge/180 daysdisposition, justifieddelayexception | NHISAct87(1)-(3) | [appeal](https://law.go.kr/lsLinkCommonInfo.do?chrClsCd=010202&lsJoLnkSeq=1026290197) | Pass |
| SI36 | NPSordinarydue10thnextmonth; weekend/publicholidaynextbusinessday | NPSpremiumpaymentdeadline | [nps](https://www.nps.or.kr/pnsinfo/ntpsklg/getOHAF0038M0.do) | Pass |
| SI37 | NHISordinarydue10thnextmonth; approvedquarterlyroute | NHISAct78(1)-(2) | [act](https://www.law.go.kr/LSW/lsPdfPrint.do?ancYnChk=0&bylChaChk=N&efGubun=Y&efYd=20261008&joAllCheck=Y&joEfOutPutYn=on&lsiSeq=285273&mokChaChk=N) | Pass |
| SI38 | LTCI collected with NHIS, separately itemised; NHIS collection rules apply | LTCI Act arts. 7-8 and 11 | [official PDF](https://www.law.go.kr/LSW/lsPdfPrint.do?ancYnChk=0&bylChaChk=N&efGubun=Y&efYd=20260526&joAllCheck=Y&joEfOutPutYn=on&lsiSeq=286217&mokChaChk=N) | Pass |
| SI39 | NPS contribution discards amounts below KRW 10 after the base-times-rate calculation | National Pension Act art. 117 | [operative PDF](https://www.law.go.kr/LSW/lsPdfPrint.do?ancYnChk=0&bylChaChk=N&efGubun=Y&efYd=20261020&joAllCheck=Y&joEfOutPutYn=on&lsiSeq=291347&mokChaChk=N) | Pass |
| SI40 | November-December 2026 premiums use ratio rounded at the fifth decimal place, retaining four decimal places: computed 0.1314; commencement 27 November applies to the premium for November | Act No. 21690 amended art. 9; addenda arts. 1 and 3 | [enacted amendment](https://law.go.kr/LSW/lsRvsDocListP.do?chrClsCd=010202&lsId=010436&lsRvsGubun=all) | Pass |

Actual independent source reads: NPS premium substantive sections from standard-income definition through contribution periods, dated historical2024-27 base rows and regional/workplace rate paragraphs; NPS lifecycle FAQ age/no-income exclusions, conversion, actual-income reporting/adjustment and staff-registration answers; NPS Act12-13 and117, with88/88-2 collection context; NPS reciprocity/agreement entries. NHIS2026 formula/limits entire relevant short section, actualMarch2024 property/vehicle implementation paragraph, historical2025 booklet48 formula, NHIS Act5-6,69-73,78,87,107,109 complete relevant paragraphs including foreign-payment proviso and neighboring exceptions. IncomeTax Act51-3(1)/(3),52(1) and Decree55 opening plus all11 to11-5 insurance categories. Actual rendered official MOEL entry/application/grade/approval and Work24 paidyear/24month, closure/re-employment/restrictions paragraphs; live Work24 arrears prerequisite also independently read. IA Decree122 entire scope/continuation/exclusion. NHIS foreign average-minimum warning read without adopting staleEnglish score formula. Treasury47 full rule/delegated exception read. Sources are the actual localHTML/PDF/text and renderedofficial captures, not response codes.

Additional operative research after a check failed: independently fetched/read official LTCI ActPDF286217, pp3-4 arts7-9/11, observed adjacent future art9 ratio-rounding wording and effective2026-11-27 marker, then opened/read actual enacted amendment21690 including addenda1/3 at https://law.go.kr/LSW/lsRvsDocListP.do?chrClsCd=010202&lsId=010436&lsRvsGubun=all. Addenda3 applies from the premium month containingcommencement, thereforeNovember2026, not just27November days. This is promulgated law with operative future application, not a bill. Raw captures remain local in cache/social-insurance/; only short excerpts and review metadata may be archived.

Fixes required and verified against actual final Guide:

1. The writer treated the year-long exactLTCIratio as sufficient and missed the enacted November ratio-rounding change. Corrected Jan-Oct exactratio versus Nov-Dec rounded0.1314 multiplier, commencement27Nov and wholeNovember application; added a distinguishing3m example. Source amended9 and Act21690addenda1/3. LedgerSI40 added. This is a material correction, not a wrapper update.
2. The writer unnecessarily held originaltest4's final month as unknowable without exactbirthday. Act12(2) age60loss is NEXTday (item6, not same-day exceptions3/4); premiums throughmonth containingdaybeforeloss give finalMarch2025 for the stated soleageevent. Restored concreteMarch result360000 and noApril, retaining all original inputs. SI28/SI29 and Sources updated.
3. SI38 combinedcollection source refined from art9 formula alone to LTCI8(2), with art11 collection context. Writer independently read the same actual authority; final Guide sources include it.

Independent arithmetic, every case and every original input retained:

| Case | All original/new numeric inputs | Recomputed result |
|---|---|---|
| CurrentA2026 | monthly8000000; Jan-Jun400000/6370000; Jul-Dec410000/6590000; full9.5%;6months each | bases6370000/6590000; monthly605150/626050; annual7387200 |
| CurrentB2026 | health350000; rates0.9448/7.19;10wontruncation; Novemberratio0.1314 |45990LTCI/395990combined under both periods |
| CurrentC2026 | health3000000; same rate inputs and Novemberroundedratio |Jan-Oct394210; Nov-Dec394200; difference10 |
| Original1 | age35; monthly3000000; Jul2025+ preserved as Jul-Dec2025 |270000NPS; NHIS not invented withoutincome/property |
| Original2 | age40; monthly8000000; Jul-Dec2025 |6370000base;573300NPS |
| Original3 | age25; monthly300000; Jul-Dec2025 |400000base;36000NPS; lowpositive income notautomaticexception |
| Original4 | age60, turnedMarch2025; monthly4000000; nootherstatus event/exception |lastmandatoryMarch,360000; April0 |
| Original5 | annualNPS3240000; annualcommunityNHIS/LTCI2400000 |3240000pensiondeduction subjectincome limit;2400000businessexpense; old288000creditrejected; nofixedtaxsaving invented |
| Original6 | owner3employees wantsunemploymentcoverage |3<50; eligibility/approval/closure/payment/reemployment conditions remain; ownerworkplacecategoryrechecked |
| Original7 | age45; monthly6300000; full2025; Jan-Jun390000/6170000; Jul-Dec400000/6370000;9% |monthly555300/567000; annual6733800 |
| Original8 | NHIS350000; historical2025ratio0.9182/7.09;10wontruncation |exact45327.2214... becomes45320; combined395320, correcting45325/395325 |

All sevenoa-check blocks independently checked against their inputs and prose. Decimal arithmetic independently recomputed, not merely trustingexpected values. Both2026ratio branches checked even where350000 yields same answer. Original nonarithmetic inputs/ages/dates/status flags checked too.

Preservation: every original section/topic/field and all eight original cases compared to the complete old-topic map. All refusalIDs R-KR-SI-1/2/3, bankpatterns (includingrefund/agencyambiguity/NTS/Hometax), staff/foreign/noincome/age60/July/appeal/newbusiness edges, reviewerescalationfields, ten prohibitiontopics, generalnotice/disclaimer and OpenAccountantscredit remain. Wrong vehicles formula, taxcredit, ordinary25thdue date and blanketvoluntaryowner categories were corrected with authority. Unsupported historical19780 minimum, broadreassessmentcycles, broadforeignsixmonthrule, subsidy/disability/occupation/treaty/arrears specifics are expressly held. No case simplified to satisfy checks. Lost content restored:1 (originaltest4 concretefinalmonth); newly discovered materialrule added:1 (Novemberrounding). File expanded, no25%cut.

Still not confirmed: source holds listed in Guide include fullpropertyscorebands, low-income cutoffs, occupation-specificmandatorycoverage, individualdisability/nationality/visa/treaty outcomes, subsidies, disputedarrears/latecharges, mixedstatuseventdates and category-specificassessmenttiming/documents. Coverage is explicitlylimited, not calledcomprehensive. No accountant approval. This review is scoped to exactSHA above; later changedclaims require only delta review, unchanged research/reviews are reused.
