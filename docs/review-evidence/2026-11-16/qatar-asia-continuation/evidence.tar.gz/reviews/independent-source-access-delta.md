# Independent Qatar official-source access and citation delta review

**PASS, limited scope.** Reviewed on 2026-11-16 by the crypto agent, separate from the Qatar writer and the coordinator's earlier layout review. Candidate SHA256: `513ca2489862bb73f8e499d333b7fcaf6979b4e74bed4a819b4157c0c724cff1`. Reference candidate at commit `e4564a669` has SHA256 `302a73d064fa6748a87de480efdd502a07ea8198fca2bb188e6f2a46aee30f19`.

This review covers the newly accessible primary-source binding for the existing foreign-investment percentage row, related source-read provenance and QF004–QF007 excerpts. It does not repeat or replace the prior full legal review reused from PR806 or the coordinator's completed layout/preservation/arithmetic review. No full legal-source scan is claimed. No professional approval is added.

## Exact delta checked

I independently read the actual diff and compared the complete prior and candidate Guide. Reversing exactly three changes restores the prior Guide byte for byte:

1. The source cell of the foreign-participation quick-reference row now links the Arabic Gazette PDF and same-law public API instead of only the JavaScript viewer.
2. Sources adds one actual 2026-11-16 limited-read record for arts. 1–4 and 27.
3. The provenance paragraph distinguishes the retained October reads from that additional limited November read.

Every legal paragraph, figure, condition, example input/output, other source record/read date, hold and contributor credit is unchanged. The two percentage figures 49% and 100% remain exactly as before; this is one source-cell change covering two diagnostic misses, not a new legal position. The separate decision-period row and operative paragraph citations retain their canonical viewer links.

## Actual official source and edition binding

I read the actual cached Arabic public API response, SHA256 `86c915181633d3bd2f46e2597fbafec2d361e06a28cbf6bec2e36cd38875896d`, and independently fetched its ordinary public Gazette file:

- API: https://api.moj.gov.qa/api/v1/Legislation/5181e3c0-8689-4d83-9fec-c9b560af090a?lang=2
- PDF: https://files.almeezan.gov.qa/almeezan/a92d29be-0fd0-4726-be5f-3187aedb3ef5.pdf

The API identifies UUID `5181e3c0-8689-4d83-9fec-c9b560af090a`, Law1/2019, the Arabic title regulating non-Qatari capital investment in economic activity, 27 articles and status `قيد التطبيق`. Its Gazette/file record links the exact PDF and specifies 233402 bytes, matching the independently downloaded file. PDF SHA256: `26dc1f7a12adfe35768ec4f9c5d42a75d3a929cc0712ea1d181568afa5dac3c8`. PDF metadata names the Qatari Ministry of Justice. The actual first page visually identifies the same law and title; the final page carries the Emir's signature and issuance date.

The PDF contains scanned Arabic pages, with no substantive text extracted by pdftotext. I rendered and visually read PDF pages1–4 and12, corresponding to printed pages5–8 and16: heading/preamble, complete relevant definitions, arts.2–4 and their neighboring text, and art.27/signature. Actual local images are `cache/foreign-gazette-page-01.png` through04 and12. Full raw sources and images remain local and are not public evidence attachments.

The API retains `isMachineTranslated: true` and `isCertified: false` even in the Arabic response; the default response is machine English. I did not treat those flags, a successful request or the English translation as certification of controlling Arabic. The actual Arabic Gazette independently corroborates the relevant Arabic API wording. The Guide appropriately places the Arabic Gazette first and says it controls over machine English.

## Limited substantive binding checked

| Existing rule | Actual provision and relevant conditions read | Result |
|---|---|---|
| Up to100% is conditional | Art.2: `حتى بنسبة (100%) من رأس المال` in the actual Arabic API, visually corroborated by the Arabic-numeral percentage in printedp7. The provision preserves special legislation governing non-Qatari trade/professions, art.4 exclusions and Executive Regulations | Supported; Guide does not describe automatic universal permission |
| Above49% needs approval application | Art.3: `تُقدّم طلبات الموافقة على تجاوز مساهمة غير القطريين نسبة (49%)`. Prescribed application, supporting documents and prescribed fees were read on printedp7 and match the Arabic API | Supported; no change to application conditions |
| Complete-application decision rule | The remainder of art.3 gives15days from complete documents and silence as implied rejection. I also read notification, grievance and delegated-procedure tails across printedp7–8, rather than stopping at the first numeric phrase | Existing conditional statement supported; not an end-to-end service promise |
| Excluded sectors | Art.4 on printedp8 excludes banks/insurance subject to Cabinet exception, commercial agencies and further Cabinet-excluded fields. Arabic API wording matches | Existing exclusions retained and supported |
| Definitions and publication dependency | Art.1 definitions on printedp5–6 and art.27 on printedp16 were actually read | Correct law and relevant dependency scope; no new date rule introduced |

The focused ledger QF004–QF007 now contains actual short Arabic excerpts with the November limited-read scope. I checked those entries against the response and visually corroborating Gazette provisions. Their excerpt/native-source limitation is explicit; the rest of the legal review is still the precisely reused prior review.

## Publication metadata caveat, retained

The API's top-level `publishDate` is2019-01-07, but its Gazette issue is number2 dated2019-01-24. The actual PDF final page identifies2019-01-07 as the issuance/signature date. Art.27 directs publication in the Official Gazette; API `effectiveDate` is null. Do not turn the top-level API date into a claim that publication or commencement occurred on7January. The candidate makes no such claim. This discrepancy is preserved here and in the checks JSON as a source-binding limitation; no new commencement conclusion is needed for the unchanged percentage statements.

No unresolved defect remains within this narrow delta. Required final committed-head gates remain the coordinator's responsibility. No Guide or script was edited by this reviewer, and no tests, full legal review or prior evidence archive were repeated merely because the citation changed.
