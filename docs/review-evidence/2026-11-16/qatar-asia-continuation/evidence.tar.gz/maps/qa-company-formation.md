# Complete Qatar old-topic destination map

Original: mainbbab4f1a6d82cace432e6ca8eda89c98ffb1c038. Every nonblank body line is enumerated; no original worked examples existed. New onecase is explicitly hypothetical. Protected Michael Cutajar credit unchanged. No source-backed topic removed.

| Original line | Exact old text | Destination / disposition |
|---|---|---|
| 24 | # Qatar company formation and entity choice v0.1 | Titlev0.2; versiononly |
| 26 | ## Scope and entity choice | Scope; canonicalheading changedonly |
| 28 | For a mainland LLC/WLL, [Commercial Companies Law 11/2015 (CCL), art. 228](https://almeezan.qa/legislations/66253e38-5696-4b73-84a8-e7696d9508e5) | Scope; exact line retained |
| 29 | permits one to fifty partners. A partner's liability is limited to their capital | Scope; exact line retained |
| 30 | share; the interests are not negotiable securities. Art. 230 prohibits public | Scope; exact line retained |
| 31 | subscription and negotiable shares/bonds. The LLC label therefore does not | Scope; exact line retained |
| 32 | permit public fundraising as though the entity were a listed company. | Scope; exact line retained |
| 34 | QFC, free-zone entities, public shareholding companies, branches and | Scope; exact line retained |
| 35 | representative offices have separate establishment and activity conditions. | Scope; exact line retained |
| 36 | Choose the regime from the actual activity, regulated sector, investors and | Scope; exact line retained |
| 37 | operating location before choosing a tax treatment. This Guide covers the | Scope; exact line retained |
| 38 | ordinary mainland LLC route, not a licence to operate in every sector. | Scope; exact line retained |
| 40 | ## Foreign investment approval | Method1; canonicalheading changedonly |
| 42 | [Foreign Investment Law 1/2019, arts. 2–4](https://almeezan.qa/legislations/5181e3c0-8689-4d83-9fec-c9b560af090a) permits up to 100% foreign | Method1; exact line retained |
| 43 | investment subject to that law and its approvals. A participation above 49% | Method1; exact line retained |
| 44 | requires the art. 3 application, supporting documents and fees to the competent | Method1; exact line retained |
| 45 | department. The decision period is 15 days after a complete application; silence | Method1; exact line retained |
| 46 | means rejection. This is a statutory application-decision period, not a promised | Method1; exact line retained |
| 47 | end-to-end incorporation turnaround. | Method1; exact line retained |
| 49 | Art. 4 excludes banks and insurance unless the Cabinet permits them, commercial | Method1; exact line retained |
| 50 | agencies and further sectors excluded by Cabinet decision. Do not describe | Method1; exact line retained |
| 51 | 100% foreign ownership as automatic for every activity, or apply a tax ownership | Method1; exact line retained |
| 52 | exemption merely because an investment approval was obtained. | Method1; exact line retained |
| 54 | ## Capital and documents | Method2; canonicalheading changedonly |
| 56 | Under [CCL arts. 231–235](https://almeezan.qa/legislations/66253e38-5696-4b73-84a8-e7696d9508e5), partners determine the capital. These LLC | Method2; exact line retained |
| 57 | provisions prescribe no universal QAR 200,000 minimum. Sector-specific capital | Method2; exact line retained |
| 58 | and approval conditions still require their own applicable source. All cash and | Method2; exact line retained |
| 59 | in-kind interests must be allocated and fully paid; art. 232 requires cash | Method2; exact line retained |
| 60 | contributions in an approved Qatar bank, released to managers after evidence | Method2; exact line retained |
| 61 | of commercial registration. Document in-kind contributions and their agreed | Method2; exact line retained |
| 62 | value, including the statutory liability for overvaluation. | Method2; exact line retained |
| 64 | The signed constitution identifies the legal form, name, purposes and seat; | Method2; exact line retained |
| 65 | partners and nationalities/addresses; capital and interests, including in-kind | Method2; exact line retained |
| 66 | assets; managers and any supervisory board; term; profit/loss allocation; | Method2; exact line retained |
| 67 | transfer conditions; and notices: CCL art. 231. Art. 229 requires the LLC | Method2; exact line retained |
| 68 | suffix. Maintain the partner register under art. 236 and record transfers as | Method2; exact line retained |
| 69 | required by art. 237. | Method2; exact line retained |
| 71 | ## Registration sequence and continuing records | Method3; canonicalheading changedonly |
| 73 | The manager applies for commercial registration with the constitution and | Method3; exact line retained |
| 74 | proof of full allocation/payment and delivery of in-kind interests. Amended | Method3; exact line retained |
| 75 | [CCL art. 233](https://almeezan.qa/legislations/66253e38-5696-4b73-84a8-e7696d9508e5) provides 15 days to decide a complete application and | Method3; exact line retained |
| 76 | prohibits operating before commercial registration. Sector, premises and | Method3; exact line retained |
| 77 | activity permissions must be identified for the actual business; commercial | Method3; exact line retained |
| 78 | registration alone is not evidence that every regulated activity is licensed. | Method3; exact line retained |
| 80 | Keep the commercial registration, constitution, partner register, capital proof, | Method3; exact line retained |
| 81 | manager appointment, ownership approval and actual activity/sector permissions | Method3; exact line retained |
| 82 | together. This Guide does not quote an unverified registration fee, a universal | Method3; exact line retained |
| 83 | renewal period or a two-to-five-day service promise. Obtain the current applicable | Method3; exact line retained |
| 84 | service requirement for the chosen legal form and activity before submission. | Method3; exact line retained |
| 86 | ## Tax and payroll handover | Method4; canonicalheading changedonly |
| 88 | Commercial incorporation does not complete tax registration or establish a | Method4; exact line retained |
| 89 | blanket exemption. Under [income-tax ER arts. 25 and 29](https://almeezan.qa/legislations/afee272e-4654-41c7-9e76-2b42f13c9b35), | Method4; exact line retained |
| 90 | register with GTA within 60 days of the earliest statutory trigger and file the | Method4; exact line retained |
| 91 | ordinary annual return within four months after year end. Ownership exemptions, | Method4; exact line retained |
| 92 | foreign income and evidence must be tested under the current law, not inferred | Method4; exact line retained |
| 93 | from nationality or a licence alone. | Method4; exact line retained |
| 95 | - [Corporate income tax](qa-corporate-income-tax.md): base, allowable costs, | Method4; exact line retained |
| 96 |   ownership conditions, losses, returns and audited accounts. | Method4; exact line retained |
| 97 | - [Individual business tax](qa-tax-overview.md): employment exclusion versus | Method4; exact line retained |
| 98 |   taxable independent business income. | Method4; exact line retained |
| 99 | - [Cross-border tax](qa-cross-border-tax.md): PE, foreign income, WHT and | Method4; exact line retained |
| 100 |   approved-payer treaty relief. | Method4; exact line retained |
| 101 | - [Transfer pricing](qa-transfer-pricing.md): related-party pricing and files. | Method4; exact line retained |
| 102 | - [Payroll/social insurance](qa-payroll-social.md): covered Qatari employees, | Method4; exact line retained |
| 103 |   GCC coordination, employer and employee registration. | Method4; exact line retained |
| 104 | - [VAT status](qa-vat-gst.md): current non-implementation, not a future rate. | Method4; exact line retained |
| 106 | ## Ask before choosing the route | Ask the client first; canonicalheading changedonly |
| 108 | - What exact activities, locations and regulated sectors will the company operate in? | Ask the client first; exact line retained |
| 109 | - Who are the legal/beneficial owners, their nationalities and intended percentages? | Ask the client first; exact line retained |
| 110 | - Is a mainland LLC required, or is another regime being considered for specified activities? | Ask the client first; exact line retained |
| 111 | - What cash/in-kind capital, managers, premises and activity approvals are proposed? | Ask the client first; exact line retained |
| 112 | - What employees, related-party transactions and foreign payments will begin on formation? | Ask the client first; exact line retained |
| 114 | ## Sources | Sources; exact line retained |
| 116 | &#124; Source &#124; URL &#124; Read on &#124; | Sources; exact line retained |
| 117 | &#124;---&#124;---&#124;---&#124; | Sources; exact line retained |
| 118 | &#124; Commercial Companies Law 11/2015, current arts. 228–237 including amended art. 233 &#124; https://almeezan.qa/legislations/66253e38-5696-4b73-84a8-e7696d9508e5 &#124; 2026-10-24 &#124; | Sources; exact line retained |
| 119 | &#124; Foreign Investment Law 1/2019, arts. 2–4 &#124; https://almeezan.qa/legislations/5181e3c0-8689-4d83-9fec-c9b560af090a &#124; 2026-10-24 &#124; | Sources; exact line retained |
| 120 | &#124; Current income-tax ER, arts. 25 and 29 &#124; https://almeezan.qa/legislations/afee272e-4654-41c7-9e76-2b42f13c9b35 &#124; 2026-10-24 &#124; | Sources; exact line retained |
| 122 | Not yet confirmed: no service fee, universal renewal period or full formation | Sources; exact line retained |
| 123 | turnaround is asserted. Sector-specific permissions and fees are outside this | Sourcesexplicitpermission/feeapplicationholds; currentportalholds; no blanketnarrowingclaim |
| 124 | ordinary entity-choice scope and must be sourced for the actual application. | Sourcesexplicitpermission/feeapplicationholds; currentportalholds; no blanketnarrowingclaim |
| 126 | Source-cited draft. A qualified Qatar professional must review the ownership, | Sources; exact line retained |
| 127 | activity and licensing facts before submission or acting. | Sources; exact line retained |
| 129 | > Contributed by Michael Cutajar. | Sources; exact line retained |
