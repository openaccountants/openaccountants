Whole-pack review closure for commit `978841f1153dcb0da309a185cba6b2428320457c`.

Eight 2026 Guides plus README; seven tax Guides with 14 passing executable examples. No remaining ordinary-domain gaps were established by the fresh independent review. All Guides remain tier 2 and there are zero professional attestations.

Final local publication checks:
- Changed-only validation: eight Guides, zero errors/warnings.
- Example recomputation: 14 blocks, zero failures.
- Strict sync-integrity audit: eight source Guides, zero errors/warnings/notices.
- Full repository validation: passed; existing warning groups remain (821 missing Sources, five freshness, five jurisdiction warnings).
- Only nine Qatar source files differ from main; generated trees untouched, protected platform fields and existing CTA bytes preserved.
- Exact reviewed SHA256 hashes below match the published tree after merging unrelated main changes. Commits use the required Michael Cutajar GitHub identity; no force-push.

CI for this exact head is terminal green: `cla`, `guard-derived-trees`, `validate`, `compare` and `unit-tests` all passed. [Validation workflow](https://github.com/openaccountants/openaccountants/actions/runs/40123826195), [sync-integrity and repo/MCP tests](https://github.com/openaccountants/openaccountants/actions/runs/40123826230).

The independent report follows. It records both reviewer-found corrections, the writer's checked treaty-procedure precision changes, sources read, source-access limits, arithmetic, declared exclusions and final hashes. No professional review is claimed.

---

# Qatar whole-pack independent review

Review date: 24 October 2026. Reviewer: separate Codex AI reviewer, not the writer and not a licensed-accountant attestation. Review target: `/private/tmp/oa-qatar-country-pack/skills/international/qatar`, eight Guides and README. No country file was edited by this reviewer. Read `docs/skill-template.md` and `docs/pack-readme-template.md` first. The earlier narrower review was not used as the basis of this decision.

## Decision

**PASS for an ordinary mainland, source-cited-draft pack, at the exact hashes below.** No unresolved P1/P2 legal error or remaining ordinary core-computation gap was established after the writer's corrections during review. All eight Guides remain current-year 2026 and tier 2. Removing the README `partial` entries is justified for the ordinary scope expressly stated in the README; it is not a claim to cover all Qatar tax regimes or every transaction.

## Findings and corrections checked

| Severity / status | File and current location | Finding and required correction | Primary source |
|---|---|---|---|
| P2, fixed and re-read | `qa-payroll-social.md:160–164` | The initial wording said GCC system arts. 13 and 15 applied host-state penalty and **leave** rules. Article 15 concerns employment-ending notification. Current text now correctly identifies penalties and employment-ending notification, and adds the home-law default under art. 19. Do not apply Qatar's sick-leave calculation to every GCC home scheme. | [Law 4/2007, attached system arts. 13, 15 and 19](https://almeezan.qa/legislations/3a0c705a-eb50-4db8-a7d1-0a1edd28743f), read live in Arabic |
| P2, fixed and re-read | `qa-payroll-social.md:166–170` | Initial wording stated covered GCC employees do not receive end-of-service benefits. The amendment removes the **employer's obligation**, rather than prohibiting a voluntary payment. Current text says employer is not obliged to pay. | [Law 5/2021 art. 1](https://almeezan.qa/legislations/38bdc1f3-21db-4df2-8169-f657597d41b3), read live in Arabic |
| Writer-identified during review, independently verified closed | `qa-cross-border-tax.md:334–376` | The extra treaty object/purpose qualification was removed from the recipient's main-purpose declaration; payer liability now expressly covers failed direct-benefit conditions **or** treaty misuse. Effective dates distinguish the mechanism from early-year withholding/refund and threshold operation. | [Cabinet Decision 4/2026 arts. 2–3](https://almeezan.qa/legislations/f6bfa17b-9d1d-47fc-97b3-873859357599), read live in Arabic; GTA Decision 8/2026 arts. 1–3, downloaded official PDF |

No open correction is required by this review. The two reviewer findings were narrow legal wording errors, not evidence that an entire domain remains partial.

## Review coverage and source evidence

I read every Guide and the README, checked substantive rules and legal figures against the following primary sources, and compared sibling statements. Where the 2024 English compilation conflicts with current Arabic text, the Arabic text was applied.

| Guide / topic | Checks and result | Primary evidence read on 24 October 2026 |
|---|---|---|
| Individual income tax | Employment exclusion versus taxable independent activity; residence; nationality exemptions; professional election and actual costs; craft conditions; loss and asset-disposal rules; registration, filing and penalties checked. The examples supply sufficient assumptions and do not treat wages as professional receipts. | [Current ITL](https://almeezan.qa/legislations/d444f6ad-68b1-4244-af96-6bf9ee39e065), promulgation art. 2 and arts. 1–9, 20, 24; [current ER](https://almeezan.qa/legislations/afee272e-4654-41c7-9e76-2b42f13c9b35), arts. 2, 4–20, 25–36, read live in Arabic |
| Corporate income tax | Ownership/full-period/beneficial-ownership conditions; ordinary rate; loss vintages; cash basis; hospitality/donation ceilings; loan ceiling; bad debts; depreciation; reconciliation and filing checked. Exempt-income costs are correctly disallowed. Statutory audit thresholds are accurately distinguished from the GTA operational FAQ. | Same ITL/ER; [GTA investor guide](https://www.gta.gov.qa/en/investors-guide), read live, especially accounting-office FAQ |
| Cross-border | Residence/PE tests; WHT performance/use, exclusions, gross base, accrual government-payer exception and remittance; PE attribution; specified foreign-income inclusion/exemptions; substance screening; credit cap; actual disposal/cessation; direct treaty procedure checked. No universal departure charge or blanket territorial exemption is invented. | Current Arabic ITL arts. 1–4, 11 Bis, 20, 24 and ER arts. 1–7, 21–30, 34 Bis, 36–37; [Cabinet Decision 4/2026](https://almeezan.qa/legislations/f6bfa17b-9d1d-47fc-97b3-873859357599); [Decision 8/2026](https://www.gta.gov.qa/assets/pdf/Decision%20of%20the%20President%20of%20the%20General%20Tax%20Authority%20No.%20(8)%20of.pdf) |
| Social contributions | Nationality/age/coverage, ordinary wage and housing caps, grandfather date, shares, registration/payment, multiple jobs, monthly/January data, reduced sick pay, unpaid-leave election, penalties and GCC contribution-difference allocation checked. Findings above were corrected. | [Law 1/2022](https://almeezan.qa/legislations/ff5e6696-5502-42af-b342-c2f9882cec6a), arts. 1–23, 74–81; [SR 3/2025](https://almeezan.qa/legislations/2248f9c5-1f1b-4183-af84-ab8fbaf71bae), arts. 2–28, read live in Arabic; Law 4/2007 and Law 5/2021 above; [current Daman GCC guidance](https://www.daman.gov.qa/Arabic/Pensions/InsuranceProtection/Pages/default.aspx), read live |
| Transfer pricing | Entity/PE thresholds and equality, foreign group condition, transaction-detail threshold, arm's length/functional/comparables rules, amended master/local deadline and penalty, ordinary tax penalties, CbCR threshold/report/notice/suspension and distinct sanctions checked. BAPA/rollback targets are described as guidance. | [Decision 4/2020](https://www.gta.gov.qa/assets/pdf/Resolution%20of%20President%20of%20General%20Tax%20Authority%20No.%20%284%29%20of%202020.pdf), read official PDF and local text; [Decision 10/2022](https://almeezan.qa/legislations/7e4d34ec-d133-43cf-b8fe-956a8169cf59), read live Arabic; current ER arts. 52–64; [Circular 10/2020 including Decision 16/2019](https://www.gta.gov.qa/assets/pdf/Circular%20of%20the%20GTA%20President%20No.%20%2810%29%20of%202020.pdf), read live; [Decision 7/2019](https://almeezan.qa/legislations/66ff7dfb-2ed4-4454-9861-69f2d1508104), read live Arabic; [OECD 2026 Qatar review](https://www.oecd.org/en/publications/country-by-country-reporting-compilation-of-2026-peer-review-reports_353cb719-en/full-report/qatar_b342d28e.html), current jurisdiction-confirmed implementation; [BAPA guide](https://www.gta.gov.qa/assets/pdf/GTA_BAPAM_Annex_Guide_En_20260429.pdf) and [rollback guidance](https://www.gta.gov.qa/assets/pdf/Guidance_on_Roll-Back_of_Bilateral_Advance_Pricing_Arrangements_20260329.pdf), read official PDFs |
| Both VAT siblings | Both use the same non-implementation rule, without a fictitious zero-rate/return/input-credit regime. Foreign VAT remains a separate foreign-law question. No contradictory sibling rate or commencement was found. | [GTA investor guide, VAT statement](https://www.gta.gov.qa/en/investors-guide), read live |
| Formation | LLC partner range/liability, capital and payment, constitutional documents, register/transfers, amended application period, foreign-ownership approval and exclusions checked. Registration is not presented as tax clearance. | [CCL 11/2015 arts. 228–237](https://almeezan.qa/legislations/66253e38-5696-4b73-84a8-e7696d9508e5) and [Foreign Investment Law 1/2019 arts. 2–4](https://almeezan.qa/legislations/5181e3c0-8689-4d83-9fec-c9b560af090a), read live in Arabic |

Source access notes: Al Meezan failed in the web text tool but the UUID pages loaded and their rendered Arabic legislation was read in the normal in-app browser. GTA Decision 8/2026 and the Arabic compilation could not be independently refreshed through the web extractor in this pass; the supplied official downloaded PDF/text and page image were read. The obsolete `gcc-insurance-qatar.pdf` redirect was not used as evidence. The Arabic compilation printed page 36 visibly confirms ER art. 37(5)'s 30-day notification and equal extension; the current register omission does not repeal it. Current Arabic ER art. 37 and the original/compilation context were cross-checked. No secondary professional tax summary was used as authority. OECD's current peer-review text is used only as direct published evidence of Qatar's confirmed implementation, read with domestic commencement law and GTA circular.

## Executable examples and structure

Final explicit-path run: `checked 7 files, 14 oa-check blocks, 0 failures, 0 missing`.

| File | Independently recomputed outputs |
|---|---|
| `qa-tax-overview.md` | Actual costs: net 180,000; loss 30,000; base 150,000; tax 15,000. Election: costs 120,000; base 280,000; tax 28,000. |
| `qa-corporate-income-tax.md` | Reconciliation: adjusted 650,000; loss 100,000; base 550,000; tax 55,000. Mixed ownership: permitted loan 3,000,000; interest 150,000; addback 50,000; adjusted 1,050,000; taxable share 630,000; tax 63,000. |
| `qa-payroll-social.md` | Housing cap: base 31,000; employee 2,170; employer 4,340; total 6,510. Sick pay: employee 1,050; transferred share 1,050; employer 5,250; total 6,300. |
| `qa-cross-border-tax.md` | Gross consultancy: WHT 5,000; recipient 95,000. Royalty/PE credit: base 800,000; tax 80,000; eligible foreign tax 95,000; credit 80,000; payable 0; excess 15,000. |
| `qa-transfer-pricing.md` | Underbilling: revenue 1,050,000; adjustment 50,000; tax 5,000. Asset threshold/excess charge: headrooms 40,000,000 and 0; adjustment 150,000; tax 15,000. |
| Both VAT Guides | Each: invoice 50,000; foreign-invoice cash 10,500; foreign-tax item for review 500. Assumed amounts are not represented as statutory foreign rates. |

Calendar cross-check: 30 April 2027 plus 60 days is 29 June 2027. November WHT is due before 16 December 2026; November social contributions by 5 December 2026. CbCR parent notification/report dates match the year-end/12-month rules.

Focused `check_guides` validation explicitly included all eight current working-tree Guides: **0 errors, 0 warnings**. The first import attempt lacked `scripts` on Python's module path and failed before validation; the corrected invocation succeeded. No reliance was placed on `--changed-only`. All seven tax files have the nine required deep-tax sections and exactly two examples; company formation is the non-tax entity-choice Guide. This review did not re-run repository-wide/index publication checks.

## README completeness decision

IT-IND now supplies both actual-expense and professional-election computation, exemptions, losses and filing. IT-CORP supplies a practical reconciliation and ownership allocation. SC covers ordinary Qatari employees plus GCC coordination rather than incorrectly excluding GCC workers. TP includes mandatory CbCR and positive current suspension evidence. XB includes foreign-income/credit, PE attribution, actual disposals/cessation and current treaty-relief procedure. VAT non-application and employment-payroll exclusion are backed by express primary authority. Therefore the listed ordinary domains do not require `partial` solely because specialist calculations are excluded.

The expressly named exclusions remain real scope limits: QFC/free zones, petroleum/government agreements, detailed Pillar Two, regulated banking/insurance calculations, voluntary self-employed income-slice enrolment, benefit/pension computation, excise/customs, particular reorganisations, voluntary surrogate CbCR and treaty-rate tables. They are specialist/niche regimes or separate domains under the template. A reader must not market this as every Qatar regime covered. No ordinary taxpayer group or core calculation was found hidden behind those exclusions. Home-state GCC rates/base require the actual home-country authority's law/assessment; inventing one Qatar/GCC-wide rate would be wrong.

The statutory ER art. 33 versus GTA FAQ audit-threshold conflict remains a disclosed source conflict, not an arithmetic or completeness gap. The text applies the statute and requires evidence for a different submission treatment. This review does not independently resolve any taxpayer-specific portal concession.

## Exact reviewed SHA256 hashes

These identify the final reviewed bytes, including the fixes. Any subsequent substantive edit needs a corresponding review update.

```text
8b1ee4ba9956a11371e16938b366a99a68574931caa8060ca644cc94964a67c7  README.md
af160efa48b2d91efb0766a446605461a68ff25d3173d8721580f74d7fa901e5  qa-company-formation.md
bac2f05ddb25687391f18fd86c47ce7c1fdf92683a2d7df0b78e5fc30892d05e  qa-corporate-income-tax.md
5ce9a6080e32f43b46e117087fa1a4df49b6f5e0ec73005a25aa18231de0668b  qa-cross-border-tax.md
3f1ee8a08cdadfdd3991bd89c2c76c4645f7caa69a29fc2f62af70eeeb2f3754  qa-payroll-social.md
a951d349160199b9e4b4a6d3b576511995ac5aa85b803194bb9c669c2ac65680  qa-tax-overview.md
ca1549e21965c542f4a85f46b0af7c9745dba7b9de0da0438e584a2675f035f5  qa-transfer-pricing.md
17e2a39e880120afbe46dd05e5cbc383a2eb5c9a2d64a787cff43fc3a4d3d46c  qa-vat-gst.md
d11be0cd6a25f52dffbc014f98a819db6940f8a6e74b3f3db77a8ca7d10fb53b  qatar-tax.md
```

