# Tanzania exact recovery, 16 November 2026

Ready for a separate independent continuity decision. This is recovery of an existing source-reviewed candidate, not a fresh legal review or accountant approval. No PR, push, merge, release, live-site or database action was performed by this writer.

## Frozen candidate

- Worktree: `/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-resume-2026-11-16/wt-tanzania`
- Branch: `world/codex-tanzania-2026-11-16`
- New local commit: `7c8b9c17b29e60cdadd91479d6dafcd0e43ef8e8`
- Parent/main: `2844c309238b4fdb63be0a3d0ad9ae99a8ea89c8`
- Recovered prior head: `67c03fe8237c6a7de66cf43d59e1adfb94884646`, old branch `codex/world-tanzania-2026`.
- Prior review base: `973f780840b73585aa0b43e979c9d78b03e7e2c6`.
- Exactly the five assigned Tanzania skills and the independently reviewed honest partial-coverage README. All six candidate files are BYTE IDENTICAL to the prior reviewed head. Every one of the ten current-main original Tanzania files is BYTE IDENTICAL to the old review base/original population. The approved income file and three passing sibling files are unchanged.
- Michael Cutajar <107185374+michaelcutajar1995@users.noreply.github.com> is the sole commit author. No AI trailers.

No tax guidance, source URL, date, version, case, input, name, approval field, historical credit, calculator quote or held boundary was changed during recovery. Original November 15 source/read/review dates remain honest. Existing candidate versions are above current main. November 16 is the continuity report date, not a newly invented source-read date.

## Complete preserved evidence

Original packet: `/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-7/tanzania/`.

Its 444 artifacts, including all writer source bodies, ledgers, no-loss maps, initial HOLD, correction HOLD, final scoped PASS, independent source bodies, source scopes, rendered-image evidence and test logs, are bound in `preserved-packet-files.json`. The entire packet is archived in `preserved-tanzania-packet.tar.gz`, SHA256 `3ffc132fb196ba800d8a2b27901ee356ca673a94b1a0106b10502231060a3fac`. Neither old worktree nor old evidence has been edited. Exact current original/candidate bytes are also saved locally.

Final independent source review: `review-tanzania-pack-final-67c03fe82.md` in that packet, SHA256 `1c28cc7ec930ff1a56be1fc437b76a82e89ddb0f02fc6c863031d6a82588381a`. Full final matrices/review bindings are copied unchanged into `preserved-final-review/`; all five source ledgers and rule-data files are copied unchanged into `ledgers/`.

`continuity-audit.json` checks EVERY final report hash, candidate/ledger/rule-data hash, all 28 independent official source bodies, every row/block identifier, every recorded original physical-block text at its exact original line, and all 444 preserved artifacts. No mismatches. Populations are 243 rule groups, 1,099 old physical body blocks, 1,407 total original nonblank lines, and 100 arithmetic OUTPUT checks. These are not 243 freshly reread statutes or 100 distinct cases. `all-original-nonblank-lines.json` explicitly includes protected metadata and structural headings/separators/code fences beyond the old substantive-block population. That extra structural map does not create new legal approval.

The full original country was read before recovery. All final current-row claims, source/read scopes, initial correction findings and residual closures were inspected. Prior source-review evidence and all no-loss destinations remain bound to identical candidate bytes; this writer does not represent continuity checking as a new independent source/no-loss review. Root must obtain separate continuity acceptance before publishing.

Fresh ordinary official TRAB captures of the Income Tax Act, Tax Administration Act, Finance Act 2025 and VAT Act are each byte-identical to the corresponding independently reviewed November 15 source bodies. See `fresh-official-body-continuity.json`. Downloading these is not a claim of a fresh whole-Act reread. Ordinary TRA transport failures are retained in `sources/*.json`; none were counted as reads. No Firecrawl, private source, login, challenge bypass, paid API or model was used.

## Previous defects remain corrected

- Resident PAYE uses proved approved-retirement relief, with the statutory/agency conditions, not gross salary. Retained gross 400,000 now gives PAYE 7,200/net 352,800; gross 700,000 gives 42,000/net 588,000; gross 1,500,000 gives 233,000/net 1,117,000. Raw case inputs are unchanged. Nonresident gross 15% remains a distinct rule.
- Current WCF 0.5% replaces old private 0.6%, employer-only, with the separate basic-plus-fixed base and verified scope. The old 50 million payroll WCF 300,000 becomes 250,000. Unrecovered late-charge mechanics and variable-pay scope remain held.
- Deemed distribution changes 30% to 15% from July 2026, retaining Commissioner determination, 12-month test, exceptions, actual dividend rate and no automatic board-resolution escape. The 800 million hypothetical now yields 12 million only under the stated applicable 10% rate; the old 24 million is historical.
- Four car rows each retain annual agency attribution, statutory less-than/more-than-five-year distinction, exact-five-year HOLD and the no-employer-deduction-or-relief gate.
- Conditional loss floor, charity scope, royalty renumbering, VAT withholding net-value basis and deadline, imported-service entitlement gate, deferment amendment and penalty sources remain as corrected in the existing independent review.

The initial full HOLD and correction HOLD have NOT been overwritten with a PASS. The old final scoped PASS closes their identified defects at the exact current bytes. `final-readiness-and-checker-precision-addendum.md` explicitly corrects a previous speculative parser-cause diagnosis: the 200m/100m VAT amounts are supported by actual agency text, while the exact cause of the old stock checker misses was not established. Do not repeat the abandoned concatenated-URL explanation.

## Scope stays partial

All seven country jobs are honestly partial in the reviewed README. Exact five-year car benefit, health-insurance implementation/current premium, live form details, nonmonthly/terminal allocations, Zanzibar levies, 16% eligible-person notice, simplified digital procedure, actual treaty effective periods, zones and exact exemption/HS/application chains remain held where stated. No unsupported value becomes an operative default. The approved 2025 income file and stale currency-point statements in passing siblings are separately identified follow-ups, not silently repaired or reapproved here. Historical Baraka Cassian attribution remains history, not approval of the rewrite.

## Current validation

Current-main code was used on the recovered committed diff:

- Five `skill_checks` results: `{}` for every file.
- `validate-guides.py --changed-only --no-index-check --base origin/main`: exit 0, zero warnings, actual six-path committed diff.
- `check-examples.py --require` all five files: 12 blocks, zero failures or missing.
- `check-sync-integrity.py --base origin/main --head HEAD --mode audit --strict-metadata`: zero errors/warnings/notices.
- Changed calculator-quote check: preserved.
- All 100 retained Decimal output expressions independently recomputed using a restricted AST evaluator: pass. `cases-rerun-nov16.json`.
- Current unchanged stock row-source run: exit 1; 144 parsed table rows, 2 repeated PSSSF 1.5% textual-format MISS occurrences and 63 UNREADABLE rows. Both PSSSF section 19 clauses were directly reread with neighbors: each says one and a half percentum. Every occurrence is rebound to its prior rule/source evidence in `row-source-result.json`; 61 ordinary TRA transport failures and 2 scan-only HESLB rows are not fresh reads. See `row-sources-nov16.log`. No exit 1 is relabelled as passing. The earlier exact-head result was 9 MISS and 2 scanned UNREADABLE, each with an individual independent actual-body/visual/held-context disposition; preserved with the precision addendum.
- Earlier exact candidate evidence: 494 unit tests and 61 MCP tests passed. They were NOT rerun on this new recovery commit and are not represented as fresh runs. The content/case bytes are identical; remote CI has not run.

## Ownership and old hold

Fresh `origin/main`, all open PRs and every changed-file list were read before edits. No Tanzania overlap, including Ryan #1336. `start-ownership.json` retains the full snapshot. Issue #1989 assigns Codex. Cambodia #2054, the old readiness hold, actually merged on 15 November at 19:29:33Z; its state was freshly read. It is not a Tanzania ownership overlap. Root coordinates current release/merge policy; no historic report is rewritten to imply newer permission.

Next: separate independent continuity acceptance, fresh final ownership/active-ingest check by root, then one Tanzania PR using these exact six path bytes. Do not import other country changes from the old branch or edit the protected siblings.
