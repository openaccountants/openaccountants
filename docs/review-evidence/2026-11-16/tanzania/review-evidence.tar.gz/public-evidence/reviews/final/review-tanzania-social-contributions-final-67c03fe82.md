# Final independent source review: tanzania-social-contributions

**PASS for proposed published guidance at exact bound bytes. No accountant attestation or publication authorization.**

HEAD `67c03fe8237c6a7de66cf43d59e1adfb94884646`, base `973f780840b73585aa0b43e979c9d78b03e7e2c6`; reviewer2026-11-15. Draft SHA256 `b7c8346ae8edf83d18e1d6c5d2b93be6ac00394b30e9206d2bbbb50e6651052e`; ledger SHA256 `9cccbdd3819c8db8fb8aea7c04495e900222d73029d714f51e522a1640ddbbc5`; rule-data SHA256 `64d76ca17ef0afe459106a22e2675598f727263868cfbc8df8557ce8c6d3126d`.

Full cumulative coverage: all37rows PASS; all262actual original physical blocks preserved/corrected/held/routed; all18Decimal output checks PASS. This incorporates complete first-pass reading and complete a5ac213fd correction review. Final sweep covered every one of the6changed rows and linked source conditions; other bytes verified unchanged. This is a full cumulative review, not a fresh complete reread claim and not sample approval.

Both remaining findings are resolved. Each car row now repeats TRA attribution, annual basis, exact5-year HOLD and ITA7(3)(e) no-deduction-or-relief exclusion. Both derived currency minima rows now link TAA89 alongside FA2024s97. Own sources27/03/12/13 reread for closure; same previously independently retrieved official bytes and hashes, not new downloads.

Full actual source scopes/URLs/hashes: `/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-7/tanzania/review/correction-a5ac213fd/independent-source-read-record.json`. ScannedHESLB visually read; actual GN809timingreg23 clarification preserved. Every source claim outside usable guidance passes only as an honest held boundary.

## All current ledger rows

|Row|Verdict|Claim|Article|Actual official support|
|---|---|---|---|---|
|R1|PASS|Rates, bands and thresholds: NSSF covered Mainland employee: 20% of statutory wages total; employee at most 10%, employer balance. Documented 10/10, employee 5/employer 15, or employer 20/employee 0 arrangements. No automatic exemption just because the employee is foreign.|Rates of Contributions;NSSF ss6,12-13|https://www.nssf.go.tz/pages/payment-of-contributions (Rates of Contributions;NSSF ss6,12-13)|
|R2|PASS|Rates, bands and thresholds: NSSF wages and coverage: s 3 contractual money wages include living allowance and pay in lieu of notice. ss 6-7 cover Mainland private, self-employed, foreign/international categories and Board-approved religious ministers. Employee scheme computation does not establish a self-employed contribution arrangement.|ss3,6-7|https://www.nssf.go.tz/uploads/publications/en-1771921274-NSSF%20ACT%20CAP%2050%20RE.%202023.pdf (ss3,6-7)|
|R3|PASS|Rates, bands and thresholds: PSSSF default: 20% of s 3 salary: employee 5%/employer 15% (in words on the page). s 3 excludes bonus, commission, cost-of-living allowance, overtime, directors fees and other additional emoluments. This is not the PAYE gross base.|ss3,18|https://elibrary.osg.go.tz/bitstreams/cf923cdc-b36a-4a5b-88f8-21818597c3a2/download (ss3,18)|
|R4|PASS|Rates, bands and thresholds: PSSSF higher contributions/coverage: Actual higher employee/employer contributions allowed; employee contribution at most 50% of total (in words on the page). Applies to Mainland public service/former schemes/specified corporations, including government ownership at least 30% or designation. Do not select a fund from a bank description.|ss2-5,18(6)|https://elibrary.osg.go.tz/bitstreams/cf923cdc-b36a-4a5b-88f8-21818597c3a2/download (ss2-5,18(6))|
|R5|PASS|Rates, bands and thresholds: SDL: 3.5% employer-only on total monthly cash emoluments for at least 10 employees, unless s 19 exemption. Includes permanent, part-time, secondary and casual staff; irregular periods allocated monthly.|Chargeability,Who is liable,Applicable rates|https://www.tra.go.tz/page/skills-development-levy-sdl (Chargeability,Who is liable,Applicable rates)|
|R6|PASS|Rates, bands and thresholds: WCF: 0.5% employer-only for formal Mainland private and public sectors; agency base basic salary plus fixed allowances. Private 0.6% is historical, replaced from 1July 2022 by GN478F. Variable-pay inclusions beyond this guidance remain unconfirmed.|UCHANGIAJI(a)-(f)and rate/base FAQ;GN478F|https://www.wcf.go.tz/pages/contribution (UCHANGIAJI(a)-(f)and rate/base FAQ;GN478F); https://www.wcf.go.tz/uploads/documents/sw-1666602227-sw1658489842-GN%20No.%20478F%20Tariff%20Regulation.pdf (regs1-2 replacing0.6with0.5effective1July2022)|
|R7|PASS|Rates, bands and thresholds: HESLB covered borrower: After Board confirmation/billing, deduct at least 15% of basic salary, wages or remuneration as applicable, monthly (minimum and bases in words on the scanned law page). Agency guidance uses billed 15% of basic salary. Do not apply 15% to all staff or to total outstanding loan balance.|Amendment s19; substituted principal s20(1)(b)|https://www.heslb.go.tz/images/storage/downloads/1761132137_heslb-act-amendment-2016.pdf (Amendment s19; substituted principal s20(1)(b))|
|R8|PASS|Rates, bands and thresholds: HESLB employer reporting/remittance: Notify Board of employed degree/diploma graduates within 28 days from employment; upon confirmed beneficiary status deduct under principal 20(1)(b), report beneficiary status/rank and name/address/occupation/salary changes under 20(1)(d), and remit within 15 days after month-end under 20(2). Numbers in words on the scanned law; agency before-15th guidance does not override statutory within-15-days.|Amendment s19; substituted principal s20(1)(a),(b),(d),(2)|https://www.heslb.go.tz/images/storage/downloads/1761132137_heslb-act-amendment-2016.pdf (Amendment s19; substituted principal s20(1)(a),(b),(d),(2))|
|R9|PASS|Rates, bands and thresholds: HESLB priority and arrears: Statutory loan deduction has priority over nonstatutory salary deductions. Replacement s 21 imposes 10% of amount due for repayment for each month not remitted (in words on law page), not 10% of the entire loan by default; obtain Board schedule.|Amendment s19; substituted principal ss20-21|https://www.heslb.go.tz/images/storage/downloads/1761132137_heslb-act-amendment-2016.pdf (Amendment s19; substituted principal ss20-21)|
|R10|PASS|Rates, bands and thresholds: Resident PAYE: Monthly taxable income after eligible approved-retirement relief: up to 270,000 nil; over 270,000-520,000 8% excess; over 520,000-760,000 20,000+20% excess; over 760,000-1,000,000 68,000+25% excess; above 1,000,000 128,000+30% excess. All TZS.|Mainland/Zanzibar monthly tables|https://www.tra.go.tz/page/income-tax-for-individuals (Mainland/Zanzibar monthly tables)|
|R11|PASS|Rates, bands and thresholds: Approved pension relief: Lower of actual eligible contribution and statutory fund amount. Employer contribution only where included in employment income. Do not reduce taxable pay twice, or treat voluntary/health/loan deductions as automatically eligible pension relief.|How contributions made to approved retirement funds are treated|https://www.tra.go.tz/page/pay-as-you-earn (How contributions made to approved retirement funds are treated)|
|R12|PASS|Rates, bands and thresholds: Nonresident employee PAYE: 15% gross Tanzania-source employment pay, final for that employment. Pension coverage is separate; foreign citizenship alone is not an NSSF exemption.|Nonresident employees|https://www.tra.go.tz/page/pay-as-you-earn (Nonresident employees)|
|R13|PASS|Rates, bands and thresholds: Combined on-cost illustration: 14% (derived:10% NSSF+3.5% SDL+0.5% WCF) only for proved SDL liability, employee 10/employer 10 split and identical bases. Below 10 staff, no SDL, that illustration becomes 10.5%. Not a universal employer-cost percentage.|Rates of Contributions;VETA14;WCF guidance|https://www.nssf.go.tz/pages/payment-of-contributions (Rates of Contributions;VETA14;WCF guidance); https://elibrary.osg.go.tz/bitstreams/46a41d49-ae99-478c-8188-310fdc970d1b/download (VETA14); https://www.wcf.go.tz/pages/contribution (Current WCF rate/base)|
|R14|PASS|Rates, bands and thresholds: Private-sector wages: GN605A/2025 from 1 January 2026: choose actual category and pay-period rate. Full monthly table is in payroll and complete rates in official Second Schedule. Other-sector TZS 175,000 and other-domestic TZS 80,000 are specific monthly categories, not universal floors; the old claimed average is unconfirmed under Sources.|paras1-7 and Schedules1-2|https://www.kazi.go.tz/uploads/documents/en-1760702541-GN%20605A-THE%20LABOUR%20INSTITUTIONS%20%28MINIMUM%20WAGE%20FOR%20PRIVATE%20SECTOR%29%20ORDER%2C%202025%20%285%29.pdf (paras1-7 and Schedules1-2)|
|R15|PASS|The method, step by step / deadlines: NSSF registration: Employer within 1 month after becoming a contributing employer; covered employees without delay (number in words on page). Keep old membership, avoid duplicate registration and allocate each contribution to the member.|s11|https://www.nssf.go.tz/uploads/publications/en-1771921274-NSSF%20ACT%20CAP%2050%20RE.%202023.pdf (s11)|
|R16|PASS|The method, step by step / deadlines: NSSF payment and support: Within 1 month after contribution month-end. Send complete NSSF/CON.05 to relevant office immediately after GePG payment; retain bank/control number and member earnings schedule. A consolidated multi-region payer needs branch allocation.|Payment/support and location paragraphs;Act14|https://www.nssf.go.tz/pages/payment-of-contributions (Payment/support and location paragraphs;Act14)|
|R17|PASS|The method, step by step / deadlines: Employee recovery of missed NSSF: s 13 permits current deduction or recovery within 6 months, by at least 4 approximately equal instalments unless employee agrees fewer or lump sum (numbers in words on page). Do not deduct employer share from wages or sweep arrears without checking conditions.|s13|https://www.nssf.go.tz/uploads/publications/en-1771921274-NSSF%20ACT%20CAP%2050%20RE.%202023.pdf (s13)|
|R18|PASS|The method, step by step / deadlines: NSSF penalty: 5% unpaid contribution per month or part (in words on page); do not presume compound-on-penalty computation. Board remission and exact principal/period allocation require actual decision/statement.|Penalties;Act14|https://www.nssf.go.tz/pages/payment-of-contributions (Penalties;Act14)|
|R19|PASS|The method, step by step / deadlines: PSSSF timing and surcharge: s 18 deems remitted on last day of month salary paid. s 19 initial 1.5% unremitted contribution; after 30 days, additional 1.5% of aggregate remaining unpaid per month or part (all in words on page). Waiver requires Board with Minister approval; do not substitute NSSF 5% penalty.|ss18-20|https://elibrary.osg.go.tz/bitstreams/cf923cdc-b36a-4a5b-88f8-21818597c3a2/download (ss18-20)|
|R20|PASS|The method, step by step / deadlines: PAYE / SDL: TRA 7th following month; SDL ITX300.01.E credit slip and monthly return through IDRAS; half-year certificate must tally monthly returns per agency guidance. Exact live half-year form/deadline is held. PAYE certificate/return details in payroll.|Employer obligation|https://www.tra.go.tz/page/skills-development-levy-sdl (Employer obligation)|
|R21|PASS|The method, step by step / deadlines: WCF payment: Within contribution month or following month. Agency FAQ permits 3-month,6-month or annual only with actual DG consent; obtain it. Portal/control number does not replace salary-base/member schedule.|UCHANGIAJI;frequency FAQ|https://www.wcf.go.tz/pages/contribution (UCHANGIAJI;frequency FAQ)|
|R22|PASS|The method, step by step / deadlines: TRA s 89 penalty: For failure to file return or pay tax on due date, per month/part, higher of 2.5% (in words on the page) tax assessable less paid at period start or 5 currency points individual/15 corporate. Separate provisional/final return failures.|s89|https://www.tra.go.tz/images/uploads/acts/Tax_Administration_Act.pdf (s89)|
|R23|PASS|The method, step by step / deadlines: Currency point / interest: Current point TZS 20,000 under FA 2024 s 97, so minima TZS 100,000 individual/TZS 300,000 corporate (derived). s 87 late-payment interest compounds monthly at prevailing BoT discount; no fixed/current percentage supplied.|s97;TAAdefinition/s87|https://www.tra.go.tz/images/uploads/acts/Finance_Act_2024_%281%29.pdf (s97;TAAdefinition/s87); https://www.tra.go.tz/images/uploads/acts/Tax_Administration_Act.pdf (Statutory rate definition and s87)|
|R24|PASS|The method, step by step / deadlines: WCF late amount: Current agency guidance says 2% of delayed amount. Principal 2016 reg 13/2017 tariff not recovered for full frequency/base mechanics; no definitive per-month/compound bill from this statement.|UCHANGIAJI(e);GN668amendment|https://www.wcf.go.tz/pages/contribution (UCHANGIAJI(e);GN668amendment)|
|R25|PASS|Health insurance boundary: Older 3%+3%=6%; special 6.25% Treasuryand 1 monthtimingpreservedashistorical, notcurrentblanketcomputation|ss2,8-11|https://elibrary.osg.go.tz/bitstreams/c135c899-14da-4a3f-b832-563eb52278f1/download (ss2,8-11); https://elibrary.osg.go.tz/bitstreams/a551ff1e-24a3-408a-a121-5ffbf228bfca/download (Special Bill Supplement cover/notice22January2025; status only)|
|R26|PASS|Health insurance boundary: UHI3 public/privatebases;22 registration 30 days;23 publiclaw/privateapprovedpremium; currentimplementationhold|ss3,22-24|https://www.nhif.or.tz/uploads/documents/sw-1736978659-sw1729595633-Sheria%20ya%20Bima%20ya%20Afya%20kwa%20Wote.pdf (ss3,22-24)|
|R27|PASS|Health insurance boundary: 16August 2024 partialcommencement; excluded 5,37,43,58-65; nolatercommencementassumed|para2|https://www.nhif.or.tz/uploads/documents/sw-1744266564-BIMA-GN%20NO.%20700A%20OF%202024%20-%20TANGAZO-KUANZA%20KUTUMIKA.pdf (para2)|
|R28|PASS|Health insurance boundary: GN809 reg 23 employeeconsultation/schemechoiceand 15 thfollowingregistrationmonthremittance; notallmonthlydeadlineinferred|regs22-25|https://www.nhif.or.tz/uploads/documents/sw-1744266616-BIMA-Kanuni%20ya%20Bima%20ya%20Afya-2024.pdf (regs22-25)|
|R29|PASS|SDL exemptions: AllVETA19(a)-(k), charityresidentpubliccharacterconditions, due diligence, Ministerorder, and 16 exemptreturnrule; VETA19(2) specifically requires a resident public-character entity registered as such, functioning solely for relief of public poverty/distress AND provision of education or public health, with the Commissioner General satisfied after due diligence that its business is for public good. TRA SDL guidance uses a broader ITA-style charity definition and current ruling language; do not substitute it for the distinct VETA wording. Establish the statutory conditions and actual evidence, or hold relief.|ss16,19|https://elibrary.osg.go.tz/bitstreams/46a41d49-ae99-478c-8188-310fdc970d1b/download (ss16,19)|
|R30|PASS|SDL exemptions: Governmentfinancewordingthroughsubventionfrom 1July 2026|s98|https://www.tra.go.tz/images/uploads/acts/THE_FINANCE_ACT%2C_2026.pdf (s98)|
|R31|PASS|Worked cases: Allhypotheticalcases/formulas/derivedresults; residentbandswithapprovedretirementrelief, old 0.6% corrected 0.5%, publicexcludedovertimeandactualHESLBbase|monthlytables;PSSSF3/18;WCFguidance;HESLBreplacement20|https://www.tra.go.tz/page/income-tax-for-individuals (monthlytables;PSSSF3/18;WCFguidance;HESLBreplacement20)|
|R32|PASS|Worked cases: PSSSFovertimeexcluded; salary 1.2 mplus 200 kovertimewrongcontributionoverstatement 40 kderived|ss3,18|https://elibrary.osg.go.tz/bitstreams/cf923cdc-b36a-4a5b-88f8-21818597c3a2/download (ss3,18)|
|R33|PASS|Rates, bands and thresholds: Resident monthly taxable pay up to TZS 270,000: 0% (nil). Apply to taxable employment income after proved eligible retirement relief, not automatically to gross cash.|Mainland / Zanzibar rate tables|https://www.tra.go.tz/page/income-tax-for-individuals (Mainland / Zanzibar rate tables)|
|R34|PASS|Rates, bands and thresholds: Over TZS 270,000 to TZS 520,000: 8% of excess over TZS 270,000. At upper boundary TZS 20,000 tax (derived).|Monthly taxable income|https://www.tra.go.tz/page/income-tax-for-individuals (Monthly taxable income)|
|R35|PASS|Rates, bands and thresholds: Over TZS 520,000 to TZS 760,000: TZS 20,000 + 20% of excess over TZS 520,000. Upper-bound tax TZS 68,000 (derived).|Monthly taxable income|https://www.tra.go.tz/page/income-tax-for-individuals (Monthly taxable income)|
|R36|PASS|Rates, bands and thresholds: Over TZS 760,000 to TZS 1,000,000: TZS 68,000 + 25% of excess over TZS 760,000. Upper-bound tax TZS 128,000 (derived).|Monthly taxable income|https://www.tra.go.tz/page/income-tax-for-individuals (Monthly taxable income)|
|R37|PASS|Rates, bands and thresholds: Over TZS 1,000,000: TZS 128,000 + 30% of excess over TZS 1,000,000.|Monthly taxable income|https://www.tra.go.tz/page/income-tax-for-individuals (Monthly taxable income)|

## All actual original blocks

|Block|Line|Original|Final destination|Verdict|
|---|---|---|---|---|
|O1|18|Items flagged for further clarification are tracked separately and excluded here.|tanzania-social-contributions.md:35 — ## Rates, bands and thresholds|PASS|
|O2|19|This block is generated from verified `skill_facts` — edit the facts, not the prose.|tanzania-social-contributions.md:180 — ## Sources|PASS|
|O3|23|- **NSSF - total contribution (private sector)** — 20% of employee's monthly wages (joint employer/employee)  _(NSSF Act, Cap 50, s.13)_|tanzania-social-contributions.md:35 — ## Rates, bands and thresholds|PASS|
|O4|24|- **NSSF - split** — Employee share capped at 10% of monthly wage; standard splits 10% employer / 10% employee, or 15% / 5%  _(NSSF Act, Cap 50, s.13)_|tanzania-social-contributions.md:35 — ## Rates, bands and thresholds|PASS|
|O5|25|- **NSSF - payment deadline** — Within one month after the end of the month to which the contribution relates  _(NSSF Act, Cap 50, s.14)_|tanzania-social-contributions.md:70 — \| NSSF registration \| Employer within 1 month after becoming a contributing employer; covered employ|PASS|
|O6|26|- **NSSF - late payment penalty** — 5% of the unpaid amount for each month or part of a month after the due date  _(NSSF Act, Cap 50, ss.14-15)_|tanzania-social-contributions.md:70 — \| NSSF registration \| Employer within 1 month after becoming a contributing employer; covered employ|PASS|
|O7|27|- **NSSF - registration** — Employers must register with NSSF and register all employees (membership mandatory for private-sector employees)  _(NSSF Act, Cap 50)_|tanzania-social-contributions.md:35 — ## Rates, bands and thresholds|PASS|
|O8|28|- **PSSSF - public service scheme** — 20% of salary: employer 15% / employee 5%  _(Public Service Social Security Fund Act No. 2 of 2018 (Cap 371 RE 2023), Part IV - contributions)_|tanzania-social-contributions.md:35 — ## Rates, bands and thresholds|PASS|
|O9|29|- **WCF - tariff rate** — 0.5% of cash sums paid to employees - both private and public sector employers  _(Workers Compensation Act, Cap 263; Tariff Regulations)_|tanzania-social-contributions.md:35 — ## Rates, bands and thresholds|PASS|
|O10|30|- **WCF - payment deadline** — Monthly; payable within the contribution month or not later than the end of the following month  _(Workers Compensation (Payment of Tariff) Regulations)_|tanzania-social-contributions.md:70 — \| NSSF registration \| Employer within 1 month after becoming a contributing employer; covered employ|PASS|
|O11|31|- **WCF - late payment interest** — 2% of the unpaid amount per month of delay  _(WCF regulations/notices)_|tanzania-social-contributions.md:70 — \| NSSF registration \| Employer within 1 month after becoming a contributing employer; covered employ|PASS|
|O12|32|- **SDL - cross reference** — 3.5% of gross emoluments, employers with 10+ employees, monthly by the 7th (see tanzania-payroll sheet)  _(VETA Act, Cap 82 (as amended by Finance Act 2023))_|tanzania-social-contributions.md:62 — ### SDL exemptions|PASS|
|O13|33|- **HESLB - employer deduction** — 15% of monthly salary of each loan beneficiary; remit by the 15th day of the following month  _(HESLB Act, Cap 178)_|tanzania-social-contributions.md:70 — \| NSSF registration \| Employer within 1 month after becoming a contributing employer; covered employ|PASS|
|O14|34|- **HESLB - employer penalty** — 10% of the monthly deduction amount for failure to deduct/remit on time  _(HESLB Act, Cap 178)_|tanzania-social-contributions.md:70 — \| NSSF registration \| Employer within 1 month after becoming a contributing employer; covered employ|PASS|
|O15|35|- **NHIF - public service** — 6% of basic salary: 3% employer / 3% employee (mandatory for public servants)  _(National Health Insurance Fund Act, Cap 395)_|tanzania-social-contributions.md:81 — ### Health insurance: supported scope and unresolved current rate|PASS|
|O16|36|- **Employer statutory on-cost (private sector summary)** — NSSF 10% + SDL 3.5% + WCF 0.5% = 14% of gross payroll (SDL-liable employers, 10/10 NSSF split)  _(Derived)_|tanzania-social-contributions.md:62 — ### SDL exemptions|PASS|
|O17|37|- **Employee statutory deductions (typical)** — NSSF 10% of wages + PAYE per bands (+ 15% HESLB if loan beneficiary)  _(Derived)_|tanzania-social-contributions.md:35 — ## Rates, bands and thresholds|PASS|
|O18|41|**Read this whole section before computing or classifying anything.**|tanzania-social-contributions.md:180 — ## Sources|PASS|
|O19|43|**Quick reference field table**|tanzania-social-contributions.md:180 — ## Sources|PASS|
|O20|45|**Quick reference field table**|tanzania-social-contributions.md:180 — ## Sources|PASS|
|O21|47|\| Field \| Value \||tanzania-social-contributions.md:180 — ## Sources|PASS|
|O22|49|\| Country \| United Republic of Tanzania (Mainland — see Zanzibar note) \||tanzania-social-contributions.md:180 — ## Sources|PASS|
|O23|50|\| Tax year \| Calendar year (1 Jan – 31 Dec) \||tanzania-social-contributions.md:180 — ## Sources|PASS|
|O24|51|\| Primary Legislation (PAYE) \| Income Tax Act, Cap. 332 \||tanzania-social-contributions.md:180 — ## Sources|PASS|
|O25|52|\| Pension Legislation (private) \| National Social Security Fund Act, Cap. 50 \||tanzania-social-contributions.md:180 — ## Sources|PASS|
|O26|53|\| Pension Legislation (public) \| Public Service Social Security Act, 2018 \||tanzania-social-contributions.md:180 — ## Sources|PASS|
|O27|54|\| Levy Legislation \| Vocational Education and Training Act (SDL); Workers Compensation Act (WCF) \||tanzania-social-contributions.md:62 — ### SDL exemptions|PASS|
|O28|55|\| Tax Authority \| Tanzania Revenue Authority (TRA) \||tanzania-social-contributions.md:180 — ## Sources|PASS|
|O29|56|\| Pension funds \| NSSF (private/informal sector); PSSSF (public sector) \||tanzania-social-contributions.md:180 — ## Sources|PASS|
|O30|57|\| Personal income tax? \| YES — Tanzania has PAYE (this is NOT a no-PIT jurisdiction) \||tanzania-social-contributions.md:180 — ## Sources|PASS|
|O31|58|\| Resident PAYE rates \| 0% / 8% / 20% / 25% / 30% progressive (TRA) \||tanzania-social-contributions.md:180 — ## Sources|PASS|
|O32|59|\| Non-resident employment rate \| 15% flat, final tax (PwC) \||tanzania-social-contributions.md:180 — ## Sources|PASS|
|O33|60|\| Tax-free threshold \| First TZS 270,000/month (TRA) \||tanzania-social-contributions.md:180 — ## Sources|PASS|
|O34|61|\| NSSF total \| 20% of gross wage — 10% employer / 10% employee (NSSF) \||tanzania-social-contributions.md:180 — ## Sources|PASS|
|O35|62|\| PSSSF total \| 20% of gross wage — 15% employer / 5% employee (secondary; see gap) \||tanzania-social-contributions.md:180 — ## Sources|PASS|
|O36|63|\| SDL \| 3.5% of gross emoluments, employer ≥10 employees (TRA) \||tanzania-social-contributions.md:62 — ### SDL exemptions|PASS|
|O37|64|\| WCF \| 0.5%–0.6% of cash paid to employees, employer-only (see gap) \||tanzania-social-contributions.md:180 — ## Sources|PASS|
|O38|65|\| Currency \| TZS only \||tanzania-social-contributions.md:180 — ## Sources|PASS|
|O39|67|**Contribution overview (private-sector Mainland employee)**|tanzania-social-contributions.md:180 — ## Sources|PASS|
|O40|69|\| Item \| Employer \| Employee \| Total \| Base \| Source \||tanzania-social-contributions.md:180 — ## Sources|PASS|
|O41|71|\| PAYE \| — \| 0%–30% progressive \| — \| Monthly income after pension \| TRA \||tanzania-social-contributions.md:180 — ## Sources|PASS|
|O42|72|\| NSSF pension \| 10% \| 10% \| 20% \| Gross wage \| NSSF \||tanzania-social-contributions.md:180 — ## Sources|PASS|
|O43|73|\| SDL \| 3.5% \| — \| 3.5% \| Gross emoluments (if ≥10 employees) \| TRA \||tanzania-social-contributions.md:62 — ### SDL exemptions|PASS|
|O44|74|\| WCF \| 0.5%–0.6% \| — \| 0.5%–0.6% \| Cash paid to employees \| PwC / WCF [RESEARCH GAP — reviewer to confirm tariff] \||tanzania-social-contributions.md:180 — ## Sources|PASS|
|O45|76|**Conservative defaults**|tanzania-social-contributions.md:171 — ## When to refuse or refer|PASS|
|O46|78|\| Ambiguity \| Default \||tanzania-social-contributions.md:180 — ## Sources|PASS|
|O47|80|\| Unknown residency status \| Assume resident (progressive PAYE); ask before applying 15% flat \||tanzania-social-contributions.md:171 — ## When to refuse or refer|PASS|
|O48|81|\| Unknown sector (private vs public) \| Assume private → NSSF (10%/10%); confirm before PSSSF \||tanzania-social-contributions.md:171 — ## When to refuse or refer|PASS|
|O49|82|\| Unknown employee headcount for SDL \| If unknown, flag — SDL only applies at ≥10 employees (TRA) \||tanzania-social-contributions.md:62 — ### SDL exemptions|PASS|
|O50|83|\| Unknown WCF tariff \| Use 0.6% private / 0.5% public and FLAG [RESEARCH GAP] \||tanzania-social-contributions.md:171 — ## When to refuse or refer|PASS|
|O51|84|\| Unknown whether pension already deducted before PAYE \| Deduct mandatory pension before computing PAYE base (TRA) \||tanzania-social-contributions.md:171 — ## When to refuse or refer|PASS|
|O52|85|\| Zanzibar vs Mainland not stated \| Assume Mainland; STOP on levies if Zanzibar (different regime) \||tanzania-social-contributions.md:180 — ## Sources|PASS|
|O53|91|**Minimum viable** — gross monthly wage (TZS), residency status (resident / non-resident), and sector (private vs public). Without gross wage, STOP.|tanzania-social-contributions.md:171 — ## When to refuse or refer|PASS|
|O54|93|**Recommended** — employer headcount (for SDL liability), whether employee is on a permitted alternative NSSF split (15%/5%), and Mainland vs Zanzibar location.|tanzania-social-contributions.md:62 — ### SDL exemptions|PASS|
|O55|95|**Ideal** — TRA PAYE return (ITX 300.01.E credit slip), NSSF Form NSSF/CON.5 earnings statement, payroll register, and bank statements showing TRA / NSSF / WCF remittances.|tanzania-social-contributions.md:89 — ### Statement classification and Kiswahili terminology|PASS|
|O56|99|- **R-TZ-SC-1 — Gross wage unknown** — Trigger: monthly gross wage not provided. Message: "Monthly gross wage in TZS is mandatory for PAYE and pension computation. PAYE is progressive and pension is a percentage of gross. Cannot proceed without this figure."|tanzania-social-contributions.md:171 — ## When to refuse or refer|PASS|
|O57|100|- **R-TZ-SC-2 — Zanzibar payroll levies** — Trigger: employment located in Zanzibar. Message: "PAYE brackets are identical in Zanzibar per TRA, but SDL and certain social levies operate under a separate Zanzibar regime. Do not apply Mainland SDL/levy figures to Zanzibar without confirming the Zanzibar schedule. Escalate to a practitioner."|tanzania-social-contributions.md:62 — ### SDL exemptions|PASS|
|O58|101|- **R-TZ-SC-3 — WCF tariff confirmation** — Trigger: a definitive WCF figure is required for filing. Message: "The current private-sector WCF tariff is unconfirmed from WCF's own publications (PwC states 0.5%; other sources state 0.6%). Do not present a definitive WCF charge without confirming the tariff directly with WCF."|tanzania-social-contributions.md:70 — \| NSSF registration \| Employer within 1 month after becoming a contributing employer; covered employ|PASS|
|O59|102|- **R-TZ-SC-4 — Arrears / penalty quantification** — Trigger: client has unpaid PAYE, NSSF, SDL, or WCF from prior periods. Message: "Statutory penalties (TRA 2.5%/month, NSSF 5%/month) compound on unpaid amounts. Do not attempt to quantify arrears without official statements. Escalate to a practitioner."|tanzania-social-contributions.md:62 — ### SDL exemptions|PASS|
|O60|103|- **R-TZ-SC-5 — Presumptive tax / non-PAYE individuals** — Trigger: individual under the presumptive regime (turnover ≤ TZS 100 million). Message: "The presumptive income tax regime is outside the scope of this payroll skill and its rate bands are not captured here. Escalate to a practitioner. [RESEARCH GAP — presumptive bands not extracted]"|tanzania-social-contributions.md:171 — ## When to refuse or refer|PASS|
|O61|107|This is the deterministic pre-classifier for bank statement transactions related to Tanzanian payroll taxes and social security. When a transaction matches a pattern below, apply the treatment directly. Do not second-guess.|tanzania-social-contributions.md:89 — ### Statement classification and Kiswahili terminology|PASS|
|O62|109|**How to read this table.** Match by case-insensitive substring on the counterparty/reference as it appears in the bank statement. Statutory remittances (PAYE, NSSF, PSSSF, SDL, WCF) are EXCLUDED from any VAT return — they are statutory obligations, not business supplies. The employer share of pension/SDL/WCF is a deductible business cost; the employee share is withheld from wages, not an employer expense.|tanzania-social-contributions.md:89 — ### Statement classification and Kiswahili terminology|PASS|
|O63|113|**TRA payments (PAYE / SDL)**|tanzania-social-contributions.md:62 — ### SDL exemptions|PASS|
|O64|115|\| Pattern \| Treatment \| Notes \||tanzania-social-contributions.md:89 — ### Statement classification and Kiswahili terminology|PASS|
|O65|117|\| TRA, TANZANIA REVENUE AUTHORITY \| EXCLUDE — statutory tax remittance \| PAYE and/or SDL monthly remittance \||tanzania-social-contributions.md:62 — ### SDL exemptions|PASS|
|O66|118|\| PAYE, P.A.Y.E \| EXCLUDE — employee tax withheld \| Remitted by 7th of following month \||tanzania-social-contributions.md:62 — ### SDL exemptions|PASS|
|O67|119|\| SDL, SKILLS DEVELOPMENT LEVY \| EXCLUDE — employer levy \| 3.5%; employer ≥10 staff \||tanzania-social-contributions.md:62 — ### SDL exemptions|PASS|
|O68|120|\| ITX 300, ITX300.01.E \| EXCLUDE — employment taxes credit slip \| TRA payment reference \||tanzania-social-contributions.md:62 — ### SDL exemptions|PASS|
|O69|124|**Pension fund debits (NSSF / PSSSF)**|tanzania-social-contributions.md:35 — ## Rates, bands and thresholds|PASS|
|O70|126|\| Pattern \| Treatment \| Notes \||tanzania-social-contributions.md:89 — ### Statement classification and Kiswahili terminology|PASS|
|O71|128|\| NSSF, NATIONAL SOCIAL SECURITY FUND \| EXCLUDE — pension contribution \| 20% total (10% er / 10% ee) \||tanzania-social-contributions.md:35 — ## Rates, bands and thresholds|PASS|
|O72|129|\| NSSF/CON.5, CON.5 \| EXCLUDE — NSSF contribution statement \| Form filed with payment \||tanzania-social-contributions.md:35 — ## Rates, bands and thresholds|PASS|
|O73|130|\| PSSSF, PUBLIC SERVICE SOCIAL SECURITY \| EXCLUDE — public-sector pension \| 20% total (15% er / 5% ee) \||tanzania-social-contributions.md:35 — ## Rates, bands and thresholds|PASS|
|O74|131|\| MICHANGO YA PENSHENI \| EXCLUDE — pension contribution \| Swahili: "pension contributions" \||tanzania-social-contributions.md:89 — ### Statement classification and Kiswahili terminology|PASS|
|O75|135|**Workers Compensation Fund (WCF)**|tanzania-social-contributions.md:35 — ## Rates, bands and thresholds|PASS|
|O76|137|\| Pattern \| Treatment \| Notes \||tanzania-social-contributions.md:89 — ### Statement classification and Kiswahili terminology|PASS|
|O77|139|\| WCF, WORKERS COMPENSATION FUND \| EXCLUDE — employer levy \| 0.5%–0.6%, employer-only \||tanzania-social-contributions.md:35 — ## Rates, bands and thresholds|PASS|
|O78|140|\| MFUKO WA FIDIA KWA WAFANYAKAZI \| EXCLUDE — WCF \| Swahili: "workers compensation fund" \||tanzania-social-contributions.md:89 — ### Statement classification and Kiswahili terminology|PASS|
|O79|144|**Salary and payroll (exclude from contributions classification)**|tanzania-social-contributions.md:35 — ## Rates, bands and thresholds|PASS|
|O80|146|\| Pattern \| Treatment \| Notes \||tanzania-social-contributions.md:89 — ### Statement classification and Kiswahili terminology|PASS|
|O81|148|\| SALARY, MSHAHARA (outgoing) \| EXCLUDE — payroll expense \| Gross wage paid; not a contribution \||tanzania-social-contributions.md:35 — ## Rates, bands and thresholds|PASS|
|O82|149|\| SALARY, MSHAHARA (incoming) \| EXCLUDE — employment income received \| Not a contribution \||tanzania-social-contributions.md:35 — ## Rates, bands and thresholds|PASS|
|O83|150|\| WAGES, MISHAHARA \| EXCLUDE — payroll expense \| Plural Swahili "salaries" \||tanzania-social-contributions.md:89 — ### Statement classification and Kiswahili terminology|PASS|
|O84|154|**Pension / benefit payments received (NOT contributions)**|tanzania-social-contributions.md:89 — ### Statement classification and Kiswahili terminology|PASS|
|O85|156|\| Pattern \| Treatment \| Notes \||tanzania-social-contributions.md:89 — ### Statement classification and Kiswahili terminology|PASS|
|O86|158|\| NSSF PENSION, PSSSF PENSION (credit) \| EXCLUDE — pension benefit received \| Inbound, not a contribution paid \||tanzania-social-contributions.md:89 — ### Statement classification and Kiswahili terminology|PASS|
|O87|159|\| PENSHENI (credit) \| EXCLUDE — pension income \| Swahili: "pension" received \||tanzania-social-contributions.md:89 — ### Statement classification and Kiswahili terminology|PASS|
|O88|163|Six bank statement / payroll classifications for a hypothetical private-sector employer and employee in Tanzania Mainland. All amounts in TZS. PAYE is computed on income **after** deducting the mandatory NSSF employee contribution (TRA).|tanzania-social-contributions.md:114 — ## Worked cases|PASS|
|O89|167|**Input:** Resident employee, gross monthly wage TZS 800,000, private sector, employer has 25 staff.|tanzania-social-contributions.md:114 — ## Worked cases|PASS|
|O90|169|**Reasoning:**|tanzania-social-contributions.md:114 — ## Worked cases|PASS|
|O91|170|- NSSF employee 10% = 80,000. NSSF employer 10% = 80,000. NSSF total 20% = 160,000.|tanzania-social-contributions.md:114 — ## Worked cases|PASS|
|O92|171|- PAYE base = 800,000 − 80,000 = 720,000.|tanzania-social-contributions.md:114 — ## Worked cases|PASS|
|O93|172|- PAYE: falls in band 520,001–760,000 → 20,000 + 20% × (720,000 − 520,000) = 20,000 + 20% × 200,000 = 20,000 + 40,000 = **60,000**.|tanzania-social-contributions.md:114 — ## Worked cases|PASS|
|O94|173|- Net pay = 800,000 − 80,000 (NSSF ee) − 60,000 (PAYE) = **660,000**.|tanzania-social-contributions.md:114 — ## Worked cases|PASS|
|O95|174|- Employer also bears: NSSF 80,000 + SDL 3.5% × 800,000 = 28,000 + WCF 0.6% × 800,000 = 4,800.|tanzania-social-contributions.md:114 — ## Worked cases|PASS|
|O96|176|**Classification:** PAYE 60,000 and NSSF ee 80,000 withheld; NSSF er 80,000, SDL 28,000, WCF 4,800 employer-borne. All statutory remittances EXCLUDE from VAT.|tanzania-social-contributions.md:114 — ## Worked cases|PASS|
|O97|180|**Input:** Resident employee, gross monthly wage TZS 1,500,000, private sector.|tanzania-social-contributions.md:114 — ## Worked cases|PASS|
|O98|182|**Reasoning:**|tanzania-social-contributions.md:114 — ## Worked cases|PASS|
|O99|183|- NSSF employee 10% = 150,000. PAYE base = 1,500,000 − 150,000 = 1,350,000.|tanzania-social-contributions.md:114 — ## Worked cases|PASS|
|O100|184|- PAYE: above 1,000,000 → 128,000 + 30% × (1,350,000 − 1,000,000) = 128,000 + 30% × 350,000 = 128,000 + 105,000 = **233,000**.|tanzania-social-contributions.md:114 — ## Worked cases|PASS|
|O101|185|- Net pay = 1,500,000 − 150,000 − 233,000 = **1,117,000**.|tanzania-social-contributions.md:114 — ## Worked cases|PASS|
|O102|187|**Classification:** PAYE 233,000 + NSSF ee 150,000 withheld. EXCLUDE remittances from VAT.|tanzania-social-contributions.md:114 — ## Worked cases|PASS|
|O103|191|**Input:** Resident employee, gross monthly wage TZS 290,000, private sector.|tanzania-social-contributions.md:114 — ## Worked cases|PASS|
|O104|193|**Reasoning:**|tanzania-social-contributions.md:114 — ## Worked cases|PASS|
|O105|194|- NSSF employee 10% = 29,000. PAYE base = 290,000 − 29,000 = 261,000.|tanzania-social-contributions.md:114 — ## Worked cases|PASS|
|O106|195|- PAYE base 261,000 ≤ 270,000 tax-free threshold → PAYE = **Nil** (TRA).|tanzania-social-contributions.md:114 — ## Worked cases|PASS|
|O107|196|- Net pay = 290,000 − 29,000 = **261,000**.|tanzania-social-contributions.md:114 — ## Worked cases|PASS|
|O108|197|- Note: 290,000 gross is below the new general minimum-wage baseline of TZS 358,322/month effective 1 Jan 2026 (GN 605A/2025) — flag wage compliance.|tanzania-social-contributions.md:114 — ## Worked cases|PASS|
|O109|199|**Classification:** PAYE Nil; NSSF ee 29,000 withheld. Flag minimum-wage compliance.|tanzania-social-contributions.md:114 — ## Worked cases|PASS|
|O110|203|**Input:** Non-resident employee, gross monthly employment income TZS 4,000,000.|tanzania-social-contributions.md:114 — ## Worked cases|PASS|
|O111|205|**Reasoning:**|tanzania-social-contributions.md:114 — ## Worked cases|PASS|
|O112|206|- Non-resident employment income is taxed at a **flat 15% final tax** (PwC) — progressive brackets do NOT apply.|tanzania-social-contributions.md:114 — ## Worked cases|PASS|
|O113|207|- PAYE = 15% × 4,000,000 = **600,000**.|tanzania-social-contributions.md:114 — ## Worked cases|PASS|
|O114|208|- Pension: NSSF applicability to non-residents is case-specific; flag for reviewer.|tanzania-social-contributions.md:114 — ## Worked cases|PASS|
|O115|210|**Classification:** PAYE 600,000 (final tax). EXCLUDE from VAT. Flag NSSF applicability.|tanzania-social-contributions.md:114 — ## Worked cases|PASS|
|O116|214|**Input line:**|tanzania-social-contributions.md:114 — ## Worked cases|PASS|
|O117|215|`07.02.2026 ; TANZANIA REVENUE AUTHORITY ; DEBIT ; ITX 300.01.E JAN PAYE+SDL ; -1,250,000 ; TZS`|tanzania-social-contributions.md:114 — ## Worked cases|PASS|
|O118|217|**Reasoning:**|tanzania-social-contributions.md:114 — ## Worked cases|PASS|
|O119|218|Matches "TANZANIA REVENUE AUTHORITY" / "ITX 300.01.E" (patterns 3.1). This is the monthly employment-taxes remittance (PAYE withheld + SDL) due by the 7th of the following month (TRA). EXCLUDE from VAT. The PAYE component is withheld employee tax (not an employer cost); the SDL component (3.5%) is a deductible employer levy.|tanzania-social-contributions.md:114 — ## Worked cases|PASS|
|O120|220|**Classification:** EXCLUDE from VAT. Statutory PAYE+SDL remittance.|tanzania-social-contributions.md:114 — ## Worked cases|PASS|
|O121|224|**Input line:**|tanzania-social-contributions.md:114 — ## Worked cases|PASS|
|O122|225|`20.03.2026 ; NATIONAL SOCIAL SECURITY FUND ; DEBIT ; ARREARS ; -3,500,000 ; TZS`|tanzania-social-contributions.md:114 — ## Worked cases|PASS|
|O123|227|**Reasoning:**|tanzania-social-contributions.md:114 — ## Worked cases|PASS|
|O124|228|Matches "NATIONAL SOCIAL SECURITY FUND" (pattern 3.2) but amount is irregular and reference says "ARREARS." NSSF late penalty is 5% of the unpaid amount per month or part-month (NSSF Act, Cap. 50). Cannot separate principal from penalty without an NSSF statement / Form NSSF/CON.5. EXCLUDE from VAT. Flag for reviewer.|tanzania-social-contributions.md:114 — ## Worked cases|PASS|
|O125|230|**Classification:** EXCLUDE from VAT. Flag for reviewer — request NSSF breakdown to split contribution principal from 5%/month penalty.|tanzania-social-contributions.md:114 — ## Worked cases|PASS|
|O126|234|These rules apply when payroll data is clear and all required inputs are available. Apply exactly as written.|tanzania-social-contributions.md:171 — ## When to refuse or refer|PASS|
|O127|238|- **PAYE base formula** — PAYE base = gross monthly income − mandatory NSSF/PSSSF employee contribution. Pension contributions are deductible before applying the PAYE schedule.  _(TRA)_|tanzania-social-contributions.md:35 — ## Rates, bands and thresholds|PASS|
|O128|242|**Resident PAYE progressive schedule**  _(TRA (Income Tax for Individuals); PwC (last reviewed 14 Jan 2026))_|tanzania-social-contributions.md:35 — ## Rates, bands and thresholds|PASS|
|O129|244|\| Monthly PAYE base (TZS) \| Tax \||tanzania-social-contributions.md:35 — ## Rates, bands and thresholds|PASS|
|O130|246|\| 0 – 270,000 \| Nil \||tanzania-social-contributions.md:35 — ## Rates, bands and thresholds|PASS|
|O131|247|\| 270,001 – 520,000 \| 8% of excess over 270,000 \||tanzania-social-contributions.md:35 — ## Rates, bands and thresholds|PASS|
|O132|248|\| 520,001 – 760,000 \| 20,000 + 20% of excess over 520,000 \||tanzania-social-contributions.md:35 — ## Rates, bands and thresholds|PASS|
|O133|249|\| 760,001 – 1,000,000 \| 68,000 + 25% of excess over 760,000 \||tanzania-social-contributions.md:35 — ## Rates, bands and thresholds|PASS|
|O134|250|\| Above 1,000,000 \| 128,000 + 30% of excess over 1,000,000 \||tanzania-social-contributions.md:35 — ## Rates, bands and thresholds|PASS|
|O135|252|- **Cumulative figures verification and lowest band note** — Cumulative figures verified: at 520,000 → 20,000; at 760,000 → 68,000; at 1,000,000 → 128,000. Lowest band is 8% (TRA/PwC) — do not use the outdated 9% from some secondary calculators.  _(TRA/PwC)_|tanzania-social-contributions.md:180 — ## Sources|PASS|
|O136|256|- **Tax-free threshold** — The first TZS 270,000/month is not taxed (TRA states annual income of TZS 3,240,000 is not taxable). 270,000 × 12 = 3,240,000 ✓.  _(TRA)_|tanzania-social-contributions.md:35 — ## Rates, bands and thresholds|PASS|
|O137|260|- **Non-resident employment income rate** — Non-resident employment income is taxed at a flat 15% final tax. The progressive schedule does not apply.  _(PwC)_|tanzania-social-contributions.md:35 — ## Rates, bands and thresholds|PASS|
|O138|264|- **NSSF total contribution and split** — Total NSSF = 20% of gross monthly wage, joint employer/employee. Standard split: 10% employer / 10% employee (employee share capped at 10%). Permitted alternative: 15% employer / 5% employee; employer may remit the full 20% without deducting from the employee. The legal obligation to remit rests on the employer. No published floor or ceiling on the contribution base.  _(NSSF; PwC)_|tanzania-social-contributions.md:70 — \| NSSF registration \| Employer within 1 month after becoming a contributing employer; covered employ|PASS|
|O139|268|- **PSSSF total contribution and split** — Total PSSSF = 20%, split 15% employer / 5% employee, under the Public Service Social Security Act, 2018. [RESEARCH GAP — split sourced from secondary material; reviewer to confirm against PSSSF official documentation.]  _(Public Service Social Security Act, 2018)_|tanzania-social-contributions.md:180 — ## Sources|PASS|
|O140|272|- **SDL rate and threshold** — SDL = 3.5% of total gross monthly emoluments paid to all employees, payable by employers with 10 or more employees (TRA — authoritative; ignore secondary "4 or more" sources). Form ITX 300.01.E. Employer-borne. Exemptions: government departments / wholly govt-financed institutions, certain interns, and farm employers whose employees are solely engaged in farming.  _(TRA)_|tanzania-social-contributions.md:62 — ### SDL exemptions|PASS|
|O141|276|- **WCF rate and treatment** — WCF is employer-borne only (not deducted from employees), payable monthly on cash paid to employees. Rate: PwC (Jan 2026) states 0.5%; other sources state 0.6% private / 0.5% public (0.6% private effective July 2021). [RESEARCH GAP — exact current private-sector tariff unconfirmed from WCF's own publications; default to 0.6% private / 0.5% public and FLAG before filing.]  _(PwC / WCF)_|tanzania-social-contributions.md:70 — \| NSSF registration \| Employer within 1 month after becoming a contributing employer; covered employ|PASS|
|O142|280|**Monthly remittance deadlines**|tanzania-social-contributions.md:70 — \| NSSF registration \| Employer within 1 month after becoming a contributing employer; covered employ|PASS|
|O143|282|\| Item \| Deadline \| Source \||tanzania-social-contributions.md:70 — \| NSSF registration \| Employer within 1 month after becoming a contributing employer; covered employ|PASS|
|O144|284|\| PAYE + SDL (TRA) \| 7th day of the month following the payroll month \| TRA \||tanzania-social-contributions.md:62 — ### SDL exemptions|PASS|
|O145|285|\| WCF \| Monthly (with cash paid) \| PwC \||tanzania-social-contributions.md:70 — \| NSSF registration \| Employer within 1 month after becoming a contributing employer; covered employ|PASS|
|O146|286|\| NSSF \| Within one month after the end of the month it relates to (NSSF Act s.14); practitioners cite end of following month \| NSSF Act Cap. 50 \||tanzania-social-contributions.md:70 — \| NSSF registration \| Employer within 1 month after becoming a contributing employer; covered employ|PASS|
|O147|290|**Penalties**|tanzania-social-contributions.md:70 — \| NSSF registration \| Employer within 1 month after becoming a contributing employer; covered employ|PASS|
|O148|292|\| Item \| Penalty \| Source \||tanzania-social-contributions.md:70 — \| NSSF registration \| Employer within 1 month after becoming a contributing employer; covered employ|PASS|
|O149|294|\| PAYE/SDL late (TRA) \| Higher of 2.5% of unpaid tax per month (or part) or 15 currency points (body corporate); plus interest \| TRA \||tanzania-social-contributions.md:62 — ### SDL exemptions|PASS|
|O150|295|\| NSSF late \| 5% of unpaid amount per month or part-month \| NSSF Act Cap. 50 \||tanzania-social-contributions.md:70 — \| NSSF registration \| Employer within 1 month after becoming a contributing employer; covered employ|PASS|
|O151|299|- **Minimum wage** — New order Government Notice No. 605A (13 Oct 2025) raises the baseline by an average 33.4% to TZS 358,322/month (cross-sector average; rates are sector-specific). Sectors not specifically covered: TZS 175,000/month. Based on a 45-hour workweek.  _(TanzLII GN 605A/2025; PKF)_|tanzania-social-contributions.md:35 — ## Rates, bands and thresholds|PASS|
|O152|303|- **VAT treatment of statutory remittances** — PAYE, NSSF, PSSSF, SDL, and WCF remittances are EXCLUDED from any VAT return. Employer shares of pension/SDL/WCF are deductible business costs; employee withholdings are not employer expenses.|tanzania-social-contributions.md:62 — ### SDL exemptions|PASS|
|O153|307|When payroll data is ambiguous or client circumstances are unclear, flag these situations for reviewer confirmation.|tanzania-social-contributions.md:171 — ## When to refuse or refer|PASS|
|O154|311|- **Residency status ambiguity** — Trigger: Unclear whether the employee is resident or non-resident for the tax year. Issue: Residents use the progressive 0%–30% schedule; non-residents pay a flat 15% final tax. Misclassification changes the entire computation. Action: Flag for reviewer. Confirm tax residency before computing PAYE.|tanzania-social-contributions.md:35 — ## Rates, bands and thresholds|PASS|
|O155|315|- **NSSF split election** — Trigger: Employer applies, or asks about, the alternative 15% employer / 5% employee split, or remits the full 20% with no employee deduction. Issue: Net pay and employer cost differ depending on which permitted split applies. The employee share must not exceed 10%. Action: Flag for reviewer. Confirm the agreed split before computing net pay.|tanzania-social-contributions.md:70 — \| NSSF registration \| Employer within 1 month after becoming a contributing employer; covered employ|PASS|
|O156|319|- **SDL headcount near threshold** — Trigger: Employer headcount is around 9–11, or fluctuates across months. Issue: SDL applies only at 10 or more employees (TRA). Crossing the threshold mid-year changes SDL liability. Action: Flag for reviewer. Confirm the monthly headcount basis.|tanzania-social-contributions.md:62 — ### SDL exemptions|PASS|
|O157|323|- **WCF tariff ambiguity** — Trigger: A definitive WCF charge is needed. Issue: PwC states 0.5%; other sources state 0.6% private / 0.5% public. The exact current private tariff is unconfirmed from WCF's own publications. Action: Flag for reviewer. Confirm the tariff directly with WCF before filing. [RESEARCH GAP]|tanzania-social-contributions.md:70 — \| NSSF registration \| Employer within 1 month after becoming a contributing employer; covered employ|PASS|
|O158|327|- **Public vs private sector fund selection** — Trigger: Unclear whether the employer is in the public sector (PSSSF) or private/informal sector (NSSF). Issue: Fund and split differ — NSSF 10%/10% vs PSSSF 15%/5%. The PSSSF split itself is sourced from secondary material. Action: Flag for reviewer. Confirm sector and the applicable fund.|tanzania-social-contributions.md:180 — ## Sources|PASS|
|O159|331|- **Zanzibar employment** — Trigger: Employment located in Zanzibar. Issue: PAYE brackets are identical, but SDL and certain social levies follow a separate Zanzibar regime. Action: Flag for reviewer. Do not apply Mainland levy figures to Zanzibar without the Zanzibar schedule.|tanzania-social-contributions.md:62 — ### SDL exemptions|PASS|
|O160|335|- **Arrears and penalties** — Trigger: Unpaid PAYE, NSSF, SDL, or WCF from prior periods. Issue: TRA penalty 2.5%/month (or part) plus interest; NSSF penalty 5%/month (or part). These compound on unpaid amounts. Action: Do not quantify arrears without official statements. Escalate to a practitioner.|tanzania-social-contributions.md:62 — ### SDL exemptions|PASS|
|O161|339|When producing a Tanzanian payroll computation, structure the working paper as follows:|tanzania-social-contributions.md:108 — ### Workpaper and bank-only onboarding|PASS|
|O162|342|TANZANIA (MAINLAND) PAYROLL COMPUTATION -- WORKING PAPER|tanzania-social-contributions.md:108 — ### Workpaper and bank-only onboarding|PASS|
|O163|343|Client / Employer: [name]|tanzania-social-contributions.md:108 — ### Workpaper and bank-only onboarding|PASS|
|O164|344|Tax Year: [calendar year]|tanzania-social-contributions.md:108 — ### Workpaper and bank-only onboarding|PASS|
|O165|345|Prepared: [date]|tanzania-social-contributions.md:108 — ### Workpaper and bank-only onboarding|PASS|
|O166|347|INPUT DATA|tanzania-social-contributions.md:108 — ### Workpaper and bank-only onboarding|PASS|
|O167|348|  Employee name:                 [____]|tanzania-social-contributions.md:108 — ### Workpaper and bank-only onboarding|PASS|
|O168|349|  Residency status:              [Resident / Non-resident]|tanzania-social-contributions.md:108 — ### Workpaper and bank-only onboarding|PASS|
|O169|350|  Sector:                        [Private (NSSF) / Public (PSSSF)]|tanzania-social-contributions.md:108 — ### Workpaper and bank-only onboarding|PASS|
|O170|351|  Gross monthly wage (TZS):      [____]|tanzania-social-contributions.md:108 — ### Workpaper and bank-only onboarding|PASS|
|O171|352|  Employer headcount:            [____]   (SDL applies if >= 10)|tanzania-social-contributions.md:108 — ### Workpaper and bank-only onboarding|PASS|
|O172|353|  NSSF split:                    [10/10 standard / 15/5 alt / 20 er-only]|tanzania-social-contributions.md:108 — ### Workpaper and bank-only onboarding|PASS|
|O173|354|  Location:                      [Mainland / Zanzibar]|tanzania-social-contributions.md:108 — ### Workpaper and bank-only onboarding|PASS|
|O174|356|PENSION (NSSF private: 20% total)|tanzania-social-contributions.md:108 — ### Workpaper and bank-only onboarding|PASS|
|O175|357|  Employee share (10%):          TZS [____]|tanzania-social-contributions.md:108 — ### Workpaper and bank-only onboarding|PASS|
|O176|358|  Employer share (10%):          TZS [____]|tanzania-social-contributions.md:108 — ### Workpaper and bank-only onboarding|PASS|
|O177|359|  Total (20%):                   TZS [____]|tanzania-social-contributions.md:108 — ### Workpaper and bank-only onboarding|PASS|
|O178|361|PAYE (resident progressive; base = gross - employee pension)|tanzania-social-contributions.md:108 — ### Workpaper and bank-only onboarding|PASS|
|O179|362|  PAYE base:                     TZS [____]|tanzania-social-contributions.md:108 — ### Workpaper and bank-only onboarding|PASS|
|O180|363|  Band applied:                  [0 / 8% / 20% / 25% / 30%]|tanzania-social-contributions.md:108 — ### Workpaper and bank-only onboarding|PASS|
|O181|364|  PAYE due (monthly):            TZS [____]|tanzania-social-contributions.md:108 — ### Workpaper and bank-only onboarding|PASS|
|O182|365|  (Non-resident: 15% flat final tax on gross employment income)|tanzania-social-contributions.md:108 — ### Workpaper and bank-only onboarding|PASS|
|O183|367|EMPLOYER LEVIES|tanzania-social-contributions.md:108 — ### Workpaper and bank-only onboarding|PASS|
|O184|368|  SDL (3.5% of gross emoluments, if >= 10 staff): TZS [____]|tanzania-social-contributions.md:108 — ### Workpaper and bank-only onboarding|PASS|
|O185|369|  WCF (0.5%-0.6% of cash paid) [CONFIRM TARIFF]:  TZS [____]|tanzania-social-contributions.md:108 — ### Workpaper and bank-only onboarding|PASS|
|O186|371|NET PAY|tanzania-social-contributions.md:108 — ### Workpaper and bank-only onboarding|PASS|
|O187|372|  Gross:                         TZS [____]|tanzania-social-contributions.md:108 — ### Workpaper and bank-only onboarding|PASS|
|O188|373|  Less employee NSSF (10%):      TZS [____]|tanzania-social-contributions.md:108 — ### Workpaper and bank-only onboarding|PASS|
|O189|374|  Less PAYE:                     TZS [____]|tanzania-social-contributions.md:108 — ### Workpaper and bank-only onboarding|PASS|
|O190|375|  Net pay:                       TZS [____]|tanzania-social-contributions.md:108 — ### Workpaper and bank-only onboarding|PASS|
|O191|377|REMITTANCE DEADLINES|tanzania-social-contributions.md:108 — ### Workpaper and bank-only onboarding|PASS|
|O192|378|  PAYE + SDL (TRA, 7th of next month): [____]|tanzania-social-contributions.md:108 — ### Workpaper and bank-only onboarding|PASS|
|O193|379|  NSSF (within one month after month-end): [____]|tanzania-social-contributions.md:108 — ### Workpaper and bank-only onboarding|PASS|
|O194|380|  WCF (monthly): [____]|tanzania-social-contributions.md:108 — ### Workpaper and bank-only onboarding|PASS|
|O195|382|REVIEWER FLAGS|tanzania-social-contributions.md:108 — ### Workpaper and bank-only onboarding|PASS|
|O196|383|  [List any Tier 2 / RESEARCH GAP flags here]|tanzania-social-contributions.md:108 — ### Workpaper and bank-only onboarding|PASS|
|O197|385|CONSERVATIVE DEFAULTS APPLIED|tanzania-social-contributions.md:108 — ### Workpaper and bank-only onboarding|PASS|
|O198|386|  [List any defaults applied and their impact]|tanzania-social-contributions.md:108 — ### Workpaper and bank-only onboarding|PASS|
|O199|393|**CRDB Bank:**|tanzania-social-contributions.md:89 — ### Statement classification and Kiswahili terminology|PASS|
|O200|394|- Description: "TRA", "TANZANIA REVENUE AUTHORITY", "PAYE", "SDL", "NSSF", "WCF"|tanzania-social-contributions.md:89 — ### Statement classification and Kiswahili terminology|PASS|
|O201|395|- Timing: TRA (PAYE/SDL) around the 7th of the following month; NSSF by month-end following|tanzania-social-contributions.md:89 — ### Statement classification and Kiswahili terminology|PASS|
|O202|397|**NMB Bank:**|tanzania-social-contributions.md:89 — ### Statement classification and Kiswahili terminology|PASS|
|O203|398|- Description: "TRA PAYMENT", "ITX 300", "NSSF", "PSSSF", "WCF"|tanzania-social-contributions.md:89 — ### Statement classification and Kiswahili terminology|PASS|
|O204|399|- Timing: Same monthly cycle|tanzania-social-contributions.md:89 — ### Statement classification and Kiswahili terminology|PASS|
|O205|401|**NBC Bank:**|tanzania-social-contributions.md:89 — ### Statement classification and Kiswahili terminology|PASS|
|O206|402|- Description: "TANZANIA REVENUE AUTHORITY", "NATIONAL SOCIAL SECURITY FUND", "WORKERS COMPENSATION FUND"|tanzania-social-contributions.md:89 — ### Statement classification and Kiswahili terminology|PASS|
|O207|403|- Timing: Same monthly cycle|tanzania-social-contributions.md:89 — ### Statement classification and Kiswahili terminology|PASS|
|O208|405|**Key identification tips:**|tanzania-social-contributions.md:89 — ### Statement classification and Kiswahili terminology|PASS|
|O209|406|1. Statutory remittances are always outgoing (DEBIT), never credits.|tanzania-social-contributions.md:89 — ### Statement classification and Kiswahili terminology|PASS|
|O210|407|2. TRA debits cover PAYE and/or SDL; pension debits go to NSSF or PSSSF; WCF is a separate small debit.|tanzania-social-contributions.md:89 — ### Statement classification and Kiswahili terminology|PASS|
|O211|408|3. PAYE/SDL recur around the 7th of the following month; NSSF by the end of the following month.|tanzania-social-contributions.md:89 — ### Statement classification and Kiswahili terminology|PASS|
|O212|409|4. Swahili terms: MSHAHARA = salary; MICHANGO YA PENSHENI = pension contributions; MFUKO WA FIDIA KWA WAFANYAKAZI = workers compensation fund; PENSHENI = pension.|tanzania-social-contributions.md:89 — ### Statement classification and Kiswahili terminology|PASS|
|O213|410|5. Inbound credits labelled "NSSF PENSION" / "PENSHENI" are benefits received, not contributions paid.|tanzania-social-contributions.md:89 — ### Statement classification and Kiswahili terminology|PASS|
|O214|411|6. Irregular lump sums with "ARREARS" may include penalties — flag and request a fund statement.|tanzania-social-contributions.md:89 — ### Statement classification and Kiswahili terminology|PASS|
|O215|415|If the client provides only a bank statement and no other information:|tanzania-social-contributions.md:89 — ### Statement classification and Kiswahili terminology|PASS|
|O216|417|1. **Scan for statutory debits** — identify all outgoing payments matching Section 3 patterns (TRA, NSSF, PSSSF, SDL, WCF).|tanzania-social-contributions.md:89 — ### Statement classification and Kiswahili terminology|PASS|
|O217|418|2. **Group by type** — separate TRA (PAYE/SDL) from pension (NSSF/PSSSF) and from WCF.|tanzania-social-contributions.md:62 — ### SDL exemptions|PASS|
|O218|419|3. **Reverse-engineer the wage base where possible:**|tanzania-social-contributions.md:171 — ## When to refuse or refer|PASS|
|O219|420|   - NSSF total ÷ 20% ≈ gross wage (standard split). Employee 10% line ÷ 10% ≈ gross wage.|tanzania-social-contributions.md:171 — ## When to refuse or refer|PASS|
|O220|421|   - SDL ÷ 3.5% ≈ total gross emoluments for the payroll (only if employer has ≥10 staff).|tanzania-social-contributions.md:62 — ### SDL exemptions|PASS|
|O221|422|4. **Confirm sector** — NSSF implies private/informal; PSSSF implies public.|tanzania-social-contributions.md:171 — ## When to refuse or refer|PASS|
|O222|423|5. **Flag for reviewer:** "Payroll figures derived from bank statement amounts only. Residency, sector, NSSF split, headcount, and the WCF tariff have not been independently verified. Reviewer must confirm before filing."|tanzania-social-contributions.md:89 — ### Statement classification and Kiswahili terminology|PASS|
|O223|429|**PAYE worked figures (resident, 2026)**|tanzania-social-contributions.md:114 — ## Worked cases|PASS|
|O224|431|\| Gross wage (TZS) \| NSSF ee (10%) \| PAYE base \| PAYE due \| Net pay \| Source \||tanzania-social-contributions.md:114 — ## Worked cases|PASS|
|O225|433|\| 290,000 \| 29,000 \| 261,000 \| 0 \| 261,000 \| TRA \||tanzania-social-contributions.md:114 — ## Worked cases|PASS|
|O226|434|\| 800,000 \| 80,000 \| 720,000 \| 60,000 \| 660,000 \| TRA \||tanzania-social-contributions.md:114 — ## Worked cases|PASS|
|O227|435|\| 1,500,000 \| 150,000 \| 1,350,000 \| 233,000 \| 1,117,000 \| TRA \||tanzania-social-contributions.md:114 — ## Worked cases|PASS|
|O228|437|(Arithmetic: 720,000 → 20,000 + 20%×200,000 = 60,000. 1,350,000 → 128,000 + 30%×350,000 = 233,000.)|tanzania-social-contributions.md:114 — ## Worked cases|PASS|
|O229|441|**Thresholds and rates summary**|tanzania-social-contributions.md:35 — ## Rates, bands and thresholds|PASS|
|O230|443|\| Item \| Figure \| Source \||tanzania-social-contributions.md:180 — ## Sources|PASS|
|O231|445|\| Tax-free threshold \| TZS 270,000/month (TZS 3,240,000/year) \| TRA \||tanzania-social-contributions.md:35 — ## Rates, bands and thresholds|PASS|
|O232|446|\| Top marginal PAYE \| 30% (over TZS 1,000,000/month base) \| TRA \||tanzania-social-contributions.md:35 — ## Rates, bands and thresholds|PASS|
|O233|447|\| Non-resident PAYE \| 15% flat final \| PwC \||tanzania-social-contributions.md:35 — ## Rates, bands and thresholds|PASS|
|O234|448|\| NSSF total \| 20% (10% er / 10% ee) \| NSSF \||tanzania-social-contributions.md:35 — ## Rates, bands and thresholds|PASS|
|O235|449|\| PSSSF total \| 20% (15% er / 5% ee) [GAP — secondary] \| Public Service SSA 2018 \||tanzania-social-contributions.md:35 — ## Rates, bands and thresholds|PASS|
|O236|450|\| SDL \| 3.5%, employer ≥10 staff \| TRA \||tanzania-social-contributions.md:62 — ### SDL exemptions|PASS|
|O237|451|\| WCF \| 0.5%–0.6% [GAP — confirm] \| PwC / WCF \||tanzania-social-contributions.md:35 — ## Rates, bands and thresholds|PASS|
|O238|452|\| Minimum wage (1 Jan 2026) \| TZS 358,322/month avg; TZS 175,000 uncovered sectors \| GN 605A/2025; PKF \||tanzania-social-contributions.md:35 — ## Rates, bands and thresholds|PASS|
|O239|453|\| Corporate income tax (context) \| 30% standard; 25% newly DSE-listed 3 yrs \| PwC / TRA \||tanzania-social-contributions.md:35 — ## Rates, bands and thresholds|PASS|
|O240|457|**Penalties**|tanzania-social-contributions.md:70 — \| NSSF registration \| Employer within 1 month after becoming a contributing employer; covered employ|PASS|
|O241|459|\| Item \| Penalty \| Source \||tanzania-social-contributions.md:70 — \| NSSF registration \| Employer within 1 month after becoming a contributing employer; covered employ|PASS|
|O242|461|\| PAYE/SDL late (TRA) \| Higher of 2.5%/month (or part) of unpaid tax or 15 currency points (body corporate) + interest \| TRA \||tanzania-social-contributions.md:62 — ### SDL exemptions|PASS|
|O243|462|\| NSSF late \| 5% of unpaid amount per month or part-month \| NSSF Act Cap. 50 \||tanzania-social-contributions.md:70 — \| NSSF registration \| Employer within 1 month after becoming a contributing employer; covered employ|PASS|
|O244|466|**Test 1:** Resident, gross 800,000, private. → NSSF ee 80,000; PAYE base 720,000; PAYE 60,000; net 660,000.|tanzania-social-contributions.md:114 — ## Worked cases|PASS|
|O245|468|**Test 2:** Resident, gross 1,500,000, private. → NSSF ee 150,000; PAYE base 1,350,000; PAYE 233,000; net 1,117,000.|tanzania-social-contributions.md:114 — ## Worked cases|PASS|
|O246|470|**Test 3:** Resident, gross 290,000, private. → NSSF ee 29,000; PAYE base 261,000; PAYE Nil; net 261,000.|tanzania-social-contributions.md:114 — ## Worked cases|PASS|
|O247|472|**Test 4:** Resident, gross 600,000, private. → NSSF ee 60,000; PAYE base 540,000; PAYE = 20,000 + 20%×(540,000−520,000) = 20,000 + 4,000 = 24,000; net = 600,000 − 60,000 − 24,000 = 516,000.|tanzania-social-contributions.md:114 — ## Worked cases|PASS|
|O248|474|**Test 5:** Resident, gross 1,000,000, private. → NSSF ee 100,000; PAYE base 900,000; PAYE = 68,000 + 25%×(900,000−760,000) = 68,000 + 35,000 = 103,000; net = 1,000,000 − 100,000 − 103,000 = 797,000.|tanzania-social-contributions.md:114 — ## Worked cases|PASS|
|O249|476|**Test 6:** Non-resident, gross 4,000,000. → PAYE = 15%×4,000,000 = 600,000 (final tax).|tanzania-social-contributions.md:114 — ## Worked cases|PASS|
|O250|478|**Test 7:** Private employer, total payroll 50,000,000, 30 staff. → SDL = 3.5%×50,000,000 = 1,750,000 (employer-borne). WCF (0.6%) = 300,000 [confirm tariff].|tanzania-social-contributions.md:114 — ## Worked cases|PASS|
|O251|480|**Test 8:** Public-sector employee, gross 1,200,000, PSSSF 15/5. → PSSSF ee 5% = 60,000; PSSSF er 15% = 180,000; total 20% = 240,000 [GAP — confirm PSSSF split].|tanzania-social-contributions.md:114 — ## Worked cases|PASS|
|O252|484|- NEVER compute PAYE without the monthly gross wage.|tanzania-social-contributions.md:171 — ## When to refuse or refer|PASS|
|O253|485|- NEVER apply progressive brackets to a non-resident — non-resident employment income is a flat 15% final tax.|tanzania-social-contributions.md:171 — ## When to refuse or refer|PASS|
|O254|486|- NEVER compute PAYE on gross — always deduct the mandatory employee pension contribution first (TRA).|tanzania-social-contributions.md:171 — ## When to refuse or refer|PASS|
|O255|487|- NEVER charge SDL to an employer with fewer than 10 employees (TRA).|tanzania-social-contributions.md:62 — ### SDL exemptions|PASS|
|O256|488|- NEVER present a definitive WCF figure without confirming the current tariff with WCF [RESEARCH GAP].|tanzania-social-contributions.md:171 — ## When to refuse or refer|PASS|
|O257|489|- NEVER apply the PSSSF 15/5 split as definitive without confirming against PSSSF documentation [RESEARCH GAP].|tanzania-social-contributions.md:171 — ## When to refuse or refer|PASS|
|O258|490|- NEVER apply Mainland SDL/levy figures to Zanzibar without the Zanzibar schedule.|tanzania-social-contributions.md:62 — ### SDL exemptions|PASS|
|O259|491|- NEVER deduct more than 10% from an employee for NSSF — the employee share is capped at 10%.|tanzania-social-contributions.md:171 — ## When to refuse or refer|PASS|
|O260|492|- NEVER quantify arrears or penalties without official TRA/NSSF statements — escalate to a practitioner.|tanzania-social-contributions.md:70 — \| NSSF registration \| Employer within 1 month after becoming a contributing employer; covered employ|PASS|
|O261|493|- NEVER present figures as definitive — label as estimated and direct the client to their TRA/NSSF statements.|tanzania-social-contributions.md:171 — ## When to refuse or refer|PASS|
|O262|497|This skill and its outputs are provided for informational and computational purposes only and do not constitute tax, legal, or financial advice. Open Accountants and its contributors accept no liability for any errors, omissions, or outcomes arising from the use of this skill. All outputs must be reviewed and signed off by a qualified professional (such as a CPA, EA, tax attorney, or equivalent licensed practitioner in your jurisdiction) before filing or acting upon.|tanzania-social-contributions.md:70 — \| NSSF registration \| Employer within 1 month after becoming a contributing employer; covered employ|PASS|

## All independent case outputs

|Case|Expression|Result|Expected|Verdict|
|---|---|---|---|---|
|800000grossPAYE|paye(D(800000)*D(".9"))|60000.000|60000|PASS|
|800000grossnet|D(800000)*D(".9")-paye(D(800000)*D(".9"))|660000.000|660000|PASS|
|1500000grossPAYE|paye(D(1500000)*D(".9"))|233000.000|233000|PASS|
|1500000grossnet|D(1500000)*D(".9")-paye(D(1500000)*D(".9"))|1117000.000|1117000|PASS|
|290000grossPAYE|paye(D(290000)*D(".9"))|0.00|0|PASS|
|290000grossnet|D(290000)*D(".9")-paye(D(290000)*D(".9"))|261000.00|261000|PASS|
|600000grossPAYE|paye(D(600000)*D(".9"))|24000.000|24000|PASS|
|600000grossnet|D(600000)*D(".9")-paye(D(600000)*D(".9"))|516000.000|516000|PASS|
|1000000grossPAYE|paye(D(1000000)*D(".9"))|103000.000|103000|PASS|
|1000000grossnet|D(1000000)*D(".9")-paye(D(1000000)*D(".9"))|797000.000|797000|PASS|
|800kemployercost|D(800000)*D("1.14")|912000.00|912000|PASS|
|50mpayrollSDL|D(50000000)*D(".035")|1750000.000|1750000|PASS|
|50mpayrollWCF|D(50000000)*D(".005")|250000.000|250000|PASS|
|1.2mPSSSFemployee|D(1200000)*D(".05")|60000.00|60000|PASS|
|1.2mPSSSFemployer|D(1200000)*D(".15")|180000.00|180000|PASS|
|overtimebaseoverstatement|D(200000)*D(".20")|40000.00|40000|PASS|
|4mnonresident|D(4000000)*D(".15")|600000.00|600000|PASS|
|HESLBactual15basic1m|D(1000000)*D(".15")|150000.00|150000|PASS|
