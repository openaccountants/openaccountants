# Tanzania final-head readiness and checker-cause precision

Reviewer: 2026-11-15. Frozen HEAD `67c03fe8237c6a7de66cf43d59e1adfb94884646`. Existing final reports and manifest remain unchanged.

The final writer-run unit log was independently inspected: **494 tests in230.762s, OK**, with no skips reported. Supplemental fixture warnings remain in the original log. This is an inspected writer result, not a reviewer rerun or remoteCI/MCP result.

The final checker has9MISS/2UNREADABLE occurrences. All11exact occurrence lines were independently compared and are byte-identical to the a5ac213fd log; the individual actual-source/visual/held-context dispositions remain applicable.

**Precision correction:** the earlier VAT registration disposition described the linked sources as parsed into concatenatedURLs. Actual checker code fetches URLs individually and joins them for display. The200m/100mthresholds were independently verified in the official TRA agency page, which prints200million/100million; the exact supplementary-source/transport/parser cause is unproven without per-fetch payloads. This changes only the cause diagnosis, not the source-verification conclusion. Publication comments must preserve this distinction.

Exact hashes, source URL, comparison and log provenance are in the adjacent JSON. Source PASS remains; no mechanical exit1 is relabelled as a pass. Publication/merge hold remains.
