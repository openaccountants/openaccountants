# Validity of the preserved independent review

Reviewer: 16 November 2026. This assesses the complete earlier review chain, not a new full legal review. The actual operative source/read scopes remain 15 November.

The first complete review recorded 242 rows, 1,099 physical old blocks, 100 computed outputs and 28 independently acquired official publications. It failed 56 row checks and 20 preservation blocks through 28 named findings. The second complete review added exported-services R36, covered all 243 rows and all 1,099 blocks, and retained two residual findings. Final closure covers the six affected rows; the other candidate and ledger changes were bound to that complete correction review. No missing review unit was found. The full report tables were checked against their complete structured populations, not inferred from the pack summary alone.

The first report's 28 finding definitions and the complete resolution record were inspected. Current claims/prose and the actual correction destinations support these closures:

| Findings | Current correction inspected | Assessment |
|---|---|---|
| P01, S02, O01, V02, W02 | Actual compound-source URLs and supplementary ledger support, including NSSF wage definition, WCF contribution, VETA, Acts and subsequent amendments | Closed; names of Acts alone were not accepted as support |
| P02, S03 | Claimed 358,322 average is unconfirmed on the boundary line, not a wage floor | Closed as exclusion |
| P03 and P03-residual | Each of four car rows repeats TRA annual attribution, statutory age-column conflict, exact-five-year HOLD, and employer deduction/relief exclusion | Closed; no universal exact-five-year answer approved |
| P04 | Employer and associates nondiscrimination; actual passage costs; government subvention and enumerated allowances | Conditions restored |
| P05 | Complete VETA statutory charity test distinguished from the broader TRA formulation | Closed without substituting agency wording for statute |
| P06 | Mining AND prospecting label retained | Closed |
| P07, S04 | Calendar year, same Mainland/Zanzibar monthly PAYE bands with levy boundary, name/date workpaper fields, Kiswahili identifiers; 50 detailed wage rows rather than 46; historical increase/average held | Closed; actual current text inspected beyond historical map anchors |
| S01 | Amendment s19 replaces principal ss20–21; employment notification, minimum deduction, status/change reporting, remittance and arrears distinguished | Closed within actual scan/agency scopes |
| S05 | Actual official BILL URL and cover/notice scope; current health implementation held | Closed as bounded positive identity claim |
| O02 | ITA charity purpose/ruling conditions; separate social-development-project branch | Closed |
| O03 | Current corporate/municipal bond reference 105(2)(g) | Closed |
| O04 | Explicit TP/Pillar Two/structuring, arrears/audit/ruling, customs/excise/mining referral; original listing scenario retains 30% float while law condition is 25% | Closed; actual restored prose inspected |
| V01 | Previous-month start for expected-turnover test; linked Act timing | Closed |
| V03 | VAT25 taxable-supply gate for employee benefit exception; old fewer-than-13-seat/driving-instruction claim explicitly held | Closed |
| V04 | Applicant OR connected-person tax/return/conviction refusal and capital-goods/non-resale classification conditions | Closed |
| V05 | Original six-country EAC list explicitly historical/unverified, with no common-VAT inference | Closed as held historical context |
| V06 | Separate ss61/62/64 roles and exported-service conditions; actual application held | Closed within inspected statutory scope |
| W01 | Official 2025 sports/film/other numbering plus 2026 deletion/renaming preserves film10%, removes special sports5% | Closed; subtype/exemption/treaty conditions remain |
| W03 | Carbon106(1)(g), recovery109(3)–(6), digital numbering caution and readable research quote | Closed |
| W04 | Underlying-owner classes and treaty residence outside both states retained | Closed |
| W05 | Original digital-asset5m scenario restored with residence/platform/gross-value assumptions | Closed; independently computed150,000 withholding |
| X01 | Identified broken words repaired in current prose | Closed |
| L01 | TAA89 link beside FA2024s97 in both currency-point rows; 5/15 points and20,000 point yield100,000/300,000 | Closed with both actual sources |

The 20 first-pass failed preservation units are separately listed in `semantic-correction-continuity.json`, with actual current prose and boundary destinations. Some historical destination anchors point to a nearby or generic section. They are navigation aids, not precise proof; the earlier report explicitly says so. Current correction text and the original finding definitions establish these closures. This continuity review does not claim a new semantic re-review of all 1,099 old blocks; it verifies the complete earlier semantic review record and identical underlying original/candidate bytes, and independently examines the prior defects rather than simply trusting PASS labels.

Both earlier HOLD reports remain immutable. The precision addendum is essential: agency text supports the200m/100m VAT amounts, but the old checker-miss cause was not established. The abandoned concatenated-URL diagnosis must not be repeated.

The preserved source bodies and read scopes are substantive: actual operative clauses and neighboring exceptions, full GN605A schedule, and all seven scanned HESLB pages, rather than status codes. All seven HESLB rendered images are retained in the archived packet. This reviewer validates their provenance and earlier full visual-read record; it does not claim a new seven-page visual reread. Every current stock occurrence links to that actual body/scan chain. Current transport failures do not replace earlier supported reads or become new reads.
