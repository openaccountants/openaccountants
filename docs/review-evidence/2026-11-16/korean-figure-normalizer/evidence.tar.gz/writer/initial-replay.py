"""Offline implementation proof; never writes to the Korea owner checkout/cache."""
from pathlib import Path
import ast, functools, hashlib, html, importlib.util, json, re, subprocess, time
E=Path(__file__).resolve().parent;R=E.parent;W=R/'wt-korean-figure-parser';C=R/'parallel-chats/south-korea/cache'
sha=lambda b:hashlib.sha256(b).hexdigest()
def load(name,p):
 s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
base=subprocess.check_output(['git','show','20622011b20ddb94a981e18272213a6dcc58c00d:scripts/check-row-sources.py'],cwd=W)
(E/'baseline-checker.py').write_bytes(base)
b=load('baseline',E/'baseline-checker.py');m=load('candidate',W/'scripts/check-row-sources.py')
# Disclosed external memoization of the pure text->set function; no source or
# fetch alteration. check_text only reads each returned set in a new union.
for mod in [b,m]:mod.page_values=functools.lru_cache(maxsize=32)(mod.page_values)
controls=json.loads((R/'korean-figure-parser-diagnostic/positive-negative-controls.json').read_text())['controls']
for x in controls:x.update(candidate_found=m.found(x['target'],m.page_values(x['source'])),candidate_values=sorted(m.page_values(x['source'])))
assert all(x['candidate_found']==x['expected'] for x in controls)
(E/'32-controls.json').write_text(json.dumps(controls,ensure_ascii=False,indent=2)+'\n')
source_files={
 'https://www.law.go.kr/LSW/lsInfoR.do?lsiSeq=280405&efYd=20260701&chrClsCd=010202':'crypto-law-main.html',
 'https://www.law.go.kr/LSW/lsInfoR.do?lsiSeq=280865&efYd=20260102&chrClsCd=010202':'crypto-law-decree.html',
 'https://www.law.go.kr/LSW/lsInfoR.do?lsiSeq=282559&efYd=20260701&chrClsCd=010202':'crypto-local-law.html',
 'https://www.nts.go.kr/nts/cm/cntnts/cntntsView.do?cntntsId=7728&mi=2338':'crypto-gift-rates.html',
 'https://www.law.go.kr/lsLinkCommonInfo.do?chrClsCd=010202&lsJoLnkSeq=1017648003':'crypto-gift-allowance.html',
 'https://s.nts.go.kr/nts/cm/cntnts/cntntsView.do?cntntsId=7819&mi=2513':'crypto-foreign.html',
 'https://www.law.go.kr/LSW/flDownload.do?flSeq=123278409':'crypto-income-rate-table.gif',
}
oldbindings=json.loads((R/'korean-figure-parser-diagnostic/input-bindings.json').read_text())['record_bindings'];expected={Path(x['path']).name:x['sha256'] for x in oldbindings}
inputbindings=[];pages={}
for u,f in source_files.items():
 raw=(C/f).read_bytes();assert sha(raw)==expected[f]
 pages[u]=m.read_bytes(raw);inputbindings.append(dict(url=u,path=str(C/f),bytes=len(raw),sha256=sha(raw),text_sha256=sha(pages[u].encode())))
# The already-read statutory image's actual complete alt, not invented OCR.
raw=(C/'crypto-law-main.html').read_text();tag=re.search(r'<img[^>]*flSeq=123278409[^>]*>',raw).group();alt=html.unescape(re.search(r'alt="([\s\S]*?)"',tag).group(1))
assert sha(alt.encode())=='b4a4f18337b5ca10f993f1f530d95e16aa79098ac880d28aab869ab5380d86a5'
targets=['14,000,000','50,000,000','88,000,000','150,000,000','300,000,000','500,000,000','1,000,000,000','840,000','6,240,000','15,360,000','37,060,000','94,060,000','174,060,000','384,060,000']+[str(x)+'%' for x in [6,15,24,35,38,40,42,45]]
altobs=[dict(figure=f,before=b.found(f,b.page_values(alt)),after=m.found(f,m.page_values(alt))) for f in targets]
assert all(x['after'] for x in altobs)
(E/'actual-alt-replay.json').write_text(json.dumps(dict(alt_sha256=sha(alt.encode()),alt_chars=len(alt),complete_alt_retained_by_unchanged_extractor=alt in pages[next(iter(source_files))],observations=altobs),indent=2)+'\n')
head='321438ebf24f246badb998634af155da6592630d';g=subprocess.check_output(['git','show',head+':skills/south-korea/south-korea-crypto-tax.md'],cwd=R/'parallel-chats/south-korea/repo');assert sha(g)=='a1d3180b5d54ad730d1c4c9dfa2d9900dbd3d88664824f4be347012782884fc9'
start=time.monotonic();before=b.check_text(g.decode(),pages.get);after=m.check_text(g.decode(),pages.get)
# Explicitly hypothetical citation-only replay: direct GIF URLs replaced in a
# copied in-memory guide by the authentic same-edition HTML carrying its full alt.
# It is not a response substituted at the GIF URL and not a guide edit.
bodyurl=next(iter(source_files));bodyguide=g.decode().replace('https://www.law.go.kr/LSW/flDownload.do?flSeq=123278409',bodyurl)
bodyafter=m.check_text(bodyguide,pages.get)
(E/'actual-body-replays.json').write_text(json.dumps(dict(frozen_owner_head=head,guide_sha256=sha(g),before=before,candidate=after,hypothetical_same_edition_body_citation_only=bodyafter,memoization='External pure page_values input memoization only; no fetch or source alterations.',gif_limitation='Unchanged read_bytes incorrectly decodes GIF as text. This patch does not claim to read images or repair transport.',seconds=round(time.monotonic()-start,3)),ensure_ascii=False,indent=2)+'\n')
# Check AST-level equality of ALL existing functions except the explicitly
# modified numeric aggregator; no row policy/extraction/fetch drift.
def functions(s):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(s).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
a=functions(base);c=functions((W/'scripts/check-row-sources.py').read_text());same={k:a[k]==c[k] for k in a};assert all(v for k,v in same.items() if k!='page_values')
(E/'scope-proof.json').write_text(json.dumps(dict(base_commit='20622011b20ddb94a981e18272213a6dcc58c00d',base_checker_sha256=sha(base),candidate_checker_sha256=sha((W/'scripts/check-row-sources.py').read_bytes()),existing_function_class_ast_equal=same,added_functions=sorted(set(c)-set(a)),source_inputs=inputbindings,owner_guide_written=False,network_fetches=0),indent=2)+'\n')
# Confirm immutable owner source/evidence inputs still match after the replay.
assert all(sha(Path(x['path']).read_bytes())==x['sha256'] for x in inputbindings)
print('controls',len(controls),'all pass; actual alt',len(altobs),'all pass')
for name,r in [('frozen-current/base',before),('frozen-current/candidate',after),('hypothetical body-only citation/candidate',bodyafter)]:print(name,'rows',r[0],'MISS',len(r[1]),'UNREADABLE',len(r[2]))
