#!/usr/bin/env python3
"""Row-by-row figure check: is every figure in a linked table row on the page that row links to?

For each table row above `## Worked cases` that carries a link (or says `same`, meaning
the link of the row above), every dollar-style amount and every percentage in the row
must appear on one of the pages linked in that row. Pages are fetched with curl;
PDFs go through pdftotext, Excel files are read from their XML. A page that cannot be
read (blocked, empty, image only) is reported as UNREADABLE, never as a miss.

Worked-case arithmetic is not checked here: check-examples.py recomputes it.
A figure the page does not print but that follows from it (half of a joint threshold,
the difference of two rates) is marked in the row with the word `derived` or `computed`
(for example "USD 125,000 (derived: half of the USD 250,000 joint threshold)"); figures in
such a row are reported as derived, not as misses, and zero amounts are ignored.

Usage:
  python3 scripts/check-row-sources.py FILE...          # report, exit 1 if any miss
  python3 scripts/check-row-sources.py --changed-only   # skills/**.md changed vs origin/$BASE_REF
Writes a markdown report to $GITHUB_STEP_SUMMARY when set.
"""
import html
import io
import json
import os
import re
import subprocess
import sys
import zipfile
from decimal import Decimal
from html.parser import HTMLParser

# A URL may hold balanced brackets (gibraltarlaws.gov.gi/...(01-07-24).pdf).
LINK_RE = re.compile(r"https?://(?:[^\s()|>\"\]]|\([^\s()|>\"\]]*\))+")
# Identifiers that look like numbers but are not figures (statute and form numbers).
IDENT_RE = re.compile(
    r"(?i)\b(section|sec\.|§|art\.|article|rcw|a\.r\.s\.|ilcs|mcl|g\.s\.|r\.c\.|k\.s\.a\.|n\.d\.c\.c\.|nrs|cite=|"
    r"form|line|schedule|pub\.?|publication|notice|rev\. ?proc\.?|rev\. ?rul\.?|act|chapter|ch\.|p\.l\.|"
    r"public law|regulation|reg\.|no\.)\s*[\d.\-:()a-z]+"
)
FIG_RE = re.compile(r"\$\s?\d[\d,]*(?:\.\d+)?|\b\d{1,3}(?:,\d{3})+(?:\.\d+)?\b|\b\d+(?:\.\d+)?\s?%")
NUM_RE = re.compile(r"\d[\d.,]*\d|\d")


def table_rows(text):
    """Yield (row_text, urls) for linked table rows before ## Worked cases. `same` inherits."""
    body = re.split(r"(?m)^##\s+Worked cases", text)[0]
    last = []
    for line in body.splitlines():
        s = line.strip()
        if not s.startswith("|") or re.fullmatch(r"\|[\s:|-]+\|?", s):
            if not s.startswith("|"):
                last = []
            continue
        urls = [u.rstrip(".,;") for u in LINK_RE.findall(s) if "openaccountants" not in u]
        if not urls and re.search(r"\|\s*same\s*\|?\s*$", s, re.I):
            urls = list(last)
        if urls:
            last = urls
            yield s, urls


def figures(row):
    """Dollar amounts with a thousands separator or a $ sign, and percentages, minus identifiers."""
    t = re.sub(r"\]\([^)]*\)", "]", row)
    t = LINK_RE.sub("", t)
    t = IDENT_RE.sub("", t)
    return [f.strip() for f in FIG_RE.findall(t)]


def _value(s):
    s = s.replace("$", "").replace(",", "").replace("%", "").strip()
    try:
        return float(s)
    except ValueError:
        return None


# A space, no-break space or thin space between digit groups ("1 234,56").
# A space, no-break space, thin space or apostrophe between digit groups ("1 234,56", Swiss "80'000").
GROUP_SPACE_RE = re.compile(r"(?<=\d)[ \u00a0\u202f\u2009'\u2019](?=\d{3}\b)")


# Laws often write a rate in words ("twenty per cent", "centoventi per cento",
# "diez por ciento", "vingt pour cent", "vinte por cento", 百分之七十). These tables
# give the words for 1 to 200 in each language, so such a rate matches its digit.
def _strip_accents(s):
    import unicodedata
    return "".join(c for c in unicodedata.normalize("NFD", s) if unicodedata.category(c) != "Mn")


def _en(n):
    u = "zero one two three four five six seven eight nine ten eleven twelve thirteen fourteen fifteen sixteen seventeen eighteen nineteen".split()
    tens = "_ _ twenty thirty forty fifty sixty seventy eighty ninety".split()
    if n < 20: return [u[n]]
    if n < 100:
        t, r = divmod(n, 10)
        return [tens[t]] if r == 0 else [f"{tens[t]}-{u[r]}", f"{tens[t]} {u[r]}"]
    h, r = divmod(n, 100)
    head = f"{u[h]} hundred"
    return [head] if r == 0 else [f"{head} and {w}" for w in _en(r)] + [f"{head} {w}" for w in _en(r)]


def _it(n):
    u = "zero uno due tre quattro cinque sei sette otto nove dieci undici dodici tredici quattordici quindici sedici diciassette diciotto diciannove".split()
    tens = "_ _ venti trenta quaranta cinquanta sessanta settanta ottanta novanta".split()
    if n < 20: return [u[n]]
    if n < 100:
        t, r = divmod(n, 10)
        if r == 0: return [tens[t]]
        stem = tens[t][:-1] if r in (1, 8) else tens[t]
        return [stem + u[r]] + ([tens[t] + "tre"] if r == 3 else [])
    h, r = divmod(n, 100)
    head = "cento" if h == 1 else u[h] + "cento"
    return [head] if r == 0 else [head + w for w in _it(r)]


def _es(n):
    u = "cero uno dos tres cuatro cinco seis siete ocho nueve diez once doce trece catorce quince dieciseis diecisiete dieciocho diecinueve".split()
    veinti = "veinte veintiuno veintidos veintitres veinticuatro veinticinco veintiseis veintisiete veintiocho veintinueve".split()
    tens = "_ _ veinte treinta cuarenta cincuenta sesenta setenta ochenta noventa".split()
    if n < 20: return [u[n]]
    if n < 30: return [veinti[n - 20]]
    if n < 100:
        t, r = divmod(n, 10)
        return [tens[t]] if r == 0 else [f"{tens[t]} y {u[r]}"]
    if n == 100: return ["cien"]
    if n < 200: return ["ciento " + w for w in _es(n - 100)]
    return ["doscientos"]


def _fr(n):
    u = "zero un deux trois quatre cinq six sept huit neuf dix onze douze treize quatorze quinze seize dix-sept dix-huit dix-neuf".split()
    tens = "_ _ vingt trente quarante cinquante soixante".split()
    if n < 20: return [u[n]]
    if n < 70:
        t, r = divmod(n, 10)
        if r == 0: return [tens[t]]
        return [f"{tens[t]} et un"] if r == 1 else [f"{tens[t]}-{u[r]}"]
    if n < 80:
        r = n - 60
        return ["soixante et onze"] if r == 11 else [f"soixante-{u[r]}"]
    if n < 100:
        r = n - 80
        return ["quatre-vingts"] if r == 0 else [f"quatre-vingt-{u[r]}"]
    if n == 100: return ["cent"]
    if n < 200: return ["cent " + w for w in _fr(n - 100)]
    return ["deux cents"]


def _pt(n):
    u = "zero um dois tres quatro cinco seis sete oito nove dez onze doze treze catorze quinze dezasseis dezassete dezoito dezanove".split()
    br = {16: "dezesseis", 17: "dezessete", 19: "dezenove"}
    tens = "_ _ vinte trinta quarenta cinquenta sessenta setenta oitenta noventa".split()
    if n < 20: return [u[n]] + ([br[n]] if n in br else [])
    if n < 100:
        t, r = divmod(n, 10)
        return [tens[t]] if r == 0 else [f"{tens[t]} e {w}" for w in _pt(r)]
    if n == 100: return ["cem"]
    if n < 200: return ["cento e " + w for w in _pt(n - 100)]
    return ["duzentos"]


PERCENT_WORDS = r"(?:per\s*cent(?:um)?|percent|per\s+cento|por\s+ciento|pour\s+cent|por\s+cento)"
_WORD_VALUES = {}
for _n in range(1, 201):
    for _f in (_en, _it, _es, _fr, _pt):
        for _w in _f(_n):
            _WORD_VALUES[_w] = _n
_WORD_RE = re.compile(r"\b(" + "|".join(re.escape(w) for w in sorted(_WORD_VALUES, key=len, reverse=True))
                      + r")\s*(?:\(\s*[\d.,]+\s*\)\s*)?" + PERCENT_WORDS, re.IGNORECASE)
_ENGLISH_VALUES = {w: n for n in range(1, 201) for w in _en(n)}
_NUMBER_WORDS = {part for word in _ENGLISH_VALUES for part in re.split(r'[ -]+', word)}
_NUMBER_WORDS |= {'zero', 'a', 'half', 'thousand', 'million', 'billion', 'trillion', 'quadrillion', 'quintillion'}
_NUMBER_TOKEN = '(?:' + '|'.join(sorted(_NUMBER_WORDS, key=len, reverse=True)) + ')'
_HALF_PERCENT_RE = re.compile(
    r'\b(?P<phrase>' + _NUMBER_TOKEN + r'(?:[\s-]+' + _NUMBER_TOKEN + r')*)\s*'
    + PERCENT_WORDS + r"\b", re.IGNORECASE)
_SCALED_NUMBER_RE = re.compile(
    r"(?<![\w.,])(?P<number>(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?)"
    r"\s+(?P<scale>million|billion)\b", re.IGNORECASE)
# Consume the complete number-word run before looking it up: an unsupported
# "one thousand fifteen million" must never match its "fifteen million" suffix.
_MONEY_CARDINALS = {re.sub(r'[\s-]+', ' ', w): n for n in range(1, 1000) for w in _en(n)}
_MONEY_NUMBER_WORDS = _NUMBER_WORDS | {
    'point', 'minus', 'negative', 'plus', 'quarter', 'quarters', 'third', 'thirds',
    'sextillion', 'septillion', 'octillion', 'nonillion', 'decillion',
}
_MONEY_TOKEN = '(?:' + '|'.join(sorted(_MONEY_NUMBER_WORDS, key=len, reverse=True)) + ')'
_WORD_MONEY_RE = re.compile(
    r'(?<![\w./:\u2010-\u2015-])(?P<phrase>' + _MONEY_TOKEN
    + r'(?:[\s,\u2010-\u2015-]+' + _MONEY_TOKEN + r')*)(?![\w\u2010-\u2015-])',
    re.IGNORECASE)
_MONEY_UNIT_RE = re.compile(
    r'\s+(?:shillings?|dollars?|pounds?|euros?|rupees?|baht|rand)(?![\w\u2010-\u2015-])',
    re.IGNORECASE)
_WORD_MONEY_IDENTIFIER_RE = re.compile(
    r'\b(?:section|sec|article|art|chapter|ch|form|line|schedule|no|ref|id)[:.#]?\s*$',
    re.IGNORECASE)
_ZH_DIGITS = {"一": 1, "二": 2, "两": 2, "三": 3, "四": 4, "五": 5, "六": 6, "七": 7, "八": 8, "九": 9}


def _zh_number(s):
    if s == "百": return 100
    if "十" in s:
        a, _, b = s.partition("十")
        return (_ZH_DIGITS.get(a, 1) if a else 1) * 10 + (_ZH_DIGITS.get(b, 0) if b else 0)
    return _ZH_DIGITS.get(s)


def word_percent_values(page_text):
    """Rates the page writes in words, as numbers (20 for "twenty per cent")."""
    vals = set()
    for m in _WORD_RE.finditer(_strip_accents(page_text)):
        vals.add(float(_WORD_VALUES[m.group(1).lower()]))
    for m in _HALF_PERCENT_RE.finditer(page_text):
        words = re.sub(r'[\s-]+', ' ', m.group('phrase').lower())
        while words.startswith(('and ', 'a ')):
            words = words.split(' ', 1)[1]
        fraction = re.search(r'(?:^| )(?:a half|one half|half)$', words)
        if not fraction:
            continue
        prefix = words[:fraction.start()].strip()
        if prefix:
            if not prefix.endswith(' and'):
                continue
            whole = _ENGLISH_VALUES.get(prefix[:-4])
            if whole is None:
                continue  # An unsupported full cardinal must not become a smaller suffix rate.
        else:
            whole = 0
        vals.add(whole + 0.5)
    for m in re.finditer(r"百分之([一二两三四五六七八九十百]{1,4})", page_text):
        v = _zh_number(m.group(1))
        if v: vals.add(float(v))
    return vals


def word_money_values(page_text):
    """Whole English cardinals (1–999) times million/billion, with a money unit."""
    vals = set()
    for m in _WORD_MONEY_RE.finditer(page_text):
        if not _MONEY_UNIT_RE.match(page_text, m.end()):
            continue
        prefix = page_text[max(0, m.start() - 80):m.start()]
        if _WORD_MONEY_IDENTIFIER_RE.search(prefix) or re.search(r'\d[\s,-]*$', prefix):
            continue
        words = re.sub(r'[\s\u2010-\u2015-]+', ' ', m.group('phrase').lower())
        words = re.sub(r'^(?:and )?(?:a )?', '', words, count=1)
        cardinal, _, scale = words.rpartition(' ')
        whole = _MONEY_CARDINALS.get(cardinal)
        if whole is not None and scale in ('million', 'billion'):
            vals.add(whole * (1_000_000 if scale == 'million' else 1_000_000_000))
    return vals


def page_values(page_text):
    """Every number on the page, read the English way (1,234.56) and the European way
    (1.234,56, 1 234,56, 2,25 %), so a page that writes figures with a decimal comma is
    not reported as a miss."""
    vals = set()
    page_text = re.sub(r"\.{2,}", " ", page_text)  # dot leaders: "250,400.....3,916.09"
    found_nums = NUM_RE.findall(page_text) + NUM_RE.findall(GROUP_SPACE_RE.sub("", page_text))
    for m in found_nums:
        v = _value(m)
        if v is not None:
            vals.add(round(v, 6))
        try:
            vals.add(round(float(m.replace(".", "").replace(",", ".")), 6))
        except ValueError:
            pass
    vals |= word_percent_values(page_text)
    vals |= word_money_values(page_text)
    for m in _SCALED_NUMBER_RE.finditer(page_text):
        multiplier = 1_000_000 if m.group('scale').lower() == 'million' else 1_000_000_000
        vals.add(round(float(Decimal(m.group('number').replace(',', '')) * multiplier), 6))
    return vals


def found(fig, vals):
    v = _value(fig)
    if v is None:
        return True
    if round(v, 6) in vals:
        return True
    if fig.endswith("%") and round(v / 100, 6) in vals:  # 5.2% written 0.052 (rate sheets)
        return True
    return False


def read_bytes(raw):
    """Bytes of a fetched URL to plain text."""
    if raw[:4] == b"%PDF":
        r = subprocess.run(["pdftotext", "-layout", "-", "-"], input=raw, capture_output=True)
        return r.stdout.decode("utf-8", "replace")
    if raw[:2] == b"PK":
        try:
            z = zipfile.ZipFile(io.BytesIO(raw))
            xml = " ".join(z.read(n).decode("utf-8", "ignore") for n in z.namelist() if n.endswith(".xml"))
            # Some law sites (consigliograndeegenerale.sm) serve a ZIP of PDFs.
            pdfs = " ".join(read_bytes(z.read(n)) for n in z.namelist() if n.lower().endswith(".pdf"))
            return re.sub(r"<[^>]+>", " ", xml) + " " + pdfs
        except zipfile.BadZipFile:
            return ""
    t = raw.decode("utf-8", "replace")
    flight = next_flight_text(t)
    article = next_data_text(t)
    # Some sites (vero.fi) keep a table as JSON inside a long attribute value: keep that text too.
    attrs = " ".join(html.unescape(a) for a in re.findall(r'="([^"]{50,})"', t))
    t = re.sub(r"(?s)<script.*?</script>|<style.*?</style>", " ", t)
    return html.unescape(re.sub(r"<[^>]+>", " ", t)) + flight + article + (" " + attrs if attrs else "")


# Next.js sites (finlex.fi and others) ship the page text inside
# <script>self.__next_f.push([1,"..."])</script> blocks, not in the HTML body.
NEXT_F_RE = re.compile(r'self\.__next_f\.push\(\[\d+,("(?:[^"\\]|\\.)*")\]\)')


def next_flight_text(page):
    """The text carried in Next.js data blocks, or "" when the page has none."""
    parts = []
    for lit in NEXT_F_RE.findall(page):
        try:
            parts.append(json.loads(lit))
        except ValueError:
            continue
    if not parts:
        return ""
    return " " + html.unescape(re.sub(r"<[^>]+>", " ", "".join(parts)))


def next_data_text(page):
    """Article bodies in Pages Router JSON, excluding analytics, IDs and other metadata."""
    bodies = []

    class DataScripts(HTMLParser):
        def __init__(self):
            super().__init__(convert_charrefs=False)
            self.active = False
            self.buffer = []
            self.scripts = []

        def handle_starttag(self, tag, attrs):
            if tag == 'script':
                ids = [value for key, value in attrs if key == 'id']
                self.active = ids == ['__NEXT_DATA__']
                self.buffer = []

        def handle_data(self, data):
            if self.active:
                self.buffer.append(data)

        def handle_endtag(self, tag):
            if tag == 'script' and self.active:
                self.scripts.append(''.join(self.buffer))
                self.active = False

    parser = DataScripts()
    parser.feed(page)
    parser.close()

    def article_bodies(node):
        if not isinstance(node, dict):
            return
        for key in ('articleBody', 'body', 'content', 'detail'):
            value = node.get(key)
            if isinstance(value, str):
                bodies.append(value)
        for key in ('article', 'post', 'news', 'news_detail', 'news_detial', 'response', 'data'):
            article_bodies(node.get(key))

    for body in parser.scripts:
        try:
            data = json.loads(body)
        except (ValueError, TypeError):
            continue
        if isinstance(data, dict) and isinstance(data.get('props'), dict):
            article_bodies(data['props'].get('pageProps'))
    text = re.sub(r'(?is)<script\b.*?</script>|<style\b.*?</style>', ' ', ' '.join(bodies))
    return ' ' + html.unescape(re.sub(r'<[^>]+>', ' ', text)) if text else ''


_cache = {}

# FisconetPlus (Belgium) pages are a script shell; the same document is served as JSON,
# with base64 content (a PDF or HTML), by the public REST endpoint.
FISCONET_RE = re.compile(r"fisconet[^/]*/document/([0-9a-fA-F-]{8,})")


def fisconet_text(doc_id):
    import base64
    r = subprocess.run(["curl", "-sL", "-m", "90", "-A", "Mozilla/5.0", "-H", "Accept: application/json",
                        "https://eservices.minfin.fgov.be/myminfin-rest/fisconetPlus/public/document/" + doc_id],
                       capture_output=True)
    try:
        content = json.loads(r.stdout)["data"]["content"]["content"]
    except (ValueError, KeyError, TypeError):
        return ""
    if content.lstrip().startswith("<"):
        return html.unescape(re.sub(r"<[^>]+>", " ", content))
    try:
        return read_bytes(base64.b64decode(content))
    except ValueError:
        return ""


def fetch(url):
    """Return page text, or None when the page cannot be read."""
    if url in _cache:
        return _cache[url]
    fisco = FISCONET_RE.search(url)
    if fisco:
        text = fisconet_text(fisco.group(1))
        _cache[url] = text if len(text) >= 400 else None
        return _cache[url]
    headers = []
    if "boe.es/datosabiertos/" in url:  # the BOE open-data API answers 400 without it
        headers = ["-H", "Accept: application/xml"]
    r = subprocess.run(["curl", "-sL", "-m", "45", "-A", "Mozilla/5.0 (OpenAccountants figure check)",
                        *headers, "-w", "\n%{http_code}", url], capture_output=True)
    raw, code = r.stdout[:-4], r.stdout[-3:].decode("ascii", "replace")
    text = read_bytes(raw) if code.startswith("2") else ""
    _cache[url] = text if len(text) >= 400 else None
    return _cache[url]


def check_text(text, fetcher=fetch):
    """Return (rows_checked, misses, unreadable). misses: (figure, urls, row)."""
    misses, unreadable, n = [], [], 0
    for row, urls in table_rows(text):
        figs = figures(row)
        if not figs:
            continue
        n += 1
        pages = [fetcher(u) for u in urls]
        readable = [p for p in pages if p]
        if not readable:
            unreadable.append((urls, row))
            continue
        vals = set().union(*(page_values(p) for p in readable))
        derived = bool(re.search(r"(?i)\b(derived|computed)\b|in words on the page", row))
        for f in figs:
            if _value(f) == 0 or derived:
                continue
            if not found(f, vals):
                misses.append((f, urls, row))
    return n, misses, unreadable


def changed_files():
    base = os.environ.get("BASE_REF", "main")
    out = subprocess.run(["git", "diff", "--name-only", "--diff-filter=AM", f"origin/{base}...HEAD", "--", "skills/"],
                         capture_output=True, text=True).stdout.split()
    return [f for f in out if f.endswith(".md") and not f.endswith("README.md")]


def main(argv):
    files = changed_files() if "--changed-only" in argv else [a for a in argv if not a.startswith("--")]
    lines, total_miss = ["## Row-by-row figure check", ""], 0
    for f in files:
        text = open(f, encoding="utf-8", errors="replace").read()
        if re.search(r"(?m)^reviewed_by:", text.split("\n---", 1)[0]):
            continue
        n, misses, unreadable = check_text(text)
        total_miss += len(misses)
        lines.append(f"**{f}**: {n} rows checked, {len(misses)} figure(s) not found on the linked page, "
                     f"{len(unreadable)} row(s) whose page could not be read")
        for fig, urls, row in misses:
            lines.append(f"- MISS `{fig}` not on {' '.join(urls)} | row: {row[:160]}")
        for urls, row in unreadable:
            lines.append(f"- UNREADABLE {' '.join(urls)} | row: {row[:120]}")
        lines.append("")
    if not files:
        lines.append("No changed skill files.")
    lines.append(f"Total misses: {total_miss}. A miss is a figure that is not on the page its row links to: "
                 "fix the figure or the link, or write the figure the way the page writes it.")
    report = "\n".join(lines)
    print(report)
    if os.environ.get("GITHUB_STEP_SUMMARY"):
        with open(os.environ["GITHUB_STEP_SUMMARY"], "a") as fh:
            fh.write(report + "\n")
    return 1 if total_miss else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
