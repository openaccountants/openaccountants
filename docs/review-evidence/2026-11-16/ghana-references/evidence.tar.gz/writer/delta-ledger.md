# Ghana references: operative navigation ledger

This is a source router, not a tax computation, rates card or decision about a person's liability. The original file was exclusively a private-project bibliography. It contained no examples or method for computing a result. Its only numeric/private claims remain quoted non-operative history. Declared router therefore has zero required executable cases; none were removed or invented.

The complete source-navigation-ledger.json binds every new official navigation claim, exact short English heading, URL, actual16Novreading scope and frozen body hash. Only the following three groups are used:

1. GRA PAYE: original heading “Pay As You Earn (PAYE)” and navigation to Acts/tax guidance. PAYE rates/base/deadlines were not independently verified in this task.
2. GRA Acts: heading “Abridged Versions of The Tax Laws” separately from “Acts”, with income-tax/amendment title listings. No underlying Act/full amendment chain is claimed read. The reader must distinguish an index from the actual law.
3. SSNIT FAQs: “Social Security” and “Act 766” topic labels/navigation. No pension percentage/base/eligibility/deadline is imported from this page.

The two local route targets, ghana-pit and gh-payroll-social, exist and describe those jobs. Their source dates, rules, names, approval state and bodies are not changed or recertified. The licensing map was actually read at currentmain; the instruction merely sends code reuse to the applicable licence/provenance check, and does not grant reuse rights. No licence frontmatter was added.

All historical claims are still present: the AGPL blanket statement; project reference use; Kessir/taxcalculatorgh identity/URL; no-explicit-licence assertion and verify-before-reuse instruction;32stars twice; JavaScript/Vue; most-popular/active-maintenance/usage statements;2021through2024monthlyPAYEtables;5.5%SSNIT; bracket/SSNITintegration; public-domain/attribution claim. They are not adopted as tax authority, code provenance or permission. Source-read dates were absent from the old note; itsJune12maintenance date is preserved as such, not invented as a reading date. The historical quote and H4heading keep this distinction inside Sources.

The19-row old-topic-destinations.json maps every nonempty original line to actual final spans, not similarity guesses. Removing historical quotation prefixes and restoring its old H2heading exactly reconstructs the complete original private-project block. Names/credits/URLs and every substantive claim are literal. Original disclaimer is exact. Only the title's emdash is replaced by the ASCII source-router title, plus routine type/category/year/version/maintenance metadata. No old cases or inputs existed.

Prior research recovered before new reads: merged GhanaPR1141pack source/review summary, PR1813payroll checks/source-read repairs and held findings/person-check closure, and PR1984Ryanfold-in with its review limitations. Stored complete PR JSONs preserve those histories. None covers this references file; they are context for source selection and sibling identity, never evidence of a full review of this new router. No new country-wide review is claimed.
