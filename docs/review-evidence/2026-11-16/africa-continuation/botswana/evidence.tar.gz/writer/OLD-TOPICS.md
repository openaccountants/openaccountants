# Complete old-topic and input destination map

Exact originals at base bbab4f1a6d82cace432e6ca8eda89c98ffb1c038 were read in full. All eight country Guides and README were read for compatibility. Six siblings and README are byte-unchanged. This is a writer preservation map, not independent review. Neither original assigned Guide contained worked cases or numerical case inputs.

## bw-company-formation

| Original topic/rule/input | Final destination and disposition |
|---|---|
| Tax year 2026-27; three Acts from July 2026 | Formation Scope confirms TAA; overview Scope retains all three Acts. |
| Private:25shareholders,one shareholder/director,(Proprietary)Limited | Sources: nonusable CIPA entity hold, including statutory qualifications/counting exceptions. |
| Public:anynumber,Limited,usuallylisted | Sources: nonusable CIPA entity hold. |
| Close:five individuals,no corporate members,not banking/insurance,CC | Sources: nonusable CIPA entity hold. |
| Guarantee company:no dividends | Sources: nonusable CIPA entity hold. |
| Business name:trading style,not separate entity,it is you | Sources: nonusable CIPA entity hold. |
| External company:foreign company registering locally | Sources: nonusable CIPA entity hold; Method4 separately confirms foreign-established entity tax documents. |
| Reservation:P20online/P60counter | Sources: historical fee hold. |
| Private/public/close registration:P360/P900 | Sources: historical fee hold. |
| Guarantee/external registration:P4600/P6000 | Sources: historical fee hold. |
| Business-name registration:P150/P450 | Sources: historical fee hold. |
| Name change:P1000/P1500 | Sources: historical fee hold. |
| OBRS name reservation | Method1: intake route only; exact filing steps held under Sources. |
| Incorporation details:shareholders,officers,addresses | Ask the client first: obtain facts; exact OBRS fields and supporting documents held. |
| CIPA beneficial ownership | Intake facts retained; CIPA filing held. Method5 separately confirms conditional BURS requests. |
| Card payment;deposit at CIPA/FNB | Sources: historical payment-route hold. |
| Secretary within three months | Sources: appointment hold, including close-company accounting-officer exception. |
| BURS1 certified incorporation/director/secretary/share-capital documents | Method3/6: corrected to SI90 reg5 conditional certificate; historical checklist/form identifier held. |
| BURS biometric data | Method5: individual identification/fraud-prevention power, conditional. |
| BURS beneficial-ownership data | Method5: interface failure,written notice,notice deadline. |
| VAT registration/threshold handoff | Method7 links VAT; intake asks supply type and turnover. |
| CIPA annual return in incorporation month | Sources: nonusable annual-return hold. |
| Deregistration/restoration fees | Sources: nonusable consequence/fee hold. |
| Minimum capital | Sources: original nonusable hold retained. |
| 30-day name reservation | Sources: original nonusable hold retained. |
| One-to-three-week formation timeline | Sources: original nonusable hold retained. |
| 2025 constitution requirement | Sources: nonusable hold retained. |
| 2025 licensed-secretary requirement | Sources: nonusable hold retained. |
| 2025 twelve/twenty-four-month windows and commencement | Sources: nonusable hold retained, including later deadline extensions. |
| Current fees after October 2025 | Sources: current fee authority held. |
| Archived entity/fees/FAQ sources and November 1 read dates | Sources: retained with honest earlier-read provenance; no fresh read claimed. |
| Old TAA record/extension/objection/penalty source-only scope | Not an operative formation rule. Detailed unchanged tax Guides retain these subjects; formation Sources now declare only its actual registration scope. |

## bw-tax-overview

| Original topic/rule/input | Final destination and disposition |
|---|---|
| BURS authority | System summary row1; statutory identity definition. |
| Currency Pula/BWP/P | Method2 notation retained. |
| July1–June30 tax year | Method1. |
| Company accounting period | Method1 adds the approved substituted-period transition. |
| Resident business source and foreign PE | Summary row2 preserves it with international-transport qualification. |
| Other income by source | Corrected summary row2 to s14 worldwide resident income and temporary-resident exception; old wording unsupported. |
| Individual27.5%aboveP400000,nilP48000 | Summary row3 with lower-band/nonresident conditions. |
| Company24.5% | Summary row4 with special categories and period condition. |
| VAT14% | Summary row5 with supply classification. |
| Ordinary VAT threshold P1million | Summary row5 with actual/forecast,aggregation,exceptional-turnover and special-category conditions. |
| Individual return September30 | Summary row6 adds s124 exceptions. |
| Company return four months | Summary row7 adds nil/loss condition. |
| VAT return28days | Summary row8 includes payment. |
| VAT two-monthly/monthly periods | Summary row8 retains them and adds remote-quarterly/reverse-charge exceptions. |
| PAYE/withholding14days | Summary row9 with month/payment and remittance-return conditions. |
| Formation route | Method3; explicit CIPA completion hold. |
| Personal income-tax route | Method3. |
| Company-tax route | Method3. |
| VAT route | Method3. |
| Payroll route | Method3. |
| Cross-border route | Method3. |
| Transfer-pricing route | Method3. |
| Acts13/14/15 commencement | Scope; SI93/SI91/SI95 with VAT exceptions. |
| Cap52:01/50:03 replaced | Method4 preserves repeal and savings. |
| Late-payment penalty waiver12months | Method4 clarifies end date and scope. |
| Interest still runs | Method4 clarifies simple1.5%/month or part and s41(7) exception. |
| Old website22%,12%,P500000 | Method4 retains only as historical discrepancies. |
| Earlier broad ITA research and SI92/SI93 | Sources now state actual overview read scope; detailed unchanged siblings retain their broader earlier scope. |
| Earlier broad TAA/SI90 research | Sources now state actual scope supporting this overview. |
| Earlier broad VAT/SI94/SI95 research | Sources now state actual headline/period/registration scope; detailed VAT owns supply detail. |
| Earlier TaxTable notes,Examples4/5/14,housing,allowances | Sources preserve prior read without a re-read claim; detailed income/payroll routes retained. |
| Capital transfer-tax hold | Sources nonusable hold and referral scope retained. |
| Customs Amendment2026 detail hold | Sources nonusable hold and referral scope retained. |

## Case inputs

| Guide | Original cases | New facts and inputs | Recomputed result |
|---|---|---|---|
| Formation | None | Existing Botswana company; unregistered; potentially taxable activity; no extension;21-day window;17 whole days elapsed;reg5 document condition |21−17=4 days remain; no calendar-date opinion |
| Overview | None | Registered supplier; standard-rated domestic supply; no exemption/zero rating/special rule; P1000 net;14% | VAT P140; inclusive P1140; no input-tax/registration opinion |

Removed and why: no old legal topic removed. CIPA law/fees/OBRS instructions move to explicit nonusable holds because their current official text cannot be read. The unconditional old BURS document list is replaced by SI90 regs5/8. The overview source-basis description is corrected to s14. Neither final file is25% shorter. Lost content restored:0 (writer comparison only; independent reviewer must make its own determination).
