# Independent Botswana source review

Reviewed head `ee5814f8b8ab580b1930244b1bc7b7eeb4faf627`. Reviewer: separate Codex agent that wrote Zimbabwe, not the Botswana writer. This is independent AI source review, not accountant approval.

## Figures and rules checked

All35ledger rows checked:15formation and20overview. Read actual operative paragraphs, commencement orders and neighboring exceptions in the cached official BURS ITA/TAA/VAT bundles, plus the BURS Registration article. All four raw-source SHA256 values match the writer source inventory. Existing primary-source caches were reused; no HTTP status or URL was treated as a substantive read. The source-read scope below is actual, not a whole-document claim.

TAA:s2relevant definitions,ss6-11,41;SI90regs1,3-12,21,28-30,33-34;SI91paras1-2. ITA:ss2,7-8,13-14,45,123-124,138-140,143-144;Sch1PtIparas1-5;SI92reg51(9)-(11);SI93paras1-2. VAT:ss7-15,54-55,64-67,87-88;Sch5;SI95paras1-3. BURS Registration:substantive historical document lists/BURS1 wording and official e-Tax portal href in cached HTML.

| ID | Authority actually read | Assessment |
|---|---|---|
| F01 | TAA SI91 para2 and SI90 reg1 | Commencement1July2026 confirmed; formation scope does not pretend company-law commencement verified. |
| F02 | TAA6(1) | Potential liability/withholding agent triggers and already-registered exclusion confirmed. |
| F03 | TAA6(2) | Nonresident only-final-withholding exception correctly limited to tax registration. |
| F04 | TAA6(3),7(1) | Pre-activity licence-related application permitted; Guide makes no unconditional grant promise. |
| F05 | TAA6(4)-(5) | Approved form/evidence,21days and extension confirmed; tax-specific registrations remain subject to7(4). |
| F06 | SI90reg5 | Botswana company number; certified certificate conditional on failed CIPA-interface confirmation. |
| F07 | SI90reg8(1)-(4),9 | Foreign formation/existence certificate, certified English translation and local CIPA certificate; foreign establishment definition correctly distinguished from tax residence. |
| F08 | SI90reg10 | Individual biometrics permissive and identification/fraud-specific, not universal upload. |
| F09 | SI90reg11 | Interface information unavailable, written notice and specified notice deadline all retained. |
| F10 | SI90regs28-29; BURS registration raw HTML | Approved manner/paper/electronic and official e-Tax portal link confirmed; exact current form/screens held. |
| F11 | BURS Registration substantive article | BURS1 and old2007/2011 requirements confirmed historical, not substituted for new reg5. |
| F12 | TAA7(1)-(3),(6)-(7) | Registration outcome/certificate and certificate effective date confirmed; no promise of automatic CIPA status. |
| F13 | TAA7(4)-(5) | No further registration forms where7(4)applies; necessary extra information may be requested. |
| F14 | TAA10-11 | Only oneTIN across tax laws; written issue/use conditions read. |
| F15 | TAA6(4)(c),SI90reg5; Decimal recomputation | 21minus17=4; whole-day hypothetical avoids unsupported calendar-date calculation. |
| O01 | SI93para2,SI91para2,SI95paras2-3 | Three1July2026commencements confirmed with explicit deferred inbound-tourism/platform provisions. |
| O02 | ITA2,45(1)-(8) | July-June definition and company accounting/transitional periods confirmed. |
| O03 | ITA144(c),SI92reg51(9)-(10) | Specific continuing approved substituted-period grandfathering uses commencement of period; no unsupported apportionment. |
| O04 | TAA2 CommissionerGeneral definition | BURS identity reference confirmed. |
| O05 | ITA7(6),14(1)-(4) | Residents other than temporary residents worldwide gross income; exempt/final-tax exclusions read. |
| O06 | ITA14(3) | Nonresident/temporary resident only Botswana-source income confirmed. |
| O07 | ITA8(4)-(5) | Resident business source deeming foreign-PE exception and international-transport override retained. |
| O08 | ITA Sch1PtIpara1 | P48000nil;27.5%excessoverP400000; resident/nonresident distinction and lower bands confirmed. |
| O09 | ITA Sch1PtIpara3,144(h),SI92reg51 | 24.5%general, special mining/IFSC/mutualassociation categories and continuingagreements/periodqualifications confirmed. |
| O10 | VAT7(1)-(3),8-11 | 14%standard and zero/exemptclassification confirmed; computation basis is supply value. |
| O11 | VAT12(1)-(5),13;Sch5para2 | P1000000ordinarythreshold actual12monthsorless/forecast12, associate discretion and exceptional-turnover/special-category conditions confirmed. |
| O12 | ITA123-124 | Three months/ordinary30Sep; singleemployer and other exclusions unlessrequested; overwithheld election confirmed. |
| O13 | ITA123(1)-(3) | Company fourmonths and nil/loss filing confirmed. |
| O14 | VAT54(1)-(9) | A/Btwo-month,Cmonthly; remote-only supplier quarterly; government/largeunregistered reversecharge two-calendar-month exception confirmed. |
| O15 | VAT65-66,67 | 28day return and domestic-period payment confirmed; separate import procedure read, not generalized. |
| O16 | ITA138(1)-(6) | Monthofwithholdingincome paid;14daysaftermonthend; remittancereturnonpayment confirmed. |
| O17 | ITA143-144;VAT87-88 | Repeals/savings confirmed; currentheadlinecorrections do not purport to prove historic websites current. |
| O18 | SI90reg33;SI91para2 | 12month latepaymentpenaltywaiver1July2026through30June2027 confirmed; no interest waiver. |
| O19 | TAA41(1)-(9);SI90reg21 | Simple1.5%eachmonthorpart and writtennotification/fulltimelypayment exception confirmed. |
| O20 | VAT7(2)-(3);Decimal recomputation | 1000times0.14=140;inclusive1140 under explicit standardratedregistered assumptions. |

## Preservation and cases

Read both exact originals from origin/main and both final Guides. Independently checked all65old-topic destination rows:32formation and33overview. All six old legal forms, every old fee/payment route, name/OBRS steps, secretary/accounting-officer/annual-return topics, minimumcapital/name-reservation/timeline and2025transition questions are retained as explicit nonusable holds or supported tax-onboarding deltas. The original source-only broad research references are not misrepresented as current substantive formation rules. Overview retains all prior tax/rate/filing/topic routes and both capital-transfer/customs holds. No original worked cases existed. Recomputed both new cases independently using Decimal:21-17=4;P1000*14%=P140;inclusiveP1140. No old numerical case input was removed or changed. No human name, approval, credit or stampedCTA changed.

## Fixes made or required

No substantive defect found in the35operative ledger rows at these exact Guide hashes. No Guide edited by this reviewer. Existing local machine checks were examined as supporting evidence, not substituted for this source review, and were not rerun merely for a new wrapper/hash.

## Items still not confirmed

Current CIPA company-law eligibility, fees, live OBRS steps/payment methods, annual-return/secretary/constitution/transition requirements and other listed formation topics remain unverified and explicitly unusable. This review neither verifies those held legal claims nor upgrades the formation deliverable to a complete incorporation procedure. Current approved BURS registration form identifier/screens are held; procedure stops if they cannot be identified. Capital-transfer/customs detail and later commencement of deferred VAT provisions remain outside confirmed overview coverage.

Formation is acceptable only as an explicitly partial BURS onboarding/preparation draft. A complete incorporation Guide still needs the CIPA source work; publication must retain that draft/hold status. The generated README remains unchanged and its broad ready label is stale, as both writer and router disclose. No merge/push/PR recommendation or accountant approval is implied.
