# Writer figure ledger: et-tax-overview

Read date: 2026-11-16. Writer inventory, not an independent review or accountant approval. English quotations are from an enacted bilingual original; Amharic quotations retain source characters. Every row identifies the rule, its destination, operative paragraph, source and limitations. Source-document captures stay local.

| ID | Guide section | Figure or rule | Act/article | Official URL | Short exact original-language quote | Applicability/read scope | Read on |
|---|---|---|---|---|---|---|---|
| T01 | Who / Base | ETB and federal authority/customs routing | 979 gazette; Ministry and Customs official identity | https://justice.gov.et/wp-content/uploads/2025/02/%E1%8A%A0%E1%8B%8B%E1%8C%85-%E1%89%81%E1%8C%A5%E1%88%AD-979-2008.pdf | "የፌዴራል የገቢ ግብር አዋጅ" | ETB/Birr appears throughout rates; institutional routing retained, no regional/customs computation | 2026-11-16 |
| T02 | Rate table | 30% ordinary body business-income tax | 979 art. 19(1) | https://justice.gov.et/wp-content/uploads/2025/02/%E1%8A%A0%E1%8B%8B%E1%8C%85-%E1%89%81%E1%8C%A5%E1%88%AD-979-2008.pdf | "ሰላሳ በመቶ (፴%)" | Neighbouring arts18to20 read; applies to taxable income, not turnover/final liability | 2026-11-16 |
| T03 | Rate table | LLP/registered fund corporate-tax exception | 1395 art. 2(10), new979art19(3),(4) | https://www.hopr.gov.et/admin/Files/2026/4/8/5fc57d68-d0f6-4bf1-91b4-5b23abd0df72%E1%8C%88%E1%89%A2%20%E1%8C%8D%E1%89%A5%E1%88%AD%20%201395.pdf | "shall not be subject to corporate income tax" | Distribution withholding/other duties remain; complete new limbs read | 2026-11-16 |
| T04 | Rate table / example | Monthly employment bands0/15/20/25/30/35%, thresholds2k/4k/7k/10k/14k | 1395 art. 2(6), replacing979art11 | https://www.hopr.gov.et/admin/Files/2026/4/8/5fc57d68-d0f6-4bf1-91b4-5b23abd0df72%E1%8C%88%E1%89%A2%20%E1%8C%8D%E1%89%A5%E1%88%AD%20%201395.pdf | "Over 14,000" | All six rows read; top slice only; example salary30,000 unchanged | 2026-11-16 |
| T05 | Rate table / example | VAT15%, other than zero-rated taxable supplies | 1341 art.8(1)to(3) | https://www.hopr.gov.et/admin/Files/2026/1/21/237b0abc-d9d2-4749-96a8-7cf2ae7dbcf91341-2016%20%E1%8B%A8%E1%89%B0%E1%8C%A8%E1%88%9B%E1%88%AA%20%E1%8A%A5%E1%88%B4%E1%89%B5%20%E1%89%B3%E1%8A%AD%E1%88%B5%20%E1%8A%A0%E1%8B%8B%E1%8C%85.pdf | "in any other case 15 percent" | Standard sale100,000=>15,000; no net-return/invoicing/exemption ruling | 2026-11-16 |
| T06 | Rate table / Filing | CategoryA annual return4months and financial statements | 979art83(4)(a),(5)(a), renumbered87 | https://justice.gov.et/wp-content/uploads/2025/02/%E1%8A%A0%E1%8B%8B%E1%8C%85-%E1%89%81%E1%8C%A5%E1%88%AD-979-2008.pdf | "ባሉት የአራት ወራት ጊዜ" | Taxpayer actual year-end; no automaticGregorian7Novdate | 2026-11-16 |
| T07 | Rate table / Filing | Monthly VAT including nil; Nehase/Pagumen combined | 1341arts2(1),58(1),(2) | https://www.hopr.gov.et/admin/Files/2026/1/21/237b0abc-d9d2-4749-96a8-7cf2ae7dbcf91341-2016%20%E1%8B%A8%E1%89%B0%E1%8C%A8%E1%88%9B%E1%88%AA%20%E1%8A%A5%E1%88%B4%E1%89%B5%20%E1%89%B3%E1%8A%AD%E1%88%B5%20%E1%8A%A0%E1%8B%8B%E1%8C%85.pdf | "whether or not the person has an amount" | Full paragraphs/neighbor58(3) read; not a procedure for unregistered reverse-charge filers | 2026-11-16 |
| T08 | Filing | VAT payment at required-return date | 1341art59(1) | https://www.hopr.gov.et/admin/Files/2026/1/21/237b0abc-d9d2-4749-96a8-7cf2ae7dbcf91341-2016%20%E1%8B%A8%E1%89%B0%E1%8C%A8%E1%88%9B%E1%88%AA%20%E1%8A%A5%E1%88%B4%E1%89%B5%20%E1%89%B3%E1%8A%AD%E1%88%B5%20%E1%8A%A0%E1%8B%8B%E1%8C%85.pdf | "on the date that the VAT return" | Read in local cached official PDF with58and59neighbours | 2026-11-16 |
| T09 | Base | Residentworldwide; nonresidentEthiopiansource | 979arts5to8, especially7 | https://justice.gov.et/wp-content/uploads/2025/02/%E1%8A%A0%E1%8B%8B%E1%8C%85-%E1%89%81%E1%8C%A5%E1%88%AD-979-2008.pdf | "በኢትዮጵያ ውስጥ እና በማናቸውም" | Recovered primarytext read; officialMoJPDFcross-check; no inventedresidencedayrule | 2026-11-16 |
| T10 | Base | IndividualdefaultHamle1toSene30; bodyaccountingyear; permittedalternative/transitionalperiod | 979art2(21),art28(now30) | https://justice.gov.et/wp-content/uploads/2025/02/%E1%8A%A0%E1%8B%8B%E1%8C%85-%E1%89%81%E1%8C%A5%E1%88%AD-979-2008.pdf | "ለድርጅት ሲሆን የድርጅቱ የሂሳብ ዓመት" | Bodyperiodcorrection; Gregorianconversionnonusablehold | 2026-11-16 |
| T11 | Base | Ordinaryamendmentincomecommencement8July2025 | 1395art4(3); neighbours4(1),(2) | https://www.hopr.gov.et/admin/Files/2026/4/8/5fc57d68-d0f6-4bf1-91b4-5b23abd0df72%E1%8C%88%E1%89%A2%20%E1%8C%8D%E1%89%A5%E1%88%AD%20%201395.pdf | "as of July 8, 2025" | SeparateAMT/withholdingdatesread; no universaleffective-dateassumption | 2026-11-16 |
| T12 | Table/Filing | 979art83=>87,28=>30 | 1395renumberingandart2(33) | https://www.hopr.gov.et/admin/Files/2026/4/8/5fc57d68-d0f6-4bf1-91b4-5b23abd0df72%E1%8C%88%E1%89%A2%20%E1%8C%8D%E1%89%A5%E1%88%AD%20%201395.pdf | "or the renumbered Article 87" | Originalandamendednumbersidentified | 2026-11-16 |
| T13 | Workedcases | VAT100,000->15,000; employment30,000->8,450 | VAT8; amendedIncome11 | https://www.hopr.gov.et/admin/Files/2026/4/8/5fc57d68-d0f6-4bf1-91b4-5b23abd0df72%E1%8C%88%E1%89%A2%20%E1%8C%8D%E1%89%A5%E1%88%AD%20%201395.pdf | "2,001-4,000" | Originalinputsunchanged; lower300+600+750+1200=2850; top16000*.35=5600; tax8450 | 2026-11-16 |

## Complete original-topic destination map

| Original topic | Destination | Disposition |
|---|---|---|
| Federaltaxsystem/admin2024-25reforms | Who/Base/Sources | Federalroutingandamendedlawsretained; no comprehensivenessclaim |
| Budgetyear8Julyto7JulyHamle1Sene30 | Base/Notyetconfirmed | Correctedbodyaccountingyear; actualGregorianconversionheld |
| ETBcurrency | Who | Retained |
| MOR/customscommission | Who/Crossborder | Retained |
| Residentsworldwide/nonresidentEthiopiansource | Base/Crossborder | Retainedwithscopeinputs |
| PIT35% | Table/example | Top-sliceconditionandfullbandsforcase |
| CIT30% | Table/handoff | Confirmedordinaryrate; statutoryLLP/fundexceptions |
| VATexists15% | Table/example | Retainedwithtaxable/notzeroorexemptcondition |
| CategoryA4months/7Novemberclaim | Table/Filing/hold | Fourmonthsconfirmed;bodyactualyear-endandGregorianconversioncorrected |
| VATmonthly/followingmonthend | Table/Filing | Retainedwithcalendaraccountingmonthandnilfilings |
| VAT100,000=>15,000case | Workedcases | Allinputsoutputsunchanged |
| Employment30,000=>8,450case | Workedcases | Allinputsoutputsunchanged; actualJuly8commencement |
| 979/1395/1341sourceentries | Sources | Officialactualreadscopeupdated |
| 1434/2026sourceentry | Penalties/Notyetconfirmed | Topicretainedonexplicitnon-usablehold;nofictitiousfreshread |
| 30%rateunconfirmed | Table | ResolvedfromofficialMoJgazetteart19(1) |
| Generalreferencedisclaimer | Finalparagraph | Byte-exactpreserved |

## Non-usable holds

SpecificGregorianfiscal-year/due-dateconversion; authenticatedefilingfieldsandpaymentreferences; operative1434/2026penalty/interestcalculationforanyspecificcase.

## Removed and why

No original tax/legal topic or case input removed. Unsupported assertions are replaced by sourced conditions or explicit non-usable holds. Boilerplate source rows not supporting the job were replaced by actual scoped authority. Both files are larger than main, so the >25% reduction rule is not triggered. No human credits, approvals, licence identifiers or CTAs were changed.
