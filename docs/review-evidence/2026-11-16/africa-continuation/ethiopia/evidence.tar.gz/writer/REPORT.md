# Ethiopia writer candidate

Candidate head: `111129658b5a50a6344590e03a1fdf32fc6d30ee`. Base: `bbab4f1a6d82cace432e6ca8eda89c98ffb1c038`.

Exact scope: the two Ethiopia files in candidate.json. Both remain tier 2, with no accountant approval asserted. Separate independent review is required before publication. No push, PR, merge, deployment or production action performed.

## Corrected

| Old | New | Official source |
|---|---|---|
| Approximate30-day name reservation, unverified | Directive requires cleared business name registration within6months after issue, following authentication/TIN steps | Directive935/2022art5(3),(4): https://www.motri.gov.et/sites/default/files/resource/COMMERCIAL%20REGISTRATION%2C%20LICENSING%20AND%20POST%20LICENSING%20INSPECTION%2C%20NO.%209352022_0.pdf |
| PLCminimum1or2members conflated | OrdinaryPLC2to50; one-memberPLCseparate statutoryform | Code495,534to537: https://justice.gov.et/wp-content/uploads/2025/02/%E1%8A%A0%E1%8B%8B%E1%8C%85-%E1%89%81%E1%8C%A5%E1%88%AD-1243-2013.pdf |
| Companycapital/foreigncapital broadly unverified | Scoped codecapital/memberrules read; foreigncapital exceptions and specialtrade/zone holds attached | Code247,248,495,496,499,535; Investment9: https://justice.gov.et/wp-content/uploads/2025/02/%E1%8A%A0%E1%8B%8B%E1%8C%85-%E1%89%81%E1%8C%A5%E1%88%AD-1243-2013.pdf ; https://ldi.gov.et/wp-content/uploads/2026/04/Investment-Proclamation-Proc-No.-1180_2020.pdf |
| Every taxpayer uses8Julyto7July | IndividualdefaultHamle1toSene30; bodytaxyearisitsaccountingyear | 979art2(21),28: https://justice.gov.et/wp-content/uploads/2025/02/%E1%8A%A0%E1%8B%8B%E1%8C%85-%E1%89%81%E1%8C%A5%E1%88%AD-979-2008.pdf |
| Automatic7Novembercompanyfilingdate | Fourmonthsafteractualtaxyear-end; exactGregorianconversionheld | 979art83(4),(5),renumbered87: https://justice.gov.et/wp-content/uploads/2025/02/%E1%8A%A0%E1%8B%8B%E1%8C%85-%E1%89%81%E1%8C%A5%E1%88%AD-979-2008.pdf ; https://www.hopr.gov.et/admin/Files/2026/4/8/5fc57d68-d0f6-4bf1-91b4-5b23abd0df72%E1%8C%88%E1%89%A2%20%E1%8C%8D%E1%89%A5%E1%88%AD%20%201395.pdf |
| Corporate30%unconfirmed and unconditional | Ordinarybody30%readfromart19(1), with amendedLLP/fundexception | https://justice.gov.et/wp-content/uploads/2025/02/%E1%8A%A0%E1%8B%8B%E1%8C%85-%E1%89%81%E1%8C%A5%E1%88%AD-979-2008.pdf ; https://www.hopr.gov.et/admin/Files/2026/4/8/5fc57d68-d0f6-4bf1-91b4-5b23abd0df72%E1%8C%88%E1%89%A2%20%E1%8C%8D%E1%89%A5%E1%88%AD%20%201395.pdf |
| RetainedVAT180,000/monthcaseassertedcurrentregistration | Inputs/arithmeticretained; currentregistrationconclusionnon-usablependingDirective1104/2025 | VAT12: https://www.hopr.gov.et/admin/Files/2026/1/21/237b0abc-d9d2-4749-96a8-7cf2ae7dbcf91341-2016%20%E1%8B%A8%E1%89%B0%E1%8C%A8%E1%88%9B%E1%88%AA%20%E1%8A%A5%E1%88%B4%E1%89%B5%20%E1%89%B3%E1%8A%AD%E1%88%B5%20%E1%8A%A0%E1%8B%8B%E1%8C%85.pdf |

## Preservation and scope

The ledgers include a complete original-topic destination map. Both files grew; no25%reduction. All four original worked-case inputs/outputs remain, plus a formation decision case. No human credits, approvals, identifiers or protectedCTAs changed. Sibling retained-note inconsistencies were observed but not edited outside assignment.

## Validation

- skill_checks: all checks pass for bothfiles; corresponding run_checks result has no findings.
- validate-guides changed-only/no-index:2guides,0warnings at finalhead.
- check-examples --require:5blocks,0failures,0missing; examples unchanged by last boundary-label correction.
- syncintegrityaudit/strictmetadata:2sourceguides,0errors,0warnings at finalhead.
- Row-sourcechecker, unmodifiedmodule using actualcachedofficialtexts/webcaptures:10rows,0misses,0unreadable at finalhead. Initial2misses on derived3,000slice widths were corrected by printing originalbandboundaries; failedoutputpreserved.
- Calculatorquotecheck changed-only passed.20calculatorquotetests passed;2copyruletests passed.
- Earlier failures preserved: sparsemissingMCP/workflowdependencies; pytestunavailable (these are unittesttests); copytestmissing53sparsefiles resolved bymaterializingexactunchangedcopydependencies. No source/testscriptmodified.

## Non-usable holds

Directive1104/2025/currentVATregistrationoutcome; domestic2to4weekserviceclaim; universalconstitutionallanguage/articlesrequirements; currentfees/authenticatedfields/paymentreferences; annuallicencerenewalfrequency/exactdate; sector/branch/tradezonebranches; exactGregorianperiod/due-dateconversion; specific1434/2026penalty/interestcomputation. TheseholdsareexplicitinGuidesandledgers.

## Moved

No files moved. Existingtopics retained or held at destinations in ledgers.

## Not moved

No unassignedcountry/siblingfileorprotectedcredit moved or edited.

Written by Codex (world wave). Not reviewed by an accountant.
