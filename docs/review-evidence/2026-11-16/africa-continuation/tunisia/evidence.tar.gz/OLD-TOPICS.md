# Original topic destinations

Original exact Guide blob: 52029a8a3a1d04ec8023eb27e980c31b93d0634e

| # | Original topic | Final destination/status | Ledger |
|---|---|---|---|
| 1 | Entityoverview SARL/SA/SUARL | Compare forms; threeoptionsfullformationmethod | T02–T16 |
| 2 | One-stopshopregistry/investmentagency | Prepareandregister1–5; currentAPII/RNEprocessdistinguished | T17–T33 |
| 3 | SARL2+shareholders | Compareforms2–50withupperboundexception | T02–T03 |
| 4 | SARL1+manager | Compareformsnaturalmanageroneormore | T06 |
| 5 | SUARLsinglemember | Compareformssingle naturalorlegalplus2019conditions | T07–T09 |
| 6 | SA7shareholders | Compareformsminimum7 | T10 |
| 7 | SA3fornonpublic | Corrected: no3shareholderexception;board3different | T10,T15 |
| 8 | SAboardofdirectors | Compareformsboard3–12and2tieroption | T15 |
| 9 | SARL1000minimum | Corrected: actfixedno1000statutoryfloor;case2chosen1000notminimum | T04–T05,T44 |
| 10 | SA5000nonpublic | Confirmedlateststatutoryedition;Compareformsandcase1 | T11,T43 |
| 11 | SA50000public | Confirmedlateststatutoryedition;Compareformsandcase1 | T11–T12,T43 |
| 12 | RNEincorporation | Prepareandregister3–5C012/C004BOandtaxcard | T25–T33 |
| 13 | APIIindustryservices | Prepareandregister1;declarationoptionalnotuniversal | T17–T19 |
| 14 | APIAagriculture | Prepareandregister1activitydependentaccepteddeclarationroute | T19 |
| 15 | ONTTtourism | Prepareandregister1activitydependentaccepteddeclarationroute | T19 |
| 16 | Typical5–10workingdays | ExplicitnonusableholdSources;24hpublicationnotformationpromise | T33 |
| 17 | AnnualfinancialstatementsTunisianaccountingsystem | AccountssectionSARL/SUARL/SApackagesandSA201system | T35–T36 |
| 18 | Financialswithtaxreturn | Explicitunconfirmedtaxattachmenttopic;linkedcorporatetaxGuide;RNEdepositseparate | T41,T46 |
| 19 | AnnualISreturn25March | Retainedannualtaxcompliancetask/link;notindependentlyconfirmedhere;nooperativefilingdateasserted | T46 |
| 20 | Audited25Junefiling | Unsafeblanketextensionwithdrawn;taxGuideprovisional/amendmentmethodlinked;explicitunconfirmedhandoff | T46 |
| 21 | Advanceinstalmentsduringyear | Retainedlinkedcorporatetaxmethod;notindependentlyconfirmedinformationupdate | T46 |
| 22 | SAstatutoryaudit | Accounts/auditsectionsharecompanynoordinaryexemption | T37 |
| 23 | Othercompanysizethresholdsaudit | Accounts/auditfull2of3/firstperiod/cessation/qualification/definitions/statute/shareholderoverride | T37–T40 |
| 24 | Approxconfirmationmarkers | Replacedoperativeconfirmationwhereactualsource;explicitnonusableholdsremaining | T01,T45–T46 |
| 25 | Originalcases/refusals/caseinputs | None inoriginal;2newdecisioncasesnotreplacement;currentreferralsadded | T43–T46 |
| 26 | Humancredits/approval/license/CTA | Originalhasnoperson/approver/CTA;licensebytepreserved;tier2;approvedirppsiblinguntouched | Protectedbinding |
