# Tunisia formation writer checkpoint

Exact assigned file: skills/tunisia/tn-company-formation.md. Approved irpp-calculation.md and every other Tunisia Guide are unchanged.

Content head: 5eb724a12b8bbd83ea5d346ab85fabda71c1910f
Guide SHA256: bc0c7fd3b91eb9202e263eaa0ee70e3a0087460f651d61d998eb6509ab90c804
Main: bbab4f1a6d82cace432e6ca8eda89c98ffb1c038
Branch: world/codex-tunisia-2026-11-16-africa-continuation

The full formation job now compares SARL, SUARL and SA eligibility, capital and governance, then sets out name/activity routing, premises and signed constitutive documents, fiscal identification, beneficial-owner declaration, RNE dossiers, fees/deadlines and annual obligations. The older TND1,000 SARL minimum is corrected to constitutive-act-fixed capital; the three-shareholder private-SA suggestion is corrected to seven; the 5,000/50,000 SA capital floors are confirmed in the identified Code. RNE fee50TND and30-day triggers are distinguished from total cost/processing time. APII declaration exceptions are explicit, and current2026 SARL checklist followed.

Company law is labeled by its latest confirmed official French2022 edition and Arabic text through2019; no2026consolidation is claimed. The current procedural source includes an APII checklist dated31August2026. The native Arabic/French article128 discrepancy was visually checked and held nonusable. Five-to-ten-day total processing, full cost, authenticated portal field names and case-specific foreign permissions remain nonusable. Annual IS/advance/financial-tax-attachment topics are retained through the unchanged corporate-tax Guide with no independent tax-deadline confirmation claimed here.

46 ledger rows,26 original-topic destinations,2 new decision examples. Original had no case inputs, human credits or protected CTA. License preserved. No professional approval added.

Required local checks on the actual content head: skill_checks {}, validate-guides one changed Guide/zero warnings, two oa-check blocks/zero failures, sync zero errors/warnings, calculator quotes pass,20 calculator-quote tests and2 copy tests pass. Row-source checker checked five rows/no unreadable sources; four numeric-parser falsepositives individually reconciled in evidence/ROW-SOURCE-RECONCILIATION.md. Initial read-scope formatting failure and example-block syntax failure are preserved in validation records and corrected. Required checks were not rerun for evidence-only wrapper changes.

Independent source review accepted all46ledgerrows,26oldtopics andbothcases with noopenfindings. The three canonical reviewer files are preserved byte-exact in the bundle. Writer does not self-certify. Raw full sources remain in local source-cache. Publication is authorized after this packaging; remote readiness requires all six CI checks at the final pushed head. No merge or auto-merge authorized.
