# Applicability and recovery

Recovery before rewriting: Nov1 Tunisia source report read; it contains tax-code snippets, no completed operative formation-law review. Original whole Tunisia pack read for compatibility; approved irpp-calculation.md excluded from edits. Current public main bbab4f1a6d82cace432e6ca8eda89c98ffb1c038 and current instructions/template reused once for unchanged context.

Statutory edition: official French CSC updated10Feb2022; CMF Arabic PDF contains2019amendments. Government2019-47art4 and Finance2007-69art12 operative replacements were actually read, alongside their neighboring/final clauses and confirming code provisions. Code promulgation law1–4 retains old transitional cases/mandates, not a new-formation postponement. Audit decree2006-1546 publicationclause8 read.

Bounded official later-amendment searches on16Nov2026 used CMF, Finance, legislation and APII queries for later core-company-code changes. No later replacement of the cited core formation provisions found; a negative search does not establish exhaustive absence. Guide expressly labels latestconfirmed statutory editions and does not call them2026consolidation. Current procedure crosschecked against RNE liveC004/C012 and APII SARL checklistupdated31Aug2026; currentAPIISUARLcorporateowner recognition agrees2019statute.

Conflicting old APII FAQ says legalpersoncannotformSUARL;2019art149expresslyallowslegalperson. FAQ legalandlegacyworkflowclaims rejected. NativeArabic128says3months whileFrench2022says6;physicalArabicPDFpage27viewedandconfirmed actualthree-monthglyphs, notextractionerror. No usableSARLmeetingdeadlineadded; explicitconflicthold. SA275andSUARL153datesagreeacrossbothtexts.

Other holds: totalformation5–10daytimeline,totalcost,authenticatedportalfieldlabels,case-specificforeignpermissions; taxreturndates/advances/financialattachments linkedto unchangedtaxGuidewithoutnewverificationclaim. No research of approvedIRPP or unassignedsiblingclaims.
