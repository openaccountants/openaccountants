# Tunisia formatting delta review

Accepted content head `b7695a7d80ee0c8707678368d44d16abb2d3d995`, Guide SHA256 `ece53509c181e51453965d8efcccdd0874a390bc4b7714a19f8089f9444ce7d1`.

Independently compared exact Guide bytes to the previously accepted candidate. The only changes are comma-space separators in three article-reference lists and the identical public-call capital amount expressed as the statute’s French words with an English gloss. These resolve the actual CI parser failure. Both case blocks and every other Guide byte are unchanged; the approved IRPP blob remains unchanged.

The original 46-row source review and explicit holds remain applicable. Original canonical review records are preserved byte-exact; this separate record supplements them. No new source, legal fact or rate was introduced. Required affected checks and all six remote CI checks must pass at the new final head.
