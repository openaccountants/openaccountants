# Independent Tunisia formation review

Accepted the bounded formation draft at content commit `5eb724a12b8bbd83ea5d346ab85fabda71c1910f`, Guide SHA256 `bc0c7fd3b91eb9202e263eaa0ee70e3a0087460f651d61d998eb6509ab90c804`. This is a source review independent of the writer, not accountant approval. Remote readiness still requires the six CI checks.

Read and checked all 46 ledger rows against actual operative official passages, neighbouring conditions and the source scopes in READ-SCOPES.json. Inspected all 26 old-topic destinations against the original Guide. Independently recomputed both cases with Decimal. The accountant-approved IRPP blob and original licence are unchanged. No open findings.

The Arabic/French article128 meeting deadline remains explicitly non-usable. The draft identifies the latest confirmed statutory editions, does not claim a 2026 consolidation, and holds total timing/cost, authenticated fields and foreign permissions. Annual IS, advances and tax attachments remain linked tasks without a new tax-deadline verification claim. These holds are not passed as verified law.

| Row | Result and actual review |
|---|---|
| T01 | Cover gives 10 February 2022; latest confirmed edition qualification and bounded applicability search avoid a 2026-consolidation claim. |
| T02 | Arts.90 and93 establish contribution-limited liability and two-to-fifty membership; Arabic agrees. |
| T03 | Complete art.93 retains reduction alternative, one-year transformation period, judicial request and possible extension. |
| T04 | 2007 art.12 and CSC92 replace numeric minimum with constitutive-act capital; equal interests retained; commencement dependency checked. |
| T05 | CSC97 complete payment and allocation rule; 2007 art.16 industry contribution outside capital preserved. |
| T06 | CSC112 permits one or more natural-person managers, member or outsider, appointed in statutes or later act. |
| T07 | CSC148 default SARL rules; CSC149 and operative 2019 art.4 expressly allow natural or legal sole owner. |
| T08 | Full149 natural-person one-SUARL restriction and no SUARL forming another SUARL both retained. |
| T09 | 2019 art.4 delegation clause plus complete CSC154 support one agent and signed, court-initialled special register. |
| T10 | CSC160 seven shareholders without three-person private exception; Arabic confirms. Board count distinguished. |
| T11 | CSC161 five thousand without public call, fifty thousand with public call; Arabic confirms amounts. |
| T12 | Complete162 includes issuing/transferring by inviting public savings and special-law designation; no public-offer clearance inferred. |
| T13 | Complete165 gives all subscribed, quarter cash initially, five-year balance;180 does not exclude165 for non-public formations. |
| T14 | Complete166 requires in-kind fully paid on issue and excludes industry shares. |
| T15 | Complete181,188-189 support initial appointments, board or two-tier governance, three-to-twelve board. |
| T16 | Complete94 mandatory-form and regulated financial-company SARL restriction retained without foreign-investment clearance. |
| T17 | Actual APII steps1/3 support reservation and online admissibility/appointment route. |
| T18 | Actual APII step2 expressly excludes commerce and makes project declaration optional for industry/services. |
| T19 | Complete dated APII checklist accepts relevant APII/APIA/ONA/ONTT/CEPEX route conditionally; not universal permission. |
| T20 | CSC3/96 complete constitutive document requirements including signature/special mandate; eight details retained in summary. |
| T21 | Complete APII checklist documents, alternative premises routes and activity permissions read with conditions; no unsupported prices stated. |
| T22 | Complete100 supports majority waiver only where each in-kind contribution does not exceed3000, report and joint liability. |
| T23 | Complete151 requires sole-member appointment/report and personal liability; ordinary SARL waiver not automatically extended. |
| T24 | CSC3 and full APII land-contribution note establish special drafting formalities; no complete land conveyancing method claimed. |
| T25 | Complete APII existence declaration and final note require fiscal card before online BO/RNE; no authenticated fields invented. |
| T26 | Full SA checklist contains subscription/payment statement, bulletins, bank evidence, constitutive/board minutes and declaration received by tax receiver. |
| T27 | Complete C012 supports dossier with conditional report/appointments/professional card and BO declaration. |
| T28 | Complete C012 business purchase/lease/free management condition requires registered contract and its JORT publication; not general company JORT rule. |
| T29 | Both C004 pages support preliminary public-call deposit and completion dossier; conditional in-kind registration retained. |
| T30 | C012 and exact live row agree30 days from statutes signature and50TND with BO/publication included. |
| T31 | C004 and exact live row agree30 days from subscription/payment declaration and50TND. |
| T32 | Both complete checklists support half-operation-fee penalty for every month or part month. |
| T33 | Complete observation supports electronic publication24 hours after acceptance without extra procedure/cost; no total incorporation-time inference. |
| T34 | Complete operative2019 art.4/CSC98 prevents manager use of funds before all formation formalities and RNE;148 supplies SUARL default. |
| T35 | CSC128 package and153 three-month sole-member approval verified; conflicting SARL date excluded. Arabic153 agrees. |
| T36 | Complete201 annual financials/accounting system and275 ordinary meeting within6months; Arabic275 agrees. |
| T37 | Complete13 and decree1 retain share-company exclusion, first-period exemption, two-limit test100000/300000/10 and existing-mandate last-two-period condition. |
| T38 | Complete123-125 distinguish5% agenda request from mandatory one-fifth court appointment and statutes override. |
| T39 | Complete13/decree2 support OECT qualification at two limits1500000/2000000/30; not conflated with general audit threshold. |
| T40 | Complete decree7 supports gross assets plus contractual leased values excluding finance/margin, products less stock variation, opening/closing employees incl occasional person-years. |
| T41 | Independently parsed exact live M004.09 object supports end of seventh month and50TND; distinct from tax attachments. |
| T42 | Exact live M004.37 object supports30days from minutes and20TND; distinct from meeting deadline. |
| T43 | Independent Decimal arithmetic:10000-5000=5000 and50000-10000=40000; shareholder count7 and fully-paid assumptions retained; legal public-offer steps not inferred. |
| T44 | Independent Decimal arithmetic:1000/2=500;1000 chosen capital, one eligible SUARL versus two-member SARL, SA7 rule. No original case inputs existed. |
| T45 | Genuine explicit non-usable hold: actual Arabic128 page27 three months versus French2022 six months. No ruling inferred; not verified operative deadline. |
| T46 | Preservation/handoff only: annual IS, advances and attachments remain linked tasks. No primary-source verification of tax deadlines claimed from accounts quote; old blanket25June extension withheld. |

Cases: 10,000 - 5,000 = 5,000; 50,000 - 10,000 = 40,000; 1,000 / 2 = 500. The original contained no worked cases.

Required writer validations pass within their scope; the four numeric-parser misses are article-reference concatenations or French words for 50,000, confirmed from the operative passages. Reusing these checks avoids an unnecessary duplicate full suite.
