# Four explained numeric-parser misses

The unchanged repository row checker ran against the actual downloaded official cache. It checked five numeric table rows, found no unreadable pages and emitted four misses. These are not unresolved source defects:

| Emitted miss | Reason | Actual operative read |
|---|---|---|
| `148,149,154` | Three adjacent article references treated as one number | CSC arts.148,149,154 each read. Art.148 supplies default SARL law; 149 and154 also match government Law2019-47art.4. Ledger T07–T09 |
| `50,000` | French statute expresses the capital in words rather than digits | CSC art.161: “son capital ne peut être inférieur à cinquante mille dinars.” Arabic art.161 agrees. Ledger T11; next art.162 defines public-call scope |
| `165,166,180` | Three adjacent article references treated as one number | CSC arts.165,166,180 read: subscription/payment, in-kind and retained non-public rules. Ledger T13–T14 |
| `181,188,189` | Three adjacent article references treated as one number | CSC arts.181,188,189 read: first officers/auditor, governance alternatives, three-to-twelve board. Ledger T15 |

No checker edits, invented source numbers or case simplification were used. Native quotations and conditions remain in the ledger; the independent reviewer must assess them. No full legal review is claimed from this mechanical check.
