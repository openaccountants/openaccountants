# Required CI formatting repair

Initial published head0ef49f0a40acb0851a120dc40399c757358bc6fc passed five of six required checks. The figures job43929361579/133517333492 failed on the four already reconciled numeric-parser misses. Its actual failure excerpt is preserved in validation/remote-figures-initial-failure.txt.

The four-line patch spaces three comma-separated article lists and expresses fifty thousand dinars using the actual French statute wording plus English gloss. No rule, rate, source, case input or oa-check changed. Original source review remains byte-exact; separate canonical format-delta review proves only these four replacements and unchanged IRPP.

Affected checks: row-source checker zero misses/unreadable; skill_checks {}; changed-only validation zero warnings; strict sync zero errors/warnings. Unaffected example/calculator/copy checks are reused, with required remote CI rerun at the final repaired head. No broad source scan or legal re-review repeated. The archive was updated only because an actual required CI failure necessitated a Guide formatting change.
