# Source access and recovery

Read-only recovery examined the prior Angola source catalogue, official AGT HTML/text and 2026 Budget PDF/text under Downloads. No completed formation-law draft/review was recovered. Existing stale public repository copies were not treated as new research.

Official CMC current catalogue resolved Law1/04,Law19/12,Law11/15; actual PDFs were cached once. Their content needed local Portuguese OCR. Material capital,signature,owner,annualaccounts andNIF clauses were visually checked against retained pagePNG files. Source-read-scopes.json records exact operative scopes. No law was inferred from OCR alone at doubtful clauses.

GUE current page, FAQ, manual and leaflet actual reads failed with403 or inaccessible errors; records remain in sources/fetch-receipt.json and actual web tool outputs. Search excerpts revealing currentleaflet/form references were discovery leads, not source reads. Normal browser fallback found IAB unavailable, Brave visibility unsupported, and tab creationfailed with timeoutMs capabilityerror. No warning/challenge was bypassed.

Official2026fiscalcalendar downloadfailed certificate-chain validation. No bypass and no exact2026calendar claim.

A diagnostic `validate-guides.py --help` unexpectedly ran its full sparse-tree validation rather than help, reporting stale index/missingllms-full and one duplicate warninggroup. This is not the required changed-only check and no generatedindex was edited. Required scoped result is retained separately. `check-row-sources.py --help` reported no changed files before commit, not evidence of source verification.
