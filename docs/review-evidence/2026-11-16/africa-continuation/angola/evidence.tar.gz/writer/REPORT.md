# Angola formation writer checkpoint

One assigned Guide is committed at `6b8dfbac372cc34cc3bae902815b1cdc835e85d2` with SHA256 `271b21dc1bf18406c1970cbc942ca8ebb9c1ee739e8049725f432715971be607`. Only `skills/angola/ao-company-formation.md` changes; no push or PR. This is a writer candidate awaiting separate independent review, not accountant approval.

## Work completed

Recovered the existing tax source cache and prior research catalogue. No completed formation-law read or review was recovered. Read the actual official CMC copies of Laws1/04,19/12,11/15, plus the official NIF245/21/87/25 instruments and recovered AGT/Budget registration-handoff sources. Portuguese OCR and material visual clause checks are recorded in `evidence/source-read-scopes.json`; raw PDFs and renders stay in `sources/`. No proof was inferred from search results or failed requests.

The candidate covers entity selection, ordinary and single-member owner restrictions, capital and contributions, contract content, signatures, registration/publication, NIF documents and annual-account/tax handoff. It corrects the old blanket notarial-deed requirement, replaces approximate capital assumptions with the statutory per-quota floor, distinguishes S.A. and single-member routes, and keeps the original timing/ranking/maximum claims as explicit non-usable holds.

The ledger contains42rule/figure rows and the complete23nonblank-line original destination map. The original had no worked cases; two new cases use chosen Kz1,000 capital, not a legal minimum. The licence is unchanged; no human approval, credit or CTA altered. The candidate grew from3899to26027bytes.

## Validation

Required checks pass: skill-check findings{}; one changed Guide/zero warnings; strict audit sync zero errors/warnings/notices; two required oa-check blocks/zero failures/missing; cached stock row-source check two numeric table rows/zero misses/unreadable; calculator quote checks;20calculator unit tests and2copy tests. Logs are in `evidence/`.

A diagnostic `validate-guides.py --help` unexpectedly performed a full sparse-tree run and reported stale index/missing llms-full. Its exact failure is preserved; the required changed-only/no-index check then passed. No generated files or check scripts changed. A cone-mode sparse setup rejected exact file paths; it was corrected to the existing no-cone dependency manifest.

## Holds

Current GUE forms/fields, detailed name/publication implementation, Formulário Único attachments, fees/payment references, possible accountant-certification condition, full S.A./special-sector/foreign-investment branches, bank account timing and old3-5day/4-6week estimates remain non-usable. GUE actual page/manual/leaflet reads failed403 or capability errors; no bypass attempted. Calendar download failed certificate-chain validation; exact2026dates and monthly VAT/IRT/INSS applicability/deadlines remain outside cleared scope. These are explicit in the Guide and ledger.

## Moved

No files moved. Original topics stay in the assigned Guide as operative content or explicit holds.

## Not moved

No sibling Guide, README, generated package, protected identity or production data changed. No push, PR, merge, auto-merge, release or deployment.

Written by Codex (world wave). Not reviewed by an accountant.

Independent-review correction AO-F01: the 2004 S.A. five/two shareholder counts are historical text only; current counts held because Law11/15 art2(b) lists304 but art19/reproduced amendments omit replacement304. Guide table, Sources, holds, AO09 and old-topic map updated. Bounded diff/Guide validation passed; unchanged checks and cases retained. Separate reviewer verifying delta.
