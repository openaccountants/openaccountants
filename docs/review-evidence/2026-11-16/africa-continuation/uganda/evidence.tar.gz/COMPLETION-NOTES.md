# Uganda completion notes

One assigned Guide refreshed from main bbab4f1a6; original notice and both oa-check blocks retained byte-for-byte. Independent reviewer accepted all30ledger rows, actual operative sources,300m/75m arithmetic and complete58original nonblank-line destinations at content02df0784. Correct VAT computation is300m/4=75m;90m excess15m.

Initial source utility lacked requests; changed local acquisition helper to standardlibrary without installing packages. Legacy Act URL404, handbook/2021compendium full downloads incomplete; they are not counted as acquired/read. Relevant2021clauses were actually read through officialonlinePDF and independently checked. Current source paragraphs and complete fees/regulations documents cached once; full rawdocuments/captures excluded.

Initial skill-check run showed missing canonical headings/perrow dates; corrected. Read-scope heuristic warning persisted until explicit section wording; finalchanged-only run passes1Guide/0warninggroups. First stock live row check had7unreadableURLs because sandboxDNSfailed; cachedactualsource text passedunmodifiedcheck_text7rows/0miss/0unreadable. This parser checks numericrows, not all legalclaims.

Independent review found an inferred notice/fee exemption and the Form23/Form40 overlap. Exemption removed and unresolvedrouteheld. Complete old-line map had misaligned ranges; corrected and independently reviewed, no further Guide content change. Required quote/copy22tests passed after43exactunchangeddependencies were materialized; object hashes checked. No unrelated source/test change.

Current complete company-law/director/minimumcapital/branchActdocuments/BO/audit/liveTINmapping and provisional amount-formula dependencies remain explicit non-usable holds. This is limited registration preparation.
