---
name: ug-company-formation
description: >
  Forming a company in Uganda, tax year 2026-27: entity types registered by URSB, first steps, URA TIN documents, EFRIS and VAT at the 2026 threshold. Fees and timing from the old file are held as unverified. Use for Uganda questions from URA taxpayers, employers, advisers and foreign investors, including rates, thresholds, filing dates, the URA portal and worked computations. Figures for tax year 2026-27 come from Uganda Revenue Authority pages and the law, and items that could not be opened are named as unverified in the Sources section. Not reviewed by a licensed accountant.
version: 0.2
jurisdiction: UG
category: formation
tax_year: 2026
tax_year_notes: "2026-27 (1 July 2026 to 30 June 2027)"
last_updated: 2026-11-01
license: AGPL-3.0-or-later (code) / OpenAccountants Guide License v1.0 (content)
tier: 2
domain: formation
---

# Uganda Company Formation and Entity Choice v0.2

> **General reference only.** This skill is general tax/accounting reference material for AI-assisted workflows. It has not been reviewed for any specific person's facts, documents, elections, deadlines, residency, filing status, or local procedures. Do not rely on it to file, pay, amend, or take a tax position without review by a qualified professional in the relevant jurisdiction.

Tax year: 2026-27 (year of income 1 July 2026 to 30 June 2027).

## Entity types and steps

URSB registers public and private companies, foreign companies and legal documents, under the URSB Act Cap 217 ([URSB](https://ursb.go.ug/services/business-registration/), read 2026-11-01).

1. Register with URSB through its online start link.
2. Get a TIN: a private company uploads the template with the certificate of incorporation and company form 20; a foreign company needs the certificate of registration and forms 19 and 21 ([URA](https://ura.go.ug/en/domestic-taxes/tin-application/tin-registration-non-individual/)).
3. Register for EFRIS (https://ura.go.ug/en/efris/efris-registration/) where required.
4. Register for VAT above UGX 300,000,000 a year (https://ura.go.ug/en/download/tax-amendments-fy-2026-2027/).
5. File provisional and annual income tax returns (https://ura.go.ug/en/domestic-taxes/returns/).

## Two worked examples that recompute

Example 1. A new private company expects taxable sales of UGX 90,000,000 in its first quarter. The quarterly test is 300,000,000 / 4 = 75,000,000, so it registers for VAT.

```oa-check
name: Formation, VAT quarterly test
inputs:
  threshold: 300000000
  quarter: 90000000
steps:
  - test: threshold / 4
  - excess: quarter - test
expected:
  test: 75000000.00
  excess: 15000000.00
```

Example 2. A decision: what to set aside for the first provisional instalment on estimated tax of UGX 10,000,000, with nothing withheld. Instalment = 50% x 10,000,000 = UGX 5,000,000 (https://ura.go.ug/en/download/compendium-for-various-domestic-tax-laws/, s.111, 2021 text).

```oa-check
name: Formation, first instalment
inputs:
  estimate: 10000000
  withheld: 0
steps:
  - instalment: estimate * 0.5 - withheld
expected:
  instalment: 5000000.00
```

## Sources

| Source | URL | Read on |
|---|---|---|
| URSB, Business Registration | https://ursb.go.ug/services/business-registration/ | 2026-11-01 |
| URA, Non Individual TIN Registration | https://ura.go.ug/en/domestic-taxes/tin-application/tin-registration-non-individual/ | 2026-11-01 |
| URA, Tax Amendments FY 2026-27 handbook (36-page PDF, all read); printed before the Income Tax and Excise Acts were assented | https://ura.go.ug/en/download/tax-amendments-fy-2026-2027/ | 2026-11-01 |
| URA, EFRIS registration | https://ura.go.ug/en/efris/efris-registration/ | 2026-11-01 |
| URA, File a Tax Return page (still shows the old UGX 2,820,000 threshold) | https://ura.go.ug/en/domestic-taxes/returns/ | 2026-11-01 |

Not yet confirmed (from the old file, secondary sources; official fee schedule not opened): no minimum share capital, UGX 5,000,000 fee band; single-member company with one director; name reservation UGX 35,000; registration UGX 105,000 or 1.5% above UGX 5,000,000; 0.5% stamp duty on formation; all-in cost UGX 300,000 to 700,000; a few days to incorporate; Forms 18 and 20; annual return and audited accounts; business names, guarantee companies and branches as forms.
