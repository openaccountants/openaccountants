# Zimbabwe independent two-Guide review

**Qualified PASS for the stated limited draft scope.** All39 final ledger rows were independently checked (27 formation,12 overview), all26 old-topic map rows were compared with the complete original files, and all3 worked cases were independently recomputed. Four findings were corrected by the writer; no material finding remains in the reviewed usable scope. This is not accountant approval or a complete-country tax opinion.

Reviewed source head: `e776b86648fb480131ed038974d7210fd30a3166`. The initial full source review was at `ffa65994fe3a30c0473973a0b639f155b9fe3285`; only the four surgical corrections and new F27 were reviewed afterward. Exact final SHA256 values:

| Guide | SHA256 |
|---|---|
| zw-company-formation.md | a3f7c178a52f88dea8877a8e515fd98680a7f44e6eef75b5f1f8c7d2ba2cf36d |
| zw-tax-overview.md | 7a89321ea9a4f8130d2447d4986a7bf46852e4936de20e926309cf2afdd9a97f |

The reviewer did not write these Zimbabwe Guides, edit writer content, push, open a PR or merge. The writer supplied ledgers before this review. Completed research/checks for unchanged content were preserved; no repeated broad scan or test suite was added for report/head changes.

## Corrections checked

- **ZW-R01:** COBE241(16) excludes licensed investors,licensed banks/insurers and statutory-SEZ operators from the general241 procedure. The final branch table and boundary now state that exception.
- **ZW-R02:** The original statutory-records topic is restored through the narrow confirmed21(2) constitutive-document/amendment retention rule. Lost content restored:1; no other topic or original input lost.
- **ZW-R03:** PN50 requires an E-Agreement before generating a CGT return under Pending Returns. The router now carries that prerequisite beside the generic route.
- **ZW-R04:** The exact50%/50.001% case now uses tolerance0.000001. Default0.01 would not meaningfully test the boundary. Arithmetic itself was correct.

## Evidence and source scope

ROW-ASSESSMENTS.json inventories every final rule with its official URL,short English original-language excerpt,read date and individual assessment. SOURCE-READS.json binds the recovered official Act/notice bytes and identifies actual direct primary-page reads. The COBE paragraphs,operative exceptions and neighbors were read,including1;18–25;75–78;82;85;87–93;165;195;241 including16;247–254;273–275. Relevant adjacent81,272 and276 provisions were also read. Income Tax Act2 year definition/historical provisos and8(1) gross-income opening were read within the router's limited claim scope. PN50 was read in its original cached PDF/text; PN49/61 complete primary captures were read; PN7/58 and the VAT Registration/Tax Rates substantive pages were read directly. Recovered Finance Act ordinary-rate material and2025 amendment paragraphs were read for the limited trade-income comparison; no complete2026 rate-card review is claimed.

Full laws,session/raw captures and full webpage text stay local outside this public-safe review. No byte hash is invented for web-provider-only reads. The official undated Tax Rates page supports the limited ordinary25% plus3%-of-tax illustration; special regimes,credits and distributions remain outside it.

## Preservation and arithmetic

Both original formation cases retain their original input names and values:30000 expected supplies,25000 threshold,100000 trade profit. Results:5000 excess;25000 tax plus750 levy gives25750 for each entity and zero difference. The added router case gives50% exactly and50.001% above,with the source's different routing outcomes. ARITHMETIC.json records independent Decimal recomputation. OLD-TOPIC-ASSESSMENT.json records all26 map rows; neither file shrank by25%.

## Remaining limits

Formation still holds single-shareholder director minimum,current fees/capital/current portal and form identifiers,turnaround,current re-registration and sector investment permissions. The narrow confirmed retention rule does not supply a complete register checklist. VAT registration steps are a handoff within a decision Guide,not an exhaustive VAT-registration filing procedure. The router preserves linked PAYE/NSSA/new-tax computation/penalty/interest/treaty holds and confines monthly dates to the named periods and categories. It does not establish later notices or generalize the August/October deadlines. First-three QPD payment days remain held.

Unchanged sibling Guides were inspected only for relevant route compatibility/holds; their entire content was not independently reviewed or approved here. The generated README is outside the two-file source review and left unchanged; its readiness/partial labels do not establish legal completion or accountant approval. Writer mechanical results and targeted correction checks are preserved in the writer archive; this independent source review does not relabel them as reviewer-run tests.

The final content can proceed through the parent's country draft-PR workflow with these limits intact. A later evidence-only commit requires matching the exact Guide hashes,not reopening unchanged source research.
