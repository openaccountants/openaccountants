# Zimbabwe source read and recovery record

Writer record only; independent source review remains pending.

Read common brief, current public AGENTS.md, docs/skill-template.md, the whole original Zimbabwe pack and latest source-gap sections. The original income-tax/payroll files contain known held historical working material; no authority is inferred from those sibling notes. Both assigned files were tier 2, with no reviewed_by, protected credit line or CTA.

Recovered November 14 official ZIMRA Income Tax Act and Finance Act consolidations, Finance Act 7/2025 Government Printer text (Veritas-hosted historical copy), and PN50 original PDF/text. Read only relevant operative sections for the new work and neighbors; do not claim a new whole-Act review. The old recovery report's completed checks concerned individual bonus/credits, not these assigned files, and do not replace independent formation/router review.

New actual primary read: government CGU-hosted COBE Act PDF, cached and extracted locally. Scope is stated in the Guide/ledger, including commencement and eligibility exceptions. ZIMRA VAT Registration and Tax Rates scripted fetches returned403; normal in-app browser loaded the actual substantive pages and was read. Normal web primary-page reads supplied PN7/49/58/61 operative text, with dated scope and neighboring instructions. No challenge was bypassed. Local source cache contains full Acts and captures and is excluded from the public-safe evidence archive. Public ledgers contain only short relevant excerpts.

PN49 still described manual DST filing for its August period; later PN50 expressly configures the new return in TaRMS. The router uses PN49 for only its period/category/dates and PN50 for current new-tax-type navigation. No contradiction is resolved by silently combining the old manual instruction with later portal status.

Official undated Tax Rates confirms the two ordinary25% rows and3% levy. The recovered statutory schedule and 2025 amending Act were read to check the ordinary-rate comparison; special new regimes are excluded from its assumptions. Company/individual tax equivalence is only before credits/distributions and is not a complete extraction-cost comparison.

No independent review has been performed or claimed by this writer. No push, PR, merge, release, database write, live-form submission or accountant approval.
