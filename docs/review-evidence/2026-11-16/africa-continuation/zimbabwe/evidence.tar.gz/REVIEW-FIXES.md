# Changes responding to independent review

Guide-content commit: e776b86648fb480131ed038974d7210fd30a3166. Independent reviewer: separate Botswana writer agent, not the Zimbabwe writer; final independent acceptance record is supplied separately.

1. F14: COBE Act s.241(1) is expressly subject to s.241(16). The table and boundary now exclude foreign companies with an investment licence, a bank or insurer licence, or operating in a statutory special economic zone; their separate regime must be assessed. Writer read the actual cached subsection and neighbors after the finding.
2. F27: explicitly restored the old statutory-records topic through the narrow confirmed s.21(2) duty to retain original/certified constitutive documents and amendments at the registered office or accounting officer physical address. No exhaustive register checklist is claimed. The old-topic map now names this destination.
3. O10: PN50 states CGT cases require an E-Agreement first to generate the pending CGT return. This condition now sits beside the generic portal procedure.
4. O12: overview case tolerance is0.000001 so the default0.01 cannot accept the same50%answer for the50%/50.001%boundary. Input values and arithmetic remain unchanged.

Delta validation: skill_checks{}each; all three recomputing blocks pass; actual two-file changed-only validation zero warning groups; strict-metadata sync audit zero errors/warnings. Earlier passing row-source and22quote/copy-test records remain applicable to unchanged figures/test inputs; no full legal scan or suite was repeated solely for evidence wrappers. The new evidence report is checked against repository copy rules separately.
