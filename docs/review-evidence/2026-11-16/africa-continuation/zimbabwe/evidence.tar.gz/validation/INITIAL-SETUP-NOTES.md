# Retained setup failures

The first isolated-clone fetch failed with `Could not resolve host: github.com`; ordinary permitted network escalation succeeded. The first validator import before exact unchanged `mcp/` dependencies were materialized failed with `ModuleNotFoundError: No module named openaccountants_mcp`.

Calling validate-guides with `--help` ran its full-scan mode because the script does not implement that flag. It reported an index counts mismatch and a zero-member duplicate warning in the sparse tree. No generated index or unrelated script was changed. The required changed-only/no-index run was then used.

The first changed-only run before a commit selected zero guides and is not claimed as validation. After committing both Guide changes, the actual two-file run surfaced a six-sources read-scope warning. The exact read descriptions were clarified, and the final committed two-file run has zero warning groups. Both logs are retained.

The first 22-test quote/copy invocation errored on an absent unchanged sparse Markdown dependency. The exact 43 unchanged HEAD Markdown files needed by the existing copy test were then materialized; rerun passed all 22 tests. No test or script implementation was edited.
