# zw-company-formation: writer figure/rule ledger

Writer record, not independent review. Read date for every confirmed row: 2026-11-16. Tax year: 2026; source-period limits and holds are part of the rule. Official-source text was actually read, not inferred from a download or status code.

| ID | Destination | Rule/figure and operative conditions | Act/article or authority paragraph | Short exact original-language excerpt | Official URL | Read on |
|---|---|---|---|---|---|---|
| F01 | Scope | COBE Act; commenced 13 February 2020 | s.1 / commencement annotation | Date of commencement: 13.02.2020 | https://cgu.pfms.gov.zw/download/companies-and-other-business-entities-act-chapter-2431/?wpdmdl=21343 | 2026-11-16 |
| F02 | Scope / choose form | Separate legal personality on certificate; membership alone not entity-debt liability, subject to Act | ss.19-20 | shall thereupon become a body corporate | https://cgu.pfms.gov.zw/download/companies-and-other-business-entities-act-chapter-2431/?wpdmdl=21343 | 2026-11-16 |
| F03 | Choose form | Company one or more persons; liability to unpaid shares | s.76 | Any one or more persons associated for any lawful purpose | https://cgu.pfms.gov.zw/download/companies-and-other-business-entities-act-chapter-2431/?wpdmdl=21343 | 2026-11-16 |
| F04 | Choose form | Private-company transfer restriction and no public invitation | s.85(1)(a),(c) | restricts the right to transfer its shares | https://cgu.pfms.gov.zw/download/companies-and-other-business-entities-act-chapter-2431/?wpdmdl=21343 | 2026-11-16 |
| F05 | Choose form | Fifty member ceiling; qualifying current/former employee exclusions; joint holders single member | s.85(1)(b),(2) | limits the number of its members to fifty | https://cgu.pfms.gov.zw/download/companies-and-other-business-entities-act-chapter-2431/?wpdmdl=21343 | 2026-11-16 |
| F06 | Choose form | Private directors: 2+ for 2-9 shareholders, 3+ for 10+; single-shareholder numeric minimum held | s.195(1) | more than one and fewer than ten shareholders shall have two or more directors | https://cgu.pfms.gov.zw/download/companies-and-other-business-entities-act-chapter-2431/?wpdmdl=21343 | 2026-11-16 |
| F07 | Choose form | At least one director ordinarily resident | s.195(2) | At least one director shall be ordinarily resident in Zimbabwe | https://cgu.pfms.gov.zw/download/companies-and-other-business-entities-act-chapter-2431/?wpdmdl=21343 | 2026-11-16 |
| F08 | Choose form | PBC 1-20 members | ss.247,252 | a minimum of one member and a maximum of twenty | https://cgu.pfms.gov.zw/download/companies-and-other-business-entities-act-chapter-2431/?wpdmdl=21343 | 2026-11-16 |
| F09 | Choose form / boundaries | PBC natural persons own right; no corporate nominee; estates, minors and insolvency exceptions | s.253 | only individual natural persons acting in their own right | https://cgu.pfms.gov.zw/download/companies-and-other-business-entities-act-chapter-2431/?wpdmdl=21343 | 2026-11-16 |
| F10 | Choose form / boundaries | No Zimbabwean-member condition in ss.247/253; no inference about investment restrictions | ss.247,253 | Any one or more persons, not exceeding twenty, who qualify for membership | https://cgu.pfms.gov.zw/download/companies-and-other-business-entities-act-chapter-2431/?wpdmdl=21343 | 2026-11-16 |
| F11 | Choose form / documents | PBC accounting officer name/signature and annual examination/review/report | ss.248(1)(g),(3),274-275 | a person who is qualified to become the accounting officer | https://cgu.pfms.gov.zw/download/companies-and-other-business-entities-act-chapter-2431/?wpdmdl=21343 | 2026-11-16 |
| F12 | Other forms | Public/co-operative are distinct; restricted private checklist not their procedure | ss.76,85,87-93 | A co-operative company is a company, other than a private company | https://cgu.pfms.gov.zw/download/companies-and-other-business-entities-act-chapter-2431/?wpdmdl=21343 | 2026-11-16 |
| F13 | Other forms | Profit-making partnership/association over 20 needs statutory form subject to designated profession/other-law exception | s.75 | unless it is registered as a company under this Part | https://cgu.pfms.gov.zw/download/companies-and-other-business-entities-act-chapter-2431/?wpdmdl=21343 | 2026-11-16 |
| F14 | Other forms / refusal | Where s.241 applies: branch ministerial authorisation, registration, principal officer ordinarily resident or citizen; s.241(16) excludes investment-licensed, bank/insurer-licensed and statutory SEZ companies | s.241(1)-(3),(16) | No foreign company shall establish a place of business within Zimbabwe unless it is registered | https://cgu.pfms.gov.zw/download/companies-and-other-business-entities-act-chapter-2431/?wpdmdl=21343 | 2026-11-16 |
| F15 | Name | Acceptable name, prescribed fee, reservation up to one month | s.25(1)-(2) | reserve, for a period not exceeding one month, a name | https://cgu.pfms.gov.zw/download/companies-and-other-business-entities-act-chapter-2431/?wpdmdl=21343 | 2026-11-16 |
| F16 | Documents | Company memorandum/articles, limited liability, shares/subscriber and witnessed signatures | ss.18,77-78 | No subscriber to the memorandum of a company limited by shares may take less than one share | https://cgu.pfms.gov.zw/download/companies-and-other-business-entities-act-chapter-2431/?wpdmdl=21343 | 2026-11-16 |
| F17 | Documents | PBC prescribed incorporation statement: member ID/interests/contributions, addresses/officer/year and signatures | s.248 | The incorporation statement shall be in the prescribed form | https://cgu.pfms.gov.zw/download/companies-and-other-business-entities-act-chapter-2431/?wpdmdl=21343 | 2026-11-16 |
| F18 | Registration | Electronic/manual registration, prescribed fee, compliance, number and certificate | ss.18-19 | The registration ... may be done either electronically or manually | https://cgu.pfms.gov.zw/download/companies-and-other-business-entities-act-chapter-2431/?wpdmdl=21343 | 2026-11-16 |
| F19 | Post-incorporation | TIN before VAT, TaRMS VAT tax-type menu and supporting evidence | ZIMRA VAT Registration, requirements/how to register | Must be registered with ZIMRA and have a TIN Number | https://www.zimra.co.zw/domestic-taxes/vat/vat-registration | 2026-11-16 |
| F20 | Tax comparison | VAT US$25,000/ZiG equivalent expected or actual taxable supplies / 12 months; exempt-only excluded; January 2024 commencement | ZIMRA VAT Registration, compulsory and exclusions | US$25,000.00 or ZiG equivalent within a period of 12 months | https://www.zimra.co.zw/domestic-taxes/vat/vat-registration | 2026-11-16 |
| F21 | Tax comparison | Standard individual trade/investment and company rates 25%, levy 3% of tax; special regimes excluded | Finance Act s.14(2)(b)-(c), ZIMRA Tax Rates | Income of individual from trade and investments ... 25% | https://www.zimra.co.zw/domestic-taxes/corporate/tax-rates | 2026-11-16 |
| F22 | Worked cases | Original VAT inputs 30,000 and 25,000; excess 5,000 computed | ZIMRA compulsory VAT threshold; arithmetic | US$25,000.00 | https://www.zimra.co.zw/domestic-taxes/vat/vat-registration | 2026-11-16 |
| F23 | Worked cases | Original trade profit 100,000; both 25,750, difference nil under explicit assumptions; dividends/liability still separate | ZIMRA ordinary rate and levy; arithmetic | Aids Levy: Rate is based on tax chargeable ... 3% | https://www.zimra.co.zw/domestic-taxes/corporate/tax-rates | 2026-11-16 |
| F24 | Filing | Company annual return 21 days after anniversary; private company certificate/signatures | s.165(1)-(4) | within twenty-one (21) days of the anniversary date | https://cgu.pfms.gov.zw/download/companies-and-other-business-entities-act-chapter-2431/?wpdmdl=21343 | 2026-11-16 |
| F25 | Filing | s.82 licensed association exemptions; s.165 not a universal all-entity return | s.82(1)-(2) | subject to all the obligations thereof, except ... 165 | https://cgu.pfms.gov.zw/download/companies-and-other-business-entities-act-chapter-2431/?wpdmdl=21343 | 2026-11-16 |
| F26 | Filing | PBC annual financial statements / accounting officer rather than blanket company annual return | ss.273-275 | shall contain the report of an accounting officer | https://cgu.pfms.gov.zw/download/companies-and-other-business-entities-act-chapter-2431/?wpdmdl=21343 | 2026-11-16 |
| F27 | Filing / statutory records | Company or PBC original/certified constitutive documents and amendments retained at registered office or accounting officer physical address; not an exhaustive registers checklist | s.21(2) | original or a certified copy of its constitutive documents together with any amendments | https://cgu.pfms.gov.zw/download/companies-and-other-business-entities-act-chapter-2431/?wpdmdl=21343 | 2026-11-16 |

## Complete old-topic destination map

| Original topic/input | Destination and treatment |
|---|---|
| Governing legislation | Scope: official COBE Act and commencement now read |
| Pvt Ltd personality, share liability and uncertain director count | Scope / legal-form table: statutory personality/limited liability; conditional director counts; exact single-holder minimum held |
| PBC 1-20, accounting officer, Zimbabwean member | Legal-form table: verified 1-20/officer, natural-person rule; Zimbabwean member assertion corrected; investment-law clearance held |
| Other forms: public, partnership, sole trader, co-operative, branch | Legal-form table and referrals preserve all alternatives |
| No minimum / USD 1 share capital | Sources hold; no usable amount asserted |
| Name search/reservation | Name step: statutory authority and one-month maximum |
| Memorandum/articles CR forms and PBC2 | Documents step: legal contents retained, current form IDs held |
| One-to-four-week timeline | Sources hold, no turnaround representation |
| PBC USD 70 to USD 140 indicative cost | Sources hold, current fee instrument not read |
| Post-incorporation TIN, VAT, PAYE/NSSA | Registration steps and payroll handoff; separate VAT liability |
| ITF12C and QPDs | Filing: corporate-tax handoff |
| Annual return/statutory records | Filing: precise company rule, statutory exception, distinct PBC regime and s.21(2) constitutive-document retention |
| VAT case: expected supplies 30000, threshold 25000, excess 5000 | Worked cases: input names and values retained exactly |
| Decision: trade profit 100000, 25% plus 3% levy for each, nil difference | Worked cases: input and computation retained; no-credit/no-distribution scope clarified |
| Original sources and company-law gap | Sources: company-law gap partly resolved; unknown fee/capital/single-holder/current portal points held |

## Non-usable holds

H-F01: single-shareholder numeric director minimum; H-F02: minimum capital / USD 1; H-F03: fees USD 70 to USD 140; H-F04: one-to-four-week turnaround; H-F05: CR/PBC2/current portal screens; H-F06: current re-registration and sector investment permissions. No source read is claimed for any held item.

## Removed and why

No topic or case input deleted. Unopened law/indicative claims moved to explicit non-usable holds. Both files grew, so no reduction over twenty-five percent. No human name, approval, contributor credit, licence identifier or protected CTA was added, removed or changed.
