# Tanzania: independent three-skill delta review

**HOLD at `7392247dd309b26eea2ae243b748a0a5c23f1526` for one precise VAT condition.** The citation/preservation changes otherwise pass this complete delta review. The stock figure checker still fails, honestly:144 rows,2MISS,58UNREADABLE,exit1. No check is waived or relabelled green.

Published parent: `c1d0a92ea2c4c9eaa301b4b650deda3474d31bda`. Local review date:16November2026. Reviewer: Codex agent `/root/maldives_full_review_nov16`, independent of this delta's writer. This is a complete review of the exact three-file delta and continuity of the earlier full review. It is not a fresh full-country legal audit or accountant approval.

## Exact change and candidate protection

Only `tanzania-tax-optimization.md`, `tanzania-vat.md` and `tanzania-withholding-tax.md` differ from the published parent. Three edit dates advance from15 to16November. Two section-list labels are separated so their identifiers cannot be read as concatenated amounts. Five rows gain narrowly scoped real official corroborations. Four new Sources rows describe only the actually reread provisions. The complete negative gift-threshold sentence and its original citation move unchanged from the VAT table to prose immediately after it.

| File | Candidate SHA256 |
| --- | --- |
| tax optimization | `59bea0c4569738a6d260d59ee261699a1a17dfe52598cb9308f18d05a9f92b0e` |
| VAT | `feb1ef2742e492bb1ca568c9e8677ea5749fe518c1310ed8131d8d97fdd1e389` |
| withholding | `cc4204190ecff29b0fe13429b349bce220d87df611047cc909e0b844fa1ea5ef` |

All ten country files were frozen from actual Git parent/current blobs and compared with the worktree. Seven files, including the approved income skill, README, payroll and social contributions, remain byte-identical. All versions and protected names, approval/tier/licence fields, original Sources rows/dates, CTA material and unconfirmed boundaries remain unchanged. The worktree remains clean. No new professional approval or country-completeness claim is created.

## F01: the VAT private-use row needs the separate produced/improved-property branch

File `skills/tanzania/tanzania-vat.md`, current line63, rule `R25`.

The newly corroborated row says `s 79 increasing adjustment depends on prior input and private application`. That is a supported description of the input-credit branch in79(2)–(3), but it is too broad as a description of the whole section. The same complete official page provides a separate79(4) branch for property a taxable person modifies, improves or produces: adjustment is required if the property is applied wholly privately and its supply would have been taxable. That branch does not require an input tax credit. Under79(5), the amount is the tax fraction of fair market value at first wholly private use;79(6) places adjustment in the period of that use. The current end hold concerns full private-use adjustment quantum; it does not correct this overstated eligibility predicate.

Source: [official TRAB VAT Act, section79](https://www.trab.go.tz/uploads/documents/en-1776866166-THE%20VALUE%20ADDED%20TAX%20ACT.pdf), complete physicalpage61, printed349, with78/80 neighboring context independently read. Exact PDF SHA256: `f23548971722ae028c7015087ad5066e08f3bb83e75744ec35b76ef3e7dd9e49`. The full-page image and complete literal source scope remain local and are hash-bound in the final manifest. This is an actual substantive issue found in a newly corroborated row, although its wording predates this delta; the prior PASS is not silently reused over a contrary operative clause.

Minimum correction: narrow the prior-input condition explicitly to79(2)–(3), then preserve79(4)–(6)'s separate modified/improved/produced-property eligibility branch without implying prior input is necessary. Keep the actual valuation/case-specific quantum hold and the complete old gift warning. Alternatively, explicitly hold this separate branch non-operative until the chosen complete calculation is supplied; do not leave an apparent general no-input/no-adjustment rule. No new country/topic expansion is required.

No candidate was edited by the reviewer. After a writer correction, only that precise change and its source/case/map effects need an independent delta review; this immutable HOLD must remain.

## The other four row corroborations

| Target | Actual complete source reading and result |
| --- | --- |
| OptimizationR19, line57 | FinanceAct2025 clauses124/131, ordinary July1 commencement and the express September1 exception, unregistered Mainland purchaser, bank/approved-electronic payment, actual CG notice and payment-proof requirements. New TRAB link is the same actual earlier source22. Candidate preserves the missing-notice hold. PASS for this scope. |
| OptimizationR22, line60 | OSG ITA section3 entire investment-asset definition and adjacent lease context. Individual residence ownership is continuous for at least3years, use continuous/intermittent totals at least3years, and exclusion does not cover gain exceeding15million shillings. Candidate's at-most15million boundary is supported. PASS. |
| OptimizationR23, line61 | Complete business-asset and investment-asset exclusions: individual-held land value strictly less than10million at realization and agricultural use at least2 of the prior3years. Equality is excluded. Candidate retains those conditions. PASS. |
| WithholdingR6, line44 | Complete rent/royalty definitions,105(1)–(3),104tail/106opening and FirstSchedule4(b) with4(c)opening. Resident-payer/source scope, resident-asset exception, all neighboring exceptions and classification limits remain. Schedule4(b)(ii) supports nonresident rent10%; equipment classification is not decided from its commercial label. Candidate retains the existing TRA-summary conflict and contract-classification limitation. PASS. |

Three actual bodies match the previously independently read source records exactly: OSG ITA2025 source27, FinanceAct2025 source22, VATAct2023 source23. The OSG cover identifies the2025 annual supplement as incorporating amendments through1July2025; this delta does not replace or redate the pack's separate2026 amendment-chain reading. Nine complete local scopes and18 complete PDF pages were independently read/viewed. Fresh narrow read date16November is honest; older full-review dates remain15November. No new full-consolidation reading, missing public notice recovery or actual contract/valuation outcome is claimed.

The official VAT84 deregistration provision was read in full: final return, property on hand, prior credit including subsumed inputs, statutory valuation and credit limits. The candidate's narrow84 statement is supported. Neither79 nor84 establishes the held gift threshold, which remains unusable.

## Complete preservation and earlier review continuity

All164 current writer-manifest payloads match their sealed sizes/hashes. The earlier recovery review's592 manifest entries also match:589 immutable payloads remain directly identical, and the three current skill paths now changed by this delta match their recorded old hashes through exact published-parent Git blobs. This is an explicit parent-blob rebinding, not a claim that the live three files are unchanged.

The full previous review's243 rule records and1,099 original-topic decisions are retained as historical decisions. All243 inherited complete records match their earlier records exactly;238 unchanged claims keep their prior source scope and five changed rows receive this actual new source review. All1,099 actual final destination spans were verified byte-for-byte at the current head, including shifted VAT destinations and the preserved moved warning. This continuity does not pretend to freshly repeat all old1,099 semantic decisions or all243 law reads.

All1,677 nonblank published-parent lines have actual final destinations with no duplicate/missing parent-line identifier. Of these,1,669 remain exact, three are edit dates, four are same-rule citation/corroboration rows, and one splits into the exact preserved positive row plus complete warning/original citation. All old source URLs and Sources dates remain. The complete warning is still followed by its original79/84 link; the separate final Not yet confirmed gift/case entry is also byte-identical. Relocation has not converted an unsupported number into a supported threshold.

The earlier initial/correction HOLDs and complete final pack review remain attached. Their actual raw sources, input/eligibility judgments, scope limits and later correction closures are preserved through this chain; the new finding above explicitly supersedes approval only for the blanket79 predicate. It does not revoke unrelated historical review findings or create a new approval on the unchanged approved income skill.

## Cases and mechanical checks

All12 recomputing blocks in the five assigned skills are byte-identical, including every raw input, formula and expected output. They were independently recomputed with Decimal arithmetic:53 expected outputs, zero failures. The earlier100 prose/scenario arithmetic checks remain linked to exact unchanged case/input bytes and their original eligibility assessments; they are not represented as100 newly repeated output checks here. This delta introduces no new case or changed numerical input.

Fresh reviewer reruns: five target standard objects are empty; five-file examples check12blocks with zero failures/missing; strict sync against the exact published parent checks three guides with zero errors/warnings/notices. Writer's ordinary cumulative validator log is sealed and was inspected: six changed guide paths, five substantive guides, zero warning groups. The unchanged calculator-quotation pass and whitespace pass were inspected. The cumulative validator was not redundantly rerun, and no remote check result is claimed.

The actual terminal merged-stock log was parsed independently:144 rows, two MISS,58UNREADABLE, recorded exit1. Both remaining MISS are the supported15,000,000 and10,000,000 amounts written as monetary words in the actual OSG law. The exact checker lacks general word-money parsing; these citations do not change that. Ordinary transport/extraction failures remain UNREADABLE. The actual parsed row/URL inputs remain unchanged across the writer's last blank-line formatting fix. No source waiver, figure-as-words substitution, source replacement, weakened parser or all-green claim was used. Any software repair is a separate reviewed change owned by root.

## Scope and publication boundary

This exact delta is **HOLD for F01**, despite its otherwise intact preservation/citation changes. Prior README partials, health implementation, fund/remittance boundaries, Zanzibar,16%notice, treaty effects, exemption/HS/source/form and actual private-use valuation limitations remain. Raw official PDFs, full primary scopes, rendered pages and old author material stay local. Only the explicit public-safe own-record allowlist may be published; the local-only manifest exposes metadata/hashes, not primary-document contents.

No writer skill/evidence file, source head, review history, public PR, database or service was changed. No commit, push, merge, release or approval waiver occurred.
