# Tanzania VAT section79: narrow correction handoff

Frozen local head `a4938d17fe9b2752e8824e63c017605598eb7c2a`, parent `7392247dd309b26eea2ae243b748a0a5c23f1526`, clean writer worktree `wt-tanzania`. No push, PR edit, branch merge or release. Only `skills/tanzania/tanzania-vat.md` changed: two existing lines, the private-use row63 and its precise TRAB Sources scope at187. No metadata or version change; the still-open country PR already carries one version increment above actual main (VAT3.0 versus2.0).

The original independent HOLD at `review-tanzania-7392247dd/REPORT.md` remains immutable. I independently read actual VAT79(1)-(6), preceding78 and following80, and viewed physical page61/printed349. The preserved official TRAB body, complete literal scope and image are bound in `actual-source-branches-and-read-scope.json`. This is a narrow operative source read, not a new whole-Act/consolidation review.

The correction limits prior-input-credit eligibility to79(2)-(3), retaining the prior-taxable-use/lesser-of-credit-and-adjusted-FMV condition. It separately states79(4)-(5)'s modified/improved/produced-property branch: taxable person, wholly private application, hypothetical supply taxable, no prior-credit prerequisite, tax-fraction FMV at first wholly private use. Section79(6) fixes the period. Existing84 conditions, complete gift warning and full case-specific valuation/quantum hold remain unchanged.

`R25-corrected-operative-binding.json` and `ledger.md` bind the current rule to every operative branch, short native anchors and actual read scope. The earlier R25 blanket-prior-input PASS remains historical but is expressly superseded for that predicate. Other242 rule records retain their prior chain. `affected-exact-destination-records.json` rebinds the20 affected spans in the1099-topic map and one published-parent line-map entry; `complete-map-continuity-index.json` binds the entire old/current map population without duplicating or overwriting the canonical records. The complete original warning still has its separate exact destination. Source URLs and read dates are preserved.

All nine other country files, the VAT frontmatter, human credit/approval/licence fields, CTA content, held tail, all original case narratives/inputs and executable case blocks remain byte-identical to7392247dd. `exact-candidate-and-protection.json` proves the two-line delta and full country/case hashes. The prior full-country source/no-loss review and the independent739 review are reused only for unchanged content; no fresh full-country research or case re-review is claimed. The reviewer has already confirmed the substantive two-line correction and is awaiting this sealed packet for final binding.

## Relevant checks

- Changed VAT full skill standard: `{}`.
- Actual cumulative changed-file validator: six guide paths, five substantive guides, zero warning groups, exit0.
- Authoritative cumulative PR-base strict sync: actual merge-base `2844c309238b4fdb63be0a3d0ad9ae99a8ea89c8` to this HEAD, five source guides, zero errors/warnings/notices.
- Calculator quotations and committed whitespace check pass.
- All12 executable cases/53 expected outputs retain their exact739-reviewed input/formula/output bytes, so completed independent recomputation is reused. No redundant rerun for this non-case delta.
- The unchanged merged-stock checker replays the one changed row against the actual preserved TRAB body: one row, zero MISS/UNREADABLE. All27 VAT row URL/numeric payloads are unchanged; only that row's legal conditions changed. This cached-body replay is not a new network claim.
- Prior complete live stock result remains honestly144rows/two MISS/58UNREADABLE/exit1 at739. The two remaining monetary-word MISS are in unchanged optimization rows. No full network scan was repeated; root owns the separate general parser repair and final composed candidate/CI.

The first direct sync against the same-day unpublished739 checkpoint fails its metadata-advance test as expected. A direct moving-main-tip comparison also produces unrelated older-branch regressions:128guides/409errors. Both unsuitable comparison logs are preserved, not labelled passing. The published-c1d checkpoint comparison passes3guides; the actual cumulative PR merge-base comparison above is authoritative and passes5. No extra version was introduced to make a wrong comparison pass.

Only this new correction's binding/check packet is sealed. The previous164-artifact writer packet and full independent HOLD remain referenced by their immutable manifest hashes; they were not reuploaded or repackaged. Full primary PDF/image/scopes stay in existing local evidence paths. No source/check waiver, new professional approval or comprehensive-country claim is introduced. Root owns independent final acceptance, parser composition, publication and ingestion-safe merge.
