# Tanzania VAT: independent correction review

**PASS for the exact two-line legal/content correction at `a4938d17fe9b2752e8824e63c017605598eb7c2a`.** F01 in the complete preceding review is closed. This does not waive figure-check failures, certify comprehensive country coverage or grant accountant approval.

Parent: `7392247dd309b26eea2ae243b748a0a5c23f1526`. Review date: 16 November 2026. Reviewer: `/root/maldives_full_review_nov16`, independent of this correction's writer.

## Actual legal correction

Only `skills/tanzania/tanzania-vat.md` changes, at lines 63 and 187. The guide remains 189 lines. The complete candidate VAT SHA256 is `8febd71ac59871f51ead7d23a7b83f7895286ce9949d58b5dc3a8d30e26670dc`. The exact patch and changed-destination hashes are preserved alongside this report.

The actual [official TRAB VAT Act](https://www.trab.go.tz/uploads/documents/en-1776866166-THE%20VALUE%20ADDED%20TAX%20ACT.pdf), complete s 79(1)-(6) and neighboring ss 78 and 80, was independently read on 16 November during the preceding review, including physical page 61, printed page 349. That unchanged full source scope and the actual viewed page are bound by SHA256 in `delta-bindings.json`. The complete clause was examined again against this specific correction. No fresh whole-Act or amendment-chain read is asserted.

The amended line accurately distinguishes the two statutory branches:

- Section 79(2)-(3) concerns a taxable person allowed all or part of acquisition/import input credit who applies the property wholly privately. The adjustment is limited to that credit; where the property had been used in taxable activity, the lesser-of comparison includes the tax fraction of fair market value at first wholly private use, reduced for the portion for which credit was not allowed.
- Section 79(4)-(5) separately concerns property the taxable person modifies, improves or produces. Wholly private application and a hypothetical taxable supply are the eligibility conditions. This branch does not impose the acquisition/import prior-credit prerequisite. Its amount is the tax fraction of fair market value at first wholly private use.
- Section 79(6) places the adjustment in the period of first private use. The separate s 84 deregistration statement and its valuation boundary are unchanged.

These are the complete conditions relevant to the finding. The prior blanket input-credit predicate is no longer used for the independent modified/improved/produced-property branch. The Sources row now accurately identifies the actually read branch, valuation and timing scope. Its URL and genuine 16 November read date are unchanged. F01 is closed through a substantive correction, without a parser exception, source substitution or a narrower review population.

## Preservation and proportionate verification

The completed preceding review is retained unchanged at `review-tanzania-7392247dd`, including its original HOLD disposition. Its report and final-manifest hashes were checked once for applicability. That review had already examined the complete three-skill citation delta, 243 inherited rule records, 1,099 old-topic destinations, 1,677 published-parent nonblank lines and the prior full source/case chain. There was no reason to repeat that whole audit for two replacements.

Direct git comparison proves that all other bytes in this VAT guide and all nine other country files are unchanged. The changed destinations remain at the same line numbers, so no subsequent map offset shifts. The previous s 79 operative claim now resolves to the corrected line 63; the expanded Sources scope resolves to line 187. Other semantic destinations and all source/hold boundaries remain applicable. The original gift-threshold warning and citation, held gift example, final quantum hold, source-read dates, people, approvals, credits, calculator quotations, version and frontmatter are byte-identical.

The sealed writer packet has 26 payloads, all verified against its final manifest SHA256 `bfa23ff6bdbeb6ba8d6f1767d51a062930f6dedc8999acc976b5cc7d31cfc317`. Its 20 changed old-topic spans were independently checked against their actual final line ranges. The one changed published-parent line record retains both the corrected operative row and the separate complete gift warning/citation at line 67. The other 242 rule records and other map destinations reuse their applicable completed review. This does not substitute a generic footer for a substantive subject. Exact new evidence and authoritative merge-base hashes are bound in `writer-final-check-bindings.json`.

All three complete VAT `oa-check` blocks are byte-identical, and the nine unchanged country files preserve the remaining cases. The preceding independent 53-output Decimal check and existing complete case review remain applicable. No redundant arithmetic suite or full source scan was run, and no fresh professional approval is implied.

## Required-check boundary

The prior exact-head stock result remains recorded honestly as 144 parsed rows, two MISS, 58 UNREADABLE and exit 1. The two money-in-words source-format misses were already separately diagnosed. This legal correction neither repairs nor waives them. A later checker result, if obtained through the separate general parser repair, must be bound to its actual software and candidate head; this report does not claim it in advance. The writer's cached-source replay of the sole changed row has one eligible figure, zero MISS and zero UNREADABLE. Its numerical payload and source URLs are unchanged, so that narrow replay is not a fresh full-network stock result.

The writer's targeted standard result is `{}`. The ordinary cumulative validation passes with five guides and zero warning groups; calculator quotations and whitespace checks pass. The final correct cumulative strict-sync check uses the actual git merge-base of main and the candidate: five guides, zero errors, warnings or notices, exit 0. Two preliminary comparisons remain recorded as diagnostics: comparing the correction to its immediately preceding unmerged same-day parent flags an unversioned-body-change; comparing the older tree directly to moving main also flags unrelated regressions. Neither is represented as a passing check. The correct cumulative PR comparison supersedes them for the required sync gate, without an unnecessary extra version bump.

The content correction passes and the old legal HOLD is resolved. Required engineering and hosted-check gates remain for the publisher to assess. No source, candidate, old record, author worktree, commit, PR or service was changed by this review.
