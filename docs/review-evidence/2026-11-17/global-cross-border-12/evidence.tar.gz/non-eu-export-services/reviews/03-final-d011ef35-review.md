# Final independent non-EU export review

Guide SHA256 `d011ef35780a81d0c4d77634b1847be4ea0a1a385fe835765e517f92855ea179`.
Author ledger SHA256 `7b4f425ba11296a8c00d251be2f83ad6d346b8535e837634bc0c1507c5802cb9`; rendered ledger SHA256 `67a70eb6903710a9be806c2be042d7bc0ef4afe6c29141675d32bd4a9e789517`.

**Bounded source accuracy: PASS. Native evidence format and overall standard: HOLD.**

All 321 current rows were checked; all 317 original IDs/exact claims remain bound. All 209 evidence entries match the immutable recommendation plus actual-primary INR addendum. All 321 full contexts match the actual Guide lines. F1–F3, INR and D1 are resolved.

The remaining 45 rows carry 12 explicit copyrighted-guidance extract gaps. No format waiver, full-standard approval or accountant attestation is claimed.

The INR rule is CGST34(2), applied through IGST20: GAAP exchange rate at CGST13 time of supply. IGST13 place of supply and RBI receipt-currency permission are separate. No actual exchange rate or INR result was determined. Full source-version/access limitations remain in the JSON/addendum.

All 160 old body atoms and 52 headings retain their complete prior mapping; the annual LUT recommendation is now explicit. Original case monetary inputs/rates/results are unchanged, so all 14 independent recomputations remain applicable.

Validation: 23 checks pass; skill_checks filtered{};2 oa-check blocks, 0 failures/0 missing; git diff check passes.

This is independent evidence research and review, with the remaining native-format HOLD preserved.
