# DAC6 complete first independent review: findings open

Candidate `97d75e4540bd54b5cef4c3cbb9c3c0857e6305f7f255d91e37f931260c786943`; original `74af9798ba2758f7d174e6e8874defc0aa194ed8179f70fda8d68e2ed9918162`. Review/read date16November2026. **NOT PASS.**

I read the whole original and candidate, all137 ledger rows/151native fragments, all46actual primary-source scopes with relevant neighbors, and all39headings/162old body entries. Every old map original text matches the immutable original. I recomputed both new cases and compared all original qualitative cases, workflow outputs, refusal branches and conditions. Historical captures retain their original dates; source registers and my own read record distinguish fresh web reads from archived actual official bodies. No author log is substituted for reading.

The scoped19checks, target validator, both examples, calculator quotes and diff check pass. The source helper covers only one E.3 row and returns1UNREADABLE/0MISS. Its50%/three-year figure is manually supported by my actual whole AnnexIV E.3 paragraph read in the retained official consolidation, alongsidePartI/adjacentE.2 and raw source hashes; no fresh successful direct EU retrieval is claimed. This parser result does not verify other figures. See independent-five-checks.json.

Both independent calculations match: annual1m×50%=500k,500k equality fails strict below while490k/1m=49% meets; Italy1500–15000×1.5=2250–22500 and×0.5=750–7500. The15dayreduction condition remains a finding. No current Belgian implementation/non-lawyer compatibility/Irish identity conflict/Italian technical package/Argentine overlay/Swiss negative is cleared. Names/platform/licence/frontmatter and exact original disclaimer remain preserved.

## DAC6-STRUCT-001 — Guide Sources/Disclaimer

Sources must be the last section written; unchanged original Disclaimer currently follows Sources. Move it before Sources.

Evidence: CLAUDE.md:39.

## DAC6-COPY-001 — D06/D11/D27/D33/D42/D61 and matching public parentheticals

Remove parser-facing explanations such as 1 is in words on the page /50% in words; D11 duplicates the annotation. Keep actual-source/manual-proof details in evidence, preserve substantive figures and conditions.

Evidence: Public product-flow instruction; complete candidate read.

## DAC6-SOURCE-001 — D32 / R035–R036

Auxiliary/service-intermediary clock needs binding C623/22 paras85–86: day after completion of aid/assistance/advice and, at latest, applicable first-subparagraph trigger insofar as aware; earlier voluntary reporting permitted. Do not import this EU qualification into UK reg4. Add actual judgment operative fragments.

Evidence: C623/22 paras82–86; archived official judgment personally read16Nov.

## DAC6-SOURCE-002 — D61/D68 / R100–R102

Actual current471/1997 art10(1) halves sanction if transmission is in the following15days. Saying only addresses15days leaves the operative effect unstated. Explain the condition/effect and explicitly keep the illustrated unreduced ranges outside that gate or add an accurately conditioned calculation.

Evidence: D.Lgs471/1997 art10(1),100/2020 art12,87/2024 arts2(1)(g),5; actual official current texts read16Nov.

## DAC6-SOURCE-003 — D49 / R076–R081

UK reg12 employee exclusion missing: employee is not an intermediary if employer is intermediary or relevant taxpayer for the arrangement/structure; include meanings and connected-employer financial/economic/organisational links. Add bound native clauses.

Evidence: SI2023/38 reg12(1)–(4), whole original official PDF read and p5 visually inspected16Nov.

## DAC6-SOURCE-004 — D40 / R054

Partial-LPP procedure omits taxpayer deadline: manual p48 says within14days of receiving ArrangementID file all specified information through ROS. State this condition while preserving separately identified unresolved EU protected-identity field conflict and actual partial-LPP route.

Evidence: Revenue March2026manual4.10 printed48, full operative passage/footnotes/neighbor read and visually inspected.

## DAC6-NATIVE-001 — Entire ledger

118 of151 native fragments exceed25words, maximum906. Losslessly split complete operative clauses into ordered short fragments of at most25words; retain exact source/locator/read-date provenance and assert full reconstruction. This is not permission to sample prefixes/middle/tails.

Evidence: independent-initial-native-audit.json; all137 row claim/native assignments personally compared.

## DAC6-NATIVE-002 — R074 / D48

Only extract is regulation21 introductory sentence; every revoked instrument is missing. Include21(a)–(c) losslessly.

Evidence: Actual SI2023/38 p9/reg21(a)–(c), own text and visual read.

## DAC6-NATIVE-003 — R070 / D47

Quote labelled manual5.6/TCA817RD(8)–(9) is actually generic manual5.1 filing scope and5.2heading. Bind actual5.6 annual-reference operative text: transaction OR obtained/sought tax advantage, all applicable years/periods, pre2020/joint-assessment qualifications and pertinent notes.

Evidence: Actual Revenue manual printed52/5.6 and original enacted817RD(8)–(9), own text and visual read.

## DAC6-NATIVE-004 — R091 / D55

ITA237.3(1) reportable-transaction definition is truncated mid-sentence after confidentiality in respect of a; remainder of(b) and all(c) omitted. Reconstruct complete definition then losslessly split.

Evidence: Actual archived JusticeLaws237.3(1) entire definitions with neighbors independently read16Nov.

## DAC6-NATIVE-005 — Additional claim/source bindings

Complete each missing assigned operative limb: R018 C.1(b) resident-recipient parent; R050 AO102(1) opening and capacity closing; D41 WIB10h(2)(a) waived-intermediary identity exclusion; R084 actual assigned model2.1/2.6 instead of lone national placeholder; R085/D52 CFF197 adviser definition/nexus plus claimed198 taxpayer conditions; R088/D53 RG5306art5 annual condition; R089–90/D54 actual ATO CategoriesA/B as well asC; R092 assignedITA237.4(2)–(3) interpretation/designation; R094/D56 actual SARS35criteria/36exclusions/form-route passages; R083 complete assigned model2.7(a)–(b) conditional context instead of three isolated numbers; R003 procedure identity/COM2026/0308 proposal entry as well as pending status. Every addition needs own actual scope/locator/date and lossless short fragments.

Evidence: All corresponding46 actual primary-source scopes read; independent-source-read-record.json and retained actual source/web artifacts.

## DAC6-MAP-001 — Old map all201entries

166 entries point partly/wholly to standalone group markers or blanks, e.g.O001 old22→21 is comment only while body is22. Rebuild every destination to actual current body lines/spans and literal text, preserving complete original snapshots.

Evidence: independent-map-initial-audit.json lists all201 actual text destinations and166 affectedentries.

## DAC6-LOSS-001 — O151 / original294 → D36/D37/Completion

Original specific self-check applies privilege by intermediary MemberState rather than taxpayer MemberState. General national-law/protected-information wording does not retain that actor/jurisdiction distinction. Restore specific check or explicit individual source-bound reservation where applicable nexus cannot be established.

Evidence: Whole original/candidate and all162 old body entries personally compared; original294/current113,116,284.

## Exact review evidence

Own frozen candidate/original and244writer evidence files remain immutable. independent-source-read-record.json records all46actual scopes; web retrieval snapshots preserve live official bodies and failed attempts. independent-initial-native-audit.json and independent-map-initial-audit.json retain every mechanical result. own-source-visuals contains28page images personally inspected (UK1–9; Ireland47/48/52–54; BZSt9–12; OECDPDF19/21–24; ItalianDM5; Luxembourg3/6; ATO10/11). Actual printed OECD17/19–22 differs from physical PDF indices; locators are explicit. No image was treated as read just because rendered.

Resolve the complete batch, seal exact corrected Guide/ledger/map/source bytes, and rerun applicable checks. I will independently inspect every changed body/evidence/source binding and map, retaining this first-review record. No Guide author edits, commit, push, PR, merge or publication performed.
