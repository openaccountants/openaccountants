# Free-zones and SEZ matrix: writer report

Writer checkpoint: `b25aa5640641f68c408f341cb14f863292d8a238`. Guide SHA256 `9f25cce30e60665d3fcd515e2d2f8a7ff2e55b038fb0d1187635c624c7c0fffa`. Original SHA256 `f26aa794d1d9cdda7528578e64070a9c6d972033418327a8c54cb35380c8a983` matches current main. Source read date: **16 November2026**. Only `skills/global/cross-border/free-zones-sez-matrix.md` changed. No push, PR, publication or merge.

This is writer evidence awaiting complete separate independent review. It is not accountant approval or a filing-ready incorporation recommendation.

## Changes

- Replaced obsolete UAE QFZP instruments and corrected income categories, de minimis numerator/denominator, failure periods and IP nexus; preserved all13 original UAE shortlist rows as individual licensing questions.
- Separated QFC/Qatar from UAE, geographic Saudi SEZs from cloud rules, and ordinary tax rates from minimum-tax overlays.
- Updated read China extensions, Indian2026 IFSC provisions, Bahamas initial-year condition, Jersey MCIT distinction, Mauritius QDMTT and selected national rate changes. Unrecovered original national claims remain individually non-usable under Sources.
- Preserved all original geographic topics, workflow outputs, self-checks, refusals and exact disclaimer. Added two meaningful revenue-cap cases without inventing tax liabilities.

## Corrected examples of old and new positions

| Old proposition | Corrected bounded treatment | Source |
| --- | --- | --- |
| UAE mainland sales only via distributor/de minimis;9% excess | Income category and licence permissions separate;ordinary QFZP failure from beginning plus4subsequent periods | CD100 Arts3–8; MD229 Arts3–5 |
| QFC counted with UAE financial centres | Qatar;10% local-source charge with actual2026 exceptions/Rule1Aconditions | QFC TaxRegs9–10/TaxRules1A |
| Cloud Saudi5%/20years | Separate ordinary20% manual treatment;qualifying geographic SEZ5%/20years remains conditional | ZATCA current manual |
| GIFT10of15 |20of25 qualifying IFSC-unit100% specified-income deduction;other banking/15%income terms separate | FinanceAct2026 sections47/60 |
| Madeira5% through2027 | Eligible licences through2026/benefit through2033;actual start/jobs/investment/caps/exclusions | EBF36-A |
| Labuan3%orMYR20,000 |3% audited covered trading profits;section7deleted;other substance/IP/nontrade rules | AGC2026 updated text, authenticity caveat |
| Mauritius no minimum tax adopted | Actual15%QDMTT/reg29 commencement read;full computation not cleared | Act50Q–50R/GN1352026 |

## Preservation and evidence

308 current groups, 783 individual current subclaims, 136 claim-scoped source bindings; 56 actual source records, 93 selected operative blocks and 2253 short private native fragments. Complete original map: 191 nonblank body lines including 19 headings, 384 cell/clause atoms. All actual destination spans match. Numeric occurrence inventory counts851 current and240 original occurrences, including statutory identifiers/dates; these are not851 separate tax rates.

## Removed and why

No old substantive topic, case input or refusal is silently dropped. Stale favourable rates and generic legal assertions are corrected or individually withdrawn pending actual source proof. All actual new destinations are in old-topic-map.json; no bulk old-body archive serves as a replacement for preservation. The Guide grew from20,293 to84,855bytes.

## Moved

Individual unconfirmed national source requests sit under Sources, with references from the relevant country rows. Protected disclaimer remains unchanged before Sources. Raw sources and complete copyrighted bodies remain local and are excluded from any public evidence package.

## Not moved

No other Guide, accountant name, contribution, approval, licence, calculator quote or platform-written key changed. Financial/routing/DST and coordinator-owned incorporation/reconciliation/invoice/SAF-T are untouched.

## Required checks and boundaries

Structural19checks empty, targetvalidator0warnings, sync0errors/warnings, two meaningful oa-checks pass, calculator quotes and copy2tests pass, diffcheck clear. Initial sparse/invocation failures retained. Live figure helper:34rows/1explainedwithdrawn-legacy-amountMISS/3UNREADABLE; actual operative read dispositions are explicit, not automatic-green. Final Kenya in-words annotation changes no figure/condition; unaffected completed checks are reused rather than repeated for the hash.

Source limitations remain material: selected rather than whole-book reads; UAE unofficial English/Arabic unread; Labuan text explicitly not authentic; MRA informational consolidation; historical CostaRica/MEF overview; failed national/licensing recoveries individually marked. These limits are not resolved by a parser or this writer report.

Written by Codex (world wave). Not reviewed by an accountant.
