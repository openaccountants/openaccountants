# exit-taxes-when-a-family-moves figure and rule ledger

Public projection; canonical private SHA256: `18b0265c07d7f55d79f82fd1915b2d4b48331263b982d9384c023c417502439f`. Complete captured/native source passages remain local. The JSON companion preserves every retained evidence field.

## Whole rule groups

### DE-EVENTS

Three deemed-disposal events, exact timing, FMV and conditional new acquisition value.

```json
{
  "act_article_or_scope": "AStG6(1) full",
  "actual_read_on": "2026-11-16",
  "id": "DE-EVENTS",
  "official_url": "https://www.gesetze-im-internet.de/astg/__6.html",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "What triggers it. Three events are treated as a sale of the shares at fair market value (gemeiner Wert): the end of unlimited tax liability because the person gives up domicile or habitual abode; a free transfer to a person who is not unlimited liable to German tax; and any exclusion or restriction of Germany's right to tax the gain on the shares ([section 6(1) AStG](https://www.gesetze-im-internet.de/astg/__6.html)).",
      "line": 66
    }
  ],
  "short_exact_native_quotes": [
    "(1) Vorbehaltlich der Vorschriften des Einkommensteuergesetzes, Körperschaftsteuergesetzes und Umwandlungssteuergesetzes stehen bei unbeschränkt Steuerpflichtigen der Veräußerung von Anteilen im Sinne des § 17 Absatz 1 Satz"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/de-astg6-current.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "02e9d3b19c3c5b8f0e5ab7d59de94ca5a82174a814839e2092ebffdd83f98bec",
  "source_version_basis": "Current actual official body retrieved/read2026-11-16; relevant operative unit and neighbours personally read."
}
```

### DE-LOOKBACK

Natural person7of12years; gratuitous predecessors, simultaneous-year single count and earlier return-relief deeming.

```json
{
  "act_article_or_scope": "AStG6(2) full",
  "actual_read_on": "2026-11-16",
  "id": "DE-LOOKBACK",
  "official_url": "https://www.gesetze-im-internet.de/astg/__6.html",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Who is caught. A natural person who, within the last twelve years before the event, was unlimited liable to German income tax for at least seven years in total ([section 6(2) AStG](https://www.gesetze-im-internet.de/astg/__6.html)). Periods of a gratuitous predecessor also count, with simultaneous periods counted only once; the special prior-return-relief deeming provision in6(2) must also be checked.",
      "line": 64
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/de-astg6-current.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "02e9d3b19c3c5b8f0e5ab7d59de94ca5a82174a814839e2092ebffdd83f98bec",
  "source_version_basis": "Current actual official body retrieved/read2026-11-16; relevant operative unit and neighbours personally read."
}
```

### DE-RETURN

Temporary absence7years, possible5extension, retained holdings/distributions/restored taxing rights; death-successor and analogous cases.

```json
{
  "act_article_or_scope": "AStG6(3) full",
  "actual_read_on": "2026-11-16",
  "id": "DE-RETURN",
  "official_url": "https://www.gesetze-im-internet.de/astg/__6.html",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Return within seven years. If the departure was only a temporary absence and the person becomes unlimited liable again within seven years, the tax falls away, but only to the extent that: the shares were not sold, transferred or put into business assets in the meantime; distributions or capital repayments did not exceed one quarter of the value at departure; AND Germany's right to tax a sale of the shares is restored at least to the extent it existed at departure. On application the tax office can extend the seven years by at most five years in total if the intention to return still exists ([section 6(3) AStG](https://www.gesetze-im-internet.de/astg/__6.html)).",
      "line": 83
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/de-astg6-current.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "02e9d3b19c3c5b8f0e5ab7d59de94ca5a82174a814839e2092ebffdd83f98bec",
  "source_version_basis": "Current actual official body retrieved/read2026-11-16; relevant operative unit and neighbours personally read."
}
```

### DE-INSTALMENTS

Application7equal annual instalments/security, first1month then31July/nointerest; whole versus proportional acceleration, death continuity and temporary-return deferral/interest.

```json
{
  "act_article_or_scope": "AStG6(4) full",
  "actual_read_on": "2026-11-16",
  "id": "DE-INSTALMENTS",
  "official_url": "https://www.gesetze-im-internet.de/astg/__6.html",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Instalments. On application, the tax on the deemed gain can be paid in seven equal yearly instalments. The application is normally granted only against security. The first instalment is due within one month of the tax notice; the rest fall due on 31 July of the following years; no interest is charged. Collection accelerates within one month for missed instalments, reporting default or insolvency, and to the statutory extent of a sale/transfer or distributions/capital repayments beyond the aggregate one-quarter limit ([section 6(4) AStG](https://www.gesetze-im-internet.de/astg/__6.html)). A transfer on death to a natural person is disregarded for the sale or transfer event. The law prints no special EU or EEA deferral for a departure under the current text.",
      "line": 81
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/de-astg6-current.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "02e9d3b19c3c5b8f0e5ab7d59de94ca5a82174a814839e2092ebffdd83f98bec",
  "source_version_basis": "Current actual official body retrieved/read2026-11-16; relevant operative unit and neighbours personally read."
}
```

### DE-REPORTING

Event notification1month and annual31July address/attribution electronically; successor and hardship paper exception.

```json
{
  "act_article_or_scope": "AStG6(5) full",
  "actual_read_on": "2026-11-16",
  "id": "DE-REPORTING",
  "official_url": "https://www.gesetze-im-internet.de/astg/__6.html",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Reporting. The taxpayer must report any of the events that end the instalments within one month, electronically, to the tax office that was competent at departure. Every year by 31 July the taxpayer must report the current address and confirm that the shares are still attributed to them ([section 6(5) AStG](https://www.gesetze-im-internet.de/astg/__6.html)).",
      "line": 87
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/de-astg6-current.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "02e9d3b19c3c5b8f0e5ab7d59de94ca5a82174a814839e2092ebffdd83f98bec",
  "source_version_basis": "Current actual official body retrieved/read2026-11-16; relevant operative unit and neighbours personally read."
}
```

### DE-SHARES-1

Direct/indirect1%within5years share scope, gratuitous predecessor condition and defined shares.

```json
{
  "act_article_or_scope": "EStG17(1) full",
  "actual_read_on": "2026-11-16",
  "id": "DE-SHARES-1",
  "official_url": "https://www.gesetze-im-internet.de/estg/__17.html",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "What is taxed. Only shares within section 17(1) sentence 1 EStG: shares in a corporation where the person held, directly or indirectly, at least the percentage in the table below of the capital at any time within the last five years ([section 17 EStG](https://www.gesetze-im-internet.de/estg/__17.html)). Fund units outside business assets have their own deemed sale under section 19(3) InvStG, but only if the holder held at least the percentage in the table of the issued units within the last five years, OR holds units whose acquisition cost is at least the amount in the table, per fund (units \"an dem Investmentfonds\"), and only if the sum of taxable gains is positive (\"die Summe der ... steuerpflichtigen Gewinne insgesamt positiv\") ([section 19 InvStG](https://www.gesetze-im-internet.de/invstg_2018/__19.html)). Special-investment-fund units have a separate nonbusiness rule in [InvStG 49(5)](https://www.gesetze-im-internet.de/invstg_2018/__49.html), including a positive-gain condition, different return treatment and no ordinary-fund 1%/EUR 500,000 gates. Both fund provisions incorporate the relevant AStG6(2)–(5) lookback/payment/reporting framework, with their own substitutions and the special-fund return mechanism. Do not transfer section 19’s thresholds to section 49. [Section 57(10)](https://www.gesetze-im-internet.de/invstg_2018/__57.html) applies these fund exit provisions to events after 31 December 2024. EStG17(6)/(7) also extends the covered interests in its specified restructuring/cooperative cases; do not use1% as the only possible entry route. For qualifying section17 share gains, the partial-income method is grounded in EStG3No40(c) and3c(2): the prescribed exemption and corresponding deduction limits must be applied before the individual's relevant income-tax tariff under32a. That is not a universal flat exit-tax rate or the ordinary-fund calculation. [Exemption](https://www.gesetze-im-internet.de/estg/__3.html); [deduction limits](https://www.gesetze-im-internet.de/estg/__3c.html); [2026 tariff](https://www.gesetze-im-internet.de/estg/__32a.html). This Guide does not calculate the German income tax on the gain; see `germany-to-switzerland-cross-border-tax`.",
      "line": 68
    }
  ],
  "short_exact_native_quotes": [
    "(1) 1Zu den Einkünften aus Gewerbebetrieb gehört auch der Gewinn aus der Veräußerung von Anteilen an einer Kapitalgesellschaft, wenn der Veräußerer innerhalb der letzten fünf"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/de-estg17-current.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "d5071b16954ff86f442f54e8902d9fe2ad8b366e628e452da53cbaa1e1639738",
  "source_version_basis": "Current actual official body retrieved/read2026-11-16; relevant operative unit and neighbours personally read."
}
```

### DE-SHARES-6

Specified contribution/restructuring interests can enter scope under the separate statutory extension.

```json
{
  "act_article_or_scope": "EStG17(6) full",
  "actual_read_on": "2026-11-16",
  "id": "DE-SHARES-6",
  "official_url": "https://www.gesetze-im-internet.de/estg/__17.html",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "What is taxed. Only shares within section 17(1) sentence 1 EStG: shares in a corporation where the person held, directly or indirectly, at least the percentage in the table below of the capital at any time within the last five years ([section 17 EStG](https://www.gesetze-im-internet.de/estg/__17.html)). Fund units outside business assets have their own deemed sale under section 19(3) InvStG, but only if the holder held at least the percentage in the table of the issued units within the last five years, OR holds units whose acquisition cost is at least the amount in the table, per fund (units \"an dem Investmentfonds\"), and only if the sum of taxable gains is positive (\"die Summe der ... steuerpflichtigen Gewinne insgesamt positiv\") ([section 19 InvStG](https://www.gesetze-im-internet.de/invstg_2018/__19.html)). Special-investment-fund units have a separate nonbusiness rule in [InvStG 49(5)](https://www.gesetze-im-internet.de/invstg_2018/__49.html), including a positive-gain condition, different return treatment and no ordinary-fund 1%/EUR 500,000 gates. Both fund provisions incorporate the relevant AStG6(2)–(5) lookback/payment/reporting framework, with their own substitutions and the special-fund return mechanism. Do not transfer section 19’s thresholds to section 49. [Section 57(10)](https://www.gesetze-im-internet.de/invstg_2018/__57.html) applies these fund exit provisions to events after 31 December 2024. EStG17(6)/(7) also extends the covered interests in its specified restructuring/cooperative cases; do not use1% as the only possible entry route. For qualifying section17 share gains, the partial-income method is grounded in EStG3No40(c) and3c(2): the prescribed exemption and corresponding deduction limits must be applied before the individual's relevant income-tax tariff under32a. That is not a universal flat exit-tax rate or the ordinary-fund calculation. [Exemption](https://www.gesetze-im-internet.de/estg/__3.html); [deduction limits](https://www.gesetze-im-internet.de/estg/__3c.html); [2026 tariff](https://www.gesetze-im-internet.de/estg/__32a.html). This Guide does not calculate the German income tax on the gain; see `germany-to-switzerland-cross-border-tax`.",
      "line": 68
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/de-estg17-current.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "d5071b16954ff86f442f54e8902d9fe2ad8b366e628e452da53cbaa1e1639738",
  "source_version_basis": "Current actual official body retrieved/read2026-11-16; relevant operative unit and neighbours personally read."
}
```

### DE-SHARES-7

Specified cooperative interests also enter the covered section17 scope.

```json
{
  "act_article_or_scope": "EStG17(7) full",
  "actual_read_on": "2026-11-16",
  "id": "DE-SHARES-7",
  "official_url": "https://www.gesetze-im-internet.de/estg/__17.html",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "What is taxed. Only shares within section 17(1) sentence 1 EStG: shares in a corporation where the person held, directly or indirectly, at least the percentage in the table below of the capital at any time within the last five years ([section 17 EStG](https://www.gesetze-im-internet.de/estg/__17.html)). Fund units outside business assets have their own deemed sale under section 19(3) InvStG, but only if the holder held at least the percentage in the table of the issued units within the last five years, OR holds units whose acquisition cost is at least the amount in the table, per fund (units \"an dem Investmentfonds\"), and only if the sum of taxable gains is positive (\"die Summe der ... steuerpflichtigen Gewinne insgesamt positiv\") ([section 19 InvStG](https://www.gesetze-im-internet.de/invstg_2018/__19.html)). Special-investment-fund units have a separate nonbusiness rule in [InvStG 49(5)](https://www.gesetze-im-internet.de/invstg_2018/__49.html), including a positive-gain condition, different return treatment and no ordinary-fund 1%/EUR 500,000 gates. Both fund provisions incorporate the relevant AStG6(2)–(5) lookback/payment/reporting framework, with their own substitutions and the special-fund return mechanism. Do not transfer section 19’s thresholds to section 49. [Section 57(10)](https://www.gesetze-im-internet.de/invstg_2018/__57.html) applies these fund exit provisions to events after 31 December 2024. EStG17(6)/(7) also extends the covered interests in its specified restructuring/cooperative cases; do not use1% as the only possible entry route. For qualifying section17 share gains, the partial-income method is grounded in EStG3No40(c) and3c(2): the prescribed exemption and corresponding deduction limits must be applied before the individual's relevant income-tax tariff under32a. That is not a universal flat exit-tax rate or the ordinary-fund calculation. [Exemption](https://www.gesetze-im-internet.de/estg/__3.html); [deduction limits](https://www.gesetze-im-internet.de/estg/__3c.html); [2026 tariff](https://www.gesetze-im-internet.de/estg/__32a.html). This Guide does not calculate the German income tax on the gain; see `germany-to-switzerland-cross-border-tax`.",
      "line": 68
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/de-estg17-current.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "d5071b16954ff86f442f54e8902d9fe2ad8b366e628e452da53cbaa1e1639738",
  "source_version_basis": "Current actual official body retrieved/read2026-11-16; relevant operative unit and neighbours personally read."
}
```

### DE-ORDINARY-FUNDS

Nonbusiness fund units: positive total taxable gains AND1%in5years OR acquisition cost500000 per fund; incorporated AStG rules/distribution substitutions/no withholding.

```json
{
  "act_article_or_scope": "InvStG19(3) whole",
  "actual_read_on": "2026-11-16",
  "id": "DE-ORDINARY-FUNDS",
  "official_url": "https://www.gesetze-im-internet.de/invstg_2018/__19.html",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "What is taxed. Only shares within section 17(1) sentence 1 EStG: shares in a corporation where the person held, directly or indirectly, at least the percentage in the table below of the capital at any time within the last five years ([section 17 EStG](https://www.gesetze-im-internet.de/estg/__17.html)). Fund units outside business assets have their own deemed sale under section 19(3) InvStG, but only if the holder held at least the percentage in the table of the issued units within the last five years, OR holds units whose acquisition cost is at least the amount in the table, per fund (units \"an dem Investmentfonds\"), and only if the sum of taxable gains is positive (\"die Summe der ... steuerpflichtigen Gewinne insgesamt positiv\") ([section 19 InvStG](https://www.gesetze-im-internet.de/invstg_2018/__19.html)). Special-investment-fund units have a separate nonbusiness rule in [InvStG 49(5)](https://www.gesetze-im-internet.de/invstg_2018/__49.html), including a positive-gain condition, different return treatment and no ordinary-fund 1%/EUR 500,000 gates. Both fund provisions incorporate the relevant AStG6(2)–(5) lookback/payment/reporting framework, with their own substitutions and the special-fund return mechanism. Do not transfer section 19’s thresholds to section 49. [Section 57(10)](https://www.gesetze-im-internet.de/invstg_2018/__57.html) applies these fund exit provisions to events after 31 December 2024. EStG17(6)/(7) also extends the covered interests in its specified restructuring/cooperative cases; do not use1% as the only possible entry route. For qualifying section17 share gains, the partial-income method is grounded in EStG3No40(c) and3c(2): the prescribed exemption and corresponding deduction limits must be applied before the individual's relevant income-tax tariff under32a. That is not a universal flat exit-tax rate or the ordinary-fund calculation. [Exemption](https://www.gesetze-im-internet.de/estg/__3.html); [deduction limits](https://www.gesetze-im-internet.de/estg/__3c.html); [2026 tariff](https://www.gesetze-im-internet.de/estg/__32a.html). This Guide does not calculate the German income tax on the gain; see `germany-to-switzerland-cross-border-tax`.",
      "line": 68
    }
  ],
  "short_exact_native_quotes": [
    "(3) Soweit ein unbeschränkt Steuerpflichtiger seine Investmentanteile nicht im Betriebsvermögen hält, stehen der Veräußerung von Investmentanteilen zum gemeinen Wert gleich 1. die Beendigung der unbeschränkten"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/de-fund-exit.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "1957aa9307c5d36ee505bbdeb952eda13b2f3b24c2c142a265da6651f4b4ca7c",
  "source_version_basis": "Current actual official body retrieved/read2026-11-16; relevant operative unit and neighbours personally read."
}
```

### DE-SPECIAL-FUNDS

Separate nonbusiness positive-gain rule without ordinary1%/500000gates; incorporated rules, special later-realisation return treatment and immediate fund notice.

```json
{
  "act_article_or_scope": "InvStG49(5) whole",
  "actual_read_on": "2026-11-16",
  "id": "DE-SPECIAL-FUNDS",
  "official_url": "https://www.gesetze-im-internet.de/invstg_2018/__49.html",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "What is taxed. Only shares within section 17(1) sentence 1 EStG: shares in a corporation where the person held, directly or indirectly, at least the percentage in the table below of the capital at any time within the last five years ([section 17 EStG](https://www.gesetze-im-internet.de/estg/__17.html)). Fund units outside business assets have their own deemed sale under section 19(3) InvStG, but only if the holder held at least the percentage in the table of the issued units within the last five years, OR holds units whose acquisition cost is at least the amount in the table, per fund (units \"an dem Investmentfonds\"), and only if the sum of taxable gains is positive (\"die Summe der ... steuerpflichtigen Gewinne insgesamt positiv\") ([section 19 InvStG](https://www.gesetze-im-internet.de/invstg_2018/__19.html)). Special-investment-fund units have a separate nonbusiness rule in [InvStG 49(5)](https://www.gesetze-im-internet.de/invstg_2018/__49.html), including a positive-gain condition, different return treatment and no ordinary-fund 1%/EUR 500,000 gates. Both fund provisions incorporate the relevant AStG6(2)–(5) lookback/payment/reporting framework, with their own substitutions and the special-fund return mechanism. Do not transfer section 19’s thresholds to section 49. [Section 57(10)](https://www.gesetze-im-internet.de/invstg_2018/__57.html) applies these fund exit provisions to events after 31 December 2024. EStG17(6)/(7) also extends the covered interests in its specified restructuring/cooperative cases; do not use1% as the only possible entry route. For qualifying section17 share gains, the partial-income method is grounded in EStG3No40(c) and3c(2): the prescribed exemption and corresponding deduction limits must be applied before the individual's relevant income-tax tariff under32a. That is not a universal flat exit-tax rate or the ordinary-fund calculation. [Exemption](https://www.gesetze-im-internet.de/estg/__3.html); [deduction limits](https://www.gesetze-im-internet.de/estg/__3c.html); [2026 tariff](https://www.gesetze-im-internet.de/estg/__32a.html). This Guide does not calculate the German income tax on the gain; see `germany-to-switzerland-cross-border-tax`.",
      "line": 68
    }
  ],
  "short_exact_native_quotes": [
    "(5) Soweit ein unbeschränkt Steuerpflichtiger seine Spezial-Investmentanteile nicht im Betriebsvermögen hält, stehen der Veräußerung von Spezial-Investmentanteilen zum gemeinen Wert gleich 1. die Beendigung der unbeschränkten"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/de-special-fund-exit.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "59a8af9e77b639332a117872507f8716f1ef22364302acd03270530878b3fc07",
  "source_version_basis": "Current actual official body retrieved/read2026-11-16; relevant operative unit and neighbours personally read."
}
```

### DE-FUND-EFFECT

New ordinary/special fund exit provisions apply to events after31December2024.

```json
{
  "act_article_or_scope": "InvStG57(10) whole",
  "actual_read_on": "2026-11-16",
  "id": "DE-FUND-EFFECT",
  "official_url": "https://www.gesetze-im-internet.de/invstg_2018/__57.html",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "What is taxed. Only shares within section 17(1) sentence 1 EStG: shares in a corporation where the person held, directly or indirectly, at least the percentage in the table below of the capital at any time within the last five years ([section 17 EStG](https://www.gesetze-im-internet.de/estg/__17.html)). Fund units outside business assets have their own deemed sale under section 19(3) InvStG, but only if the holder held at least the percentage in the table of the issued units within the last five years, OR holds units whose acquisition cost is at least the amount in the table, per fund (units \"an dem Investmentfonds\"), and only if the sum of taxable gains is positive (\"die Summe der ... steuerpflichtigen Gewinne insgesamt positiv\") ([section 19 InvStG](https://www.gesetze-im-internet.de/invstg_2018/__19.html)). Special-investment-fund units have a separate nonbusiness rule in [InvStG 49(5)](https://www.gesetze-im-internet.de/invstg_2018/__49.html), including a positive-gain condition, different return treatment and no ordinary-fund 1%/EUR 500,000 gates. Both fund provisions incorporate the relevant AStG6(2)–(5) lookback/payment/reporting framework, with their own substitutions and the special-fund return mechanism. Do not transfer section 19’s thresholds to section 49. [Section 57(10)](https://www.gesetze-im-internet.de/invstg_2018/__57.html) applies these fund exit provisions to events after 31 December 2024. EStG17(6)/(7) also extends the covered interests in its specified restructuring/cooperative cases; do not use1% as the only possible entry route. For qualifying section17 share gains, the partial-income method is grounded in EStG3No40(c) and3c(2): the prescribed exemption and corresponding deduction limits must be applied before the individual's relevant income-tax tariff under32a. That is not a universal flat exit-tax rate or the ordinary-fund calculation. [Exemption](https://www.gesetze-im-internet.de/estg/__3.html); [deduction limits](https://www.gesetze-im-internet.de/estg/__3c.html); [2026 tariff](https://www.gesetze-im-internet.de/estg/__32a.html). This Guide does not calculate the German income tax on the gain; see `germany-to-switzerland-cross-border-tax`.",
      "line": 68
    }
  ],
  "short_exact_native_quotes": [
    "(10) In der Fassung des Artikels 11 des Gesetzes vom 2. Dezember 2024 (BGBl. 2024 I Nr. 387) sind anzuwenden: 1. § 17 Absatz 1"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/de-fund-transition.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "c4e7bc533c88fa53a14da0d4f39db3a05f3e011af2f141fe3d1692eb069818d6",
  "source_version_basis": "Current actual official body retrieved/read2026-11-16; relevant operative unit and neighbours personally read."
}
```

### DE-OLD-EVENTS

Old pre2022events continue the older6version, subject to21(3)modifications.

```json
{
  "act_article_or_scope": "AStG21(3) whole",
  "actual_read_on": "2026-11-16",
  "id": "DE-OLD-EVENTS",
  "official_url": "https://www.gesetze-im-internet.de/astg/__21.html",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Older departures. Where a trigger under the version in force until 30 June 2021 happened before 1 January 2022, that older version continues to apply to the case, with the modifications in section 21(3) AStG ([section 21 AStG](https://www.gesetze-im-internet.de/astg/__21.html)).",
      "line": 89
    }
  ],
  "short_exact_native_quotes": [
    "(3) Wurde ein Tatbestand des § 6 Absatz 1 in einer bis zum 30. Juni 2021 geltenden Fassung vor dem 1. Januar 2022 verwirklicht, ist"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/de-astg21-current.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "9ea1aacd4d4df2f6341b2fa4029382dff313e47ccedeb9c272ee0bc35bf41433",
  "source_version_basis": "Current actual official body retrieved/read2026-11-16; relevant operative unit and neighbours personally read."
}
```

### DE-PARTIAL-EXEMPTION

Qualifying section17fair-value/disposal proceeds are within3No40(c), with the paragraph’s scope/exceptions. No universal flat exit rate is calculated.

```json
{
  "act_article_or_scope": "EStG3No40 all(a)–(i) and following limitations, not whole§3",
  "actual_read_on": "2026-11-16",
  "id": "DE-PARTIAL-EXEMPTION",
  "official_url": "https://www.gesetze-im-internet.de/estg/__3.html",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "What is taxed. Only shares within section 17(1) sentence 1 EStG: shares in a corporation where the person held, directly or indirectly, at least the percentage in the table below of the capital at any time within the last five years ([section 17 EStG](https://www.gesetze-im-internet.de/estg/__17.html)). Fund units outside business assets have their own deemed sale under section 19(3) InvStG, but only if the holder held at least the percentage in the table of the issued units within the last five years, OR holds units whose acquisition cost is at least the amount in the table, per fund (units \"an dem Investmentfonds\"), and only if the sum of taxable gains is positive (\"die Summe der ... steuerpflichtigen Gewinne insgesamt positiv\") ([section 19 InvStG](https://www.gesetze-im-internet.de/invstg_2018/__19.html)). Special-investment-fund units have a separate nonbusiness rule in [InvStG 49(5)](https://www.gesetze-im-internet.de/invstg_2018/__49.html), including a positive-gain condition, different return treatment and no ordinary-fund 1%/EUR 500,000 gates. Both fund provisions incorporate the relevant AStG6(2)–(5) lookback/payment/reporting framework, with their own substitutions and the special-fund return mechanism. Do not transfer section 19’s thresholds to section 49. [Section 57(10)](https://www.gesetze-im-internet.de/invstg_2018/__57.html) applies these fund exit provisions to events after 31 December 2024. EStG17(6)/(7) also extends the covered interests in its specified restructuring/cooperative cases; do not use1% as the only possible entry route. For qualifying section17 share gains, the partial-income method is grounded in EStG3No40(c) and3c(2): the prescribed exemption and corresponding deduction limits must be applied before the individual's relevant income-tax tariff under32a. That is not a universal flat exit-tax rate or the ordinary-fund calculation. [Exemption](https://www.gesetze-im-internet.de/estg/__3.html); [deduction limits](https://www.gesetze-im-internet.de/estg/__3c.html); [2026 tariff](https://www.gesetze-im-internet.de/estg/__32a.html). This Guide does not calculate the German income tax on the gain; see `germany-to-switzerland-cross-border-tax`.",
      "line": 68
    }
  ],
  "short_exact_native_quotes": [
    "40 Prozent a) der Betriebsvermögensmehrungen oder Einnahmen aus der Veräußerung oder der Entnahme von Anteilen an Körperschaften, Personenvereinigungen und Vermögensmassen, deren Leistungen beim Empfänger zu"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/de-estg3-current.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "2f28fb98d2fc85f1370351d93e3d3caf3ca08135c99e08d49423856988eed639",
  "source_version_basis": "Current actual official body retrieved/read2026-11-16; relevant operative unit and neighbours personally read."
}
```

### DE-PARTIAL-DEDUCTIONS

Corresponding deduction restriction under3c(2), not an unrestricted deduction against partial-income gains.

```json
{
  "act_article_or_scope": "EStG3c(2) full",
  "actual_read_on": "2026-11-16",
  "id": "DE-PARTIAL-DEDUCTIONS",
  "official_url": "https://www.gesetze-im-internet.de/estg/__3c.html",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "What is taxed. Only shares within section 17(1) sentence 1 EStG: shares in a corporation where the person held, directly or indirectly, at least the percentage in the table below of the capital at any time within the last five years ([section 17 EStG](https://www.gesetze-im-internet.de/estg/__17.html)). Fund units outside business assets have their own deemed sale under section 19(3) InvStG, but only if the holder held at least the percentage in the table of the issued units within the last five years, OR holds units whose acquisition cost is at least the amount in the table, per fund (units \"an dem Investmentfonds\"), and only if the sum of taxable gains is positive (\"die Summe der ... steuerpflichtigen Gewinne insgesamt positiv\") ([section 19 InvStG](https://www.gesetze-im-internet.de/invstg_2018/__19.html)). Special-investment-fund units have a separate nonbusiness rule in [InvStG 49(5)](https://www.gesetze-im-internet.de/invstg_2018/__49.html), including a positive-gain condition, different return treatment and no ordinary-fund 1%/EUR 500,000 gates. Both fund provisions incorporate the relevant AStG6(2)–(5) lookback/payment/reporting framework, with their own substitutions and the special-fund return mechanism. Do not transfer section 19’s thresholds to section 49. [Section 57(10)](https://www.gesetze-im-internet.de/invstg_2018/__57.html) applies these fund exit provisions to events after 31 December 2024. EStG17(6)/(7) also extends the covered interests in its specified restructuring/cooperative cases; do not use1% as the only possible entry route. For qualifying section17 share gains, the partial-income method is grounded in EStG3No40(c) and3c(2): the prescribed exemption and corresponding deduction limits must be applied before the individual's relevant income-tax tariff under32a. That is not a universal flat exit-tax rate or the ordinary-fund calculation. [Exemption](https://www.gesetze-im-internet.de/estg/__3.html); [deduction limits](https://www.gesetze-im-internet.de/estg/__3c.html); [2026 tariff](https://www.gesetze-im-internet.de/estg/__32a.html). This Guide does not calculate the German income tax on the gain; see `germany-to-switzerland-cross-border-tax`.",
      "line": 68
    }
  ],
  "short_exact_native_quotes": [
    "(2) 1Betriebsvermögensminderungen, Betriebsausgaben, Veräußerungskosten oder Werbungskosten, die mit den dem § 3 Nummer 40 zugrunde liegenden Betriebsvermögensmehrungen oder Einnahmen oder mit Vergütungen nach § 3"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/de-estg3c-current.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "a1510ec43cb2cee82e97b7b79abb006e06b27e028e7030848baae91915d475d1",
  "source_version_basis": "Current actual official body retrieved/read2026-11-16; relevant operative unit and neighbours personally read."
}
```

### DE-PERSONAL-TARIFF

2026personal progressive tariff is conditional on taxable income and applicable exceptions; this comparison deliberately does not compute the full German bill.

```json
{
  "act_article_or_scope": "EStG32a(1) full2026table, rounding and exclusions",
  "actual_read_on": "2026-11-16",
  "id": "DE-PERSONAL-TARIFF",
  "official_url": "https://www.gesetze-im-internet.de/estg/__32a.html",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "What is taxed. Only shares within section 17(1) sentence 1 EStG: shares in a corporation where the person held, directly or indirectly, at least the percentage in the table below of the capital at any time within the last five years ([section 17 EStG](https://www.gesetze-im-internet.de/estg/__17.html)). Fund units outside business assets have their own deemed sale under section 19(3) InvStG, but only if the holder held at least the percentage in the table of the issued units within the last five years, OR holds units whose acquisition cost is at least the amount in the table, per fund (units \"an dem Investmentfonds\"), and only if the sum of taxable gains is positive (\"die Summe der ... steuerpflichtigen Gewinne insgesamt positiv\") ([section 19 InvStG](https://www.gesetze-im-internet.de/invstg_2018/__19.html)). Special-investment-fund units have a separate nonbusiness rule in [InvStG 49(5)](https://www.gesetze-im-internet.de/invstg_2018/__49.html), including a positive-gain condition, different return treatment and no ordinary-fund 1%/EUR 500,000 gates. Both fund provisions incorporate the relevant AStG6(2)–(5) lookback/payment/reporting framework, with their own substitutions and the special-fund return mechanism. Do not transfer section 19’s thresholds to section 49. [Section 57(10)](https://www.gesetze-im-internet.de/invstg_2018/__57.html) applies these fund exit provisions to events after 31 December 2024. EStG17(6)/(7) also extends the covered interests in its specified restructuring/cooperative cases; do not use1% as the only possible entry route. For qualifying section17 share gains, the partial-income method is grounded in EStG3No40(c) and3c(2): the prescribed exemption and corresponding deduction limits must be applied before the individual's relevant income-tax tariff under32a. That is not a universal flat exit-tax rate or the ordinary-fund calculation. [Exemption](https://www.gesetze-im-internet.de/estg/__3.html); [deduction limits](https://www.gesetze-im-internet.de/estg/__3c.html); [2026 tariff](https://www.gesetze-im-internet.de/estg/__32a.html). This Guide does not calculate the German income tax on the gain; see `germany-to-switzerland-cross-border-tax`.",
      "line": 68
    }
  ],
  "short_exact_native_quotes": [
    "(1) 1Die tarifliche Einkommensteuer bemisst sich nach dem auf volle Euro abgerundeten zu versteuernden Einkommen. 2Sie beträgt ab dem Veranlagungszeitraum 2026 vorbehaltlich der §§ 32b,"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/de-estg32a-current.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "49ab8f1ba02bd46cb481df3eb0441a2f12e1319802a2788bdc4c3b872fe93269",
  "source_version_basis": "Current actual official body retrieved/read2026-11-16; relevant operative unit and neighbours personally read."
}
```

### FR-I

History6of10 for latent gains/earnout; household direct/indirect50%OR>800000, valuation/basis/exchange/allowances and no latent-loss offset.

```json
{
  "act_article_or_scope": "CGI167bisI full",
  "actual_read_on": "2026-11-16",
  "id": "FR-I",
  "official_url": "https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000048806379",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Who and what is caught. Article I requires at least 6 of the preceding 10 years of French tax domicile for latent gains and earn-out receivables. The household’s directly or indirectly held securities trigger latent-gain taxation if they represent at least 50% of a company’s profits OR their aggregate value exceeds EUR 800,000. Those holding/value gates do not turn previously deferred gains under II into the same category: II independently brings its listed deferred gains into charge on departure. The deemed transfer is the day before worldwide French taxation ceases. Value less tax acquisition value gives the latent gain, with the exchange-basis and applicable allowance provisions in I(2)–(3). Latent losses cannot offset those gains or other gains. [CGI I–III](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000048806379).",
      "line": 95
    }
  ],
  "short_exact_native_quotes": [
    "I. – 1. Les contribuables fiscalement domiciliés en France pendant au moins six des dix années précédant le transfert de leur domicile fiscal hors de"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/fr-cgi167bis-web-native.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "d1a27f76e068e710cf46de59c8f05cb0d9049dd13ec003ace0cf6b8dad8e8306",
  "source_version_basis": "Actual current article effective2024-01-01, personally re-read2026-11-16 I–X, not CLI403 challenge."
}
```

### FR-II

Previously deferred listed gains separately enter charge on departure, without falsely inheriting Iholding/history gates.

```json
{
  "act_article_or_scope": "CGI167bisII full",
  "actual_read_on": "2026-11-16",
  "id": "FR-II",
  "official_url": "https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000048806379",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Who and what is caught. Article I requires at least 6 of the preceding 10 years of French tax domicile for latent gains and earn-out receivables. The household’s directly or indirectly held securities trigger latent-gain taxation if they represent at least 50% of a company’s profits OR their aggregate value exceeds EUR 800,000. Those holding/value gates do not turn previously deferred gains under II into the same category: II independently brings its listed deferred gains into charge on departure. The deemed transfer is the day before worldwide French taxation ceases. Value less tax acquisition value gives the latent gain, with the exchange-basis and applicable allowance provisions in I(2)–(3). Latent losses cannot offset those gains or other gains. [CGI I–III](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000048806379).",
      "line": 95
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/fr-cgi167bis-web-native.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "d1a27f76e068e710cf46de59c8f05cb0d9049dd13ec003ace0cf6b8dad8e8306",
  "source_version_basis": "Actual current article effective2024-01-01, personally re-read2026-11-16 I–X, not CLI403 challenge."
}
```

### FR-II-bis

Ordinary income-tax calculation/global progressive treatment versus special historic150-0Bter rate; no selective asset election.

```json
{
  "act_article_or_scope": "CGI167bisII bis full",
  "actual_read_on": "2026-11-16",
  "id": "FR-II-bis",
  "official_url": "https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000048806379",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "The progressive election is global for the household’s relevant capital income/gains, using 2OP; it is not a selective election for one favourable asset. Historic-rate deferred gains under article 150-0 B ter require their separate calculation. [CGI II bis](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000048806379); [notice II, p4](https://www.impots.gouv.fr/sites/default/files/formulaires/2074-etd/2026/2074-etd_5518.pdf).",
      "line": 107
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/fr-cgi167bis-web-native.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "d1a27f76e068e710cf46de59c8f05cb0d9049dd13ec003ace0cf6b8dad8e8306",
  "source_version_basis": "Actual current article effective2024-01-01, personally re-read2026-11-16 I–X, not CLI403 challenge."
}
```

### FR-III

Deemed transfer the day before worldwide French taxation ceases.

```json
{
  "act_article_or_scope": "CGI167bisIII full",
  "actual_read_on": "2026-11-16",
  "id": "FR-III",
  "official_url": "https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000048806379",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Who and what is caught. Article I requires at least 6 of the preceding 10 years of French tax domicile for latent gains and earn-out receivables. The household’s directly or indirectly held securities trigger latent-gain taxation if they represent at least 50% of a company’s profits OR their aggregate value exceeds EUR 800,000. Those holding/value gates do not turn previously deferred gains under II into the same category: II independently brings its listed deferred gains into charge on departure. The deemed transfer is the day before worldwide French taxation ceases. Value less tax acquisition value gives the latent gain, with the exchange-basis and applicable allowance provisions in I(2)–(3). Latent losses cannot offset those gains or other gains. [CGI I–III](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000048806379).",
      "line": 95
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/fr-cgi167bis-web-native.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "d1a27f76e068e710cf46de59c8f05cb0d9049dd13ec003ace0cf6b8dad8e8306",
  "source_version_basis": "Actual current article effective2024-01-01, personally re-read2026-11-16 I–X, not CLI403 challenge."
}
```

### FR-IV

Automatic suspension: EU OR both qualifying assistance agreements and noncooperative exclusion.

```json
{
  "act_article_or_scope": "CGI167bisIV full",
  "actual_read_on": "2026-11-16",
  "id": "FR-IV",
  "official_url": "https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000048806379",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Suspension. IV grants automatic suspension for the EU or a destination with BOTH qualifying administrative and recovery assistance that is not noncooperative. The notice’s list for transfers from 2025 includes the UK, US, Australia, Norway and Monaco; it does not list Switzerland or the UAE. Test the current legal agreements and status for the actual destination/date rather than treating the dated list as immutable. V allows an express request for other destinations or a later onward move outside IV, with declaration, a representative in France and predeparture guarantees. It sets a 12.8%-of-gross provisional guarantee rule, a special historic-rate rule and possible adjustment within 1 month after the notice. No work-related security waiver is stated in this current V. [CGI IV–VI](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000048806379); [notice III, pp4–5](https://www.impots.gouv.fr/sites/default/files/formulaires/2074-etd/2026/2074-etd_5518.pdf).",
      "line": 109
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/fr-cgi167bis-web-native.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "d1a27f76e068e710cf46de59c8f05cb0d9049dd13ec003ace0cf6b8dad8e8306",
  "source_version_basis": "Actual current article effective2024-01-01, personally re-read2026-11-16 I–X, not CLI403 challenge."
}
```

### FR-V

Express suspension/second move declaration, representative, predeparture guarantees12.8%gross/historic exception,1month adjustment and guarantee release; no work waiver.

```json
{
  "act_article_or_scope": "CGI167bisV full",
  "actual_read_on": "2026-11-16",
  "id": "FR-V",
  "official_url": "https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000048806379",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Suspension. IV grants automatic suspension for the EU or a destination with BOTH qualifying administrative and recovery assistance that is not noncooperative. The notice’s list for transfers from 2025 includes the UK, US, Australia, Norway and Monaco; it does not list Switzerland or the UAE. Test the current legal agreements and status for the actual destination/date rather than treating the dated list as immutable. V allows an express request for other destinations or a later onward move outside IV, with declaration, a representative in France and predeparture guarantees. It sets a 12.8%-of-gross provisional guarantee rule, a special historic-rate rule and possible adjustment within 1 month after the notice. No work-related security waiver is stated in this current V. [CGI IV–VI](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000048806379); [notice III, pp4–5](https://www.impots.gouv.fr/sites/default/files/formulaires/2074-etd/2026/2074-etd_5518.pdf).",
      "line": 109
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/fr-cgi167bis-web-native.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "d1a27f76e068e710cf46de59c8f05cb0d9049dd13ec003ace0cf6b8dad8e8306",
  "source_version_basis": "Actual current article effective2024-01-01, personally re-read2026-11-16 I–X, not CLI403 challenge."
}
```

### FR-VI

Suspension affects recovery limitation and specified procedural status.

```json
{
  "act_article_or_scope": "CGI167bisVI full",
  "actual_read_on": "2026-11-16",
  "id": "FR-VI",
  "official_url": "https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000048806379",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Suspension. IV grants automatic suspension for the EU or a destination with BOTH qualifying administrative and recovery assistance that is not noncooperative. The notice’s list for transfers from 2025 includes the UK, US, Australia, Norway and Monaco; it does not list Switzerland or the UAE. Test the current legal agreements and status for the actual destination/date rather than treating the dated list as immutable. V allows an express request for other destinations or a later onward move outside IV, with declaration, a representative in France and predeparture guarantees. It sets a 12.8%-of-gross provisional guarantee rule, a special historic-rate rule and possible adjustment within 1 month after the notice. No work-related security waiver is stated in this current V. [CGI IV–VI](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000048806379); [notice III, pp4–5](https://www.impots.gouv.fr/sites/default/files/formulaires/2074-etd/2026/2074-etd_5518.pdf).",
      "line": 109
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/fr-cgi167bis-web-native.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "d1a27f76e068e710cf46de59c8f05cb0d9049dd13ec003ace0cf6b8dad8e8306",
  "source_version_basis": "Actual current article effective2024-01-01, personally re-read2026-11-16 I–X, not CLI403 challenge."
}
```

### FR-VII

Category-specific acceleration, exchange/rollover exceptions, gifts/death, retained latent-gain2years or5onlystrict>2.57m, return deferred-status restoration and remaining earnout less receipts.

```json
{
  "act_article_or_scope": "CGI167bisVII full",
  "actual_read_on": "2026-11-16",
  "id": "FR-VII",
  "official_url": "https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000048806379",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Acceleration and relief. Sale, redemption, repayment or cancellation can end suspension, subject to the express qualifying-exchange/contribution exceptions. Gifts and death differ between latent gains, the listed historical deferred-gain regimes and earn-out claims; never apply one category’s exception to all categories. Qualifying latent gains are relieved/refunded after the 2- or 5-year period if the required securities remain held, or on an earlier qualifying return. The statute says the 5-year period applies only above EUR 2.57 million; equality therefore stays on the 2-year side, despite inconsistent equality shorthand in the notice. This time relief does not discharge every deferred gain or receivable. On return, VII(3) restores the predeparture tax position for retained deferred-gain securities; VII(4) limits earn-out relief to the retained claim, after intervening receipts. Donation, death, lower actual gains/losses and foreign tax can also change the charge under their own VII–VIII conditions. [CGI VII–VIII bis](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000048806379).",
      "line": 111
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/fr-cgi167bis-web-native.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "d1a27f76e068e710cf46de59c8f05cb0d9049dd13ec003ace0cf6b8dad8e8306",
  "source_version_basis": "Actual current article effective2024-01-01, personally re-read2026-11-16 I–X, not CLI403 challenge."
}
```

### FR-VIII

Actual lower gain/loss, allowance and French/foreign tax effects with statutory limitations and credit ordering.

```json
{
  "act_article_or_scope": "CGI167bisVIII full",
  "actual_read_on": "2026-11-16",
  "id": "FR-VIII",
  "official_url": "https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000048806379",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Acceleration and relief. Sale, redemption, repayment or cancellation can end suspension, subject to the express qualifying-exchange/contribution exceptions. Gifts and death differ between latent gains, the listed historical deferred-gain regimes and earn-out claims; never apply one category’s exception to all categories. Qualifying latent gains are relieved/refunded after the 2- or 5-year period if the required securities remain held, or on an earlier qualifying return. The statute says the 5-year period applies only above EUR 2.57 million; equality therefore stays on the 2-year side, despite inconsistent equality shorthand in the notice. This time relief does not discharge every deferred gain or receivable. On return, VII(3) restores the predeparture tax position for retained deferred-gain securities; VII(4) limits earn-out relief to the retained claim, after intervening receipts. Donation, death, lower actual gains/losses and foreign tax can also change the charge under their own VII–VIII conditions. [CGI VII–VIII bis](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000048806379).",
      "line": 111
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/fr-cgi167bis-web-native.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "d1a27f76e068e710cf46de59c8f05cb0d9049dd13ec003ace0cf6b8dad8e8306",
  "source_version_basis": "Actual current article effective2024-01-01, personally re-read2026-11-16 I–X, not CLI403 challenge."
}
```

### FR-VIII-bis

Definitive-event rate, optional recomputation and irrevocable global choice conditions.

```json
{
  "act_article_or_scope": "CGI167bisVIII bis full",
  "actual_read_on": "2026-11-16",
  "id": "FR-VIII-bis",
  "official_url": "https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000048806379",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Acceleration and relief. Sale, redemption, repayment or cancellation can end suspension, subject to the express qualifying-exchange/contribution exceptions. Gifts and death differ between latent gains, the listed historical deferred-gain regimes and earn-out claims; never apply one category’s exception to all categories. Qualifying latent gains are relieved/refunded after the 2- or 5-year period if the required securities remain held, or on an earlier qualifying return. The statute says the 5-year period applies only above EUR 2.57 million; equality therefore stays on the 2-year side, despite inconsistent equality shorthand in the notice. This time relief does not discharge every deferred gain or receivable. On return, VII(3) restores the predeparture tax position for retained deferred-gain securities; VII(4) limits earn-out relief to the retained claim, after intervening receipts. Donation, death, lower actual gains/losses and foreign tax can also change the charge under their own VII–VIII conditions. [CGI VII–VIII bis](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000048806379).",
      "line": 111
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/fr-cgi167bis-web-native.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "d1a27f76e068e710cf46de59c8f05cb0d9049dd13ec003ace0cf6b8dad8e8306",
  "source_version_basis": "Actual current article effective2024-01-01, personally re-read2026-11-16 I–X, not CLI403 challenge."
}
```

### FR-IX

Initial declaration year after departure; annual receivable/deferred/mixed versus event-based latent cases, due amounts/evidence/payment and default consequences.

```json
{
  "act_article_or_scope": "CGI167bisIX full",
  "actual_read_on": "2026-11-16",
  "id": "FR-IX",
  "official_url": "https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000048806379",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Forms and timing. IX normally requires the initial declaration in the year AFTER departure, within the income-return deadline. The 2026 notice for 2025 transfers uses paper 2074-ETD with 2042/2042 C; an express suspension request instead requires an initial ETD at least 90 days BEFORE departure and a second filing the next year. Follow-up since 2014 uses ETS3: latent-gains-only cases after 2018 are generally event-based; deferred gains/receivables and mixed cases retain annual reporting, with ETSL available in specified no-event cases. Subsequent changes of tax domicile must be notified within 2 months; the move may itself end automatic suspension. Do not invent a calendar deadline or a final 2027 form for a 2026 departure. [CGI IX–X](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000048806379); [ETD notice V–IX, pp7–9](https://www.impots.gouv.fr/sites/default/files/formulaires/2074-etd/2026/2074-etd_5518.pdf); [ETS3 notice I–III](https://www.impots.gouv.fr/sites/default/files/formulaires/2074-ets3/2026/2074-ets3_5526.pdf). The authority’s 2026 simulator labels 8TN for tax on gains in payment suspension; that confirms the old code only for its stated 2025-income version, not universal 2026-departure filing instructions. [Actual simulator field](https://simulateur-ir-ifi.impots.gouv.fr/calcul_impot/2026/complet/). For depth use `leaving-france-exit-tax`.",
      "line": 115
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/fr-cgi167bis-web-native.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "d1a27f76e068e710cf46de59c8f05cb0d9049dd13ec003ace0cf6b8dad8e8306",
  "source_version_basis": "Actual current article effective2024-01-01, personally re-read2026-11-16 I–X, not CLI403 challenge."
}
```

### FR-X

Later foreign domicile changes must be notified within2months; new legal status matters.

```json
{
  "act_article_or_scope": "CGI167bisX full",
  "actual_read_on": "2026-11-16",
  "id": "FR-X",
  "official_url": "https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000048806379",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Forms and timing. IX normally requires the initial declaration in the year AFTER departure, within the income-return deadline. The 2026 notice for 2025 transfers uses paper 2074-ETD with 2042/2042 C; an express suspension request instead requires an initial ETD at least 90 days BEFORE departure and a second filing the next year. Follow-up since 2014 uses ETS3: latent-gains-only cases after 2018 are generally event-based; deferred gains/receivables and mixed cases retain annual reporting, with ETSL available in specified no-event cases. Subsequent changes of tax domicile must be notified within 2 months; the move may itself end automatic suspension. Do not invent a calendar deadline or a final 2027 form for a 2026 departure. [CGI IX–X](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000048806379); [ETD notice V–IX, pp7–9](https://www.impots.gouv.fr/sites/default/files/formulaires/2074-etd/2026/2074-etd_5518.pdf); [ETS3 notice I–III](https://www.impots.gouv.fr/sites/default/files/formulaires/2074-ets3/2026/2074-ets3_5526.pdf). The authority’s 2026 simulator labels 8TN for tax on gains in payment suspension; that confirms the old code only for its stated 2025-income version, not universal 2026-departure filing instructions. [Actual simulator field](https://simulateur-ir-ifi.impots.gouv.fr/calcul_impot/2026/complet/). For depth use `leaving-france-exit-tax`.",
      "line": 115
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/fr-cgi167bis-web-native.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "d1a27f76e068e710cf46de59c8f05cb0d9049dd13ec003ace0cf6b8dad8e8306",
  "source_version_basis": "Actual current article effective2024-01-01, personally re-read2026-11-16 I–X, not CLI403 challenge."
}
```

### NL-ENJOYMENT

Rights of enjoyment: a person only entitled to share benefits is equated with a shareholder and the entitlement with a share; corresponding profit-certificate equivalence. Distinct from acquisition rights.

```json
{
  "act_article_or_scope": "WetIB2001 4.3 whole operative body",
  "actual_read_on": "2026-11-16",
  "id": "NL-ENJOYMENT",
  "official_url": "https://wetten.overheid.nl/BWBR0011353",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Scope and trigger. [Wet IB 2001 4.16(1)(h)](https://wetten.overheid.nl/BWBR0011353) treats cessation of domestic tax liability otherwise than death as a deemed disposal of a substantial interest. It is not restricted to Dutch-incorporated companies. The 4.18 exception for a non-Dutch-established company requires departure within 8 years after arrival AND no more than 10 total years of Dutch residence in the preceding 25 years. Check its full facts before charging foreign-company shares. Article 4.6 includes at least 5% held directly/indirectly, alone or with a partner, in shares, acquisition rights, profit certificates and specified voting interests; class rules and family attribution can extend scope under the adjacent provisions. Article 4.3 separately equates a person entitled only to benefits from shares (rights of enjoyment, genotsrechten) with a shareholder and treats that entitlement as a share; it does the corresponding thing for benefits from profit certificates. These are distinct from acquisition rights. [Statutory equivalence 4.3](https://wetten.overheid.nl/BWBR0011353). [Statute 4.6–4.7/4.16–4.18](https://wetten.overheid.nl/BWBR0011353); [2026 authority substantial-interest explanation](https://www.belastingdienst.nl/wps/wcm/connect/fisin/fisin2026/aanmerkelijk_belang).",
      "line": 119
    }
  ],
  "short_exact_native_quotes": [
    "Artikel 4.3. Genotsrechten Toon relaties in LiDO Maak een permanente link Toon wetstechnische informatie ... Druk het regelingonderdeel af Sla het regelingonderdeel op Voor de"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/nl-wetib-current-compact.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "d260c551bfea3f2cd726654ae98fc0cf3157b9ee6a6a86ddd2d226b45d261cac",
  "source_version_basis": "Current official body from2026-02-21, ordinaryHTTP200; whitespace-only compact derivative, not a future amendment."
}
```

### NL-RATES

Printed2026box2table:68843ceiling,24.5%,fixed16866and31%above; do not reconstruct fractional first-band base.

```json
{
  "act_article_or_scope": "WetIB2001 2.12 whole operative body",
  "actual_read_on": "2026-11-16",
  "id": "NL-RATES",
  "official_url": "https://wetten.overheid.nl/BWBR0011353",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Use the printed tax table in article 2.12, rather than constructing an unrounded base from the first percentage. The difference is reconciled in the worked example. [Current table](https://wetten.overheid.nl/BWBR0011353); [authority rates and example](https://www.belastingdienst.nl/wps/wcm/connect/bldcontentnl/belastingdienst/prive/inkomstenbelasting/heffingskortingen_boxen_tarieven/boxen_en_tarieven/box_2/box_2).",
      "line": 131
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/nl-wetib-current-compact.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "d260c551bfea3f2cd726654ae98fc0cf3157b9ee6a6a86ddd2d226b45d261cac",
  "source_version_basis": "Current official body from2026-02-21, ordinaryHTTP200; whitespace-only compact derivative, not a future amendment."
}
```

### NL-SCOPE

Alone/partner direct/indirect5%rights and specified instruments.

```json
{
  "act_article_or_scope": "WetIB2001 4.6 whole operative body",
  "actual_read_on": "2026-11-16",
  "id": "NL-SCOPE",
  "official_url": "https://wetten.overheid.nl/BWBR0011353",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Scope and trigger. [Wet IB 2001 4.16(1)(h)](https://wetten.overheid.nl/BWBR0011353) treats cessation of domestic tax liability otherwise than death as a deemed disposal of a substantial interest. It is not restricted to Dutch-incorporated companies. The 4.18 exception for a non-Dutch-established company requires departure within 8 years after arrival AND no more than 10 total years of Dutch residence in the preceding 25 years. Check its full facts before charging foreign-company shares. Article 4.6 includes at least 5% held directly/indirectly, alone or with a partner, in shares, acquisition rights, profit certificates and specified voting interests; class rules and family attribution can extend scope under the adjacent provisions. Article 4.3 separately equates a person entitled only to benefits from shares (rights of enjoyment, genotsrechten) with a shareholder and treats that entitlement as a share; it does the corresponding thing for benefits from profit certificates. These are distinct from acquisition rights. [Statutory equivalence 4.3](https://wetten.overheid.nl/BWBR0011353). [Statute 4.6–4.7/4.16–4.18](https://wetten.overheid.nl/BWBR0011353); [2026 authority substantial-interest explanation](https://www.belastingdienst.nl/wps/wcm/connect/fisin/fisin2026/aanmerkelijk_belang).",
      "line": 119
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/nl-wetib-current-compact.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "d260c551bfea3f2cd726654ae98fc0cf3157b9ee6a6a86ddd2d226b45d261cac",
  "source_version_basis": "Current official body from2026-02-21, ordinaryHTTP200; whitespace-only compact derivative, not a future amendment."
}
```

### NL-CLASS

Specified class and special-right distinctions extend the ordinary test.

```json
{
  "act_article_or_scope": "WetIB2001 4.7 whole operative body",
  "actual_read_on": "2026-11-16",
  "id": "NL-CLASS",
  "official_url": "https://wetten.overheid.nl/BWBR0011353",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Scope and trigger. [Wet IB 2001 4.16(1)(h)](https://wetten.overheid.nl/BWBR0011353) treats cessation of domestic tax liability otherwise than death as a deemed disposal of a substantial interest. It is not restricted to Dutch-incorporated companies. The 4.18 exception for a non-Dutch-established company requires departure within 8 years after arrival AND no more than 10 total years of Dutch residence in the preceding 25 years. Check its full facts before charging foreign-company shares. Article 4.6 includes at least 5% held directly/indirectly, alone or with a partner, in shares, acquisition rights, profit certificates and specified voting interests; class rules and family attribution can extend scope under the adjacent provisions. Article 4.3 separately equates a person entitled only to benefits from shares (rights of enjoyment, genotsrechten) with a shareholder and treats that entitlement as a share; it does the corresponding thing for benefits from profit certificates. These are distinct from acquisition rights. [Statutory equivalence 4.3](https://wetten.overheid.nl/BWBR0011353). [Statute 4.6–4.7/4.16–4.18](https://wetten.overheid.nl/BWBR0011353); [2026 authority substantial-interest explanation](https://www.belastingdienst.nl/wps/wcm/connect/fisin/fisin2026/aanmerkelijk_belang).",
      "line": 119
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/nl-wetib-current-compact.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "d260c551bfea3f2cd726654ae98fc0cf3157b9ee6a6a86ddd2d226b45d261cac",
  "source_version_basis": "Current official body from2026-02-21, ordinaryHTTP200; whitespace-only compact derivative, not a future amendment."
}
```

### NL-FAMILY

Actual ascending/descending family-attribution rule, not all relatives indiscriminately.

```json
{
  "act_article_or_scope": "WetIB2001 4.10 whole operative body",
  "actual_read_on": "2026-11-16",
  "id": "NL-FAMILY",
  "official_url": "https://wetten.overheid.nl/BWBR0011353",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Scope and trigger. [Wet IB 2001 4.16(1)(h)](https://wetten.overheid.nl/BWBR0011353) treats cessation of domestic tax liability otherwise than death as a deemed disposal of a substantial interest. It is not restricted to Dutch-incorporated companies. The 4.18 exception for a non-Dutch-established company requires departure within 8 years after arrival AND no more than 10 total years of Dutch residence in the preceding 25 years. Check its full facts before charging foreign-company shares. Article 4.6 includes at least 5% held directly/indirectly, alone or with a partner, in shares, acquisition rights, profit certificates and specified voting interests; class rules and family attribution can extend scope under the adjacent provisions. Article 4.3 separately equates a person entitled only to benefits from shares (rights of enjoyment, genotsrechten) with a shareholder and treats that entitlement as a share; it does the corresponding thing for benefits from profit certificates. These are distinct from acquisition rights. [Statutory equivalence 4.3](https://wetten.overheid.nl/BWBR0011353). [Statute 4.6–4.7/4.16–4.18](https://wetten.overheid.nl/BWBR0011353); [2026 authority substantial-interest explanation](https://www.belastingdienst.nl/wps/wcm/connect/fisin/fisin2026/aanmerkelijk_belang).",
      "line": 119
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/nl-wetib-current-compact.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "d260c551bfea3f2cd726654ae98fc0cf3157b9ee6a6a86ddd2d226b45d261cac",
  "source_version_basis": "Current official body from2026-02-21, ordinaryHTTP200; whitespace-only compact derivative, not a future amendment."
}
```

### NL-EVENT

Fictitious disposal includes cessation of domestic liability otherwise than death and other separately specified events.

```json
{
  "act_article_or_scope": "WetIB2001 4.16 whole operative body",
  "actual_read_on": "2026-11-16",
  "id": "NL-EVENT",
  "official_url": "https://wetten.overheid.nl/BWBR0011353",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Scope and trigger. [Wet IB 2001 4.16(1)(h)](https://wetten.overheid.nl/BWBR0011353) treats cessation of domestic tax liability otherwise than death as a deemed disposal of a substantial interest. It is not restricted to Dutch-incorporated companies. The 4.18 exception for a non-Dutch-established company requires departure within 8 years after arrival AND no more than 10 total years of Dutch residence in the preceding 25 years. Check its full facts before charging foreign-company shares. Article 4.6 includes at least 5% held directly/indirectly, alone or with a partner, in shares, acquisition rights, profit certificates and specified voting interests; class rules and family attribution can extend scope under the adjacent provisions. Article 4.3 separately equates a person entitled only to benefits from shares (rights of enjoyment, genotsrechten) with a shareholder and treats that entitlement as a share; it does the corresponding thing for benefits from profit certificates. These are distinct from acquisition rights. [Statutory equivalence 4.3](https://wetten.overheid.nl/BWBR0011353). [Statute 4.6–4.7/4.16–4.18](https://wetten.overheid.nl/BWBR0011353); [2026 authority substantial-interest explanation](https://www.belastingdienst.nl/wps/wcm/connect/fisin/fisin2026/aanmerkelijk_belang).",
      "line": 119
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/nl-wetib-current-compact.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "d260c551bfea3f2cd726654ae98fc0cf3157b9ee6a6a86ddd2d226b45d261cac",
  "source_version_basis": "Current official body from2026-02-21, ordinaryHTTP200; whitespace-only compact derivative, not a future amendment."
}
```

### NL-FOREIGN-PASSANTS

Foreign-company exception: departure within8years and at most10Dutch-resident years within25; treaty residence cessation included.

```json
{
  "act_article_or_scope": "WetIB2001 4.18 whole operative body",
  "actual_read_on": "2026-11-16",
  "id": "NL-FOREIGN-PASSANTS",
  "official_url": "https://wetten.overheid.nl/BWBR0011353",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Scope and trigger. [Wet IB 2001 4.16(1)(h)](https://wetten.overheid.nl/BWBR0011353) treats cessation of domestic tax liability otherwise than death as a deemed disposal of a substantial interest. It is not restricted to Dutch-incorporated companies. The 4.18 exception for a non-Dutch-established company requires departure within 8 years after arrival AND no more than 10 total years of Dutch residence in the preceding 25 years. Check its full facts before charging foreign-company shares. Article 4.6 includes at least 5% held directly/indirectly, alone or with a partner, in shares, acquisition rights, profit certificates and specified voting interests; class rules and family attribution can extend scope under the adjacent provisions. Article 4.3 separately equates a person entitled only to benefits from shares (rights of enjoyment, genotsrechten) with a shareholder and treats that entitlement as a share; it does the corresponding thing for benefits from profit certificates. These are distinct from acquisition rights. [Statutory equivalence 4.3](https://wetten.overheid.nl/BWBR0011353). [Statute 4.6–4.7/4.16–4.18](https://wetten.overheid.nl/BWBR0011353); [2026 authority substantial-interest explanation](https://www.belastingdienst.nl/wps/wcm/connect/fisin/fisin2026/aanmerkelijk_belang).",
      "line": 119
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/nl-wetib-current-compact.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "d260c551bfea3f2cd726654ae98fc0cf3157b9ee6a6a86ddd2d226b45d261cac",
  "source_version_basis": "Current official body from2026-02-21, ordinaryHTTP200; whitespace-only compact derivative, not a future amendment."
}
```

### NL-ARRIVAL-BASIS

Arrival acquisition value and statutory exceptions/implementing rules, not an unconditional market-value step-up.

```json
{
  "act_article_or_scope": "WetIB2001 4.25 whole operative body",
  "actual_read_on": "2026-11-16",
  "id": "NL-ARRIVAL-BASIS",
  "official_url": "https://wetten.overheid.nl/BWBR0011353",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Return. The former source gap is resolved: UBIB 16(5) reduces the protective assessment for an individual becoming a domestic taxpayer, but only to the extent its tax is still deferred under 25(8). Wet IB 4.25/UBIB 16 separately regulate arrival acquisition value, including prior domestic/foreign tax and Dutch-company exceptions. This is not a blanket refund of every amount already collected or an unconditional market-value step-up. [UBIB 16](https://wetten.overheid.nl/BWBR0012066); [Wet IB 4.25](https://wetten.overheid.nl/BWBR0011353).",
      "line": 139
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/nl-wetib-current-compact.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "d260c551bfea3f2cd726654ae98fc0cf3157b9ee6a6a86ddd2d226b45d261cac",
  "source_version_basis": "Current official body from2026-02-21, ordinaryHTTP200; whitespace-only compact derivative, not a future amendment."
}
```

### NL-COLLECTION-1

General payment deferral is conditional and can end.

```json
{
  "act_article_or_scope": "Invorderingswet25(1) whole",
  "actual_read_on": "2026-11-16",
  "id": "NL-COLLECTION-1",
  "official_url": "https://wetten.overheid.nl/BWBR0004770",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Payment and security. The authority gives automatic deferral for EU/EEA moves; elsewhere request it using the assessment procedure, with security for a substantial interest (the Norway/Iceland/Liechtenstein exception belongs to the EEA treatment). A bank guarantee, mortgage or pledge can provide security. An onward move outside the protected area must be reported and may require a new request/security. Current Invorderingswet 25(8) regulates the deferral and its termination, including disposal, distributions and capital repayments, with specific continuation/credit limits; it is not an unconditional lifelong nonpayment promise. [Current collection statute](https://wetten.overheid.nl/BWBR0004770); [2026 authority preserved-income section 26.2.1](https://www.belastingdienst.nl/wps/wcm/connect/fisin/fisin2026/te_conserveren_inkomen).",
      "line": 133
    }
  ],
  "short_exact_native_quotes": [
    "1 De ontvanger kan onder door hem te stellen voorwaarden aan een belastingschuldige voor een bepaalde tijd bij beschikking uitstel van betaling verlenen. Gedurende het"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/nl-collection-act-compact.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "8ccdab821dcf1077280528a00744a31d9dc67818927e830c107f83f004dee44e",
  "source_version_basis": "Current2026-10-01 official body; future2027changes not applied."
}
```

### NL-COLLECTION-8

Substantial-interest deferral/security/delegation, disposal/distribution/capital repayment termination and precise continuation/credit limitations.

```json
{
  "act_article_or_scope": "Invorderingswet25(8) whole",
  "actual_read_on": "2026-11-16",
  "id": "NL-COLLECTION-8",
  "official_url": "https://wetten.overheid.nl/BWBR0004770",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Payment and security. The authority gives automatic deferral for EU/EEA moves; elsewhere request it using the assessment procedure, with security for a substantial interest (the Norway/Iceland/Liechtenstein exception belongs to the EEA treatment). A bank guarantee, mortgage or pledge can provide security. An onward move outside the protected area must be reported and may require a new request/security. Current Invorderingswet 25(8) regulates the deferral and its termination, including disposal, distributions and capital repayments, with specific continuation/credit limits; it is not an unconditional lifelong nonpayment promise. [Current collection statute](https://wetten.overheid.nl/BWBR0004770); [2026 authority preserved-income section 26.2.1](https://www.belastingdienst.nl/wps/wcm/connect/fisin/fisin2026/te_conserveren_inkomen).",
      "line": 133
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/nl-collection-act-compact.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "8ccdab821dcf1077280528a00744a31d9dc67818927e830c107f83f004dee44e",
  "source_version_basis": "Current2026-10-01 official body; future2027changes not applied."
}
```

### NL-INTEREST

No interest during specified deferrals, with termination/latepayment exception and delegated period; not a lifelong no-interest promise.

```json
{
  "act_article_or_scope": "Invorderingswet28 all1–5",
  "actual_read_on": "2026-11-16",
  "id": "NL-INTEREST",
  "official_url": "https://wetten.overheid.nl/BWBR0004770",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Interest requires care. Invorderingswet 28(3) excludes collection interest during specified qualifying deferral; 28(4) makes an exception when the assessment is collected after termination or late payment. The authority’s general emigration page says no interest during deferral, whereas its 2026 substantial-interest section expressly identifies an exception. Use the statutory 28(3)/(4) distinction; this Guide neither guarantees an interest-free lifetime nor calculates the delegated interest period. [Actual 28](https://wetten.overheid.nl/BWBR0004770); [current substantial-interest guidance](https://www.belastingdienst.nl/wps/wcm/connect/fisin/fisin2026/te_conserveren_inkomen).",
      "line": 135
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/nl-collection-act-compact.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "8ccdab821dcf1077280528a00744a31d9dc67818927e830c107f83f004dee44e",
  "source_version_basis": "Current2026-10-01 official body."
}
```

### NL-OLD-CUTOFF

Earlier law continues for events before15September2015at15:15; current substantial-interest ordinary10year remission cannot be assumed.

```json
{
  "act_article_or_scope": "Invorderingswet70ea all1–2",
  "actual_read_on": "2026-11-16",
  "id": "NL-OLD-CUTOFF",
  "official_url": "https://wetten.overheid.nl/BWBR0004770",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Duration and acceleration. The authority distinguishes its normal 10-year protective assessment from the unlimited substantial-interest assessment. For departure from 15 September 2015 at 15:15, no ordinary remission after 10 years applies; pre-cutoff substantial-interest cases can request remission subject to continued ownership/company conditions. Report sale, distributions and cessation; only the amount required by the applicable collection provisions becomes payable. [Authority dated transition](https://www.belastingdienst.nl/wps/wcm/connect/nl/buitenland/content/conserverende-aanslag-bij-emigratie); [25(8)](https://wetten.overheid.nl/BWBR0004770).",
      "line": 137
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/nl-collection-act-compact.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "8ccdab821dcf1077280528a00744a31d9dc67818927e830c107f83f004dee44e",
  "source_version_basis": "Current2026-10-01 official body."
}
```

### NL-RETURN-1

Arrival basis starts from the prescribed acquisition value for a returning/previously nonresident-taxable shareholder.

```json
{
  "act_article_or_scope": "UBIB16(1) whole",
  "actual_read_on": "2026-11-16",
  "id": "NL-RETURN-1",
  "official_url": "https://wetten.overheid.nl/BWBR0012066",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Return. The former source gap is resolved: UBIB 16(5) reduces the protective assessment for an individual becoming a domestic taxpayer, but only to the extent its tax is still deferred under 25(8). Wet IB 4.25/UBIB 16 separately regulate arrival acquisition value, including prior domestic/foreign tax and Dutch-company exceptions. This is not a blanket refund of every amount already collected or an unconditional market-value step-up. [UBIB 16](https://wetten.overheid.nl/BWBR0012066); [Wet IB 4.25](https://wetten.overheid.nl/BWBR0011353).",
      "line": 139
    }
  ],
  "short_exact_native_quotes": [
    "1 Indien een belastingplichtige met een aanmerkelijk belang in Nederland gaat wonen en de belastingplichtige eerder in Nederland heeft gewoond of voordien ten aanzien van"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/nl-ubib-current-compact.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "d02bbdd8bf102c97fffa34e6521278a6c0512e30d2e248d1fbf8e315785d566a",
  "source_version_basis": "Current official2026-01-01 body; no full16(10)read claimed."
}
```

### NL-RETURN-2

Qualifying reasonable foreign income tax paid on value increase can affect arrival basis.

```json
{
  "act_article_or_scope": "UBIB16(2) whole",
  "actual_read_on": "2026-11-16",
  "id": "NL-RETURN-2",
  "official_url": "https://wetten.overheid.nl/BWBR0012066",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Return. The former source gap is resolved: UBIB 16(5) reduces the protective assessment for an individual becoming a domestic taxpayer, but only to the extent its tax is still deferred under 25(8). Wet IB 4.25/UBIB 16 separately regulate arrival acquisition value, including prior domestic/foreign tax and Dutch-company exceptions. This is not a blanket refund of every amount already collected or an unconditional market-value step-up. [UBIB 16](https://wetten.overheid.nl/BWBR0012066); [Wet IB 4.25](https://wetten.overheid.nl/BWBR0011353).",
      "line": 139
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/nl-ubib-current-compact.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "d02bbdd8bf102c97fffa34e6521278a6c0512e30d2e248d1fbf8e315785d566a",
  "source_version_basis": "Current official2026-01-01 body; no full16(10)read claimed."
}
```

### NL-RETURN-3

Specified non-Dutch-taxable-period increase can affect arrival basis, with no double count.

```json
{
  "act_article_or_scope": "UBIB16(3) whole",
  "actual_read_on": "2026-11-16",
  "id": "NL-RETURN-3",
  "official_url": "https://wetten.overheid.nl/BWBR0012066",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Return. The former source gap is resolved: UBIB 16(5) reduces the protective assessment for an individual becoming a domestic taxpayer, but only to the extent its tax is still deferred under 25(8). Wet IB 4.25/UBIB 16 separately regulate arrival acquisition value, including prior domestic/foreign tax and Dutch-company exceptions. This is not a blanket refund of every amount already collected or an unconditional market-value step-up. [UBIB 16](https://wetten.overheid.nl/BWBR0012066); [Wet IB 4.25](https://wetten.overheid.nl/BWBR0011353).",
      "line": 139
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/nl-ubib-current-compact.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "d02bbdd8bf102c97fffa34e6521278a6c0512e30d2e248d1fbf8e315785d566a",
  "source_version_basis": "Current official2026-01-01 body; no full16(10)read claimed."
}
```

### NL-RETURN-4

Specified non-Dutch-taxable-period decline reduces arrival basis.

```json
{
  "act_article_or_scope": "UBIB16(4) whole",
  "actual_read_on": "2026-11-16",
  "id": "NL-RETURN-4",
  "official_url": "https://wetten.overheid.nl/BWBR0012066",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Return. The former source gap is resolved: UBIB 16(5) reduces the protective assessment for an individual becoming a domestic taxpayer, but only to the extent its tax is still deferred under 25(8). Wet IB 4.25/UBIB 16 separately regulate arrival acquisition value, including prior domestic/foreign tax and Dutch-company exceptions. This is not a blanket refund of every amount already collected or an unconditional market-value step-up. [UBIB 16](https://wetten.overheid.nl/BWBR0012066); [Wet IB 4.25](https://wetten.overheid.nl/BWBR0011353).",
      "line": 139
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/nl-ubib-current-compact.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "d02bbdd8bf102c97fffa34e6521278a6c0512e30d2e248d1fbf8e315785d566a",
  "source_version_basis": "Current official2026-01-01 body; no full16(10)read claimed."
}
```

### NL-RETURN-5

Return reduces only the part of the earlier assessment still deferred under25(8).

```json
{
  "act_article_or_scope": "UBIB16(5) whole",
  "actual_read_on": "2026-11-16",
  "id": "NL-RETURN-5",
  "official_url": "https://wetten.overheid.nl/BWBR0012066",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Return. The former source gap is resolved: UBIB 16(5) reduces the protective assessment for an individual becoming a domestic taxpayer, but only to the extent its tax is still deferred under 25(8). Wet IB 4.25/UBIB 16 separately regulate arrival acquisition value, including prior domestic/foreign tax and Dutch-company exceptions. This is not a blanket refund of every amount already collected or an unconditional market-value step-up. [UBIB 16](https://wetten.overheid.nl/BWBR0012066); [Wet IB 4.25](https://wetten.overheid.nl/BWBR0011353).",
      "line": 139
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/nl-ubib-current-compact.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "d02bbdd8bf102c97fffa34e6521278a6c0512e30d2e248d1fbf8e315785d566a",
  "source_version_basis": "Current official2026-01-01 body; no full16(10)read claimed."
}
```

### NL-RETURN-6

Allocated costs can increase basis as prescribed.

```json
{
  "act_article_or_scope": "UBIB16(6) whole",
  "actual_read_on": "2026-11-16",
  "id": "NL-RETURN-6",
  "official_url": "https://wetten.overheid.nl/BWBR0012066",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Return. The former source gap is resolved: UBIB 16(5) reduces the protective assessment for an individual becoming a domestic taxpayer, but only to the extent its tax is still deferred under 25(8). Wet IB 4.25/UBIB 16 separately regulate arrival acquisition value, including prior domestic/foreign tax and Dutch-company exceptions. This is not a blanket refund of every amount already collected or an unconditional market-value step-up. [UBIB 16](https://wetten.overheid.nl/BWBR0012066); [Wet IB 4.25](https://wetten.overheid.nl/BWBR0011353).",
      "line": 139
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/nl-ubib-current-compact.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "d02bbdd8bf102c97fffa34e6521278a6c0512e30d2e248d1fbf8e315785d566a",
  "source_version_basis": "Current official2026-01-01 body; no full16(10)read claimed."
}
```

### NL-RETURN-7

Prescribed continuation of deferred-tax and foreign-company basis limits apply.

```json
{
  "act_article_or_scope": "UBIB16(7) whole",
  "actual_read_on": "2026-11-16",
  "id": "NL-RETURN-7",
  "official_url": "https://wetten.overheid.nl/BWBR0012066",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Return. The former source gap is resolved: UBIB 16(5) reduces the protective assessment for an individual becoming a domestic taxpayer, but only to the extent its tax is still deferred under 25(8). Wet IB 4.25/UBIB 16 separately regulate arrival acquisition value, including prior domestic/foreign tax and Dutch-company exceptions. This is not a blanket refund of every amount already collected or an unconditional market-value step-up. [UBIB 16](https://wetten.overheid.nl/BWBR0012066); [Wet IB 4.25](https://wetten.overheid.nl/BWBR0011353).",
      "line": 139
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/nl-ubib-current-compact.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "d02bbdd8bf102c97fffa34e6521278a6c0512e30d2e248d1fbf8e315785d566a",
  "source_version_basis": "Current official2026-01-01 body; no full16(10)read claimed."
}
```

### NL-RETURN-8

Prescribed basis treatment for later taxed value changes applies.

```json
{
  "act_article_or_scope": "UBIB16(8) whole",
  "actual_read_on": "2026-11-16",
  "id": "NL-RETURN-8",
  "official_url": "https://wetten.overheid.nl/BWBR0012066",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Return. The former source gap is resolved: UBIB 16(5) reduces the protective assessment for an individual becoming a domestic taxpayer, but only to the extent its tax is still deferred under 25(8). Wet IB 4.25/UBIB 16 separately regulate arrival acquisition value, including prior domestic/foreign tax and Dutch-company exceptions. This is not a blanket refund of every amount already collected or an unconditional market-value step-up. [UBIB 16](https://wetten.overheid.nl/BWBR0012066); [Wet IB 4.25](https://wetten.overheid.nl/BWBR0011353).",
      "line": 139
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/nl-ubib-current-compact.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "d02bbdd8bf102c97fffa34e6521278a6c0512e30d2e248d1fbf8e315785d566a",
  "source_version_basis": "Current official2026-01-01 body; no full16(10)read claimed."
}
```

### NL-RETURN-9

The prescribed taxpayer/fiscal-partner deeming rules apply.

```json
{
  "act_article_or_scope": "UBIB16(9) whole",
  "actual_read_on": "2026-11-16",
  "id": "NL-RETURN-9",
  "official_url": "https://wetten.overheid.nl/BWBR0012066",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Return. The former source gap is resolved: UBIB 16(5) reduces the protective assessment for an individual becoming a domestic taxpayer, but only to the extent its tax is still deferred under 25(8). Wet IB 4.25/UBIB 16 separately regulate arrival acquisition value, including prior domestic/foreign tax and Dutch-company exceptions. This is not a blanket refund of every amount already collected or an unconditional market-value step-up. [UBIB 16](https://wetten.overheid.nl/BWBR0012066); [Wet IB 4.25](https://wetten.overheid.nl/BWBR0011353).",
      "line": 139
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/nl-ubib-current-compact.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "d02bbdd8bf102c97fffa34e6521278a6c0512e30d2e248d1fbf8e315785d566a",
  "source_version_basis": "Current official2026-01-01 body; no full16(10)read claimed."
}
```

### NL-AUTHORITY-DURATION

Deemeddisposal createsbox2protectiveassessment, pre15September2015at15:15versuslaterdeferral/dischargeconditions differ; disposal/dividend/companycessation reporting/payment triggers apply.

```json
{
  "act_article_or_scope": "Substantialinterest emigration section, all3paragraphs",
  "actual_read_on": "2026-11-16",
  "id": "NL-AUTHORITY-DURATION",
  "official_url": "https://www.belastingdienst.nl/wps/wcm/connect/nl/buitenland/content/conserverende-aanslag-bij-emigratie",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "sections": [
    {
      "actual_text": "Duration and acceleration. The authority distinguishes its normal 10-year protective assessment from the unlimited substantial-interest assessment. For departure from 15 September 2015 at 15:15, no ordinary remission after 10 years applies; pre-cutoff substantial-interest cases can request remission subject to continued ownership/company conditions. Report sale, distributions and cessation; only the amount required by the applicable collection provisions becomes payable. [Authority dated transition](https://www.belastingdienst.nl/wps/wcm/connect/nl/buitenland/content/conserverende-aanslag-bij-emigratie); [25(8)](https://wetten.overheid.nl/BWBR0004770).",
      "line": 137
    }
  ],
  "short_exact_native_quotes": [
    "Hebt u een aanmerkelijk belang? Als u emigreert, behandelen wij uw aandelen alsof u ze hebt verkocht. Dit heet fictieve vervreemding van uw aanmerkelijk belang."
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/nl-exit-native.txt",
  "source_provenance": "Same writer own actual16November residence-source reading reused for this candidate-specific scope, not another reader approval; precise source version remains binding.",
  "source_sha256": "06560de15fd3c69f2e9ba5e79695288aef69f2e75a22f93210ce2f06f563f04d",
  "source_version_basis": "Actual current nativeauthoritypage read; ownwholeoperative body and neighbours, not personal-taxassessment conclusion."
}
```

### NL-AUTHORITY-SECURITY

AutomaticEU/EEAdeferral versus application/conditions, subsequent nonEUmove and security rules require actual incomecomponent/country facts.

```json
{
  "act_article_or_scope": "Paymentdeferral/application/latermove/security full assigned operative sections",
  "actual_read_on": "2026-11-16",
  "id": "NL-AUTHORITY-SECURITY",
  "official_url": "https://www.belastingdienst.nl/wps/wcm/connect/nl/buitenland/content/conserverende-aanslag-bij-emigratie",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "sections": [
    {
      "actual_text": "Payment and security. The authority gives automatic deferral for EU/EEA moves; elsewhere request it using the assessment procedure, with security for a substantial interest (the Norway/Iceland/Liechtenstein exception belongs to the EEA treatment). A bank guarantee, mortgage or pledge can provide security. An onward move outside the protected area must be reported and may require a new request/security. Current Invorderingswet 25(8) regulates the deferral and its termination, including disposal, distributions and capital repayments, with specific continuation/credit limits; it is not an unconditional lifelong nonpayment promise. [Current collection statute](https://wetten.overheid.nl/BWBR0004770); [2026 authority preserved-income section 26.2.1](https://www.belastingdienst.nl/wps/wcm/connect/fisin/fisin2026/te_conserveren_inkomen).",
      "line": 133
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/nl-exit-native.txt",
  "source_provenance": "Same writer own actual16November residence-source reading reused for this candidate-specific scope, not another reader approval; precise source version remains binding.",
  "source_sha256": "06560de15fd3c69f2e9ba5e79695288aef69f2e75a22f93210ce2f06f563f04d",
  "source_version_basis": "Actual currentauthoritypage personally read; scope includes sharesecurityexception forNO/IS/LI, not universal security."
}
```

### NO-STATUTE-1

Residence/treaty exit, foreign recipient transfer and estate distribution timing.

```json
{
  "act_article_or_scope": "TaxAct10-70(1) whole",
  "actual_read_on": "2026-11-16",
  "id": "NO-STATUTE-1",
  "official_url": "https://lovdata.no/lov/1999-03-26-14/%C2%A710-70",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "What triggers it. Moving out of Norway and becoming resident in another country under a tax treaty, being registered as emigrated for tax purposes, or becoming tax resident in Svalbard, after having been tax resident in Norway under both the Taxation Act and any relevant treaty. Gifts and gift sales to persons resident abroad, and inheritance passing to heirs abroad (inheritance from a Norwegian estate from 1 January 2025), are also caught ([Skatteetaten, exit tax](https://www.skatteetaten.no/en/person/to-from-norway/from/tax-when-you-move-abroad/exit-tax/)). Registration of a residential address in Norway is not relevant.",
      "line": 143
    }
  ],
  "short_exact_native_quotes": [
    "(1) Gevinst på eiendel som nevnt i annet ledd, og som personlig skattyter eier på det tidspunkt skatteplikten til riket opphører etter § 2-1 tredje"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/no-law1070.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "e0e9c83aff84546ae29561f93eabbeed62996e5891ee7fed837f95bd34d8075e",
  "source_version_basis": "Current actual official body retrieved/read2026-11-16; relevant operative unit and neighbours personally read."
}
```

### NO-STATUTE-2

Actual assets covered; no blanket all-property tax.

```json
{
  "act_article_or_scope": "TaxAct10-70(2) whole",
  "actual_read_on": "2026-11-16",
  "id": "NO-STATUTE-2",
  "official_url": "https://lovdata.no/lov/1999-03-26-14/%C2%A710-70",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "What is taxed. Latent gains on shares in Norwegian or foreign companies, units in securities funds, share savings accounts, investment fund accounts, employment options, interests in companies assessed as partnerships, financial instruments with such underlying assets, and assets in foreign pension savings schemes when considered a regular investment account (the page names IRAs and 401(k)s). Exit tax is calculated only on values accumulated while the person was tax resident in Norway. On a move there is a basic deduction, shown below; only the total gain or loss above it is subject to exit tax. On a move within the EEA or to Svalbard, gains and losses are netted before the deduction. On a move outside the EEA, only gains are added up; losses are not included. For gifts and other transfers, the NOK 100,000 net-gain threshold is an annual aggregate cliff, not a per-gift deduction: above it the whole net gain is caught. Coordinate transfers and an actual move in the same year under 10-70(4); do not double-use the move deduction. EEA loss relief also has later recapture/return conditions. [10-70(2)–(4)](https://lovdata.no/lov/1999-03-26-14/%C2%A710-70).",
      "line": 147
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/no-law1070.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "e0e9c83aff84546ae29561f93eabbeed62996e5891ee7fed837f95bd34d8075e",
  "source_version_basis": "Current actual official body retrieved/read2026-11-16; relevant operative unit and neighbours personally read."
}
```

### NO-STATUTE-3

EEA loss deduction and later nonEEA recapture conditions.

```json
{
  "act_article_or_scope": "TaxAct10-70(3) whole",
  "actual_read_on": "2026-11-16",
  "id": "NO-STATUTE-3",
  "official_url": "https://lovdata.no/lov/1999-03-26-14/%C2%A710-70",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "What is taxed. Latent gains on shares in Norwegian or foreign companies, units in securities funds, share savings accounts, investment fund accounts, employment options, interests in companies assessed as partnerships, financial instruments with such underlying assets, and assets in foreign pension savings schemes when considered a regular investment account (the page names IRAs and 401(k)s). Exit tax is calculated only on values accumulated while the person was tax resident in Norway. On a move there is a basic deduction, shown below; only the total gain or loss above it is subject to exit tax. On a move within the EEA or to Svalbard, gains and losses are netted before the deduction. On a move outside the EEA, only gains are added up; losses are not included. For gifts and other transfers, the NOK 100,000 net-gain threshold is an annual aggregate cliff, not a per-gift deduction: above it the whole net gain is caught. Coordinate transfers and an actual move in the same year under 10-70(4); do not double-use the move deduction. EEA loss relief also has later recapture/return conditions. [10-70(2)–(4)](https://lovdata.no/lov/1999-03-26-14/%C2%A710-70).",
      "line": 147
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/no-law1070.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "e0e9c83aff84546ae29561f93eabbeed62996e5891ee7fed837f95bd34d8075e",
  "source_version_basis": "Current actual official body retrieved/read2026-11-16; relevant operative unit and neighbours personally read."
}
```

### NO-STATUTE-4

Move3m deduction versus annual100ktransfer cliff, with same-year coordination.

```json
{
  "act_article_or_scope": "TaxAct10-70(4) whole",
  "actual_read_on": "2026-11-16",
  "id": "NO-STATUTE-4",
  "official_url": "https://lovdata.no/lov/1999-03-26-14/%C2%A710-70",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "What is taxed. Latent gains on shares in Norwegian or foreign companies, units in securities funds, share savings accounts, investment fund accounts, employment options, interests in companies assessed as partnerships, financial instruments with such underlying assets, and assets in foreign pension savings schemes when considered a regular investment account (the page names IRAs and 401(k)s). Exit tax is calculated only on values accumulated while the person was tax resident in Norway. On a move there is a basic deduction, shown below; only the total gain or loss above it is subject to exit tax. On a move within the EEA or to Svalbard, gains and losses are netted before the deduction. On a move outside the EEA, only gains are added up; losses are not included. For gifts and other transfers, the NOK 100,000 net-gain threshold is an annual aggregate cliff, not a per-gift deduction: above it the whole net gain is caught. Coordinate transfers and an actual move in the same year under 10-70(4); do not double-use the move deduction. EEA loss relief also has later recapture/return conditions. [10-70(2)–(4)](https://lovdata.no/lov/1999-03-26-14/%C2%A710-70).",
      "line": 147
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/no-law1070.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "e0e9c83aff84546ae29561f93eabbeed62996e5891ee7fed837f95bd34d8075e",
  "source_version_basis": "Current actual official body retrieved/read2026-11-16; relevant operative unit and neighbours personally read."
}
```

### NO-STATUTE-5

Market value/reconstruction and share-savings gain mechanics.

```json
{
  "act_article_or_scope": "TaxAct10-70(5) whole",
  "actual_read_on": "2026-11-16",
  "id": "NO-STATUTE-5",
  "official_url": "https://lovdata.no/lov/1999-03-26-14/%C2%A710-70",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "What is taxed. Latent gains on shares in Norwegian or foreign companies, units in securities funds, share savings accounts, investment fund accounts, employment options, interests in companies assessed as partnerships, financial instruments with such underlying assets, and assets in foreign pension savings schemes when considered a regular investment account (the page names IRAs and 401(k)s). Exit tax is calculated only on values accumulated while the person was tax resident in Norway. On a move there is a basic deduction, shown below; only the total gain or loss above it is subject to exit tax. On a move within the EEA or to Svalbard, gains and losses are netted before the deduction. On a move outside the EEA, only gains are added up; losses are not included. For gifts and other transfers, the NOK 100,000 net-gain threshold is an annual aggregate cliff, not a per-gift deduction: above it the whole net gain is caught. Coordinate transfers and an actual move in the same year under 10-70(4); do not double-use the move deduction. EEA loss relief also has later recapture/return conditions. [10-70(2)–(4)](https://lovdata.no/lov/1999-03-26-14/%C2%A710-70).",
      "line": 147
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/no-law1070.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "e0e9c83aff84546ae29561f93eabbeed62996e5891ee7fed837f95bd34d8075e",
  "source_version_basis": "Current actual official body retrieved/read2026-11-16; relevant operative unit and neighbours personally read."
}
```

### NO-STATUTE-6

Norwegian-residence accrued gain basis with prior-residence value adjustments.

```json
{
  "act_article_or_scope": "TaxAct10-70(6) whole",
  "actual_read_on": "2026-11-16",
  "id": "NO-STATUTE-6",
  "official_url": "https://lovdata.no/lov/1999-03-26-14/%C2%A710-70",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "What is taxed. Latent gains on shares in Norwegian or foreign companies, units in securities funds, share savings accounts, investment fund accounts, employment options, interests in companies assessed as partnerships, financial instruments with such underlying assets, and assets in foreign pension savings schemes when considered a regular investment account (the page names IRAs and 401(k)s). Exit tax is calculated only on values accumulated while the person was tax resident in Norway. On a move there is a basic deduction, shown below; only the total gain or loss above it is subject to exit tax. On a move within the EEA or to Svalbard, gains and losses are netted before the deduction. On a move outside the EEA, only gains are added up; losses are not included. For gifts and other transfers, the NOK 100,000 net-gain threshold is an annual aggregate cliff, not a per-gift deduction: above it the whole net gain is caught. Coordinate transfers and an actual move in the same year under 10-70(4); do not double-use the move deduction. EEA loss relief also has later recapture/return conditions. [10-70(2)–(4)](https://lovdata.no/lov/1999-03-26-14/%C2%A710-70).",
      "line": 147
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/no-law1070.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "e0e9c83aff84546ae29561f93eabbeed62996e5891ee7fed837f95bd34d8075e",
  "source_version_basis": "Current actual official body retrieved/read2026-11-16; relevant operative unit and neighbours personally read."
}
```

### NO-STATUTE-7

12years from recognition-year end; security/realEEAcollectionrisk;12annual portions versus interest-bearing whole postponement.

```json
{
  "act_article_or_scope": "TaxAct10-70(7) whole",
  "actual_read_on": "2026-11-16",
  "id": "NO-STATUTE-7",
  "official_url": "https://lovdata.no/lov/1999-03-26-14/%C2%A710-70",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Payment. The current statute offers immediate payment, 12 equal annual instalments, or postponement of the whole claim with interest. The 12-year endpoint is counted from the END of the tax year in which the deemed gain is recognised, not simply the anniversary of the move. Recognition is the day before the residence/treaty change under section 14-25. Security is normally required, but an EEA move requires a real collection risk before security can be demanded; it is not automatic for every EEA move. [Tax Act 10-70/14-25](https://lovdata.no/lov/1999-03-26-14/%C2%A710-70); [security guideline](https://www.skatteetaten.no/en/rettskilder/type/retningslinjer/retningslinje-for-utsettelse-av-innbetaling-av-fastsatt-utflyttingsskatt-etter-skatteloven--10-70/).",
      "line": 163
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/no-law1070.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "e0e9c83aff84546ae29561f93eabbeed62996e5891ee7fed837f95bd34d8075e",
  "source_version_basis": "Current actual official body retrieved/read2026-11-16; relevant operative unit and neighbours personally read."
}
```

### NO-STATUTE-8

Acceleration, death/heir assumption, savings withdrawals and0.7distribution repayment/100%ceiling delegation.

```json
{
  "act_article_or_scope": "TaxAct10-70(8) whole",
  "actual_read_on": "2026-11-16",
  "id": "NO-STATUTE-8",
  "official_url": "https://lovdata.no/lov/1999-03-26-14/%C2%A710-70",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Distribution, death and return. The 70% distribution repayment rule has statutory/regulatory credits for qualifying paid tax and the ceiling preventing combined tax/repayment from exceeding the distribution; share-savings withdrawals have a separate proportional mechanism. Death can end postponement, but a personal heir may assume the tax duties under the required continuity conditions; a Norwegian-resident heir can claim relief with full continuity. Return within the statutory period can discharge the retained-assets claim and associated interest. After that period, the original basis is adjusted for the value change actually taxed; this is not an unconditional new market-value basis on return. [10-70](https://lovdata.no/lov/1999-03-26-14/%C2%A710-70); [FSFIN 10-70-1–6](https://lovdata.no/forskrift/1999-11-19-1158/%C2%A710-70-1).",
      "line": 165
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/no-law1070.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "e0e9c83aff84546ae29561f93eabbeed62996e5891ee7fed837f95bd34d8075e",
  "source_version_basis": "Current actual official body retrieved/read2026-11-16; relevant operative unit and neighbours personally read."
}
```

### NO-STATUTE-9

Retained-assets return relief and interest within12years; later originalbasis adjusted by taxed value, not market-value reset.

```json
{
  "act_article_or_scope": "TaxAct10-70(9) whole",
  "actual_read_on": "2026-11-16",
  "id": "NO-STATUTE-9",
  "official_url": "https://lovdata.no/lov/1999-03-26-14/%C2%A710-70",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Distribution, death and return. The 70% distribution repayment rule has statutory/regulatory credits for qualifying paid tax and the ceiling preventing combined tax/repayment from exceeding the distribution; share-savings withdrawals have a separate proportional mechanism. Death can end postponement, but a personal heir may assume the tax duties under the required continuity conditions; a Norwegian-resident heir can claim relief with full continuity. Return within the statutory period can discharge the retained-assets claim and associated interest. After that period, the original basis is adjusted for the value change actually taxed; this is not an unconditional new market-value basis on return. [10-70](https://lovdata.no/lov/1999-03-26-14/%C2%A710-70); [FSFIN 10-70-1–6](https://lovdata.no/forskrift/1999-11-19-1158/%C2%A710-70-1).",
      "line": 165
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/no-law1070.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "e0e9c83aff84546ae29561f93eabbeed62996e5891ee7fed837f95bd34d8075e",
  "source_version_basis": "Current actual official body retrieved/read2026-11-16; relevant operative unit and neighbours personally read."
}
```

### NO-STATUTE-10

Inheritance continuity cross-reference applies to specified recipients.

```json
{
  "act_article_or_scope": "TaxAct10-70(10) whole",
  "actual_read_on": "2026-11-16",
  "id": "NO-STATUTE-10",
  "official_url": "https://lovdata.no/lov/1999-03-26-14/%C2%A710-70",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Distribution, death and return. The 70% distribution repayment rule has statutory/regulatory credits for qualifying paid tax and the ceiling preventing combined tax/repayment from exceeding the distribution; share-savings withdrawals have a separate proportional mechanism. Death can end postponement, but a personal heir may assume the tax duties under the required continuity conditions; a Norwegian-resident heir can claim relief with full continuity. Return within the statutory period can discharge the retained-assets claim and associated interest. After that period, the original basis is adjusted for the value change actually taxed; this is not an unconditional new market-value basis on return. [10-70](https://lovdata.no/lov/1999-03-26-14/%C2%A710-70); [FSFIN 10-70-1–6](https://lovdata.no/forskrift/1999-11-19-1158/%C2%A710-70-1).",
      "line": 165
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/no-law1070.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "e0e9c83aff84546ae29561f93eabbeed62996e5891ee7fed837f95bd34d8075e",
  "source_version_basis": "Current actual official body retrieved/read2026-11-16; relevant operative unit and neighbours personally read."
}
```

### NO-STATUTE-11

Prompt unsolicited information and default effect, subject to implementing cure procedure.

```json
{
  "act_article_or_scope": "TaxAct10-70(11) whole",
  "actual_read_on": "2026-11-16",
  "id": "NO-STATUTE-11",
  "official_url": "https://lovdata.no/lov/1999-03-26-14/%C2%A710-70",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Reporting. Report for the day before residence changes: a change on 1 January 2025 belongs to the 2024 return. While postponement runs, answer the annual questionnaire by 30 April and notify qualifying disposal, transfer or move changes within 2 months. The regulation gives notice and at least 3 weeks to cure material reporting noncompliance before that ground ends postponement. The authority describes an assessment period up to 15 years where exit-tax information is missing; do not treat it as permission to omit reporting. [Current authority reporting/history](https://www.skatteetaten.no/en/person/to-from-norway/from/tax-when-you-move-abroad/exit-tax/); [14-25](https://lovdata.no/lov/1999-03-26-14/%C2%A714-25); [FSFIN](https://lovdata.no/forskrift/1999-11-19-1158/%C2%A710-70-1). For the corridor see `norway-to-switzerland-wealth-tax-exit`.",
      "line": 167
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/no-law1070.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "e0e9c83aff84546ae29561f93eabbeed62996e5891ee7fed837f95bd34d8075e",
  "source_version_basis": "Current actual official body retrieved/read2026-11-16; relevant operative unit and neighbours personally read."
}
```

### NO-REG-1

Return information,30Aprilcontinuation,3weekminimumcure,additional security,2monthnotice and interest mechanics.

```json
{
  "act_article_or_scope": "FSFIN10-70-1 whole operative unit",
  "actual_read_on": "2026-11-16",
  "id": "NO-REG-1",
  "official_url": "https://lovdata.no/forskrift/1999-11-19-1158/%C2%A710-70-1",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Reporting. Report for the day before residence changes: a change on 1 January 2025 belongs to the 2024 return. While postponement runs, answer the annual questionnaire by 30 April and notify qualifying disposal, transfer or move changes within 2 months. The regulation gives notice and at least 3 weeks to cure material reporting noncompliance before that ground ends postponement. The authority describes an assessment period up to 15 years where exit-tax information is missing; do not treat it as permission to omit reporting. [Current authority reporting/history](https://www.skatteetaten.no/en/person/to-from-norway/from/tax-when-you-move-abroad/exit-tax/); [14-25](https://lovdata.no/lov/1999-03-26-14/%C2%A714-25); [FSFIN](https://lovdata.no/forskrift/1999-11-19-1158/%C2%A710-70-1). For the corridor see `norway-to-switzerland-wealth-tax-exit`.",
      "line": 167
    }
  ],
  "short_exact_native_quotes": [
    "§ 10-70-1.Utsettelse med betaling av fastsatt skatt (1) Utsettelse med innbetaling av fastsatt skatt etter skatteloven § 10-70 er betinget av at det leveres opplysninger"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/no-reg10701.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "66a02b26bafd9de9cfec230b693ae31602ee5efbc08bbb23778c10240c420504",
  "source_version_basis": "Current actual official body retrieved/read2026-11-16; relevant operative unit and neighbours personally read."
}
```

### NO-REG-2

Loss-relief recapture on nonEEA move/transfer or qualifying return;2monthnotification.

```json
{
  "act_article_or_scope": "FSFIN10-70-2 whole operative unit",
  "actual_read_on": "2026-11-16",
  "id": "NO-REG-2",
  "official_url": "https://lovdata.no/forskrift/1999-11-19-1158/%C2%A710-70-1",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Reporting. Report for the day before residence changes: a change on 1 January 2025 belongs to the 2024 return. While postponement runs, answer the annual questionnaire by 30 April and notify qualifying disposal, transfer or move changes within 2 months. The regulation gives notice and at least 3 weeks to cure material reporting noncompliance before that ground ends postponement. The authority describes an assessment period up to 15 years where exit-tax information is missing; do not treat it as permission to omit reporting. [Current authority reporting/history](https://www.skatteetaten.no/en/person/to-from-norway/from/tax-when-you-move-abroad/exit-tax/); [14-25](https://lovdata.no/lov/1999-03-26-14/%C2%A714-25); [FSFIN](https://lovdata.no/forskrift/1999-11-19-1158/%C2%A710-70-1). For the corridor see `norway-to-switzerland-wealth-tax-exit`.",
      "line": 167
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/no-reg10701.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "66a02b26bafd9de9cfec230b693ae31602ee5efbc08bbb23778c10240c420504",
  "source_version_basis": "Current actual official body retrieved/read2026-11-16; relevant operative unit and neighbours personally read."
}
```

### NO-REG-3

Proportional share-savings withdrawal acceleration and2monthnotice.

```json
{
  "act_article_or_scope": "FSFIN10-70-3 whole operative unit",
  "actual_read_on": "2026-11-16",
  "id": "NO-REG-3",
  "official_url": "https://lovdata.no/forskrift/1999-11-19-1158/%C2%A710-70-1",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Distribution, death and return. The 70% distribution repayment rule has statutory/regulatory credits for qualifying paid tax and the ceiling preventing combined tax/repayment from exceeding the distribution; share-savings withdrawals have a separate proportional mechanism. Death can end postponement, but a personal heir may assume the tax duties under the required continuity conditions; a Norwegian-resident heir can claim relief with full continuity. Return within the statutory period can discharge the retained-assets claim and associated interest. After that period, the original basis is adjusted for the value change actually taxed; this is not an unconditional new market-value basis on return. [10-70](https://lovdata.no/lov/1999-03-26-14/%C2%A710-70); [FSFIN 10-70-1–6](https://lovdata.no/forskrift/1999-11-19-1158/%C2%A710-70-1).",
      "line": 165
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/no-reg10701.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "66a02b26bafd9de9cfec230b693ae31602ee5efbc08bbb23778c10240c420504",
  "source_version_basis": "Current actual official body retrieved/read2026-11-16; relevant operative unit and neighbours personally read."
}
```

### NO-REG-4

Distribution repayment can reduce for documented paid tax only after exhausting credits; combined100%ceiling.

```json
{
  "act_article_or_scope": "FSFIN10-70-4 whole operative unit",
  "actual_read_on": "2026-11-16",
  "id": "NO-REG-4",
  "official_url": "https://lovdata.no/forskrift/1999-11-19-1158/%C2%A710-70-1",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Distribution, death and return. The 70% distribution repayment rule has statutory/regulatory credits for qualifying paid tax and the ceiling preventing combined tax/repayment from exceeding the distribution; share-savings withdrawals have a separate proportional mechanism. Death can end postponement, but a personal heir may assume the tax duties under the required continuity conditions; a Norwegian-resident heir can claim relief with full continuity. Return within the statutory period can discharge the retained-assets claim and associated interest. After that period, the original basis is adjusted for the value change actually taxed; this is not an unconditional new market-value basis on return. [10-70](https://lovdata.no/lov/1999-03-26-14/%C2%A710-70); [FSFIN 10-70-1–6](https://lovdata.no/forskrift/1999-11-19-1158/%C2%A710-70-1).",
      "line": 165
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/no-reg10701.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "66a02b26bafd9de9cfec230b693ae31602ee5efbc08bbb23778c10240c420504",
  "source_version_basis": "Current actual official body retrieved/read2026-11-16; relevant operative unit and neighbours personally read."
}
```

### NO-REG-5

Return-year tax return must provide the basis information, also for returned capital.

```json
{
  "act_article_or_scope": "FSFIN10-70-5 whole operative unit",
  "actual_read_on": "2026-11-16",
  "id": "NO-REG-5",
  "official_url": "https://lovdata.no/forskrift/1999-11-19-1158/%C2%A710-70-1",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Reporting. Report for the day before residence changes: a change on 1 January 2025 belongs to the 2024 return. While postponement runs, answer the annual questionnaire by 30 April and notify qualifying disposal, transfer or move changes within 2 months. The regulation gives notice and at least 3 weeks to cure material reporting noncompliance before that ground ends postponement. The authority describes an assessment period up to 15 years where exit-tax information is missing; do not treat it as permission to omit reporting. [Current authority reporting/history](https://www.skatteetaten.no/en/person/to-from-norway/from/tax-when-you-move-abroad/exit-tax/); [14-25](https://lovdata.no/lov/1999-03-26-14/%C2%A714-25); [FSFIN](https://lovdata.no/forskrift/1999-11-19-1158/%C2%A710-70-1). For the corridor see `norway-to-switzerland-wealth-tax-exit`.",
      "line": 167
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/no-reg10701.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "66a02b26bafd9de9cfec230b693ae31602ee5efbc08bbb23778c10240c420504",
  "source_version_basis": "Current actual official body retrieved/read2026-11-16; relevant operative unit and neighbours personally read."
}
```

### NO-REG-6

Implementing information-rule authority retained; not a new automatic exemption.

```json
{
  "act_article_or_scope": "FSFIN10-70-6 whole operative unit",
  "actual_read_on": "2026-11-16",
  "id": "NO-REG-6",
  "official_url": "https://lovdata.no/forskrift/1999-11-19-1158/%C2%A710-70-1",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Reporting. Report for the day before residence changes: a change on 1 January 2025 belongs to the 2024 return. While postponement runs, answer the annual questionnaire by 30 April and notify qualifying disposal, transfer or move changes within 2 months. The regulation gives notice and at least 3 weeks to cure material reporting noncompliance before that ground ends postponement. The authority describes an assessment period up to 15 years where exit-tax information is missing; do not treat it as permission to omit reporting. [Current authority reporting/history](https://www.skatteetaten.no/en/person/to-from-norway/from/tax-when-you-move-abroad/exit-tax/); [14-25](https://lovdata.no/lov/1999-03-26-14/%C2%A714-25); [FSFIN](https://lovdata.no/forskrift/1999-11-19-1158/%C2%A710-70-1). For the corridor see `norway-to-switzerland-wealth-tax-exit`.",
      "line": 167
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/no-reg10701.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "66a02b26bafd9de9cfec230b693ae31602ee5efbc08bbb23778c10240c420504",
  "source_version_basis": "Current actual official body retrieved/read2026-11-16; relevant operative unit and neighbours personally read."
}
```

### NO-TIMING

Recognition day before exit;1Januarydeparture belongs to preceding year.

```json
{
  "act_article_or_scope": "TaxAct14-25 whole",
  "actual_read_on": "2026-11-16",
  "id": "NO-TIMING",
  "official_url": "https://lovdata.no/lov/1999-03-26-14/%C2%A714-25",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Payment. The current statute offers immediate payment, 12 equal annual instalments, or postponement of the whole claim with interest. The 12-year endpoint is counted from the END of the tax year in which the deemed gain is recognised, not simply the anniversary of the move. Recognition is the day before the residence/treaty change under section 14-25. Security is normally required, but an EEA move requires a real collection risk before security can be demanded; it is not automatic for every EEA move. [Tax Act 10-70/14-25](https://lovdata.no/lov/1999-03-26-14/%C2%A710-70); [security guideline](https://www.skatteetaten.no/en/rettskilder/type/retningslinjer/retningslinje-for-utsettelse-av-innbetaling-av-fastsatt-utflyttingsskatt-etter-skatteloven--10-70/).",
      "line": 163
    }
  ],
  "short_exact_native_quotes": [
    "§ 14-25.Gevinst og tap på aksjer og andeler mv. ved utflytting Gevinst og tap på eiendel som nevnt i § 10-70 annet ledd tas til"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/no-timing1425.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "2aa87012664638bdca56fc5c207ee3ec862d9dcd6b93de4be2d1dcba7f3f8080",
  "source_version_basis": "Current actual official body retrieved/read2026-11-16; relevant operative unit and neighbours personally read."
}
```

### ES-95BIS-1

10of15history AND>4maggregate OR>25%and>1mholding-only gate.

```json
{
  "act_article_or_scope": "LIRPF95bis(1) whole",
  "actual_read_on": "2026-11-16",
  "id": "ES-95BIS-1",
  "official_url": "https://www.boe.es/buscar/act.php?id=BOE-A-2006-20764",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Who is caught. A taxpayer who loses Spanish taxpayer status by change of residence, and who was a taxpayer in at least ten of the fifteen tax periods before the last period that must be declared ([article 95 bis Ley 35/2006](https://www.boe.es/buscar/act.php?id=BOE-A-2006-20764)). For a person who used the special regime for workers posted to Spain, the ten periods are counted from the first period in which that regime no longer applied.",
      "line": 171
    }
  ],
  "short_exact_native_quotes": [
    "1. Cuando el contribuyente pierda su condición por cambio de residencia, se considerarán ganancias patrimoniales las diferencias positivas entre el valor de mercado de las"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/es-current-lirpf.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "b18d0de5cb1a677d552e23d64e171c094b0c18bf17a09d717ef9b282b5e10fbe",
  "source_version_basis": "CurrentBOEconsolidation updated2026-11-11; common-regime only."
}
```

### ES-95BIS-2

Savings-income treatment/last-period complementary return without penalty,interest,surcharge.

```json
{
  "act_article_or_scope": "LIRPF95bis(2) whole",
  "actual_read_on": "2026-11-16",
  "id": "ES-95BIS-2",
  "official_url": "https://www.boe.es/buscar/act.php?id=BOE-A-2006-20764",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "What is taxed. The positive difference between market value and acquisition value of shares and units of any type of entity, if EITHER the market value of all such holdings together exceeds the first amount in the table, OR, where that test is not met, the person holds more than the percentage in the table in one entity on the accrual date of the last period and the market value of that holding exceeds the second amount. Under the second test only the gain on that holding is taxed. The gain is savings income, imputed to the last period that must be declared, by a complementary self-assessment without penalty, late-payment interest or surcharge. Listed shares use their quotation on accrual; unlisted shares use the higher of the last closed balance-sheet equity and the average results of the last 3 closed years capitalised at 20%, unless another market value is proved. Investment-fund interests use the applicable net-asset-value rule and fallback under 95 bis(3)(c).",
      "line": 175
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/es-current-lirpf.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "b18d0de5cb1a677d552e23d64e171c094b0c18bf17a09d717ef9b282b5e10fbe",
  "source_version_basis": "CurrentBOEconsolidation updated2026-11-11; common-regime only."
}
```

### ES-95BIS-3

Quoted/unquoted/collective-investment valuation rules,3yearprofits20%capitalisation and proved-marketvalue exception.

```json
{
  "act_article_or_scope": "LIRPF95bis(3) whole",
  "actual_read_on": "2026-11-16",
  "id": "ES-95BIS-3",
  "official_url": "https://www.boe.es/buscar/act.php?id=BOE-A-2006-20764",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "What is taxed. The positive difference between market value and acquisition value of shares and units of any type of entity, if EITHER the market value of all such holdings together exceeds the first amount in the table, OR, where that test is not met, the person holds more than the percentage in the table in one entity on the accrual date of the last period and the market value of that holding exceeds the second amount. Under the second test only the gain on that holding is taxed. The gain is savings income, imputed to the last period that must be declared, by a complementary self-assessment without penalty, late-payment interest or surcharge. Listed shares use their quotation on accrual; unlisted shares use the higher of the last closed balance-sheet equity and the average results of the last 3 closed years capitalised at 20%, unless another market value is proved. Investment-fund interests use the applicable net-asset-value rule and fallback under 95 bis(3)(c).",
      "line": 175
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/es-current-lirpf.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "b18d0de5cb1a677d552e23d64e171c094b0c18bf17a09d717ef9b282b5e10fbe",
  "source_version_basis": "CurrentBOEconsolidation updated2026-11-11; common-regime only."
}
```

### ES-95BIS-4

Requested qualifying temporarywork/other treaty move; interest/security/fiveperiodreturnplusuptofiveworkextension and actual relief/no-security-cost refund.

```json
{
  "act_article_or_scope": "LIRPF95bis(4) whole",
  "actual_read_on": "2026-11-16",
  "id": "ES-95BIS-4",
  "official_url": "https://www.boe.es/buscar/act.php?id=BOE-A-2006-20764",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Temporary move elsewhere. On the taxpayer's request, payment is deferred where the change of residence is a temporary move for work to a country or territory that is not a tax haven, or a temporary move for any other reason to a country with a double tax treaty with Spain containing an exchange of information clause. Interest accrues and guarantees are required; the guarantees can be given over the shares. If the person becomes a Spanish taxpayer again within the five periods after the last one declared without having transferred the shares, the deferred debt and the interest are extinguished. For a work move the five periods can be extended, by no more than five more periods.",
      "line": 188
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/es-current-lirpf.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "b18d0de5cb1a677d552e23d64e171c094b0c18bf17a09d717ef9b282b5e10fbe",
  "source_version_basis": "CurrentBOEconsolidation updated2026-11-11; common-regime only."
}
```

### ES-95BIS-5

Return retained-securities rectification/refund with paid-date interest and filing-start condition.

```json
{
  "act_article_or_scope": "LIRPF95bis(5) whole",
  "actual_read_on": "2026-11-16",
  "id": "ES-95BIS-5",
  "official_url": "https://www.boe.es/buscar/act.php?id=BOE-A-2006-20764",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Return after paying. A person who becomes a Spanish taxpayer again without having transferred the shares can ask for rectification of the self-assessment and a refund, with interest from the date of payment.",
      "line": 190
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/es-current-lirpf.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "b18d0de5cb1a677d552e23d64e171c094b0c18bf17a09d717ef9b282b5e10fbe",
  "source_version_basis": "CurrentBOEconsolidation updated2026-11-11; common-regime only."
}
```

### ES-95BIS-6

Optional qualifyingEU/EEA effective-exchange route;10periodthreeevent triggers/reporting/lowerdisposalgain adjustments/return without event.

```json
{
  "act_article_or_scope": "LIRPF95bis(6) whole",
  "actual_read_on": "2026-11-16",
  "id": "ES-95BIS-6",
  "official_url": "https://www.boe.es/buscar/act.php?id=BOE-A-2006-20764",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Move to another EU or EEA state. Where the new residence is in another EU member state, or an EEA state with effective exchange of tax information, the taxpayer can opt for special rules: the gain is self-assessed only if, within the ten periods after the last one declared, the shares are transferred inter vivos, the person stops being resident in an EU or EEA state, or the person fails to make the required communication. The option, the gain, the new state and address, later changes, and continued ownership must be communicated to the tax authority. If the person becomes a Spanish taxpayer again before any of those events, the rule has no effect.",
      "line": 186
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/es-current-lirpf.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "b18d0de5cb1a677d552e23d64e171c094b0c18bf17a09d717ef9b282b5e10fbe",
  "source_version_basis": "CurrentBOEconsolidation updated2026-11-11; common-regime only."
}
```

### ES-95BIS-7

Haven move retaining taxpayer status; special timing and subsequent basis.

```json
{
  "act_article_or_scope": "LIRPF95bis(7) whole",
  "actual_read_on": "2026-11-16",
  "id": "ES-95BIS-7",
  "official_url": "https://www.boe.es/buscar/act.php?id=BOE-A-2006-20764",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Tax havens. The article also applies where a person moves to a tax haven but keeps Spanish taxpayer status under article 8.2, with the gain imputed to the last period of habitual residence in Spain.",
      "line": 192
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/es-current-lirpf.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "b18d0de5cb1a677d552e23d64e171c094b0c18bf17a09d717ef9b282b5e10fbe",
  "source_version_basis": "CurrentBOEconsolidation updated2026-11-11; common-regime only."
}
```

### ES-95BIS-8

Former special impatriate regime starts10periodcount only when regime ceases.

```json
{
  "act_article_or_scope": "LIRPF95bis(8) whole",
  "actual_read_on": "2026-11-16",
  "id": "ES-95BIS-8",
  "official_url": "https://www.boe.es/buscar/act.php?id=BOE-A-2006-20764",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Who is caught. A taxpayer who loses Spanish taxpayer status by change of residence, and who was a taxpayer in at least ten of the fifteen tax periods before the last period that must be declared ([article 95 bis Ley 35/2006](https://www.boe.es/buscar/act.php?id=BOE-A-2006-20764)). For a person who used the special regime for workers posted to Spain, the ten periods are counted from the first period in which that regime no longer applied.",
      "line": 171
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/es-current-lirpf.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "b18d0de5cb1a677d552e23d64e171c094b0c18bf17a09d717ef9b282b5e10fbe",
  "source_version_basis": "CurrentBOEconsolidation updated2026-11-11; common-regime only."
}
```

### ES-SCOPE

Basque/Navarre foral systems preserved; no common-regime universality.

```json
{
  "act_article_or_scope": "LIRPF4 operative article and printed change notes",
  "actual_read_on": "2026-11-16",
  "id": "ES-SCOPE",
  "official_url": "https://www.boe.es/buscar/act.php?id=BOE-A-2006-20764",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Article 95 bis is the law of common-regime Spain. The Basque historical territories and Navarre apply their own income tax law (\"sin perjuicio de los regímenes tributarios forales de concierto y convenio económico en vigor, respectivamente, en los Territorios Históricos del País Vasco y en la Comunidad Foral de Navarra\", [article 4 Ley 35/2006](https://www.boe.es/buscar/act.php?id=BOE-A-2006-20764)); this Guide does not cover them.",
      "line": 173
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/es-current-lirpf.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "b18d0de5cb1a677d552e23d64e171c094b0c18bf17a09d717ef9b282b5e10fbe",
  "source_version_basis": "CurrentBOE2026-11-11; actual table/notes personally read, common-regime resident calculation."
}
```

### ES-TAXPAYER

Spanish nationals moving to a haven retain taxpayer status for the stated periods.

```json
{
  "act_article_or_scope": "LIRPF8 operative article and printed change notes",
  "actual_read_on": "2026-11-16",
  "id": "ES-TAXPAYER",
  "official_url": "https://www.boe.es/buscar/act.php?id=BOE-A-2006-20764",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Tax havens. The article also applies where a person moves to a tax haven but keeps Spanish taxpayer status under article 8.2, with the gain imputed to the last period of habitual residence in Spain.",
      "line": 192
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/es-current-lirpf.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "b18d0de5cb1a677d552e23d64e171c094b0c18bf17a09d717ef9b282b5e10fbe",
  "source_version_basis": "CurrentBOE2026-11-11; actual table/notes personally read, common-regime resident calculation."
}
```

### ES-STATE-RATE

Resident state savings half35,940at300000and15%above; do not substitute66(2)alone.

```json
{
  "act_article_or_scope": "LIRPF66 operative article and printed change notes",
  "actual_read_on": "2026-11-16",
  "id": "ES-STATE-RATE",
  "official_url": "https://www.boe.es/buscar/act.php?id=BOE-A-2006-20764",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "| Savings scale: tax on the first EUR 300,000 of the savings base (state and regional halves together, as the common resident state and regional halves in articles 66.1 and 76) | EUR 71,880 | Articles 66(1) and 76 each print EUR 35,940 at EUR 300,000 and 15% above it; the combined amounts are derived here, not quoted as one resident table.  https://www.boe.es/buscar/act.php?id=BOE-A-2006-20764 |",
      "line": 183
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/es-current-lirpf.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "b18d0de5cb1a677d552e23d64e171c094b0c18bf17a09d717ef9b282b5e10fbe",
  "source_version_basis": "CurrentBOE2026-11-11; actual table/notes personally read, common-regime resident calculation."
}
```

### ES-REGIONAL-RATE

Resident regional savings half35,940at300000and15%above; combined71880and30%are arithmetic.

```json
{
  "act_article_or_scope": "LIRPF76 operative article and printed change notes",
  "actual_read_on": "2026-11-16",
  "id": "ES-REGIONAL-RATE",
  "official_url": "https://www.boe.es/buscar/act.php?id=BOE-A-2006-20764",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "| Savings scale: rate on the savings base above EUR 300,000 | 30% | Articles 66(1) and 76 each print EUR 35,940 at EUR 300,000 and 15% above it; the combined amounts are derived here, not quoted as one resident table.  https://www.boe.es/buscar/act.php?id=BOE-A-2006-20764 |",
      "line": 184
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/es-current-lirpf.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "b18d0de5cb1a677d552e23d64e171c094b0c18bf17a09d717ef9b282b5e10fbe",
  "source_version_basis": "CurrentBOE2026-11-11; actual table/notes personally read, common-regime resident calculation."
}
```

### IT-166-1

Five commercial-business exit/taxing-right events; no universal private-share migration charge.

```json
{
  "act_article_or_scope": "CurrentTUIR166(1) full",
  "actual_read_on": "2026-11-16",
  "id": "IT-166-1",
  "official_url": "https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.del.presidente.della.repubblica:1986-12-22;917~art166!vig=2026-11-16",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Current TUIR 166 applies to persons carrying on commercial businesses. Its events cover residence transfer and specified asset/business transfers or restructurings that remove Italian taxing rights; assets retained in the Italian permanent establishment are treated under the relevant exceptions. The taxable value uses the event-specific market-value rules, including goodwill where applicable, less the tax basis; losses have separate limitations. An individual’s migration does not by itself establish that privately held company shares are a commercial business, and paragraph 14 says the company’s transfer does not itself tax its shareholders. [Actual 2026 article 166, paragraphs 1–15](https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.del.presidente.della.repubblica:1986-12-22;917~art166!vig=2026-11-16).",
      "line": 196
    }
  ],
  "short_exact_native_quotes": [
    "1. ((Le disposizioni del presente articolo si applicano ai soggetti che esercitano imprese commerciali qualora si verifichi una delle seguenti ipotesi:)) a) ((sono fiscalmente residenti"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/it-current166.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "f47a50d29a5102007ad5a534f95ad8ce29d5f1a2cfa85f10bac6849d4791e415",
  "source_version_basis": "Actual point-in-time2026-11-16 version; full1–15and2018effect note personally read. Recast application2027separately limited."
}
```

### IT-166-2

Separate-entity/function/risk/asset transfer criteria.

```json
{
  "act_article_or_scope": "CurrentTUIR166(2) full",
  "actual_read_on": "2026-11-16",
  "id": "IT-166-2",
  "official_url": "https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.del.presidente.della.repubblica:1986-12-22;917~art166!vig=2026-11-16",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Current TUIR 166 applies to persons carrying on commercial businesses. Its events cover residence transfer and specified asset/business transfers or restructurings that remove Italian taxing rights; assets retained in the Italian permanent establishment are treated under the relevant exceptions. The taxable value uses the event-specific market-value rules, including goodwill where applicable, less the tax basis; losses have separate limitations. An individual’s migration does not by itself establish that privately held company shares are a commercial business, and paragraph 14 says the company’s transfer does not itself tax its shareholders. [Actual 2026 article 166, paragraphs 1–15](https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.del.presidente.della.repubblica:1986-12-22;917~art166!vig=2026-11-16).",
      "line": 196
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/it-current166.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "f47a50d29a5102007ad5a534f95ad8ce29d5f1a2cfa85f10bac6849d4791e415",
  "source_version_basis": "Actual point-in-time2026-11-16 version; full1–15and2018effect note personally read. Recast application2027separately limited."
}
```

### IT-166-3

Event-specific market-value minus tax-basis charge and ItalianPE retention exceptions.

```json
{
  "act_article_or_scope": "CurrentTUIR166(3) full",
  "actual_read_on": "2026-11-16",
  "id": "IT-166-3",
  "official_url": "https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.del.presidente.della.repubblica:1986-12-22;917~art166!vig=2026-11-16",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Current TUIR 166 applies to persons carrying on commercial businesses. Its events cover residence transfer and specified asset/business transfers or restructurings that remove Italian taxing rights; assets retained in the Italian permanent establishment are treated under the relevant exceptions. The taxable value uses the event-specific market-value rules, including goodwill where applicable, less the tax basis; losses have separate limitations. An individual’s migration does not by itself establish that privately held company shares are a commercial business, and paragraph 14 says the company’s transfer does not itself tax its shareholders. [Actual 2026 article 166, paragraphs 1–15](https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.del.presidente.della.repubblica:1986-12-22;917~art166!vig=2026-11-16).",
      "line": 196
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/it-current166.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "f47a50d29a5102007ad5a534f95ad8ce29d5f1a2cfa85f10bac6849d4791e415",
  "source_version_basis": "Actual point-in-time2026-11-16 version; full1–15and2018effect note personally read. Recast application2027separately limited."
}
```

### IT-166-4

Prescribed market-value and goodwill valuation.

```json
{
  "act_article_or_scope": "CurrentTUIR166(4) full",
  "actual_read_on": "2026-11-16",
  "id": "IT-166-4",
  "official_url": "https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.del.presidente.della.repubblica:1986-12-22;917~art166!vig=2026-11-16",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Current TUIR 166 applies to persons carrying on commercial businesses. Its events cover residence transfer and specified asset/business transfers or restructurings that remove Italian taxing rights; assets retained in the Italian permanent establishment are treated under the relevant exceptions. The taxable value uses the event-specific market-value rules, including goodwill where applicable, less the tax basis; losses have separate limitations. An individual’s migration does not by itself establish that privately held company shares are a commercial business, and paragraph 14 says the company’s transfer does not itself tax its shareholders. [Actual 2026 article 166, paragraphs 1–15](https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.del.presidente.della.repubblica:1986-12-22;917~art166!vig=2026-11-16).",
      "line": 196
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/it-current166.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "f47a50d29a5102007ad5a534f95ad8ce29d5f1a2cfa85f10bac6849d4791e415",
  "source_version_basis": "Actual point-in-time2026-11-16 version; full1–15and2018effect note personally read. Recast application2027separately limited."
}
```

### IT-166-5

Suspended reserves and retainedPE reconstruction conditions.

```json
{
  "act_article_or_scope": "CurrentTUIR166(5) full",
  "actual_read_on": "2026-11-16",
  "id": "IT-166-5",
  "official_url": "https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.del.presidente.della.repubblica:1986-12-22;917~art166!vig=2026-11-16",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Current TUIR 166 applies to persons carrying on commercial businesses. Its events cover residence transfer and specified asset/business transfers or restructurings that remove Italian taxing rights; assets retained in the Italian permanent establishment are treated under the relevant exceptions. The taxable value uses the event-specific market-value rules, including goodwill where applicable, less the tax basis; losses have separate limitations. An individual’s migration does not by itself establish that privately held company shares are a commercial business, and paragraph 14 says the company’s transfer does not itself tax its shareholders. [Actual 2026 article 166, paragraphs 1–15](https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.del.presidente.della.repubblica:1986-12-22;917~art166!vig=2026-11-16).",
      "line": 196
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/it-current166.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "f47a50d29a5102007ad5a534f95ad8ce29d5f1a2cfa85f10bac6849d4791e415",
  "source_version_basis": "Actual point-in-time2026-11-16 version; full1–15and2018effect note personally read. Recast application2027separately limited."
}
```

### IT-166-6

Event-specific loss use and retainedPE limits.

```json
{
  "act_article_or_scope": "CurrentTUIR166(6) full",
  "actual_read_on": "2026-11-16",
  "id": "IT-166-6",
  "official_url": "https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.del.presidente.della.repubblica:1986-12-22;917~art166!vig=2026-11-16",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Current TUIR 166 applies to persons carrying on commercial businesses. Its events cover residence transfer and specified asset/business transfers or restructurings that remove Italian taxing rights; assets retained in the Italian permanent establishment are treated under the relevant exceptions. The taxable value uses the event-specific market-value rules, including goodwill where applicable, less the tax basis; losses have separate limitations. An individual’s migration does not by itself establish that privately held company shares are a commercial business, and paragraph 14 says the company’s transfer does not itself tax its shareholders. [Actual 2026 article 166, paragraphs 1–15](https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.del.presidente.della.repubblica:1986-12-22;917~art166!vig=2026-11-16).",
      "line": 196
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/it-current166.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "f47a50d29a5102007ad5a534f95ad8ce29d5f1a2cfa85f10bac6849d4791e415",
  "source_version_basis": "Actual point-in-time2026-11-16 version; full1–15and2018effect note personally read. Recast application2027separately limited."
}
```

### IT-166-7

Event-specific valuation/recognition dates.

```json
{
  "act_article_or_scope": "CurrentTUIR166(7) full",
  "actual_read_on": "2026-11-16",
  "id": "IT-166-7",
  "official_url": "https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.del.presidente.della.repubblica:1986-12-22;917~art166!vig=2026-11-16",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Current TUIR 166 applies to persons carrying on commercial businesses. Its events cover residence transfer and specified asset/business transfers or restructurings that remove Italian taxing rights; assets retained in the Italian permanent establishment are treated under the relevant exceptions. The taxable value uses the event-specific market-value rules, including goodwill where applicable, less the tax basis; losses have separate limitations. An individual’s migration does not by itself establish that privately held company shares are a commercial business, and paragraph 14 says the company’s transfer does not itself tax its shareholders. [Actual 2026 article 166, paragraphs 1–15](https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.del.presidente.della.repubblica:1986-12-22;917~art166!vig=2026-11-16).",
      "line": 196
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/it-current166.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "f47a50d29a5102007ad5a534f95ad8ce29d5f1a2cfa85f10bac6849d4791e415",
  "source_version_basis": "Actual point-in-time2026-11-16 version; full1–15and2018effect note personally read. Recast application2027separately limited."
}
```

### IT-166-8

Post-event loss/value treatment limits.

```json
{
  "act_article_or_scope": "CurrentTUIR166(8) full",
  "actual_read_on": "2026-11-16",
  "id": "IT-166-8",
  "official_url": "https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.del.presidente.della.repubblica:1986-12-22;917~art166!vig=2026-11-16",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Current TUIR 166 applies to persons carrying on commercial businesses. Its events cover residence transfer and specified asset/business transfers or restructurings that remove Italian taxing rights; assets retained in the Italian permanent establishment are treated under the relevant exceptions. The taxable value uses the event-specific market-value rules, including goodwill where applicable, less the tax basis; losses have separate limitations. An individual’s migration does not by itself establish that privately held company shares are a commercial business, and paragraph 14 says the company’s transfer does not itself tax its shareholders. [Actual 2026 article 166, paragraphs 1–15](https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.del.presidente.della.repubblica:1986-12-22;917~art166!vig=2026-11-16).",
      "line": 196
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/it-current166.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "f47a50d29a5102007ad5a534f95ad8ce29d5f1a2cfa85f10bac6849d4791e415",
  "source_version_basis": "Actual point-in-time2026-11-16 version; full1–15and2018effect note personally read. Recast application2027separately limited."
}
```

### IT-166-9

QualifiedEU/EEAassistance election for5equalannual instalments across the stated event cases.

```json
{
  "act_article_or_scope": "CurrentTUIR166(9) full",
  "actual_read_on": "2026-11-16",
  "id": "IT-166-9",
  "official_url": "https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.del.presidente.della.repubblica:1986-12-22;917~art166!vig=2026-11-16",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Paragraph 9 allows an election for 5 equal annual instalments in its qualifying EU/EEA assistance cases. Interest runs on later instalments; security and collection conditions apply. Disposal, onward nonqualifying transfer, insolvency and missed payments can accelerate collection under the stated rules; the missed-payment provision includes its 5-month cure. This is not a general private-portfolio deferral or an established cancellation on return. Do not state an Italian tax rate from this comparison. Refer the business valuation, election and charge to an Italian professional. [166(9)–(15)](https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.del.presidente.della.repubblica:1986-12-22;917~art166!vig=2026-11-16).",
      "line": 198
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/it-current166.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "f47a50d29a5102007ad5a534f95ad8ce29d5f1a2cfa85f10bac6849d4791e415",
  "source_version_basis": "Actual point-in-time2026-11-16 version; full1–15and2018effect note personally read. Recast application2027separately limited."
}
```

### IT-166-10

The instalment election necessarily covers the whole prescribed unitary tax.

```json
{
  "act_article_or_scope": "CurrentTUIR166(10) full",
  "actual_read_on": "2026-11-16",
  "id": "IT-166-10",
  "official_url": "https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.del.presidente.della.repubblica:1986-12-22;917~art166!vig=2026-11-16",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Paragraph 9 allows an election for 5 equal annual instalments in its qualifying EU/EEA assistance cases. Interest runs on later instalments; security and collection conditions apply. Disposal, onward nonqualifying transfer, insolvency and missed payments can accelerate collection under the stated rules; the missed-payment provision includes its 5-month cure. This is not a general private-portfolio deferral or an established cancellation on return. Do not state an Italian tax rate from this comparison. Refer the business valuation, election and charge to an Italian professional. [166(9)–(15)](https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.del.presidente.della.repubblica:1986-12-22;917~art166!vig=2026-11-16).",
      "line": 198
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/it-current166.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "f47a50d29a5102007ad5a534f95ad8ce29d5f1a2cfa85f10bac6849d4791e415",
  "source_version_basis": "Actual point-in-time2026-11-16 version; full1–15and2018effect note personally read. Recast application2027separately limited."
}
```

### IT-166-11

Interest is payable on instalments after the first under the specified cross-reference.

```json
{
  "act_article_or_scope": "CurrentTUIR166(11) full",
  "actual_read_on": "2026-11-16",
  "id": "IT-166-11",
  "official_url": "https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.del.presidente.della.repubblica:1986-12-22;917~art166!vig=2026-11-16",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Paragraph 9 allows an election for 5 equal annual instalments in its qualifying EU/EEA assistance cases. Interest runs on later instalments; security and collection conditions apply. Disposal, onward nonqualifying transfer, insolvency and missed payments can accelerate collection under the stated rules; the missed-payment provision includes its 5-month cure. This is not a general private-portfolio deferral or an established cancellation on return. Do not state an Italian tax rate from this comparison. Refer the business valuation, election and charge to an Italian professional. [166(9)–(15)](https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.del.presidente.della.repubblica:1986-12-22;917~art166!vig=2026-11-16).",
      "line": 198
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/it-current166.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "f47a50d29a5102007ad5a534f95ad8ce29d5f1a2cfa85f10bac6849d4791e415",
  "source_version_basis": "Actual point-in-time2026-11-16 version; full1–15and2018effect note personally read. Recast application2027separately limited."
}
```

### IT-166-12

Statutory acceleration cases including disposal/onwardtransfer/insolvency/missedpayment with5monthcure.

```json
{
  "act_article_or_scope": "CurrentTUIR166(12) full",
  "actual_read_on": "2026-11-16",
  "id": "IT-166-12",
  "official_url": "https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.del.presidente.della.repubblica:1986-12-22;917~art166!vig=2026-11-16",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Paragraph 9 allows an election for 5 equal annual instalments in its qualifying EU/EEA assistance cases. Interest runs on later instalments; security and collection conditions apply. Disposal, onward nonqualifying transfer, insolvency and missed payments can accelerate collection under the stated rules; the missed-payment provision includes its 5-month cure. This is not a general private-portfolio deferral or an established cancellation on return. Do not state an Italian tax rate from this comparison. Refer the business valuation, election and charge to an Italian professional. [166(9)–(15)](https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.del.presidente.della.repubblica:1986-12-22;917~art166!vig=2026-11-16).",
      "line": 198
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/it-current166.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "f47a50d29a5102007ad5a534f95ad8ce29d5f1a2cfa85f10bac6849d4791e415",
  "source_version_basis": "Actual point-in-time2026-11-16 version; full1–15and2018effect note personally read. Recast application2027separately limited."
}
```

### IT-166-13

Individual businesses and partnerships have the prescribed article17(1)(g)/(l) cross-reference; not a general private-portfolio rule.

```json
{
  "act_article_or_scope": "CurrentTUIR166(13) full",
  "actual_read_on": "2026-11-16",
  "id": "IT-166-13",
  "official_url": "https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.del.presidente.della.repubblica:1986-12-22;917~art166!vig=2026-11-16",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Paragraph 9 allows an election for 5 equal annual instalments in its qualifying EU/EEA assistance cases. Interest runs on later instalments; security and collection conditions apply. Disposal, onward nonqualifying transfer, insolvency and missed payments can accelerate collection under the stated rules; the missed-payment provision includes its 5-month cure. This is not a general private-portfolio deferral or an established cancellation on return. Do not state an Italian tax rate from this comparison. Refer the business valuation, election and charge to an Italian professional. [166(9)–(15)](https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.del.presidente.della.repubblica:1986-12-22;917~art166!vig=2026-11-16).",
      "line": 198
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/it-current166.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "f47a50d29a5102007ad5a534f95ad8ce29d5f1a2cfa85f10bac6849d4791e415",
  "source_version_basis": "Actual point-in-time2026-11-16 version; full1–15and2018effect note personally read. Recast application2027separately limited."
}
```

### IT-166-14

Company migration does not by itself charge its shareholders.

```json
{
  "act_article_or_scope": "CurrentTUIR166(14) full",
  "actual_read_on": "2026-11-16",
  "id": "IT-166-14",
  "official_url": "https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.del.presidente.della.repubblica:1986-12-22;917~art166!vig=2026-11-16",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Current TUIR 166 applies to persons carrying on commercial businesses. Its events cover residence transfer and specified asset/business transfers or restructurings that remove Italian taxing rights; assets retained in the Italian permanent establishment are treated under the relevant exceptions. The taxable value uses the event-specific market-value rules, including goodwill where applicable, less the tax basis; losses have separate limitations. An individual’s migration does not by itself establish that privately held company shares are a commercial business, and paragraph 14 says the company’s transfer does not itself tax its shareholders. [Actual 2026 article 166, paragraphs 1–15](https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.del.presidente.della.repubblica:1986-12-22;917~art166!vig=2026-11-16).",
      "line": 196
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/it-current166.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "f47a50d29a5102007ad5a534f95ad8ce29d5f1a2cfa85f10bac6849d4791e415",
  "source_version_basis": "Actual point-in-time2026-11-16 version; full1–15and2018effect note personally read. Recast application2027separately limited."
}
```

### IT-166-15

Administrative implementing provisions may prescribe election, guarantees and monitoring of acceleration.

```json
{
  "act_article_or_scope": "CurrentTUIR166(15) full",
  "actual_read_on": "2026-11-16",
  "id": "IT-166-15",
  "official_url": "https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.del.presidente.della.repubblica:1986-12-22;917~art166!vig=2026-11-16",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Paragraph 9 allows an election for 5 equal annual instalments in its qualifying EU/EEA assistance cases. Interest runs on later instalments; security and collection conditions apply. Disposal, onward nonqualifying transfer, insolvency and missed payments can accelerate collection under the stated rules; the missed-payment provision includes its 5-month cure. This is not a general private-portfolio deferral or an established cancellation on return. Do not state an Italian tax rate from this comparison. Refer the business valuation, election and charge to an Italian professional. [166(9)–(15)](https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.del.presidente.della.repubblica:1986-12-22;917~art166!vig=2026-11-16).",
      "line": 198
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/it-current166.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "f47a50d29a5102007ad5a534f95ad8ce29d5f1a2cfa85f10bac6849d4791e415",
  "source_version_basis": "Actual point-in-time2026-11-16 version; full1–15and2018effect note personally read. Recast application2027separately limited."
}
```

### CA-1281-4

Departure deemed-disposal/reacquisition and all listed(a)–(d)exceptions/election, including60months-in10years scope.

```json
{
  "act_article_or_scope": "ITA128.1(4) whole",
  "actual_read_on": "2026-11-16",
  "id": "CA-1281-4",
  "official_url": "https://laws-lois.justice.gc.ca/eng/acts/I-3.3/section-128.1.html",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "What is not caught. The exceptions the page lists include: Canadian real or immovable property, Canadian resource property and timber resource property; Canadian business property (including inventory) where the business is carried on through a permanent establishment in Canada; pension plans, annuities, registered retirement savings plans, registered retirement income funds, registered education and disability savings plans, tax-free savings accounts and the other plans and rights the page lists as excluded rights or interests; and property owned on last becoming resident (or inherited afterwards) by an individual who was resident in Canada for 60 months or less in the ten years before emigrating. A person can elect to report a deemed disposition of the first two kinds of property.",
      "line": 206
    }
  ],
  "short_exact_native_quotes": [
    "(4) For the purposes of this Act, where at a particular time a taxpayer ceases to be resident in Canada, Marginal note:Year-end, fiscal period"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/ca-ita1281.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "041773d41fb70c29f3468d15a0de0899e691ebee03d287c91e028da4c6d4f5a9",
  "source_version_basis": "Actual current official law and adjacent5–8/9–10 personally read16November2026."
}
```

### CA-1281-6

Post1996return written election by filingdue date, continuous holdings, differentTCP/other formulas and exact originalgain/currentFMV/electedamount least rule.

```json
{
  "act_article_or_scope": "ITA128.1(6) whole",
  "actual_read_on": "2026-11-16",
  "id": "CA-1281-6",
  "official_url": "https://laws-lois.justice.gc.ca/eng/acts/I-3.3/section-128.1.html",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "On return. For post-1 October 1996 departures, ITA 128.1(6) provides a written election by the filing due date for the return year, subject to continuous retained ownership. Taxable Canadian property and other property have different adjustment formulas; the other-property branch requires its arrival deemed-disposition condition and uses the least of the original deemed gain, return-date fair market value and elected amount. This is not automatic relief for every earlier payment. [Actual 128.1(6)](https://laws-lois.justice.gc.ca/eng/acts/I-3.3/section-128.1.html). This Guide does not state a Canadian rate. For residence questions, see `ca-tax-residency`.",
      "line": 217
    }
  ],
  "short_exact_native_quotes": [
    "(6)"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/ca-ita1281.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "041773d41fb70c29f3468d15a0de0899e691ebee03d287c91e028da4c6d4f5a9",
  "source_version_basis": "Actual current official law and adjacent5–8/9–10 personally read16November2026."
}
```

### CA-1281-9

Reportable-property aggregate>25000and prescribed list by filingdue date.

```json
{
  "act_article_or_scope": "ITA128.1(9) whole",
  "actual_read_on": "2026-11-16",
  "id": "CA-1281-9",
  "official_url": "https://laws-lois.justice.gc.ca/eng/acts/I-3.3/section-128.1.html",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "| Form T1161 required if the fair market value of reportable property owned on leaving was more than | CAD 25,000 | Reportable-property scope and exclusions must also be applied.  https://www.canada.ca/en/revenue-agency/services/tax/international-non-residents/individuals-leaving-entering-canada-non-residents/dispositions-property.html |",
      "line": 211
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/ca-ita1281.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "041773d41fb70c29f3468d15a0de0899e691ebee03d287c91e028da4c6d4f5a9",
  "source_version_basis": "Actual current official law and adjacent5–8/9–10 personally read16November2026."
}
```

### CA-220-4.5

Individual election,excludedemployeeplan,security/securedamount and payment timing.

```json
{
  "act_article_or_scope": "ITA220(4.5) whole",
  "actual_read_on": "2026-11-16",
  "id": "CA-220-4.5",
  "official_url": "https://laws-lois.justice.gc.ca/eng/acts/I-3.3/section-220.html",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Forms and deferral. The gains are computed on Form T1243 and carried to Schedule 3 of the return for the year of departure. Form T1161 lists all property inside and outside Canada above the limit in the table, with listed exclusions such as cash. Form T1244 is the election to defer payment of the tax on the deemed disposition until the property is sold, without interest; it must be made by April 30 of the year after emigration, and it does not apply to the deemed disposition of an employee benefit plan. Above the limit in the table, adequate security is required; provincial or territorial tax may also need security. The page is written for the 2025 return; the 2026 equivalents are not printed on it.",
      "line": 215
    }
  ],
  "short_exact_native_quotes": [
    "(4.5) If an individual who is deemed by subsection 128.1(4) to have disposed of a property (other than a right to a benefit under, or"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/ca-ita220.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "2e28a18f50c8baf511882e83b2dcb489fa9eff9784ecb424226ee06271c7b52e",
  "source_version_basis": "Current actual official body retrieved/read2026-11-16; relevant operative unit and neighbours personally read."
}
```

### CA-220-4.51

Deemed acceptable security condition and limit.

```json
{
  "act_article_or_scope": "ITA220(4.51) whole",
  "actual_read_on": "2026-11-16",
  "id": "CA-220-4.51",
  "official_url": "https://laws-lois.justice.gc.ca/eng/acts/I-3.3/section-220.html",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Forms and deferral. The gains are computed on Form T1243 and carried to Schedule 3 of the return for the year of departure. Form T1161 lists all property inside and outside Canada above the limit in the table, with listed exclusions such as cash. Form T1244 is the election to defer payment of the tax on the deemed disposition until the property is sold, without interest; it must be made by April 30 of the year after emigration, and it does not apply to the deemed disposition of an employee benefit plan. Above the limit in the table, adequate security is required; provincial or territorial tax may also need security. The page is written for the 2025 return; the 2026 equivalents are not printed on it.",
      "line": 215
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/ca-ita220.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "2e28a18f50c8baf511882e83b2dcb489fa9eff9784ecb424226ee06271c7b52e",
  "source_version_basis": "Current actual official body retrieved/read2026-11-16; relevant operative unit and neighbours personally read."
}
```

### CA-220-4.52

Required security limitations and attributed amounts.

```json
{
  "act_article_or_scope": "ITA220(4.52) whole",
  "actual_read_on": "2026-11-16",
  "id": "CA-220-4.52",
  "official_url": "https://laws-lois.justice.gc.ca/eng/acts/I-3.3/section-220.html",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Forms and deferral. The gains are computed on Form T1243 and carried to Schedule 3 of the return for the year of departure. Form T1161 lists all property inside and outside Canada above the limit in the table, with listed exclusions such as cash. Form T1244 is the election to defer payment of the tax on the deemed disposition until the property is sold, without interest; it must be made by April 30 of the year after emigration, and it does not apply to the deemed disposition of an employee benefit plan. Above the limit in the table, adequate security is required; provincial or territorial tax may also need security. The page is written for the 2025 return; the 2026 equivalents are not printed on it.",
      "line": 215
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/ca-ita220.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "2e28a18f50c8baf511882e83b2dcb489fa9eff9784ecb424226ee06271c7b52e",
  "source_version_basis": "Current actual official body retrieved/read2026-11-16; relevant operative unit and neighbours personally read."
}
```

### CA-220-4.53

Additional security with90daystatutorycure.

```json
{
  "act_article_or_scope": "ITA220(4.53) whole",
  "actual_read_on": "2026-11-16",
  "id": "CA-220-4.53",
  "official_url": "https://laws-lois.justice.gc.ca/eng/acts/I-3.3/section-220.html",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Forms and deferral. The gains are computed on Form T1243 and carried to Schedule 3 of the return for the year of departure. Form T1161 lists all property inside and outside Canada above the limit in the table, with listed exclusions such as cash. Form T1244 is the election to defer payment of the tax on the deemed disposition until the property is sold, without interest; it must be made by April 30 of the year after emigration, and it does not apply to the deemed disposition of an employee benefit plan. Above the limit in the table, adequate security is required; provincial or territorial tax may also need security. The page is written for the 2025 return; the 2026 equivalents are not printed on it.",
      "line": 215
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/ca-ita220.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "2e28a18f50c8baf511882e83b2dcb489fa9eff9784ecb424226ee06271c7b52e",
  "source_version_basis": "Current actual official body retrieved/read2026-11-16; relevant operative unit and neighbours personally read."
}
```

### CA-220-4.54

Equitable Minister extension of the prescribed election period.

```json
{
  "act_article_or_scope": "ITA220(4.54) whole",
  "actual_read_on": "2026-11-16",
  "id": "CA-220-4.54",
  "official_url": "https://laws-lois.justice.gc.ca/eng/acts/I-3.3/section-220.html",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "Forms and deferral. The gains are computed on Form T1243 and carried to Schedule 3 of the return for the year of departure. Form T1161 lists all property inside and outside Canada above the limit in the table, with listed exclusions such as cash. Form T1244 is the election to defer payment of the tax on the deemed disposition until the property is sold, without interest; it must be made by April 30 of the year after emigration, and it does not apply to the deemed disposition of an employee benefit plan. Above the limit in the table, adequate security is required; provincial or territorial tax may also need security. The page is written for the 2025 return; the 2026 equivalents are not printed on it.",
      "line": 215
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/ca-ita220.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "2e28a18f50c8baf511882e83b2dcb489fa9eff9784ecb424226ee06271c7b52e",
  "source_version_basis": "Current actual official body retrieved/read2026-11-16; relevant operative unit and neighbours personally read."
}
```

### AU-I1-EVENT

I1 occurs when residence ceases. It covers assets except specified855-15items1/3 and linkeditem4rights, computes gain/loss from market value and cost/reduced cost, and has an indirect-property interest reset and pre1985exception.

```json
{
  "act_article_or_scope": "ITAA1997 s104-160(1)–(5)",
  "actual_read_on": "2026-11-16",
  "id": "AU-I1-EVENT",
  "official_url": "https://www.legislation.gov.au/C2004A05138/2026-10-01/2026-10-01/text/original/epub/OEBPS/document_3/document_3.html",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "sections": [
    {
      "actual_text": "The detailed route remains `leaving-australia-tax-residency-cgt`; current legislation now supplies readable primary support. CGT event I1 happens when a person ceases to be an Australian resident. The specified pre-CGT and temporary-resident exclusions must be applied. I1 excludes the taxable-Australian-property items 1 and 3 in 855-15 and their linked item4 rights; it can still cover an indirect Australian real-property interest. The individual may choose to disregard all covered I1 capital gains/losses, but covered assets are then treated as taxable Australian property until their next CGT event or residence resumes; the choice is not permanent exemption. Division 855 defines taxable Australian property, while 768-915/995-1 govern the temporary-resident exception and definition. No Australian tax bill or automatic return cancellation is computed here. [ITAA 1997 104-160/104-165/855-15/768-915/995-1](https://www.legislation.gov.au/C2004A05138/latest/text). Refer valuation, election and treaty interaction to an Australian practitioner.",
      "line": 221
    }
  ],
  "short_exact_native_quotes": [
    "104‑160 Individual or company stops being an Australian resident: CGT event I1 (1) CGT event I1 happens if you stop being an Australian resident. (2)"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/res-au-law.txt",
  "source_provenance": "Same writer own actual16November residence-source reading reused for this candidate-specific scope, not another reader approval; precise source version remains binding.",
  "source_sha256": "f7cc8357901110c3994c86e446a96abdecef5e42fbd6620d340f39a3842372e2",
  "source_version_basis": "Compilation268 dated1October2026; actual retained source personally reread3977–4010"
}
```

### AU-I1-INDIVIDUAL-CHOICE

An individual can choose to disregard gains/losses from all covered I1assets. They become TAP until an ownership-ending CGT event or resumed residence. The specific2006historical-transition note must also be checked.

```json
{
  "act_article_or_scope": "ITAA1997 s104-165(2)–(3) including historical transition note",
  "actual_read_on": "2026-11-16",
  "id": "AU-I1-INDIVIDUAL-CHOICE",
  "official_url": "https://www.legislation.gov.au/C2004A05138/2026-10-01/2026-10-01/text/original/epub/OEBPS/document_3/document_3.html",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "sections": [
    {
      "actual_text": "The detailed route remains `leaving-australia-tax-residency-cgt`; current legislation now supplies readable primary support. CGT event I1 happens when a person ceases to be an Australian resident. The specified pre-CGT and temporary-resident exclusions must be applied. I1 excludes the taxable-Australian-property items 1 and 3 in 855-15 and their linked item4 rights; it can still cover an indirect Australian real-property interest. The individual may choose to disregard all covered I1 capital gains/losses, but covered assets are then treated as taxable Australian property until their next CGT event or residence resumes; the choice is not permanent exemption. Division 855 defines taxable Australian property, while 768-915/995-1 govern the temporary-resident exception and definition. No Australian tax bill or automatic return cancellation is computed here. [ITAA 1997 104-160/104-165/855-15/768-915/995-1](https://www.legislation.gov.au/C2004A05138/latest/text). Refer valuation, election and treaty interaction to an Australian practitioner.",
      "line": 221
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/res-au-law.txt",
  "source_provenance": "Same writer own actual16November residence-source reading reused for this candidate-specific scope, not another reader approval; precise source version remains binding.",
  "source_sha256": "f7cc8357901110c3994c86e446a96abdecef5e42fbd6620d340f39a3842372e2",
  "source_version_basis": "Compilation268 dated1October2026"
}
```

### AU-TAP-CATEGORIES

The five TAP categories include direct property, qualifying indirect property, specified PE business assets, linked rights/options and prior I1choice assets. I1does not exclude every TAP category.

```json
{
  "act_article_or_scope": "ITAA1997 s855-15 all5items and notes,855-16",
  "actual_read_on": "2026-11-16",
  "id": "AU-TAP-CATEGORIES",
  "official_url": "https://www.legislation.gov.au/C2004A05138/2026-10-01/2026-10-01/text/original/epub/OEBPS/document_9/document_9.html",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "sections": [
    {
      "actual_text": "The detailed route remains `leaving-australia-tax-residency-cgt`; current legislation now supplies readable primary support. CGT event I1 happens when a person ceases to be an Australian resident. The specified pre-CGT and temporary-resident exclusions must be applied. I1 excludes the taxable-Australian-property items 1 and 3 in 855-15 and their linked item4 rights; it can still cover an indirect Australian real-property interest. The individual may choose to disregard all covered I1 capital gains/losses, but covered assets are then treated as taxable Australian property until their next CGT event or residence resumes; the choice is not permanent exemption. Division 855 defines taxable Australian property, while 768-915/995-1 govern the temporary-resident exception and definition. No Australian tax bill or automatic return cancellation is computed here. [ITAA 1997 104-160/104-165/855-15/768-915/995-1](https://www.legislation.gov.au/C2004A05138/latest/text). Refer valuation, election and treaty interaction to an Australian practitioner.",
      "line": 221
    }
  ],
  "short_exact_native_quotes": [
    "855‑15 When an asset is taxable Australian property There are 5 categories of *CGT assets that are taxable Australian property. They are set out in"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/au-itaa1997-v9.txt",
  "source_provenance": "Same writer own actual16November residence-source reading reused for this candidate-specific scope, not another reader approval; precise source version remains binding.",
  "source_sha256": "0cc93983f65719a57e8af837ed93b49381184c1823da1d0c0c790613f3760f60",
  "source_version_basis": "Compilation268 dated1October2026; entire assignedtable/notes nativebody"
}
```

### AU-TEMP-RESIDENT-CGT

Temporary-resident CGT disregard depends on hypothetical foreign-resident treatment, with an explicit I1exception for qualifying start-up ESS rights and shares.

```json
{
  "act_article_or_scope": "ITAA1997 s768-915(1)–(2)",
  "actual_read_on": "2026-11-16",
  "id": "AU-TEMP-RESIDENT-CGT",
  "official_url": "https://www.legislation.gov.au/C2004A05138/2026-10-01/2026-10-01/text/original/epub/OEBPS/document_9/document_9.html",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "sections": [
    {
      "actual_text": "The detailed route remains `leaving-australia-tax-residency-cgt`; current legislation now supplies readable primary support. CGT event I1 happens when a person ceases to be an Australian resident. The specified pre-CGT and temporary-resident exclusions must be applied. I1 excludes the taxable-Australian-property items 1 and 3 in 855-15 and their linked item4 rights; it can still cover an indirect Australian real-property interest. The individual may choose to disregard all covered I1 capital gains/losses, but covered assets are then treated as taxable Australian property until their next CGT event or residence resumes; the choice is not permanent exemption. Division 855 defines taxable Australian property, while 768-915/995-1 govern the temporary-resident exception and definition. No Australian tax bill or automatic return cancellation is computed here. [ITAA 1997 104-160/104-165/855-15/768-915/995-1](https://www.legislation.gov.au/C2004A05138/latest/text). Refer valuation, election and treaty interaction to an Australian practitioner.",
      "line": 221
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/au-itaa1997-v9.txt",
  "source_provenance": "Same writer own actual16November residence-source reading reused for this candidate-specific scope, not another reader approval; precise source version remains binding.",
  "source_sha256": "0cc93983f65719a57e8af837ed93b49381184c1823da1d0c0c790613f3760f60",
  "source_version_basis": "Compilation268 dated1October2026"
}
```

### AU-TEMP-RESIDENT-DEFINITION

Temporary tax residence requires the visa and claimant/spouse social-security-residence conditions, subject to the historical qualification-loss exclusion. A visa label alone is insufficient.

```json
{
  "act_article_or_scope": "ITAA1997 s995-1 temporary resident definition and exclusion",
  "actual_read_on": "2026-11-16",
  "id": "AU-TEMP-RESIDENT-DEFINITION",
  "official_url": "https://www.legislation.gov.au/C2004A05138/2026-10-01/2026-10-01/text/original/epub/OEBPS/document_10/document_10.html",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "sections": [
    {
      "actual_text": "The detailed route remains `leaving-australia-tax-residency-cgt`; current legislation now supplies readable primary support. CGT event I1 happens when a person ceases to be an Australian resident. The specified pre-CGT and temporary-resident exclusions must be applied. I1 excludes the taxable-Australian-property items 1 and 3 in 855-15 and their linked item4 rights; it can still cover an indirect Australian real-property interest. The individual may choose to disregard all covered I1 capital gains/losses, but covered assets are then treated as taxable Australian property until their next CGT event or residence resumes; the choice is not permanent exemption. Division 855 defines taxable Australian property, while 768-915/995-1 govern the temporary-resident exception and definition. No Australian tax bill or automatic return cancellation is computed here. [ITAA 1997 104-160/104-165/855-15/768-915/995-1](https://www.legislation.gov.au/C2004A05138/latest/text). Refer valuation, election and treaty interaction to an Australian practitioner.",
      "line": 221
    }
  ],
  "short_exact_native_quotes": [
    "temporary resident: you are a temporary resident if: (a) you hold a temporary visa granted under the Migration Act 1958; and (b) you are not"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/au-itaa1997-v10.txt",
  "source_provenance": "Same writer own actual16November residence-source reading reused for this candidate-specific scope, not another reader approval; precise source version remains binding.",
  "source_sha256": "b8c7c388f0d9e051458a3a3ab2726048fbe508f8fb4c803a099766c7cf5de3bd",
  "source_version_basis": "Compilation268 dated1October2026"
}
```

### US-EXPAT-COVERED-GATES

Covered gates include5yearaveragetax indexed amount, networthatleast2million OR5yearcompliancecertification failure; apply877Aexceptions and applicable index separately.

```json
{
  "act_article_or_scope": "IRC877(a)(2), cross-reference by877A(g)(1)",
  "actual_read_on": "2026-11-16",
  "id": "US-EXPAT-COVERED-GATES",
  "official_url": "https://uscode.house.gov/us/usc/t26/s877/",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "sections": [
    {
      "actual_text": "The expatriation tax provisions of sections 877 and 877A of the Internal Revenue Code apply to US citizens who relinquish citizenship under the statutory event rules (including renunciation) and to long-term residents who have ended their US resident status for federal tax purposes. For expatriation on or after June 17, 2008, a person is a covered expatriate if any one of three tests is met: an average annual net income tax test, a net worth test, or a failure to certify five years of tax compliance on Form 8854 ([IRS, expatriation tax](https://www.irs.gov/individuals/international-taxpayers/expatriation-tax)). The amounts, the deemed sale and the deferral are in `us-expatriation-exit-tax`. Citizens who move abroad but keep citizenship are not expatriating; see `us-citizen-moving-abroad-tax`.",
      "line": 225
    }
  ],
  "short_exact_native_quotes": [
    "(2) Individuals subject to this section This section shall apply to any individual if⁠— (A) the average annual net income tax (as defined in section"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/us-code877.txt",
  "source_provenance": "Same writer own actual16November residence-source reading reused for this candidate-specific scope, not another reader approval; precise source version remains binding.",
  "source_sha256": "0738cfe86bc89be33959367900d46b0787d57b1466f37fae837e65c836a9da1b",
  "source_version_basis": "Actual Code throughPL119-142/10November2026, own operative/neighbour read."
}
```

### US-EXPAT-EVENT-DEFINITIONS

Actual relinquishment or longtermLPRcessation determines expatriate/date, including formal approval conditions; an ordinary move alone is insufficient.

```json
{
  "act_article_or_scope": "IRC877A(g)(2)–(5)",
  "actual_read_on": "2026-11-16",
  "id": "US-EXPAT-EVENT-DEFINITIONS",
  "official_url": "https://uscode.house.gov/us/usc/t26/s877A/",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "sections": [
    {
      "actual_text": "The expatriation tax provisions of sections 877 and 877A of the Internal Revenue Code apply to US citizens who relinquish citizenship under the statutory event rules (including renunciation) and to long-term residents who have ended their US resident status for federal tax purposes. For expatriation on or after June 17, 2008, a person is a covered expatriate if any one of three tests is met: an average annual net income tax test, a net worth test, or a failure to certify five years of tax compliance on Form 8854 ([IRS, expatriation tax](https://www.irs.gov/individuals/international-taxpayers/expatriation-tax)). The amounts, the deemed sale and the deferral are in `us-expatriation-exit-tax`. Citizens who move abroad but keep citizenship are not expatriating; see `us-citizen-moving-abroad-tax`.",
      "line": 225
    }
  ],
  "short_exact_native_quotes": [
    "(2) Expatriate The term “expatriate” means⁠— (A) any United States citizen who relinquishes his citizenship, and (B) any long-term resident of the United States who"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/us-code877A.txt",
  "source_provenance": "Same writer own actual16November residence-source reading reused for this candidate-specific scope, not another reader approval; precise source version remains binding.",
  "source_sha256": "50501bef0a8da910c45355ed2b37aa28c282d2f6a0014a34e04fec8df0803ac6",
  "source_version_basis": "Current Code personally read."
}
```

### US-EXPAT-LPR-8OF15

Longtermresident generallyLPRin8of15taxyears, with specified foreign-treaty-resident nonwaiveryears excluded.

```json
{
  "act_article_or_scope": "IRC877(e)(2) complete",
  "actual_read_on": "2026-11-16",
  "id": "US-EXPAT-LPR-8OF15",
  "official_url": "https://uscode.house.gov/us/usc/t26/s877/",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "sections": [
    {
      "actual_text": "The expatriation tax provisions of sections 877 and 877A of the Internal Revenue Code apply to US citizens who relinquish citizenship under the statutory event rules (including renunciation) and to long-term residents who have ended their US resident status for federal tax purposes. For expatriation on or after June 17, 2008, a person is a covered expatriate if any one of three tests is met: an average annual net income tax test, a net worth test, or a failure to certify five years of tax compliance on Form 8854 ([IRS, expatriation tax](https://www.irs.gov/individuals/international-taxpayers/expatriation-tax)). The amounts, the deemed sale and the deferral are in `us-expatriation-exit-tax`. Citizens who move abroad but keep citizenship are not expatriating; see `us-citizen-moving-abroad-tax`.",
      "line": 225
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/us-code877.txt",
  "source_provenance": "Same writer own actual16November residence-source reading reused for this candidate-specific scope, not another reader approval; precise source version remains binding.",
  "source_sha256": "0738cfe86bc89be33959367900d46b0787d57b1466f37fae837e65c836a9da1b",
  "source_version_basis": "Current Code personally read; no invented full-calendar-year daycount."
}
```

### UK-SCH45-109

Actual statutory temporary-nonresidence definition and linked period/soleUKresidence/year/return condition, paragraph109.

```json
{
  "act_article_or_scope": "FA2013Schedule45paragraph109 whole",
  "actual_read_on": "2026-11-16",
  "id": "UK-SCH45-109",
  "official_url": "https://www.legislation.gov.uk/ukpga/2013/29/schedule/45/part/4/data.xht?wrap=true",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "No UK charge on the unrealised gains of an individual who leaves is printed on the HMRC page linked in this section. The rule HMRC sets out for departures is temporary non-residence: a person who returns may pay tax in the year of return on certain income and gains received during the absence ([HMRC RDR3, section 7](https://www.gov.uk/government/publications/rdr3-statutory-residence-test-srt/guidance-note-for-statutory-residence-test-srt-rdr3)). A person is temporarily non-resident if, after a residence period with sole UK residence, they have one or more residence periods without sole UK residence; AND in 4 or more of the 7 tax years before the year of departure they had sole UK residence for the tax year, or the year was a split year with a residence period of sole UK residence; AND the period of non-residence lasts 5 years or less. The statutory period is defined using the end of the preceding sole-UK-residence period and the start of the next one; raw travel dates alone are insufficient. HMRC’s dated example leaves on 4 May 2015 and returns on 4 May 2020 and says the rules do not apply. Preserve that illustration in its stated residence facts; those calendar dates are 1,827 days apart and do not themselves prove a universal “5 years plus 1 day” safe harbour. [FA 2013 Schedule 45 paragraphs 109–115](https://www.legislation.gov.uk/ukpga/2013/29/schedule/45/part/4/data.xht?wrap=true). Capital gains are among the items in scope. Current TCGA 1M/1N govern the gains rule and the conditional new-assets exclusion; old sections 10A/10AA are repealed. The current 2026–27 amendment separates specified carried-interest amounts, so this is not an all-income rule. Trust and company charges remain outside this Guide. [Current 1M](https://www.legislation.gov.uk/ukpga/1992/12/section/1M/data.xht); [1N](https://www.legislation.gov.uk/ukpga/1992/12/section/1N/data.xht).",
      "line": 229
    }
  ],
  "short_exact_native_quotes": [
    "109U.K.This Part of this Schedule— (a)explains when an individual is to be regarded for the purposes of certain enactments as temporarily non-resident, (b)defines the year"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/uk-fa2013sch45part4.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "acc2170c03cbd29e4a4250a8c4d4732b76a6422dc128ee2ac790e8aed694610b",
  "source_version_basis": "Current actual legislation body; whole109–115plus116opening read."
}
```

### UK-SCH45-110

Actual statutory temporary-nonresidence definition and linked period/soleUKresidence/year/return condition, paragraph110.

```json
{
  "act_article_or_scope": "FA2013Schedule45paragraph110 whole",
  "actual_read_on": "2026-11-16",
  "id": "UK-SCH45-110",
  "official_url": "https://www.legislation.gov.uk/ukpga/2013/29/schedule/45/part/4/data.xht?wrap=true",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "No UK charge on the unrealised gains of an individual who leaves is printed on the HMRC page linked in this section. The rule HMRC sets out for departures is temporary non-residence: a person who returns may pay tax in the year of return on certain income and gains received during the absence ([HMRC RDR3, section 7](https://www.gov.uk/government/publications/rdr3-statutory-residence-test-srt/guidance-note-for-statutory-residence-test-srt-rdr3)). A person is temporarily non-resident if, after a residence period with sole UK residence, they have one or more residence periods without sole UK residence; AND in 4 or more of the 7 tax years before the year of departure they had sole UK residence for the tax year, or the year was a split year with a residence period of sole UK residence; AND the period of non-residence lasts 5 years or less. The statutory period is defined using the end of the preceding sole-UK-residence period and the start of the next one; raw travel dates alone are insufficient. HMRC’s dated example leaves on 4 May 2015 and returns on 4 May 2020 and says the rules do not apply. Preserve that illustration in its stated residence facts; those calendar dates are 1,827 days apart and do not themselves prove a universal “5 years plus 1 day” safe harbour. [FA 2013 Schedule 45 paragraphs 109–115](https://www.legislation.gov.uk/ukpga/2013/29/schedule/45/part/4/data.xht?wrap=true). Capital gains are among the items in scope. Current TCGA 1M/1N govern the gains rule and the conditional new-assets exclusion; old sections 10A/10AA are repealed. The current 2026–27 amendment separates specified carried-interest amounts, so this is not an all-income rule. Trust and company charges remain outside this Guide. [Current 1M](https://www.legislation.gov.uk/ukpga/1992/12/section/1M/data.xht); [1N](https://www.legislation.gov.uk/ukpga/1992/12/section/1N/data.xht).",
      "line": 229
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/uk-fa2013sch45part4.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "acc2170c03cbd29e4a4250a8c4d4732b76a6422dc128ee2ac790e8aed694610b",
  "source_version_basis": "Current actual legislation body; whole109–115plus116opening read."
}
```

### UK-SCH45-111

Actual statutory temporary-nonresidence definition and linked period/soleUKresidence/year/return condition, paragraph111.

```json
{
  "act_article_or_scope": "FA2013Schedule45paragraph111 whole",
  "actual_read_on": "2026-11-16",
  "id": "UK-SCH45-111",
  "official_url": "https://www.legislation.gov.uk/ukpga/2013/29/schedule/45/part/4/data.xht?wrap=true",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "No UK charge on the unrealised gains of an individual who leaves is printed on the HMRC page linked in this section. The rule HMRC sets out for departures is temporary non-residence: a person who returns may pay tax in the year of return on certain income and gains received during the absence ([HMRC RDR3, section 7](https://www.gov.uk/government/publications/rdr3-statutory-residence-test-srt/guidance-note-for-statutory-residence-test-srt-rdr3)). A person is temporarily non-resident if, after a residence period with sole UK residence, they have one or more residence periods without sole UK residence; AND in 4 or more of the 7 tax years before the year of departure they had sole UK residence for the tax year, or the year was a split year with a residence period of sole UK residence; AND the period of non-residence lasts 5 years or less. The statutory period is defined using the end of the preceding sole-UK-residence period and the start of the next one; raw travel dates alone are insufficient. HMRC’s dated example leaves on 4 May 2015 and returns on 4 May 2020 and says the rules do not apply. Preserve that illustration in its stated residence facts; those calendar dates are 1,827 days apart and do not themselves prove a universal “5 years plus 1 day” safe harbour. [FA 2013 Schedule 45 paragraphs 109–115](https://www.legislation.gov.uk/ukpga/2013/29/schedule/45/part/4/data.xht?wrap=true). Capital gains are among the items in scope. Current TCGA 1M/1N govern the gains rule and the conditional new-assets exclusion; old sections 10A/10AA are repealed. The current 2026–27 amendment separates specified carried-interest amounts, so this is not an all-income rule. Trust and company charges remain outside this Guide. [Current 1M](https://www.legislation.gov.uk/ukpga/1992/12/section/1M/data.xht); [1N](https://www.legislation.gov.uk/ukpga/1992/12/section/1N/data.xht).",
      "line": 229
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/uk-fa2013sch45part4.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "acc2170c03cbd29e4a4250a8c4d4732b76a6422dc128ee2ac790e8aed694610b",
  "source_version_basis": "Current actual legislation body; whole109–115plus116opening read."
}
```

### UK-SCH45-112

Actual statutory temporary-nonresidence definition and linked period/soleUKresidence/year/return condition, paragraph112.

```json
{
  "act_article_or_scope": "FA2013Schedule45paragraph112 whole",
  "actual_read_on": "2026-11-16",
  "id": "UK-SCH45-112",
  "official_url": "https://www.legislation.gov.uk/ukpga/2013/29/schedule/45/part/4/data.xht?wrap=true",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "No UK charge on the unrealised gains of an individual who leaves is printed on the HMRC page linked in this section. The rule HMRC sets out for departures is temporary non-residence: a person who returns may pay tax in the year of return on certain income and gains received during the absence ([HMRC RDR3, section 7](https://www.gov.uk/government/publications/rdr3-statutory-residence-test-srt/guidance-note-for-statutory-residence-test-srt-rdr3)). A person is temporarily non-resident if, after a residence period with sole UK residence, they have one or more residence periods without sole UK residence; AND in 4 or more of the 7 tax years before the year of departure they had sole UK residence for the tax year, or the year was a split year with a residence period of sole UK residence; AND the period of non-residence lasts 5 years or less. The statutory period is defined using the end of the preceding sole-UK-residence period and the start of the next one; raw travel dates alone are insufficient. HMRC’s dated example leaves on 4 May 2015 and returns on 4 May 2020 and says the rules do not apply. Preserve that illustration in its stated residence facts; those calendar dates are 1,827 days apart and do not themselves prove a universal “5 years plus 1 day” safe harbour. [FA 2013 Schedule 45 paragraphs 109–115](https://www.legislation.gov.uk/ukpga/2013/29/schedule/45/part/4/data.xht?wrap=true). Capital gains are among the items in scope. Current TCGA 1M/1N govern the gains rule and the conditional new-assets exclusion; old sections 10A/10AA are repealed. The current 2026–27 amendment separates specified carried-interest amounts, so this is not an all-income rule. Trust and company charges remain outside this Guide. [Current 1M](https://www.legislation.gov.uk/ukpga/1992/12/section/1M/data.xht); [1N](https://www.legislation.gov.uk/ukpga/1992/12/section/1N/data.xht).",
      "line": 229
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/uk-fa2013sch45part4.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "acc2170c03cbd29e4a4250a8c4d4732b76a6422dc128ee2ac790e8aed694610b",
  "source_version_basis": "Current actual legislation body; whole109–115plus116opening read."
}
```

### UK-SCH45-113

Actual statutory temporary-nonresidence definition and linked period/soleUKresidence/year/return condition, paragraph113.

```json
{
  "act_article_or_scope": "FA2013Schedule45paragraph113 whole",
  "actual_read_on": "2026-11-16",
  "id": "UK-SCH45-113",
  "official_url": "https://www.legislation.gov.uk/ukpga/2013/29/schedule/45/part/4/data.xht?wrap=true",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "No UK charge on the unrealised gains of an individual who leaves is printed on the HMRC page linked in this section. The rule HMRC sets out for departures is temporary non-residence: a person who returns may pay tax in the year of return on certain income and gains received during the absence ([HMRC RDR3, section 7](https://www.gov.uk/government/publications/rdr3-statutory-residence-test-srt/guidance-note-for-statutory-residence-test-srt-rdr3)). A person is temporarily non-resident if, after a residence period with sole UK residence, they have one or more residence periods without sole UK residence; AND in 4 or more of the 7 tax years before the year of departure they had sole UK residence for the tax year, or the year was a split year with a residence period of sole UK residence; AND the period of non-residence lasts 5 years or less. The statutory period is defined using the end of the preceding sole-UK-residence period and the start of the next one; raw travel dates alone are insufficient. HMRC’s dated example leaves on 4 May 2015 and returns on 4 May 2020 and says the rules do not apply. Preserve that illustration in its stated residence facts; those calendar dates are 1,827 days apart and do not themselves prove a universal “5 years plus 1 day” safe harbour. [FA 2013 Schedule 45 paragraphs 109–115](https://www.legislation.gov.uk/ukpga/2013/29/schedule/45/part/4/data.xht?wrap=true). Capital gains are among the items in scope. Current TCGA 1M/1N govern the gains rule and the conditional new-assets exclusion; old sections 10A/10AA are repealed. The current 2026–27 amendment separates specified carried-interest amounts, so this is not an all-income rule. Trust and company charges remain outside this Guide. [Current 1M](https://www.legislation.gov.uk/ukpga/1992/12/section/1M/data.xht); [1N](https://www.legislation.gov.uk/ukpga/1992/12/section/1N/data.xht).",
      "line": 229
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/uk-fa2013sch45part4.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "acc2170c03cbd29e4a4250a8c4d4732b76a6422dc128ee2ac790e8aed694610b",
  "source_version_basis": "Current actual legislation body; whole109–115plus116opening read."
}
```

### UK-SCH45-114

Actual statutory temporary-nonresidence definition and linked period/soleUKresidence/year/return condition, paragraph114.

```json
{
  "act_article_or_scope": "FA2013Schedule45paragraph114 whole",
  "actual_read_on": "2026-11-16",
  "id": "UK-SCH45-114",
  "official_url": "https://www.legislation.gov.uk/ukpga/2013/29/schedule/45/part/4/data.xht?wrap=true",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "No UK charge on the unrealised gains of an individual who leaves is printed on the HMRC page linked in this section. The rule HMRC sets out for departures is temporary non-residence: a person who returns may pay tax in the year of return on certain income and gains received during the absence ([HMRC RDR3, section 7](https://www.gov.uk/government/publications/rdr3-statutory-residence-test-srt/guidance-note-for-statutory-residence-test-srt-rdr3)). A person is temporarily non-resident if, after a residence period with sole UK residence, they have one or more residence periods without sole UK residence; AND in 4 or more of the 7 tax years before the year of departure they had sole UK residence for the tax year, or the year was a split year with a residence period of sole UK residence; AND the period of non-residence lasts 5 years or less. The statutory period is defined using the end of the preceding sole-UK-residence period and the start of the next one; raw travel dates alone are insufficient. HMRC’s dated example leaves on 4 May 2015 and returns on 4 May 2020 and says the rules do not apply. Preserve that illustration in its stated residence facts; those calendar dates are 1,827 days apart and do not themselves prove a universal “5 years plus 1 day” safe harbour. [FA 2013 Schedule 45 paragraphs 109–115](https://www.legislation.gov.uk/ukpga/2013/29/schedule/45/part/4/data.xht?wrap=true). Capital gains are among the items in scope. Current TCGA 1M/1N govern the gains rule and the conditional new-assets exclusion; old sections 10A/10AA are repealed. The current 2026–27 amendment separates specified carried-interest amounts, so this is not an all-income rule. Trust and company charges remain outside this Guide. [Current 1M](https://www.legislation.gov.uk/ukpga/1992/12/section/1M/data.xht); [1N](https://www.legislation.gov.uk/ukpga/1992/12/section/1N/data.xht).",
      "line": 229
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/uk-fa2013sch45part4.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "acc2170c03cbd29e4a4250a8c4d4732b76a6422dc128ee2ac790e8aed694610b",
  "source_version_basis": "Current actual legislation body; whole109–115plus116opening read."
}
```

### UK-SCH45-115

Actual statutory temporary-nonresidence definition and linked period/soleUKresidence/year/return condition, paragraph115.

```json
{
  "act_article_or_scope": "FA2013Schedule45paragraph115 whole",
  "actual_read_on": "2026-11-16",
  "id": "UK-SCH45-115",
  "official_url": "https://www.legislation.gov.uk/ukpga/2013/29/schedule/45/part/4/data.xht?wrap=true",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "No UK charge on the unrealised gains of an individual who leaves is printed on the HMRC page linked in this section. The rule HMRC sets out for departures is temporary non-residence: a person who returns may pay tax in the year of return on certain income and gains received during the absence ([HMRC RDR3, section 7](https://www.gov.uk/government/publications/rdr3-statutory-residence-test-srt/guidance-note-for-statutory-residence-test-srt-rdr3)). A person is temporarily non-resident if, after a residence period with sole UK residence, they have one or more residence periods without sole UK residence; AND in 4 or more of the 7 tax years before the year of departure they had sole UK residence for the tax year, or the year was a split year with a residence period of sole UK residence; AND the period of non-residence lasts 5 years or less. The statutory period is defined using the end of the preceding sole-UK-residence period and the start of the next one; raw travel dates alone are insufficient. HMRC’s dated example leaves on 4 May 2015 and returns on 4 May 2020 and says the rules do not apply. Preserve that illustration in its stated residence facts; those calendar dates are 1,827 days apart and do not themselves prove a universal “5 years plus 1 day” safe harbour. [FA 2013 Schedule 45 paragraphs 109–115](https://www.legislation.gov.uk/ukpga/2013/29/schedule/45/part/4/data.xht?wrap=true). Capital gains are among the items in scope. Current TCGA 1M/1N govern the gains rule and the conditional new-assets exclusion; old sections 10A/10AA are repealed. The current 2026–27 amendment separates specified carried-interest amounts, so this is not an all-income rule. Trust and company charges remain outside this Guide. [Current 1M](https://www.legislation.gov.uk/ukpga/1992/12/section/1M/data.xht); [1N](https://www.legislation.gov.uk/ukpga/1992/12/section/1N/data.xht).",
      "line": 229
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/uk-fa2013sch45part4.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "acc2170c03cbd29e4a4250a8c4d4732b76a6422dc128ee2ac790e8aed694610b",
  "source_version_basis": "Current actual legislation body; whole109–115plus116opening read."
}
```

### UK-TCGA1M

Current gains rule and conditional newly acquired-assets exclusion; actual2026carried-interest amendment and exclusions apply.

```json
{
  "act_article_or_scope": "TCGA1M actual operative body/adjacent amendment notes",
  "actual_read_on": "2026-11-16",
  "id": "UK-TCGA1M",
  "official_url": "https://www.legislation.gov.uk/ukpga/1992/12/section/1M/data.xht",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "No UK charge on the unrealised gains of an individual who leaves is printed on the HMRC page linked in this section. The rule HMRC sets out for departures is temporary non-residence: a person who returns may pay tax in the year of return on certain income and gains received during the absence ([HMRC RDR3, section 7](https://www.gov.uk/government/publications/rdr3-statutory-residence-test-srt/guidance-note-for-statutory-residence-test-srt-rdr3)). A person is temporarily non-resident if, after a residence period with sole UK residence, they have one or more residence periods without sole UK residence; AND in 4 or more of the 7 tax years before the year of departure they had sole UK residence for the tax year, or the year was a split year with a residence period of sole UK residence; AND the period of non-residence lasts 5 years or less. The statutory period is defined using the end of the preceding sole-UK-residence period and the start of the next one; raw travel dates alone are insufficient. HMRC’s dated example leaves on 4 May 2015 and returns on 4 May 2020 and says the rules do not apply. Preserve that illustration in its stated residence facts; those calendar dates are 1,827 days apart and do not themselves prove a universal “5 years plus 1 day” safe harbour. [FA 2013 Schedule 45 paragraphs 109–115](https://www.legislation.gov.uk/ukpga/2013/29/schedule/45/part/4/data.xht?wrap=true). Capital gains are among the items in scope. Current TCGA 1M/1N govern the gains rule and the conditional new-assets exclusion; old sections 10A/10AA are repealed. The current 2026–27 amendment separates specified carried-interest amounts, so this is not an all-income rule. Trust and company charges remain outside this Guide. [Current 1M](https://www.legislation.gov.uk/ukpga/1992/12/section/1M/data.xht); [1N](https://www.legislation.gov.uk/ukpga/1992/12/section/1N/data.xht).",
      "line": 229
    }
  ],
  "short_exact_native_quotes": [
    "Temporary periods of non-residenceU.K.1MTemporary non-residentsU.K. (1)If, in the case of the disposal of an asset by an individual who is temporarily non-resident— (a)a gain or"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/uk-tcga1m.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "994bf96c056d01fee5cbb0391bf5a5dd6fd0dd7bccd6550335b09c3b238ad287",
  "source_version_basis": "Current actual statutory body personally read with2026–27amendment note; not repealed10A/10AA."
}
```

### UK-TCGA1N

Current gains rule and conditional newly acquired-assets exclusion; actual2026carried-interest amendment and exclusions apply.

```json
{
  "act_article_or_scope": "TCGA1N actual operative body/adjacent amendment notes",
  "actual_read_on": "2026-11-16",
  "id": "UK-TCGA1N",
  "official_url": "https://www.legislation.gov.uk/ukpga/1992/12/section/1N/data.xht",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "No UK charge on the unrealised gains of an individual who leaves is printed on the HMRC page linked in this section. The rule HMRC sets out for departures is temporary non-residence: a person who returns may pay tax in the year of return on certain income and gains received during the absence ([HMRC RDR3, section 7](https://www.gov.uk/government/publications/rdr3-statutory-residence-test-srt/guidance-note-for-statutory-residence-test-srt-rdr3)). A person is temporarily non-resident if, after a residence period with sole UK residence, they have one or more residence periods without sole UK residence; AND in 4 or more of the 7 tax years before the year of departure they had sole UK residence for the tax year, or the year was a split year with a residence period of sole UK residence; AND the period of non-residence lasts 5 years or less. The statutory period is defined using the end of the preceding sole-UK-residence period and the start of the next one; raw travel dates alone are insufficient. HMRC’s dated example leaves on 4 May 2015 and returns on 4 May 2020 and says the rules do not apply. Preserve that illustration in its stated residence facts; those calendar dates are 1,827 days apart and do not themselves prove a universal “5 years plus 1 day” safe harbour. [FA 2013 Schedule 45 paragraphs 109–115](https://www.legislation.gov.uk/ukpga/2013/29/schedule/45/part/4/data.xht?wrap=true). Capital gains are among the items in scope. Current TCGA 1M/1N govern the gains rule and the conditional new-assets exclusion; old sections 10A/10AA are repealed. The current 2026–27 amendment separates specified carried-interest amounts, so this is not an all-income rule. Trust and company charges remain outside this Guide. [Current 1M](https://www.legislation.gov.uk/ukpga/1992/12/section/1M/data.xht); [1N](https://www.legislation.gov.uk/ukpga/1992/12/section/1N/data.xht).",
      "line": 229
    }
  ],
  "short_exact_native_quotes": [
    "Temporary periods of non-residenceU.K.1NSection 1M(1): assets acquired in temporary period of non-residenceU.K. (1)An asset is excluded from section 1M(1) if— (a)it was acquired by the"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/uk-tcga1n.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "afdbdbeed640e2c4b9dc7c2a12a0c8e3741482fad539e38a013e74ad7cd476ab",
  "source_version_basis": "Current actual statutory body personally read with2026–27amendment note; not repealed10A/10AA."
}
```

### NO-AUTHORITY-HISTORY

Dated2022/2023/2024/2025transitions qualify the current20March2024onward scope.

```json
{
  "act_article_or_scope": "Current actual page history/date sections, whole operative0–308 plus actualtail300–413 read.",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": [
    "The authority separates moves before/after20March2024; earlier departures on/before28November2022 have the conditional5year lapse. Transfers widened from3December2023; distribution repayment from7October2024 and Norwegian-estate distributions from1January2025 have their distinct dates. No old5yearlapse is applied to current departures."
  ],
  "id": "NO-AUTHORITY-HISTORY",
  "official_url": "https://www.skatteetaten.no/en/person/to-from-norway/from/tax-when-you-move-abroad/exit-tax/",
  "quote_mode": "Permitted total short extracts with exact operative locators and complete own condition paraphrase. Strict full-native-clause reproduction is not claimed.",
  "sections": [
    {
      "actual_text": "Which rules apply depends on the date of the move. The page splits moves on or before 19 March 2024 from moves on or after 20 March 2024, with further changes from 7 October 2024 and 1 January 2025. This section states the rules for moves on or after 20 March 2024. For a move on or before 28 November 2022, the conditional liability lasted five years and then lapsed.",
      "line": 145
    }
  ],
  "short_exact_native_quotes": [
    "28 November 2022"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/no-authority-exit-actual-web.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "8f21664ec9d8df27b3464ad30a124a40d09ffe65afb40e1b30edb6cba79a9160",
  "source_version_basis": "Actual2026currentEnglish authority body, read16November; legal statute/FSFIN win over simplified authority wording."
}
```

### NO-AUTHORITY-ACCOUNT-SCOPE

Svalbard/address/residence and foreign IRA/401(k) account classification require actual scope, not universal account-label treatment.

```json
{
  "act_article_or_scope": "Actual current page introductory residence and asset-list sections, read with fullstatute10-70(1)–(6).",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": [
    "Actual Norwegian residence under law and treaty precedes emigration/treatychange/Svalbard. Civil address registration is not decisive. Foreign pension schemes are within the described scope when treated as ordinary investment accounts; IRA/401(k) are named examples, not all pension exemptions or universal foreign-tax treatment."
  ],
  "id": "NO-AUTHORITY-ACCOUNT-SCOPE",
  "official_url": "https://www.skatteetaten.no/en/person/to-from-norway/from/tax-when-you-move-abroad/exit-tax/",
  "quote_mode": "Permitted total short extracts with exact operative locators and complete own condition paraphrase. Strict full-native-clause reproduction is not claimed.",
  "sections": [
    {
      "actual_text": "What is taxed. Latent gains on shares in Norwegian or foreign companies, units in securities funds, share savings accounts, investment fund accounts, employment options, interests in companies assessed as partnerships, financial instruments with such underlying assets, and assets in foreign pension savings schemes when considered a regular investment account (the page names IRAs and 401(k)s). Exit tax is calculated only on values accumulated while the person was tax resident in Norway. On a move there is a basic deduction, shown below; only the total gain or loss above it is subject to exit tax. On a move within the EEA or to Svalbard, gains and losses are netted before the deduction. On a move outside the EEA, only gains are added up; losses are not included. For gifts and other transfers, the NOK 100,000 net-gain threshold is an annual aggregate cliff, not a per-gift deduction: above it the whole net gain is caught. Coordinate transfers and an actual move in the same year under 10-70(4); do not double-use the move deduction. EEA loss relief also has later recapture/return conditions. [10-70(2)–(4)](https://lovdata.no/lov/1999-03-26-14/%C2%A710-70).",
      "line": 147
    }
  ],
  "short_exact_native_quotes": [
    "Svalbard"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/no-authority-exit-actual-web.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "8f21664ec9d8df27b3464ad30a124a40d09ffe65afb40e1b30edb6cba79a9160",
  "source_version_basis": "Actual2026currentEnglish authority body, read16November; legal statute/FSFIN win over simplified authority wording."
}
```

### NO-AUTHORITY-ASSESSMENT

Omitted exit information can produce authority assessment up to15years; not permission to omit.

```json
{
  "act_article_or_scope": "Actual current reporting/enforcement section with annualnotice/cure neighbours.",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": [
    "The authority states an extended up-to15year assessment period when required exit-tax information was not provided; the actual fact pattern and reporting duty remain material. This Guide does not claim a full tax-administration limitation-period opinion."
  ],
  "id": "NO-AUTHORITY-ASSESSMENT",
  "official_url": "https://www.skatteetaten.no/en/person/to-from-norway/from/tax-when-you-move-abroad/exit-tax/",
  "quote_mode": "Permitted total short extracts with exact operative locators and complete own condition paraphrase. Strict full-native-clause reproduction is not claimed.",
  "sections": [
    {
      "actual_text": "Reporting. Report for the day before residence changes: a change on 1 January 2025 belongs to the 2024 return. While postponement runs, answer the annual questionnaire by 30 April and notify qualifying disposal, transfer or move changes within 2 months. The regulation gives notice and at least 3 weeks to cure material reporting noncompliance before that ground ends postponement. The authority describes an assessment period up to 15 years where exit-tax information is missing; do not treat it as permission to omit reporting. [Current authority reporting/history](https://www.skatteetaten.no/en/person/to-from-norway/from/tax-when-you-move-abroad/exit-tax/); [14-25](https://lovdata.no/lov/1999-03-26-14/%C2%A714-25); [FSFIN](https://lovdata.no/forskrift/1999-11-19-1158/%C2%A710-70-1). For the corridor see `norway-to-switzerland-wealth-tax-exit`.",
      "line": 167
    }
  ],
  "short_exact_native_quotes": [
    "15 years"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/no-authority-exit-actual-web.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "8f21664ec9d8df27b3464ad30a124a40d09ffe65afb40e1b30edb6cba79a9160",
  "source_version_basis": "Actual2026currentEnglish authority body, read16November; legal statute/FSFIN win over simplified authority wording."
}
```

### NO-SHARE-RATE

2026share gains/dividends37.84%,other capital22%; no cross-asset universal rate.

```json
{
  "act_article_or_scope": "Actual whole104line share-rate page, operative current-year paragraph plus factor explanation",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": [
    "2026share gain/dividend rate is37.84%;other capital income22%;the share amount is derived from22%with1.72upward factor. Asset classification determines application; share rate does not automatically apply to every derivative/fund/account."
  ],
  "id": "NO-SHARE-RATE",
  "official_url": "https://www.skatteetaten.no/en/rates/factor-for-upward-adjustment-of-gainloss-or-dividend-on-shares/",
  "quote_mode": "Permitted total short extracts with exact operative locators and complete own condition paraphrase. Strict full-native-clause reproduction is not claimed.",
  "sections": [
    {
      "actual_text": "Rate. The tax authority's rate page prints the 2026 share-gain/dividend rate below. Other capital income has a different rate; do not apply the share rate indiscriminately to every fund, derivative or account component.",
      "line": 156
    }
  ],
  "short_exact_native_quotes": [
    "37.84 percent"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/no-share-rate-actual-web.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "cebc8487eb991acd0f4740dc5aef1e2bf390da3d8061519ee681b4ab8adc3309",
  "source_version_basis": "Actual2026named rate page personally read;22%times1.72share factor, no invented EUR/NOK conversion."
}
```

### FR-NOTICE-RATE

Default12.8%ordinary income-tax component and explicit18.6%general2026social component; high-income/overseas/historic cases separate.

```json
{
  "act_article_or_scope": "2026ETDnotice actualPDFp4/II, rendered and visually checked; pp1–9whole read, not all18pages.",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": [
    "Notice is2026vintage for2025departures. Its rate section expressly says the general social rate progresses to18.6%for2026; ordinary12.8%IR/global progressive election and special historical150-0Bter calculations are separate. Overseas-collectivity social rules differ."
  ],
  "id": "FR-NOTICE-RATE",
  "official_url": "https://www.impots.gouv.fr/sites/default/files/formulaires/2074-etd/2026/2074-etd_5518.pdf",
  "quote_mode": "Permitted total short extracts with exact operative locators and complete own condition paraphrase. Strict full-native-clause reproduction is not claimed.",
  "sections": [
    {
      "actual_text": "| Default income-tax component, ordinary flat-rate case | 12.8%; optional household-wide progressive treatment, with historical-rate exceptions for specified deferred gains | https://www.impots.gouv.fr/sites/default/files/formulaires/2074-etd/2026/2074-etd_5518.pdf |",
      "line": 103
    }
  ],
  "short_exact_native_quotes": [
    "12,8%"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/fr-etd-2026-notice.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "0b1143e7702f6da2af0f751c91de2c7667770fd4b7a25555c5ff9fc806bf1ef8",
  "source_version_basis": "Actual2026notice for2025events; bounded pp1–9read16November, not a whole18page claim."
}
```

### FR-NOTICE-DESTINATIONS

Dated list includes the named states but is not an immutable legal eligibility table.

```json
{
  "act_article_or_scope": "NoticeIIIactualPDFpp4–5 including full dated destination list; independently read withCGIIV–VI.",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": [
    "The notice’s list for transfers from2025includesUK/US/Australia/Norway/Monaco and does not listSwitzerland/UAE. Actual both-assistance/noncooperative statutory test and later agreements/status control on actual date. The list is dated corroboration, not universal treaty entitlement."
  ],
  "id": "FR-NOTICE-DESTINATIONS",
  "official_url": "https://www.impots.gouv.fr/sites/default/files/formulaires/2074-etd/2026/2074-etd_5518.pdf",
  "quote_mode": "Permitted total short extracts with exact operative locators and complete own condition paraphrase. Strict full-native-clause reproduction is not claimed.",
  "sections": [
    {
      "actual_text": "Suspension. IV grants automatic suspension for the EU or a destination with BOTH qualifying administrative and recovery assistance that is not noncooperative. The notice’s list for transfers from 2025 includes the UK, US, Australia, Norway and Monaco; it does not list Switzerland or the UAE. Test the current legal agreements and status for the actual destination/date rather than treating the dated list as immutable. V allows an express request for other destinations or a later onward move outside IV, with declaration, a representative in France and predeparture guarantees. It sets a 12.8%-of-gross provisional guarantee rule, a special historic-rate rule and possible adjustment within 1 month after the notice. No work-related security waiver is stated in this current V. [CGI IV–VI](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000048806379); [notice III, pp4–5](https://www.impots.gouv.fr/sites/default/files/formulaires/2074-etd/2026/2074-etd_5518.pdf).",
      "line": 109
    }
  ],
  "short_exact_native_quotes": [
    "Royaume-Uni"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/fr-etd-2026-notice.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "0b1143e7702f6da2af0f751c91de2c7667770fd4b7a25555c5ff9fc806bf1ef8",
  "source_version_basis": "Actual2026notice for2025events; bounded pp1–9read16November, not a whole18page claim."
}
```

### FR-NOTICE-FORMS

Initial paperETD/2042C timing and express-request90daysbefore plus next-year second filing; no final2027forms claim.

```json
{
  "act_article_or_scope": "NoticeV–IXactualPDFpp7–9, full operative/neighbours; p7rendered visual check. WholecurrentCGIIX–X separately read.",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": [
    "Ordinary initial filing is in year after departure. Notice uses paper2074-ETD with2042/2042C. Express suspension requires initialETDat least90daysbefore departure and another filing next year. Annual deferred/receivable/mixed and event-based retained latent cases differ; specified no-event cases can useETSL. Onward domicile changes2months and new suspension status must be checked. Applies only to its stated2025event/2026filing version; no2027calendar or final form is invented."
  ],
  "id": "FR-NOTICE-FORMS",
  "official_url": "https://www.impots.gouv.fr/sites/default/files/formulaires/2074-etd/2026/2074-etd_5518.pdf",
  "quote_mode": "Permitted total short extracts with exact operative locators and complete own condition paraphrase. Strict full-native-clause reproduction is not claimed.",
  "sections": [
    {
      "actual_text": "Forms and timing. IX normally requires the initial declaration in the year AFTER departure, within the income-return deadline. The 2026 notice for 2025 transfers uses paper 2074-ETD with 2042/2042 C; an express suspension request instead requires an initial ETD at least 90 days BEFORE departure and a second filing the next year. Follow-up since 2014 uses ETS3: latent-gains-only cases after 2018 are generally event-based; deferred gains/receivables and mixed cases retain annual reporting, with ETSL available in specified no-event cases. Subsequent changes of tax domicile must be notified within 2 months; the move may itself end automatic suspension. Do not invent a calendar deadline or a final 2027 form for a 2026 departure. [CGI IX–X](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000048806379); [ETD notice V–IX, pp7–9](https://www.impots.gouv.fr/sites/default/files/formulaires/2074-etd/2026/2074-etd_5518.pdf); [ETS3 notice I–III](https://www.impots.gouv.fr/sites/default/files/formulaires/2074-ets3/2026/2074-ets3_5526.pdf). The authority’s 2026 simulator labels 8TN for tax on gains in payment suspension; that confirms the old code only for its stated 2025-income version, not universal 2026-departure filing instructions. [Actual simulator field](https://simulateur-ir-ifi.impots.gouv.fr/calcul_impot/2026/complet/). For depth use `leaving-france-exit-tax`.",
      "line": 115
    }
  ],
  "short_exact_native_quotes": [
    "2074-ETD"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/fr-etd-2026-notice.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "0b1143e7702f6da2af0f751c91de2c7667770fd4b7a25555c5ff9fc806bf1ef8",
  "source_version_basis": "Actual2026notice for2025events; bounded pp1–9read16November, not a whole18page claim."
}
```

### FR-GENERAL-PFU

Default31.4%sum and global household2OPelection, not a selectable per-asset election.

```json
{
  "act_article_or_scope": "Actual authority operative347–420 plus updated2026-07-17 date; ordinary current PFU paragraph",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": [
    "Ordinary PFUtotal31.4%=12.8%income tax+18.6%social levies. Progressive choice is household-wide for the applicable capital income/gains and uses2OP; no high-income levy, allowance or special deferred-gain case is included in the founder illustration."
  ],
  "id": "FR-GENERAL-PFU",
  "official_url": "https://www.impots.gouv.fr/particulier/questions/jai-realise-une-plus-value-mobiliere-comment-est-elle-imposee",
  "quote_mode": "Permitted total short extracts with exact operative locators and complete own condition paraphrase. Strict full-native-clause reproduction is not claimed.",
  "sections": [
    {
      "actual_text": "| Ordinary flat-rate illustration total | 31.4% = 12.8% + 18.6%, excluding high-income contributions and special cases | https://www.impots.gouv.fr/particulier/questions/jai-realise-une-plus-value-mobiliere-comment-est-elle-imposee |",
      "line": 105
    }
  ],
  "short_exact_native_quotes": [
    "31,4 %"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/fr-capital-gain-current.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "9a8145db0729dc8840c4f5dc8cdbf2f8febd46afee0396c1969d78e87da85f28",
  "source_version_basis": "Actual authority page updated17July2026, read16November; exit-specific notice/statute separately bound."
}
```

### FR-ETS3-HISTORY

Historical scope preserved with date-specific retention/filing boundaries.

```json
{
  "act_article_or_scope": "Actual first4PDFpages and§430PDFp26; not all35pages.",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": [
    "Notice expressly covers2014–2025departures despite stale landing text2014–2020. Latent-gain retention is15years for2014–2018and2/5for2019onward under statutory conditions. §430relief/evidence and dates do not discharge every deferred gain/receivable."
  ],
  "id": "FR-ETS3-HISTORY",
  "official_url": "https://www.impots.gouv.fr/sites/default/files/formulaires/2074-ets3/2026/2074-ets3_5526.pdf",
  "quote_mode": "Permitted total short extracts with exact operative locators and complete own condition paraphrase. Strict full-native-clause reproduction is not claimed.",
  "sections": [
    {
      "actual_text": "Historic periods remain important: 2014–2018 departures have the 15-year latent-gain retention period; the historical 8-year period belongs to the 2011–2013 regime, not every departure before 2014. The ETS1 notice covers 3 March 2011–2012; ETS2 covers 2013. Relief still needs the appropriate evidence and follow-up, including the separately dated extension of social-levy relief. [ETS3 notice pp1–4/§430](https://www.impots.gouv.fr/sites/default/files/formulaires/2074-ets3/2026/2074-ets3_5526.pdf); [ETS1 notice p1](https://www.impots.gouv.fr/sites/default/files/formulaires/2074-ets1/2026/2074-ets1_5522.pdf); [ETS2 notice p1](https://www.impots.gouv.fr/sites/default/files/formulaires/2074-ets2/2026/2074-ets2_5524.pdf).",
      "line": 113
    }
  ],
  "short_exact_native_quotes": [
    "2014"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/fr-ets3-2026-notice.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "77691bc3557833ba9dd86afa43d2f593154fd6aa38af3de812c6ee162c5cff96",
  "source_version_basis": "Dated2026formnotice with the expressly identified older departure year; only stated scope read16November."
}
```

### FR-ETS1-HISTORY

Historical scope preserved with date-specific retention/filing boundaries.

```json
{
  "act_article_or_scope": "ActualPDFpp1–2andp3opening; not all24pages.",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": [
    "ETS1covers3March2011through2012departures. Historical8year retention periods expired2019/2020; separately dated2024social-levy relief and retained evidence/reporting remain material. This is not a general current8yearrule."
  ],
  "id": "FR-ETS1-HISTORY",
  "official_url": "https://www.impots.gouv.fr/sites/default/files/formulaires/2074-ets1/2026/2074-ets1_5522.pdf",
  "quote_mode": "Permitted total short extracts with exact operative locators and complete own condition paraphrase. Strict full-native-clause reproduction is not claimed.",
  "sections": [
    {
      "actual_text": "Historic periods remain important: 2014–2018 departures have the 15-year latent-gain retention period; the historical 8-year period belongs to the 2011–2013 regime, not every departure before 2014. The ETS1 notice covers 3 March 2011–2012; ETS2 covers 2013. Relief still needs the appropriate evidence and follow-up, including the separately dated extension of social-levy relief. [ETS3 notice pp1–4/§430](https://www.impots.gouv.fr/sites/default/files/formulaires/2074-ets3/2026/2074-ets3_5526.pdf); [ETS1 notice p1](https://www.impots.gouv.fr/sites/default/files/formulaires/2074-ets1/2026/2074-ets1_5522.pdf); [ETS2 notice p1](https://www.impots.gouv.fr/sites/default/files/formulaires/2074-ets2/2026/2074-ets2_5524.pdf).",
      "line": 113
    }
  ],
  "short_exact_native_quotes": [
    "2011"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/fr-ets1-2026-notice.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "2cb4f91bb557eb748322f98b2fe576b66d133501a8d9087518cbeda3fd196316",
  "source_version_basis": "Dated2026formnotice with the expressly identified older departure year; only stated scope read16November."
}
```

### FR-ETS2-HISTORY

Historical scope preserved with date-specific retention/filing boundaries.

```json
{
  "act_article_or_scope": "Actual first45extractedlines/firstpage only; not all30pages.",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": [
    "ETS2is for2013departures and2025follow-up filed2026. Historical8year latent period expired2021; specified relief still requires the appropriate declaration/evidence. It is not the new-departure manual."
  ],
  "id": "FR-ETS2-HISTORY",
  "official_url": "https://www.impots.gouv.fr/sites/default/files/formulaires/2074-ets2/2026/2074-ets2_5524.pdf",
  "quote_mode": "Permitted total short extracts with exact operative locators and complete own condition paraphrase. Strict full-native-clause reproduction is not claimed.",
  "sections": [
    {
      "actual_text": "Historic periods remain important: 2014–2018 departures have the 15-year latent-gain retention period; the historical 8-year period belongs to the 2011–2013 regime, not every departure before 2014. The ETS1 notice covers 3 March 2011–2012; ETS2 covers 2013. Relief still needs the appropriate evidence and follow-up, including the separately dated extension of social-levy relief. [ETS3 notice pp1–4/§430](https://www.impots.gouv.fr/sites/default/files/formulaires/2074-ets3/2026/2074-ets3_5526.pdf); [ETS1 notice p1](https://www.impots.gouv.fr/sites/default/files/formulaires/2074-ets1/2026/2074-ets1_5522.pdf); [ETS2 notice p1](https://www.impots.gouv.fr/sites/default/files/formulaires/2074-ets2/2026/2074-ets2_5524.pdf).",
      "line": 113
    }
  ],
  "short_exact_native_quotes": [
    "2013"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/fr-ets2-2026.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "adc12e587bf47ae3d902aa7696c9bf9f0a01f05707aa635f88a22993d727d22a",
  "source_version_basis": "Dated2026formnotice with the expressly identified older departure year; only stated scope read16November."
}
```

### FR-SIMULATOR-8TN

Old8TNfield retained only in the actual2026simulator for2025income version.

```json
{
  "act_article_or_scope": "Actual2026simulator introductory year label, field481–489 and1628–1656 with8TN1647",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": [
    "8TNlabels tax on gains in payment suspension in this dated simulator. Initial ETD/3WM/3WAfields are separate. This confirms the original field only within that version; not a universal2026departure instruction."
  ],
  "id": "FR-SIMULATOR-8TN",
  "official_url": "https://simulateur-ir-ifi.impots.gouv.fr/calcul_impot/2026/complet/",
  "quote_mode": "Permitted total short extracts with exact operative locators and complete own condition paraphrase. Strict full-native-clause reproduction is not claimed.",
  "sections": [
    {
      "actual_text": "Forms and timing. IX normally requires the initial declaration in the year AFTER departure, within the income-return deadline. The 2026 notice for 2025 transfers uses paper 2074-ETD with 2042/2042 C; an express suspension request instead requires an initial ETD at least 90 days BEFORE departure and a second filing the next year. Follow-up since 2014 uses ETS3: latent-gains-only cases after 2018 are generally event-based; deferred gains/receivables and mixed cases retain annual reporting, with ETSL available in specified no-event cases. Subsequent changes of tax domicile must be notified within 2 months; the move may itself end automatic suspension. Do not invent a calendar deadline or a final 2027 form for a 2026 departure. [CGI IX–X](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000048806379); [ETD notice V–IX, pp7–9](https://www.impots.gouv.fr/sites/default/files/formulaires/2074-etd/2026/2074-etd_5518.pdf); [ETS3 notice I–III](https://www.impots.gouv.fr/sites/default/files/formulaires/2074-ets3/2026/2074-ets3_5526.pdf). The authority’s 2026 simulator labels 8TN for tax on gains in payment suspension; that confirms the old code only for its stated 2025-income version, not universal 2026-departure filing instructions. [Actual simulator field](https://simulateur-ir-ifi.impots.gouv.fr/calcul_impot/2026/complet/). For depth use `leaving-france-exit-tax`.",
      "line": 115
    }
  ],
  "short_exact_native_quotes": [
    "8TN"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/fr-simulator-2026.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "9bf61b9eea0aa3ca405c16534c8f4441dd030f146d4ad1bcbb4386a5189c3c25",
  "source_version_basis": "Actual2025income/2026simulator version read; not final2027execution."
}
```

### NL-OTHER-CONSERVED-CATEGORIES

Pension accrual with relief, deducted annuity premiums and specified own-home savings categories have separate protective-assessment rules.

```json
{
  "act_article_or_scope": "Actual whole authority operative preserved-income categories, pension/annuity/own-home sections read with substantial-interest section",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": [
    "Protective assessments can concern relievedDutchpension accrual,deductedannuitypremiums and specifiedown-home savings products. Those are distinct categories with their own qualifying events and relief; substantial-interest lifetime/return rules must not be transplanted."
  ],
  "id": "NL-OTHER-CONSERVED-CATEGORIES",
  "official_url": "https://www.belastingdienst.nl/wps/wcm/connect/nl/buitenland/content/conserverende-aanslag-bij-emigratie",
  "quote_mode": "Permitted total short extracts with exact operative locators and complete own condition paraphrase. Strict full-native-clause reproduction is not claimed.",
  "sections": [
    {
      "actual_text": "The protective assessment can also concern relieved Dutch pension accrual, deducted annuity premiums and specified own-home savings products. Those categories have their own scope and relief; do not apply the substantial-interest rule to them. [Authority emigration assessment](https://www.belastingdienst.nl/wps/wcm/connect/nl/buitenland/content/conserverende-aanslag-bij-emigratie).",
      "line": 121
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/nl-exit-native.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "06560de15fd3c69f2e9ba5e79695288aef69f2e75a22f93210ce2f06f563f04d",
  "source_version_basis": "Current official native authority page; own16Novemberread, CC0text licence separately read; not pension-category execution clearance."
}
```

### CA-FORMS-SECURITY

T1243/Schedule3,T1161reportable-property list and T1244election/deadline/security/interest/employeeplan limits.

```json
{
  "act_article_or_scope": "Actual CRA guide reporting/deferral/unwind sections570–695 and preceding exclusions; complete bounded operative read",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": [
    "T1243calculates the deemed gain and flows toSchedule3. T1161lists reportableproperty above25000, with exclusions such as cash/definedpersonal-use items. T1244elects deferral without interest until disposal; by30Aprilafter emigration, excluding employee-benefit-plan deemed dispositions. Federal tax above16500needs security,or13777.50for formerQuebecresidents; provincial/territorialsecurity may also apply. Current statute election/security/extension rules remain controlling. No Canadian tax rate or FX is invented."
  ],
  "id": "CA-FORMS-SECURITY",
  "official_url": "https://www.canada.ca/en/revenue-agency/services/tax/international-non-residents/individuals-leaving-entering-canada-non-residents/dispositions-property.html",
  "quote_mode": "Permitted total short extracts with exact operative locators and complete own condition paraphrase. Strict full-native-clause reproduction is not claimed.",
  "sections": [
    {
      "actual_text": "Forms and deferral. The gains are computed on Form T1243 and carried to Schedule 3 of the return for the year of departure. Form T1161 lists all property inside and outside Canada above the limit in the table, with listed exclusions such as cash. Form T1244 is the election to defer payment of the tax on the deemed disposition until the property is sold, without interest; it must be made by April 30 of the year after emigration, and it does not apply to the deemed disposition of an employee benefit plan. Above the limit in the table, adequate security is required; provincial or territorial tax may also need security. The page is written for the 2025 return; the 2026 equivalents are not printed on it.",
      "line": 215
    }
  ],
  "short_exact_native_quotes": [
    "T1243"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/ca-exit-guide.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "7fc171630ea970d56d7e2ac2a279bb8e4c88a2abb7af7d4354f432816bacd6ac",
  "source_version_basis": "Guide expressly for2025returns; final2026equivalent form version not established. Paired current128.1/220statutes read."
}
```

### IT-RECAST-193

Replacement exit article193 is traced to old166; full current2027execution remains reserved.

```json
{
  "act_article_or_scope": "OriginalGazzetta annex193heading/cross-reference; actual full260line article personally read with192neighbour",
  "actual_read_on": "2026-11-16",
  "id": "IT-RECAST-193",
  "official_url": "https://www.gazzettaufficiale.it/atto/serie_generale/caricaArticolo?art.codiceRedazionale=26G00131&art.dataPubblicazioneGazzetta=2026-07-03&art.flagTipoArticolo=1&art.idArticolo=193&art.idGruppo=21&art.idSottoArticolo=1&art.idSottoArticolo1=10&art.progressivo=0&art.versione=1",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "The replacement is now traced: D.Lgs. 19 June 2026 n.117 approves the new income-tax code; its annex article 193 carries the exit rule (192 concerns entry values), with application from 1 January 2027 under 377 and repeal coordinated by 376. Entry into force of the decree in July 2026 is not the application date of the recast code. The current Normattiva contents shows a later version of 376; its full amended body was not recovered here. Accordingly this Guide does not clear a 2027 execution using the original recast alone. [Official decree and annex](https://www.gazzettaufficiale.it/eli/id/2026/07/03/26G00131/sg); [current Normattiva code](https://www.normattiva.it/atto/caricaDettaglioAtto?atto.codiceRedazionale=26G00131&atto.dataPubblicazioneGazzetta=2026-07-03).",
      "line": 200
    }
  ],
  "short_exact_native_quotes": [
    "(Testo unico imposte sui redditi-art. 193) ART. 193 Imposizione in uscita (articolo 166 decreto del Presidente della Repubblica 22 dicembre"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/it-gazzetta193-actual-web.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "f0f5f6070dd1e0c19fd29adfcc2f4103ab40cbf5a4dccefa9ed6f3c72d2f1dd7",
  "source_version_basis": "Original19June2026n117, not a claim of complete later376overlay."
}
```

### IT-RECAST-APPLICATION

Recast code applies from1January2027, distinct from July decree entry.

```json
{
  "act_article_or_scope": "Originalannex377whole7lines",
  "actual_read_on": "2026-11-16",
  "id": "IT-RECAST-APPLICATION",
  "official_url": "https://www.gazzettaufficiale.it/atto/serie_generale/caricaArticolo?art.codiceRedazionale=26G00131&art.dataPubblicazioneGazzetta=2026-07-03&art.flagTipoArticolo=1&art.idArticolo=377&art.idGruppo=74&art.idSottoArticolo=1&art.idSottoArticolo1=10&art.progressivo=0&art.versione=1",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "The replacement is now traced: D.Lgs. 19 June 2026 n.117 approves the new income-tax code; its annex article 193 carries the exit rule (192 concerns entry values), with application from 1 January 2027 under 377 and repeal coordinated by 376. Entry into force of the decree in July 2026 is not the application date of the recast code. The current Normattiva contents shows a later version of 376; its full amended body was not recovered here. Accordingly this Guide does not clear a 2027 execution using the original recast alone. [Official decree and annex](https://www.gazzettaufficiale.it/eli/id/2026/07/03/26G00131/sg); [current Normattiva code](https://www.normattiva.it/atto/caricaDettaglioAtto?atto.codiceRedazionale=26G00131&atto.dataPubblicazioneGazzetta=2026-07-03).",
      "line": 200
    }
  ],
  "short_exact_native_quotes": [
    "(Testo unico imposte sui redditi-art. 377) ART. 377 Decorrenza 1. Le disposizioni del presente testo unico si applicano a decorrere dal 1° gennaio 2027."
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/it-gazzetta377-actual-web.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "f00c57b09b87111751301622b7409cda51e1d3150faef866ec39cdb2e164dfc3",
  "source_version_basis": "Original2026decree; no latest376version2execution clearance."
}
```

### IT-RECAST-DECREE

Decree approves annex and enters into force day after official publication; annex377governs2027application.

```json
{
  "act_article_or_scope": "D.Lgs117/2026mainArt1(1)/(2) whole pluspreamble read",
  "actual_read_on": "2026-11-16",
  "id": "IT-RECAST-DECREE",
  "official_url": "https://www.gazzettaufficiale.it/atto/serie_generale/caricaArticoloDefault/originario?atto.codiceRedazionale=26G00131&atto.dataPubblicazioneGazzetta=2026-07-03&atto.tipoProvvedimento=DECRETO+LEGISLATIVO",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "The replacement is now traced: D.Lgs. 19 June 2026 n.117 approves the new income-tax code; its annex article 193 carries the exit rule (192 concerns entry values), with application from 1 January 2027 under 377 and repeal coordinated by 376. Entry into force of the decree in July 2026 is not the application date of the recast code. The current Normattiva contents shows a later version of 376; its full amended body was not recovered here. Accordingly this Guide does not clear a 2027 execution using the original recast alone. [Official decree and annex](https://www.gazzettaufficiale.it/eli/id/2026/07/03/26G00131/sg); [current Normattiva code](https://www.normattiva.it/atto/caricaDettaglioAtto?atto.codiceRedazionale=26G00131&atto.dataPubblicazioneGazzetta=2026-07-03).",
      "line": 200
    }
  ],
  "short_exact_native_quotes": [
    "Art. 1 1. E' approvato l'allegato testo unico delle disposizioni legislative in materia di imposte sui redditi. 2. Il presente decreto legislativo entra in vigore"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/exit-taxes/sources/it-gazzetta-main.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "8ca892acc9bf7e50b11f2102a4ff6fc7b020f3ac63bbdbb2878d94345ce2102c",
  "source_version_basis": "OriginalGazzetta3July2026publication; July entry is not January2027application."
}
```

### CA-1281-DEFINITIONS

Complete excluded-rights/interests and reportable-property definitions qualify the departure and25000reporting rows.

```json
{
  "act_article_or_scope": "ITA128.1(10) full definitions, actual474–568; read with(4)/(9)",
  "actual_read_on": "2026-11-16",
  "id": "CA-1281-DEFINITIONS",
  "official_url": "https://laws-lois.justice.gc.ca/eng/acts/I-3.3/section-128.1.html",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "What is not caught. The exceptions the page lists include: Canadian real or immovable property, Canadian resource property and timber resource property; Canadian business property (including inventory) where the business is carried on through a permanent establishment in Canada; pension plans, annuities, registered retirement savings plans, registered retirement income funds, registered education and disability savings plans, tax-free savings accounts and the other plans and rights the page lists as excluded rights or interests; and property owned on last becoming resident (or inherited afterwards) by an individual who was resident in Canada for 60 months or less in the ten years before emigrating. A person can elect to report a deemed disposition of the first two kinds of property.",
      "line": 206
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/ca-ita1281.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "041773d41fb70c29f3468d15a0de0899e691ebee03d287c91e028da4c6d4f5a9",
  "source_version_basis": "Actual current JusticeLaw definition, all listedparagraphs personally read16November; no all-property reportable shortcut."
}
```

### US-EXPAT-DATE

Post17June2008modern expatriation orientation is distinguished from ordinary continued-citizenship relocation.

```json
{
  "act_article_or_scope": "Actual IRS expatriation operative post2008scope paragraph; paired currentIRC877/877Aevent/gates source units",
  "actual_read_on": "2026-11-16",
  "id": "US-EXPAT-DATE",
  "official_url": "https://www.irs.gov/individuals/international-taxpayers/expatriation-tax",
  "quote_mode": "Actual public-law or CC0 operative unit; ordered lossless fragments <=25words/240characters. Full clause not replaced by generic source anchor.",
  "sections": [
    {
      "actual_text": "The expatriation tax provisions of sections 877 and 877A of the Internal Revenue Code apply to US citizens who relinquish citizenship under the statutory event rules (including renunciation) and to long-term residents who have ended their US resident status for federal tax purposes. For expatriation on or after June 17, 2008, a person is a covered expatriate if any one of three tests is met: an average annual net income tax test, a net worth test, or a failure to certify five years of tax compliance on Form 8854 ([IRS, expatriation tax](https://www.irs.gov/individuals/international-taxpayers/expatriation-tax)). The amounts, the deemed sale and the deferral are in `us-expatriation-exit-tax`. Citizens who move abroad but keep citizenship are not expatriating; see `us-citizen-moving-abroad-tax`.",
      "line": 225
    }
  ],
  "short_exact_native_quotes": [
    "If you expatriated on or after June 17, 2008, the new IRC 877A expatriation rules apply to you if any of the following statements apply."
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/res-us-expat.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "6dc70146cdf7316749113b468ac1a4ec5507c53db645c83e159062a18434625d",
  "source_version_basis": "Retained official IRS source previously personally read, re-read assigned paragraph16November; current statutory corpus separately controls. No updated-dollar amount copied from older authority prose."
}
```

### UK-DATED-DATEPAIR

DatedRDR3example retains4May2015/4May2020and its given residence facts; raw1827daysnot universal5yearsplus1day.

```json
{
  "act_article_or_scope": "RDR3section7actual895–942date-pair and statutory-period neighbours; whole earlier7scope personally read",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": [
    "The original4May2015departure/4May2020return illustration is preserved in its given residence facts and the authority says temporary rules do not apply. Those dates differ by1827calendar days. Current statutory residence-period endpoints and split years govern, so rawtravel-date arithmetic does not prove a universal safe harbour."
  ],
  "id": "UK-DATED-DATEPAIR",
  "official_url": "https://www.gov.uk/government/publications/rdr3-statutory-residence-test-srt/guidance-note-for-statutory-residence-test-srt-rdr3",
  "quote_mode": "Permitted total short extracts with exact operative locators and complete own condition paraphrase. Strict full-native-clause reproduction is not claimed.",
  "sections": [
    {
      "actual_text": "No UK charge on the unrealised gains of an individual who leaves is printed on the HMRC page linked in this section. The rule HMRC sets out for departures is temporary non-residence: a person who returns may pay tax in the year of return on certain income and gains received during the absence ([HMRC RDR3, section 7](https://www.gov.uk/government/publications/rdr3-statutory-residence-test-srt/guidance-note-for-statutory-residence-test-srt-rdr3)). A person is temporarily non-resident if, after a residence period with sole UK residence, they have one or more residence periods without sole UK residence; AND in 4 or more of the 7 tax years before the year of departure they had sole UK residence for the tax year, or the year was a split year with a residence period of sole UK residence; AND the period of non-residence lasts 5 years or less. The statutory period is defined using the end of the preceding sole-UK-residence period and the start of the next one; raw travel dates alone are insufficient. HMRC’s dated example leaves on 4 May 2015 and returns on 4 May 2020 and says the rules do not apply. Preserve that illustration in its stated residence facts; those calendar dates are 1,827 days apart and do not themselves prove a universal “5 years plus 1 day” safe harbour. [FA 2013 Schedule 45 paragraphs 109–115](https://www.legislation.gov.uk/ukpga/2013/29/schedule/45/part/4/data.xht?wrap=true). Capital gains are among the items in scope. Current TCGA 1M/1N govern the gains rule and the conditional new-assets exclusion; old sections 10A/10AA are repealed. The current 2026–27 amendment separates specified carried-interest amounts, so this is not an all-income rule. Trust and company charges remain outside this Guide. [Current 1M](https://www.legislation.gov.uk/ukpga/1992/12/section/1M/data.xht); [1N](https://www.legislation.gov.uk/ukpga/1992/12/section/1N/data.xht).",
      "line": 229
    }
  ],
  "short_exact_native_quotes": [
    "4 May 2015"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/uk-rdr3.txt",
  "source_provenance": "Same writer actual operative/neighbour reading on16November2026, including bounded prior source reuse; no inherited independent PASS.",
  "source_sha256": "89ea9047d1ded213a6a534e4c0cd0e487c9be1e1b8c1c621f4807b16800de5f9",
  "source_version_basis": "Dated official guidance alongside currentFA2013Sch45/TCGA1M1N, not former10A/10AA current law."
}
```

## Original-topic destinations

The complete original-topic destination table is in `../exit-taxes-when-a-family-moves/old-topic-map.json`.
