# dac6-mdr-reportable-arrangements figure and rule ledger

Public projection; canonical private SHA256: `d5314807d7e1f2f74eaab5fa28620a7a4b6e313ccdc58447e46916eeb9e7518c`. Complete captured/native source passages remain local. The JSON companion preserves every retained evidence field.

## Whole rule groups

### R001

Tax scope and exclusions

```json
{
  "act_article": "article2(1)–(4)",
  "guide_group": "D02",
  "guide_lines": [
    25
  ],
  "id": "R001",
  "native_quote_fragments": [
    "This Directive shall apply to all taxes of any kind levied by, or on behalf of, a Member State or the Member State’s territorial or"
  ],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "dac",
  "status": "SOURCE READ; independent review pending"
}
```

### R002

Original application/commencement basis

```json
{
  "act_article": "articles2–3",
  "guide_group": "D03",
  "guide_lines": [
    28
  ],
  "id": "R002",
  "native_quote_fragments": [
    "Article 2 1. Member States shall adopt and publish, by 31 December 2019 at the latest, the laws, regulations and administrative provisions necessary to comply"
  ],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://publications.europa.eu/resource/celex/32018L0822",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "dac6",
  "status": "SOURCE READ; independent review pending"
}
```

### R003

Pending recast status,not enacted law

```json
{
  "act_article": "Procedure2026/0168(CNS),status/keyevents",
  "guide_group": "D03",
  "guide_lines": [
    28
  ],
  "id": "R003",
  "native_quote_fragments": [
    "2026/0168(CNS) CNS - Consultation procedure Directive"
  ],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://oeil.europarl.europa.eu/oeil/en/procedure-file?reference=2026%2F0168%28CNS%29",
  "own_condition_paraphrase": "The actual procedure is the administrative-cooperation recast; a legislative proposal and pending committee stage do not enact replacement law. Own fresh official web read on 16 November independently reconfirmed the archived identity/status/events.",
  "quote_method": "Own 16 November correction read of the named operative scope; exact source-language fragments. Source-capture dates retained separately.",
  "read_date": "2026-11-16",
  "source_key": "eprecast",
  "status": "SOURCE READ; independent review pending"
}
```

### R004

Cross-border geographic opening/five limbs/series and parts

```json
{
  "act_article": "article3(18)",
  "guide_group": "D04",
  "guide_lines": [
    44
  ],
  "id": "R004",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "dac",
  "status": "SOURCE READ; independent review pending"
}
```

### R005

Reportability/hallmark/promoter/serviceknowledge and rebuttal

```json
{
  "act_article": "article3(19)–(21),firsttwo paragraphs",
  "guide_group": "D05",
  "guide_lines": [
    47
  ],
  "id": "R005",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "dac",
  "status": "SOURCE READ; independent review pending"
}
```

### R006

Knowledge,possession or control limit

```json
{
  "act_article": "article8ab(1),firstsentence",
  "guide_group": "D05",
  "guide_lines": [
    47
  ],
  "id": "R006",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "dac",
  "status": "SOURCE READ; independent review pending"
}
```

### R007

Four alternative EU connections;relevant taxpayer

```json
{
  "act_article": "article3(21),nexus;(22)",
  "guide_group": "D06",
  "guide_lines": [
    50
  ],
  "id": "R007",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "dac",
  "status": "SOURCE READ; independent review pending"
}
```

### R008

Association thresholds/influence/aggregation,jointaction,indirect,family

```json
{
  "act_article": "article3(23)",
  "guide_group": "D07",
  "guide_lines": [
    53
  ],
  "id": "R008",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "dac",
  "status": "SOURCE READ; independent review pending"
}
```

### R009

MBT definition,applicable hallmarks,and noautomaticC1test

```json
{
  "act_article": "AnnexIVPartI",
  "guide_group": "D08",
  "guide_lines": [
    58
  ],
  "id": "R009",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "dac",
  "status": "SOURCE READ; independent review pending"
}
```

### R010

HallmarkA.1 complete elements and MBT

```json
{
  "act_article": "AnnexIVA.1;PartI",
  "guide_group": "D09",
  "guide_lines": [
    62
  ],
  "id": "R010",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "dac",
  "status": "SOURCE READ; independent review pending"
}
```

### R011

HallmarkA.2 complete elements and MBT

```json
{
  "act_article": "AnnexIVA.2;PartI",
  "guide_group": "D10",
  "guide_lines": [
    63
  ],
  "id": "R011",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "dac",
  "status": "SOURCE READ; independent review pending"
}
```

### R012

HallmarkA.3 complete elements and MBT

```json
{
  "act_article": "AnnexIVA.3;PartI",
  "guide_group": "D11",
  "guide_lines": [
    64
  ],
  "id": "R012",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "dac",
  "status": "SOURCE READ; independent review pending"
}
```

### R013

HallmarkB.1 complete elements and MBT

```json
{
  "act_article": "AnnexIVB.1;PartI",
  "guide_group": "D12",
  "guide_lines": [
    65
  ],
  "id": "R013",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "dac",
  "status": "SOURCE READ; independent review pending"
}
```

### R014

HallmarkB.2 complete elements and MBT

```json
{
  "act_article": "AnnexIVB.2;PartI",
  "guide_group": "D13",
  "guide_lines": [
    66
  ],
  "id": "R014",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "dac",
  "status": "SOURCE READ; independent review pending"
}
```

### R015

HallmarkB.3 complete elements and MBT

```json
{
  "act_article": "AnnexIVB.3;PartI",
  "guide_group": "D14",
  "guide_lines": [
    67
  ],
  "id": "R015",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "dac",
  "status": "SOURCE READ; independent review pending"
}
```

### R016

HallmarkC.1(a) deductible/associated/crossborder prerequisites,recipientlimb,correctMBT

```json
{
  "act_article": "AnnexIVC.1(a)opening+limb;PartI",
  "guide_group": "D15",
  "guide_lines": [
    68
  ],
  "id": "R016",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "dac",
  "status": "SOURCE READ; independent review pending"
}
```

### R017

HallmarkC.1(b)(i) deductible/associated/crossborder prerequisites,recipientlimb,correctMBT

```json
{
  "act_article": "AnnexIVC.1(b)(i)opening+limb;PartI",
  "guide_group": "D16",
  "guide_lines": [
    69
  ],
  "id": "R017",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "dac",
  "status": "SOURCE READ; independent review pending"
}
```

### R018

HallmarkC.1(b)(ii) deductible/associated/crossborder prerequisites,recipientlimb,correctMBT

```json
{
  "act_article": "Annex IV C.1 opening, C.1(b) resident-recipient parent and (ii); Part I",
  "guide_group": "D17",
  "guide_lines": [
    70
  ],
  "id": "R018",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1",
  "quote_method": "Own 16 November correction read of the named operative scope; exact source-language fragments. Source-capture dates retained separately.",
  "read_date": "2026-11-16",
  "source_key": "dac",
  "status": "SOURCE READ; independent review pending"
}
```

### R019

HallmarkC.1(c) deductible/associated/crossborder prerequisites,recipientlimb,correctMBT

```json
{
  "act_article": "AnnexIVC.1(c)opening+limb;PartI",
  "guide_group": "D18",
  "guide_lines": [
    71
  ],
  "id": "R019",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "dac",
  "status": "SOURCE READ; independent review pending"
}
```

### R020

HallmarkC.1(d) deductible/associated/crossborder prerequisites,recipientlimb,correctMBT

```json
{
  "act_article": "AnnexIVC.1(d)opening+limb;PartI",
  "guide_group": "D19",
  "guide_lines": [
    72
  ],
  "id": "R020",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "dac",
  "status": "SOURCE READ; independent review pending"
}
```

### R021

HallmarkC.2 complete elements;noMBT classification inPartI

```json
{
  "act_article": "AnnexIVC.2",
  "guide_group": "D20",
  "guide_lines": [
    73
  ],
  "id": "R021",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "dac",
  "status": "SOURCE READ; independent review pending"
}
```

### R022

HallmarkC.3 complete elements;noMBT classification inPartI

```json
{
  "act_article": "AnnexIVC.3",
  "guide_group": "D21",
  "guide_lines": [
    74
  ],
  "id": "R022",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "dac",
  "status": "SOURCE READ; independent review pending"
}
```

### R023

HallmarkC.4 complete elements;noMBT classification inPartI

```json
{
  "act_article": "AnnexIVC.4",
  "guide_group": "D22",
  "guide_lines": [
    75
  ],
  "id": "R023",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "dac",
  "status": "SOURCE READ; independent review pending"
}
```

### R024

HallmarkD.1opening complete elements;noMBT classification inPartI

```json
{
  "act_article": "AnnexIVD.1opening",
  "guide_group": "D23",
  "guide_lines": [
    76
  ],
  "id": "R024",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "dac",
  "status": "SOURCE READ; independent review pending"
}
```

### R025

HallmarkD.2 complete elements;noMBT classification inPartI

```json
{
  "act_article": "AnnexIVD.2",
  "guide_group": "D24",
  "guide_lines": [
    77
  ],
  "id": "R025",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "dac",
  "status": "SOURCE READ; independent review pending"
}
```

### R026

HallmarkE.1 complete elements;noMBT classification inPartI

```json
{
  "act_article": "AnnexIVE.1",
  "guide_group": "D25",
  "guide_lines": [
    78
  ],
  "id": "R026",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "dac",
  "status": "SOURCE READ; independent review pending"
}
```

### R027

HallmarkE.2 complete elements;noMBT classification inPartI

```json
{
  "act_article": "AnnexIVE.2",
  "guide_group": "D26",
  "guide_lines": [
    79
  ],
  "id": "R027",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "dac",
  "status": "SOURCE READ; independent review pending"
}
```

### R028

HallmarkE.3 complete elements;noMBT classification inPartI

```json
{
  "act_article": "AnnexIVE.3",
  "guide_group": "D27",
  "guide_lines": [
    80
  ],
  "id": "R028",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "dac",
  "status": "SOURCE READ; independent review pending"
}
```

### R029

All six DAC6patterns,countderived,noinvented(g)

```json
{
  "act_article": "AnnexIVD.1(a)–(f)",
  "guide_group": "D28",
  "guide_lines": [
    83
  ],
  "id": "R029",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "dac",
  "status": "SOURCE READ; independent review pending"
}
```

### R030

Silent authority notacceptance;classification nottaxapproval

```json
{
  "act_article": "article8ab(15)",
  "guide_group": "D29",
  "guide_lines": [
    86
  ],
  "id": "R030",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "dac",
  "status": "SOURCE READ; independent review pending"
}
```

### R031

Notified intermediary/taxpayer responsibility

```json
{
  "act_article": "article8ab(6)",
  "guide_group": "D30",
  "guide_lines": [
    91
  ],
  "id": "R031",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "dac",
  "status": "SOURCE READ; independent review pending"
}
```

### R032

Allintermediaries,sameinformationproof,multiple taxpayerpriority

```json
{
  "act_article": "article8ab(9)–(10)",
  "guide_group": "D30",
  "guide_lines": [
    91
  ],
  "id": "R032",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "dac",
  "status": "SOURCE READ; independent review pending"
}
```

### R033

Intermediaryjurisdictionorder and sameinformationproof

```json
{
  "act_article": "article8ab(3)–(4)",
  "guide_group": "D31",
  "guide_lines": [
    94
  ],
  "id": "R033",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "dac",
  "status": "SOURCE READ; independent review pending"
}
```

### R034

Separatetaxpayerjurisdictionorder and proof

```json
{
  "act_article": "article8ab(7)–(8)",
  "guide_group": "D31",
  "guide_lines": [
    94
  ],
  "id": "R034",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "dac",
  "status": "SOURCE READ; independent review pending"
}
```

### R035

30days;literal earliestthree triggers;serviceproviderclock

```json
{
  "act_article": "article8ab(1)",
  "guide_group": "D32",
  "guide_lines": [
    99
  ],
  "id": "R035",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "dac",
  "status": "SOURCE READ; independent review pending"
}
```

### R036

Taxpayerown trigger wording

```json
{
  "act_article": "article8ab(7),firstparagraph",
  "guide_group": "D32",
  "guide_lines": [
    99
  ],
  "id": "R036",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "dac",
  "status": "SOURCE READ; independent review pending"
}
```

### R037

Marketable/bespokedefinitions

```json
{
  "act_article": "article3(24)–(25)",
  "guide_group": "D33",
  "guide_lines": [
    102
  ],
  "id": "R037",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "dac",
  "status": "SOURCE READ; independent review pending"
}
```

### R038

Every3monthsnewinformation(a,d,g,h)

```json
{
  "act_article": "article8ab(2)",
  "guide_group": "D33",
  "guide_lines": [
    102
  ],
  "id": "R038",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "dac",
  "status": "SOURCE READ; independent review pending"
}
```

### R039

German marketableupdate10daysaftercalendarquarter

```json
{
  "act_article": "AO138h",
  "guide_group": "D33",
  "guide_lines": [
    102
  ],
  "id": "R039",
  "native_quote_fragments": [
    "Bei marktfähigen grenzüberschreitenden Steuergestaltungen sind Änderungen und Ergänzungen hinsichtlich der in § 138f Absatz 3 Satz 1 Nummer 1, 2, 3, 6, 9 und 10"
  ],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.gesetze-im-internet.de/ao_1977/__138h.html",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "de138h",
  "status": "SOURCE READ; independent review pending"
}
```

### R040

Originalbacklogwindow and31Aug2020deadline

```json
{
  "act_article": "article8ab(12)",
  "guide_group": "D34",
  "guide_lines": [
    105
  ],
  "id": "R040",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "dac",
  "status": "SOURCE READ; independent review pending"
}
```

### R041

Optionalbacklog28Feb2021/Janclock/Aprmarketabledeferrals

```json
{
  "act_article": "article1/inserted27a(1)–(2)",
  "guide_group": "D34",
  "guide_lines": [
    105
  ],
  "id": "R041",
  "native_quote_fragments": [
    "1. Notwithstanding the time limits for filing information on reportable cross-border arrangements as specified in Article 8ab(12), Member States may take the measures necessary to"
  ],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://publications.europa.eu/resource/celex/32020L0876",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "delay",
  "status": "SOURCE READ; independent review pending"
}
```

### R042

8derivedlettercategories,currentprivilegedidentityexclusion,expandedsummaryandotherfields

```json
{
  "act_article": "article8ab(14)(a)–(h)",
  "guide_group": "D35",
  "guide_lines": [
    110
  ],
  "id": "R042",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "dac",
  "status": "SOURCE READ; independent review pending"
}
```

### R043

Clientdefinition

```json
{
  "act_article": "article3(31)",
  "guide_group": "D36",
  "guide_lines": [
    113
  ],
  "id": "R043",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "dac",
  "status": "SOURCE READ; independent review pending"
}
```

### R044

Nationalwaiver/clientonlynotice/withinprofessionlimits

```json
{
  "act_article": "article8ab(5)",
  "guide_group": "D36",
  "guide_lines": [
    113
  ],
  "id": "R044",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "dac",
  "status": "SOURCE READ; independent review pending"
}
```

### R045

Nonclientlawyernotificationinvalid,notblanketnoticeabolition

```json
{
  "act_article": "paragraph66+operative",
  "guide_group": "D37",
  "guide_lines": [
    116
  ],
  "id": "R045",
  "native_quote_fragments": [
    "66 It follows from all the foregoing considerations that the answer to the question referred is that Article 8ab(5) of amended Directive 2011/16 is invalid"
  ],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://publications.europa.eu/resource/cellar/3748055b-76dd-11ed-9887-01aa75ed71a1.0007.05/DOC_1",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "case694",
  "status": "SOURCE READ; independent review pending"
}
```

### R046

Clientnotificationandconfidentialrelationship

```json
{
  "act_article": "paragraph19",
  "guide_group": "D37",
  "guide_lines": [
    116
  ],
  "id": "R046",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://publications.europa.eu/resource/cellar/3748055b-76dd-11ed-9887-01aa75ed71a1.0007.05/DOC_1",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "case694",
  "status": "SOURCE READ; independent review pending"
}
```

### R047

Waiversubstitutiononlylegalrepresentationprofessions

```json
{
  "act_article": "paragraph108",
  "guide_group": "D37",
  "guide_lines": [
    116
  ],
  "id": "R047",
  "native_quote_fragments": [
    "In view of the foregoing considerations, it must be held that the power of the Member States to substitute the obligation to notify for the"
  ],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://publications.europa.eu/resource/celex/62022CJ0623",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "case623",
  "status": "SOURCE READ; independent review pending"
}
```

### R048

SpecialC694protectionlimitedDirective98/5titles

```json
{
  "act_article": "paragraph118",
  "guide_group": "D37",
  "guide_lines": [
    116
  ],
  "id": "R048",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://publications.europa.eu/resource/celex/62022CJ0623",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "case623",
  "status": "SOURCE READ; independent review pending"
}
```

### R049

Conditionalpartialuserdatareporttransfer/notice/IDs/clock/remainingreport

```json
{
  "act_article": "AO138f(6)",
  "guide_group": "D38",
  "guide_lines": [
    119
  ],
  "id": "R049",
  "native_quote_fragments": [
    "(6) Unterliegt ein Intermediär einer gesetzlichen Pflicht zur Verschwiegenheit und hat der Nutzer ihn von dieser Pflicht nicht entbunden, so geht die Pflicht zur Übermittlung"
  ],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.gesetze-im-internet.de/ao_1977/__138f.html",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "de138f",
  "status": "SOURCE READ; independent review pending"
}
```

### R050

Namedstatutoryprofessions,releaseandremainingDAC6duties

```json
{
  "act_article": "AO 102(1), including profession-list opening and capacity-limited closing",
  "guide_group": "D38",
  "guide_lines": [
    119
  ],
  "id": "R050",
  "native_quote_fragments": [
    "(1) Die Auskunft können ferner verweigern: 1. Geistliche über das, was ihnen in ihrer Eigenschaft als Seelsorger anvertraut worden oder bekannt geworden ist, 2. Mitglieder"
  ],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.gesetze-im-internet.de/ao_1977/__102.html",
  "quote_method": "Own 16 November correction read of the named operative scope; exact source-language fragments. Source-capture dates retained separately.",
  "read_date": "2026-11-16",
  "source_key": "de102",
  "status": "SOURCE READ; independent review pending"
}
```

### R051

ReleaseandremainingDAC6informationduty

```json
{
  "act_article": "AO102(3)–(4)",
  "guide_group": "D38",
  "guide_lines": [
    119
  ],
  "id": "R051",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.gesetze-im-internet.de/ao_1977/__102.html",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "de102",
  "status": "SOURCE READ; independent review pending"
}
```

### R052

Qualifyingavocats,clientonlynotice,datecertain,information

```json
{
  "act_article": "CGI1649AEI(4)",
  "guide_group": "D39",
  "guide_lines": [
    122
  ],
  "id": "R052",
  "native_quote_fragments": [
    "4° L'intermédiaire qui a la qualité d'avocat ou d'avocat au Conseil d'Etat et à la Cour de cassation est dispensé de souscrire la déclaration mentionnée"
  ],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000051215679/2025-02-16",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "fr1649",
  "status": "SOURCE READ; independent review pending"
}
```

### R053

Effective16Feb2025andcurrent23Sep2026guidance

```json
{
  "act_article": "BOFiP150–180",
  "guide_group": "D39",
  "guide_lines": [
    122
  ],
  "id": "R053",
  "native_quote_fragments": [
    "Cette disposition s’applique à compter de la date d’entrée en vigueur de la loi n° 2025-127 du 14 février 2025 de finances pour 2025, soit"
  ],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://bofip.impots.gouv.fr/bofip/12275-PGP.html/identifiant=BOI-CF-CPF-30-40-10-20-20260923",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "frguide",
  "status": "SOURCE READ; independent review pending"
}
```

### R054

Partialprivilege/legalcontext/marketing/clientrelease/clientnotice

```json
{
  "act_article": "March2026manual4.10,printed47–48",
  "guide_group": "D40",
  "guide_lines": [
    125
  ],
  "id": "R054",
  "native_quote_fragments": [
    "An intermediary will be exempt from the obligation to file a return of the specified information with Revenue if a claim to legal professional privilege"
  ],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.revenue.ie/en/tax-professionals/tdm/income-tax-capital-gains-tax-corporation-tax/part-33/33-03-03.pdf",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "iecurrent",
  "status": "SOURCE READ; independent review pending"
}
```

### R055

FormDAC6LPP/MyEnquiriesroute

```json
{
  "act_article": "Howtofile,partialLPPparagraph",
  "guide_group": "D40",
  "guide_lines": [
    125
  ],
  "id": "R055",
  "native_quote_fragments": [
    "You cannot file a return on ROS where information is identified as subject to LPP. In those specific circumstances, Form DAC 6 (LPP) should be"
  ],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.revenue.ie/en/companies-and-charities/international-tax/aeoi/dac6/file-dac6.aspx",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "iefiling",
  "status": "SOURCE READ; independent review pending"
}
```

### R056

Confidentialitystatutorycrossref+clientnotification

```json
{
  "act_article": "WIB10h(5)",
  "guide_group": "D41",
  "guide_lines": [
    128
  ],
  "id": "R056",
  "native_quote_fragments": [
    "5 Artikel 53a, eerste lid, van de Algemene wet inzake rijksbelastingen is van overeenkomstige toepassing. Als de intermediair, bedoeld in het eerste lid, zich op"
  ],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://wetten.overheid.nl/BWBR0003954",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "nllatest",
  "status": "SOURCE READ; independent review pending"
}
```

### R057

Specifiedprofessionsandcapacity-limitedinformation

```json
{
  "act_article": "AWR53a(1)",
  "guide_group": "D41",
  "guide_lines": [
    128
  ],
  "id": "R057",
  "native_quote_fragments": [
    "1 Voor een weigering om te voldoen aan de verplichtingen ten behoeve van de belastingheffing van derden kunnen alleen bekleders van een geestelijk ambt, notarissen,"
  ],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://wetten.overheid.nl/BWBR0002320/2026-01-01",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "nl53acurrent",
  "status": "SOURCE READ; independent review pending"
}
```

### R058

Originalnationalprofessionlist,limits,10daynotice;notcurrentcompatibilityclearance

```json
{
  "act_article": "Original2020lawarticle3(1)–(2)",
  "guide_group": "D42",
  "guide_lines": [
    131
  ],
  "id": "R058",
  "native_quote_fragments": [
    "Art. 3. (1) Par dérogation aux articles 2 et 5, les intermédiaires qui sont soumis à l’article 35 de la loi modifiée du er 10"
  ],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://legilux.public.lu/filestore/eli/etat/leg/loi/2020/03/25/a192/jo/fr/pdfa/eli-etat-leg-loi-2020-03-25-a192-jo-fr-pdfa.pdf",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "lulaw",
  "status": "SOURCE READ; independent review pending"
}
```

### R059

Nationalcurrentguidanceprofession/noticecontrast

```json
{
  "act_article": "ACD4.2/6.2,updated15June2026",
  "guide_group": "D42",
  "guide_lines": [
    131
  ],
  "id": "R059",
  "native_quote_fragments": [
    "Les avocats, les experts-comptables et les professionnels de l’audit sont dispensés de transmettre à l’ACD les informations dont ils ont eu connaissance, qu’ils possèdent ou"
  ],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://impotsdirects.public.lu/fr/echanges_electroniques/dispositifstransfrontieres.html",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "lupage",
  "status": "SOURCE READ; independent review pending"
}
```

### R060

Stated10daynationalnoticeperiod

```json
{
  "act_article": "ACD6.2",
  "guide_group": "D42",
  "guide_lines": [
    131
  ],
  "id": "R060",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://impotsdirects.public.lu/fr/echanges_electroniques/dispositifstransfrontieres.html",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "lupage",
  "status": "SOURCE READ; independent review pending"
}
```

### R061

Nationalcourtlegalrepresentationandlawyertitleboundaries

```json
{
  "act_article": "Judgment33/2025B.11–B.12",
  "guide_group": "D43",
  "guide_lines": [
    134
  ],
  "id": "R061",
  "native_quote_fragments": [
    "En ce qui concerne la faculté pour les États membres de dispenser les intermédiaires de l’obligation de déclaration en raison du secret professionnel, il ressort"
  ],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://fr.const-court.be/public/f/2025/2025-033f.pdf",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "becurrent",
  "status": "SOURCE READ; independent review pending"
}
```

### R062

Protectedinformation/selfincrimination/clientonlynotice/taxpayerduplicates

```json
{
  "act_article": "CurrentD.Lgs100/2020art3(4)–(10)",
  "guide_group": "D44",
  "guide_lines": [
    137
  ],
  "id": "R062",
  "native_quote_fragments": [
    "4. L'intermediario è esonerato dall'obbligo di comunicazione per le informazioni che riceve dal proprio cliente, o ottiene riguardo allo stesso nel corso dell'esame della posizione"
  ],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.legislativo:2020-07-30;100!vig=~art3",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "it3",
  "status": "SOURCE READ; independent review pending"
}
```

### R063

Neutrallegaladvice,regardlessactivity,notfacilitation,clientrelease

```json
{
  "act_article": "LGTDA23(2)",
  "guide_group": "D45",
  "guide_lines": [
    140
  ],
  "id": "R063",
  "native_quote_fragments": [
    "2. Estarán dispensados de la obligación de información por el deber de secreto profesional al que se refieren el apartado 5 del artículo 8 bis"
  ],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.boe.es/eli/es/l/2003/12/17/58/con",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "eslaw",
  "status": "SOURCE READ; independent review pending"
}
```

### R064

Clientnotificationcurrentnationaltext

```json
{
  "act_article": "LGTDA24(1)",
  "guide_group": "D45",
  "guide_lines": [
    140
  ],
  "id": "R064",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.boe.es/eli/es/l/2003/12/17/58/con",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "eslaw",
  "status": "SOURCE READ; independent review pending"
}
```

### R065

Arrangement/DisclosureIDsandreuse/notification

```json
{
  "act_article": "AO138f(5)",
  "guide_group": "D46",
  "guide_lines": [
    143
  ],
  "id": "R065",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.gesetze-im-internet.de/ao_1977/__138f.html",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "de138f",
  "status": "SOURCE READ; independent review pending"
}
```

### R066

ArrangementvsDisclosureID meaning

```json
{
  "act_article": "May2026handbook1.5.1–1.5.2",
  "guide_group": "D46",
  "guide_lines": [
    143
  ],
  "id": "R066",
  "native_quote_fragments": [
    "Eine grenzüberschreitende Steuergestaltung (Arrangement) kann sich aus einer oder mehrere(n) Offenlegung(en) von unterschiedlichen Intermediären und/oder Nutzern zusammensetzen. Die Registriernummer (ArrangementID) gibt entsprechend die Nummer zu"
  ],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.bzst.de/SharedDocs/Downloads/DE/DAC6/KHB/khb_dac6_bop.pdf?__blob=publicationFile&v=23",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "dehandbook",
  "status": "SOURCE READ; independent review pending"
}
```

### R067

Issue/reuse/notifyknownparticipants/annualuse

```json
{
  "act_article": "Ministerialdecreeart3(1)–(3)",
  "guide_group": "D46",
  "guide_lines": [
    143
  ],
  "id": "R067",
  "native_quote_fragments": [
    "1. L’Agenzia delle Entrate rilascia un numero di riferimento al momento della comunicazione di un meccanismo transfrontaliero, salvo nei casi in cui la comunicazione contenga"
  ],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.finanze.gov.it/export/sites/finanze/.galleries/Documenti/Varie/dm_dac6_testo.docx_signed.pdf",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "itdm",
  "status": "SOURCE READ; independent review pending"
}
```

### R068

AnnualuseisMemberStateoption

```json
{
  "act_article": "8ab(11)",
  "guide_group": "D47",
  "guide_lines": [
    146
  ],
  "id": "R068",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "dac",
  "status": "SOURCE READ; independent review pending"
}
```

### R069

Firsttaxadvantageperiodandtworeferences

```json
{
  "act_article": "AO138k",
  "guide_group": "D47",
  "guide_lines": [
    146
  ],
  "id": "R069",
  "native_quote_fragments": [
    "Hat ein Nutzer eine grenzüberschreitende Steuergestaltung im Sinne des § 138d Absatz 2 oder der entsprechenden Regelung eines anderen Mitgliedstaats der Europäischen Union verwirklicht, so"
  ],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.gesetze-im-internet.de/ao_1977/__138k.html",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "de138k",
  "status": "SOURCE READ; independent review pending"
}
```

### R070

Irishannualincome-returnuseconditions

```json
{
  "act_article": "March 2026 Revenue manual 5.6, printed p52, entire text and footnotes 64–65",
  "guide_group": "D47",
  "guide_lines": [
    146
  ],
  "id": "R070",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.revenue.ie/en/tax-professionals/tdm/income-tax-capital-gains-tax-corporation-tax/part-33/33-03-03.pdf",
  "own_condition_paraphrase": "Chargeable-person self-assessment; reference in each period of an arrangement transaction OR obtained/sought advantage and every period until the advantage stops. Practical pre-2020 exclusion; joint-assessment satisfaction through spouse/civil partner reference. Where the intermediary did not file/provide ID the taxpayer returns to obtain one; Form11/CT1/Form1 fields. No blanket annual EU duty.",
  "quote_method": "Own 16 November correction read of the named operative scope; exact source-language fragments. Source-capture dates retained separately.",
  "read_date": "2026-11-16",
  "source_key": "iecurrent",
  "status": "SOURCE READ; independent review pending"
}
```

### R071

Luxembourgannualuseforms500/100

```json
{
  "act_article": "ACD3,taxpayerannualuseforms",
  "guide_group": "D47",
  "guide_lines": [
    146
  ],
  "id": "R071",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://impotsdirects.public.lu/fr/echanges_electroniques/dispositifstransfrontieres.html",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "lupage",
  "status": "SOURCE READ; independent review pending"
}
```

### R072

Commencement28Mar2023

```json
{
  "act_article": "SI2023/38reg1",
  "guide_group": "D48",
  "guide_lines": [
    151
  ],
  "id": "R072",
  "native_quote_fragments": [
    "These Regulations may be cited as the International Tax Enforcement (Disclosable Arrangements) Regulations 2023 and come into force on 28th March 2023."
  ],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.legislation.gov.uk/uksi/2023/38/pdfs/uksi_20230038_en.pdf",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "uk",
  "status": "SOURCE READ; independent review pending"
}
```

### R073

OECDmodelincorporation,scopeandUKdefinedterms

```json
{
  "act_article": "reg2",
  "guide_group": "D48",
  "guide_lines": [
    151
  ],
  "id": "R073",
  "native_quote_fragments": [
    "In these Regulations—"
  ],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.legislation.gov.uk/uksi/2023/38/pdfs/uksi_20230038_en.pdf",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "uk",
  "status": "SOURCE READ; independent review pending"
}
```

### R074

Revocationold2020regime

```json
{
  "act_article": "SI 2023/38 regulation 21(a)–(c), complete named revocations",
  "guide_group": "D48",
  "guide_lines": [
    151
  ],
  "id": "R074",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.legislation.gov.uk/uksi/2023/38/pdfs/uksi_20230038_en.pdf",
  "quote_method": "Own 16 November correction read of the named operative scope; exact source-language fragments. Source-capture dates retained separately.",
  "read_date": "2026-11-16",
  "source_key": "uk",
  "status": "SOURCE READ; independent review pending"
}
```

### R075

Onlyoriginalformatserved,notrevised2026consolidation

```json
{
  "act_article": "Officialversionstatus",
  "guide_group": "D48",
  "guide_lines": [
    151
  ],
  "id": "R075",
  "native_quote_fragments": [
    "This is the original version (as it was originally made). This item of legislation is currently only available in its original format."
  ],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.legislation.gov.uk/uksi/2023/38/contents",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "ukcurrent",
  "status": "SOURCE READ; independent review pending"
}
```

### R076

UKnexus,knowledgepossessioncontrol

```json
{
  "act_article": "reg3(1)–(2)",
  "guide_group": "D49",
  "guide_lines": [
    154
  ],
  "id": "R076",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.legislation.gov.uk/uksi/2023/38/pdfs/uksi_20230038_en.pdf",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "uk",
  "status": "SOURCE READ; independent review pending"
}
```

### R077

Intermediary30dayafteravailabilityorservices

```json
{
  "act_article": "reg4",
  "guide_group": "D49",
  "guide_lines": [
    154
  ],
  "id": "R077",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.legislation.gov.uk/uksi/2023/38/pdfs/uksi_20230038_en.pdf",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "uk",
  "status": "SOURCE READ; independent review pending"
}
```

### R078

Extentprivilege,clientwrittennoticebydeadline,Scotland

```json
{
  "act_article": "reg5",
  "guide_group": "D49",
  "guide_lines": [
    154
  ],
  "id": "R078",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.legislation.gov.uk/uksi/2023/38/pdfs/uksi_20230038_en.pdf",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "uk",
  "status": "SOURCE READ; independent review pending"
}
```

### R079

Documentedduplicateandpartnerjurisdictionexceptions

```json
{
  "act_article": "reg6",
  "guide_group": "D49",
  "guide_lines": [
    154
  ],
  "id": "R079",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.legislation.gov.uk/uksi/2023/38/pdfs/uksi_20230038_en.pdf",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "uk",
  "status": "SOURCE READ; independent review pending"
}
```

### R080

UKresidentreportabletaxpayerrole,exceptionsandfirststepclock

```json
{
  "act_article": "reg7",
  "guide_group": "D49",
  "guide_lines": [
    154
  ],
  "id": "R080",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.legislation.gov.uk/uksi/2023/38/pdfs/uksi_20230038_en.pdf",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "uk",
  "status": "SOURCE READ; independent review pending"
}
```

### R081

Writtennoticefactofreturn,notreference,30daysbeginningreturnday

```json
{
  "act_article": "reg9",
  "guide_group": "D49",
  "guide_lines": [
    154
  ],
  "id": "R081",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.legislation.gov.uk/uksi/2023/38/pdfs/uksi_20230038_en.pdf",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "uk",
  "status": "SOURCE READ; independent review pending"
}
```

### R082

UKpromoter/CRSbacklog,dates,USD1mstrictgate,priorduplicate,FX

```json
{
  "act_article": "reg8",
  "guide_group": "D50",
  "guide_lines": [
    157
  ],
  "id": "R082",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.legislation.gov.uk/uksi/2023/38/pdfs/uksi_20230038_en.pdf",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "uk",
  "status": "SOURCE READ; independent review pending"
}
```

### R083

Modelhistoricaldate/deadlinearecomparisononly

```json
{
  "act_article": "Model2.7(a)–(b),printed22",
  "guide_group": "D50",
  "guide_lines": [
    157
  ],
  "id": "R083",
  "native_quote_fragments": [
    "A Promoter shall disclose a CRS Avoidance Arrangement within 180 days"
  ],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.oecd.org/content/dam/oecd/en/publications/reports/2018/03/model-mandatory-disclosure-rules-for-addressing-crs-avoidance-arrangements-and-opaque-offshore-structures_1d2a819d/e3cabd80-en.pdf",
  "own_condition_paraphrase": "Model comparison only. Rule2.7(a) ties the180days to effective date and a CRS avoidance arrangement implemented from29October2014 before effectiveness, where the person was its promoter, irrespective of later relevant services. Rule2.7(b) exempts documented aggregate financial-account balance/value immediately before implementation belowUSD1million. Rule2.7(c) uses the2014CRS interpretation. UKreg8 instead supplies operative UK dates/exceptions; do not substitute model dates.",
  "quote_method": "Own 16 November correction read of the named operative scope; exact source-language fragments. Source-capture dates retained separately.",
  "read_date": "2026-11-16",
  "source_key": "oecd",
  "status": "SOURCE READ; independent review pending"
}
```

### R084

Modelrequiresnationaladoption;notworldwideoperativefilinglaw

```json
{
  "act_article": "Model2.1/2.6,nationalplaceholders",
  "guide_group": "D51",
  "guide_lines": [
    160
  ],
  "id": "R084",
  "native_quote_fragments": [
    "to the tax authorities in [Jurisdiction Name]"
  ],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.oecd.org/content/dam/oecd/en/publications/reports/2018/03/model-mandatory-disclosure-rules-for-addressing-crs-avoidance-arrangements-and-opaque-offshore-structures_1d2a819d/e3cabd80-en.pdf",
  "own_condition_paraphrase": "Model2.1 imposes intermediary disclosure on the adopting jurisdiction branch-services/availability, residence/place-of-management, or incorporation/establishment connections. Model2.6 imposes residual disclosure on its resident user/beneficial-owner taxpayer if intermediary is outside2.1 or protected by2.4, with documented substantially-similar partner-jurisdiction disclosure exception;2.3information and30days after first implementation. These national placeholders demonstrate that the model is not itself worldwide filing legislation. Actual entire2.1/2.6 read; permitted short extract only, no full-paragraph reproduction claim.",
  "quote_method": "Own 16 November correction read of the named operative scope; exact source-language fragments. Source-capture dates retained separately.",
  "read_date": "2026-11-16",
  "source_key": "oecd",
  "status": "SOURCE READ; independent review pending"
}
```

### R085

Mexicostatute/advisernexus/taxbenefit/exchangeavoidancewithforeignproof

```json
{
  "act_article": "CFF197 adviser definition, national nexus, foreign-adviser rebuttable presumptions and Mexican-benefit gate; CFF199 opening/I separately assigned",
  "guide_group": "D52",
  "guide_lines": [
    169
  ],
  "id": "R085",
  "native_quote_fragments": [
    "Artículo 197. Los asesores fiscales se encuentran obligados a revelar los esquemas reportables generalizados y personalizados a que se refiere este Capítulo al Servicio de"
  ],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.diputados.gob.mx/LeyesBiblio/pdf/CFF.pdf",
  "quote_method": "Own 16 November correction read of the named operative scope; exact source-language fragments. Source-capture dates retained separately.",
  "read_date": "2026-11-16",
  "source_key": "mxcurrent",
  "status": "SOURCE READ; independent review pending"
}
```

### R086

Mexicanbenefitplusfeature,exchangefeatureexception

```json
{
  "act_article": "CFF199opening/I",
  "guide_group": "D52",
  "guide_lines": [
    169
  ],
  "id": "R086",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.diputados.gob.mx/LeyesBiblio/pdf/CFF.pdf",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "mxcurrent",
  "status": "SOURCE READ; independent review pending"
}
```

### R087

RG4838repeal/substitutionandoriginaleffectiveperiod

```json
{
  "act_article": "RG5306arts9–10",
  "guide_group": "D53",
  "guide_lines": [
    172
  ],
  "id": "R087",
  "native_quote_fragments": [
    "ARTÍCULO 9°.- Dejar sin efecto la Resolución General N° 4.838 y sus complementarias. ARTÍCULO 10.- Las disposiciones establecidas por esta resolución general entrarán en vigencia"
  ],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.argentina.gob.ar/normativa/nacional/resoluci%C3%B3n-5306-2022-377151/texto",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "ar5306",
  "status": "SOURCE READ; independent review pending"
}
```

### R088

SeparateRICOIscope/taxpayers/SMEexception/exchangefeatures

```json
{
  "act_article": "Original RG5306 arts1–3(d) and5 annual filing condition; current2026overlay expressly held",
  "guide_group": "D53",
  "guide_lines": [
    172
  ],
  "id": "R088",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.argentina.gob.ar/normativa/nacional/resoluci%C3%B3n-5306-2022-377151/texto",
  "quote_method": "Own 16 November correction read of the named operative scope; exact source-language fragments. Source-capture dates retained separately.",
  "read_date": "2026-11-16",
  "source_key": "ar5306",
  "status": "SOURCE READ; independent review pending"
}
```

### R089

RTPcompanyschedule/scope andcriteria

```json
{
  "act_article": "Actual ATO14October2026 public PDF, scope and CategoriesA/B, pp10–11",
  "guide_group": "D54",
  "guide_lines": [
    175
  ],
  "id": "R089",
  "native_quote_fragments": [
    "The Reportable tax position (RTP) schedule is a schedule to the Company tax return. It gathers information on uncertain tax positions from the largest companies."
  ],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://caat-p-001.sitecorecontenthub.cloud/api/public/content/0-643fc4e2-ea95-4c3e-93c2-cab5cc6c81a7",
  "quote_method": "Own 16 November correction read of the named operative scope; exact source-language fragments. Source-capture dates retained separately.",
  "read_date": "2026-11-16",
  "source_key": "aurtp",
  "status": "SOURCE READ; independent review pending"
}
```

### R090

SpecificconcernsandPCGriskratings,separatefromMDR

```json
{
  "act_article": "Actual ATO14October2026 public PDF, CategoriesA–C, pp10–11",
  "guide_group": "D54",
  "guide_lines": [
    175
  ],
  "id": "R090",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://caat-p-001.sitecorecontenthub.cloud/api/public/content/0-643fc4e2-ea95-4c3e-93c2-cab5cc6c81a7",
  "quote_method": "Own 16 November correction read of the named operative scope; exact source-language fragments. Source-capture dates retained separately.",
  "read_date": "2026-11-16",
  "source_key": "aurtp",
  "status": "SOURCE READ; independent review pending"
}
```

### R091

Canadianreportabletransactionownhallmarkconditions

```json
{
  "act_article": "ITA237.3(1), complete reportable-transaction definition(a)–(c), including confidential-protection and contractual-protection limbs",
  "guide_group": "D55",
  "guide_lines": [
    178
  ],
  "id": "R091",
  "native_quote_fragments": [
    "reportable transaction, at any time, means an avoidance transaction that is entered into by or for the benefit of a person, and each transaction that"
  ],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://laws-lois.justice.gc.ca/eng/acts/I-3.3/section-237.3.html",
  "quote_method": "Own 16 November correction read of the named operative scope; exact source-language fragments. Source-capture dates retained separately.",
  "read_date": "2026-11-16",
  "source_key": "calaw3",
  "status": "SOURCE READ; independent review pending"
}
```

### R092

CanadianMinisterdesignatedsame/substantiallysimilartransactions

```json
{
  "act_article": "ITA237.4(1) definition plus complete(2) substantial-similarity interpretation and(3) Minister/Finance concurrence designation",
  "guide_group": "D55",
  "guide_lines": [
    178
  ],
  "id": "R092",
  "native_quote_fragments": [
    "notifiable transaction, at any time, means (a) a transaction that is the same as, or substantially similar to, a transaction that is designated at that"
  ],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://laws-lois.justice.gc.ca/eng/acts/I-3.3/section-237.4.html",
  "quote_method": "Own 16 November correction read of the named operative scope; exact source-language fragments. Source-capture dates retained separately.",
  "read_date": "2026-11-16",
  "source_key": "calaw4",
  "status": "SOURCE READ; independent review pending"
}
```

### R093

Canadian237.3–5separateregimes

```json
{
  "act_article": "CRAoverview",
  "guide_group": "D55",
  "guide_lines": [
    178
  ],
  "id": "R093",
  "native_quote_fragments": [
    "These rules (Income Tax Act sections 237.3 to 237.5) consist of: changes to existing reportable transaction rules a new rule to report notifiable transactions a"
  ],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.canada.ca/en/revenue-agency/programs/about-canada-revenue-agency-cra/compliance/mandatory-disclosure-rules-overview.html",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "caguide",
  "status": "SOURCE READ; independent review pending"
}
```

### R094

SouthAfricaTAA34–39route/exclusions

```json
{
  "act_article": "Actual SARS reportable-arrangements guide sections3–8:35criteria/36exclusions,37/38procedures,RA01route and data; not full underlying TAA statutory clearance",
  "guide_group": "D56",
  "guide_lines": [
    181
  ],
  "id": "R094",
  "native_quote_fragments": [
    "Sections 34 to 39 of the TAA establish the framework for identifying and disclosing reportable arrangements. Sections 37 and 38 require each participant who derives"
  ],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.sars.gov.za/guide-to-reportable-arrangement/",
  "quote_method": "Own 16 November correction read of the named operative scope; exact source-language fragments. Source-capture dates retained separately.",
  "read_date": "2026-11-16",
  "source_key": "saguideweb",
  "status": "SOURCE READ; independent review pending"
}
```

### R095

Contacttrusteeregistration/ongoingdisclosure/annualreturnexemptionconditions

```json
{
  "act_article": "IRforeignexemptiontrusts,scope",
  "guide_group": "D57",
  "guide_lines": [
    184
  ],
  "id": "R095",
  "native_quote_fragments": [
    "For the NZFT to receive a tax exemption for foreign-sourced income, the contact trustee must: * register the NZFT with us * comply with ongoing"
  ],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.ird.govt.nz/international-tax/foreign-exemption-trusts",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "nztrust",
  "status": "SOURCE READ; independent review pending"
}
```

### R096

Intentionalorrecklessculpability

```json
{
  "act_article": "AO379opening",
  "guide_group": "D59",
  "guide_lines": [
    194
  ],
  "id": "R096",
  "native_quote_fragments": [
    "Ordnungswidrig handelt, wer vorsätzlich oder leichtfertig"
  ],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.gesetze-im-internet.de/ao_1977/__379.html",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "de379",
  "status": "SOURCE READ; independent review pending"
}
```

### R097

CoveredDAC6failures

```json
{
  "act_article": "AO379(2)1e/1g",
  "guide_group": "D59",
  "guide_lines": [
    194
  ],
  "id": "R097",
  "native_quote_fragments": [
    "1e. entgegen § 138d Absatz 1 in Verbindung mit § 138f Absatz 1, 2, 3 Satz 1 Nummer 1"
  ],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.gesetze-im-internet.de/ao_1977/__379.html",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "de379",
  "status": "SOURCE READ; independent review pending"
}
```

### R098

25000ceilingands378priority

```json
{
  "act_article": "AO379(7)",
  "guide_group": "D59",
  "guide_lines": [
    194
  ],
  "id": "R098",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.gesetze-im-internet.de/ao_1977/__379.html",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "de379",
  "status": "SOURCE READ; independent review pending"
}
```

### R099

French10000/5000firstin3prioryears/100000annualcap/scopeexclusion

```json
{
  "act_article": "CGI1729Cter,entirearticle",
  "guide_group": "D60",
  "guide_lines": [
    197
  ],
  "id": "R099",
  "native_quote_fragments": [
    "Les manquements à une obligation de déclaration ou de notification prévue aux articles 1649 AD, 1649 AE et 1649 AG entraînent l'application d'une amende qui"
  ],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000039250301/2999-01-01",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "frpen",
  "status": "SOURCE READ; independent review pending"
}
```

### R100

Omissionplus50/inaccuracyminus50crossreference

```json
{
  "act_article": "D.Lgs100/2020art12(1)–(2)",
  "guide_group": "D61",
  "guide_lines": [
    200
  ],
  "id": "R100",
  "native_quote_fragments": [
    "1. Nei casi di omessa comunicazione delle informazioni di cui all'articolo 6 si applica la sanzione amministrativa pecuniaria prevista dall'articolo 10, comma 1, del decreto"
  ],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.legislativo:2020-07-30;100!vig=~art12",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "it12",
  "status": "SOURCE READ; independent review pending"
}
```

### R101

1500–15000base/15dayreduction

```json
{
  "act_article": "Current471/1997art10(1)",
  "guide_group": "D61",
  "guide_lines": [
    200
  ],
  "id": "R101",
  "native_quote_fragments": [
    "1. Se viene omessa la trasmissione dei dati, delle notizie e dei documenti richiesti ai sensi dell'articolo 32, primo comma, numero 7, del decreto del"
  ],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.legislativo:1997-12-18;471!vig=~art10",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "it471",
  "status": "SOURCE READ; independent review pending"
}
```

### R102

Violationdatefrom1Sep2024transition

```json
{
  "act_article": "87/2024art5(1)",
  "guide_group": "D61",
  "guide_lines": [
    200
  ],
  "id": "R102",
  "native_quote_fragments": [
    "1. Le disposizioni di cui agli articoli 2, 3 ((a esclusione del comma 1, lettera o),)) e 4 si applicano alle violazioni commesse a partire"
  ],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.legislativo:2024-06-14;87!vig=~art5",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "it87",
  "status": "SOURCE READ; independent review pending"
}
```

### R103

Intent/grossnegligence/nontimelyincompleteincorrect/category6ceiling

```json
{
  "act_article": "WIB11(2)",
  "guide_group": "D62",
  "guide_lines": [
    203
  ],
  "id": "R103",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://wetten.overheid.nl/BWBR0003954",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "nllatest",
  "status": "SOURCE READ; independent review pending"
}
```

### R104

2026category6amount1100000,indexing

```json
{
  "act_article": "WvS23(4),(9),2026annotation",
  "guide_group": "D62",
  "guide_lines": [
    203
  ],
  "id": "R104",
  "native_quote_fragments": [
    "de zesde categorie, € 670 000 [Red: Per 1 januari 2026: € 1.100.000.] ."
  ],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://wetten.overheid.nl/BWBR0001854/2026-01-01#BoekEerste_TiteldeelII_Artikel23",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "nl23",
  "status": "SOURCE READ; independent review pending"
}
```

### R105

Failure-specificSpanishunits/minmax/latehalving/electronicmedium/exceptions

```json
{
  "act_article": "LGTDA23(4)(a)–(d)",
  "guide_group": "D63",
  "guide_lines": [
    206
  ],
  "id": "R105",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.boe.es/eli/es/l/2003/12/17/58/con",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "eslaw",
  "status": "SOURCE READ; independent review pending"
}
```

### R106

Notification600andqualifiedaggravation

```json
{
  "act_article": "LGTDA24(3)(a)–(b)",
  "guide_group": "D63",
  "guide_lines": [
    206
  ],
  "id": "R106",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.boe.es/eli/es/l/2003/12/17/58/con",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "eslaw",
  "status": "SOURCE READ; independent review pending"
}
```

### R107

Irish4000+100/500daily/5000annual/courtdeterminationandfactors

```json
{
  "act_article": "March2026manual6.1–6.2,TCA817RH",
  "guide_group": "D64",
  "guide_lines": [
    209
  ],
  "id": "R107",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.revenue.ie/en/tax-professionals/tdm/income-tax-capital-gains-tax-corporation-tax/part-33/33-03-03.pdf",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "iecurrent",
  "status": "SOURCE READ; independent review pending"
}
```

### R108

250000max,competentdecision,judicialrecourse

```json
{
  "act_article": "Originalarticle15(1)–(3)",
  "guide_group": "D65",
  "guide_lines": [
    212
  ],
  "id": "R108",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://legilux.public.lu/filestore/eli/etat/leg/loi/2020/03/25/a192/jo/fr/pdfa/eli-etat-leg-loi-2020-03-25-a192-jo-fr-pdfa.pdf",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "lulaw",
  "status": "SOURCE READ; independent review pending"
}
```

### R109

Current250000summaryconfirmsidentifiedfailures

```json
{
  "act_article": "CurrentACD7",
  "guide_group": "D65",
  "guide_lines": [
    212
  ],
  "id": "R109",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://impotsdirects.public.lu/fr/echanges_electroniques/dispositifstransfrontieres.html",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "lupage",
  "status": "SOURCE READ; independent review pending"
}
```

### R110

5000ORqualified600/day,notificationdistinction,continuation

```json
{
  "act_article": "reg13(1)–(3)",
  "guide_group": "D66",
  "guide_lines": [
    215
  ],
  "id": "R110",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.legislation.gov.uk/uksi/2023/38/pdfs/uksi_20230038_en.pdf",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "uk",
  "status": "SOURCE READ; independent review pending"
}
```

### R111

Tribunalhigherpenaltymax1mnotdeliberateonly

```json
{
  "act_article": "reg15(5)",
  "guide_group": "D66",
  "guide_lines": [
    215
  ],
  "id": "R111",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.legislation.gov.uk/uksi/2023/38/pdfs/uksi_20230038_en.pdf",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "uk",
  "status": "SOURCE READ; independent review pending"
}
```

### R112

Specialcircumstancesandreasonableexcuse

```json
{
  "act_article": "regs19–20",
  "guide_group": "D66",
  "guide_lines": [
    215
  ],
  "id": "R112",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.legislation.gov.uk/uksi/2023/38/pdfs/uksi_20230038_en.pdf",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "uk",
  "status": "SOURCE READ; independent review pending"
}
```

### R113

Currenthandbook8May2026basis

```json
{
  "act_article": "2026handbookcover/version1.1",
  "guide_group": "D70",
  "guide_lines": [
    280
  ],
  "id": "R113",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.bzst.de/SharedDocs/Downloads/DE/DAC6/KHB/khb_dac6_bop.pdf?__blob=publicationFile&v=23",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "dehandbook",
  "status": "SOURCE READ; independent review pending"
}
```

### R114

NewBOPform/XMLupload/DIP,registrationroutes

```json
{
  "act_article": "1.4/1.4.1–1.4.3",
  "guide_group": "D70",
  "guide_lines": [
    280
  ],
  "id": "R114",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.bzst.de/SharedDocs/Downloads/DE/DAC6/KHB/khb_dac6_bop.pdf?__blob=publicationFile&v=23",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "dehandbook",
  "status": "SOURCE READ; independent review pending"
}
```

### R115

CurrentXMLpayload1.07/ISO1.01

```json
{
  "act_article": "1.4.2",
  "guide_group": "D70",
  "guide_lines": [
    280
  ],
  "id": "R115",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.bzst.de/SharedDocs/Downloads/DE/DAC6/KHB/khb_dac6_bop.pdf?__blob=publicationFile&v=23",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "dehandbook",
  "status": "SOURCE READ; independent review pending"
}
```

### R116

ProfessionalspaceXML,nationalvalidation

```json
{
  "act_article": "EDIcurrentroute",
  "guide_group": "D70",
  "guide_lines": [
    280
  ],
  "id": "R116",
  "native_quote_fragments": [
    "Le dépôt EDI permet de souscrire la déclaration via le dépôt d'un fichier xml depuis l'espace professionnel. Ce mode de dépôt est ouvert uniquement aux"
  ],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.impots.gouv.fr/cahier-des-charges?l=fr",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "frfiling",
  "status": "SOURCE READ; independent review pending"
}
```

### R117

From3Sep2026spec4.0/XSD4.05

```json
{
  "act_article": "Versionperiodsfor2026filing",
  "guide_group": "D70",
  "guide_lines": [
    280
  ],
  "id": "R117",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.impots.gouv.fr/cahier-des-charges?l=fr",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "frfiling",
  "status": "SOURCE READ; independent review pending"
}
```

### R118

ROSregistration,reportingentity,form/XML/amend

```json
{
  "act_article": "CurrentRevenuefilingpage",
  "guide_group": "D70",
  "guide_lines": [
    280
  ],
  "id": "R118",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.revenue.ie/en/companies-and-charities/international-tax/aeoi/dac6/file-dac6.aspx",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "iefiling",
  "status": "SOURCE READ; independent review pending"
}
```

### R119

MDRIDregistrationidentifier

```json
{
  "act_article": "HMRCregistration",
  "guide_group": "D70",
  "guide_lines": [
    280
  ],
  "id": "R119",
  "native_quote_fragments": [
    "Once you’ve registered, you’ll get a: MDR ID confirmation email You’ll need this MDR ID to report your cross-border arrangements."
  ],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.gov.uk/guidance/register-to-report-a-cross-border-arrangement-mdr",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "ukregister",
  "status": "SOURCE READ; independent review pending"
}
```

### R120

XMLschema,filevalidationstatus,correction/deletion

```json
{
  "act_article": "HMRCreport/correctionprocedure",
  "guide_group": "D70",
  "guide_lines": [
    280
  ],
  "id": "R120",
  "native_quote_fragments": [
    "You’ll be able to upload an XML file containing the reportable information. If you’re uploading an XML file, you should use the schema and supporting"
  ],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.gov.uk/guidance/report-a-cross-border-arrangement-to-hmrc-mdr",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "ukreport",
  "status": "SOURCE READ; independent review pending"
}
```

### R121

Authoring scope/year/source-version basis;not professional orfilingapproval

```json
{
  "act_article": "See specific operative supporting rows for identifiedrule;noindependent statutoryrateinvented",
  "guide_group": "D01",
  "guide_lines": [
    22
  ],
  "id": "R121",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": null,
  "read_date": "2026-11-15",
  "source_key": null,
  "status": "AUTHOR METHOD;independentreviewpending"
}
```

### R122

Swissoriginalassertionsindividuallyreserved afterfailedprimaryaccess/search;EUconnectionroute retained

```json
{
  "act_article": "No operativecurrentSwissclaimcleared",
  "guide_group": "D58",
  "guide_lines": [
    187
  ],
  "id": "R122",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": null,
  "read_date": "2026-11-15",
  "source_key": null,
  "status": "UNCONFIRMED ORIGINAL CLAIMS;independentreviewpending"
}
```

### R123

E3strictcomparisondecision:500000equalityvs490000below,annualprojectionsidentical3years

```json
{
  "act_article": "See specific operative supporting rows for identifiedrule;noindependent statutoryrateinvented",
  "guide_group": "D67",
  "guide_lines": [
    222
  ],
  "id": "R123",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": null,
  "read_date": "2026-11-15",
  "source_key": null,
  "status": "DERIVED WORKED CASE;independentreviewpending"
}
```

### R124

Italy1500–15000times1.5/0.5gives2250–22500/750–7500

```json
{
  "act_article": "See specific operative supporting rows for identifiedrule;noindependent statutoryrateinvented",
  "guide_group": "D68",
  "guide_lines": [
    247
  ],
  "id": "R124",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": null,
  "read_date": "2026-11-15",
  "source_key": null,
  "status": "DERIVED WORKED CASE;independentreviewpending"
}
```

### R125

CorrectC1MBTboundaryandprerequisites;separateUKscope;duplicatesrequireproof

```json
{
  "act_article": "See specific operative supporting rows for identifiedrule;noindependent statutoryrateinvented",
  "guide_group": "D69",
  "guide_lines": [
    267
  ],
  "id": "R125",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": null,
  "read_date": "2026-11-15",
  "source_key": null,
  "status": "DERIVED CLASSIFICATION CHECK;independentreviewpending"
}
```

### R126

2026-01-01EUsourceversionbasis

```json
{
  "act_article": "Consolidationheader",
  "guide_group": "D01",
  "guide_lines": [
    22
  ],
  "id": "R126",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "dac",
  "status": "SOURCE READ; independent review pending"
}
```

### R127

UKCRSavoidance/opaqueoffshorescopeandmodelincorporation

```json
{
  "act_article": "IEIM710010,currentmanual15Oct2026",
  "guide_group": "D48",
  "guide_lines": [
    151
  ],
  "id": "R127",
  "native_quote_fragments": [
    "These rules introduce new obligations on taxpayers and their advisers to report Common Reporting Standard (CRS) Avoidance Arrangements and Opaque Offshore Structures. HMRC will share"
  ],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.gov.uk/hmrc-internal-manuals/international-exchange-of-information/ieim710010",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "hmrc",
  "status": "SOURCE READ; independent review pending"
}
```

### R128

MyGuichetmanual/XMLfilingroute

```json
{
  "act_article": "ACD9",
  "guide_group": "D70",
  "guide_lines": [
    280
  ],
  "id": "R128",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://impotsdirects.public.lu/fr/echanges_electroniques/dispositifstransfrontieres.html",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "lupage",
  "status": "SOURCE READ; independent review pending"
}
```

### R129

Actualamendmentchanges2000–21000to1500–15000;art5appliesart2from1Sep2024

```json
{
  "act_article": "D.Lgs87/2024art2(1)(g)",
  "guide_group": "D61",
  "guide_lines": [
    200
  ],
  "id": "R129",
  "native_quote_fragments": [
    "g) all'articolo 10: 1) al comma 1, primo periodo, le parole: «da euro 2.000 a euro 21.000» sono sostituite dalle seguenti: «da euro 1.500 a"
  ],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.legislativo:2024-06-14;87!vig=~art2",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "it87art2",
  "status": "SOURCE READ; independent review pending"
}
```

### R130

Originalstatutoryfailure-specificpenalties,courtdetermination,andfee/taxadvantagefactors

```json
{
  "act_article": "FinanceAct2019s67,inserted817RH(1)–(7);originalenactmentreadwithcurrentmanual",
  "guide_group": "D64",
  "guide_lines": [
    209
  ],
  "id": "R130",
  "native_quote_fragments": [
    "817RH.(1) A person who fails to comply with any of the obligations imposed on such person by this Chapter shall— (a) where the failure relates"
  ],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.irishstatutebook.ie/eli/2019/act/45/enacted/en/print",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "ielaw",
  "status": "SOURCE READ; independent review pending"
}
```

### R131

ActualATOsourceversion14October2026

```json
{
  "act_article": "ATOQC21312publicationheader",
  "guide_group": "D54",
  "guide_lines": [
    175
  ],
  "id": "R131",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://caat-p-001.sitecorecontenthub.cloud/api/public/content/0-643fc4e2-ea95-4c3e-93c2-cab5cc6c81a7",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "aurtp",
  "status": "SOURCE READ; independent review pending"
}
```

### R132

ActualCanadianconsolidationcurrent19October2026,lastamended18June2026

```json
{
  "act_article": "JusticeLawsconsolidationheader",
  "guide_group": "D55",
  "guide_lines": [
    178
  ],
  "id": "R132",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://laws-lois.justice.gc.ca/eng/acts/I-3.3/section-237.3.html",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "calaw3",
  "status": "SOURCE READ; independent review pending"
}
```

### R133

ActualMexicanCodeamendmentbasis9April2026

```json
{
  "act_article": "CFFpublicationheader",
  "guide_group": "D52",
  "guide_lines": [
    169
  ],
  "id": "R133",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.diputados.gob.mx/LeyesBiblio/pdf/CFF.pdf",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "mxcurrent",
  "status": "SOURCE READ; independent review pending"
}
```

### R134

ActualRevenueMarch2026manualversion

```json
{
  "act_article": "CurrentRevenueTDMcover",
  "guide_group": "D40",
  "guide_lines": [
    125
  ],
  "id": "R134",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.revenue.ie/en/tax-professionals/tdm/income-tax-capital-gains-tax-corporation-tax/part-33/33-03-03.pdf",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "iecurrent",
  "status": "SOURCE READ; independent review pending"
}
```

### R135

ActualFrencharticleeffective16February2025

```json
{
  "act_article": "CGI1649AEversionheader",
  "guide_group": "D39",
  "guide_lines": [
    122
  ],
  "id": "R135",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000051215679/2025-02-16",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "fr1649",
  "status": "SOURCE READ; independent review pending"
}
```

### R136

ActualBOFiPversion23September2026

```json
{
  "act_article": "BOFiPpublicationheader",
  "guide_group": "D39",
  "guide_lines": [
    122
  ],
  "id": "R136",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://bofip.impots.gouv.fr/bofip/12275-PGP.html/identifiant=BOI-CF-CPF-30-40-10-20-20260923",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "frguide",
  "status": "SOURCE READ; independent review pending"
}
```

### R137

ActualHMRCmanualupdated15October2026

```json
{
  "act_article": "HMRCmanualversionheader",
  "guide_group": "D48",
  "guide_lines": [
    151
  ],
  "id": "R137",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.gov.uk/hmrc-internal-manuals/international-exchange-of-information/ieim710010",
  "quote_method": "Exact separately delimited operative native fragments; layout whitespace/hyperlink decorations normalized. No generic inherited anchor.",
  "read_date": "2026-11-15",
  "source_key": "hmrc",
  "status": "SOURCE READ; independent review pending"
}
```

### R138

Auxiliary-intermediary completion/awareness qualification and optional early reporting

```json
{
  "act_article": "C-623/22 paragraphs82–86 with81/87neighbors",
  "guide_group": "D32",
  "guide_lines": [
    99
  ],
  "id": "R138",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://publications.europa.eu/resource/celex/62022CJ0623",
  "quote_method": "Own actual correction read; exact source-language extracts, normalized layout whitespace.",
  "read_date": "2026-11-16",
  "source_key": "case623",
  "status": "SOURCE READ; independent delta review pending"
}
```

### R139

Employee exclusion and employer/connected-employer definitions

```json
{
  "act_article": "SI2023/38 regulation12(1)–(4), complete",
  "guide_group": "D49",
  "guide_lines": [
    154
  ],
  "id": "R139",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.legislation.gov.uk/uksi/2023/38/pdfs/uksi_20230038_en.pdf",
  "quote_method": "Own actual correction read; exact source-language extracts, normalized layout whitespace.",
  "read_date": "2026-11-16",
  "source_key": "uk",
  "status": "SOURCE READ; independent delta review pending"
}
```

### R140

Exclude identification of privileged intermediary

```json
{
  "act_article": "WIB10h(2)(a), complete identity limb with opening",
  "guide_group": "D41",
  "guide_lines": [
    128
  ],
  "id": "R140",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://wetten.overheid.nl/BWBR0003954",
  "quote_method": "Own actual correction read; exact source-language extracts, normalized layout whitespace.",
  "read_date": "2026-11-16",
  "source_key": "nllatest",
  "status": "SOURCE READ; independent delta review pending"
}
```

### R141

Mexican taxpayer fallback circumstances and covered persons

```json
{
  "act_article": "CFF198 complete I–VI and taxpayer/nexus closing paragraphs",
  "guide_group": "D52",
  "guide_lines": [
    169
  ],
  "id": "R141",
  "native_quote_fragments": [],
  "native_quote_fragments_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "official_url": "https://www.diputados.gob.mx/LeyesBiblio/pdf/CFF.pdf",
  "quote_method": "Own actual correction read; exact source-language extracts, normalized layout whitespace.",
  "read_date": "2026-11-16",
  "source_key": "mxcurrent",
  "status": "SOURCE READ; independent delta review pending"
}
```

## Original-topic destinations

The complete original-topic destination table is in `../dac6-mdr-reportable-arrangements/old-topic-map.json`.
