# free-zones-sez-matrix figure and rule ledger

Public projection; canonical private SHA256: `abaab9daef8b62cbf0e255b63cbaf76b6109dbc505068fecbb8128aff591a71b`. Complete captured/native source passages remain local. The JSON companion preserves every retained evidence field.

## Whole rule groups

### R0001

# Free Zones SEZ Matrix v0.2

```json
{
  "context_only_blocks": [],
  "current_lines": [
    17,
    17
  ],
  "id": "R0001",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "# Free Zones SEZ Matrix v0.2",
      "id": "R0001.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    16
  ],
  "section": "Free Zones SEZ Matrix v0.2",
  "source_read_record": null,
  "status": "heading"
}
```

### R0002

> **General reference only.** This skill is general tax/accounting reference material for AI-assisted workflows. It has not been reviewed for any specific person's facts, documents, elections, deadlines, residency, filing status, or local procedures. Do not rely on it to file, pay, amend, or take a tax position without review by a qualified professional in the relevant jurisdiction.

```json
{
  "context_only_blocks": [],
  "current_lines": [
    19,
    19
  ],
  "id": "R0002",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "> **General reference only.** This skill is general tax/accounting reference material for AI-assisted workflows.",
      "id": "R0002.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "It has not been reviewed for any specific person's facts, documents, elections, deadlines, residency, filing status, or local procedures.",
      "id": "R0002.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Do not rely on it to file, pay, amend, or take a tax position without review by a qualified professional in the relevant jurisdiction.",
      "id": "R0002.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Free Zones SEZ Matrix v0.2",
  "source_read_record": null,
  "status": "scope/workflow/refusal/protected disclaimer; no new statutory assertion"
}
```

### R0003

## What this Guide covers

```json
{
  "context_only_blocks": [],
  "current_lines": [
    21,
    21
  ],
  "id": "R0003",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "## What this Guide covers",
      "id": "R0003.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    18
  ],
  "section": "What this Guide covers",
  "source_read_record": null,
  "status": "heading"
}
```

### R0004

Load `cross-border-workflow-base` first. This comparison and research method preserves the original shortlist of free zones, special economic zones, free trade zones and financial centres, using selected sources read **16 November 2026**. A zone, offshore company form or licence is not itself a tax exemption. QFC is in Qatar, not the UAE.

```json
{
  "context_only_blocks": [],
  "current_lines": [
    23,
    23
  ],
  "id": "R0004",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Load `cross-border-workflow-base` first.",
      "id": "R0004.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "This comparison and research method preserves the original shortlist of free zones, special economic zones, free trade zones and financial centres, using selected sources read **16 November 2026**.",
      "id": "R0004.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "A zone, offshore company form or licence is not itself a tax exemption.",
      "id": "R0004.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "QFC is in Qatar, not the UAE.",
      "id": "R0004.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    20,
    22,
    52
  ],
  "section": "What this Guide covers",
  "source_read_record": null,
  "status": "scope/workflow/refusal/protected disclaimer; no new statutory assertion"
}
```

### R0005

Use the dated rules and individual limitations below for 2026, including the UAE replacements for MD 139/2023/265/2023, Saudi’s current distinction between geographic and cloud SEZs, Hainan/Qianhai extensions through 2027, India’s 2026 IFSC changes, and the current domestic minimum-tax overlays. A headline below 15% does not by itself determine a Pillar Two liability. [uae-229](<https://tax.gov.ae/datafolder/Files/Pdf/2025/MD-No-229.pdf>); [sa-sez-current](<https://zatca.gov.sa/en/HelpCenter/guidelines/Documents/SEZ-Tax%26Customs-Procedures.pdf>); [hainan-extension](<https://policy.mofcom.gov.cn/claw/clawContent.shtml?id=103253>); [qianhai-extension](<https://www.tid.gov.hk/en/tradecircular/files/2026/ci1712026a.pdf>); [india-fa2026](<https://egazette.gov.in/WriteReadData/2026/271439.pdf>); [oecd-global](<https://www.oecd.org/en/topics/global-minimum-tax.html>).

```json
{
  "context_only_blocks": [],
  "current_lines": [
    25,
    25
  ],
  "id": "R0005",
  "individual_subclaims": [
    {
      "bindings": [
        "uae-229:repeal-application",
        "sa-sez-current:income-wht",
        "hainan-extension:extension",
        "qianhai-extension:extension",
        "india-fa2026:IFSC",
        "oecd-global:overview"
      ],
      "claim": "Use the dated rules and individual limitations below for 2026, including the UAE replacements for MD 139/2023/265/2023, Saudi’s current distinction between geographic and cloud SEZs, Hainan/Qianhai extensions through 2027, India’s 2026 IFSC changes, and the current domestic minimum-tax overlays.",
      "id": "R0005.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-229:repeal-application",
        "sa-sez-current:income-wht",
        "hainan-extension:extension",
        "qianhai-extension:extension",
        "india-fa2026:IFSC",
        "oecd-global:overview"
      ],
      "claim": "A headline below 15% does not by itself determine a Pillar Two liability. [uae-229](<https://tax.gov.ae/datafolder/Files/Pdf/2025/MD-No-229.pdf>)",
      "id": "R0005.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-229:repeal-application",
        "sa-sez-current:income-wht",
        "hainan-extension:extension",
        "qianhai-extension:extension",
        "india-fa2026:IFSC",
        "oecd-global:overview"
      ],
      "claim": "[sa-sez-current](<https://zatca.gov.sa/en/HelpCenter/guidelines/Documents/SEZ-Tax%26Customs-Procedures.pdf>)",
      "id": "R0005.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-229:repeal-application",
        "sa-sez-current:income-wht",
        "hainan-extension:extension",
        "qianhai-extension:extension",
        "india-fa2026:IFSC",
        "oecd-global:overview"
      ],
      "claim": "[hainan-extension](<https://policy.mofcom.gov.cn/claw/clawContent.shtml?id=103253>)",
      "id": "R0005.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-229:repeal-application",
        "sa-sez-current:income-wht",
        "hainan-extension:extension",
        "qianhai-extension:extension",
        "india-fa2026:IFSC",
        "oecd-global:overview"
      ],
      "claim": "[qianhai-extension](<https://www.tid.gov.hk/en/tradecircular/files/2026/ci1712026a.pdf>)",
      "id": "R0005.5",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-229:repeal-application",
        "sa-sez-current:income-wht",
        "hainan-extension:extension",
        "qianhai-extension:extension",
        "india-fa2026:IFSC",
        "oecd-global:overview"
      ],
      "claim": "[india-fa2026](<https://egazette.gov.in/WriteReadData/2026/271439.pdf>)",
      "id": "R0005.6",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-229:repeal-application",
        "sa-sez-current:income-wht",
        "hainan-extension:extension",
        "qianhai-extension:extension",
        "india-fa2026:IFSC",
        "oecd-global:overview"
      ],
      "claim": "[oecd-global](<https://www.oecd.org/en/topics/global-minimum-tax.html>).",
      "id": "R0005.7",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "MD 229/2025 Articles 6–7",
      "block": "uae-229:repeal-application",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/uae-229.txt",
      "capture_sha256": "c88cc20050545d47b3fa798760db3a8bea253e48c7e300fe41682007a6b87a7c",
      "limitations": [
        "Ministry/FTA-hosted English law. January2026consolidation andMD229 explicitly not official English translations; Arabic original unread. No entity-specific licensing/application or unread cross-reference clearance."
      ],
      "native_fragment_ids": [
        "N00086",
        "N00087",
        "N00088"
      ],
      "official_url": "https://tax.gov.ae/datafolder/Files/Pdf/2025/MD-No-229.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00087",
      "read_scope": "Actual extracted lines 325–336, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [
        "decision shall be published and shall come into effect on 1 June 2023. Ministerial Decision No. 229 of 2025 – As published by the Ministry"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "uae-229",
      "visual_proof": null
    },
    {
      "act_article": "ZATCA manual geographic SEZs sections 2.1–2.2, with 2.3 introduction",
      "block": "sa-sez-current:income-wht",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/sa-sez-current.txt",
      "capture_sha256": "89c3fabc9fde3e1c9340d578abc3eb667a59164ebb549656cf030e8369cc8b4b",
      "limitations": [
        "Actual ZATCA2026 manual underCouncil468/30Dec2025; guidance, not complete enacted decision or licensed entity clearance. VAT/customs substantive sections beyond stated read scopes not cleared."
      ],
      "native_fragment_ids": [
        "N00359",
        "N00360",
        "N00361",
        "N00362",
        "N00363",
        "N00364",
        "N00365",
        "N00366",
        "N00367",
        "N00368",
        "N00369",
        "N00370",
        "N00371",
        "N00372",
        "N00373",
        "N00374",
        "N00375",
        "N00376",
        "N00377",
        "N00378",
        "N00379",
        "N00380",
        "N00381",
        "N00382",
        "N00383",
        "N00384",
        "N00385",
        "N00386",
        "N00387",
        "N00388",
        "N00389",
        "N00390",
        "N00391",
        "N00392",
        "N00393",
        "N00394",
        "N00395",
        "N00396",
        "N00397",
        "N00398",
        "N00399",
        "N00400",
        "N00401",
        "N00402",
        "N00403",
        "N00404",
        "N00405",
        "N00406",
        "N00407",
        "N00408"
      ],
      "official_url": "https://zatca.gov.sa/en/HelpCenter/guidelines/Documents/SEZ-Tax%26Customs-Procedures.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00371",
      "read_scope": "Actual extracted lines 184–350, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [
        "Minimum Tax (Pillar Two) rules in the Kingdom for companies within its scope. If a licensed entity in the SEZ generates non - qualifying income"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "sa-sez-current",
      "visual_proof": null
    },
    {
      "act_article": "Notice 2025(3) extension",
      "block": "hainan-extension:extension",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/hainan-extension.txt",
      "capture_sha256": "e67a8d0b98e572847be0c616bee3a4d25f57b20d11e7b660fcf0c7dd3cd309bf",
      "limitations": [
        "MOFCOMgovernment republication expressly disclaims completeness/currentness; originalMOFsource not recovered."
      ],
      "native_fragment_ids": [
        "N00519",
        "N00520",
        "N00521",
        "N00522",
        "N00523",
        "N00524",
        "N00525"
      ],
      "official_url": "https://policy.mofcom.gov.cn/claw/clawContent.shtml?id=103253",
      "own_read_date": "2026-11-16",
      "quote_id": "N00523",
      "read_scope": "Actual extracted lines 23–35, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [
        "14号）规定的《海南自由贸易港旅游业、现代服务业、高新技术产业企业所得税优惠目录》，执行期限延长至2027年1 2月31日。 财政部 税务总局 2025年1月24日"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "hainan-extension",
      "visual_proof": null
    },
    {
      "act_article": "Notice 2026(3), extending 2021(30)/2024(13)",
      "block": "qianhai-extension:extension",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/qianhai-extension.txt",
      "capture_sha256": "37621c9cbf60a2dffc8623d10d58c614111358e4cb4e3dec68e712491afe1574",
      "limitations": [
        "Official HKTradeDepartment reproduction of2026(3); mainland original/current base eligibility not recovered."
      ],
      "native_fragment_ids": [
        "N00544",
        "N00545",
        "N00546",
        "N00547",
        "N00548"
      ],
      "official_url": "https://www.tid.gov.hk/en/tradecircular/files/2026/ci1712026a.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00544",
      "read_scope": "Actual extracted lines 1–31, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [
        "(以下附錄節錄自中華人民共和國深圳市前海深港現代服務業合作區管理局的網站，全文可參閱 https://qh.sz.gov.cn/sygnan/xxgk/xxgkml/zcfg/zzwj/content/post_12636690.html)"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "qianhai-extension",
      "visual_proof": null
    },
    {
      "act_article": "Finance Act 2026 section 47",
      "block": "india-fa2026:IFSC",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/india-fa2026.txt",
      "capture_sha256": "93ff0ed2a206f71ee56ef09b454bf7473328d9d1946bb75ab0a9f69fb9864177",
      "limitations": [
        "Actual IndianGazette enacted Act, selected operative provisions and immediate neighbors, not entire Act. 2026amendment supersedes original147periods; no IFSCA licence or complete filing eligibility clearance."
      ],
      "native_fragment_ids": [
        "N00641",
        "N00642",
        "N00643",
        "N00644",
        "N00645",
        "N00646",
        "N00647",
        "N00648",
        "N00649",
        "N00650",
        "N00651",
        "N00652",
        "N00653",
        "N00654",
        "N00655",
        "N00656",
        "N00657",
        "N00658",
        "N00659",
        "N00660",
        "N00661",
        "N00662",
        "N00663",
        "N00664",
        "N00665",
        "N00666",
        "N00667",
        "N00668",
        "N00669",
        "N00670",
        "N00671",
        "N00672",
        "N00673"
      ],
      "official_url": "https://egazette.gov.in/WriteReadData/2026/271439.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00663",
      "read_scope": "Actual extracted lines 2405–2505, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [
        "India Act, 1992 or any other relevant 15 of 1992. law in force was obtained; or (ii) in case of an entity referred to in"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "india-fa2026",
      "visual_proof": null
    },
    {
      "act_article": "OECD global-minimum-tax selected overview",
      "block": "oecd-global:overview",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/oecd-global-native-excerpts.txt",
      "capture_sha256": "fcc245ec5302be8c7e27f4af5d45aa913ec7cb93796b1a18e2f6c06c775aadd0",
      "limitations": [
        "Selectedactualoverviewparagraphsread; legislative template, notdomesticlaw. Fullmodel/administrativeguidancenotread. Shortsource-nativeextractsinledger, notfullsitequotation.",
        "Only tool Lnn locators and citation wrappers removed, retaining visible anchor text; raw response immutable."
      ],
      "native_fragment_ids": [
        "N02245",
        "N02246",
        "N02247",
        "N02248"
      ],
      "official_url": "https://www.oecd.org/en/topics/global-minimum-tax.html",
      "own_read_date": "2026-11-16",
      "quote_id": "N02246",
      "read_scope": "Actual official web lines 3749–3771, personally read with immediate qualifications.",
      "short_exact_native_quote": [
        "15% minimum rate"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "oecd-global",
      "visual_proof": null
    }
  ],
  "old_lines": [
    22,
    23,
    24,
    25,
    26
  ],
  "section": "What this Guide covers",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0006

**The reviewer is the customer of the output.** Record commercial fit, activity permissions, exit costs and every unresolved rule before an incorporation, restructuring or onshore-versus-zone election. Obtain credentialed local tax counsel’s review before execution; a source-cited research draft is not that sign-off.

```json
{
  "context_only_blocks": [],
  "current_lines": [
    27,
    27
  ],
  "id": "R0006",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "**The reviewer is the customer of the output.** Record commercial fit, activity permissions, exit costs and every unresolved rule before an incorporation, restructuring or onshore-versus-zone election.",
      "id": "R0006.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Obtain credentialed local tax counsel’s review before execution",
      "id": "R0006.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "a source-cited research draft is not that sign-off.",
      "id": "R0006.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    28
  ],
  "section": "What this Guide covers",
  "source_read_record": null,
  "status": "scope/workflow/refusal/protected disclaimer; no new statutory assertion"
}
```

### R0007

## Scope

```json
{
  "context_only_blocks": [],
  "current_lines": [
    29,
    29
  ],
  "id": "R0007",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "## Scope",
      "id": "R0007.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    30
  ],
  "section": "Scope",
  "source_read_record": null,
  "status": "heading"
}
```

### R0008

Cover CIT, withholding and indirect-tax headlines; qualifying activities; premises, employees and expenditure; de minimis limits; onshore/mainland and Indian DTA flows; OECD BEPS Action 5/FHTP status; and Pillar Two interaction. Track income classification separately from legal permission to trade.

```json
{
  "context_only_blocks": [],
  "current_lines": [
    31,
    31
  ],
  "id": "R0008",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Cover CIT, withholding and indirect-tax headlines",
      "id": "R0008.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "qualifying activities",
      "id": "R0008.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "premises, employees and expenditure",
      "id": "R0008.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "de minimis limits",
      "id": "R0008.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "onshore/mainland and Indian DTA flows",
      "id": "R0008.5",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "OECD BEPS Action 5/FHTP status",
      "id": "R0008.6",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "and Pillar Two interaction.",
      "id": "R0008.7",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Track income classification separately from legal permission to trade.",
      "id": "R0008.8",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    32,
    34,
    35,
    36,
    37,
    38,
    39,
    40
  ],
  "section": "Scope",
  "source_read_record": null,
  "status": "scope/workflow/refusal/protected disclaimer; no new statutory assertion"
}
```

### R0009

Outside scope: detailed customs/free-circulation rates and procedures, employment and immigration, real-estate leasing economics, sector licences such as DFSA/ADGM FSRA/MAS, and designated-zone VAT mechanics. Route those to the relevant country Guides and actual regulator/customs instruments; this matrix gives only a customs/VAT summary.

```json
{
  "context_only_blocks": [],
  "current_lines": [
    33,
    33
  ],
  "id": "R0009",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Outside scope: detailed customs/free-circulation rates and procedures, employment and immigration, real-estate leasing economics, sector licences such as DFSA/ADGM FSRA/MAS, and designated-zone VAT mechanics.",
      "id": "R0009.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Route those to the relevant country Guides and actual regulator/customs instruments",
      "id": "R0009.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "this matrix gives only a customs/VAT summary.",
      "id": "R0009.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    42,
    44,
    45,
    46,
    47,
    48
  ],
  "section": "Scope",
  "source_read_record": null,
  "status": "scope/workflow/refusal/protected disclaimer; no new statutory assertion"
}
```

### R0010

## Ask the client first

```json
{
  "context_only_blocks": [],
  "current_lines": [
    35,
    35
  ],
  "id": "R0010",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "## Ask the client first",
      "id": "R0010.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Ask the client first",
  "source_read_record": null,
  "status": "heading"
}
```

### R0011

- Exact entity, country/zone, licence and proposed commencement or tax period.
- Every revenue stream, counterparty type and actual use/destination of supplies.
- Premises, CIGA, personnel, outsourcing, expenditure and actual management.
- Accounting-period revenue, adjusted qualifying/non-qualifying split and domestic sales.
- Group ownership/consolidated revenue for the relevant prior years and minimum-tax footprint.
- Intended distributions, withholding/treaty route, IP ownership and exit/election constraints.

```json
{
  "context_only_blocks": [],
  "current_lines": [
    37,
    42
  ],
  "id": "R0011",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "- Exact entity, country/zone, licence and proposed commencement or tax period. - Every revenue stream, counterparty type and actual use/destination of supplies. - Premises, CIGA, personnel, outsourcing, expenditure and actual management. - Accounting-period revenue, adjusted qualifying/non-qualifying split and domestic sales. - Group ownership/consolidated revenue for the relevant prior years and minimum-tax footprint. - Intended distributions, withholding/treaty route, IP ownership and exit/election constraints.",
      "id": "R0011.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Ask the client first",
  "source_read_record": null,
  "status": "scope/workflow/refusal/protected disclaimer; no new statutory assertion"
}
```

### R0012

## The method, step by step

```json
{
  "context_only_blocks": [],
  "current_lines": [
    44,
    44
  ],
  "id": "R0012",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "## The method, step by step",
      "id": "R0012.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    199
  ],
  "section": "The method, step by step",
  "source_read_record": null,
  "status": "heading"
}
```

### R0013

1. Identify the jurisdiction, exact zone and legal entity, licence, accounting period, revenue streams, counterparties and destination of goods/services. Confirm the enacted version and commencement before selecting any rate. Treat every **Not yet confirmed** item as an unusable source request, not an assumed favourable outcome.

```json
{
  "context_only_blocks": [],
  "current_lines": [
    46,
    46
  ],
  "id": "R0013",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "1.",
      "id": "R0013.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Identify the jurisdiction, exact zone and legal entity, licence, accounting period, revenue streams, counterparties and destination of goods/services.",
      "id": "R0013.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Confirm the enacted version and commencement before selecting any rate.",
      "id": "R0013.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Treat every **Not yet confirmed** item as an unusable source request, not an assumed favourable outcome.",
      "id": "R0013.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    28,
    32
  ],
  "section": "The method, step by step",
  "source_read_record": null,
  "status": "scope/workflow/refusal/protected disclaimer; no new statutory assertion"
}
```

### R0014

2. Classify each stream against the actual qualifying/excluded list and apply substance, beneficial-recipient, permanent-establishment, property/IP and anti-abuse rules. Assess domestic sales separately from the tax de minimis calculation. Build a forecast with an explicit denominator and failure consequences.

```json
{
  "context_only_blocks": [],
  "current_lines": [
    48,
    48
  ],
  "id": "R0014",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "2.",
      "id": "R0014.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Classify each stream against the actual qualifying/excluded list and apply substance, beneficial-recipient, permanent-establishment, property/IP and anti-abuse rules.",
      "id": "R0014.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Assess domestic sales separately from the tax de minimis calculation.",
      "id": "R0014.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Build a forecast with an explicit denominator and failure consequences.",
      "id": "R0014.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    35,
    36,
    37,
    38,
    56,
    89
  ],
  "section": "The method, step by step",
  "source_read_record": null,
  "status": "scope/workflow/refusal/protected disclaimer; no new statutory assertion"
}
```

### R0015

3. Test withholding and treaty entitlement separately, then group revenue, covered/excluded entities, jurisdictional effective tax and any domestic/parent minimum-tax rules. Document remaining conditions and local reviewer questions rather than turning an authority overview into entity-specific clearance.

```json
{
  "context_only_blocks": [],
  "current_lines": [
    50,
    50
  ],
  "id": "R0015",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "3.",
      "id": "R0015.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Test withholding and treaty entitlement separately, then group revenue, covered/excluded entities, jurisdictional effective tax and any domestic/parent minimum-tax rules.",
      "id": "R0015.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Document remaining conditions and local reviewer questions rather than turning an authority overview into entity-specific clearance.",
      "id": "R0015.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    26,
    40,
    213,
    238,
    239
  ],
  "section": "The method, step by step",
  "source_read_record": null,
  "status": "scope/workflow/refusal/protected disclaimer; no new statutory assertion"
}
```

### R0016

## UAE free zones

```json
{
  "context_only_blocks": [],
  "current_lines": [
    52,
    52
  ],
  "id": "R0016",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "## UAE free zones",
      "id": "R0016.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    50
  ],
  "section": "UAE free zones",
  "source_read_record": null,
  "status": "heading"
}
```

### R0017

Corporate tax applies to tax periods beginning on or after **1 June 2023**; a calendar-year entity’s first such period may therefore be 2024. The law has taxable/exempt-person conditions; “all UAE entities” is too broad. A QFZP has **0% on Qualifying Income** and **9% on its taxable non-qualifying income** under Article 3(2), subject separately to applicable top-up tax. This is not a 0% rate automatically attached to any zone licence. [uae-2026](<https://mof.gov.ae/wp-content/uploads/2026/01/Federal-Decree-Law-No.-47-of-2022-and-its-amendments-en-v13.1.26.pdf>).

```json
{
  "context_only_blocks": [],
  "current_lines": [
    54,
    54
  ],
  "id": "R0017",
  "individual_subclaims": [
    {
      "bindings": [
        "uae-2026:rates",
        "uae-2026:commencement"
      ],
      "claim": "Corporate tax applies to tax periods beginning on or after **1 June 2023**",
      "id": "R0017.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-2026:rates",
        "uae-2026:commencement"
      ],
      "claim": "a calendar-year entity’s first such period may therefore be 2024.",
      "id": "R0017.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-2026:rates",
        "uae-2026:commencement"
      ],
      "claim": "The law has taxable/exempt-person conditions",
      "id": "R0017.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-2026:rates",
        "uae-2026:commencement"
      ],
      "claim": "“all UAE entities” is too broad.",
      "id": "R0017.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-2026:rates",
        "uae-2026:commencement"
      ],
      "claim": "A QFZP has **0% on Qualifying Income** and **9% on its taxable non-qualifying income** under Article 3(2), subject separately to applicable top-up tax.",
      "id": "R0017.5",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-2026:rates",
        "uae-2026:commencement"
      ],
      "claim": "This is not a 0% rate automatically attached to any zone licence. [uae-2026](<https://mof.gov.ae/wp-content/uploads/2026/01/Federal-Decree-Law-No.-47-of-2022-and-its-amendments-en-v13.1.26.pdf>).",
      "id": "R0017.6",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "Federal Decree-Law 47/2022 Article 3 and neighboring Article 4",
      "block": "uae-2026:rates",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/uae-2026.txt",
      "capture_sha256": "d7e15eff1f58b7d7cba8d7f989b3de296546a0bead401fe89165810630ff0af8",
      "limitations": [
        "Ministry/FTA-hosted English law. January2026consolidation andMD229 explicitly not official English translations; Arabic original unread. No entity-specific licensing/application or unread cross-reference clearance."
      ],
      "native_fragment_ids": [
        "N00159",
        "N00160",
        "N00161",
        "N00162",
        "N00163",
        "N00164",
        "N00165",
        "N00166",
        "N00167",
        "N00168",
        "N00169",
        "N00170",
        "N00171"
      ],
      "official_url": "https://mof.gov.ae/wp-content/uploads/2026/01/Federal-Decree-Law-No.-47-of-2022-and-its-amendments-en-v13.1.26.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00160",
      "read_scope": "Actual extracted lines 300–337, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [
        "Rates Article 2 – Imposition of Corporate Tax Corporate Tax shall be imposed on Taxable Income, at the rates determined under this Decree-Law, and payable"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "uae-2026",
      "visual_proof": null
    },
    {
      "act_article": "Federal Decree-Law 47/2022 final commencement/application provisions",
      "block": "uae-2026:commencement",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/uae-2026.txt",
      "capture_sha256": "d7e15eff1f58b7d7cba8d7f989b3de296546a0bead401fe89165810630ff0af8",
      "limitations": [
        "Ministry/FTA-hosted English law. January2026consolidation andMD229 explicitly not official English translations; Arabic original unread. No entity-specific licensing/application or unread cross-reference clearance."
      ],
      "native_fragment_ids": [
        "N00242",
        "N00243",
        "N00244",
        "N00245",
        "N00246",
        "N00247"
      ],
      "official_url": "https://mof.gov.ae/wp-content/uploads/2026/01/Federal-Decree-Law-No.-47-of-2022-and-its-amendments-en-v13.1.26.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00246",
      "read_scope": "Actual extracted lines 2298–2327, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "uae-2026",
      "visual_proof": null
    }
  ],
  "old_lines": [
    52
  ],
  "section": "UAE free zones",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0018

### QFZP qualification and income

```json
{
  "context_only_blocks": [],
  "current_lines": [
    56,
    56
  ],
  "id": "R0018",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "### QFZP qualification and income",
      "id": "R0018.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    54,
    58
  ],
  "section": "QFZP qualification and income",
  "source_read_record": null,
  "status": "heading"
}
```

### R0019

Article **18**, not Article 7, requires adequate substance, Qualifying Income, no Article 19 election into the ordinary regime, arm’s-length/transfer-pricing compliance and prescribed additional conditions. MD **229/2025** requires de minimis compliance and audited financial statements under its cited MD 84/2025. Article 34 governs arm’s-length conditions; Article 55’s master/local file duties depend on prescribed conditions, not every company automatically. [uae-2026](<https://mof.gov.ae/wp-content/uploads/2026/01/Federal-Decree-Law-No.-47-of-2022-and-its-amendments-en-v13.1.26.pdf>); [uae-229](<https://tax.gov.ae/datafolder/Files/Pdf/2025/MD-No-229.pdf>).

```json
{
  "context_only_blocks": [],
  "current_lines": [
    58,
    58
  ],
  "id": "R0019",
  "individual_subclaims": [
    {
      "bindings": [
        "uae-2026:qualification",
        "uae-2026:TP",
        "uae-2026:TP-files",
        "uae-229:conditions"
      ],
      "claim": "Article **18**, not Article 7, requires adequate substance, Qualifying Income, no Article 19 election into the ordinary regime, arm’s-length/transfer-pricing compliance and prescribed additional conditions.",
      "id": "R0019.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-2026:qualification",
        "uae-2026:TP",
        "uae-2026:TP-files",
        "uae-229:conditions"
      ],
      "claim": "MD **229/2025** requires de minimis compliance and audited financial statements under its cited MD 84/2025.",
      "id": "R0019.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-2026:qualification",
        "uae-2026:TP",
        "uae-2026:TP-files",
        "uae-229:conditions"
      ],
      "claim": "Article 34 governs arm’s-length conditions",
      "id": "R0019.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-2026:qualification",
        "uae-2026:TP",
        "uae-2026:TP-files",
        "uae-229:conditions"
      ],
      "claim": "Article 55’s master/local file duties depend on prescribed conditions, not every company automatically. [uae-2026](<https://mof.gov.ae/wp-content/uploads/2026/01/Federal-Decree-Law-No.-47-of-2022-and-its-amendments-en-v13.1.26.pdf>)",
      "id": "R0019.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-2026:qualification",
        "uae-2026:TP",
        "uae-2026:TP-files",
        "uae-229:conditions"
      ],
      "claim": "[uae-229](<https://tax.gov.ae/datafolder/Files/Pdf/2025/MD-No-229.pdf>).",
      "id": "R0019.5",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "Federal Decree-Law 47/2022 Article 18 and neighboring Article 19",
      "block": "uae-2026:qualification",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/uae-2026.txt",
      "capture_sha256": "d7e15eff1f58b7d7cba8d7f989b3de296546a0bead401fe89165810630ff0af8",
      "limitations": [
        "Ministry/FTA-hosted English law. January2026consolidation andMD229 explicitly not official English translations; Arabic original unread. No entity-specific licensing/application or unread cross-reference clearance."
      ],
      "native_fragment_ids": [
        "N00172",
        "N00173",
        "N00174",
        "N00175",
        "N00176",
        "N00177",
        "N00178",
        "N00179",
        "N00180",
        "N00181",
        "N00182",
        "N00183",
        "N00184",
        "N00185",
        "N00186",
        "N00187",
        "N00188",
        "N00189",
        "N00190",
        "N00191",
        "N00192",
        "N00193",
        "N00194",
        "N00195"
      ],
      "official_url": "https://mof.gov.ae/wp-content/uploads/2026/01/Federal-Decree-Law-No.-47-of-2022-and-its-amendments-en-v13.1.26.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00174",
      "read_scope": "Actual extracted lines 950–1017, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "uae-2026",
      "visual_proof": null
    },
    {
      "act_article": "Federal Decree-Law 47/2022 Article 34 with neighboring Article 35",
      "block": "uae-2026:TP",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/uae-2026.txt",
      "capture_sha256": "d7e15eff1f58b7d7cba8d7f989b3de296546a0bead401fe89165810630ff0af8",
      "limitations": [
        "Ministry/FTA-hosted English law. January2026consolidation andMD229 explicitly not official English translations; Arabic original unread. No entity-specific licensing/application or unread cross-reference clearance."
      ],
      "native_fragment_ids": [
        "N00196",
        "N00197",
        "N00198",
        "N00199",
        "N00200",
        "N00201",
        "N00202",
        "N00203",
        "N00204",
        "N00205",
        "N00206",
        "N00207",
        "N00208",
        "N00209",
        "N00210",
        "N00211",
        "N00212",
        "N00213",
        "N00214",
        "N00215",
        "N00216",
        "N00217",
        "N00218",
        "N00219",
        "N00220",
        "N00221",
        "N00222",
        "N00223",
        "N00224"
      ],
      "official_url": "https://mof.gov.ae/wp-content/uploads/2026/01/Federal-Decree-Law-No.-47-of-2022-and-its-amendments-en-v13.1.26.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00196",
      "read_scope": "Actual extracted lines 1500–1580, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "uae-2026",
      "visual_proof": null
    },
    {
      "act_article": "Federal Decree-Law 47/2022 Article 55 with neighboring provisions",
      "block": "uae-2026:TP-files",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/uae-2026.txt",
      "capture_sha256": "d7e15eff1f58b7d7cba8d7f989b3de296546a0bead401fe89165810630ff0af8",
      "limitations": [
        "Ministry/FTA-hosted English law. January2026consolidation andMD229 explicitly not official English translations; Arabic original unread. No entity-specific licensing/application or unread cross-reference clearance."
      ],
      "native_fragment_ids": [
        "N00225",
        "N00226",
        "N00227",
        "N00228",
        "N00229",
        "N00230",
        "N00231",
        "N00232",
        "N00233",
        "N00234",
        "N00235",
        "N00236",
        "N00237",
        "N00238",
        "N00239",
        "N00240",
        "N00241"
      ],
      "official_url": "https://mof.gov.ae/wp-content/uploads/2026/01/Federal-Decree-Law-No.-47-of-2022-and-its-amendments-en-v13.1.26.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00227",
      "read_scope": "Actual extracted lines 2150–2205, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "uae-2026",
      "visual_proof": null
    },
    {
      "act_article": "MD 229/2025 Article 5",
      "block": "uae-229:conditions",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/uae-229.txt",
      "capture_sha256": "c88cc20050545d47b3fa798760db3a8bea253e48c7e300fe41682007a6b87a7c",
      "limitations": [
        "Ministry/FTA-hosted English law. January2026consolidation andMD229 explicitly not official English translations; Arabic original unread. No entity-specific licensing/application or unread cross-reference clearance."
      ],
      "native_fragment_ids": [
        "N00079",
        "N00080",
        "N00081",
        "N00082",
        "N00083",
        "N00084",
        "N00085"
      ],
      "official_url": "https://tax.gov.ae/datafolder/Files/Pdf/2025/MD-No-229.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00081",
      "read_scope": "Actual extracted lines 306–324, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "uae-229",
      "visual_proof": null
    }
  ],
  "old_lines": [
    56
  ],
  "section": "QFZP qualification and income",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0020

Cabinet Decision **100/2023** replaced CD 55/2023; MD 229/2025 repeals MD 265/2023. Their specified application is from **1 June 2023**. Do not apply the old MD 139/2023 list as the current list. These Ministry-hosted English copies/consolidation are translation aids; the January 2026 law and MD 229 expressly warn that the English is not an official translation. The Arabic originals were not read. MD 336/2025 specifies VARA as a competent authority for the stated fund/wealth-investment-management purposes, not all virtual-asset businesses. [uae-100](<https://mof.gov.ae/wp-content/uploads/2023/11/Cabinet-Decision-No.-100-of-2023-on-Determining-Qualifying-Income-for-the-Qualifying-Free-Zone-Person.pdf>); [uae-229](<https://tax.gov.ae/datafolder/Files/Pdf/2025/MD-No-229.pdf>); [uae-336](<https://mof.gov.ae/wp-content/uploads/2026/02/Ministerial-Decision-No.-336-of-2025-on-the-Specification-of-a-Competent-Authority-for-the-Purposes-of-Ministerial-Decision-No.-229-of-2025_-En.pdf>).

```json
{
  "context_only_blocks": [],
  "current_lines": [
    60,
    60
  ],
  "id": "R0020",
  "individual_subclaims": [
    {
      "bindings": [
        "uae-100:repeal-application",
        "uae-229:repeal-application",
        "uae-336:whole"
      ],
      "claim": "Cabinet Decision **100/2023** replaced CD 55/2023",
      "id": "R0020.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-100:repeal-application",
        "uae-229:repeal-application",
        "uae-336:whole"
      ],
      "claim": "MD 229/2025 repeals MD 265/2023.",
      "id": "R0020.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-100:repeal-application",
        "uae-229:repeal-application",
        "uae-336:whole"
      ],
      "claim": "Their specified application is from **1 June 2023**.",
      "id": "R0020.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-100:repeal-application",
        "uae-229:repeal-application",
        "uae-336:whole"
      ],
      "claim": "Do not apply the old MD 139/2023 list as the current list.",
      "id": "R0020.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-100:repeal-application",
        "uae-229:repeal-application",
        "uae-336:whole"
      ],
      "claim": "These Ministry-hosted English copies/consolidation are translation aids",
      "id": "R0020.5",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-100:repeal-application",
        "uae-229:repeal-application",
        "uae-336:whole"
      ],
      "claim": "the January 2026 law and MD 229 expressly warn that the English is not an official translation.",
      "id": "R0020.6",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-100:repeal-application",
        "uae-229:repeal-application",
        "uae-336:whole"
      ],
      "claim": "The Arabic originals were not read.",
      "id": "R0020.7",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-100:repeal-application",
        "uae-229:repeal-application",
        "uae-336:whole"
      ],
      "claim": "MD 336/2025 specifies VARA as a competent authority for the stated fund/wealth-investment-management purposes, not all virtual-asset businesses. [uae-100](<https://mof.gov.ae/wp-content/uploads/2023/11/Cabinet-Decision-No.-100-of-2023-on-Determining-Qualifying-Income-for-the-Qualifying-Free-Zone-Person.pdf>)",
      "id": "R0020.8",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-100:repeal-application",
        "uae-229:repeal-application",
        "uae-336:whole"
      ],
      "claim": "[uae-229](<https://tax.gov.ae/datafolder/Files/Pdf/2025/MD-No-229.pdf>)",
      "id": "R0020.9",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-100:repeal-application",
        "uae-229:repeal-application",
        "uae-336:whole"
      ],
      "claim": "[uae-336](<https://mof.gov.ae/wp-content/uploads/2026/02/Ministerial-Decision-No.-336-of-2025-on-the-Specification-of-a-Competent-Authority-for-the-Purposes-of-Ministerial-Decision-No.-229-of-2025_-En.pdf>).",
      "id": "R0020.10",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "CD 100/2023 Articles 9–11",
      "block": "uae-100:repeal-application",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/uae-100.txt",
      "capture_sha256": "ab4d1743e78d2c336d807b83fb336f668476878713a29fa68d5ca62f9cfaca73",
      "limitations": [
        "Ministry/FTA-hosted English law. January2026consolidation andMD229 explicitly not official English translations; Arabic original unread. No entity-specific licensing/application or unread cross-reference clearance."
      ],
      "native_fragment_ids": [
        "N00155",
        "N00156",
        "N00157",
        "N00158"
      ],
      "official_url": "https://mof.gov.ae/wp-content/uploads/2023/11/Cabinet-Decision-No.-100-of-2023-on-Determining-Qualifying-Income-for-the-Qualifying-Free-Zone-Person.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00155",
      "read_scope": "Actual extracted lines 229–257, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [
        "Article (10) Repeals Cabinet Decision No. 55 of 2023 on Determining Qualifying Income for the Qualifying Free Zone Person for the Purposes of Federal Decree-Law"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "uae-100",
      "visual_proof": null
    },
    {
      "act_article": "MD 229/2025 Articles 6–7",
      "block": "uae-229:repeal-application",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/uae-229.txt",
      "capture_sha256": "c88cc20050545d47b3fa798760db3a8bea253e48c7e300fe41682007a6b87a7c",
      "limitations": [
        "Ministry/FTA-hosted English law. January2026consolidation andMD229 explicitly not official English translations; Arabic original unread. No entity-specific licensing/application or unread cross-reference clearance."
      ],
      "native_fragment_ids": [
        "N00086",
        "N00087",
        "N00088"
      ],
      "official_url": "https://tax.gov.ae/datafolder/Files/Pdf/2025/MD-No-229.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00087",
      "read_scope": "Actual extracted lines 325–336, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "uae-229",
      "visual_proof": null
    },
    {
      "act_article": "MD 336/2025 Articles 1–2",
      "block": "uae-336:whole",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/uae-336.txt",
      "capture_sha256": "fcbd6d47a6588e1f59638ad0b754c442319d55dd54aa4f2d77fc046d05eff067",
      "limitations": [
        "Ministry/FTA-hosted English law. January2026consolidation andMD229 explicitly not official English translations; Arabic original unread. No entity-specific licensing/application or unread cross-reference clearance."
      ],
      "native_fragment_ids": [
        "N00248",
        "N00249",
        "N00250",
        "N00251",
        "N00252",
        "N00253",
        "N00254",
        "N00255",
        "N00256"
      ],
      "official_url": "https://mof.gov.ae/wp-content/uploads/2026/02/Ministerial-Decision-No.-336-of-2025-on-the-Specification-of-a-Competent-Authority-for-the-Purposes-of-Ministerial-Decision-No.-229-of-2025_-En.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00248",
      "read_scope": "Actual extracted lines 1–42, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [
        "Ministerial Decision No. 336 of 2025 on the Specification of a Competent Authority for the Purposes of Ministerial Decision No. 229 of 2025 Regarding Qualifying"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "uae-336",
      "visual_proof": null
    }
  ],
  "old_lines": [
    23,
    58
  ],
  "section": "QFZP qualification and income",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0021

| Income route | Current bounded rule |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    62,
    62
  ],
  "id": "R0021",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Income route",
      "id": "R0021.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Current bounded rule",
      "id": "R0021.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    60,
    73
  ],
  "section": "QFZP qualification and income",
  "source_read_record": null,
  "status": "workflow/research question or table label; no current rule asserted"
}
```

### R0022

| --- | --- |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    63,
    63
  ],
  "id": "R0022",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "---",
      "id": "R0022.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "---",
      "id": "R0022.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    61,
    74
  ],
  "section": "QFZP qualification and income",
  "source_read_record": null,
  "status": "table separator"
}
```

### R0023

| Other Free Zone Person | CD 100 Article 3 requires the other Free Zone Person to be the beneficial recipient: a right to use/enjoy without a contractual/legal obligation to onward-supply. Excluded activities and the separate PE/property/IP rules remain relevant. [uae-100](<https://mof.gov.ae/wp-content/uploads/2023/11/Cabinet-Decision-No.-100-of-2023-on-Determining-Qualifying-Income-for-the-Qualifying-Free-Zone-Person.pdf>) |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    64,
    64
  ],
  "id": "R0023",
  "individual_subclaims": [
    {
      "bindings": [
        "uae-100:income"
      ],
      "claim": "Other Free Zone Person",
      "id": "R0023.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-100:income"
      ],
      "claim": "CD 100 Article 3 requires the other Free Zone Person to be the beneficial recipient: a right to use/enjoy without a contractual/legal obligation to onward-supply. Excluded activities and the separate PE/property/IP rules remain relevant. [uae-100](<https://mof.gov.ae/wp-content/uploads/2023/11/Cabinet-Decision-No.-100-of-2023-on-Determining-Qualifying-Income-for-the-Qualifying-Free-Zone-Person.pdf>)",
      "id": "R0023.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "CD 100/2023 Articles 2–3",
      "block": "uae-100:income",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/uae-100.txt",
      "capture_sha256": "ab4d1743e78d2c336d807b83fb336f668476878713a29fa68d5ca62f9cfaca73",
      "limitations": [
        "Ministry/FTA-hosted English law. January2026consolidation andMD229 explicitly not official English translations; Arabic original unread. No entity-specific licensing/application or unread cross-reference clearance."
      ],
      "native_fragment_ids": [
        "N00104",
        "N00105",
        "N00106",
        "N00107",
        "N00108",
        "N00109",
        "N00110",
        "N00111",
        "N00112",
        "N00113",
        "N00114",
        "N00115",
        "N00116",
        "N00117"
      ],
      "official_url": "https://mof.gov.ae/wp-content/uploads/2023/11/Cabinet-Decision-No.-100-of-2023-on-Determining-Qualifying-Income-for-the-Qualifying-Free-Zone-Person.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00110",
      "read_scope": "Actual extracted lines 65–102, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "uae-100",
      "visual_proof": null
    }
  ],
  "old_lines": [
    62
  ],
  "section": "QFZP qualification and income",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0024

| Non-Free Zone Person | Only qualifying activities that are not excluded qualify under this route. MD 229 Article 2 lists manufacturing; processing; qualifying-commodity trading; investment holding of shares/securities; ownership/management/operation of ships; reinsurance; fund management; wealth/investment management; headquarters for related parties; treasury/financing for related parties or own account; aircraft financing/leasing; distribution in/from a Designated Zone; logistics; and qualifying ancillary activities. Each defined condition must also be met. [uae-229](<https://tax.gov.ae/datafolder/Files/Pdf/2025/MD-No-229.pdf>); [uae-100](<https://mof.gov.ae/wp-content/uploads/2023/11/Cabinet-Decision-No.-100-of-2023-on-Determining-Qualifying-Income-for-the-Qualifying-Free-Zone-Person.pdf>) |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    65,
    65
  ],
  "id": "R0024",
  "individual_subclaims": [
    {
      "bindings": [
        "uae-229:activities",
        "uae-100:income"
      ],
      "claim": "Non-Free Zone Person",
      "id": "R0024.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-229:activities",
        "uae-100:income"
      ],
      "claim": "Only qualifying activities that are not excluded qualify under this route. MD 229 Article 2 lists manufacturing; processing; qualifying-commodity trading; investment holding of shares/securities; ownership/management/operation of ships; reinsurance; fund management; wealth/investment management; headquarters for related parties; treasury/financing for related parties or own account; aircraft financing/leasing; distribution in/from a Designated Zone; logistics; and qualifying ancillary activities. Each defined condition must also be met. [uae-229](<https://tax.gov.ae/datafolder/Files/Pdf/2025/MD-No-229.pdf>); [uae-100](<https://mof.gov.ae/wp-content/uploads/2023/11/Cabinet-Decision-No.-100-of-2023-on-Determining-Qualifying-Income-for-the-Qualifying-Free-Zone-Person.pdf>)",
      "id": "R0024.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "MD 229/2025 Article 2(1)–(2)",
      "block": "uae-229:activities",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/uae-229.txt",
      "capture_sha256": "c88cc20050545d47b3fa798760db3a8bea253e48c7e300fe41682007a6b87a7c",
      "limitations": [
        "Ministry/FTA-hosted English law. January2026consolidation andMD229 explicitly not official English translations; Arabic original unread. No entity-specific licensing/application or unread cross-reference clearance."
      ],
      "native_fragment_ids": [
        "N00001",
        "N00002",
        "N00003",
        "N00004",
        "N00005",
        "N00006",
        "N00007",
        "N00008",
        "N00009",
        "N00010",
        "N00011",
        "N00012",
        "N00013"
      ],
      "official_url": "https://tax.gov.ae/datafolder/Files/Pdf/2025/MD-No-229.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00001",
      "read_scope": "Actual extracted lines 101–139, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "uae-229",
      "visual_proof": null
    },
    {
      "act_article": "CD 100/2023 Articles 2–3",
      "block": "uae-100:income",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/uae-100.txt",
      "capture_sha256": "ab4d1743e78d2c336d807b83fb336f668476878713a29fa68d5ca62f9cfaca73",
      "limitations": [
        "Ministry/FTA-hosted English law. January2026consolidation andMD229 explicitly not official English translations; Arabic original unread. No entity-specific licensing/application or unread cross-reference clearance."
      ],
      "native_fragment_ids": [
        "N00104",
        "N00105",
        "N00106",
        "N00107",
        "N00108",
        "N00109",
        "N00110",
        "N00111",
        "N00112",
        "N00113",
        "N00114",
        "N00115",
        "N00116",
        "N00117"
      ],
      "official_url": "https://mof.gov.ae/wp-content/uploads/2023/11/Cabinet-Decision-No.-100-of-2023-on-Determining-Qualifying-Income-for-the-Qualifying-Free-Zone-Person.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00110",
      "read_scope": "Actual extracted lines 65–102, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "uae-100",
      "visual_proof": null
    }
  ],
  "old_lines": [
    63
  ],
  "section": "QFZP qualification and income",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0025

| Important activity qualifiers | Commodity trading includes defined physical trading/hedging/structured financing, with the **51%** distribution/warehousing/logistics/inventory-revenue exclusion. Investment holding uses the specified **12-month** purpose test. Regulated fund/wealth activities need competent-authority oversight. Distribution has Designated Zone/customer resale-or-processing conditions and the specified public-benefit exception. Logistics does not involve taking title to the goods. See the individual source request under Sources. [uae-229](<https://tax.gov.ae/datafolder/Files/Pdf/2025/MD-No-229.pdf>) |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    66,
    66
  ],
  "id": "R0025",
  "individual_subclaims": [
    {
      "bindings": [
        "uae-229:definitions-activity-conditions"
      ],
      "claim": "Important activity qualifiers",
      "id": "R0025.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-229:definitions-activity-conditions"
      ],
      "claim": "Commodity trading includes defined physical trading/hedging/structured financing, with the **51%** distribution/warehousing/logistics/inventory-revenue exclusion. Investment holding uses the specified **12-month** purpose test. Regulated fund/wealth activities need competent-authority oversight. Distribution has Designated Zone/customer resale-or-processing conditions and the specified public-benefit exception. Logistics does not involve taking title to the goods. See the individual source request under Sources. [uae-229](<https://tax.gov.ae/datafolder/Files/Pdf/2025/MD-No-229.pdf>)",
      "id": "R0025.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "MD 229/2025 Article 2(3) definitions and activity conditions",
      "block": "uae-229:definitions-activity-conditions",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/uae-229.txt",
      "capture_sha256": "c88cc20050545d47b3fa798760db3a8bea253e48c7e300fe41682007a6b87a7c",
      "limitations": [
        "Ministry/FTA-hosted English law. January2026consolidation andMD229 explicitly not official English translations; Arabic original unread. No entity-specific licensing/application or unread cross-reference clearance."
      ],
      "native_fragment_ids": [
        "N00014",
        "N00015",
        "N00016",
        "N00017",
        "N00018",
        "N00019",
        "N00020",
        "N00021",
        "N00022",
        "N00023",
        "N00024",
        "N00025",
        "N00026",
        "N00027",
        "N00028",
        "N00029",
        "N00030",
        "N00031",
        "N00032",
        "N00033",
        "N00034",
        "N00035",
        "N00036",
        "N00037",
        "N00038",
        "N00039",
        "N00040",
        "N00041",
        "N00042",
        "N00043",
        "N00044",
        "N00045",
        "N00046",
        "N00047",
        "N00048",
        "N00049",
        "N00050",
        "N00051",
        "N00052",
        "N00053",
        "N00054",
        "N00055",
        "N00056",
        "N00057",
        "N00058",
        "N00059"
      ],
      "official_url": "https://tax.gov.ae/datafolder/Files/Pdf/2025/MD-No-229.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00019",
      "read_scope": "Actual extracted lines 142–251, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "uae-229",
      "visual_proof": null
    }
  ],
  "old_lines": [
    63
  ],
  "section": "QFZP qualification and income",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0026

| Excluded activities | MD 229 Article 2(2) includes natural-person transactions, except specified ship/fund/wealth/aircraft activities; banking; insurance with its reinsurance/headquarters carve-outs; finance/leasing with its commodity/ship/treasury/aircraft carve-outs; property other than commercial Free Zone property transacted with a Free Zone Person; and ancillary excluded activities. It is wrong to label all insurance, all third-party finance or all property identically. [uae-229](<https://tax.gov.ae/datafolder/Files/Pdf/2025/MD-No-229.pdf>) |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    67,
    67
  ],
  "id": "R0026",
  "individual_subclaims": [
    {
      "bindings": [
        "uae-229:activities"
      ],
      "claim": "Excluded activities",
      "id": "R0026.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-229:activities"
      ],
      "claim": "MD 229 Article 2(2) includes natural-person transactions, except specified ship/fund/wealth/aircraft activities; banking; insurance with its reinsurance/headquarters carve-outs; finance/leasing with its commodity/ship/treasury/aircraft carve-outs; property other than commercial Free Zone property transacted with a Free Zone Person; and ancillary excluded activities. It is wrong to label all insurance, all third-party finance or all property identically. [uae-229](<https://tax.gov.ae/datafolder/Files/Pdf/2025/MD-No-229.pdf>)",
      "id": "R0026.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "MD 229/2025 Article 2(1)–(2)",
      "block": "uae-229:activities",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/uae-229.txt",
      "capture_sha256": "c88cc20050545d47b3fa798760db3a8bea253e48c7e300fe41682007a6b87a7c",
      "limitations": [
        "Ministry/FTA-hosted English law. January2026consolidation andMD229 explicitly not official English translations; Arabic original unread. No entity-specific licensing/application or unread cross-reference clearance."
      ],
      "native_fragment_ids": [
        "N00001",
        "N00002",
        "N00003",
        "N00004",
        "N00005",
        "N00006",
        "N00007",
        "N00008",
        "N00009",
        "N00010",
        "N00011",
        "N00012",
        "N00013"
      ],
      "official_url": "https://tax.gov.ae/datafolder/Files/Pdf/2025/MD-No-229.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00012",
      "read_scope": "Actual extracted lines 101–139, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "uae-229",
      "visual_proof": null
    }
  ],
  "old_lines": [
    64
  ],
  "section": "QFZP qualification and income",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0027

| Other income | CD 100 Article 3(1)(d) can include other income when the de minimis requirements are met; it is not invariably non-qualifying taxable income. Separately excluded PE/property/IP income must still be addressed. [uae-100](<https://mof.gov.ae/wp-content/uploads/2023/11/Cabinet-Decision-No.-100-of-2023-on-Determining-Qualifying-Income-for-the-Qualifying-Free-Zone-Person.pdf>) |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    68,
    68
  ],
  "id": "R0027",
  "individual_subclaims": [
    {
      "bindings": [
        "uae-100:income",
        "uae-100:de-minimis"
      ],
      "claim": "Other income",
      "id": "R0027.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-100:income",
        "uae-100:de-minimis"
      ],
      "claim": "CD 100 Article 3(1)(d) can include other income when the de minimis requirements are met; it is not invariably non-qualifying taxable income. Separately excluded PE/property/IP income must still be addressed. [uae-100](<https://mof.gov.ae/wp-content/uploads/2023/11/Cabinet-Decision-No.-100-of-2023-on-Determining-Qualifying-Income-for-the-Qualifying-Free-Zone-Person.pdf>)",
      "id": "R0027.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "CD 100/2023 Articles 2–3",
      "block": "uae-100:income",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/uae-100.txt",
      "capture_sha256": "ab4d1743e78d2c336d807b83fb336f668476878713a29fa68d5ca62f9cfaca73",
      "limitations": [
        "Ministry/FTA-hosted English law. January2026consolidation andMD229 explicitly not official English translations; Arabic original unread. No entity-specific licensing/application or unread cross-reference clearance."
      ],
      "native_fragment_ids": [
        "N00104",
        "N00105",
        "N00106",
        "N00107",
        "N00108",
        "N00109",
        "N00110",
        "N00111",
        "N00112",
        "N00113",
        "N00114",
        "N00115",
        "N00116",
        "N00117"
      ],
      "official_url": "https://mof.gov.ae/wp-content/uploads/2023/11/Cabinet-Decision-No.-100-of-2023-on-Determining-Qualifying-Income-for-the-Qualifying-Free-Zone-Person.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00110",
      "read_scope": "Actual extracted lines 65–102, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "uae-100",
      "visual_proof": null
    },
    {
      "act_article": "CD 100/2023 Article 4",
      "block": "uae-100:de-minimis",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/uae-100.txt",
      "capture_sha256": "ab4d1743e78d2c336d807b83fb336f668476878713a29fa68d5ca62f9cfaca73",
      "limitations": [
        "Ministry/FTA-hosted English law. January2026consolidation andMD229 explicitly not official English translations; Arabic original unread. No entity-specific licensing/application or unread cross-reference clearance."
      ],
      "native_fragment_ids": [
        "N00118",
        "N00119",
        "N00120",
        "N00121",
        "N00122",
        "N00123",
        "N00124",
        "N00125",
        "N00126",
        "N00127",
        "N00128",
        "N00129",
        "N00130"
      ],
      "official_url": "https://mof.gov.ae/wp-content/uploads/2023/11/Cabinet-Decision-No.-100-of-2023-on-Determining-Qualifying-Income-for-the-Qualifying-Free-Zone-Person.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00118",
      "read_scope": "Actual extracted lines 103–149, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "uae-100",
      "visual_proof": null
    }
  ],
  "old_lines": [
    65
  ],
  "section": "QFZP qualification and income",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0028

| PE and property | CD 100 Articles 5–6 tax the specified domestic/foreign PE income, commercial Free Zone property transactions with non-Free Zone persons, and non-commercial property transactions with any person at the applicable Article 3(2)(b) rate. Attribute income under the separate-person conditions. Qualifying commercial property between Free Zone persons is a different route. [uae-100](<https://mof.gov.ae/wp-content/uploads/2023/11/Cabinet-Decision-No.-100-of-2023-on-Determining-Qualifying-Income-for-the-Qualifying-Free-Zone-Person.pdf>) |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    69,
    69
  ],
  "id": "R0028",
  "individual_subclaims": [
    {
      "bindings": [
        "uae-100:PE-property"
      ],
      "claim": "PE and property",
      "id": "R0028.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-100:PE-property"
      ],
      "claim": "CD 100 Articles 5–6 tax the specified domestic/foreign PE income, commercial Free Zone property transactions with non-Free Zone persons, and non-commercial property transactions with any person at the applicable Article 3(2)(b) rate. Attribute income under the separate-person conditions. Qualifying commercial property between Free Zone persons is a different route. [uae-100](<https://mof.gov.ae/wp-content/uploads/2023/11/Cabinet-Decision-No.-100-of-2023-on-Determining-Qualifying-Income-for-the-Qualifying-Free-Zone-Person.pdf>)",
      "id": "R0028.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "CD 100/2023 Articles 5–6",
      "block": "uae-100:PE-property",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/uae-100.txt",
      "capture_sha256": "ab4d1743e78d2c336d807b83fb336f668476878713a29fa68d5ca62f9cfaca73",
      "limitations": [
        "Ministry/FTA-hosted English law. January2026consolidation andMD229 explicitly not official English translations; Arabic original unread. No entity-specific licensing/application or unread cross-reference clearance."
      ],
      "native_fragment_ids": [
        "N00131",
        "N00132",
        "N00133",
        "N00134",
        "N00135",
        "N00136",
        "N00137",
        "N00138",
        "N00139",
        "N00140"
      ],
      "official_url": "https://mof.gov.ae/wp-content/uploads/2023/11/Cabinet-Decision-No.-100-of-2023-on-Determining-Qualifying-Income-for-the-Qualifying-Free-Zone-Person.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00132",
      "read_scope": "Actual extracted lines 150–182, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "uae-100",
      "visual_proof": null
    }
  ],
  "old_lines": [
    64,
    89
  ],
  "section": "QFZP qualification and income",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0029

| Qualifying IP | CD 100 Article 1 includes patents, copyrighted software and equivalent protected/approved rights, excluding marketing IP such as trademarks. MD 229 Article 4 applies a nexus fraction to overall IP income: qualifying R&D expenditure plus the permitted **30% uplift**, divided by overall expenditure; uplift cannot take qualifying expenditure above overall expenditure. Acquisition costs enter overall expenditure. Keep ownership/expenditure/income/link records. Non-qualifying IP and excess income are separately taxable under CD 100 Article 7. See the individual source request under Sources. [uae-100](<https://mof.gov.ae/wp-content/uploads/2023/11/Cabinet-Decision-No.-100-of-2023-on-Determining-Qualifying-Income-for-the-Qualifying-Free-Zone-Person.pdf>); [uae-229](<https://tax.gov.ae/datafolder/Files/Pdf/2025/MD-No-229.pdf>) |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    70,
    70
  ],
  "id": "R0029",
  "individual_subclaims": [
    {
      "bindings": [
        "uae-100:definitions",
        "uae-100:IP",
        "uae-229:IP",
        "uae-229:IP-visual-formula"
      ],
      "claim": "Qualifying IP",
      "id": "R0029.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-100:definitions",
        "uae-100:IP",
        "uae-229:IP",
        "uae-229:IP-visual-formula"
      ],
      "claim": "CD 100 Article 1 includes patents, copyrighted software and equivalent protected/approved rights, excluding marketing IP such as trademarks. MD 229 Article 4 applies a nexus fraction to overall IP income: qualifying R&D expenditure plus the permitted **30% uplift**, divided by overall expenditure; uplift cannot take qualifying expenditure above overall expenditure. Acquisition costs enter overall expenditure. Keep ownership/expenditure/income/link records. Non-qualifying IP and excess income are separately taxable under CD 100 Article 7. See the individual source request under Sources. [uae-100](<https://mof.gov.ae/wp-content/uploads/2023/11/Cabinet-Decision-No.-100-of-2023-on-Determining-Qualifying-Income-for-the-Qualifying-Free-Zone-Person.pdf>); [uae-229](<https://tax.gov.ae/datafolder/Files/Pdf/2025/MD-No-229.pdf>)",
      "id": "R0029.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "CD 100/2023 Article 1",
      "block": "uae-100:definitions",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/uae-100.txt",
      "capture_sha256": "ab4d1743e78d2c336d807b83fb336f668476878713a29fa68d5ca62f9cfaca73",
      "limitations": [
        "Ministry/FTA-hosted English law. January2026consolidation andMD229 explicitly not official English translations; Arabic original unread. No entity-specific licensing/application or unread cross-reference clearance."
      ],
      "native_fragment_ids": [
        "N00089",
        "N00090",
        "N00091",
        "N00092",
        "N00093",
        "N00094",
        "N00095",
        "N00096",
        "N00097",
        "N00098",
        "N00099",
        "N00100",
        "N00101",
        "N00102",
        "N00103"
      ],
      "official_url": "https://mof.gov.ae/wp-content/uploads/2023/11/Cabinet-Decision-No.-100-of-2023-on-Determining-Qualifying-Income-for-the-Qualifying-Free-Zone-Person.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00094",
      "read_scope": "Actual extracted lines 16–64, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "uae-100",
      "visual_proof": null
    },
    {
      "act_article": "CD 100/2023 Article 7",
      "block": "uae-100:IP",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/uae-100.txt",
      "capture_sha256": "ab4d1743e78d2c336d807b83fb336f668476878713a29fa68d5ca62f9cfaca73",
      "limitations": [
        "Ministry/FTA-hosted English law. January2026consolidation andMD229 explicitly not official English translations; Arabic original unread. No entity-specific licensing/application or unread cross-reference clearance."
      ],
      "native_fragment_ids": [
        "N00141",
        "N00142",
        "N00143",
        "N00144"
      ],
      "official_url": "https://mof.gov.ae/wp-content/uploads/2023/11/Cabinet-Decision-No.-100-of-2023-on-Determining-Qualifying-Income-for-the-Qualifying-Free-Zone-Person.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00141",
      "read_scope": "Actual extracted lines 183–194, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "uae-100",
      "visual_proof": null
    },
    {
      "act_article": "MD 229/2025 Article 4(1)–(4), formula separately visual",
      "block": "uae-229:IP",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/uae-229.txt",
      "capture_sha256": "c88cc20050545d47b3fa798760db3a8bea253e48c7e300fe41682007a6b87a7c",
      "limitations": [
        "Ministry/FTA-hosted English law. January2026consolidation andMD229 explicitly not official English translations; Arabic original unread. No entity-specific licensing/application or unread cross-reference clearance."
      ],
      "native_fragment_ids": [
        "N00064",
        "N00065",
        "N00066",
        "N00067",
        "N00068",
        "N00069",
        "N00070",
        "N00071",
        "N00072",
        "N00073",
        "N00074",
        "N00075",
        "N00076",
        "N00077",
        "N00078"
      ],
      "official_url": "https://tax.gov.ae/datafolder/Files/Pdf/2025/MD-No-229.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00064",
      "read_scope": "Actual extracted lines 263–305, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "uae-229",
      "visual_proof": null
    },
    {
      "act_article": "MD 229/2025 Article 4(1), actual PDF physical page 10 formula image",
      "block": "uae-229:IP-visual-formula",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/uae-229-formula-visual-transcription.txt",
      "capture_sha256": "8782d5c62fee56cffbe0545b7f81fd6ee9d2a9a502662efaf855d6b8d29b5dd9",
      "limitations": [
        "Ministry/FTA-hosted English law. January2026consolidation andMD229 explicitly not official English translations; Arabic original unread. No entity-specific licensing/application or unread cross-reference clearance."
      ],
      "native_fragment_ids": [
        "N-VISUAL-IP-1"
      ],
      "official_url": "https://tax.gov.ae/datafolder/Files/Pdf/2025/MD-No-229.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N-VISUAL-IP-1",
      "read_scope": "Actual image personally visually read; faithful linear transcription of the displayed fraction, with nested parentheses expressing numerator/denominator. The extracted text has no formula.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "uae-229",
      "visual_proof": {
        "image": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/pdf-reads/uae-229-p10.png",
        "image_sha256": "bb6914f933a465ea27907efacbf8565d5511022f9d133ccfd50b528b74144643",
        "physical_page": 10,
        "read": "Personally visually read16Nov2026: QI=(QE+uplift)/OE × overall income; adjacent Article4definitions/30%cap in text block."
      }
    }
  ],
  "old_lines": [
    64,
    262
  ],
  "section": "QFZP qualification and income",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0030

### Substance, de minimis and mainland sales

```json
{
  "context_only_blocks": [],
  "current_lines": [
    72,
    72
  ],
  "id": "R0030",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "### Substance, de minimis and mainland sales",
      "id": "R0030.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    67,
    89
  ],
  "section": "Substance, de minimis and mainland sales",
  "source_read_record": null,
  "status": "heading"
}
```

### R0031

CD 100 Article 8 requires CIGA in the required **Free Zone or Designated Zone**, with adequate assets, qualified full-time employees and operating expenditure for each activity. Outsourcing normally stays in the required zone under adequate supervision; qualifying IP CIGA can instead be outsourced to a UAE person or an unrelated foreign person, with supervision. “Some premises anywhere in the UAE” is insufficient; CIGA means significant value-driving functions, not mainly support work. [uae-100](<https://mof.gov.ae/wp-content/uploads/2023/11/Cabinet-Decision-No.-100-of-2023-on-Determining-Qualifying-Income-for-the-Qualifying-Free-Zone-Person.pdf>).

```json
{
  "context_only_blocks": [],
  "current_lines": [
    74,
    74
  ],
  "id": "R0031",
  "individual_subclaims": [
    {
      "bindings": [
        "uae-100:substance"
      ],
      "claim": "CD 100 Article 8 requires CIGA in the required **Free Zone or Designated Zone**, with adequate assets, qualified full-time employees and operating expenditure for each activity.",
      "id": "R0031.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-100:substance"
      ],
      "claim": "Outsourcing normally stays in the required zone under adequate supervision",
      "id": "R0031.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-100:substance"
      ],
      "claim": "qualifying IP CIGA can instead be outsourced to a UAE person or an unrelated foreign person, with supervision.",
      "id": "R0031.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-100:substance"
      ],
      "claim": "“Some premises anywhere in the UAE” is insufficient",
      "id": "R0031.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-100:substance"
      ],
      "claim": "CIGA means significant value-driving functions, not mainly support work. [uae-100](<https://mof.gov.ae/wp-content/uploads/2023/11/Cabinet-Decision-No.-100-of-2023-on-Determining-Qualifying-Income-for-the-Qualifying-Free-Zone-Person.pdf>).",
      "id": "R0031.5",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "CD 100/2023 Article 8",
      "block": "uae-100:substance",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/uae-100.txt",
      "capture_sha256": "ab4d1743e78d2c336d807b83fb336f668476878713a29fa68d5ca62f9cfaca73",
      "limitations": [
        "Ministry/FTA-hosted English law. January2026consolidation andMD229 explicitly not official English translations; Arabic original unread. No entity-specific licensing/application or unread cross-reference clearance."
      ],
      "native_fragment_ids": [
        "N00145",
        "N00146",
        "N00147",
        "N00148",
        "N00149",
        "N00150",
        "N00151",
        "N00152",
        "N00153",
        "N00154"
      ],
      "official_url": "https://mof.gov.ae/wp-content/uploads/2023/11/Cabinet-Decision-No.-100-of-2023-on-Determining-Qualifying-Income-for-the-Qualifying-Free-Zone-Person.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00152",
      "read_scope": "Actual extracted lines 195–218, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "uae-100",
      "visual_proof": null
    }
  ],
  "old_lines": [
    67
  ],
  "section": "Substance, de minimis and mainland sales",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0032

The MD 229 Article 3 cap is the **lower of 5% of total revenue and AED 5,000,000**, applied to the tax period. CD 100 Article 4 defines non-qualifying revenue and removes the specified PE/property/non-qualifying-IP revenue from **both** numerator and denominator. Do not use gross accounting sales without those adjustments. [uae-100](<https://mof.gov.ae/wp-content/uploads/2023/11/Cabinet-Decision-No.-100-of-2023-on-Determining-Qualifying-Income-for-the-Qualifying-Free-Zone-Person.pdf>); [uae-229](<https://tax.gov.ae/datafolder/Files/Pdf/2025/MD-No-229.pdf>).

```json
{
  "context_only_blocks": [],
  "current_lines": [
    76,
    76
  ],
  "id": "R0032",
  "individual_subclaims": [
    {
      "bindings": [
        "uae-100:de-minimis",
        "uae-229:de-minimis"
      ],
      "claim": "The MD 229 Article 3 cap is the **lower of 5% of total revenue and AED 5,000,000**, applied to the tax period.",
      "id": "R0032.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-100:de-minimis",
        "uae-229:de-minimis"
      ],
      "claim": "CD 100 Article 4 defines non-qualifying revenue and removes the specified PE/property/non-qualifying-IP revenue from **both** numerator and denominator.",
      "id": "R0032.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-100:de-minimis",
        "uae-229:de-minimis"
      ],
      "claim": "Do not use gross accounting sales without those adjustments. [uae-100](<https://mof.gov.ae/wp-content/uploads/2023/11/Cabinet-Decision-No.-100-of-2023-on-Determining-Qualifying-Income-for-the-Qualifying-Free-Zone-Person.pdf>)",
      "id": "R0032.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-100:de-minimis",
        "uae-229:de-minimis"
      ],
      "claim": "[uae-229](<https://tax.gov.ae/datafolder/Files/Pdf/2025/MD-No-229.pdf>).",
      "id": "R0032.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "CD 100/2023 Article 4",
      "block": "uae-100:de-minimis",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/uae-100.txt",
      "capture_sha256": "ab4d1743e78d2c336d807b83fb336f668476878713a29fa68d5ca62f9cfaca73",
      "limitations": [
        "Ministry/FTA-hosted English law. January2026consolidation andMD229 explicitly not official English translations; Arabic original unread. No entity-specific licensing/application or unread cross-reference clearance."
      ],
      "native_fragment_ids": [
        "N00118",
        "N00119",
        "N00120",
        "N00121",
        "N00122",
        "N00123",
        "N00124",
        "N00125",
        "N00126",
        "N00127",
        "N00128",
        "N00129",
        "N00130"
      ],
      "official_url": "https://mof.gov.ae/wp-content/uploads/2023/11/Cabinet-Decision-No.-100-of-2023-on-Determining-Qualifying-Income-for-the-Qualifying-Free-Zone-Person.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00119",
      "read_scope": "Actual extracted lines 103–149, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "uae-100",
      "visual_proof": null
    },
    {
      "act_article": "MD 229/2025 Article 3",
      "block": "uae-229:de-minimis",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/uae-229.txt",
      "capture_sha256": "c88cc20050545d47b3fa798760db3a8bea253e48c7e300fe41682007a6b87a7c",
      "limitations": [
        "Ministry/FTA-hosted English law. January2026consolidation andMD229 explicitly not official English translations; Arabic original unread. No entity-specific licensing/application or unread cross-reference clearance."
      ],
      "native_fragment_ids": [
        "N00060",
        "N00061",
        "N00062",
        "N00063"
      ],
      "official_url": "https://tax.gov.ae/datafolder/Files/Pdf/2025/MD-No-229.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00061",
      "read_scope": "Actual extracted lines 253–261, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "uae-229",
      "visual_proof": null
    }
  ],
  "old_lines": [
    56,
    89,
    247
  ],
  "section": "Substance, de minimis and mainland sales",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0033

Tax classification does not establish legal permission for mainland trading. The former “only through a mainland distributor or within de minimis” rule was too broad: qualifying non-Free Zone activities can use Article 3(1)(b), while distribution has its own conditions. Obtain the licence/customs/sale-permission rule separately. A de minimis breach is not merely a 9% charge on the excess/relevant revenue: MD 229 Article 5 normally ends QFZP status from the beginning of the failing period and for **4 subsequent tax periods**, with Article 18’s ministerial conditions/circumstances still relevant. [uae-100](<https://mof.gov.ae/wp-content/uploads/2023/11/Cabinet-Decision-No.-100-of-2023-on-Determining-Qualifying-Income-for-the-Qualifying-Free-Zone-Person.pdf>); [uae-229](<https://tax.gov.ae/datafolder/Files/Pdf/2025/MD-No-229.pdf>); [uae-2026](<https://mof.gov.ae/wp-content/uploads/2026/01/Federal-Decree-Law-No.-47-of-2022-and-its-amendments-en-v13.1.26.pdf>).

```json
{
  "context_only_blocks": [],
  "current_lines": [
    78,
    78
  ],
  "id": "R0033",
  "individual_subclaims": [
    {
      "bindings": [
        "uae-100:income",
        "uae-229:definitions-activity-conditions",
        "uae-229:conditions",
        "uae-2026:qualification"
      ],
      "claim": "Tax classification does not establish legal permission for mainland trading.",
      "id": "R0033.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-100:income",
        "uae-229:definitions-activity-conditions",
        "uae-229:conditions",
        "uae-2026:qualification"
      ],
      "claim": "The former “only through a mainland distributor or within de minimis” rule was too broad: qualifying non-Free Zone activities can use Article 3(1)(b), while distribution has its own conditions.",
      "id": "R0033.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-100:income",
        "uae-229:definitions-activity-conditions",
        "uae-229:conditions",
        "uae-2026:qualification"
      ],
      "claim": "Obtain the licence/customs/sale-permission rule separately.",
      "id": "R0033.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-100:income",
        "uae-229:definitions-activity-conditions",
        "uae-229:conditions",
        "uae-2026:qualification"
      ],
      "claim": "A de minimis breach is not merely a 9% charge on the excess/relevant revenue: MD 229 Article 5 normally ends QFZP status from the beginning of the failing period and for **4 subsequent tax periods**, with Article 18’s ministerial conditions/circumstances still relevant. [uae-100](<https://mof.gov.ae/wp-content/uploads/2023/11/Cabinet-Decision-No.-100-of-2023-on-Determining-Qualifying-Income-for-the-Qualifying-Free-Zone-Person.pdf>)",
      "id": "R0033.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-100:income",
        "uae-229:definitions-activity-conditions",
        "uae-229:conditions",
        "uae-2026:qualification"
      ],
      "claim": "[uae-229](<https://tax.gov.ae/datafolder/Files/Pdf/2025/MD-No-229.pdf>)",
      "id": "R0033.5",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-100:income",
        "uae-229:definitions-activity-conditions",
        "uae-229:conditions",
        "uae-2026:qualification"
      ],
      "claim": "[uae-2026](<https://mof.gov.ae/wp-content/uploads/2026/01/Federal-Decree-Law-No.-47-of-2022-and-its-amendments-en-v13.1.26.pdf>).",
      "id": "R0033.6",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "CD 100/2023 Articles 2–3",
      "block": "uae-100:income",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/uae-100.txt",
      "capture_sha256": "ab4d1743e78d2c336d807b83fb336f668476878713a29fa68d5ca62f9cfaca73",
      "limitations": [
        "Ministry/FTA-hosted English law. January2026consolidation andMD229 explicitly not official English translations; Arabic original unread. No entity-specific licensing/application or unread cross-reference clearance."
      ],
      "native_fragment_ids": [
        "N00104",
        "N00105",
        "N00106",
        "N00107",
        "N00108",
        "N00109",
        "N00110",
        "N00111",
        "N00112",
        "N00113",
        "N00114",
        "N00115",
        "N00116",
        "N00117"
      ],
      "official_url": "https://mof.gov.ae/wp-content/uploads/2023/11/Cabinet-Decision-No.-100-of-2023-on-Determining-Qualifying-Income-for-the-Qualifying-Free-Zone-Person.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00108",
      "read_scope": "Actual extracted lines 65–102, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "uae-100",
      "visual_proof": null
    },
    {
      "act_article": "MD 229/2025 Article 2(3) definitions and activity conditions",
      "block": "uae-229:definitions-activity-conditions",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/uae-229.txt",
      "capture_sha256": "c88cc20050545d47b3fa798760db3a8bea253e48c7e300fe41682007a6b87a7c",
      "limitations": [
        "Ministry/FTA-hosted English law. January2026consolidation andMD229 explicitly not official English translations; Arabic original unread. No entity-specific licensing/application or unread cross-reference clearance."
      ],
      "native_fragment_ids": [
        "N00014",
        "N00015",
        "N00016",
        "N00017",
        "N00018",
        "N00019",
        "N00020",
        "N00021",
        "N00022",
        "N00023",
        "N00024",
        "N00025",
        "N00026",
        "N00027",
        "N00028",
        "N00029",
        "N00030",
        "N00031",
        "N00032",
        "N00033",
        "N00034",
        "N00035",
        "N00036",
        "N00037",
        "N00038",
        "N00039",
        "N00040",
        "N00041",
        "N00042",
        "N00043",
        "N00044",
        "N00045",
        "N00046",
        "N00047",
        "N00048",
        "N00049",
        "N00050",
        "N00051",
        "N00052",
        "N00053",
        "N00054",
        "N00055",
        "N00056",
        "N00057",
        "N00058",
        "N00059"
      ],
      "official_url": "https://tax.gov.ae/datafolder/Files/Pdf/2025/MD-No-229.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00014",
      "read_scope": "Actual extracted lines 142–251, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "uae-229",
      "visual_proof": null
    },
    {
      "act_article": "MD 229/2025 Article 5",
      "block": "uae-229:conditions",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/uae-229.txt",
      "capture_sha256": "c88cc20050545d47b3fa798760db3a8bea253e48c7e300fe41682007a6b87a7c",
      "limitations": [
        "Ministry/FTA-hosted English law. January2026consolidation andMD229 explicitly not official English translations; Arabic original unread. No entity-specific licensing/application or unread cross-reference clearance."
      ],
      "native_fragment_ids": [
        "N00079",
        "N00080",
        "N00081",
        "N00082",
        "N00083",
        "N00084",
        "N00085"
      ],
      "official_url": "https://tax.gov.ae/datafolder/Files/Pdf/2025/MD-No-229.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00080",
      "read_scope": "Actual extracted lines 306–324, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "uae-229",
      "visual_proof": null
    },
    {
      "act_article": "Federal Decree-Law 47/2022 Article 18 and neighboring Article 19",
      "block": "uae-2026:qualification",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/uae-2026.txt",
      "capture_sha256": "d7e15eff1f58b7d7cba8d7f989b3de296546a0bead401fe89165810630ff0af8",
      "limitations": [
        "Ministry/FTA-hosted English law. January2026consolidation andMD229 explicitly not official English translations; Arabic original unread. No entity-specific licensing/application or unread cross-reference clearance."
      ],
      "native_fragment_ids": [
        "N00172",
        "N00173",
        "N00174",
        "N00175",
        "N00176",
        "N00177",
        "N00178",
        "N00179",
        "N00180",
        "N00181",
        "N00182",
        "N00183",
        "N00184",
        "N00185",
        "N00186",
        "N00187",
        "N00188",
        "N00189",
        "N00190",
        "N00191",
        "N00192",
        "N00193",
        "N00194",
        "N00195"
      ],
      "official_url": "https://mof.gov.ae/wp-content/uploads/2026/01/Federal-Decree-Law-No.-47-of-2022-and-its-amendments-en-v13.1.26.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00178",
      "read_scope": "Actual extracted lines 950–1017, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "uae-2026",
      "visual_proof": null
    }
  ],
  "old_lines": [
    89,
    260
  ],
  "section": "Substance, de minimis and mainland sales",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0034

### UAE zone shortlist: licence facts still requiring individual proof

```json
{
  "context_only_blocks": [],
  "current_lines": [
    80,
    80
  ],
  "id": "R0034",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "### UAE zone shortlist: licence facts still requiring individual proof",
      "id": "R0034.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    69,
    71
  ],
  "section": "UAE zone shortlist: licence facts still requiring individual proof",
  "source_read_record": null,
  "status": "heading"
}
```

### R0035

Use the national QFZP tests above for every listed entity; the original repeated **0%/9%** cells were conditional income rates, not zone-specific certificates. [uae-2026](<https://mof.gov.ae/wp-content/uploads/2026/01/Federal-Decree-Law-No.-47-of-2022-and-its-amendments-en-v13.1.26.pdf>).

```json
{
  "context_only_blocks": [],
  "current_lines": [
    82,
    82
  ],
  "id": "R0035",
  "individual_subclaims": [
    {
      "bindings": [
        "uae-2026:rates"
      ],
      "claim": "Use the national QFZP tests above for every listed entity",
      "id": "R0035.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-2026:rates"
      ],
      "claim": "the original repeated **0%/9%** cells were conditional income rates, not zone-specific certificates. [uae-2026](<https://mof.gov.ae/wp-content/uploads/2026/01/Federal-Decree-Law-No.-47-of-2022-and-its-amendments-en-v13.1.26.pdf>).",
      "id": "R0035.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "Federal Decree-Law 47/2022 Article 3 and neighboring Article 4",
      "block": "uae-2026:rates",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/uae-2026.txt",
      "capture_sha256": "d7e15eff1f58b7d7cba8d7f989b3de296546a0bead401fe89165810630ff0af8",
      "limitations": [
        "Ministry/FTA-hosted English law. January2026consolidation andMD229 explicitly not official English translations; Arabic original unread. No entity-specific licensing/application or unread cross-reference clearance."
      ],
      "native_fragment_ids": [
        "N00159",
        "N00160",
        "N00161",
        "N00162",
        "N00163",
        "N00164",
        "N00165",
        "N00166",
        "N00167",
        "N00168",
        "N00169",
        "N00170",
        "N00171"
      ],
      "official_url": "https://mof.gov.ae/wp-content/uploads/2026/01/Federal-Decree-Law-No.-47-of-2022-and-its-amendments-en-v13.1.26.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00165",
      "read_scope": "Actual extracted lines 300–337, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "uae-2026",
      "visual_proof": null
    }
  ],
  "old_lines": [
    73,
    74,
    75,
    76,
    77,
    78,
    79,
    80,
    81,
    82,
    83,
    84,
    85,
    86,
    87
  ],
  "section": "UAE zone shortlist: licence facts still requiring individual proof",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0036

| Original shortlist | Individually retained research questions |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    84,
    84
  ],
  "id": "R0036",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Original shortlist",
      "id": "R0036.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Individually retained research questions",
      "id": "R0036.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    73
  ],
  "section": "UAE zone shortlist: licence facts still requiring individual proof",
  "source_read_record": null,
  "status": "workflow/research question or table label; no current rule asserted"
}
```

### R0037

| --- | --- |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    85,
    85
  ],
  "id": "R0037",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "---",
      "id": "R0037.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "---",
      "id": "R0037.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    74
  ],
  "section": "UAE zone shortlist: licence facts still requiring individual proof",
  "source_read_record": null,
  "status": "table separator"
}
```

### R0038

| DIFC, Dubai | Financial services, asset management and family offices; DFSA regulation, English common-law jurisdiction and the old “ICC arbitration center” identification all require exact current institutional/licensing proof. Do not assume an arbitration institution is ICC merely because it is in DIFC. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    86,
    86
  ],
  "id": "R0038",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "DIFC, Dubai",
      "id": "R0038.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Financial services, asset management and family offices; DFSA regulation, English common-law jurisdiction and the old “ICC arbitration center” identification all require exact current institutional/licensing proof. Do not assume an arbitration institution is ICC merely because it is in DIFC.",
      "id": "R0038.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    75
  ],
  "section": "UAE zone shortlist: licence facts still requiring individual proof",
  "source_read_record": null,
  "status": "workflow/research question or table label; no current rule asserted"
}
```

### R0039

| ADGM, Abu Dhabi | FSRA, common-law application, fintech/virtual-asset permissions and the claimed Variable Capital Company structure need the current legal vehicle and regulator instrument; no crypto licence follows from QFZP treatment. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    87,
    87
  ],
  "id": "R0039",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "ADGM, Abu Dhabi",
      "id": "R0039.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "FSRA, common-law application, fintech/virtual-asset permissions and the claimed Variable Capital Company structure need the current legal vehicle and regulator instrument; no crypto licence follows from QFZP treatment.",
      "id": "R0039.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    76
  ],
  "section": "UAE zone shortlist: licence facts still requiring individual proof",
  "source_read_record": null,
  "status": "workflow/research question or table label; no current rule asserted"
}
```

### R0040

| DMCC, Jumeirah Lakes Towers, Dubai | Commodities/services and gold/diamond/crypto permissions remain separate licence questions. The “world’s most-awarded” superlative is unverified marketing, not a tax criterion. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    88,
    88
  ],
  "id": "R0040",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "DMCC, Jumeirah Lakes Towers, Dubai",
      "id": "R0040.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Commodities/services and gold/diamond/crypto permissions remain separate licence questions. The “world’s most-awarded” superlative is unverified marketing, not a tax criterion.",
      "id": "R0040.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    77
  ],
  "section": "UAE zone shortlist: licence facts still requiring individual proof",
  "source_read_record": null,
  "status": "workflow/research question or table label; no current rule asserted"
}
```

### R0041

| JAFZA, Jebel Ali Port, Dubai | Logistics/manufacturing and the claimed VAT Designated Zone status require the actual current geographic designation and transaction rules; free-zone status alone proves neither. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    89,
    89
  ],
  "id": "R0041",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "JAFZA, Jebel Ali Port, Dubai",
      "id": "R0041.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Logistics/manufacturing and the claimed VAT Designated Zone status require the actual current geographic designation and transaction rules; free-zone status alone proves neither.",
      "id": "R0041.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    78
  ],
  "section": "UAE zone shortlist: licence facts still requiring individual proof",
  "source_read_record": null,
  "status": "workflow/research question or table label; no current rule asserted"
}
```

### R0042

| DAFZA, Dubai Airport | Light-manufacturing/services permissions and premises boundary remain unconfirmed; no independent tax rate is supplied. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    90,
    90
  ],
  "id": "R0042",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "DAFZA, Dubai Airport",
      "id": "R0042.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Light-manufacturing/services permissions and premises boundary remain unconfirmed; no independent tax rate is supplied.",
      "id": "R0042.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    79
  ],
  "section": "UAE zone shortlist: licence facts still requiring individual proof",
  "source_read_record": null,
  "status": "workflow/research question or table label; no current rule asserted"
}
```

### R0043

| DWC / Dubai South / Al Maktoum Airport | Aviation/logistics and the aerospace-cluster claim remain commercial/licensing leads, not proof of qualifying income. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    91,
    91
  ],
  "id": "R0043",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "DWC / Dubai South / Al Maktoum Airport",
      "id": "R0043.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Aviation/logistics and the aerospace-cluster claim remain commercial/licensing leads, not proof of qualifying income.",
      "id": "R0043.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    80
  ],
  "section": "UAE zone shortlist: licence facts still requiring individual proof",
  "source_read_record": null,
  "status": "workflow/research question or table label; no current rule asserted"
}
```

### R0044

| Sharjah Media City / Shams | Media/creative permissions and “low-cost licence” comparative claim remain unconfirmed; obtain actual current fee/licence terms. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    92,
    92
  ],
  "id": "R0044",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Sharjah Media City / Shams",
      "id": "R0044.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Media/creative permissions and “low-cost licence” comparative claim remain unconfirmed; obtain actual current fee/licence terms.",
      "id": "R0044.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    81
  ],
  "section": "UAE zone shortlist: licence facts still requiring individual proof",
  "source_read_record": null,
  "status": "workflow/research question or table label; no current rule asserted"
}
```

### R0045

| SHAMS / SAIF Zone / SAIF / Hamriyah | Do not treat this former combined row as one legal zone. Check Sharjah Media City, Sharjah Airport International Free Zone and Hamriyah independently for industrial/logistics or media permissions and exact legal identity. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    93,
    93
  ],
  "id": "R0045",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "SHAMS / SAIF Zone / SAIF / Hamriyah",
      "id": "R0045.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Do not treat this former combined row as one legal zone. Check Sharjah Media City, Sharjah Airport International Free Zone and Hamriyah independently for industrial/logistics or media permissions and exact legal identity.",
      "id": "R0045.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    82
  ],
  "section": "UAE zone shortlist: licence facts still requiring individual proof",
  "source_read_record": null,
  "status": "workflow/research question or table label; no current rule asserted"
}
```

### R0046

| RAKEZ, Ras Al Khaimah | Industrial/services and the old “low-cost mainland-of-RAK” label need exact free-zone versus non-free-zone licence proof. Cost and mainland permission are unconfirmed; no QFZP conclusion follows from the label. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    94,
    94
  ],
  "id": "R0046",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "RAKEZ, Ras Al Khaimah",
      "id": "R0046.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Industrial/services and the old “low-cost mainland-of-RAK” label need exact free-zone versus non-free-zone licence proof. Cost and mainland permission are unconfirmed; no QFZP conclusion follows from the label.",
      "id": "R0046.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    83
  ],
  "section": "UAE zone shortlist: licence facts still requiring individual proof",
  "source_read_record": null,
  "status": "workflow/research question or table label; no current rule asserted"
}
```

### R0047

| RAK ICC, Ras Al Khaimah | The international/offshore-style company and holding-vehicle route needs the actual registrar/entity rules. The old separate automatic **0% CIT** assertion is unsupported; test the federal taxable-person/QFZP conditions instead. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    95,
    95
  ],
  "id": "R0047",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "RAK ICC, Ras Al Khaimah",
      "id": "R0047.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "The international/offshore-style company and holding-vehicle route needs the actual registrar/entity rules. The old separate automatic **0% CIT** assertion is unsupported; test the federal taxable-person/QFZP conditions instead.",
      "id": "R0047.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    84
  ],
  "section": "UAE zone shortlist: licence facts still requiring individual proof",
  "source_read_record": null,
  "status": "workflow/research question or table label; no current rule asserted"
}
```

### R0048

| Fujairah Free Zone | Manufacturing/logistics permissions and Indian Ocean oil-terminal proximity remain individual location/licensing research leads. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    96,
    96
  ],
  "id": "R0048",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Fujairah Free Zone",
      "id": "R0048.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Manufacturing/logistics permissions and Indian Ocean oil-terminal proximity remain individual location/licensing research leads.",
      "id": "R0048.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    85
  ],
  "section": "UAE zone shortlist: licence facts still requiring individual proof",
  "source_read_record": null,
  "status": "workflow/research question or table label; no current rule asserted"
}
```

### R0049

| Ajman FZ | Light-manufacturing permissions and current registrar boundary remain unconfirmed. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    97,
    97
  ],
  "id": "R0049",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Ajman FZ",
      "id": "R0049.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Light-manufacturing permissions and current registrar boundary remain unconfirmed.",
      "id": "R0049.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    86
  ],
  "section": "UAE zone shortlist: licence facts still requiring individual proof",
  "source_read_record": null,
  "status": "workflow/research question or table label; no current rule asserted"
}
```

### R0050

| Umm Al Quwain FTZ / UAQ | Light-manufacturing permissions and current registrar boundary remain unconfirmed. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    98,
    98
  ],
  "id": "R0050",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Umm Al Quwain FTZ / UAQ",
      "id": "R0050.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Light-manufacturing permissions and current registrar boundary remain unconfirmed.",
      "id": "R0050.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    87
  ],
  "section": "UAE zone shortlist: licence facts still requiring individual proof",
  "source_read_record": null,
  "status": "workflow/research question or table label; no current rule asserted"
}
```

### R0051

## QFC is in Qatar

```json
{
  "context_only_blocks": [],
  "current_lines": [
    100,
    100
  ],
  "id": "R0051",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "## QFC is in Qatar",
      "id": "R0051.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    91,
    93
  ],
  "section": "QFC is in Qatar",
  "source_read_record": null,
  "status": "heading"
}
```

### R0052

The official English QFC Tax Regulations, **January 2026 version 7**, Article 9 charge **10%** on local-source taxable profits. Article 10 contains exceptions, including the new Article 10(1A) treatment for specified services for use outside Qatar by a QFC Entity that is not an Authorised Firm. Rule 1A requires **all** its conditions: audited accounts, at least **30%** income attributable to activities in Qatar, at least **3 full-time employees**, and the Tax Department’s anti-avoidance satisfaction. This is not an automatic foreign-income exemption or a 10% charge on all QFC income. [qfc-tax2026](<https://qfcra-en.thomsonreuters.com/sites/default/files/net_file_store/QFCRA_7103_VER7.pdf>); [qfc-rules2026](<https://qfcra-en.thomsonreuters.com/sites/default/files/net_file_store/QFCRA_8454_VER4.pdf>).

```json
{
  "context_only_blocks": [],
  "current_lines": [
    102,
    102
  ],
  "id": "R0052",
  "individual_subclaims": [
    {
      "bindings": [
        "qfc-tax2026:charge-local-source",
        "qfc-rules2026:rule1A"
      ],
      "claim": "The official English QFC Tax Regulations, **January 2026 version 7**, Article 9 charge **10%** on local-source taxable profits.",
      "id": "R0052.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "qfc-tax2026:charge-local-source",
        "qfc-rules2026:rule1A"
      ],
      "claim": "Article 10 contains exceptions, including the new Article 10(1A) treatment for specified services for use outside Qatar by a QFC Entity that is not an Authorised Firm.",
      "id": "R0052.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "qfc-tax2026:charge-local-source",
        "qfc-rules2026:rule1A"
      ],
      "claim": "Rule 1A requires **all** its conditions: audited accounts, at least **30%** income attributable to activities in Qatar, at least **3 full-time employees**, and the Tax Department’s anti-avoidance satisfaction.",
      "id": "R0052.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "qfc-tax2026:charge-local-source",
        "qfc-rules2026:rule1A"
      ],
      "claim": "This is not an automatic foreign-income exemption or a 10% charge on all QFC income. [qfc-tax2026](<https://qfcra-en.thomsonreuters.com/sites/default/files/net_file_store/QFCRA_7103_VER7.pdf>)",
      "id": "R0052.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "qfc-tax2026:charge-local-source",
        "qfc-rules2026:rule1A"
      ],
      "claim": "[qfc-rules2026](<https://qfcra-en.thomsonreuters.com/sites/default/files/net_file_store/QFCRA_8454_VER4.pdf>).",
      "id": "R0052.5",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "QFC Tax Regulations version 7 Articles 9–10",
      "block": "qfc-tax2026:charge-local-source",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/qfc-tax2026.txt",
      "capture_sha256": "61a456efda744e1d6f58faadc0e51cc388ae98537872f52a4996565ea65a8722",
      "limitations": [
        "Official QFCRA rulebook publisher; version7January2026. Article4 English is authoritative original. Other Parts/cross-referenced QFClicensing law not whole-read."
      ],
      "native_fragment_ids": [
        "N00467",
        "N00468",
        "N00469",
        "N00470",
        "N00471",
        "N00472",
        "N00473",
        "N00474",
        "N00475",
        "N00476",
        "N00477",
        "N00478",
        "N00479",
        "N00480",
        "N00481",
        "N00482",
        "N00483",
        "N00484",
        "N00485",
        "N00486",
        "N00487",
        "N00488",
        "N00489",
        "N00490",
        "N00491",
        "N00492",
        "N00493",
        "N00494",
        "N00495"
      ],
      "official_url": "https://qfcra-en.thomsonreuters.com/sites/default/files/net_file_store/QFCRA_7103_VER7.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00476",
      "read_scope": "Actual extracted lines 308–405, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [
        "full amount of its Local Source Taxable Profits. (2) The standard rate of corporation tax is 10%. ARTICLE 10 – LOCAL SOURCE (1) Taxable Profits"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "qfc-tax2026",
      "visual_proof": null
    },
    {
      "act_article": "QFC Tax Rules version 4 Rule 1A",
      "block": "qfc-rules2026:rule1A",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/qfc-rules2026.txt",
      "capture_sha256": "4aeab9d78b68160bb729b326c8156afa612b6da4c8908f6824522b3e21531154",
      "limitations": [
        "Official QFCRA rulebook publisher; version4January2026. OnlyRule1Aandneighbors read, not all TaxRules."
      ],
      "native_fragment_ids": [
        "N00496",
        "N00497",
        "N00498",
        "N00499",
        "N00500",
        "N00501",
        "N00502"
      ],
      "official_url": "https://qfcra-en.thomsonreuters.com/sites/default/files/net_file_store/QFCRA_8454_VER4.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00497",
      "read_scope": "Actual extracted lines 85–112, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [
        "Regulations”. 1A LOCAL SOURCE TAXABLE PROFITS Article 10(1A) of the QFC Tax Regulations shall apply only if all the following conditions are met for the"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "qfc-rules2026",
      "visual_proof": null
    }
  ],
  "old_lines": [
    95,
    96,
    97,
    100
  ],
  "section": "QFC is in Qatar",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0053

For **QFC is in Qatar**, resolve the individual source request under Sources before acting. [qfc-tax2026](<https://qfcra-en.thomsonreuters.com/sites/default/files/net_file_store/QFCRA_7103_VER7.pdf>).

```json
{
  "context_only_blocks": [],
  "current_lines": [
    104,
    104
  ],
  "id": "R0053",
  "individual_subclaims": [
    {
      "bindings": [
        "qfc-tax2026:language"
      ],
      "claim": "For **QFC is in Qatar**, resolve the individual source request under Sources before acting. [qfc-tax2026](<https://qfcra-en.thomsonreuters.com/sites/default/files/net_file_store/QFCRA_7103_VER7.pdf>).",
      "id": "R0053.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "QFC Tax Regulations version 7 Article 4",
      "block": "qfc-tax2026:language",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/qfc-tax2026.txt",
      "capture_sha256": "61a456efda744e1d6f58faadc0e51cc388ae98537872f52a4996565ea65a8722",
      "limitations": [
        "Official QFCRA rulebook publisher; version7January2026. Article4 English is authoritative original. Other Parts/cross-referenced QFClicensing law not whole-read."
      ],
      "native_fragment_ids": [
        "N00458",
        "N00459",
        "N00460",
        "N00461",
        "N00462",
        "N00463",
        "N00464",
        "N00465",
        "N00466"
      ],
      "official_url": "https://qfcra-en.thomsonreuters.com/sites/default/files/net_file_store/QFCRA_7103_VER7.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00461",
      "read_scope": "Actual extracted lines 265–295, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "qfc-tax2026",
      "visual_proof": null
    }
  ],
  "old_lines": [
    98,
    99,
    100
  ],
  "section": "QFC is in Qatar",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0054

## Saudi Arabia SEZs

```json
{
  "context_only_blocks": [],
  "current_lines": [
    106,
    106
  ],
  "id": "R0054",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "## Saudi Arabia SEZs",
      "id": "R0054.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    102,
    106
  ],
  "section": "Saudi Arabia SEZs",
  "source_read_record": null,
  "status": "heading"
}
```

### R0055

ZATCA’s current SEZ manual identifies ECZA and Council of Ministers Decision **468 of 30 December 2025**. Do not attribute these regimes to the Royal Commission for AlUla or an “RFAGZ Authority”. Its geographic-zone chapter and Cloud Computing chapter have different tax outcomes. The authority manual is read guidance, not a substitute for the complete licensing decision and actual tax law. **Not yet confirmed:** the original historical claim that April 2023 created 4 general-purpose zones plus NEOM and the Riyadh ILBZ. The current manual identifies 4 launched zones but does not establish that date or that combined creation/grouping claim; it is not a usable historical or licensing conclusion. [sa-sez-current](<https://zatca.gov.sa/en/HelpCenter/guidelines/Documents/SEZ-Tax%26Customs-Procedures.pdf>).

```json
{
  "context_only_blocks": [],
  "current_lines": [
    108,
    108
  ],
  "id": "R0055",
  "individual_subclaims": [
    {
      "bindings": [
        "sa-sez-current:intro"
      ],
      "claim": "ZATCA’s current SEZ manual identifies ECZA and Council of Ministers Decision **468 of 30 December 2025**.",
      "id": "R0055.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "sa-sez-current:intro"
      ],
      "claim": "Do not attribute these regimes to the Royal Commission for AlUla or an “RFAGZ Authority”.",
      "id": "R0055.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "sa-sez-current:intro"
      ],
      "claim": "Its geographic-zone chapter and Cloud Computing chapter have different tax outcomes.",
      "id": "R0055.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "sa-sez-current:intro"
      ],
      "claim": "The authority manual is read guidance, not a substitute for the complete licensing decision and actual tax law. **Not yet confirmed:** the original historical claim that April 2023 created 4 general-purpose zones plus NEOM and the Riyadh ILBZ.",
      "id": "R0055.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "sa-sez-current:intro"
      ],
      "claim": "The current manual identifies 4 launched zones but does not establish that date or that combined creation/grouping claim",
      "id": "R0055.5",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "sa-sez-current:intro"
      ],
      "claim": "it is not a usable historical or licensing conclusion. [sa-sez-current](<https://zatca.gov.sa/en/HelpCenter/guidelines/Documents/SEZ-Tax%26Customs-Procedures.pdf>).",
      "id": "R0055.6",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "ZATCA SEZ manual introduction/definitions and qualifying-activity lists, Council Decision 468",
      "block": "sa-sez-current:intro",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/sa-sez-current.txt",
      "capture_sha256": "89c3fabc9fde3e1c9340d578abc3eb667a59164ebb549656cf030e8369cc8b4b",
      "limitations": [
        "Actual ZATCA2026 manual underCouncil468/30Dec2025; guidance, not complete enacted decision or licensed entity clearance. VAT/customs substantive sections beyond stated read scopes not cleared."
      ],
      "native_fragment_ids": [
        "N00302",
        "N00303",
        "N00304",
        "N00305",
        "N00306",
        "N00307",
        "N00308",
        "N00309",
        "N00310",
        "N00311",
        "N00312",
        "N00313",
        "N00314",
        "N00315",
        "N00316",
        "N00317",
        "N00318",
        "N00319",
        "N00320",
        "N00321",
        "N00322",
        "N00323",
        "N00324",
        "N00325",
        "N00326",
        "N00327",
        "N00328",
        "N00329",
        "N00330",
        "N00331",
        "N00332",
        "N00333",
        "N00334",
        "N00335",
        "N00336",
        "N00337",
        "N00338",
        "N00339",
        "N00340",
        "N00341",
        "N00342",
        "N00343",
        "N00344",
        "N00345",
        "N00346",
        "N00347",
        "N00348",
        "N00349",
        "N00350",
        "N00351",
        "N00352",
        "N00353",
        "N00354",
        "N00355",
        "N00356",
        "N00357",
        "N00358"
      ],
      "official_url": "https://zatca.gov.sa/en/HelpCenter/guidelines/Documents/SEZ-Tax%26Customs-Procedures.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00310",
      "read_scope": "Actual extracted lines 1–184, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "sa-sez-current",
      "visual_proof": null
    }
  ],
  "old_lines": [
    24,
    104
  ],
  "section": "Saudi Arabia SEZs",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0056

| Zone | Supported position and individual limits |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    110,
    110
  ],
  "id": "R0056",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Zone",
      "id": "R0056.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Supported position and individual limits",
      "id": "R0056.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    108
  ],
  "section": "Saudi Arabia SEZs",
  "source_read_record": null,
  "status": "workflow/research question or table label; no current rule asserted"
}
```

### R0057

| --- | --- |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    111,
    111
  ],
  "id": "R0057",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "---",
      "id": "R0057.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "---",
      "id": "R0057.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    109
  ],
  "section": "Saudi Arabia SEZs",
  "source_read_record": null,
  "status": "table separator"
}
```

### R0058

| King Abdullah Economic City (KAEC) | For licensed qualifying activities, ZATCA describes **5% CIT for 20 years**, conditional withholding exemptions for specified non-resident payments and ordinary treatment for non-qualifying income. The original manufacturing, ICT/logistics labels do not prove a particular listed activity. Customs treatment is conditional **suspension/deferral**, not an unconditional 0% rate for all goods kept in-zone. See the individual source request under Sources. [sa-sez-current](<https://zatca.gov.sa/en/HelpCenter/guidelines/Documents/SEZ-Tax%26Customs-Procedures.pdf>) |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    112,
    112
  ],
  "id": "R0058",
  "individual_subclaims": [
    {
      "bindings": [
        "sa-sez-current:income-wht"
      ],
      "claim": "King Abdullah Economic City (KAEC)",
      "id": "R0058.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "sa-sez-current:income-wht"
      ],
      "claim": "For licensed qualifying activities, ZATCA describes **5% CIT for 20 years**, conditional withholding exemptions for specified non-resident payments and ordinary treatment for non-qualifying income. The original manufacturing, ICT/logistics labels do not prove a particular listed activity. Customs treatment is conditional **suspension/deferral**, not an unconditional 0% rate for all goods kept in-zone. See the individual source request under Sources. [sa-sez-current](<https://zatca.gov.sa/en/HelpCenter/guidelines/Documents/SEZ-Tax%26Customs-Procedures.pdf>)",
      "id": "R0058.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "ZATCA manual geographic SEZs sections 2.1–2.2, with 2.3 introduction",
      "block": "sa-sez-current:income-wht",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/sa-sez-current.txt",
      "capture_sha256": "89c3fabc9fde3e1c9340d578abc3eb667a59164ebb549656cf030e8369cc8b4b",
      "limitations": [
        "Actual ZATCA2026 manual underCouncil468/30Dec2025; guidance, not complete enacted decision or licensed entity clearance. VAT/customs substantive sections beyond stated read scopes not cleared."
      ],
      "native_fragment_ids": [
        "N00359",
        "N00360",
        "N00361",
        "N00362",
        "N00363",
        "N00364",
        "N00365",
        "N00366",
        "N00367",
        "N00368",
        "N00369",
        "N00370",
        "N00371",
        "N00372",
        "N00373",
        "N00374",
        "N00375",
        "N00376",
        "N00377",
        "N00378",
        "N00379",
        "N00380",
        "N00381",
        "N00382",
        "N00383",
        "N00384",
        "N00385",
        "N00386",
        "N00387",
        "N00388",
        "N00389",
        "N00390",
        "N00391",
        "N00392",
        "N00393",
        "N00394",
        "N00395",
        "N00396",
        "N00397",
        "N00398",
        "N00399",
        "N00400",
        "N00401",
        "N00402",
        "N00403",
        "N00404",
        "N00405",
        "N00406",
        "N00407",
        "N00408"
      ],
      "official_url": "https://zatca.gov.sa/en/HelpCenter/guidelines/Documents/SEZ-Tax%26Customs-Procedures.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00369",
      "read_scope": "Actual extracted lines 184–350, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "sa-sez-current",
      "visual_proof": null
    }
  ],
  "old_lines": [
    104,
    110
  ],
  "section": "Saudi Arabia SEZs",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0059

| Jazan | For licensed qualifying activities, ZATCA describes **5% CIT for 20 years**, conditional withholding exemptions for specified non-resident payments and ordinary treatment for non-qualifying income. The original manufacturing, food/mining labels do not prove a particular listed activity. Customs treatment is conditional **suspension/deferral**, not an unconditional 0% rate for all goods kept in-zone. See the individual source request under Sources. [sa-sez-current](<https://zatca.gov.sa/en/HelpCenter/guidelines/Documents/SEZ-Tax%26Customs-Procedures.pdf>) |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    113,
    113
  ],
  "id": "R0059",
  "individual_subclaims": [
    {
      "bindings": [
        "sa-sez-current:income-wht"
      ],
      "claim": "Jazan",
      "id": "R0059.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "sa-sez-current:income-wht"
      ],
      "claim": "For licensed qualifying activities, ZATCA describes **5% CIT for 20 years**, conditional withholding exemptions for specified non-resident payments and ordinary treatment for non-qualifying income. The original manufacturing, food/mining labels do not prove a particular listed activity. Customs treatment is conditional **suspension/deferral**, not an unconditional 0% rate for all goods kept in-zone. See the individual source request under Sources. [sa-sez-current](<https://zatca.gov.sa/en/HelpCenter/guidelines/Documents/SEZ-Tax%26Customs-Procedures.pdf>)",
      "id": "R0059.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "ZATCA manual geographic SEZs sections 2.1–2.2, with 2.3 introduction",
      "block": "sa-sez-current:income-wht",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/sa-sez-current.txt",
      "capture_sha256": "89c3fabc9fde3e1c9340d578abc3eb667a59164ebb549656cf030e8369cc8b4b",
      "limitations": [
        "Actual ZATCA2026 manual underCouncil468/30Dec2025; guidance, not complete enacted decision or licensed entity clearance. VAT/customs substantive sections beyond stated read scopes not cleared."
      ],
      "native_fragment_ids": [
        "N00359",
        "N00360",
        "N00361",
        "N00362",
        "N00363",
        "N00364",
        "N00365",
        "N00366",
        "N00367",
        "N00368",
        "N00369",
        "N00370",
        "N00371",
        "N00372",
        "N00373",
        "N00374",
        "N00375",
        "N00376",
        "N00377",
        "N00378",
        "N00379",
        "N00380",
        "N00381",
        "N00382",
        "N00383",
        "N00384",
        "N00385",
        "N00386",
        "N00387",
        "N00388",
        "N00389",
        "N00390",
        "N00391",
        "N00392",
        "N00393",
        "N00394",
        "N00395",
        "N00396",
        "N00397",
        "N00398",
        "N00399",
        "N00400",
        "N00401",
        "N00402",
        "N00403",
        "N00404",
        "N00405",
        "N00406",
        "N00407",
        "N00408"
      ],
      "official_url": "https://zatca.gov.sa/en/HelpCenter/guidelines/Documents/SEZ-Tax%26Customs-Procedures.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00369",
      "read_scope": "Actual extracted lines 184–350, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "sa-sez-current",
      "visual_proof": null
    }
  ],
  "old_lines": [
    104,
    111
  ],
  "section": "Saudi Arabia SEZs",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0060

| Ras Al Khair | For licensed qualifying activities, ZATCA describes **5% CIT for 20 years**, conditional withholding exemptions for specified non-resident payments and ordinary treatment for non-qualifying income. The original maritime, shipbuilding/MRO labels do not prove a particular listed activity. Customs treatment is conditional **suspension/deferral**, not an unconditional 0% rate for all goods kept in-zone. See the individual source request under Sources. [sa-sez-current](<https://zatca.gov.sa/en/HelpCenter/guidelines/Documents/SEZ-Tax%26Customs-Procedures.pdf>) |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    114,
    114
  ],
  "id": "R0060",
  "individual_subclaims": [
    {
      "bindings": [
        "sa-sez-current:income-wht"
      ],
      "claim": "Ras Al Khair",
      "id": "R0060.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "sa-sez-current:income-wht"
      ],
      "claim": "For licensed qualifying activities, ZATCA describes **5% CIT for 20 years**, conditional withholding exemptions for specified non-resident payments and ordinary treatment for non-qualifying income. The original maritime, shipbuilding/MRO labels do not prove a particular listed activity. Customs treatment is conditional **suspension/deferral**, not an unconditional 0% rate for all goods kept in-zone. See the individual source request under Sources. [sa-sez-current](<https://zatca.gov.sa/en/HelpCenter/guidelines/Documents/SEZ-Tax%26Customs-Procedures.pdf>)",
      "id": "R0060.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "ZATCA manual geographic SEZs sections 2.1–2.2, with 2.3 introduction",
      "block": "sa-sez-current:income-wht",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/sa-sez-current.txt",
      "capture_sha256": "89c3fabc9fde3e1c9340d578abc3eb667a59164ebb549656cf030e8369cc8b4b",
      "limitations": [
        "Actual ZATCA2026 manual underCouncil468/30Dec2025; guidance, not complete enacted decision or licensed entity clearance. VAT/customs substantive sections beyond stated read scopes not cleared."
      ],
      "native_fragment_ids": [
        "N00359",
        "N00360",
        "N00361",
        "N00362",
        "N00363",
        "N00364",
        "N00365",
        "N00366",
        "N00367",
        "N00368",
        "N00369",
        "N00370",
        "N00371",
        "N00372",
        "N00373",
        "N00374",
        "N00375",
        "N00376",
        "N00377",
        "N00378",
        "N00379",
        "N00380",
        "N00381",
        "N00382",
        "N00383",
        "N00384",
        "N00385",
        "N00386",
        "N00387",
        "N00388",
        "N00389",
        "N00390",
        "N00391",
        "N00392",
        "N00393",
        "N00394",
        "N00395",
        "N00396",
        "N00397",
        "N00398",
        "N00399",
        "N00400",
        "N00401",
        "N00402",
        "N00403",
        "N00404",
        "N00405",
        "N00406",
        "N00407",
        "N00408"
      ],
      "official_url": "https://zatca.gov.sa/en/HelpCenter/guidelines/Documents/SEZ-Tax%26Customs-Procedures.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00369",
      "read_scope": "Actual extracted lines 184–350, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "sa-sez-current",
      "visual_proof": null
    }
  ],
  "old_lines": [
    104,
    112
  ],
  "section": "Saudi Arabia SEZs",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0061

| Cloud Computing SEZ | The manual’s separate chapter applies ordinary **20%** income tax, ordinary WHT/VAT rules and treaty/PE/TP analysis, rather than 5% for 20 years or blanket 0% withholding. The Riyadh administrative/HQ zone and qualifying data-centre activity elsewhere in Saudi Arabia need their own licence conditions. See the individual source request under Sources. [sa-sez-current](<https://zatca.gov.sa/en/HelpCenter/guidelines/Documents/SEZ-Tax%26Customs-Procedures.pdf>) |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    115,
    115
  ],
  "id": "R0061",
  "individual_subclaims": [
    {
      "bindings": [
        "sa-sez-current:cloud"
      ],
      "claim": "Cloud Computing SEZ",
      "id": "R0061.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "sa-sez-current:cloud"
      ],
      "claim": "The manual’s separate chapter applies ordinary **20%** income tax, ordinary WHT/VAT rules and treaty/PE/TP analysis, rather than 5% for 20 years or blanket 0% withholding. The Riyadh administrative/HQ zone and qualifying data-centre activity elsewhere in Saudi Arabia need their own licence conditions. See the individual source request under Sources. [sa-sez-current](<https://zatca.gov.sa/en/HelpCenter/guidelines/Documents/SEZ-Tax%26Customs-Procedures.pdf>)",
      "id": "R0061.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "ZATCA manual Cloud Computing chapter",
      "block": "sa-sez-current:cloud",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/sa-sez-current.txt",
      "capture_sha256": "89c3fabc9fde3e1c9340d578abc3eb667a59164ebb549656cf030e8369cc8b4b",
      "limitations": [
        "Actual ZATCA2026 manual underCouncil468/30Dec2025; guidance, not complete enacted decision or licensed entity clearance. VAT/customs substantive sections beyond stated read scopes not cleared."
      ],
      "native_fragment_ids": [
        "N00409",
        "N00410",
        "N00411",
        "N00412",
        "N00413",
        "N00414",
        "N00415",
        "N00416",
        "N00417",
        "N00418",
        "N00419",
        "N00420",
        "N00421",
        "N00422",
        "N00423",
        "N00424",
        "N00425",
        "N00426",
        "N00427",
        "N00428",
        "N00429",
        "N00430",
        "N00431",
        "N00432",
        "N00433",
        "N00434",
        "N00435",
        "N00436",
        "N00437",
        "N00438",
        "N00439",
        "N00440",
        "N00441",
        "N00442",
        "N00443",
        "N00444",
        "N00445",
        "N00446",
        "N00447",
        "N00448",
        "N00449",
        "N00450",
        "N00451",
        "N00452",
        "N00453",
        "N00454",
        "N00455",
        "N00456",
        "N00457"
      ],
      "official_url": "https://zatca.gov.sa/en/HelpCenter/guidelines/Documents/SEZ-Tax%26Customs-Procedures.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00409",
      "read_scope": "Actual extracted lines 1153–1315, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "sa-sez-current",
      "visual_proof": null
    }
  ],
  "old_lines": [
    104,
    113
  ],
  "section": "Saudi Arabia SEZs",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0062

| NEOM | See the individual source request under Sources. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    116,
    116
  ],
  "id": "R0062",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "NEOM",
      "id": "R0062.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "See the individual source request under Sources.",
      "id": "R0062.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    104,
    114
  ],
  "section": "Saudi Arabia SEZs",
  "source_read_record": null,
  "status": "workflow/research question or table label; no current rule asserted"
}
```

### R0063

| Riyadh Integrated Logistics Bonded Zone (ILBZ) | See the individual source request under Sources. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    117,
    117
  ],
  "id": "R0063",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Riyadh Integrated Logistics Bonded Zone (ILBZ)",
      "id": "R0063.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "See the individual source request under Sources.",
      "id": "R0063.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    104,
    115
  ],
  "section": "Saudi Arabia SEZs",
  "source_read_record": null,
  "status": "workflow/research question or table label; no current rule asserted"
}
```

### R0064

For **Saudi Arabia SEZs**, resolve the individual source request under Sources before acting.

```json
{
  "context_only_blocks": [],
  "current_lines": [
    119,
    119
  ],
  "id": "R0064",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "For **Saudi Arabia SEZs**, resolve the individual source request under Sources before acting.",
      "id": "R0064.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    117,
    223
  ],
  "section": "Saudi Arabia SEZs",
  "source_read_record": null,
  "status": "scope/workflow/refusal/protected disclaimer; no new statutory assertion"
}
```

### R0065

## China and Hong Kong

```json
{
  "context_only_blocks": [],
  "current_lines": [
    121,
    121
  ],
  "id": "R0065",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "## China and Hong Kong",
      "id": "R0065.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    119,
    121
  ],
  "section": "China and Hong Kong",
  "source_read_record": null,
  "status": "heading"
}
```

### R0066

| Zone | Supported position and individual limits |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    123,
    123
  ],
  "id": "R0066",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Zone",
      "id": "R0066.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Supported position and individual limits",
      "id": "R0066.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    123
  ],
  "section": "China and Hong Kong",
  "source_read_record": null,
  "status": "workflow/research question or table label; no current rule asserted"
}
```

### R0067

| --- | --- |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    124,
    124
  ],
  "id": "R0067",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "---",
      "id": "R0067.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "---",
      "id": "R0067.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    124
  ],
  "section": "China and Hong Kong",
  "source_read_record": null,
  "status": "table separator"
}
```

### R0068

| Hainan Free Trade Port | Notice 2020(31) gives **15%** for registered, substantially operating encouraged-industry enterprises with at least **60%** qualifying main-business revenue and the stated HQ/branch rules. The government republication of **2025(3)** extends the policy through **31 December 2027**; 2025 is not the present expiry. See the individual source request under Sources. [hainan-base](<https://fgk.chinatax.gov.cn/zcfgk/c102416/c5202204/content.html>); [hainan-extension](<https://policy.mofcom.gov.cn/claw/clawContent.shtml?id=103253>) |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    125,
    125
  ],
  "id": "R0068",
  "individual_subclaims": [
    {
      "bindings": [
        "hainan-base:operative",
        "hainan-extension:extension"
      ],
      "claim": "Hainan Free Trade Port",
      "id": "R0068.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "hainan-base:operative",
        "hainan-extension:extension"
      ],
      "claim": "Notice 2020(31) gives **15%** for registered, substantially operating encouraged-industry enterprises with at least **60%** qualifying main-business revenue and the stated HQ/branch rules. The government republication of **2025(3)** extends the policy through **31 December 2027**; 2025 is not the present expiry. See the individual source request under Sources. [hainan-base](<https://fgk.chinatax.gov.cn/zcfgk/c102416/c5202204/content.html>); [hainan-extension](<https://policy.mofcom.gov.cn/claw/clawContent.shtml?id=103253>)",
      "id": "R0068.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "Notice 2020(31) paragraphs 1–4",
      "block": "hainan-base:operative",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/hainan-base.txt",
      "capture_sha256": "173b95d069845feb326bc39b2c1e1fe867adb2e7ffb947f10cb74f98822b8103",
      "limitations": [
        "STAactual2020(31)body; later extension separately read; currentIITtalentrules not read."
      ],
      "native_fragment_ids": [
        "N00503",
        "N00504",
        "N00505",
        "N00506",
        "N00507",
        "N00508",
        "N00509",
        "N00510",
        "N00511",
        "N00512",
        "N00513",
        "N00514",
        "N00515",
        "N00516",
        "N00517",
        "N00518"
      ],
      "official_url": "https://fgk.chinatax.gov.cn/zcfgk/c102416/c5202204/content.html",
      "own_read_date": "2026-11-16",
      "quote_id": "N00518",
      "read_scope": "Actual extracted lines 48–63, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [
        "四、本通知自2020年1月1日起执行至2024年12月31日。 财政部 税务总局 2020年6月23日"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "hainan-base",
      "visual_proof": null
    },
    {
      "act_article": "Notice 2025(3) extension",
      "block": "hainan-extension:extension",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/hainan-extension.txt",
      "capture_sha256": "e67a8d0b98e572847be0c616bee3a4d25f57b20d11e7b660fcf0c7dd3cd309bf",
      "limitations": [
        "MOFCOMgovernment republication expressly disclaims completeness/currentness; originalMOFsource not recovered."
      ],
      "native_fragment_ids": [
        "N00519",
        "N00520",
        "N00521",
        "N00522",
        "N00523",
        "N00524",
        "N00525"
      ],
      "official_url": "https://policy.mofcom.gov.cn/claw/clawContent.shtml?id=103253",
      "own_read_date": "2026-11-16",
      "quote_id": "N00521",
      "read_scope": "Actual extracted lines 23–35, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [
        "税务总局关于海南自由贸易港企业所得税优惠政策的通知》（财税〔2020〕31号）规定的税收优惠政策，执行期限延长至2027年12月31日。 二、《财政部"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "hainan-extension",
      "visual_proof": null
    }
  ],
  "old_lines": [
    25,
    125
  ],
  "section": "China and Hong Kong",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0069

| Shanghai Lin-gang | Notice 2020(38) describes **15% for 5 years from establishment** for the defined key industries, including integrated circuits, AI, biomedicine and civil aviation. New registration/substantive production or R&D/key-product conditions and the specified investor-or-R&D alternative matter; inward relocation is not generally sufficient. See the individual source request under Sources. [lingang-base](<https://www.chinatax.gov.cn/chinatax/n810341/n810765/c101653/202007/c5156590/content.html>) |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    126,
    126
  ],
  "id": "R0069",
  "individual_subclaims": [
    {
      "bindings": [
        "lingang-base:operative"
      ],
      "claim": "Shanghai Lin-gang",
      "id": "R0069.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "lingang-base:operative"
      ],
      "claim": "Notice 2020(38) describes **15% for 5 years from establishment** for the defined key industries, including integrated circuits, AI, biomedicine and civil aviation. New registration/substantive production or R&D/key-product conditions and the specified investor-or-R&D alternative matter; inward relocation is not generally sufficient. See the individual source request under Sources. [lingang-base](<https://www.chinatax.gov.cn/chinatax/n810341/n810765/c101653/202007/c5156590/content.html>)",
      "id": "R0069.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "Notice 2020(38) paragraphs 1–4",
      "block": "lingang-base:operative",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/lingang-base.txt",
      "capture_sha256": "21515fa0464245416e2c5b9b873e1629f506dd39c046931145b335f3eb1dff1f",
      "limitations": [
        "STAactual2020(38)body; annex catalogue/current recognition procedure not read."
      ],
      "native_fragment_ids": [
        "N00526",
        "N00527",
        "N00528",
        "N00529",
        "N00530",
        "N00531",
        "N00532",
        "N00533",
        "N00534",
        "N00535",
        "N00536",
        "N00537",
        "N00538",
        "N00539",
        "N00540",
        "N00541",
        "N00542",
        "N00543"
      ],
      "official_url": "https://www.chinatax.gov.cn/chinatax/n810341/n810765/c101653/202007/c5156590/content.html",
      "own_read_date": "2026-11-16",
      "quote_id": "N00529",
      "read_scope": "Actual extracted lines 28–50, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [
        "产或研发活动的符合条件的法人企业，自设立之日起5年内减按15%的税率征收企业所得税。"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "lingang-base",
      "visual_proof": null
    }
  ],
  "old_lines": [
    126
  ],
  "section": "China and Hong Kong",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0070

| Shenzhen Qianhai | The official Hong Kong Trade Department republication of mainland **2026(3)** extends Notices 2021(30)/2024(13) through **31 December 2027**. See the individual source request under Sources. [qianhai-extension](<https://www.tid.gov.hk/en/tradecircular/files/2026/ci1712026a.pdf>) |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    127,
    127
  ],
  "id": "R0070",
  "individual_subclaims": [
    {
      "bindings": [
        "qianhai-extension:extension"
      ],
      "claim": "Shenzhen Qianhai",
      "id": "R0070.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "qianhai-extension:extension"
      ],
      "claim": "The official Hong Kong Trade Department republication of mainland **2026(3)** extends Notices 2021(30)/2024(13) through **31 December 2027**. See the individual source request under Sources. [qianhai-extension](<https://www.tid.gov.hk/en/tradecircular/files/2026/ci1712026a.pdf>)",
      "id": "R0070.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "Notice 2026(3), extending 2021(30)/2024(13)",
      "block": "qianhai-extension:extension",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/qianhai-extension.txt",
      "capture_sha256": "37621c9cbf60a2dffc8623d10d58c614111358e4cb4e3dec68e712491afe1574",
      "limitations": [
        "Official HKTradeDepartment reproduction of2026(3); mainland original/current base eligibility not recovered."
      ],
      "native_fragment_ids": [
        "N00544",
        "N00545",
        "N00546",
        "N00547",
        "N00548"
      ],
      "official_url": "https://www.tid.gov.hk/en/tradecircular/files/2026/ci1712026a.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00547",
      "read_scope": "Actual extracted lines 1–31, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [
        "(财税〔2021〕30 号)、《财政部 税务总局关于前海深港现代服务业合作区企业所得税优惠政策 的通知》(财税〔2024〕13 号)规定的税收优惠政策，执行期限延长至 2027 年 12"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "qianhai-extension",
      "visual_proof": null
    }
  ],
  "old_lines": [
    127
  ],
  "section": "China and Hong Kong",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0071

| Hengqin (Guangdong-Macao) | The government English translation of Notice 2022(19) describes **15%**, at least **60%** qualifying main-business revenue and substantive-operation/HQ-branch conditions for encouraged industries. The Chinese text prevails under the source’s disclaimer. See the individual source request under Sources. [hengqin-base](<https://www.hengqin.gov.cn/macau_2022_en/regulations/documents/pgp/content/post_3744459.html>) |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    128,
    128
  ],
  "id": "R0071",
  "individual_subclaims": [
    {
      "bindings": [
        "hengqin-base:operative"
      ],
      "claim": "Hengqin (Guangdong-Macao)",
      "id": "R0071.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "hengqin-base:operative"
      ],
      "claim": "The government English translation of Notice 2022(19) describes **15%**, at least **60%** qualifying main-business revenue and substantive-operation/HQ-branch conditions for encouraged industries. The Chinese text prevails under the source’s disclaimer. See the individual source request under Sources. [hengqin-base](<https://www.hengqin.gov.cn/macau_2022_en/regulations/documents/pgp/content/post_3744459.html>)",
      "id": "R0071.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "Notice 2022(19) paragraphs I–VI",
      "block": "hengqin-base:operative",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/hengqin-base.txt",
      "capture_sha256": "ca679bdcbbb8cb637c64732d6fbf26505d7af090fbbcc4246e5470fb9c5c6d36",
      "limitations": [
        "Government English reference translation expressly says Chinese prevails; entire150-itemcatalogue not read."
      ],
      "native_fragment_ids": [
        "N00549",
        "N00550",
        "N00551",
        "N00552",
        "N00553",
        "N00554",
        "N00555",
        "N00556",
        "N00557",
        "N00558",
        "N00559",
        "N00560",
        "N00561",
        "N00562",
        "N00563",
        "N00564",
        "N00565",
        "N00566",
        "N00567",
        "N00568",
        "N00569",
        "N00570",
        "N00571",
        "N00572",
        "N00573",
        "N00574",
        "N00575",
        "N00576",
        "N00577",
        "N00578",
        "N00579",
        "N00580",
        "N00581",
        "N00582",
        "N00583",
        "N00584",
        "N00585",
        "N00586",
        "N00587",
        "N00588",
        "N00589",
        "N00590",
        "N00591",
        "N00592",
        "N00593",
        "N00594",
        "N00595",
        "N00596",
        "N00597",
        "N00598"
      ],
      "official_url": "https://www.hengqin.gov.cn/macau_2022_en/regulations/documents/pgp/content/post_3744459.html",
      "own_read_date": "2026-11-16",
      "quote_id": "N00549",
      "read_scope": "Actual extracted lines 5–42, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [
        "发布日期：2022-05-25 This English translation is for reference only. The Chinese version shall prevail in case of any inconsistencies. Notice by the Department of Finance of"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "hengqin-base",
      "visual_proof": null
    }
  ],
  "old_lines": [
    128
  ],
  "section": "China and Hong Kong",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0072

| General FTZs: Shanghai, Tianjin, Fujian, Guangdong | See the individual source request under Sources. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    129,
    129
  ],
  "id": "R0072",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "General FTZs: Shanghai, Tianjin, Fujian, Guangdong",
      "id": "R0072.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "See the individual source request under Sources.",
      "id": "R0072.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    129
  ],
  "section": "China and Hong Kong",
  "source_read_record": null,
  "status": "workflow/research question or table label; no current rule asserted"
}
```

### R0073

| Hong Kong | Separate tax jurisdiction, not a mainland SEZ. The actual IRD overview states corporation two-tier **8.25% on the first HKD 2,000,000 /16.5% above** and the territorial-source principle. Its separate FSIE guidance covers specified foreign-source dividends, interest, IP income and equity-disposal gains from **1 January 2023**, expanding to other disposal gains from **1 January 2024**, for covered MNE entities and Hong Kong receipt, subject to specified exclusions and economic-substance/nexus/participation or intra-group relief conditions. An offshore claim is not automatic. See the individual source request under Sources. [hk-tax](<https://www.ird.gov.hk/eng/tax/bus_pft.htm>); [hk-fsie](<https://www.ird.gov.hk/eng/tax/bus_fsie.htm>) |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    130,
    130
  ],
  "id": "R0073",
  "individual_subclaims": [
    {
      "bindings": [
        "hk-tax:scope-rates",
        "hk-fsie:dates-scope",
        "hk-fsie:taxpayers-treatment",
        "hk-tax:scope-rates-table"
      ],
      "claim": "Hong Kong",
      "id": "R0073.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "hk-tax:scope-rates",
        "hk-fsie:dates-scope",
        "hk-fsie:taxpayers-treatment",
        "hk-tax:scope-rates-table"
      ],
      "claim": "Separate tax jurisdiction, not a mainland SEZ. The actual IRD overview states corporation two-tier **8.25% on the first HKD 2,000,000 /16.5% above** and the territorial-source principle. Its separate FSIE guidance covers specified foreign-source dividends, interest, IP income and equity-disposal gains from **1 January 2023**, expanding to other disposal gains from **1 January 2024**, for covered MNE entities and Hong Kong receipt, subject to specified exclusions and economic-substance/nexus/participation or intra-group relief conditions. An offshore claim is not automatic. See the individual source request under Sources. [hk-tax](<https://www.ird.gov.hk/eng/tax/bus_pft.htm>); [hk-fsie](<https://www.ird.gov.hk/eng/tax/bus_fsie.htm>)",
      "id": "R0073.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "IRD profits-tax overview source principle",
      "block": "hk-tax:scope-rates",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/incorporation/sources/hk-tax.txt",
      "capture_sha256": "3072cbfe622583deb481331b6b7d8a36c305fb19e1739bf7d3c0422a0717db73",
      "limitations": [
        "Authority guidance, not all cross-referenced IROprovisions or entity-specificsource/exception/two-tierconnected-entityclearance."
      ],
      "native_fragment_ids": [
        "N00783",
        "N00784",
        "N00785",
        "N00786",
        "N00787",
        "N00788",
        "N00789",
        "N00790",
        "N00791",
        "N00792",
        "N00793"
      ],
      "official_url": "https://www.ird.gov.hk/eng/tax/bus_pft.htm",
      "own_read_date": "2026-11-16",
      "quote_id": "N00787",
      "read_scope": "Actual extracted lines 33–42, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [
        "profits are derived from Hong Kong is largely one of fact, however some guidance on the principles applied can be found in cases which have"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "hk-tax",
      "visual_proof": null
    },
    {
      "act_article": "IRD FSIE overview commencement/income categories",
      "block": "hk-fsie:dates-scope",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/incorporation/sources/hk-fsie.txt",
      "capture_sha256": "99d28c567230056aa9a1aeef0144c30c66e29176c56f2c637ba96564b20efe39",
      "limitations": [
        "Authority guidance, not all cross-referenced IROprovisions or entity-specificsource/exception/two-tierconnected-entityclearance."
      ],
      "native_fragment_ids": [
        "N00799",
        "N00800",
        "N00801",
        "N00802",
        "N00803",
        "N00804",
        "N00805",
        "N00806",
        "N00807",
        "N00808",
        "N00809",
        "N00810",
        "N00811",
        "N00812",
        "N00813",
        "N00814",
        "N00815",
        "N00816",
        "N00817",
        "N00818",
        "N00819",
        "N00820",
        "N00821",
        "N00822",
        "N00823",
        "N00824",
        "N00825",
        "N00826",
        "N00827",
        "N00828",
        "N00829",
        "N00830",
        "N00831",
        "N00832",
        "N00833",
        "N00834",
        "N00835",
        "N00836",
        "N00837",
        "N00838",
        "N00839",
        "N00840",
        "N00841",
        "N00842",
        "N00843",
        "N00844",
        "N00845"
      ],
      "official_url": "https://www.ird.gov.hk/eng/tax/bus_fsie.htm",
      "own_read_date": "2026-11-16",
      "quote_id": "N00808",
      "read_scope": "Actual extracted lines 33–88, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [
        "treatments of foreign-sourced disposal gains in compliance with the Updated FSIE Guidance by the end of 2023 for implementation with effect from January 2024. To"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "hk-fsie",
      "visual_proof": null
    },
    {
      "act_article": "IRD FSIE covered taxpayers, receipt and exception overview",
      "block": "hk-fsie:taxpayers-treatment",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/incorporation/sources/hk-fsie.txt",
      "capture_sha256": "99d28c567230056aa9a1aeef0144c30c66e29176c56f2c637ba96564b20efe39",
      "limitations": [
        "Authority guidance, not all cross-referenced IROprovisions or entity-specificsource/exception/two-tierconnected-entityclearance."
      ],
      "native_fragment_ids": [
        "N00846",
        "N00847",
        "N00848",
        "N00849",
        "N00850",
        "N00851",
        "N00852",
        "N00853",
        "N00854",
        "N00855",
        "N00856",
        "N00857",
        "N00858",
        "N00859",
        "N00860",
        "N00861",
        "N00862",
        "N00863",
        "N00864",
        "N00865",
        "N00866",
        "N00867",
        "N00868",
        "N00869",
        "N00870",
        "N00871",
        "N00872",
        "N00873",
        "N00874",
        "N00875",
        "N00876"
      ],
      "official_url": "https://www.ird.gov.hk/eng/tax/bus_fsie.htm",
      "own_read_date": "2026-11-16",
      "quote_id": "N00863",
      "read_scope": "Actual extracted lines 231–289, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "hk-fsie",
      "visual_proof": null
    },
    {
      "act_article": "IRD profits-tax overview corporation rate table",
      "block": "hk-tax:scope-rates-table",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/incorporation/sources/hk-tax.txt",
      "capture_sha256": "3072cbfe622583deb481331b6b7d8a36c305fb19e1739bf7d3c0422a0717db73",
      "limitations": [
        "Authority guidance, not all cross-referenced IROprovisions or entity-specificsource/exception/two-tierconnected-entityclearance."
      ],
      "native_fragment_ids": [
        "N00794",
        "N00795",
        "N00796",
        "N00797",
        "N00798"
      ],
      "official_url": "https://www.ird.gov.hk/eng/tax/bus_pft.htm",
      "own_read_date": "2026-11-16",
      "quote_id": "N00795",
      "read_scope": "Actual extracted lines 217–235, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "hk-tax",
      "visual_proof": null
    }
  ],
  "old_lines": [
    130
  ],
  "section": "China and Hong Kong",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0074

## India SEZs and GIFT City

```json
{
  "context_only_blocks": [],
  "current_lines": [
    132,
    132
  ],
  "id": "R0074",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "## India SEZs and GIFT City",
      "id": "R0074.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    132,
    136
  ],
  "section": "India SEZs and GIFT City",
  "source_read_record": null,
  "status": "heading"
}
```

### R0075

The SEZ Act **2005** remains the source opened for the DTA provision. [india-sez-web](<https://sezindia.gov.in/sites/default/files/SEZAct2005.pdf>).

```json
{
  "context_only_blocks": [],
  "current_lines": [
    134,
    134
  ],
  "id": "R0075",
  "individual_subclaims": [
    {
      "bindings": [
        "india-sez-web:section30"
      ],
      "claim": "The SEZ Act **2005** remains the source opened for the DTA provision. [india-sez-web](<https://sezindia.gov.in/sites/default/files/SEZAct2005.pdf>).",
      "id": "R0075.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "SEZ Act 2005 section 30",
      "block": "india-sez-web:section30",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/india-sez-web-web-selected.txt",
      "capture_sha256": "5b97f27fa26ec7de606e732667f74fcce1fa63c6bb7ff4cbd932cd67846bae95",
      "limitations": [
        "Actual enacted2005Actsection30andneighbors. Cross-referenced current customs rules/notifications not cleared; not a complete current consolidation of the SEZ/GSTpackage.",
        "Only tool Lnn locators and citation wrappers removed, retaining visible anchor text; raw response immutable."
      ],
      "native_fragment_ids": [
        "N00696",
        "N00697",
        "N00698",
        "N00699",
        "N00700"
      ],
      "official_url": "https://sezindia.gov.in/sites/default/files/SEZAct2005.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00696",
      "read_scope": "Actual extracted lines 1–15, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [
        "Domestic clearance by Units. 30. Subject to the conditions specified in the rules made by the Central Government in this behalf:- (a) any goods removed"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "india-sez-web",
      "visual_proof": null
    }
  ],
  "old_lines": [
    134
  ],
  "section": "India SEZs and GIFT City",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0076

| Subject | Supported position and individual limits |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    136,
    136
  ],
  "id": "R0076",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Subject",
      "id": "R0076.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Supported position and individual limits",
      "id": "R0076.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    138
  ],
  "section": "India SEZs and GIFT City",
  "source_read_record": null,
  "status": "workflow/research question or table label; no current rule asserted"
}
```

### R0077

| --- | --- |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    137,
    137
  ],
  "id": "R0077",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "---",
      "id": "R0077.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "---",
      "id": "R0077.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    139
  ],
  "section": "India SEZs and GIFT City",
  "source_read_record": null,
  "status": "table separator"
}
```

### R0078

| Legacy section 10AA | The actually read 1961-Act **2024 (No.2)** section 10AA provides **100% for 5 assessment years**, **50% for the next 5**, then up to **50% for the next 5** through the specified reinvestment reserve and its use/recapture conditions. It has commencement, anti-reconstruction, export/receipt, return/certification and computation conditions; it is not a general new-unit holiday. Income-tax Act 2025 **section 144** continues only the eligible unexpired deduction period under its transitional terms from the new Act’s **1 April 2026** commencement. See the individual source request under Sources. [india10aa-web](<https://www.incometaxindia.gov.in/hi/w/section-10aa-19>); [india-act2025](<https://egazette.gov.in/WriteReadData/2025/265620.pdf>) |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    138,
    138
  ],
  "id": "R0078",
  "individual_subclaims": [
    {
      "bindings": [
        "india10aa-web:section10AA",
        "india-act2025:section144",
        "india-act2025:commencement"
      ],
      "claim": "Legacy section 10AA",
      "id": "R0078.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "india10aa-web:section10AA",
        "india-act2025:section144",
        "india-act2025:commencement"
      ],
      "claim": "The actually read 1961-Act **2024 (No.2)** section 10AA provides **100% for 5 assessment years**, **50% for the next 5**, then up to **50% for the next 5** through the specified reinvestment reserve and its use/recapture conditions. It has commencement, anti-reconstruction, export/receipt, return/certification and computation conditions; it is not a general new-unit holiday. Income-tax Act 2025 **section 144** continues only the eligible unexpired deduction period under its transitional terms from the new Act’s **1 April 2026** commencement. See the individual source request under Sources. [india10aa-web](<https://www.incometaxindia.gov.in/hi/w/section-10aa-19>); [india-act2025](<https://egazette.gov.in/WriteReadData/2025/265620.pdf>)",
      "id": "R0078.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "Income-tax Act 1961 section 10AA(1)–(10) and definitions, 2024(No.2) edition",
      "block": "india10aa-web:section10AA",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/india10aa-web-web-selected.txt",
      "capture_sha256": "d545932c16bec4140b54c3659b9ab8a6eaf14e42cde2721f9ace29191eb9daa3",
      "limitations": [
        "Explicit2024(No2)edition. Whole10AAremainder personally read in fz-open23; current2025Act144onlyeligibleunexpiredperiods. Covidrelaxationandcross-referencedeligibility/notification requirements not cleared.",
        "Only tool Lnn locators and citation wrappers removed, retaining visible anchor text; raw response immutable."
      ],
      "native_fragment_ids": [
        "N00701",
        "N00702",
        "N00703",
        "N00704",
        "N00705",
        "N00706",
        "N00707",
        "N00708",
        "N00709",
        "N00710",
        "N00711",
        "N00712",
        "N00713",
        "N00714",
        "N00715",
        "N00716",
        "N00717",
        "N00718",
        "N00719",
        "N00720",
        "N00721",
        "N00722",
        "N00723",
        "N00724",
        "N00725",
        "N00726",
        "N00727",
        "N00728",
        "N00729",
        "N00730",
        "N00731",
        "N00732",
        "N00733",
        "N00734",
        "N00735",
        "N00736",
        "N00737",
        "N00738",
        "N00739",
        "N00740",
        "N00741",
        "N00742",
        "N00743",
        "N00744",
        "N00745",
        "N00746",
        "N00747",
        "N00748",
        "N00749",
        "N00750",
        "N00751",
        "N00752",
        "N00753",
        "N00754",
        "N00755",
        "N00756",
        "N00757",
        "N00758",
        "N00759",
        "N00760",
        "N00761",
        "N00762",
        "N00763",
        "N00764",
        "N00765",
        "N00766",
        "N00767",
        "N00768",
        "N00769",
        "N00770",
        "N00771",
        "N00772",
        "N00773",
        "N00774",
        "N00775",
        "N00776",
        "N00777",
        "N00778",
        "N00779",
        "N00780",
        "N00781",
        "N00782"
      ],
      "official_url": "https://www.incometaxindia.gov.in/hi/w/section-10aa-19",
      "own_read_date": "2026-11-16",
      "quote_id": "N00732",
      "read_scope": "Actual extracted lines 1–76, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [
        "10A for ten consecutive assessment years, such Unit shall not be eligible for deduction from income under this section : Provided further that where a"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "india10aa-web",
      "visual_proof": null
    },
    {
      "act_article": "Income-tax Act 2025 section 144",
      "block": "india-act2025:section144",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/india-act2025.txt",
      "capture_sha256": "3cccc8c72b0a0918b3b9e9fba33e99e53d022745675309efaba40a41294459ef",
      "limitations": [
        "Actual IndianGazette enacted Act, selected operative provisions and immediate neighbors, not entire Act. 2026amendment supersedes original147periods; no IFSCA licence or complete filing eligibility clearance."
      ],
      "native_fragment_ids": [
        "N00604",
        "N00605",
        "N00606",
        "N00607",
        "N00608",
        "N00609",
        "N00610",
        "N00611",
        "N00612"
      ],
      "official_url": "https://egazette.gov.in/WriteReadData/2025/265620.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00611",
      "read_scope": "Actual extracted lines 9599–9623, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [
        "under this Act shall be allowed only for such tax years, 43 of 1961. as would have been allowed under section 10AA of the Income-tax"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "india-act2025",
      "visual_proof": null
    },
    {
      "act_article": "Income-tax Act 2025 section 1 commencement",
      "block": "india-act2025:commencement",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/india-act2025.txt",
      "capture_sha256": "3cccc8c72b0a0918b3b9e9fba33e99e53d022745675309efaba40a41294459ef",
      "limitations": [
        "Actual IndianGazette enacted Act, selected operative provisions and immediate neighbors, not entire Act. 2026amendment supersedes original147periods; no IFSCA licence or complete filing eligibility clearance."
      ],
      "native_fragment_ids": [
        "N00599",
        "N00600",
        "N00601",
        "N00602",
        "N00603"
      ],
      "official_url": "https://egazette.gov.in/WriteReadData/2025/265620.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00599",
      "read_scope": "Actual extracted lines 65–82, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "india-act2025",
      "visual_proof": null
    }
  ],
  "old_lines": [
    140
  ],
  "section": "India SEZs and GIFT City",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0079

| GST and DTA | SEZ Act section **30** charges goods removed into the DTA to customs duties, including applicable anti-dumping/countervailing/safeguard duties, as leviable on import, subject to the rules and relevant removal/payment date. This is not a new import charge on every goods arrival into an SEZ. [india-sez-web](<https://sezindia.gov.in/sites/default/files/SEZAct2005.pdf>) |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    139,
    139
  ],
  "id": "R0079",
  "individual_subclaims": [
    {
      "bindings": [
        "india-sez-web:section30"
      ],
      "claim": "GST and DTA",
      "id": "R0079.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "india-sez-web:section30"
      ],
      "claim": "SEZ Act section **30** charges goods removed into the DTA to customs duties, including applicable anti-dumping/countervailing/safeguard duties, as leviable on import, subject to the rules and relevant removal/payment date. This is not a new import charge on every goods arrival into an SEZ. [india-sez-web](<https://sezindia.gov.in/sites/default/files/SEZAct2005.pdf>)",
      "id": "R0079.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "SEZ Act 2005 section 30",
      "block": "india-sez-web:section30",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/india-sez-web-web-selected.txt",
      "capture_sha256": "5b97f27fa26ec7de606e732667f74fcce1fa63c6bb7ff4cbd932cd67846bae95",
      "limitations": [
        "Actual enacted2005Actsection30andneighbors. Cross-referenced current customs rules/notifications not cleared; not a complete current consolidation of the SEZ/GSTpackage.",
        "Only tool Lnn locators and citation wrappers removed, retaining visible anchor text; raw response immutable."
      ],
      "native_fragment_ids": [
        "N00696",
        "N00697",
        "N00698",
        "N00699",
        "N00700"
      ],
      "official_url": "https://sezindia.gov.in/sites/default/files/SEZAct2005.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00697",
      "read_scope": "Actual extracted lines 1–15, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "india-sez-web",
      "visual_proof": null
    }
  ],
  "old_lines": [
    141
  ],
  "section": "India SEZs and GIFT City",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0080

| GIFT City / IFSC | Finance Act **2026 section 47**, amending Income-tax Act 2025 section **147**, now provides a **100% deduction of the specified income** of an eligible IFSC unit for **20 consecutive tax years out of 25**, rather than 10 out of 15, subject to the actual specified income and permission/certification conditions. The offshore-banking-unit provisions have their own 20-year/transitional terms. Units commencing from **1 April 2026** also face the specified anti-splitting/reconstruction/reorganisation/transfer condition. Section **218**, as substituted, taxes the section 147(3) business income at **15%** when applicable; other income has its own rates. See the individual source request under Sources. [india-fa2026](<https://egazette.gov.in/WriteReadData/2026/271439.pdf>); [india-act2025](<https://egazette.gov.in/WriteReadData/2025/265620.pdf>) |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    140,
    140
  ],
  "id": "R0080",
  "individual_subclaims": [
    {
      "bindings": [
        "india-fa2026:IFSC",
        "india-fa2026:rate",
        "india-act2025:section147"
      ],
      "claim": "GIFT City / IFSC",
      "id": "R0080.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "india-fa2026:IFSC",
        "india-fa2026:rate",
        "india-act2025:section147"
      ],
      "claim": "Finance Act **2026 section 47**, amending Income-tax Act 2025 section **147**, now provides a **100% deduction of the specified income** of an eligible IFSC unit for **20 consecutive tax years out of 25**, rather than 10 out of 15, subject to the actual specified income and permission/certification conditions. The offshore-banking-unit provisions have their own 20-year/transitional terms. Units commencing from **1 April 2026** also face the specified anti-splitting/reconstruction/reorganisation/transfer condition. Section **218**, as substituted, taxes the section 147(3) business income at **15%** when applicable; other income has its own rates. See the individual source request under Sources. [india-fa2026](<https://egazette.gov.in/WriteReadData/2026/271439.pdf>); [india-act2025](<https://egazette.gov.in/WriteReadData/2025/265620.pdf>)",
      "id": "R0080.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "Finance Act 2026 section 47",
      "block": "india-fa2026:IFSC",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/india-fa2026.txt",
      "capture_sha256": "93ff0ed2a206f71ee56ef09b454bf7473328d9d1946bb75ab0a9f69fb9864177",
      "limitations": [
        "Actual IndianGazette enacted Act, selected operative provisions and immediate neighbors, not entire Act. 2026amendment supersedes original147periods; no IFSCA licence or complete filing eligibility clearance."
      ],
      "native_fragment_ids": [
        "N00641",
        "N00642",
        "N00643",
        "N00644",
        "N00645",
        "N00646",
        "N00647",
        "N00648",
        "N00649",
        "N00650",
        "N00651",
        "N00652",
        "N00653",
        "N00654",
        "N00655",
        "N00656",
        "N00657",
        "N00658",
        "N00659",
        "N00660",
        "N00661",
        "N00662",
        "N00663",
        "N00664",
        "N00665",
        "N00666",
        "N00667",
        "N00668",
        "N00669",
        "N00670",
        "N00671",
        "N00672",
        "N00673"
      ],
      "official_url": "https://egazette.gov.in/WriteReadData/2026/271439.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00656",
      "read_scope": "Actual extracted lines 2405–2505, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "india-fa2026",
      "visual_proof": null
    },
    {
      "act_article": "Finance Act 2026 section 60, substituting section 218",
      "block": "india-fa2026:rate",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/india-fa2026.txt",
      "capture_sha256": "93ff0ed2a206f71ee56ef09b454bf7473328d9d1946bb75ab0a9f69fb9864177",
      "limitations": [
        "Actual IndianGazette enacted Act, selected operative provisions and immediate neighbors, not entire Act. 2026amendment supersedes original147periods; no IFSCA licence or complete filing eligibility clearance."
      ],
      "native_fragment_ids": [
        "N00674",
        "N00675",
        "N00676",
        "N00677",
        "N00678",
        "N00679",
        "N00680",
        "N00681",
        "N00682",
        "N00683",
        "N00684",
        "N00685",
        "N00686",
        "N00687",
        "N00688",
        "N00689",
        "N00690",
        "N00691",
        "N00692",
        "N00693",
        "N00694",
        "N00695"
      ],
      "official_url": "https://egazette.gov.in/WriteReadData/2026/271439.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00690",
      "read_scope": "Actual extracted lines 2683–2742, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "india-fa2026",
      "visual_proof": null
    },
    {
      "act_article": "Income-tax Act 2025 section 147 before Finance Act 2026 amendment; read together",
      "block": "india-act2025:section147",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/india-act2025.txt",
      "capture_sha256": "3cccc8c72b0a0918b3b9e9fba33e99e53d022745675309efaba40a41294459ef",
      "limitations": [
        "Actual IndianGazette enacted Act, selected operative provisions and immediate neighbors, not entire Act. 2026amendment supersedes original147periods; no IFSCA licence or complete filing eligibility clearance."
      ],
      "native_fragment_ids": [
        "N00613",
        "N00614",
        "N00615",
        "N00616",
        "N00617",
        "N00618",
        "N00619",
        "N00620",
        "N00621",
        "N00622",
        "N00623",
        "N00624",
        "N00625",
        "N00626",
        "N00627",
        "N00628",
        "N00629",
        "N00630",
        "N00631",
        "N00632",
        "N00633",
        "N00634",
        "N00635",
        "N00636",
        "N00637",
        "N00638",
        "N00639",
        "N00640"
      ],
      "official_url": "https://egazette.gov.in/WriteReadData/2025/265620.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00619",
      "read_scope": "Actual extracted lines 9703–9780, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "india-act2025",
      "visual_proof": null
    }
  ],
  "old_lines": [
    142
  ],
  "section": "India SEZs and GIFT City",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0081

## Latin America and the Caribbean

```json
{
  "context_only_blocks": [],
  "current_lines": [
    142,
    142
  ],
  "id": "R0081",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "## Latin America and the Caribbean",
      "id": "R0081.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    144,
    146
  ],
  "section": "Latin America and the Caribbean",
  "source_read_record": null,
  "status": "heading"
}
```

### R0082

| Regime | Supported position and individual limits |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    144,
    144
  ],
  "id": "R0082",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Regime",
      "id": "R0082.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Supported position and individual limits",
      "id": "R0082.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    148
  ],
  "section": "Latin America and the Caribbean",
  "source_read_record": null,
  "status": "workflow/research question or table label; no current rule asserted"
}
```

### R0083

| --- | --- |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    145,
    145
  ],
  "id": "R0083",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "---",
      "id": "R0083.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "---",
      "id": "R0083.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    149
  ],
  "section": "Latin America and the Caribbean",
  "source_read_record": null,
  "status": "table separator"
}
```

### R0084

| Panama Colón Free Trade Zone | The actual consolidated Law 8/2016 Articles **46,49–50** distinguish authorised activity, foreign-source exempt income and taxable dealings with the national fiscal territory. The specified multimodal/logistics and digital-data services face CIGA/staff/expenditure/reporting substance conditions; failing them brings ordinary tax and sanctions. Article **52** includes export/re-export tax exemption, not an unconditional exemption from every tax. See the individual source request under Sources. [panama-zlc-law](<https://zolicol.gob.pa/wp-content/uploads/2025/06/LEY-8-DE-2016-que-reorganiza-la-ZLC-6.pdf>) |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    146,
    146
  ],
  "id": "R0084",
  "individual_subclaims": [
    {
      "bindings": [
        "panama-zlc-law:activities",
        "panama-zlc-law:fiscal"
      ],
      "claim": "Panama Colón Free Trade Zone",
      "id": "R0084.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "panama-zlc-law:activities",
        "panama-zlc-law:fiscal"
      ],
      "claim": "The actual consolidated Law 8/2016 Articles **46,49–50** distinguish authorised activity, foreign-source exempt income and taxable dealings with the national fiscal territory. The specified multimodal/logistics and digital-data services face CIGA/staff/expenditure/reporting substance conditions; failing them brings ordinary tax and sanctions. Article **52** includes export/re-export tax exemption, not an unconditional exemption from every tax. See the individual source request under Sources. [panama-zlc-law](<https://zolicol.gob.pa/wp-content/uploads/2025/06/LEY-8-DE-2016-que-reorganiza-la-ZLC-6.pdf>)",
      "id": "R0084.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "Law 8/2016 consolidated Articles 46–47 and neighbors",
      "block": "panama-zlc-law:activities",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/panama-zlc-law.txt",
      "capture_sha256": "eb7caab2bb9e9358c56f772f6540d0c93e5f3512d6a21bded1e3c9dbae3c5c94",
      "limitations": [
        "ActualGazette2024TextoÚnicoofLaw8/2016withLaw412/2023; Articles44–52selectedread, notallimplementingregulations orcurrentcustomsclassification."
      ],
      "native_fragment_ids": [
        "N00877",
        "N00878",
        "N00879",
        "N00880",
        "N00881",
        "N00882",
        "N00883",
        "N00884",
        "N00885",
        "N00886",
        "N00887",
        "N00888",
        "N00889",
        "N00890",
        "N00891",
        "N00892",
        "N00893",
        "N00894",
        "N00895",
        "N00896",
        "N00897",
        "N00898",
        "N00899",
        "N00900",
        "N00901",
        "N00902",
        "N00903",
        "N00904",
        "N00905",
        "N00906",
        "N00907",
        "N00908",
        "N00909",
        "N00910",
        "N00911",
        "N00912",
        "N00913"
      ],
      "official_url": "https://zolicol.gob.pa/wp-content/uploads/2025/06/LEY-8-DE-2016-que-reorganiza-la-ZLC-6.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00877",
      "read_scope": "Actual extracted lines 965–1071, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [
        "Artículo 46. A los usuarios de la Zona Libre de Colón, además de lo establecido en el artículo 44, se les permitirá realizar las siguientes"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "panama-zlc-law",
      "visual_proof": null
    },
    {
      "act_article": "Law 8/2016 consolidated Articles 48–52",
      "block": "panama-zlc-law:fiscal",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/panama-zlc-law.txt",
      "capture_sha256": "eb7caab2bb9e9358c56f772f6540d0c93e5f3512d6a21bded1e3c9dbae3c5c94",
      "limitations": [
        "ActualGazette2024TextoÚnicoofLaw8/2016withLaw412/2023; Articles44–52selectedread, notallimplementingregulations orcurrentcustomsclassification."
      ],
      "native_fragment_ids": [
        "N00914",
        "N00915",
        "N00916",
        "N00917",
        "N00918",
        "N00919",
        "N00920",
        "N00921",
        "N00922",
        "N00923",
        "N00924",
        "N00925",
        "N00926",
        "N00927",
        "N00928",
        "N00929",
        "N00930",
        "N00931",
        "N00932",
        "N00933",
        "N00934",
        "N00935",
        "N00936",
        "N00937",
        "N00938",
        "N00939",
        "N00940",
        "N00941",
        "N00942",
        "N00943",
        "N00944",
        "N00945",
        "N00946",
        "N00947",
        "N00948",
        "N00949",
        "N00950",
        "N00951",
        "N00952",
        "N00953",
        "N00954",
        "N00955",
        "N00956",
        "N00957",
        "N00958",
        "N00959",
        "N00960",
        "N00961",
        "N00962",
        "N00963",
        "N00964",
        "N00965",
        "N00966",
        "N00967",
        "N00968",
        "N00969"
      ],
      "official_url": "https://zolicol.gob.pa/wp-content/uploads/2025/06/LEY-8-DE-2016-que-reorganiza-la-ZLC-6.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00926",
      "read_scope": "Actual extracted lines 1074–1226, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "panama-zlc-law",
      "visual_proof": null
    }
  ],
  "old_lines": [
    150
  ],
  "section": "Latin America and the Caribbean",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0085

| Panama City of Knowledge / Ciudad del Saber | See the individual source request under Sources. [panama-zlc-law](<https://zolicol.gob.pa/wp-content/uploads/2025/06/LEY-8-DE-2016-que-reorganiza-la-ZLC-6.pdf>) |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    147,
    147
  ],
  "id": "R0085",
  "individual_subclaims": [
    {
      "bindings": [
        "panama-zlc-law:activities"
      ],
      "claim": "Panama City of Knowledge / Ciudad del Saber",
      "id": "R0085.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "panama-zlc-law:activities"
      ],
      "claim": "See the individual source request under Sources. [panama-zlc-law](<https://zolicol.gob.pa/wp-content/uploads/2025/06/LEY-8-DE-2016-que-reorganiza-la-ZLC-6.pdf>)",
      "id": "R0085.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "Law 8/2016 consolidated Articles 46–47 and neighbors",
      "block": "panama-zlc-law:activities",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/panama-zlc-law.txt",
      "capture_sha256": "eb7caab2bb9e9358c56f772f6540d0c93e5f3512d6a21bded1e3c9dbae3c5c94",
      "limitations": [
        "ActualGazette2024TextoÚnicoofLaw8/2016withLaw412/2023; Articles44–52selectedread, notallimplementingregulations orcurrentcustomsclassification."
      ],
      "native_fragment_ids": [
        "N00877",
        "N00878",
        "N00879",
        "N00880",
        "N00881",
        "N00882",
        "N00883",
        "N00884",
        "N00885",
        "N00886",
        "N00887",
        "N00888",
        "N00889",
        "N00890",
        "N00891",
        "N00892",
        "N00893",
        "N00894",
        "N00895",
        "N00896",
        "N00897",
        "N00898",
        "N00899",
        "N00900",
        "N00901",
        "N00902",
        "N00903",
        "N00904",
        "N00905",
        "N00906",
        "N00907",
        "N00908",
        "N00909",
        "N00910",
        "N00911",
        "N00912",
        "N00913"
      ],
      "official_url": "https://zolicol.gob.pa/wp-content/uploads/2025/06/LEY-8-DE-2016-que-reorganiza-la-ZLC-6.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00910",
      "read_scope": "Actual extracted lines 965–1071, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "panama-zlc-law",
      "visual_proof": null
    }
  ],
  "old_lines": [
    151
  ],
  "section": "Latin America and the Caribbean",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0086

| Costa Rica Zonas Francas | The actually read Law **8794/2010** replacement of Law 7210 Article 20(g) distinguishes **100% exemption for 8 years within GAMA / 12 outside**, then **50% exemption for 4 / 6 years** in the specified categories, with the operational-start condition. “50%” here is an exemption fraction, not a 50% CIT rate. See the individual source request under Sources. [cr-law8794](<https://www.pgrweb.go.cr/DOCS/NORMAS/1/VIGENTE/L/2010-2019/2010-2014/2010/1061B/CCB5F.HTML>) |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    148,
    148
  ],
  "id": "R0086",
  "individual_subclaims": [
    {
      "bindings": [
        "cr-law8794:Article20g"
      ],
      "claim": "Costa Rica Zonas Francas",
      "id": "R0086.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "cr-law8794:Article20g"
      ],
      "claim": "The actually read Law **8794/2010** replacement of Law 7210 Article 20(g) distinguishes **100% exemption for 8 years within GAMA / 12 outside**, then **50% exemption for 4 / 6 years** in the specified categories, with the operational-start condition. “50%” here is an exemption fraction, not a 50% CIT rate. See the individual source request under Sources. [cr-law8794](<https://www.pgrweb.go.cr/DOCS/NORMAS/1/VIGENTE/L/2010-2019/2010-2014/2010/1061B/CCB5F.HTML>)",
      "id": "R0086.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "Law 8794/2010 replacement of Law 7210 Article 20(g)",
      "block": "cr-law8794:Article20g",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/cr-law8794-reading-order-cp1252.txt",
      "capture_sha256": "009ae98aff695ceaf2c0d37a16b3cc2d572e66a20f130e80927ea8834f75bd83",
      "limitations": [
        "Historical2010amendingLaw8794operative wording, not complete current consolidated7210orindividualcategoryclearance.",
        "Immutable raw bytes decoded Windows1252 to preserve original accented/eurocharacters; initial UTF8replacement and Latin1trial retained separately. No wording translation."
      ],
      "native_fragment_ids": [
        "N00970",
        "N00971",
        "N00972",
        "N00973",
        "N00974",
        "N00975",
        "N00976",
        "N00977",
        "N00978",
        "N00979",
        "N00980",
        "N00981",
        "N00982",
        "N00983",
        "N00984",
        "N00985",
        "N00986",
        "N00987",
        "N00988"
      ],
      "official_url": "https://www.pgrweb.go.cr/DOCS/NORMAS/1/VIGENTE/L/2010-2019/2010-2014/2010/1061B/CCB5F.HTML",
      "own_read_date": "2026-11-16",
      "quote_id": "N00980",
      "read_scope": "Actual extracted lines 13–66, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [
        "conformidad con las siguientes diferenciaciones: 1) Para las empresas ubicadas en la Gran Área Metropolitana Ampliada (GAMA), la exención será de un cien por ciento"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "cr-law8794",
      "visual_proof": null
    }
  ],
  "old_lines": [
    152
  ],
  "section": "Latin America and the Caribbean",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0087

| Dominican Republic Zonas Francas | The actual CNZFE FAQ describes Law **8-90 Article 24** exemptions for covered operators/companies, including **100%** income-tax and specified import/customs exemptions with stated export exceptions. See the individual source request under Sources. [dominican-web](<https://cnzfe.gob.do/faqs/>) |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    149,
    149
  ],
  "id": "R0087",
  "individual_subclaims": [
    {
      "bindings": [
        "dominican-web:FAQ1-2"
      ],
      "claim": "Dominican Republic Zonas Francas",
      "id": "R0087.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "dominican-web:FAQ1-2"
      ],
      "claim": "The actual CNZFE FAQ describes Law **8-90 Article 24** exemptions for covered operators/companies, including **100%** income-tax and specified import/customs exemptions with stated export exceptions. See the individual source request under Sources. [dominican-web](<https://cnzfe.gob.do/faqs/>)",
      "id": "R0087.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "CNZFE FAQ 1–2, Law 8-90 Article 24 overview",
      "block": "dominican-web:FAQ1-2",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/dominican-web-web-selected.txt",
      "capture_sha256": "b1e8c1c8fdba7486b0fa461612573b9bedef1c248e162008991d63e196acabbf",
      "limitations": [
        "ActualCNZFEFAQ1–2guidanceandalllistitemsread; Law8-90actualPDFrecoveryfailed. Nofullstatutoryduration/WHTclearance.",
        "Only tool Lnn locators and citation wrappers removed, retaining visible anchor text; raw response immutable."
      ],
      "native_fragment_ids": [
        "N01226",
        "N01227",
        "N01228",
        "N01229",
        "N01230",
        "N01231",
        "N01232",
        "N01233",
        "N01234",
        "N01235",
        "N01236",
        "N01237",
        "N01238",
        "N01239",
        "N01240",
        "N01241",
        "N01242"
      ],
      "official_url": "https://cnzfe.gob.do/faqs/",
      "own_read_date": "2026-11-16",
      "quote_id": "N01228",
      "read_scope": "Actual extracted lines 1–16, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [
        "¿Cuáles son los incentivos de invertir en Zonas Francas? Los incentivos están establecidos en el artículo 24, de la Ley 8-90. Las operadoras de zonas"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "dominican-web",
      "visual_proof": null
    }
  ],
  "old_lines": [
    153
  ],
  "section": "Latin America and the Caribbean",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0088

| Honduras ZEDE | See the individual source request under Sources. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    150,
    150
  ],
  "id": "R0088",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Honduras ZEDE",
      "id": "R0088.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "See the individual source request under Sources.",
      "id": "R0088.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    154
  ],
  "section": "Latin America and the Caribbean",
  "source_read_record": null,
  "status": "workflow/research question or table label; no current rule asserted"
}
```

### R0089

| Uruguay Zonas Francas | MEF’s **2020** benefits page describes qualifying-user national-tax/IRAE exemptions with social-security and specified foreign-dividend exceptions. This is not proof that all current taxes remain zero. The actual **Decree 254/026**, published **13 November 2026**, implements IMCD and its Article 1 includes Uruguay entities in qualifying MNE groups with **EUR 750 million in at least 2 of the prior 4 fiscal years**, excluding excluded entities, plus JV rules. See the individual source request under Sources. [uruguay-benefits](<https://www.gub.uy/ministerio-economia-finanzas/politicas-y-gestion/beneficios-tributarios-para-zonas-francas>); [uruguay-imcd2026](<https://www.impo.com.uy/bases/decretos/254-2026>) |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    151,
    151
  ],
  "id": "R0089",
  "individual_subclaims": [
    {
      "bindings": [
        "uruguay-benefits:body",
        "uruguay-imcd2026:scope"
      ],
      "claim": "Uruguay Zonas Francas",
      "id": "R0089.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uruguay-benefits:body",
        "uruguay-imcd2026:scope"
      ],
      "claim": "MEF’s **2020** benefits page describes qualifying-user national-tax/IRAE exemptions with social-security and specified foreign-dividend exceptions. This is not proof that all current taxes remain zero. The actual **Decree 254/026**, published **13 November 2026**, implements IMCD and its Article 1 includes Uruguay entities in qualifying MNE groups with **EUR 750 million in at least 2 of the prior 4 fiscal years**, excluding excluded entities, plus JV rules. See the individual source request under Sources. [uruguay-benefits](<https://www.gub.uy/ministerio-economia-finanzas/politicas-y-gestion/beneficios-tributarios-para-zonas-francas>); [uruguay-imcd2026](<https://www.impo.com.uy/bases/decretos/254-2026>)",
      "id": "R0089.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "MEF 2020 benefits overview with dividend/social-security exceptions",
      "block": "uruguay-benefits:body",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/uruguay-benefits.txt",
      "capture_sha256": "2171cbdb3f9184b03cabc95f55320581029c5ea61f697e4a8e915335c38da600",
      "limitations": [
        "MEF2020benefits overview, not complete2026law; currentIMCDseparately read."
      ],
      "native_fragment_ids": [
        "N00989",
        "N00990",
        "N00991",
        "N00992",
        "N00993",
        "N00994",
        "N00995",
        "N00996",
        "N00997",
        "N00998",
        "N00999",
        "N01000",
        "N01001",
        "N01002",
        "N01003",
        "N01004",
        "N01005"
      ],
      "official_url": "https://www.gub.uy/ministerio-economia-finanzas/politicas-y-gestion/beneficios-tributarios-para-zonas-francas",
      "own_read_date": "2026-11-16",
      "quote_id": "N01001",
      "read_scope": "Actual extracted lines 10–27, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [
        "ingreso y egreso de divisas, títulos valores y metales preciosos. No regirán para las actividades a desarrollarse en zonas francas los requisitos establecidos o que"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "uruguay-benefits",
      "visual_proof": null
    },
    {
      "act_article": "Decree 254/026 preamble and Articles 1–3",
      "block": "uruguay-imcd2026:scope",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/uruguay-imcd2026-reading-order-cp1252.txt",
      "capture_sha256": "d53c89b3b5411811611fc181363686849f7cfe300db7989a2225ca3f1e08df22",
      "limitations": [
        "ActualIMPODecree254/026published13Nov2026, onlypreamble/Articles1–3read; underlyingTitle21/completecommencement/calculationnotcleared.",
        "Immutable raw bytes decoded Windows1252 to preserve original accented/eurocharacters; initial UTF8replacement and Latin1trial retained separately. No wording translation."
      ],
      "native_fragment_ids": [
        "N01006",
        "N01007",
        "N01008",
        "N01009",
        "N01010",
        "N01011",
        "N01012",
        "N01013",
        "N01014",
        "N01015",
        "N01016",
        "N01017",
        "N01018",
        "N01019",
        "N01020",
        "N01021",
        "N01022",
        "N01023",
        "N01024",
        "N01025",
        "N01026",
        "N01027",
        "N01028",
        "N01029"
      ],
      "official_url": "https://www.impo.com.uy/bases/decretos/254-2026",
      "own_read_date": "2026-11-16",
      "quote_id": "N01012",
      "read_scope": "Actual extracted lines 19–55, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [
        "Constitución de la República, y a lo informado por la Asesoría Tributaria y la Asesoría de la Dirección General del Ministerio de Economía y Finanzas;"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "uruguay-imcd2026",
      "visual_proof": null
    }
  ],
  "old_lines": [
    155
  ],
  "section": "Latin America and the Caribbean",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0090

| Cayman Islands | See the individual source request under Sources. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    152,
    152
  ],
  "id": "R0090",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Cayman Islands",
      "id": "R0090.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "See the individual source request under Sources.",
      "id": "R0090.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    156,
    222
  ],
  "section": "Latin America and the Caribbean",
  "source_read_record": null,
  "status": "workflow/research question or table label; no current rule asserted"
}
```

### R0091

| BVI | See the individual source request under Sources. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    153,
    153
  ],
  "id": "R0091",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "BVI",
      "id": "R0091.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "See the individual source request under Sources.",
      "id": "R0091.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    157
  ],
  "section": "Latin America and the Caribbean",
  "source_read_record": null,
  "status": "workflow/research question or table label; no current rule asserted"
}
```

### R0092

| Bahamas | Act **58/2024** creates a domestic minimum top-up tax by incorporating the GloBE rules for in-scope groups; the headline **15%** is not a general company CIT rate. Section **1(2)** deems commencement **1 January 2024** for fiscal years after **31 December 2023**, but excludes group fiscal years beginning before **1 January 2025** unless an IIR or UTPR is required for that year for **each** Bahamas constituent entity. The actual **2026-0025A** amendment operates from **1 July 2026** and changes administration; it does not remove that initial-year condition. See the individual source request under Sources. [bahamas-law2024](<https://laws.bahamas.gov.bs/cms/images/LEGISLATION/PRINCIPAL/2024/2024-0058/2024-0058_1.pdf>); [bahamas-amend2026](<https://laws.bahamas.gov.bs/cms/images/LEGISLATION/AMENDING/2026/2026-0025A/2026-0025A.pdf>); [oecd-global](<https://www.oecd.org/en/topics/global-minimum-tax.html>) |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    154,
    154
  ],
  "id": "R0092",
  "individual_subclaims": [
    {
      "bindings": [
        "bahamas-law2024:sections1-5",
        "bahamas-amend2026:whole",
        "oecd-global:overview"
      ],
      "claim": "Bahamas",
      "id": "R0092.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "bahamas-law2024:sections1-5",
        "bahamas-amend2026:whole",
        "oecd-global:overview"
      ],
      "claim": "Act **58/2024** creates a domestic minimum top-up tax by incorporating the GloBE rules for in-scope groups; the headline **15%** is not a general company CIT rate. Section **1(2)** deems commencement **1 January 2024** for fiscal years after **31 December 2023**, but excludes group fiscal years beginning before **1 January 2025** unless an IIR or UTPR is required for that year for **each** Bahamas constituent entity. The actual **2026-0025A** amendment operates from **1 July 2026** and changes administration; it does not remove that initial-year condition. See the individual source request under Sources. [bahamas-law2024](<https://laws.bahamas.gov.bs/cms/images/LEGISLATION/PRINCIPAL/2024/2024-0058/2024-0058_1.pdf>); [bahamas-amend2026](<https://laws.bahamas.gov.bs/cms/images/LEGISLATION/AMENDING/2026/2026-0025A/2026-0025A.pdf>); [oecd-global](<https://www.oecd.org/en/topics/global-minimum-tax.html>)",
      "id": "R0092.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "Act 58/2024 sections 1(2),3(1),4(1)/(5),5(1)/(2), visual passages",
      "block": "bahamas-law2024:sections1-5",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/bahamas-base-visual-native.txt",
      "capture_sha256": "900a9fa24b32fdaadd4c167978ac59d6155aaaf9ed582ae7247a85ddde0ad55e",
      "limitations": [
        "ActualofficialGazettePDF; text layer duplicates/interleaves. Physicalpages4–8(printed3–7)personallyvisuallyread; below selectednative transcription checked against images."
      ],
      "native_fragment_ids": [
        "N01162",
        "N01163",
        "N01164",
        "N01165",
        "N01166",
        "N01167",
        "N01168",
        "N01169",
        "N01170",
        "N01171",
        "N01172",
        "N01173",
        "N01174"
      ],
      "official_url": "https://laws.bahamas.gov.bs/cms/images/LEGISLATION/PRINCIPAL/2024/2024-0058/2024-0058_1.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N01163",
      "read_scope": "Selectedcomplete1(2),3(1),4(1)/(5),5(1)/(2)nativepassagespersonallytranscribed/checkedagainstactualPDFphysical4–8;entireprinted3–7readvisuallywithallneighboringexceptions.",
      "short_exact_native_quote": [
        "begin after December 31, 2023, except that it does not apply in respect of a Fiscal Year of the Group that begins before January 1,"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "bahamas-law2024",
      "visual_proof": null
    },
    {
      "act_article": "Act 2026-0025A sections 1–7",
      "block": "bahamas-amend2026:whole",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/bahamas-amend2026.txt",
      "capture_sha256": "80186796590f7c6f54a31666fe32465b63f788f704a66b16715d6a7309862be2",
      "limitations": [
        "Actualofficial2026-0025APDFwholeoperative1–7read; text duplicate/interleaving retainedraw, not complete underlyingGloBEcalculations."
      ],
      "native_fragment_ids": [
        "N01175",
        "N01176",
        "N01177",
        "N01178",
        "N01179",
        "N01180",
        "N01181",
        "N01182",
        "N01183",
        "N01184",
        "N01185",
        "N01186",
        "N01187",
        "N01188",
        "N01189",
        "N01190",
        "N01191",
        "N01192",
        "N01193",
        "N01194",
        "N01195",
        "N01196",
        "N01197",
        "N01198",
        "N01199",
        "N01200",
        "N01201",
        "N01202",
        "N01203",
        "N01204",
        "N01205",
        "N01206",
        "N01207",
        "N01208",
        "N01209",
        "N01210",
        "N01211",
        "N01212",
        "N01213",
        "N01214",
        "N01215",
        "N01216",
        "N01217",
        "N01218",
        "N01219",
        "N01220",
        "N01221",
        "N01222",
        "N01223",
        "N01224",
        "N01225"
      ],
      "official_url": "https://laws.bahamas.gov.bs/cms/images/LEGISLATION/AMENDING/2026/2026-0025A/2026-0025A.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N01175",
      "read_scope": "Actual extracted lines 1–159, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [
        "EXTRAORDINARY OFFICIAL GAZETTE THE BAHAMAS PUBLISHED BY AUTHORITY NASSAU 1st July, 2026 DOMESTIC MINIMUM TOP-UP TAX (AMENDMENT) ACT, 2026 Arrangement of Sections Section 1. Short"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "bahamas-amend2026",
      "visual_proof": null
    },
    {
      "act_article": "OECD global-minimum-tax selected overview",
      "block": "oecd-global:overview",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/oecd-global-native-excerpts.txt",
      "capture_sha256": "fcc245ec5302be8c7e27f4af5d45aa913ec7cb93796b1a18e2f6c06c775aadd0",
      "limitations": [
        "Selectedactualoverviewparagraphsread; legislative template, notdomesticlaw. Fullmodel/administrativeguidancenotread. Shortsource-nativeextractsinledger, notfullsitequotation.",
        "Only tool Lnn locators and citation wrappers removed, retaining visible anchor text; raw response immutable."
      ],
      "native_fragment_ids": [
        "N02245",
        "N02246",
        "N02247",
        "N02248"
      ],
      "official_url": "https://www.oecd.org/en/topics/global-minimum-tax.html",
      "own_read_date": "2026-11-16",
      "quote_id": "N02246",
      "read_scope": "Actual official web lines 3749–3771, personally read with immediate qualifications.",
      "short_exact_native_quote": [
        "15% minimum rate"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "oecd-global",
      "visual_proof": null
    }
  ],
  "old_lines": [
    158,
    221
  ],
  "section": "Latin America and the Caribbean",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0093

| Bermuda | The actual Corporate Income Tax Act 2023 sections **4–5,9–11,53** impose **15%** on the defined net taxable income less applicable credits for in-scope Bermuda constituent entities, with group revenue/excluded-entity and other conditions, for the specified **2025** fiscal periods. It is not a 15% charge on every Bermuda company. See the individual source request under Sources. [bermuda-cit](<https://www.bermudalaws.bm/Laws/Annual%20Law/Acts/2023/Corporate%20Income%20Tax%20Act%202023>) |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    155,
    155
  ],
  "id": "R0093",
  "individual_subclaims": [
    {
      "bindings": [
        "bermuda-cit:rate",
        "bermuda-cit:scope",
        "bermuda-cit:commencement"
      ],
      "claim": "Bermuda",
      "id": "R0093.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "bermuda-cit:rate",
        "bermuda-cit:scope",
        "bermuda-cit:commencement"
      ],
      "claim": "The actual Corporate Income Tax Act 2023 sections **4–5,9–11,53** impose **15%** on the defined net taxable income less applicable credits for in-scope Bermuda constituent entities, with group revenue/excluded-entity and other conditions, for the specified **2025** fiscal periods. It is not a 15% charge on every Bermuda company. See the individual source request under Sources. [bermuda-cit](<https://www.bermudalaws.bm/Laws/Annual%20Law/Acts/2023/Corporate%20Income%20Tax%20Act%202023>)",
      "id": "R0093.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "Corporate Income Tax Act 2023 sections 4–5",
      "block": "bermuda-cit:rate",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/bermuda-cit.txt",
      "capture_sha256": "a738262d39f906de87b9f5ecfacab7656094bb3cabbb17eda7ae6e63c1be8168",
      "limitations": [
        "ActualActconsolidation through2025:12; later2026amendmentidentified but notread, entity/currentcalculationclearanceexplicitlyreserved."
      ],
      "native_fragment_ids": [
        "N01030",
        "N01031",
        "N01032",
        "N01033",
        "N01034",
        "N01035",
        "N01036",
        "N01037",
        "N01038",
        "N01039",
        "N01040",
        "N01041",
        "N01042",
        "N01043"
      ],
      "official_url": "https://www.bermudalaws.bm/Laws/Annual%20Law/Acts/2023/Corporate%20Income%20Tax%20Act%202023",
      "own_read_date": "2026-11-16",
      "quote_id": "N01037",
      "read_scope": "Actual extracted lines 1000–1048, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [
        "Entity Group; less (b) tax credits applicable to the Bermuda Constituent Entity Group under Part 4 or as prescribed. (3) Each Bermuda Constituent Entity of"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "bermuda-cit",
      "visual_proof": null
    },
    {
      "act_article": "Corporate Income Tax Act 2023 sections 9–11",
      "block": "bermuda-cit:scope",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/bermuda-cit.txt",
      "capture_sha256": "a738262d39f906de87b9f5ecfacab7656094bb3cabbb17eda7ae6e63c1be8168",
      "limitations": [
        "ActualActconsolidation through2025:12; later2026amendmentidentified but notread, entity/currentcalculationclearanceexplicitlyreserved."
      ],
      "native_fragment_ids": [
        "N01044",
        "N01045",
        "N01046",
        "N01047",
        "N01048",
        "N01049",
        "N01050",
        "N01051",
        "N01052",
        "N01053",
        "N01054",
        "N01055",
        "N01056",
        "N01057",
        "N01058",
        "N01059",
        "N01060",
        "N01061",
        "N01062",
        "N01063",
        "N01064",
        "N01065",
        "N01066",
        "N01067",
        "N01068",
        "N01069",
        "N01070",
        "N01071",
        "N01072",
        "N01073",
        "N01074",
        "N01075",
        "N01076",
        "N01077",
        "N01078",
        "N01079",
        "N01080",
        "N01081",
        "N01082",
        "N01083",
        "N01084",
        "N01085",
        "N01086",
        "N01087",
        "N01088",
        "N01089",
        "N01090"
      ],
      "official_url": "https://www.bermudalaws.bm/Laws/Annual%20Law/Acts/2023/Corporate%20Income%20Tax%20Act%202023",
      "own_read_date": "2026-11-16",
      "quote_id": "N01044",
      "read_scope": "Actual extracted lines 1223–1353, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "bermuda-cit",
      "visual_proof": null
    },
    {
      "act_article": "Corporate Income Tax Act 2023 section 53",
      "block": "bermuda-cit:commencement",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/bermuda-cit.txt",
      "capture_sha256": "a738262d39f906de87b9f5ecfacab7656094bb3cabbb17eda7ae6e63c1be8168",
      "limitations": [
        "ActualActconsolidation through2025:12; later2026amendmentidentified but notread, entity/currentcalculationclearanceexplicitlyreserved."
      ],
      "native_fragment_ids": [
        "N01091",
        "N01092",
        "N01093",
        "N01094",
        "N01095",
        "N01096"
      ],
      "official_url": "https://www.bermudalaws.bm/Laws/Annual%20Law/Acts/2023/Corporate%20Income%20Tax%20Act%202023",
      "own_read_date": "2026-11-16",
      "quote_id": "N01094",
      "read_scope": "Actual extracted lines 2955–2985, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "bermuda-cit",
      "visual_proof": null
    }
  ],
  "old_lines": [
    159,
    220
  ],
  "section": "Latin America and the Caribbean",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0094

| Barbados | Act **2024-15** inserts **9%** from income year **2024** with explicit small-business, shipping and MNE-related alternatives; it is not universal. Act **2025-30** inserts an economic-substance regime, deemed from **1 January 2025**, for its defined insurance/international-shipping circumstances, with CIGA, staff, premises, expenditure and direction/management/outsourcing rules. It does not establish a generic IP substance regime. See the individual source request under Sources. [barbados-act2024](<https://bra.gov.bb/attachment?file=Attachments%2FIncome+Tax+%28Amendment+and+Validation%29+Act%2C+2024-15.pdf&name=Income+Tax+%28Amendment+and+Validation%29+Act%2C+2024-15>); [barbados-act2025](<https://bra.gov.bb/attachment?file=Attachments%2fIncome+Tax+(Amendment)+Act%2c+2025-30.pdf&name=Income+Tax+(Amendment)+Act%2c+2025-30>) |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    156,
    156
  ],
  "id": "R0094",
  "individual_subclaims": [
    {
      "bindings": [
        "barbados-act2024:rate",
        "barbados-act2025:substance"
      ],
      "claim": "Barbados",
      "id": "R0094.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "barbados-act2024:rate",
        "barbados-act2025:substance"
      ],
      "claim": "Act **2024-15** inserts **9%** from income year **2024** with explicit small-business, shipping and MNE-related alternatives; it is not universal. Act **2025-30** inserts an economic-substance regime, deemed from **1 January 2025**, for its defined insurance/international-shipping circumstances, with CIGA, staff, premises, expenditure and direction/management/outsourcing rules. It does not establish a generic IP substance regime. See the individual source request under Sources. [barbados-act2024](<https://bra.gov.bb/attachment?file=Attachments%2FIncome+Tax+%28Amendment+and+Validation%29+Act%2C+2024-15.pdf&name=Income+Tax+%28Amendment+and+Validation%29+Act%2C+2024-15>); [barbados-act2025](<https://bra.gov.bb/attachment?file=Attachments%2fIncome+Tax+(Amendment)+Act%2c+2025-30.pdf&name=Income+Tax+(Amendment)+Act%2c+2025-30>)",
      "id": "R0094.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "Act 2024-15 insertion of Income Tax Act section 43(8)–(12)",
      "block": "barbados-act2024:rate",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/barbados-act2024.txt",
      "capture_sha256": "128f662d254afb8c9886320d47bc125c827e1d28b4396e9c78bbe4b61a57d447",
      "limitations": [
        "Actual2024-15enactedamendment; selected43ratewithalladjacentexceptionsread, notalllaterlocalamendments."
      ],
      "native_fragment_ids": [
        "N01097",
        "N01098",
        "N01099",
        "N01100",
        "N01101",
        "N01102",
        "N01103",
        "N01104",
        "N01105",
        "N01106",
        "N01107",
        "N01108",
        "N01109",
        "N01110",
        "N01111",
        "N01112",
        "N01113"
      ],
      "official_url": "https://bra.gov.bb/attachment?file=Attachments%2FIncome+Tax+%28Amendment+and+Validation%29+Act%2C+2024-15.pdf&name=Income+Tax+%28Amendment+and+Validation%29+Act%2C+2024-15",
      "own_read_date": "2026-11-16",
      "quote_id": "N01098",
      "read_scope": "Actual extracted lines 521–564, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [
        "TAX (AMENDMENT AND VALIDATION) ACT, 2024-15 19 “(8) With effect from income year 2024, commencing 1st January, 2024, the tax payable by a company upon"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "barbados-act2024",
      "visual_proof": null
    },
    {
      "act_article": "Act 2025-30 operative economic-substance amendment and commencement",
      "block": "barbados-act2025:substance",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/barbados-act2025.txt",
      "capture_sha256": "a61d0f665fcf3e0e2b3ac7e13bde8188ff23f73115567e42827f136eb1e6a272",
      "limitations": [
        "Actual2025-30enactedActentireoperativewordingread; no genericIPregimeclearance."
      ],
      "native_fragment_ids": [
        "N01114",
        "N01115",
        "N01116",
        "N01117",
        "N01118",
        "N01119",
        "N01120",
        "N01121",
        "N01122",
        "N01123",
        "N01124",
        "N01125",
        "N01126",
        "N01127",
        "N01128",
        "N01129",
        "N01130",
        "N01131",
        "N01132",
        "N01133",
        "N01134",
        "N01135",
        "N01136",
        "N01137",
        "N01138",
        "N01139",
        "N01140",
        "N01141",
        "N01142",
        "N01143",
        "N01144",
        "N01145",
        "N01146",
        "N01147",
        "N01148",
        "N01149",
        "N01150",
        "N01151",
        "N01152",
        "N01153",
        "N01154",
        "N01155",
        "N01156",
        "N01157",
        "N01158",
        "N01159",
        "N01160",
        "N01161"
      ],
      "official_url": "https://bra.gov.bb/attachment?file=Attachments%2fIncome+Tax+(Amendment)+Act%2c+2025-30.pdf&name=Income+Tax+(Amendment)+Act%2c+2025-30",
      "own_read_date": "2026-11-16",
      "quote_id": "N01158",
      "read_scope": "Actual extracted lines 31–206, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [
        "(iii) providing insurance business services to clients; INCOME TAX (AMENDMENT) ACT, 2025-30 9 (b) international shipping business (i) managing crew, including hiring, paying and overseeing"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "barbados-act2025",
      "visual_proof": null
    }
  ],
  "old_lines": [
    160
  ],
  "section": "Latin America and the Caribbean",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0095

## Europe and the Mediterranean

```json
{
  "context_only_blocks": [],
  "current_lines": [
    158,
    158
  ],
  "id": "R0095",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "## Europe and the Mediterranean",
      "id": "R0095.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    162,
    164
  ],
  "section": "Europe and the Mediterranean",
  "source_read_record": null,
  "status": "heading"
}
```

### R0096

| Regime | Supported position and individual limits |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    160,
    160
  ],
  "id": "R0096",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Regime",
      "id": "R0096.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Supported position and individual limits",
      "id": "R0096.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    166
  ],
  "section": "Europe and the Mediterranean",
  "source_read_record": null,
  "status": "workflow/research question or table label; no current rule asserted"
}
```

### R0097

| --- | --- |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    161,
    161
  ],
  "id": "R0097",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "---",
      "id": "R0097.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "---",
      "id": "R0097.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    167
  ],
  "section": "Europe and the Mediterranean",
  "source_read_record": null,
  "status": "table separator"
}
```

### R0098

| Madeira IBC / Madeira Free Zone | Current EBF **36-A** permits qualifying licences issued through **31 December 2026**, with the stated **5%** benefit through **31 December 2033**, not 2027. Start within **6 months** of licensing, or **1 year** for industrial/maritime/air transport activities. Create **1–5 jobs in the first 6 months** and invest at least **EUR 75,000** in fixed tangible/intangible assets in the first **2 years**, or create **6 or more jobs in the first 6 months**. Qualifying income/activity and counterparty conditions, maintained-job taxable-income ceilings, annual aid limits, real local activity and the specified sector/entity exclusions still apply; jobs are counted under paragraphs 5 and 18, not simply contracted headcount. See the individual source request under Sources. [madeira36a](<https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/bf_rep/Pages/ebf-artigo-36-ordm-a.aspx>) |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    162,
    162
  ],
  "id": "R0098",
  "individual_subclaims": [
    {
      "bindings": [
        "madeira36a:whole"
      ],
      "claim": "Madeira IBC / Madeira Free Zone",
      "id": "R0098.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "madeira36a:whole"
      ],
      "claim": "Current EBF **36-A** permits qualifying licences issued through **31 December 2026**, with the stated **5%** benefit through **31 December 2033**, not 2027. Start within **6 months** of licensing, or **1 year** for industrial/maritime/air transport activities. Create **1–5 jobs in the first 6 months** and invest at least **EUR 75,000** in fixed tangible/intangible assets in the first **2 years**, or create **6 or more jobs in the first 6 months**. Qualifying income/activity and counterparty conditions, maintained-job taxable-income ceilings, annual aid limits, real local activity and the specified sector/entity exclusions still apply; jobs are counted under paragraphs 5 and 18, not simply contracted headcount. See the individual source request under Sources. [madeira36a](<https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/bf_rep/Pages/ebf-artigo-36-ordm-a.aspx>)",
      "id": "R0098.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "EBF Article 36-A(1)–(18)",
      "block": "madeira36a:whole",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/madeira36a.txt",
      "capture_sha256": "64ed852478f8d17b22c3167de3cee6ffa0f1eb701a089ee43b0084e85a9d1552",
      "limitations": [
        "ActualATcurrentEBF36Acomplete1–18read; fullEUStateaidapprovalandothercross-referencesnotcleared."
      ],
      "native_fragment_ids": [
        "N01243",
        "N01244",
        "N01245",
        "N01246",
        "N01247",
        "N01248",
        "N01249",
        "N01250",
        "N01251",
        "N01252",
        "N01253",
        "N01254",
        "N01255",
        "N01256",
        "N01257",
        "N01258",
        "N01259",
        "N01260",
        "N01261",
        "N01262",
        "N01263",
        "N01264",
        "N01265",
        "N01266",
        "N01267",
        "N01268",
        "N01269",
        "N01270",
        "N01271",
        "N01272",
        "N01273",
        "N01274",
        "N01275",
        "N01276",
        "N01277",
        "N01278",
        "N01279",
        "N01280",
        "N01281",
        "N01282",
        "N01283",
        "N01284",
        "N01285",
        "N01286",
        "N01287",
        "N01288",
        "N01289",
        "N01290",
        "N01291",
        "N01292",
        "N01293",
        "N01294",
        "N01295",
        "N01296",
        "N01297",
        "N01298",
        "N01299",
        "N01300",
        "N01301",
        "N01302",
        "N01303",
        "N01304",
        "N01305",
        "N01306",
        "N01307",
        "N01308",
        "N01309",
        "N01310",
        "N01311",
        "N01312",
        "N01313",
        "N01314",
        "N01315",
        "N01316",
        "N01317",
        "N01318",
        "N01319",
        "N01320",
        "N01321",
        "N01322",
        "N01323",
        "N01324",
        "N01325",
        "N01326",
        "N01327",
        "N01328",
        "N01329",
        "N01330",
        "N01331",
        "N01332",
        "N01333",
        "N01334",
        "N01335",
        "N01336",
        "N01337",
        "N01338",
        "N01339"
      ],
      "official_url": "https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/bf_rep/Pages/ebf-artigo-36-ordm-a.aspx",
      "own_read_date": "2026-11-16",
      "quote_id": "N01245",
      "read_scope": "Actual extracted lines 1–98, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [
        "Animations SharePoint Sign In Follow segunda-feira, 16 novembro 2026 Informação Fiscal Códigos Tributários Estatuto dos Benefícios Fiscais Page Image Page Content ​​​​​ Artigo 36.º -A"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "madeira36a",
      "visual_proof": null
    }
  ],
  "old_lines": [
    168
  ],
  "section": "Europe and the Mediterranean",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0099

| Azores | See the individual source request under Sources. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    163,
    163
  ],
  "id": "R0099",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Azores",
      "id": "R0099.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "See the individual source request under Sources.",
      "id": "R0099.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    169
  ],
  "section": "Europe and the Mediterranean",
  "source_read_record": null,
  "status": "workflow/research question or table label; no current rule asserted"
}
```

### R0100

| Cyprus | See the individual source request under Sources. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    164,
    164
  ],
  "id": "R0100",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Cyprus",
      "id": "R0100.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "See the individual source request under Sources.",
      "id": "R0100.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    170
  ],
  "section": "Europe and the Mediterranean",
  "source_read_record": null,
  "status": "workflow/research question or table label; no current rule asserted"
}
```

### R0101

| Gibraltar | The actual Income Tax Office corporate page states **15% from 1 July 2024** for most companies, with a **20%** utility/dominant-market exception. The old “12.5% rising to 15% only in 2025 for in-scope MNEs” was wrong; this ordinary rate change is distinct from Pillar Two. See the individual source request under Sources. [gibraltar-corporate](<https://www.gibraltar.gov.gi/income-tax-office/businesses-and-corporations/corporate>) |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    165,
    165
  ],
  "id": "R0101",
  "individual_subclaims": [
    {
      "bindings": [
        "gibraltar-corporate:body"
      ],
      "claim": "Gibraltar",
      "id": "R0101.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "gibraltar-corporate:body"
      ],
      "claim": "The actual Income Tax Office corporate page states **15% from 1 July 2024** for most companies, with a **20%** utility/dominant-market exception. The old “12.5% rising to 15% only in 2025 for in-scope MNEs” was wrong; this ordinary rate change is distinct from Pillar Two. See the individual source request under Sources. [gibraltar-corporate](<https://www.gibraltar.gov.gi/income-tax-office/businesses-and-corporations/corporate>)",
      "id": "R0101.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "Income Tax Office corporate rate/current change overview",
      "block": "gibraltar-corporate:body",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/gibraltar-corporate.txt",
      "capture_sha256": "f8c92ef659af0a5043fc4329d46b059d19d918dbc6179bca90689d6bb8e21af9",
      "limitations": [
        "Actualauthoritybody/selectedoperativeclausesandneighborsread; completecurrententityapplicationandunreadcross-referencesnotcleared."
      ],
      "native_fragment_ids": [
        "N01340",
        "N01341",
        "N01342",
        "N01343",
        "N01344",
        "N01345",
        "N01346",
        "N01347",
        "N01348",
        "N01349",
        "N01350",
        "N01351",
        "N01352",
        "N01353",
        "N01354",
        "N01355",
        "N01356"
      ],
      "official_url": "https://www.gibraltar.gov.gi/income-tax-office/businesses-and-corporations/corporate",
      "own_read_date": "2026-11-16",
      "quote_id": "N01348",
      "read_scope": "Actual extracted lines 27–72, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [
        "increased from 10% to 12.5% with effect from 1st August 2021 and then again to 15% with effect from 1st July 2024. Utility companies or"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "gibraltar-corporate",
      "visual_proof": null
    }
  ],
  "old_lines": [
    171
  ],
  "section": "Europe and the Mediterranean",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0102

| Malta | Income Tax Act **56(6)** provides the company **35%** rate. Income Tax Management Act **48(4)/(4A)** gives conditional shareholder refund routes, including **6/7** in the specified non-passive/non-DTR circumstances; **35% × (1 − 6/7) = 5%** is only that conditional arithmetic, not a rate conferred by shareholder foreign nationality. Registration, distributed taxed profits/tax accounts, tax actually paid, caps and other statutory qualifications matter; passive interest/royalties have the different **5/7** route and double-tax-relief cases differ. See the individual source request under Sources. [mt-cap123](<https://legislation.mt/eli/cap/123/eng/pdf>); [mt-cap372](<https://legislation.mt/eli/cap/372/eng/pdf>) |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    166,
    166
  ],
  "id": "R0102",
  "individual_subclaims": [
    {
      "bindings": [
        "mt-cap123:company-rate",
        "mt-cap372:refunds"
      ],
      "claim": "Malta",
      "id": "R0102.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "mt-cap123:company-rate",
        "mt-cap372:refunds"
      ],
      "claim": "Income Tax Act **56(6)** provides the company **35%** rate. Income Tax Management Act **48(4)/(4A)** gives conditional shareholder refund routes, including **6/7** in the specified non-passive/non-DTR circumstances; **35% × (1 − 6/7) = 5%** is only that conditional arithmetic, not a rate conferred by shareholder foreign nationality. Registration, distributed taxed profits/tax accounts, tax actually paid, caps and other statutory qualifications matter; passive interest/royalties have the different **5/7** route and double-tax-relief cases differ. See the individual source request under Sources. [mt-cap123](<https://legislation.mt/eli/cap/123/eng/pdf>); [mt-cap372](<https://legislation.mt/eli/cap/372/eng/pdf>)",
      "id": "R0102.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "Income Tax Act Cap 123 Article 56(6)",
      "block": "mt-cap123:company-rate",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/mt-cap123.txt",
      "capture_sha256": "4ab01721e228a68e059199bd668492461f8dea9ccbe8b74d427ded4e135a20cb",
      "limitations": [
        "ActualMaltaofficialActselected56(6)andneighbors; othercompanyelectionsnotcleared."
      ],
      "native_fragment_ids": [
        "N01357",
        "N01358",
        "N01359",
        "N01360",
        "N01361",
        "N01362",
        "N01363",
        "N01364",
        "N01365",
        "N01366",
        "N01367",
        "N01368",
        "N01369",
        "N01370",
        "N01371",
        "N01372",
        "N01373"
      ],
      "official_url": "https://legislation.mt/eli/cap/123/eng/pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N01369",
      "read_scope": "Actual extracted lines 9434–9482, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "mt-cap123",
      "visual_proof": null
    },
    {
      "act_article": "Income Tax Management Act Cap 372 Article 48(4)/(4A)",
      "block": "mt-cap372:refunds",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/mt-cap372.txt",
      "capture_sha256": "199e2362cce9930b3a23ee2d4566cefaeb880e365027e2a4f667f48bc6a735f8",
      "limitations": [
        "ActualMaltaofficialAct48(4)/(4A)selectedrefundconditionsandneighborsread; remaininghistorical4Ab/48(7)administrationnotcleared."
      ],
      "native_fragment_ids": [
        "N01374",
        "N01375",
        "N01376",
        "N01377",
        "N01378",
        "N01379",
        "N01380",
        "N01381",
        "N01382",
        "N01383",
        "N01384",
        "N01385",
        "N01386",
        "N01387",
        "N01388",
        "N01389",
        "N01390",
        "N01391",
        "N01392",
        "N01393",
        "N01394",
        "N01395",
        "N01396",
        "N01397",
        "N01398",
        "N01399",
        "N01400",
        "N01401",
        "N01402",
        "N01403",
        "N01404",
        "N01405",
        "N01406",
        "N01407",
        "N01408",
        "N01409",
        "N01410",
        "N01411",
        "N01412",
        "N01413",
        "N01414",
        "N01415",
        "N01416",
        "N01417",
        "N01418",
        "N01419",
        "N01420",
        "N01421",
        "N01422",
        "N01423",
        "N01424",
        "N01425",
        "N01426",
        "N01427",
        "N01428",
        "N01429",
        "N01430",
        "N01431",
        "N01432",
        "N01433",
        "N01434",
        "N01435",
        "N01436",
        "N01437",
        "N01438",
        "N01439",
        "N01440",
        "N01441",
        "N01442"
      ],
      "official_url": "https://legislation.mt/eli/cap/372/eng/pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N01437",
      "read_scope": "Actual extracted lines 2870–3070, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [
        "amount of tax actually paid by the company to the Commissioner on the profits"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "mt-cap372",
      "visual_proof": null
    }
  ],
  "old_lines": [
    172
  ],
  "section": "Europe and the Mediterranean",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0103

| Luxembourg | The actual tax authority national tariff is **16% from 2025** above its band; the Luxembourg City illustration combines it with the **7%** solidarity charge on national CIT and **6.75%** municipal business tax, yielding **23.87%**. The old **17% + approximately 7% municipal** formula was not current or generally applicable. See the individual source request under Sources. [lux-rates](<https://impotsdirects.public.lu/fr/az/c/charg_fisc.html>); [lux-tariff](<https://impotsdirects.public.lu/fr/az/t/tarif-applicable-collectivites/tarif-collect.html>) |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    167,
    167
  ],
  "id": "R0103",
  "individual_subclaims": [
    {
      "bindings": [
        "lux-rates:body",
        "lux-tariff:body"
      ],
      "claim": "Luxembourg",
      "id": "R0103.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "lux-rates:body",
        "lux-tariff:body"
      ],
      "claim": "The actual tax authority national tariff is **16% from 2025** above its band; the Luxembourg City illustration combines it with the **7%** solidarity charge on national CIT and **6.75%** municipal business tax, yielding **23.87%**. The old **17% + approximately 7% municipal** formula was not current or generally applicable. See the individual source request under Sources. [lux-rates](<https://impotsdirects.public.lu/fr/az/c/charg_fisc.html>); [lux-tariff](<https://impotsdirects.public.lu/fr/az/t/tarif-applicable-collectivites/tarif-collect.html>)",
      "id": "R0103.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "ACD current national/solidarity/Luxembourg City comparison",
      "block": "lux-rates:body",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/lux-rates.txt",
      "capture_sha256": "6f92b96c19af9f67fd77d3293ceeed39c7265c21b7396bf0cd5f59bf13535642",
      "limitations": [
        "Actualauthoritybody/selectedoperativeclausesandneighborsread; completecurrententityapplicationandunreadcross-referencesnotcleared."
      ],
      "native_fragment_ids": [
        "N01443",
        "N01444",
        "N01445",
        "N01446",
        "N01447",
        "N01448",
        "N01449",
        "N01450",
        "N01451",
        "N01452",
        "N01453",
        "N01454",
        "N01455"
      ],
      "official_url": "https://impotsdirects.public.lu/fr/az/c/charg_fisc.html",
      "own_read_date": "2026-11-16",
      "quote_id": "N01443",
      "read_scope": "Actual extracted lines 1–79, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [
        "Charge fiscale globale des collectivités - A à Z - Administration des contributions directes - Luxembourg Aller à la navigation Aller au contenu Sous"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "lux-rates",
      "visual_proof": null
    },
    {
      "act_article": "ACD corporation national tariff from 2025",
      "block": "lux-tariff:body",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/lux-tariff.txt",
      "capture_sha256": "e98979209ad19f48a1407f4bf843a904adb1c5e7cc7fa6dcb154f33a5c5b59ae",
      "limitations": [
        "Actualauthoritybody/selectedoperativeclausesandneighborsread; completecurrententityapplicationandunreadcross-referencesnotcleared."
      ],
      "native_fragment_ids": [
        "N01456",
        "N01457",
        "N01458",
        "N01459",
        "N01460",
        "N01461",
        "N01462",
        "N01463",
        "N01464",
        "N01465",
        "N01466",
        "N01467",
        "N01468",
        "N01469",
        "N01470",
        "N01471",
        "N01472"
      ],
      "official_url": "https://impotsdirects.public.lu/fr/az/t/tarif-applicable-collectivites/tarif-collect.html",
      "own_read_date": "2026-11-16",
      "quote_id": "N01456",
      "read_scope": "Actual extracted lines 1–27, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [
        "Tarif applicable aux collectivités à partir de 2017 (impôt sur le revenu des collectivités) - A à Z - Administration des contributions directes -"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "lux-tariff",
      "visual_proof": null
    }
  ],
  "old_lines": [
    173
  ],
  "section": "Europe and the Mediterranean",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0104

| Ireland / IFSC legacy / section 110 | Revenue states **12.5% trading** and **25% excepted/non-trading income**; the business type and income stream matter. See the individual source request under Sources. [ireland-rates](<https://www.revenue.ie/en/companies-and-charities/corporation-tax-for-companies/corporation-tax/basis-of-charge.aspx>) |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    168,
    168
  ],
  "id": "R0104",
  "individual_subclaims": [
    {
      "bindings": [
        "ireland-rates:body"
      ],
      "claim": "Ireland / IFSC legacy / section 110",
      "id": "R0104.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "ireland-rates:body"
      ],
      "claim": "Revenue states **12.5% trading** and **25% excepted/non-trading income**; the business type and income stream matter. See the individual source request under Sources. [ireland-rates](<https://www.revenue.ie/en/companies-and-charities/corporation-tax-for-companies/corporation-tax/basis-of-charge.aspx>)",
      "id": "R0104.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "Revenue corporation-tax basis/rate overview",
      "block": "ireland-rates:body",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/ireland-rates.txt",
      "capture_sha256": "60318d9f5558f1d6e43df6a4ccfd43ce5f60d60b00a94720bde66d422b183fda",
      "limitations": [
        "Actualauthoritybody/selectedoperativeclausesandneighborsread; completecurrententityapplicationandunreadcross-referencesnotcleared."
      ],
      "native_fragment_ids": [
        "N01473",
        "N01474",
        "N01475",
        "N01476",
        "N01477",
        "N01478",
        "N01479"
      ],
      "official_url": "https://www.revenue.ie/en/companies-and-charities/corporation-tax-for-companies/corporation-tax/basis-of-charge.aspx",
      "own_read_date": "2026-11-16",
      "quote_id": "N01473",
      "read_scope": "Actual extracted lines 32–56, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [
        "| Gaeilge Search Home Companies and charities Corporation Tax for companies Corporation Tax (CT) Basis of charge There are two rates of Corporation Tax"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "ireland-rates",
      "visual_proof": null
    }
  ],
  "old_lines": [
    174
  ],
  "section": "Europe and the Mediterranean",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0105

| Isle of Man | See the individual source request under Sources. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    169,
    169
  ],
  "id": "R0105",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Isle of Man",
      "id": "R0105.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "See the individual source request under Sources.",
      "id": "R0105.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    175
  ],
  "section": "Europe and the Mediterranean",
  "source_read_record": null,
  "status": "workflow/research question or table label; no current rule asserted"
}
```

### R0106

| Jersey | Revenue’s actual company guidance describes **0% standard**, **10%** for defined financial-service companies and **20%** for defined utility/property and other categories, with additional retail rules. The actual **Multinational Corporate Income Tax (Jersey) Law 2025**, effective **1 January 2025**, applies a separate **15% MCIT** to covered groups under its income/scope rules; Revenue expressly distinguishes it from a QDMTT. Its IIR and MCIT are not a still-unadopted 2025 proposal; no UTPR adoption is inferred. See the individual source request under Sources. [jersey-company-web](<https://www.gov.je/industry/businessadvicehub/businesstaxessocialsecurity/pages/companytax.aspx>); [jersey-law-web](<https://jerseylaw.je/laws/current/l_7_2025>); [jersey-comm-web](<https://jerseylaw.je/laws/current/l_7_2025>); [jersey-p2-web](<https://www.gov.je/taxesmoney/incometax/companies/guidelines/pages/oecdpillars.aspx>) |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    170,
    170
  ],
  "id": "R0106",
  "individual_subclaims": [
    {
      "bindings": [
        "jersey-company-web:body",
        "jersey-law-web:scope-rate",
        "jersey-law-web:commencement",
        "jersey-p2-web:body"
      ],
      "claim": "Jersey",
      "id": "R0106.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "jersey-company-web:body",
        "jersey-law-web:scope-rate",
        "jersey-law-web:commencement",
        "jersey-p2-web:body"
      ],
      "claim": "Revenue’s actual company guidance describes **0% standard**, **10%** for defined financial-service companies and **20%** for defined utility/property and other categories, with additional retail rules. The actual **Multinational Corporate Income Tax (Jersey) Law 2025**, effective **1 January 2025**, applies a separate **15% MCIT** to covered groups under its income/scope rules; Revenue expressly distinguishes it from a QDMTT. Its IIR and MCIT are not a still-unadopted 2025 proposal; no UTPR adoption is inferred. See the individual source request under Sources. [jersey-company-web](<https://www.gov.je/industry/businessadvicehub/businesstaxessocialsecurity/pages/companytax.aspx>); [jersey-law-web](<https://jerseylaw.je/laws/current/l_7_2025>); [jersey-comm-web](<https://jerseylaw.je/laws/current/l_7_2025>); [jersey-p2-web](<https://www.gov.je/taxesmoney/incometax/companies/guidelines/pages/oecdpillars.aspx>)",
      "id": "R0106.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "Revenue Jersey company-rate categories overview",
      "block": "jersey-company-web:body",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/jersey-company-web-web-selected.txt",
      "capture_sha256": "0523ad8d626ec84765fe3ad5f57910fb6c7ff27932c6f0b9694f99925b5e294f",
      "limitations": [
        "Authority page, selected actual body read; not whole cross-referenced legislation.",
        "Only tool Lnn locators and citation wrappers removed, retaining visible anchor text; raw response immutable."
      ],
      "native_fragment_ids": [
        "N02096",
        "N02097",
        "N02098",
        "N02099",
        "N02100",
        "N02101",
        "N02102",
        "N02103",
        "N02104",
        "N02105",
        "N02106",
        "N02107",
        "N02108",
        "N02109"
      ],
      "official_url": "https://www.gov.je/industry/businessadvicehub/businesstaxessocialsecurity/pages/companytax.aspx",
      "own_read_date": "2026-11-16",
      "quote_id": "N02098",
      "read_scope": "Actual extracted lines 1–46, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [
        "10% for certain financial services companies. See regulated financial service companies on Locate Jersey * 20% for utility companies. For example, telephone, gas or electric"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "jersey-company-web",
      "visual_proof": null
    },
    {
      "act_article": "MCIT (Jersey) Law 2025 Articles 1–12, 2026 consolidation",
      "block": "jersey-law-web:scope-rate",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/jersey-law-web-web-selected.txt",
      "capture_sha256": "9de921f34643fad92e4cc5d2c4fe72d88b27e132cf14f098b13e14156d3fe406",
      "limitations": [
        "Actualofficial2026consolidation, Articles1–12withallnearbyexclusions/conditionsread. CompleteIIR/alltaxcomputationsnotcleared.",
        "Only tool Lnn locators and citation wrappers removed, retaining visible anchor text; raw response immutable."
      ],
      "native_fragment_ids": [
        "N02110",
        "N02111",
        "N02112",
        "N02113",
        "N02114",
        "N02115",
        "N02116",
        "N02117",
        "N02118",
        "N02119",
        "N02120",
        "N02121",
        "N02122",
        "N02123",
        "N02124",
        "N02125",
        "N02126",
        "N02127",
        "N02128",
        "N02129",
        "N02130",
        "N02131",
        "N02132",
        "N02133",
        "N02134",
        "N02135",
        "N02136",
        "N02137",
        "N02138",
        "N02139",
        "N02140",
        "N02141",
        "N02142",
        "N02143",
        "N02144",
        "N02145",
        "N02146",
        "N02147",
        "N02148",
        "N02149",
        "N02150",
        "N02151",
        "N02152",
        "N02153",
        "N02154",
        "N02155",
        "N02156",
        "N02157",
        "N02158",
        "N02159",
        "N02160",
        "N02161",
        "N02162",
        "N02163",
        "N02164",
        "N02165",
        "N02166",
        "N02167",
        "N02168",
        "N02169",
        "N02170",
        "N02171",
        "N02172",
        "N02173",
        "N02174",
        "N02175"
      ],
      "official_url": "https://jerseylaw.je/laws/current/l_7_2025",
      "own_read_date": "2026-11-16",
      "quote_id": "N02123",
      "read_scope": "Actual extracted lines 1–196, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [
        "are defined in the Model Rules. 3 Application of this Law: large multinational enterprise groups (1) This Law applies in relation to an in-scope MNE"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "jersey-law-web",
      "visual_proof": null
    },
    {
      "act_article": "MCIT (Jersey) Law 2025 Article 43",
      "block": "jersey-law-web:commencement",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/jersey-comm-web-web-selected.txt",
      "capture_sha256": "cb2ef166e59418b08e1b05f6dfc43d8f530d797a6bf0ce19806801f483219039",
      "limitations": [
        "ActualArticle43wholecommencementwithneighborheadingsread.",
        "Only tool Lnn locators and citation wrappers removed, retaining visible anchor text; raw response immutable."
      ],
      "native_fragment_ids": [
        "N02176",
        "N02177",
        "N02178"
      ],
      "official_url": "https://jerseylaw.je/laws/current/l_7_2025",
      "own_read_date": "2026-11-16",
      "quote_id": "N02178",
      "read_scope": "Actual extracted lines 1–12, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "jersey-comm-web",
      "visual_proof": null
    },
    {
      "act_article": "Revenue Jersey IIR/MCIT overview",
      "block": "jersey-p2-web:body",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/jersey-p2-web-web-selected.txt",
      "capture_sha256": "b49df7b0c1c029c8df988e936eaa2096a4fa2d80ab9f0694e3b4e7bb2732ce61",
      "limitations": [
        "Authority page, selected actual body read; not whole cross-referenced legislation.",
        "Only tool Lnn locators and citation wrappers removed, retaining visible anchor text; raw response immutable."
      ],
      "native_fragment_ids": [
        "N02179",
        "N02180",
        "N02181",
        "N02182",
        "N02183",
        "N02184",
        "N02185",
        "N02186",
        "N02187",
        "N02188",
        "N02189",
        "N02190",
        "N02191",
        "N02192",
        "N02193",
        "N02194",
        "N02195",
        "N02196",
        "N02197",
        "N02198",
        "N02199",
        "N02200",
        "N02201",
        "N02202",
        "N02203",
        "N02204",
        "N02205",
        "N02206",
        "N02207",
        "N02208",
        "N02209",
        "N02210",
        "N02211",
        "N02212",
        "N02213",
        "N02214",
        "N02215",
        "N02216",
        "N02217",
        "N02218",
        "N02219",
        "N02220",
        "N02221",
        "N02222",
        "N02223",
        "N02224",
        "N02225",
        "N02226",
        "N02227",
        "N02228",
        "N02229",
        "N02230",
        "N02231",
        "N02232",
        "N02233",
        "N02234",
        "N02235",
        "N02236",
        "N02237",
        "N02238",
        "N02239",
        "N02240",
        "N02241",
        "N02242",
        "N02243",
        "N02244"
      ],
      "official_url": "https://www.gov.je/taxesmoney/incometax/companies/guidelines/pages/oecdpillars.aspx",
      "own_read_date": "2026-11-16",
      "quote_id": "N02184",
      "read_scope": "Actual extracted lines 1–125, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [
        "Income Tax (MCIT) for in-scope entities for accounting periods beginning on or after 1 Janu​ary 2025. ​ Multinational Corporate Income Tax (Jersey) Law 2025 ​Multinational"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "jersey-p2-web",
      "visual_proof": null
    }
  ],
  "old_lines": [
    176
  ],
  "section": "Europe and the Mediterranean",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0107

| Guernsey | See the individual source request under Sources. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    171,
    171
  ],
  "id": "R0107",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Guernsey",
      "id": "R0107.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "See the individual source request under Sources.",
      "id": "R0107.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    176
  ],
  "section": "Europe and the Mediterranean",
  "source_read_record": null,
  "status": "workflow/research question or table label; no current rule asserted"
}
```

### R0108

| Monaco | Actual consolidated Ordinance 3152 Articles **1–2** cover defined industrial/commercial activity with **at least 25%** external turnover and separately defined IP receipts, with specified foreign-operation exclusions. Article **21** gives **25% from 1 January 2022**, not the old 33.33%. The actual October 2026 amendment is procedural with its own period application. See the individual source request under Sources. [monaco-current](<https://legimonaco.mc/tnc/ordonnance/1964/03-19-3.152/>); [monaco-oct2026](<https://journaldemonaco.gouv.mc/fr/Journaux/2026/Journal-8823/Ordonnance-Souveraine-n-12.211-du-23-octobre-2026-modifiant-l-Ordonnance-Souveraine-n-3.152-du-19-mars-1964-instituant-un-impot-sur-les-benefices-modifiee>) |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    172,
    172
  ],
  "id": "R0108",
  "individual_subclaims": [
    {
      "bindings": [
        "monaco-current:scope",
        "monaco-current:rate",
        "monaco-oct2026:operative"
      ],
      "claim": "Monaco",
      "id": "R0108.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "monaco-current:scope",
        "monaco-current:rate",
        "monaco-oct2026:operative"
      ],
      "claim": "Actual consolidated Ordinance 3152 Articles **1–2** cover defined industrial/commercial activity with **at least 25%** external turnover and separately defined IP receipts, with specified foreign-operation exclusions. Article **21** gives **25% from 1 January 2022**, not the old 33.33%. The actual October 2026 amendment is procedural with its own period application. See the individual source request under Sources. [monaco-current](<https://legimonaco.mc/tnc/ordonnance/1964/03-19-3.152/>); [monaco-oct2026](<https://journaldemonaco.gouv.mc/fr/Journaux/2026/Journal-8823/Ordonnance-Souveraine-n-12.211-du-23-octobre-2026-modifiant-l-Ordonnance-Souveraine-n-3.152-du-19-mars-1964-instituant-un-impot-sur-les-benefices-modifiee>)",
      "id": "R0108.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "Ordinance 3152 Articles 1–2 with next heading",
      "block": "monaco-current:scope",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/monaco-current.txt",
      "capture_sha256": "1382a316b026aa091e6c7b8c8034c730da84df0770b87c0680d22dfe9e040e95",
      "limitations": [
        "Actualauthoritybody/selectedoperativeclausesandneighborsread; completecurrententityapplicationandunreadcross-referencesnotcleared."
      ],
      "native_fragment_ids": [
        "N01480",
        "N01481",
        "N01482",
        "N01483",
        "N01484",
        "N01485",
        "N01486",
        "N01487",
        "N01488",
        "N01489",
        "N01490",
        "N01491",
        "N01492",
        "N01493",
        "N01494",
        "N01495",
        "N01496",
        "N01497",
        "N01498",
        "N01499",
        "N01500"
      ],
      "official_url": "https://legimonaco.mc/tnc/ordonnance/1964/03-19-3.152/",
      "own_read_date": "2026-11-16",
      "quote_id": "N01480",
      "read_scope": "Actual extracted lines 1–24, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [
        "Ordonnance Souveraine n° 3.152 du 19 mars 1964 instituant un impôt sur les bénéfices [Legimonaco] Vu la Constitution du 17 décembre 1962 ; Vu la"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "monaco-current",
      "visual_proof": null
    },
    {
      "act_article": "Ordinance 3152 Article 21",
      "block": "monaco-current:rate",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/monaco-current.txt",
      "capture_sha256": "1382a316b026aa091e6c7b8c8034c730da84df0770b87c0680d22dfe9e040e95",
      "limitations": [
        "Actualauthoritybody/selectedoperativeclausesandneighborsread; completecurrententityapplicationandunreadcross-referencesnotcleared."
      ],
      "native_fragment_ids": [
        "N01501",
        "N01502",
        "N01503",
        "N01504",
        "N01505",
        "N01506",
        "N01507",
        "N01508",
        "N01509",
        "N01510",
        "N01511",
        "N01512",
        "N01513",
        "N01514",
        "N01515",
        "N01516",
        "N01517",
        "N01518"
      ],
      "official_url": "https://legimonaco.mc/tnc/ordonnance/1964/03-19-3.152/",
      "own_read_date": "2026-11-16",
      "quote_id": "N01505",
      "read_scope": "Actual extracted lines 200–217, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "monaco-current",
      "visual_proof": null
    },
    {
      "act_article": "Ordinance 12.211/2026 operative procedural amendments",
      "block": "monaco-oct2026:operative",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/monaco-oct2026.txt",
      "capture_sha256": "33217e353fb9f99ea03ee2eae95b1e6072100599b4755c51b30738c480d6d92b",
      "limitations": [
        "Actualauthoritybody/selectedoperativeclausesandneighborsread; completecurrententityapplicationandunreadcross-referencesnotcleared."
      ],
      "native_fragment_ids": [
        "N01519",
        "N01520",
        "N01521",
        "N01522",
        "N01523",
        "N01524",
        "N01525",
        "N01526",
        "N01527",
        "N01528",
        "N01529",
        "N01530",
        "N01531",
        "N01532",
        "N01533",
        "N01534",
        "N01535",
        "N01536",
        "N01537",
        "N01538",
        "N01539",
        "N01540",
        "N01541",
        "N01542",
        "N01543",
        "N01544",
        "N01545",
        "N01546",
        "N01547",
        "N01548",
        "N01549",
        "N01550",
        "N01551",
        "N01552"
      ],
      "official_url": "https://journaldemonaco.gouv.mc/fr/Journaux/2026/Journal-8823/Ordonnance-Souveraine-n-12.211-du-23-octobre-2026-modifiant-l-Ordonnance-Souveraine-n-3.152-du-19-mars-1964-instituant-un-impot-sur-les-benefices-modifiee",
      "own_read_date": "2026-11-16",
      "quote_id": "N01525",
      "read_scope": "Actual extracted lines 64–104, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [
        "». Art. 2. L’Ordonnance Souveraine n° 3.152 du 19 mars 1964, modifiée, susvisée, est ainsi modifiée : A. L’article 34 est ainsi modifié : 1°"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "monaco-oct2026",
      "visual_proof": null
    }
  ],
  "old_lines": [
    177
  ],
  "section": "Europe and the Mediterranean",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0109

| Andorra | The actual tax department overview states **10% general CIT**, with a separate collective-investment-vehicle exception. See the individual source request under Sources. [andorra-cit](<https://www.e-tramits.ad/tramits/ca/impostos/is>) |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    173,
    173
  ],
  "id": "R0109",
  "individual_subclaims": [
    {
      "bindings": [
        "andorra-cit:rate"
      ],
      "claim": "Andorra",
      "id": "R0109.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "andorra-cit:rate"
      ],
      "claim": "The actual tax department overview states **10% general CIT**, with a separate collective-investment-vehicle exception. See the individual source request under Sources. [andorra-cit](<https://www.e-tramits.ad/tramits/ca/impostos/is>)",
      "id": "R0109.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "Departament Tributs IS general-rate overview",
      "block": "andorra-cit:rate",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/andorra-cit.txt",
      "capture_sha256": "618b5052578f65434b60fd1372123ca40c01a69d0aa7b725d98c873f33992db7",
      "limitations": [
        "Actualauthoritybody/selectedoperativeclausesandneighborsread; completecurrententityapplicationandunreadcross-referencesnotcleared."
      ],
      "native_fragment_ids": [
        "N01553",
        "N01554",
        "N01555",
        "N01556",
        "N01557",
        "N01558"
      ],
      "official_url": "https://www.e-tramits.ad/tramits/ca/impostos/is",
      "own_read_date": "2026-11-16",
      "quote_id": "N01555",
      "read_scope": "Actual extracted lines 47–59, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [
        "impositiu aplicable? El tipus general de gravamen per als obligats tributaris de l’impost sobre societats és del 10 per cent. El tipus de gravamen aplicable"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "andorra-cit",
      "visual_proof": null
    }
  ],
  "old_lines": [
    178
  ],
  "section": "Europe and the Mediterranean",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0110

| San Marino | See the individual source request under Sources. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    174,
    174
  ],
  "id": "R0110",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "San Marino",
      "id": "R0110.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "See the individual source request under Sources.",
      "id": "R0110.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    179
  ],
  "section": "Europe and the Mediterranean",
  "source_read_record": null,
  "status": "workflow/research question or table label; no current rule asserted"
}
```

### R0111

## Africa, with Labuan separately identified as Malaysia

```json
{
  "context_only_blocks": [],
  "current_lines": [
    176,
    176
  ],
  "id": "R0111",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "## Africa, with Labuan separately identified as Malaysia",
      "id": "R0111.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    181,
    183
  ],
  "section": "Africa, with Labuan separately identified as Malaysia",
  "source_read_record": null,
  "status": "heading"
}
```

### R0112

| Regime | Supported position and individual limits |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    178,
    178
  ],
  "id": "R0112",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Regime",
      "id": "R0112.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Supported position and individual limits",
      "id": "R0112.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    185
  ],
  "section": "Africa, with Labuan separately identified as Malaysia",
  "source_read_record": null,
  "status": "workflow/research question or table label; no current rule asserted"
}
```

### R0113

| --- | --- |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    179,
    179
  ],
  "id": "R0113",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "---",
      "id": "R0113.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "---",
      "id": "R0113.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    186
  ],
  "section": "Africa, with Labuan separately identified as Malaysia",
  "source_read_record": null,
  "status": "table separator"
}
```

### R0114

| Mauritius Global Business Licence | The actual MRA consolidated Income Tax Act (whose internet edition disclaims legal responsibility for errors) gives the general company **15%** rate and defined partial-exemption categories: **80%** for specified foreign dividends/interest and other listed income subject to their own exclusions/substance conditions. A resulting **3%** is conditional arithmetic on fully qualifying income, not an automatic GBL rate; some other categories use different exemption percentages. See the individual source request under Sources. [mauritius-act2026-full](<https://www.mra.mu/download/ITAConsolidated.pdf>) |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    180,
    180
  ],
  "id": "R0114",
  "individual_subclaims": [
    {
      "bindings": [
        "mauritius-act2026-full:rates",
        "mauritius-act2026-full:partial-exemption"
      ],
      "claim": "Mauritius Global Business Licence",
      "id": "R0114.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "mauritius-act2026-full:rates",
        "mauritius-act2026-full:partial-exemption"
      ],
      "claim": "The actual MRA consolidated Income Tax Act (whose internet edition disclaims legal responsibility for errors) gives the general company **15%** rate and defined partial-exemption categories: **80%** for specified foreign dividends/interest and other listed income subject to their own exclusions/substance conditions. A resulting **3%** is conditional arithmetic on fully qualifying income, not an automatic GBL rate; some other categories use different exemption percentages. See the individual source request under Sources. [mauritius-act2026-full](<https://www.mra.mu/download/ITAConsolidated.pdf>)",
      "id": "R0114.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "Income Tax Act First Schedule company rate provisions",
      "block": "mauritius-act2026-full:rates",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/mauritius-act2026-full.txt",
      "capture_sha256": "efcf33d41fd4d2d3a33ec8eb98c76d6896865e15bf818849dd597beb9cd15933",
      "limitations": [
        "MRA2026internetconsolidationcoverforinformationonly/disclaimslegalresponsibility; selectedreadscopesonly, notwhole536pages. Prescribedsubstance/fullcalculationrulesunread."
      ],
      "native_fragment_ids": [
        "N01574",
        "N01575",
        "N01576",
        "N01577",
        "N01578",
        "N01579",
        "N01580",
        "N01581",
        "N01582",
        "N01583",
        "N01584",
        "N01585",
        "N01586",
        "N01587",
        "N01588"
      ],
      "official_url": "https://www.mra.mu/download/ITAConsolidated.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N01578",
      "read_scope": "Actual extracted lines 15310–15395, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [
        "Statement under section 50B is between 1 July 2028 and 30 June 2029. 162. Repeal and savings (1) Subject to section 161A1051*, the Income Tax"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "mauritius-act2026-full",
      "visual_proof": null
    },
    {
      "act_article": "Income Tax Act Second Schedule specified partial exemptions and conditions",
      "block": "mauritius-act2026-full:partial-exemption",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/mauritius-act2026-full.txt",
      "capture_sha256": "efcf33d41fd4d2d3a33ec8eb98c76d6896865e15bf818849dd597beb9cd15933",
      "limitations": [
        "MRA2026internetconsolidationcoverforinformationonly/disclaimslegalresponsibility; selectedreadscopesonly, notwhole536pages. Prescribedsubstance/fullcalculationrulesunread."
      ],
      "native_fragment_ids": [
        "N01589",
        "N01590",
        "N01591",
        "N01592",
        "N01593",
        "N01594",
        "N01595",
        "N01596",
        "N01597",
        "N01598",
        "N01599",
        "N01600",
        "N01601",
        "N01602",
        "N01603",
        "N01604",
        "N01605",
        "N01606",
        "N01607",
        "N01608"
      ],
      "official_url": "https://www.mra.mu/download/ITAConsolidated.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N01594",
      "read_scope": "Actual extracted lines 15710–15795, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "mauritius-act2026-full",
      "visual_proof": null
    }
  ],
  "old_lines": [
    187
  ],
  "section": "Africa, with Labuan separately identified as Malaysia",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0115

| Mauritius Freeport | Section **44B** and the relevant rate schedule use **3%** for the specified export/manufacturing/local-sale circumstances, with distinct conditions; the original blanket **0%** manufacturing/warehousing/distribution-to-non-African-mainland cell is unusable. See the individual source request under Sources. [mauritius-act2026-full](<https://www.mra.mu/download/ITAConsolidated.pdf>) |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    181,
    181
  ],
  "id": "R0115",
  "individual_subclaims": [
    {
      "bindings": [
        "mauritius-act2026-full:Freeport",
        "mauritius-act2026-full:rates"
      ],
      "claim": "Mauritius Freeport",
      "id": "R0115.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "mauritius-act2026-full:Freeport",
        "mauritius-act2026-full:rates"
      ],
      "claim": "Section **44B** and the relevant rate schedule use **3%** for the specified export/manufacturing/local-sale circumstances, with distinct conditions; the original blanket **0%** manufacturing/warehousing/distribution-to-non-African-mainland cell is unusable. See the individual source request under Sources. [mauritius-act2026-full](<https://www.mra.mu/download/ITAConsolidated.pdf>)",
      "id": "R0115.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "Income Tax Act section 44B",
      "block": "mauritius-act2026-full:Freeport",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/mauritius-act2026-full.txt",
      "capture_sha256": "efcf33d41fd4d2d3a33ec8eb98c76d6896865e15bf818849dd597beb9cd15933",
      "limitations": [
        "MRA2026internetconsolidationcoverforinformationonly/disclaimslegalresponsibility; selectedreadscopesonly, notwhole536pages. Prescribedsubstance/fullcalculationrulesunread."
      ],
      "native_fragment_ids": [
        "N01559",
        "N01560",
        "N01561",
        "N01562",
        "N01563",
        "N01564",
        "N01565",
        "N01566",
        "N01567",
        "N01568",
        "N01569",
        "N01570",
        "N01571",
        "N01572",
        "N01573"
      ],
      "official_url": "https://www.mra.mu/download/ITAConsolidated.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N01561",
      "read_scope": "Actual extracted lines 3188–3260, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "mauritius-act2026-full",
      "visual_proof": null
    },
    {
      "act_article": "Income Tax Act First Schedule company rate provisions",
      "block": "mauritius-act2026-full:rates",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/mauritius-act2026-full.txt",
      "capture_sha256": "efcf33d41fd4d2d3a33ec8eb98c76d6896865e15bf818849dd597beb9cd15933",
      "limitations": [
        "MRA2026internetconsolidationcoverforinformationonly/disclaimslegalresponsibility; selectedreadscopesonly, notwhole536pages. Prescribedsubstance/fullcalculationrulesunread."
      ],
      "native_fragment_ids": [
        "N01574",
        "N01575",
        "N01576",
        "N01577",
        "N01578",
        "N01579",
        "N01580",
        "N01581",
        "N01582",
        "N01583",
        "N01584",
        "N01585",
        "N01586",
        "N01587",
        "N01588"
      ],
      "official_url": "https://www.mra.mu/download/ITAConsolidated.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N01574",
      "read_scope": "Actual extracted lines 15310–15395, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "mauritius-act2026-full",
      "visual_proof": null
    }
  ],
  "old_lines": [
    188
  ],
  "section": "Africa, with Labuan separately identified as Malaysia",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0116

| Labuan, Malaysia | Geographically in Malaysia, not Africa. The AGC updated text as at **1 January 2026**, hosted by Labuan FSA, states **3% of audited net profits** for covered trading activity and the section 9 exemption for covered non-trading investment activity; mixed activity is treated as trading. The **MYR 20,000 flat election** is not a current alternative: section 7 is deleted. Section 2B imposes substance conditions and **24%** for failure; IP royalty/other IP income is excluded from Labuan business activity, the Income Tax Act 1967 election is irrevocable under its conditions, and section 3(2)–(4) applies the minimum-tax provisions to covered groups. The cover says **“NOT AN AUTHENTIC TEXT”**: Gazette originals, detailed substance regulations and the proposed entity’s current treatment remain **not yet confirmed**. [labuan-act2026](<https://www.labuanfsa.gov.my/clients/asset_717D5286-17F8-4620-B852-83CA4FFCC30C/contentms/img/documents/regulations/legislation/2026/LBATA-updated-2026_19102026.pdf>) |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    182,
    182
  ],
  "id": "R0116",
  "individual_subclaims": [
    {
      "bindings": [
        "labuan-act2026:scope-rates",
        "labuan-act2026:deleted-election",
        "labuan-act2026:non-trading"
      ],
      "claim": "Labuan, Malaysia",
      "id": "R0116.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "labuan-act2026:scope-rates",
        "labuan-act2026:deleted-election",
        "labuan-act2026:non-trading"
      ],
      "claim": "Geographically in Malaysia, not Africa. The AGC updated text as at **1 January 2026**, hosted by Labuan FSA, states **3% of audited net profits** for covered trading activity and the section 9 exemption for covered non-trading investment activity; mixed activity is treated as trading. The **MYR 20,000 flat election** is not a current alternative: section 7 is deleted. Section 2B imposes substance conditions and **24%** for failure; IP royalty/other IP income is excluded from Labuan business activity, the Income Tax Act 1967 election is irrevocable under its conditions, and section 3(2)–(4) applies the minimum-tax provisions to covered groups. The cover says **“NOT AN AUTHENTIC TEXT”**: Gazette originals, detailed substance regulations and the proposed entity’s current treatment remain **not yet confirmed**. [labuan-act2026](<https://www.labuanfsa.gov.my/clients/asset_717D5286-17F8-4620-B852-83CA4FFCC30C/contentms/img/documents/regulations/legislation/2026/LBATA-updated-2026_19102026.pdf>)",
      "id": "R0116.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "LBATA sections 2–4 including 2B, minimum-tax 3(2)–(4), election 3A; 3B concerns treaty residence",
      "block": "labuan-act2026:scope-rates",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/labuan-act2026.txt",
      "capture_sha256": "f8c049c07582860378306f73f3d717e479f46f493063c80911908bcc1e4e015d",
      "limitations": [
        "AGCupdatedasat1Jan2026hostedbyFSAexplicitNOTANAUTHENTICTEXT; Gazetteoriginals/detailedsubstanceconditionsandall1967Actcross-referencesnotread."
      ],
      "native_fragment_ids": [
        "N01657",
        "N01658",
        "N01659",
        "N01660",
        "N01661",
        "N01662",
        "N01663",
        "N01664",
        "N01665",
        "N01666",
        "N01667",
        "N01668",
        "N01669",
        "N01670",
        "N01671",
        "N01672",
        "N01673",
        "N01674",
        "N01675",
        "N01676",
        "N01677",
        "N01678",
        "N01679",
        "N01680",
        "N01681",
        "N01682",
        "N01683",
        "N01684",
        "N01685",
        "N01686",
        "N01687",
        "N01688",
        "N01689",
        "N01690",
        "N01691",
        "N01692",
        "N01693",
        "N01694",
        "N01695",
        "N01696",
        "N01697",
        "N01698",
        "N01699",
        "N01700",
        "N01701",
        "N01702",
        "N01703",
        "N01704",
        "N01705",
        "N01706",
        "N01707",
        "N01708",
        "N01709",
        "N01710",
        "N01711",
        "N01712",
        "N01713",
        "N01714",
        "N01715",
        "N01716"
      ],
      "official_url": "https://www.labuanfsa.gov.my/clients/asset_717D5286-17F8-4620-B852-83CA4FFCC30C/contentms/img/documents/regulations/legislation/2026/LBATA-updated-2026_19102026.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N01670",
      "read_scope": "Actual extracted lines 228–470, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [
        "Labuan business activity carried on by a Labuan entity which makes an election under section 3A. Designated Labuan business activity 2A. (1) The Minister may,"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "labuan-act2026",
      "visual_proof": null
    },
    {
      "act_article": "LBATA section 7 deleted",
      "block": "labuan-act2026:deleted-election",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/labuan-act2026.txt",
      "capture_sha256": "f8c049c07582860378306f73f3d717e479f46f493063c80911908bcc1e4e015d",
      "limitations": [
        "AGCupdatedasat1Jan2026hostedbyFSAexplicitNOTANAUTHENTICTEXT; Gazetteoriginals/detailedsubstanceconditionsandall1967Actcross-referencesnotread."
      ],
      "native_fragment_ids": [
        "N01717",
        "N01718",
        "N01719",
        "N01720",
        "N01721",
        "N01722"
      ],
      "official_url": "https://www.labuanfsa.gov.my/clients/asset_717D5286-17F8-4620-B852-83CA4FFCC30C/contentms/img/documents/regulations/legislation/2026/LBATA-updated-2026_19102026.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N01717",
      "read_scope": "Actual extracted lines 648–670, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "labuan-act2026",
      "visual_proof": null
    },
    {
      "act_article": "LBATA sections 9–10",
      "block": "labuan-act2026:non-trading",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/labuan-act2026.txt",
      "capture_sha256": "f8c049c07582860378306f73f3d717e479f46f493063c80911908bcc1e4e015d",
      "limitations": [
        "AGCupdatedasat1Jan2026hostedbyFSAexplicitNOTANAUTHENTICTEXT; Gazetteoriginals/detailedsubstanceconditionsandall1967Actcross-referencesnotread."
      ],
      "native_fragment_ids": [
        "N01723",
        "N01724",
        "N01725",
        "N01726",
        "N01727",
        "N01728",
        "N01729",
        "N01730",
        "N01731",
        "N01732",
        "N01733",
        "N01734",
        "N01735",
        "N01736",
        "N01737",
        "N01738",
        "N01739",
        "N01740",
        "N01741",
        "N01742",
        "N01743"
      ],
      "official_url": "https://www.labuanfsa.gov.my/clients/asset_717D5286-17F8-4620-B852-83CA4FFCC30C/contentms/img/documents/regulations/legislation/2026/LBATA-updated-2026_19102026.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N01728",
      "read_scope": "Actual extracted lines 680–757, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "labuan-act2026",
      "visual_proof": null
    }
  ],
  "old_lines": [
    189
  ],
  "section": "Africa, with Labuan separately identified as Malaysia",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0117

| Tanger Free Zone, Morocco | See the individual source request under Sources. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    183,
    183
  ],
  "id": "R0117",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Tanger Free Zone, Morocco",
      "id": "R0117.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "See the individual source request under Sources.",
      "id": "R0117.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    190
  ],
  "section": "Africa, with Labuan separately identified as Malaysia",
  "source_read_record": null,
  "status": "workflow/research question or table label; no current rule asserted"
}
```

### R0118

| Egypt: Suez Canal Economic Zone / NUCA | See the individual source request under Sources. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    184,
    184
  ],
  "id": "R0118",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Egypt: Suez Canal Economic Zone / NUCA",
      "id": "R0118.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "See the individual source request under Sources.",
      "id": "R0118.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    191
  ],
  "section": "Africa, with Labuan separately identified as Malaysia",
  "source_read_record": null,
  "status": "workflow/research question or table label; no current rule asserted"
}
```

### R0119

| Nigeria: Lagos, Calabar, Lekki FTZs | The actually read Nigeria Tax Act 2025, applicable from **1 January 2026**, section 60/Second Schedule make free-zone income relief conditional, including domestic-sale and subsequent-period rules; section 57 has an effective-tax overlay. The old unconditional **100% CIT/customs exemption** is unusable. See the individual source request under Sources. [nigeria-tax2025](<https://nass.gov.ng/documents/download/11249>) |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    185,
    185
  ],
  "id": "R0119",
  "individual_subclaims": [
    {
      "bindings": [
        "nigeria-tax2025:scope",
        "nigeria-tax2025:free-zone",
        "nigeria-tax2025:commencement"
      ],
      "claim": "Nigeria: Lagos, Calabar, Lekki FTZs",
      "id": "R0119.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "nigeria-tax2025:scope",
        "nigeria-tax2025:free-zone",
        "nigeria-tax2025:commencement"
      ],
      "claim": "The actually read Nigeria Tax Act 2025, applicable from **1 January 2026**, section 60/Second Schedule make free-zone income relief conditional, including domestic-sale and subsequent-period rules; section 57 has an effective-tax overlay. The old unconditional **100% CIT/customs exemption** is unusable. See the individual source request under Sources. [nigeria-tax2025](<https://nass.gov.ng/documents/download/11249>)",
      "id": "R0119.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "Nigeria Tax Act sections 56–60",
      "block": "nigeria-tax2025:scope",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/nigeria-tax2025.txt",
      "capture_sha256": "f92f0c2c75dea152fdfa780d8a9972d44cbcf1f24f1d95085937787aeaf45ada",
      "limitations": [
        "ActualNASSGazetteAct7/2025; section57currencyglyphanomaly, SecondSchedule3conjunctiveconditionsandparagraph9incomplete. No textualrepairorfilingclearance."
      ],
      "native_fragment_ids": [
        "N01744",
        "N01745",
        "N01746",
        "N01747",
        "N01748",
        "N01749",
        "N01750",
        "N01751",
        "N01752",
        "N01753",
        "N01754",
        "N01755",
        "N01756",
        "N01757",
        "N01758",
        "N01759",
        "N01760",
        "N01761",
        "N01762",
        "N01763",
        "N01764",
        "N01765",
        "N01766",
        "N01767",
        "N01768",
        "N01769",
        "N01770",
        "N01771",
        "N01772",
        "N01773",
        "N01774",
        "N01775",
        "N01776",
        "N01777",
        "N01778",
        "N01779",
        "N01780"
      ],
      "official_url": "https://nass.gov.ng/documents/download/11249",
      "own_read_date": "2026-11-16",
      "quote_id": "N01754",
      "read_scope": "Actual extracted lines 1645–1745, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [
        "Tax 57.—(1) The following shall apply for the purpose of determination the Rate effective tax rate under this section : (a) notwithstanding any provision of"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "nigeria-tax2025",
      "visual_proof": null
    },
    {
      "act_article": "Nigeria Tax Act Second Schedule paragraphs 1–10; original text anomalies retained",
      "block": "nigeria-tax2025:free-zone",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/nigeria-tax2025.txt",
      "capture_sha256": "f92f0c2c75dea152fdfa780d8a9972d44cbcf1f24f1d95085937787aeaf45ada",
      "limitations": [
        "ActualNASSGazetteAct7/2025; section57currencyglyphanomaly, SecondSchedule3conjunctiveconditionsandparagraph9incomplete. No textualrepairorfilingclearance."
      ],
      "native_fragment_ids": [
        "N01789",
        "N01790",
        "N01791",
        "N01792",
        "N01793",
        "N01794",
        "N01795",
        "N01796",
        "N01797",
        "N01798",
        "N01799",
        "N01800",
        "N01801",
        "N01802",
        "N01803",
        "N01804",
        "N01805",
        "N01806",
        "N01807",
        "N01808",
        "N01809",
        "N01810",
        "N01811",
        "N01812",
        "N01813",
        "N01814",
        "N01815",
        "N01816",
        "N01817",
        "N01818",
        "N01819",
        "N01820"
      ],
      "official_url": "https://nass.gov.ng/documents/download/11249",
      "own_read_date": "2026-11-16",
      "quote_id": "N01790",
      "read_scope": "Actual extracted lines 6195–6278, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "nigeria-tax2025",
      "visual_proof": null
    },
    {
      "act_article": "Nigeria Tax Act 2025 commencement provision",
      "block": "nigeria-tax2025:commencement",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/nigeria-tax2025.txt",
      "capture_sha256": "f92f0c2c75dea152fdfa780d8a9972d44cbcf1f24f1d95085937787aeaf45ada",
      "limitations": [
        "ActualNASSGazetteAct7/2025; section57currencyglyphanomaly, SecondSchedule3conjunctiveconditionsandparagraph9incomplete. No textualrepairorfilingclearance."
      ],
      "native_fragment_ids": [
        "N01781",
        "N01782",
        "N01783",
        "N01784",
        "N01785",
        "N01786",
        "N01787",
        "N01788"
      ],
      "official_url": "https://nass.gov.ng/documents/download/11249",
      "own_read_date": "2026-11-16",
      "quote_id": "N01784",
      "read_scope": "Actual extracted lines 305–330, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "nigeria-tax2025",
      "visual_proof": null
    }
  ],
  "old_lines": [
    192
  ],
  "section": "Africa, with Labuan separately identified as Malaysia",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0120

| Kenya EPZs / SEZs | The actual Income Tax Act Third Schedule 2(f)/(h) separates **non-commercial EPZ 10-year holiday, then 25% for the next 10 years**, from **SEZ 10% for the first 10 years and 15% for the next 10** (in words on the page). Commercial EPZ activities are excluded from that holiday; the Eleventh Schedule defines relevant trading/bulk-breaking/grading/repacking/labelling and contains return/payroll/WHT/related-manufacturing conditions. Finance Act 2026 section 21 does not amend those (f)/(h) rates. See the individual source request under Sources. [kenya-income2026](<https://www.kra.go.ke/images/publications/Income-Tax-Act-2026.pdf>); [kenya-finance2026](<https://www.kra.go.ke/images/publications/Finance-Act-2026.pdf>) |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    186,
    186
  ],
  "id": "R0120",
  "individual_subclaims": [
    {
      "bindings": [
        "kenya-income2026:rates",
        "kenya-income2026:EPZ",
        "kenya-finance2026:ThirdSchedule"
      ],
      "claim": "Kenya EPZs / SEZs",
      "id": "R0120.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "kenya-income2026:rates",
        "kenya-income2026:EPZ",
        "kenya-finance2026:ThirdSchedule"
      ],
      "claim": "The actual Income Tax Act Third Schedule 2(f)/(h) separates **non-commercial EPZ 10-year holiday, then 25% for the next 10 years**, from **SEZ 10% for the first 10 years and 15% for the next 10** (in words on the page). Commercial EPZ activities are excluded from that holiday; the Eleventh Schedule defines relevant trading/bulk-breaking/grading/repacking/labelling and contains return/payroll/WHT/related-manufacturing conditions. Finance Act 2026 section 21 does not amend those (f)/(h) rates. See the individual source request under Sources. [kenya-income2026](<https://www.kra.go.ke/images/publications/Income-Tax-Act-2026.pdf>); [kenya-finance2026](<https://www.kra.go.ke/images/publications/Finance-Act-2026.pdf>)",
      "id": "R0120.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "Income Tax Act Third Schedule 2(f)/(h)",
      "block": "kenya-income2026:rates",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/kenya-income2026.txt",
      "capture_sha256": "28a7dc8309187e91dd00c67268752881b8acbf28997b8c482ca565e051e2f8c4",
      "limitations": [
        "ActualKRA2026IncomeTaxActselectedThirdSchedule2(f)/(h)andentireEleventhSchedule1–9read; customswaiversnotcleared."
      ],
      "native_fragment_ids": [
        "N01821",
        "N01822",
        "N01823",
        "N01824",
        "N01825",
        "N01826",
        "N01827",
        "N01828",
        "N01829",
        "N01830",
        "N01831",
        "N01832",
        "N01833",
        "N01834",
        "N01835",
        "N01836",
        "N01837"
      ],
      "official_url": "https://www.kra.go.ke/images/publications/Income-Tax-Act-2026.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N01827",
      "read_scope": "Actual extracted lines 7570–7625, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [
        "commencing immediately thereafter: Provided that for purposes of this subparagraph, \"commercial activities\" includes trading in, breaking bulk, grading, repacking or relabelling of goods and industrial"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "kenya-income2026",
      "visual_proof": null
    },
    {
      "act_article": "Income Tax Act Eleventh Schedule paragraphs 1–9",
      "block": "kenya-income2026:EPZ",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/kenya-income2026.txt",
      "capture_sha256": "28a7dc8309187e91dd00c67268752881b8acbf28997b8c482ca565e051e2f8c4",
      "limitations": [
        "ActualKRA2026IncomeTaxActselectedThirdSchedule2(f)/(h)andentireEleventhSchedule1–9read; customswaiversnotcleared."
      ],
      "native_fragment_ids": [
        "N01838",
        "N01839",
        "N01840",
        "N01841",
        "N01842",
        "N01843",
        "N01844",
        "N01845",
        "N01846",
        "N01847",
        "N01848",
        "N01849",
        "N01850",
        "N01851",
        "N01852",
        "N01853",
        "N01854",
        "N01855",
        "N01856",
        "N01857",
        "N01858",
        "N01859",
        "N01860",
        "N01861",
        "N01862",
        "N01863"
      ],
      "official_url": "https://www.kra.go.ke/images/publications/Income-Tax-Act-2026.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N01843",
      "read_scope": "Actual extracted lines 9790–9865, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "kenya-income2026",
      "visual_proof": null
    },
    {
      "act_article": "Finance Act 2026 section 21",
      "block": "kenya-finance2026:ThirdSchedule",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/kenya-finance2026.txt",
      "capture_sha256": "9e2757d2e1a93d77cdc1a215de20c0a6e1f833c2e97f813c86d955b1acc025be",
      "limitations": [
        "Actualenacted2026Actsection21andcommencementread; noThirdSchedule2(f)/(h)amendmentthere. Otherunrelatedsectionsnotwhole-read."
      ],
      "native_fragment_ids": [
        "N01864",
        "N01865",
        "N01866",
        "N01867",
        "N01868",
        "N01869",
        "N01870"
      ],
      "official_url": "https://www.kra.go.ke/images/publications/Finance-Act-2026.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N01864",
      "read_scope": "Actual extracted lines 434–459, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [
        "21. Head B of the Third Schedule to the Income Tax Amendment of the Third Schedule to Act is amended- Cap.470. (a) in paragraph 2,"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "kenya-finance2026",
      "visual_proof": null
    }
  ],
  "old_lines": [
    193
  ],
  "section": "Africa, with Labuan separately identified as Malaysia",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0121

| South Africa SEZs | SARS’s 2026/27 overview states **27% ordinary CIT** and potential **15%** for qualifying approved-SEZ companies. See the individual source request under Sources. [sa-rates2026](<https://www.sars.gov.za/about/sars-tax-and-customs-system/budget/budget-2026-frequently-asked-questions/>) |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    187,
    187
  ],
  "id": "R0121",
  "individual_subclaims": [
    {
      "bindings": [
        "sa-rates2026:CIT"
      ],
      "claim": "South Africa SEZs",
      "id": "R0121.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "sa-rates2026:CIT"
      ],
      "claim": "SARS’s 2026/27 overview states **27% ordinary CIT** and potential **15%** for qualifying approved-SEZ companies. See the individual source request under Sources. [sa-rates2026](<https://www.sars.gov.za/about/sars-tax-and-customs-system/budget/budget-2026-frequently-asked-questions/>)",
      "id": "R0121.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "SARS 2026/27 FAQ corporate rate summary",
      "block": "sa-rates2026:CIT",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/sa-rates2026.txt",
      "capture_sha256": "fe299fef33f98cb65db20f186d1d6eb87e05582eb52659b350df983b56cf2f09",
      "limitations": [
        "ActualSARS2026FAQheadlineguidanceonly; completecurrent12Rstatute/legislativeproposalsnotcleared."
      ],
      "native_fragment_ids": [
        "N01871",
        "N01872",
        "N01873",
        "N01874",
        "N01875"
      ],
      "official_url": "https://www.sars.gov.za/about/sars-tax-and-customs-system/budget/budget-2026-frequently-asked-questions/",
      "own_read_date": "2026-11-16",
      "quote_id": "N01873",
      "read_scope": "Actual extracted lines 153–156, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [
        "to 27% in 2022/23. Companies in approved Special Economic Zones may qualify for a reduced rate of 15%, subject to the applicable requirements. Budget 2026"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "sa-rates2026",
      "visual_proof": null
    }
  ],
  "old_lines": [
    194
  ],
  "section": "Africa, with Labuan separately identified as Malaysia",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0122

| Botswana IFSC | BURS’s actual company overview lists **22% resident-company** and **15% IFSC/manufacturing** rates. See the individual source request under Sources. [botswana-companies](<https://www.burs.org.bw/index.php/tax/income-tax/companies>) |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    188,
    188
  ],
  "id": "R0122",
  "individual_subclaims": [
    {
      "bindings": [
        "botswana-companies:rates"
      ],
      "claim": "Botswana IFSC",
      "id": "R0122.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "botswana-companies:rates"
      ],
      "claim": "BURS’s actual company overview lists **22% resident-company** and **15% IFSC/manufacturing** rates. See the individual source request under Sources. [botswana-companies](<https://www.burs.org.bw/index.php/tax/income-tax/companies>)",
      "id": "R0122.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "BURS company-rate overview",
      "block": "botswana-companies:rates",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/botswana-companies.txt",
      "capture_sha256": "6ca87dc2fb2d0b28a17ba2e2811ea7eb0f5facee9e6e91b1c79bc9db4eb5b901",
      "limitations": [
        "ActualBURScompanyoverviewonly; current2026taxlawchange/IFSCcertificationdetailsnotcleared."
      ],
      "native_fragment_ids": [
        "N01876",
        "N01877",
        "N01878",
        "N01879",
        "N01880",
        "N01881",
        "N01882",
        "N01883",
        "N01884",
        "N01885",
        "N01886",
        "N01887",
        "N01888",
        "N01889",
        "N01890"
      ],
      "official_url": "https://www.burs.org.bw/index.php/tax/income-tax/companies",
      "own_read_date": "2026-11-16",
      "quote_id": "N01880",
      "read_scope": "Actual extracted lines 144–164, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [
        "22% for resident companies and 30% for non resident companies, except for; a) Approved manufacturing companies – 15% b) IFSC Companies – 15% and, c)"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "botswana-companies",
      "visual_proof": null
    }
  ],
  "old_lines": [
    195
  ],
  "section": "Africa, with Labuan separately identified as Malaysia",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0123

## Substance and economic-substance laws

```json
{
  "context_only_blocks": [],
  "current_lines": [
    190,
    190
  ],
  "id": "R0123",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "## Substance and economic-substance laws",
      "id": "R0123.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    197
  ],
  "section": "Substance and economic-substance laws",
  "source_read_record": null,
  "status": "heading"
}
```

### R0124

Use these as planning questions, not a universal five-part legal test. For each applicable regime obtain the actual place-of-CIGA, headcount/qualifications, outsourcing, expenditure, decision-making and records rules. A rented lab/office or periodic board meeting by itself proves no concession.

```json
{
  "context_only_blocks": [],
  "current_lines": [
    192,
    192
  ],
  "id": "R0124",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Use these as planning questions, not a universal five-part legal test.",
      "id": "R0124.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "For each applicable regime obtain the actual place-of-CIGA, headcount/qualifications, outsourcing, expenditure, decision-making and records rules.",
      "id": "R0124.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "A rented lab/office or periodic board meeting by itself proves no concession.",
      "id": "R0124.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    199,
    201,
    202
  ],
  "section": "Substance and economic-substance laws",
  "source_read_record": null,
  "status": "scope/workflow/refusal/protected disclaimer; no new statutory assertion"
}
```

### R0125

| Planning subject | Evidence to obtain, regime by regime |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    194,
    194
  ],
  "id": "R0125",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Planning subject",
      "id": "R0125.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Evidence to obtain, regime by regime",
      "id": "R0125.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    201
  ],
  "section": "Substance and economic-substance laws",
  "source_read_record": null,
  "status": "workflow/research question or table label; no current rule asserted"
}
```

### R0126

| --- | --- |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    195,
    195
  ],
  "id": "R0126",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "---",
      "id": "R0126.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "---",
      "id": "R0126.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    202
  ],
  "section": "Substance and economic-substance laws",
  "source_read_record": null,
  "status": "table separator"
}
```

### R0127

| Premises | Adequate assets/premises for the actual activity and the legally required location; distinguish UAE Free Zone/Designated Zone from any national office. [uae-100](<https://mof.gov.ae/wp-content/uploads/2023/11/Cabinet-Decision-No.-100-of-2023-on-Determining-Qualifying-Income-for-the-Qualifying-Free-Zone-Person.pdf>) |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    196,
    196
  ],
  "id": "R0127",
  "individual_subclaims": [
    {
      "bindings": [
        "uae-100:substance"
      ],
      "claim": "Premises",
      "id": "R0127.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-100:substance"
      ],
      "claim": "Adequate assets/premises for the actual activity and the legally required location; distinguish UAE Free Zone/Designated Zone from any national office. [uae-100](<https://mof.gov.ae/wp-content/uploads/2023/11/Cabinet-Decision-No.-100-of-2023-on-Determining-Qualifying-Income-for-the-Qualifying-Free-Zone-Person.pdf>)",
      "id": "R0127.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "CD 100/2023 Article 8",
      "block": "uae-100:substance",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/uae-100.txt",
      "capture_sha256": "ab4d1743e78d2c336d807b83fb336f668476878713a29fa68d5ca62f9cfaca73",
      "limitations": [
        "Ministry/FTA-hosted English law. January2026consolidation andMD229 explicitly not official English translations; Arabic original unread. No entity-specific licensing/application or unread cross-reference clearance."
      ],
      "native_fragment_ids": [
        "N00145",
        "N00146",
        "N00147",
        "N00148",
        "N00149",
        "N00150",
        "N00151",
        "N00152",
        "N00153",
        "N00154"
      ],
      "official_url": "https://mof.gov.ae/wp-content/uploads/2023/11/Cabinet-Decision-No.-100-of-2023-on-Determining-Qualifying-Income-for-the-Qualifying-Free-Zone-Person.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00152",
      "read_scope": "Actual extracted lines 195–218, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "uae-100",
      "visual_proof": null
    }
  ],
  "old_lines": [
    203
  ],
  "section": "Substance and economic-substance laws",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0128

| Employees | Actual count, qualifications, work location and CIGA; identify named personnel in the client brief. Outsourced work is acceptable only under the relevant law’s conditions. [uae-100](<https://mof.gov.ae/wp-content/uploads/2023/11/Cabinet-Decision-No.-100-of-2023-on-Determining-Qualifying-Income-for-the-Qualifying-Free-Zone-Person.pdf>) |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    197,
    197
  ],
  "id": "R0128",
  "individual_subclaims": [
    {
      "bindings": [
        "uae-100:substance"
      ],
      "claim": "Employees",
      "id": "R0128.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-100:substance"
      ],
      "claim": "Actual count, qualifications, work location and CIGA; identify named personnel in the client brief. Outsourced work is acceptable only under the relevant law’s conditions. [uae-100](<https://mof.gov.ae/wp-content/uploads/2023/11/Cabinet-Decision-No.-100-of-2023-on-Determining-Qualifying-Income-for-the-Qualifying-Free-Zone-Person.pdf>)",
      "id": "R0128.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "CD 100/2023 Article 8",
      "block": "uae-100:substance",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/uae-100.txt",
      "capture_sha256": "ab4d1743e78d2c336d807b83fb336f668476878713a29fa68d5ca62f9cfaca73",
      "limitations": [
        "Ministry/FTA-hosted English law. January2026consolidation andMD229 explicitly not official English translations; Arabic original unread. No entity-specific licensing/application or unread cross-reference clearance."
      ],
      "native_fragment_ids": [
        "N00145",
        "N00146",
        "N00147",
        "N00148",
        "N00149",
        "N00150",
        "N00151",
        "N00152",
        "N00153",
        "N00154"
      ],
      "official_url": "https://mof.gov.ae/wp-content/uploads/2023/11/Cabinet-Decision-No.-100-of-2023-on-Determining-Qualifying-Income-for-the-Qualifying-Free-Zone-Person.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00152",
      "read_scope": "Actual extracted lines 195–218, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "uae-100",
      "visual_proof": null
    }
  ],
  "old_lines": [
    204
  ],
  "section": "Substance and economic-substance laws",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0129

| Operating expenditure | Incurred amount, activity nexus and permitted location/outsourcing supervision. Do not substitute an arbitrary minimum from another regime. [uae-100](<https://mof.gov.ae/wp-content/uploads/2023/11/Cabinet-Decision-No.-100-of-2023-on-Determining-Qualifying-Income-for-the-Qualifying-Free-Zone-Person.pdf>) |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    198,
    198
  ],
  "id": "R0129",
  "individual_subclaims": [
    {
      "bindings": [
        "uae-100:substance"
      ],
      "claim": "Operating expenditure",
      "id": "R0129.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-100:substance"
      ],
      "claim": "Incurred amount, activity nexus and permitted location/outsourcing supervision. Do not substitute an arbitrary minimum from another regime. [uae-100](<https://mof.gov.ae/wp-content/uploads/2023/11/Cabinet-Decision-No.-100-of-2023-on-Determining-Qualifying-Income-for-the-Qualifying-Free-Zone-Person.pdf>)",
      "id": "R0129.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "CD 100/2023 Article 8",
      "block": "uae-100:substance",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/uae-100.txt",
      "capture_sha256": "ab4d1743e78d2c336d807b83fb336f668476878713a29fa68d5ca62f9cfaca73",
      "limitations": [
        "Ministry/FTA-hosted English law. January2026consolidation andMD229 explicitly not official English translations; Arabic original unread. No entity-specific licensing/application or unread cross-reference clearance."
      ],
      "native_fragment_ids": [
        "N00145",
        "N00146",
        "N00147",
        "N00148",
        "N00149",
        "N00150",
        "N00151",
        "N00152",
        "N00153",
        "N00154"
      ],
      "official_url": "https://mof.gov.ae/wp-content/uploads/2023/11/Cabinet-Decision-No.-100-of-2023-on-Determining-Qualifying-Income-for-the-Qualifying-Free-Zone-Person.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00152",
      "read_scope": "Actual extracted lines 195–218, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "uae-100",
      "visual_proof": null
    }
  ],
  "old_lines": [
    205
  ],
  "section": "Substance and economic-substance laws",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0130

| Decision-making | Record board meetings, strategic decisions, actual control and key-person residence as research inputs; neither local board meetings nor resident directors are asserted universally mandatory. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    199,
    199
  ],
  "id": "R0130",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Decision-making",
      "id": "R0130.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Record board meetings, strategic decisions, actual control and key-person residence as research inputs; neither local board meetings nor resident directors are asserted universally mandatory.",
      "id": "R0130.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    206
  ],
  "section": "Substance and economic-substance laws",
  "source_read_record": null,
  "status": "workflow/research question or table label; no current rule asserted"
}
```

### R0131

| Records | Establish the required location, retention, regulator availability and income/activity evidence. “Maintained in-zone” is not proved for every jurisdiction. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    200,
    200
  ],
  "id": "R0131",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Records",
      "id": "R0131.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Establish the required location, retention, regulator availability and income/activity evidence. “Maintained in-zone” is not proved for every jurisdiction.",
      "id": "R0131.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    207
  ],
  "section": "Substance and economic-substance laws",
  "source_read_record": null,
  "status": "workflow/research question or table label; no current rule asserted"
}
```

### R0132

The original relevant-activity list remains a checklist: **banking, distribution, headquarters, finance/leasing, fund management, holding, IP, insurance and shipping**.

```json
{
  "context_only_blocks": [],
  "current_lines": [
    202,
    202
  ],
  "id": "R0132",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "The original relevant-activity list remains a checklist: **banking, distribution, headquarters, finance/leasing, fund management, holding, IP, insurance and shipping**.",
      "id": "R0132.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    209
  ],
  "section": "Substance and economic-substance laws",
  "source_read_record": null,
  "status": "scope/workflow/refusal/protected disclaimer; no new statutory assertion"
}
```

### R0133

OECD FHTP covers preferential regimes, transparency and substantial activities in no/nominal-tax jurisdictions; it is not an “approved free-zone list”. The actual 2026 OECD page identifies substantial-activity information exchange, including beneficial-owner and immediate/ultimate-parent jurisdictions, and a **July 2026** regime-results update. [oecd-harmful](<https://www.oecd.org/en/topics/harmful-tax-practices.html>).

```json
{
  "context_only_blocks": [],
  "current_lines": [
    204,
    204
  ],
  "id": "R0133",
  "individual_subclaims": [
    {
      "bindings": [
        "oecd-harmful:overview"
      ],
      "claim": "OECD FHTP covers preferential regimes, transparency and substantial activities in no/nominal-tax jurisdictions",
      "id": "R0133.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "oecd-harmful:overview"
      ],
      "claim": "it is not an “approved free-zone list”.",
      "id": "R0133.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "oecd-harmful:overview"
      ],
      "claim": "The actual 2026 OECD page identifies substantial-activity information exchange, including beneficial-owner and immediate/ultimate-parent jurisdictions, and a **July 2026** regime-results update. [oecd-harmful](<https://www.oecd.org/en/topics/harmful-tax-practices.html>).",
      "id": "R0133.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "OECD harmful-tax-practices selected overview",
      "block": "oecd-harmful:overview",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/oecd-harmful-native-excerpts.txt",
      "capture_sha256": "451c87f22964cd601fc587c6e4bc1e88f97ed1af9659d54449cf0f4eb121ea13",
      "limitations": [
        "Selectedactualoverviewread; individualFHTPoutcomes/nationalESAstatutesnotcleared. Shortsource-nativeextracts, noapprovedzonelistinferred.",
        "Only tool Lnn locators and citation wrappers removed, retaining visible anchor text; raw response immutable."
      ],
      "native_fragment_ids": [
        "N02249",
        "N02250",
        "N02251",
        "N02252"
      ],
      "official_url": "https://www.oecd.org/en/topics/harmful-tax-practices.html",
      "own_read_date": "2026-11-16",
      "quote_id": "N02252",
      "read_scope": "Actual official web lines 3738–3741, personally read with immediate qualifications.",
      "short_exact_native_quote": [
        "immediate and ultimate parent and the beneficial owners"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "oecd-harmful",
      "visual_proof": null
    }
  ],
  "old_lines": [
    26,
    39,
    209,
    245,
    258
  ],
  "section": "Substance and economic-substance laws",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0134

## Pillar Two interaction

```json
{
  "context_only_blocks": [],
  "current_lines": [
    206,
    206
  ],
  "id": "R0134",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "## Pillar Two interaction",
      "id": "R0134.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    211,
    215
  ],
  "section": "Pillar Two interaction",
  "source_read_record": null,
  "status": "heading"
}
```

### R0135

A below-**15%** headline is not a complete GloBE test. Establish the MNE group’s consolidated revenue, normally **EUR 750 million in at least 2 of the prior 4 fiscal years**, covered/excluded entities and domestic law; compute jurisdictional adjusted covered taxes/income with applicable exclusions, substance-based income exclusion, elections and safe harbours. Consider domestic minimum tax first and foreign IIR/UTPR in their legal order. A tax benefit is not necessarily “clawed back in full”. Route detailed computation to `pillar-two-globe-minimum-tax.md` and current national law. [uae-142](<https://tax.gov.ae/Datafolder/Files/Legislation/Cabinet-Decision-No-142-of-2024-on-Top-up-Tax-on-MNEs.pdf>); [oecd-global](<https://www.oecd.org/en/topics/global-minimum-tax.html>).

```json
{
  "context_only_blocks": [],
  "current_lines": [
    208,
    208
  ],
  "id": "R0135",
  "individual_subclaims": [
    {
      "bindings": [
        "uae-142:scope",
        "oecd-global:overview"
      ],
      "claim": "A below-**15%** headline is not a complete GloBE test.",
      "id": "R0135.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-142:scope",
        "oecd-global:overview"
      ],
      "claim": "Establish the MNE group’s consolidated revenue, normally **EUR 750 million in at least 2 of the prior 4 fiscal years**, covered/excluded entities and domestic law",
      "id": "R0135.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-142:scope",
        "oecd-global:overview"
      ],
      "claim": "compute jurisdictional adjusted covered taxes/income with applicable exclusions, substance-based income exclusion, elections and safe harbours.",
      "id": "R0135.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-142:scope",
        "oecd-global:overview"
      ],
      "claim": "Consider domestic minimum tax first and foreign IIR/UTPR in their legal order.",
      "id": "R0135.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-142:scope",
        "oecd-global:overview"
      ],
      "claim": "A tax benefit is not necessarily “clawed back in full”.",
      "id": "R0135.5",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-142:scope",
        "oecd-global:overview"
      ],
      "claim": "Route detailed computation to `pillar-two-globe-minimum-tax.md` and current national law. [uae-142](<https://tax.gov.ae/Datafolder/Files/Legislation/Cabinet-Decision-No-142-of-2024-on-Top-up-Tax-on-MNEs.pdf>)",
      "id": "R0135.6",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-142:scope",
        "oecd-global:overview"
      ],
      "claim": "[oecd-global](<https://www.oecd.org/en/topics/global-minimum-tax.html>).",
      "id": "R0135.7",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "CD 142/2024 Articles 1–3; Annex 1.1–1.5 with neighboring 1.6",
      "block": "uae-142:scope",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/uae-142.txt",
      "capture_sha256": "0bf87c650114188a0fca64ad2c614d1b8ef73bbfaf76139539a48b10120b7a86",
      "limitations": [
        "Ministry/FTA-hosted English law. January2026consolidation andMD229 explicitly not official English translations; Arabic original unread. No entity-specific licensing/application or unread cross-reference clearance."
      ],
      "native_fragment_ids": [
        "N00257",
        "N00258",
        "N00259",
        "N00260",
        "N00261",
        "N00262",
        "N00263",
        "N00264",
        "N00265",
        "N00266",
        "N00267",
        "N00268",
        "N00269",
        "N00270",
        "N00271",
        "N00272",
        "N00273",
        "N00274",
        "N00275",
        "N00276",
        "N00277",
        "N00278",
        "N00279",
        "N00280",
        "N00281",
        "N00282",
        "N00283",
        "N00284",
        "N00285",
        "N00286",
        "N00287",
        "N00288",
        "N00289",
        "N00290",
        "N00291",
        "N00292",
        "N00293",
        "N00294",
        "N00295",
        "N00296",
        "N00297",
        "N00298",
        "N00299",
        "N00300",
        "N00301"
      ],
      "official_url": "https://tax.gov.ae/Datafolder/Files/Legislation/Cabinet-Decision-No-142-of-2024-on-Top-up-Tax-on-MNEs.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00289",
      "read_scope": "Actual extracted lines 1–130, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [
        "the Excluded Entity or Entities. Cabinet Decision No. 142 of 2024 – As published in the Official Gazette 3 (b) where at least 85% of"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "uae-142",
      "visual_proof": null
    },
    {
      "act_article": "OECD global-minimum-tax selected overview",
      "block": "oecd-global:overview",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/oecd-global-native-excerpts.txt",
      "capture_sha256": "fcc245ec5302be8c7e27f4af5d45aa913ec7cb93796b1a18e2f6c06c775aadd0",
      "limitations": [
        "Selectedactualoverviewparagraphsread; legislative template, notdomesticlaw. Fullmodel/administrativeguidancenotread. Shortsource-nativeextractsinledger, notfullsitequotation.",
        "Only tool Lnn locators and citation wrappers removed, retaining visible anchor text; raw response immutable."
      ],
      "native_fragment_ids": [
        "N02245",
        "N02246",
        "N02247",
        "N02248"
      ],
      "official_url": "https://www.oecd.org/en/topics/global-minimum-tax.html",
      "own_read_date": "2026-11-16",
      "quote_id": "N02247",
      "read_scope": "Actual official web lines 3749–3771, personally read with immediate qualifications.",
      "short_exact_native_quote": [
        "after deducting a substance-based income exclusion"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "oecd-global",
      "visual_proof": null
    }
  ],
  "old_lines": [
    213,
    239,
    249,
    261
  ],
  "section": "Pillar Two interaction",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0136

OECD’s **January 2026 Side-by-Side package** adds relevant elections/safe-harbour and incentive issues while preserving QDMTT primacy. These are implementation/eligibility questions, not a universal exemption for a zone or for every group in a named country. Only the read introductory package paragraphs are used here; full safe-harbour/calculation clearance is not supplied. [oecd-sbs2026](<https://www.oecd.org/content/dam/oecd/en/topics/policy-sub-issues/global-minimum-tax/side-by-side-package.pdf>).

```json
{
  "context_only_blocks": [],
  "current_lines": [
    210,
    210
  ],
  "id": "R0136",
  "individual_subclaims": [
    {
      "bindings": [
        "oecd-sbs2026:intro"
      ],
      "claim": "OECD’s **January 2026 Side-by-Side package** adds relevant elections/safe-harbour and incentive issues while preserving QDMTT primacy.",
      "id": "R0136.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "oecd-sbs2026:intro"
      ],
      "claim": "These are implementation/eligibility questions, not a universal exemption for a zone or for every group in a named country.",
      "id": "R0136.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "oecd-sbs2026:intro"
      ],
      "claim": "Only the read introductory package paragraphs are used here",
      "id": "R0136.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "oecd-sbs2026:intro"
      ],
      "claim": "full safe-harbour/calculation clearance is not supplied. [oecd-sbs2026](<https://www.oecd.org/content/dam/oecd/en/topics/policy-sub-issues/global-minimum-tax/side-by-side-package.pdf>).",
      "id": "R0136.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "OECD Side-by-Side package pages 1–9, paragraphs 1–26 only",
      "block": "oecd-sbs2026:intro",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/oecd-sbs2026.txt",
      "capture_sha256": "ac71823d0a3958c2d5d1f4996b0c278b8041cc5480a1d8cd32faca5f3e563237",
      "limitations": [
        "OECD2026Side-by-SidePackageCCBY4.0coverlicenseread; actualpp1–9paragraphs1–26read, remaining79pagesretrievalonly. AttributionOECD2026; excerptisnotOECDendorsement."
      ],
      "native_fragment_ids": [
        "N01949",
        "N01950",
        "N01951",
        "N01952",
        "N01953",
        "N01954",
        "N01955",
        "N01956",
        "N01957",
        "N01958",
        "N01959",
        "N01960",
        "N01961",
        "N01962",
        "N01963",
        "N01964",
        "N01965",
        "N01966",
        "N01967",
        "N01968",
        "N01969",
        "N01970",
        "N01971",
        "N01972",
        "N01973",
        "N01974",
        "N01975",
        "N01976",
        "N01977",
        "N01978",
        "N01979",
        "N01980",
        "N01981",
        "N01982",
        "N01983",
        "N01984",
        "N01985",
        "N01986",
        "N01987",
        "N01988",
        "N01989",
        "N01990",
        "N01991",
        "N01992",
        "N01993",
        "N01994",
        "N01995",
        "N01996",
        "N01997",
        "N01998",
        "N01999",
        "N02000",
        "N02001",
        "N02002",
        "N02003",
        "N02004",
        "N02005",
        "N02006",
        "N02007",
        "N02008",
        "N02009",
        "N02010",
        "N02011",
        "N02012",
        "N02013",
        "N02014",
        "N02015",
        "N02016",
        "N02017",
        "N02018",
        "N02019",
        "N02020",
        "N02021",
        "N02022",
        "N02023",
        "N02024",
        "N02025",
        "N02026",
        "N02027",
        "N02028",
        "N02029",
        "N02030",
        "N02031",
        "N02032",
        "N02033",
        "N02034",
        "N02035",
        "N02036",
        "N02037",
        "N02038",
        "N02039",
        "N02040",
        "N02041",
        "N02042",
        "N02043",
        "N02044",
        "N02045",
        "N02046",
        "N02047",
        "N02048",
        "N02049",
        "N02050",
        "N02051",
        "N02052",
        "N02053",
        "N02054",
        "N02055",
        "N02056",
        "N02057",
        "N02058",
        "N02059",
        "N02060",
        "N02061",
        "N02062",
        "N02063"
      ],
      "official_url": "https://www.oecd.org/content/dam/oecd/en/topics/policy-sub-issues/global-minimum-tax/side-by-side-package.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N01972",
      "read_scope": "Actual extracted lines 113–367, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [
        "THE ECONOMY – GLOBAL ANTI-BASE EROSION MODEL RULES (PILLAR TWO), SIDE-BY-SIDE PACKAGE © OECD 2026 5 Side-by-Side Package 5. This document on the Side-by-Side package"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "oecd-sbs2026",
      "visual_proof": null
    }
  ],
  "old_lines": [
    213
  ],
  "section": "Pillar Two interaction",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0137

| Zone family | Minimum-tax rule or individual source gap |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    212,
    212
  ],
  "id": "R0137",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Zone family",
      "id": "R0137.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Minimum-tax rule or individual source gap",
      "id": "R0137.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    217
  ],
  "section": "Pillar Two interaction",
  "source_read_record": null,
  "status": "workflow/research question or table label; no current rule asserted"
}
```

### R0138

| --- | --- |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    213,
    213
  ],
  "id": "R0138",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "---",
      "id": "R0138.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "---",
      "id": "R0138.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    218
  ],
  "section": "Pillar Two interaction",
  "source_read_record": null,
  "status": "table separator"
}
```

### R0139

| UAE | Cabinet Decision 142/2024 Articles 2–3 apply the domestic top-up-tax rules to fiscal years beginning on or after **1 January 2025**, with the **750 million /2-of-4** scope test and excluded-entity provisions. See the individual source request under Sources. [uae-142](<https://tax.gov.ae/Datafolder/Files/Legislation/Cabinet-Decision-No-142-of-2024-on-Top-up-Tax-on-MNEs.pdf>) |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    214,
    214
  ],
  "id": "R0139",
  "individual_subclaims": [
    {
      "bindings": [
        "uae-142:scope"
      ],
      "claim": "UAE",
      "id": "R0139.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-142:scope"
      ],
      "claim": "Cabinet Decision 142/2024 Articles 2–3 apply the domestic top-up-tax rules to fiscal years beginning on or after **1 January 2025**, with the **750 million /2-of-4** scope test and excluded-entity provisions. See the individual source request under Sources. [uae-142](<https://tax.gov.ae/Datafolder/Files/Legislation/Cabinet-Decision-No-142-of-2024-on-Top-up-Tax-on-MNEs.pdf>)",
      "id": "R0139.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "CD 142/2024 Articles 1–3; Annex 1.1–1.5 with neighboring 1.6",
      "block": "uae-142:scope",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/uae-142.txt",
      "capture_sha256": "0bf87c650114188a0fca64ad2c614d1b8ef73bbfaf76139539a48b10120b7a86",
      "limitations": [
        "Ministry/FTA-hosted English law. January2026consolidation andMD229 explicitly not official English translations; Arabic original unread. No entity-specific licensing/application or unread cross-reference clearance."
      ],
      "native_fragment_ids": [
        "N00257",
        "N00258",
        "N00259",
        "N00260",
        "N00261",
        "N00262",
        "N00263",
        "N00264",
        "N00265",
        "N00266",
        "N00267",
        "N00268",
        "N00269",
        "N00270",
        "N00271",
        "N00272",
        "N00273",
        "N00274",
        "N00275",
        "N00276",
        "N00277",
        "N00278",
        "N00279",
        "N00280",
        "N00281",
        "N00282",
        "N00283",
        "N00284",
        "N00285",
        "N00286",
        "N00287",
        "N00288",
        "N00289",
        "N00290",
        "N00291",
        "N00292",
        "N00293",
        "N00294",
        "N00295",
        "N00296",
        "N00297",
        "N00298",
        "N00299",
        "N00300",
        "N00301"
      ],
      "official_url": "https://tax.gov.ae/Datafolder/Files/Legislation/Cabinet-Decision-No-142-of-2024-on-Top-up-Tax-on-MNEs.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00263",
      "read_scope": "Actual extracted lines 1–130, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "uae-142",
      "visual_proof": null
    }
  ],
  "old_lines": [
    219
  ],
  "section": "Pillar Two interaction",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0140

| Bermuda | The 15% ordinary corporate-tax charge for covered 2025 periods is supported above. It is not by itself a certified QDMTT or a guarantee of 15% GloBE ETR. Verify the 2026 amendment and group computation. [bermuda-cit](<https://www.bermudalaws.bm/Laws/Annual%20Law/Acts/2023/Corporate%20Income%20Tax%20Act%202023>) |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    215,
    215
  ],
  "id": "R0140",
  "individual_subclaims": [
    {
      "bindings": [
        "bermuda-cit:rate",
        "bermuda-cit:scope",
        "bermuda-cit:commencement"
      ],
      "claim": "Bermuda",
      "id": "R0140.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "bermuda-cit:rate",
        "bermuda-cit:scope",
        "bermuda-cit:commencement"
      ],
      "claim": "The 15% ordinary corporate-tax charge for covered 2025 periods is supported above. It is not by itself a certified QDMTT or a guarantee of 15% GloBE ETR. Verify the 2026 amendment and group computation. [bermuda-cit](<https://www.bermudalaws.bm/Laws/Annual%20Law/Acts/2023/Corporate%20Income%20Tax%20Act%202023>)",
      "id": "R0140.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "Corporate Income Tax Act 2023 sections 4–5",
      "block": "bermuda-cit:rate",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/bermuda-cit.txt",
      "capture_sha256": "a738262d39f906de87b9f5ecfacab7656094bb3cabbb17eda7ae6e63c1be8168",
      "limitations": [
        "ActualActconsolidation through2025:12; later2026amendmentidentified but notread, entity/currentcalculationclearanceexplicitlyreserved."
      ],
      "native_fragment_ids": [
        "N01030",
        "N01031",
        "N01032",
        "N01033",
        "N01034",
        "N01035",
        "N01036",
        "N01037",
        "N01038",
        "N01039",
        "N01040",
        "N01041",
        "N01042",
        "N01043"
      ],
      "official_url": "https://www.bermudalaws.bm/Laws/Annual%20Law/Acts/2023/Corporate%20Income%20Tax%20Act%202023",
      "own_read_date": "2026-11-16",
      "quote_id": "N01034",
      "read_scope": "Actual extracted lines 1000–1048, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "bermuda-cit",
      "visual_proof": null
    },
    {
      "act_article": "Corporate Income Tax Act 2023 sections 9–11",
      "block": "bermuda-cit:scope",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/bermuda-cit.txt",
      "capture_sha256": "a738262d39f906de87b9f5ecfacab7656094bb3cabbb17eda7ae6e63c1be8168",
      "limitations": [
        "ActualActconsolidation through2025:12; later2026amendmentidentified but notread, entity/currentcalculationclearanceexplicitlyreserved."
      ],
      "native_fragment_ids": [
        "N01044",
        "N01045",
        "N01046",
        "N01047",
        "N01048",
        "N01049",
        "N01050",
        "N01051",
        "N01052",
        "N01053",
        "N01054",
        "N01055",
        "N01056",
        "N01057",
        "N01058",
        "N01059",
        "N01060",
        "N01061",
        "N01062",
        "N01063",
        "N01064",
        "N01065",
        "N01066",
        "N01067",
        "N01068",
        "N01069",
        "N01070",
        "N01071",
        "N01072",
        "N01073",
        "N01074",
        "N01075",
        "N01076",
        "N01077",
        "N01078",
        "N01079",
        "N01080",
        "N01081",
        "N01082",
        "N01083",
        "N01084",
        "N01085",
        "N01086",
        "N01087",
        "N01088",
        "N01089",
        "N01090"
      ],
      "official_url": "https://www.bermudalaws.bm/Laws/Annual%20Law/Acts/2023/Corporate%20Income%20Tax%20Act%202023",
      "own_read_date": "2026-11-16",
      "quote_id": "N01044",
      "read_scope": "Actual extracted lines 1223–1353, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "bermuda-cit",
      "visual_proof": null
    },
    {
      "act_article": "Corporate Income Tax Act 2023 section 53",
      "block": "bermuda-cit:commencement",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/bermuda-cit.txt",
      "capture_sha256": "a738262d39f906de87b9f5ecfacab7656094bb3cabbb17eda7ae6e63c1be8168",
      "limitations": [
        "ActualActconsolidation through2025:12; later2026amendmentidentified but notread, entity/currentcalculationclearanceexplicitlyreserved."
      ],
      "native_fragment_ids": [
        "N01091",
        "N01092",
        "N01093",
        "N01094",
        "N01095",
        "N01096"
      ],
      "official_url": "https://www.bermudalaws.bm/Laws/Annual%20Law/Acts/2023/Corporate%20Income%20Tax%20Act%202023",
      "own_read_date": "2026-11-16",
      "quote_id": "N01091",
      "read_scope": "Actual extracted lines 2955–2985, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "bermuda-cit",
      "visual_proof": null
    }
  ],
  "old_lines": [
    220
  ],
  "section": "Pillar Two interaction",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0141

| Bahamas | Use the enacted DMTT with section 1(2)’s **conditional initial 2024 year**, not an unconditional 2024 charge. The 2026 amendment is adopted; entity scope and complete GloBE calculation/elections remain separate. [bahamas-law2024](<https://laws.bahamas.gov.bs/cms/images/LEGISLATION/PRINCIPAL/2024/2024-0058/2024-0058_1.pdf>); [bahamas-amend2026](<https://laws.bahamas.gov.bs/cms/images/LEGISLATION/AMENDING/2026/2026-0025A/2026-0025A.pdf>) |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    216,
    216
  ],
  "id": "R0141",
  "individual_subclaims": [
    {
      "bindings": [
        "bahamas-law2024:sections1-5",
        "bahamas-amend2026:whole"
      ],
      "claim": "Bahamas",
      "id": "R0141.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "bahamas-law2024:sections1-5",
        "bahamas-amend2026:whole"
      ],
      "claim": "Use the enacted DMTT with section 1(2)’s **conditional initial 2024 year**, not an unconditional 2024 charge. The 2026 amendment is adopted; entity scope and complete GloBE calculation/elections remain separate. [bahamas-law2024](<https://laws.bahamas.gov.bs/cms/images/LEGISLATION/PRINCIPAL/2024/2024-0058/2024-0058_1.pdf>); [bahamas-amend2026](<https://laws.bahamas.gov.bs/cms/images/LEGISLATION/AMENDING/2026/2026-0025A/2026-0025A.pdf>)",
      "id": "R0141.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "Act 58/2024 sections 1(2),3(1),4(1)/(5),5(1)/(2), visual passages",
      "block": "bahamas-law2024:sections1-5",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/bahamas-base-visual-native.txt",
      "capture_sha256": "900a9fa24b32fdaadd4c167978ac59d6155aaaf9ed582ae7247a85ddde0ad55e",
      "limitations": [
        "ActualofficialGazettePDF; text layer duplicates/interleaves. Physicalpages4–8(printed3–7)personallyvisuallyread; below selectednative transcription checked against images."
      ],
      "native_fragment_ids": [
        "N01162",
        "N01163",
        "N01164",
        "N01165",
        "N01166",
        "N01167",
        "N01168",
        "N01169",
        "N01170",
        "N01171",
        "N01172",
        "N01173",
        "N01174"
      ],
      "official_url": "https://laws.bahamas.gov.bs/cms/images/LEGISLATION/PRINCIPAL/2024/2024-0058/2024-0058_1.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N01172",
      "read_scope": "Selectedcomplete1(2),3(1),4(1)/(5),5(1)/(2)nativepassagespersonallytranscribed/checkedagainstactualPDFphysical4–8;entireprinted3–7readvisuallywithallneighboringexceptions.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "bahamas-law2024",
      "visual_proof": null
    },
    {
      "act_article": "Act 2026-0025A sections 1–7",
      "block": "bahamas-amend2026:whole",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/bahamas-amend2026.txt",
      "capture_sha256": "80186796590f7c6f54a31666fe32465b63f788f704a66b16715d6a7309862be2",
      "limitations": [
        "Actualofficial2026-0025APDFwholeoperative1–7read; text duplicate/interleaving retainedraw, not complete underlyingGloBEcalculations."
      ],
      "native_fragment_ids": [
        "N01175",
        "N01176",
        "N01177",
        "N01178",
        "N01179",
        "N01180",
        "N01181",
        "N01182",
        "N01183",
        "N01184",
        "N01185",
        "N01186",
        "N01187",
        "N01188",
        "N01189",
        "N01190",
        "N01191",
        "N01192",
        "N01193",
        "N01194",
        "N01195",
        "N01196",
        "N01197",
        "N01198",
        "N01199",
        "N01200",
        "N01201",
        "N01202",
        "N01203",
        "N01204",
        "N01205",
        "N01206",
        "N01207",
        "N01208",
        "N01209",
        "N01210",
        "N01211",
        "N01212",
        "N01213",
        "N01214",
        "N01215",
        "N01216",
        "N01217",
        "N01218",
        "N01219",
        "N01220",
        "N01221",
        "N01222",
        "N01223",
        "N01224",
        "N01225"
      ],
      "official_url": "https://laws.bahamas.gov.bs/cms/images/LEGISLATION/AMENDING/2026/2026-0025A/2026-0025A.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N01182",
      "read_scope": "Actual extracted lines 1–159, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "bahamas-amend2026",
      "visual_proof": null
    }
  ],
  "old_lines": [
    221
  ],
  "section": "Pillar Two interaction",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0142

| Cayman | See the individual source request under Sources. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    217,
    217
  ],
  "id": "R0142",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Cayman",
      "id": "R0142.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "See the individual source request under Sources.",
      "id": "R0142.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    222
  ],
  "section": "Pillar Two interaction",
  "source_read_record": null,
  "status": "workflow/research question or table label; no current rule asserted"
}
```

### R0143

| Saudi SEZs | See the individual source request under Sources. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    218,
    218
  ],
  "id": "R0143",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Saudi SEZs",
      "id": "R0143.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "See the individual source request under Sources.",
      "id": "R0143.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    223
  ],
  "section": "Pillar Two interaction",
  "source_read_record": null,
  "status": "workflow/research question or table label; no current rule asserted"
}
```

### R0144

| Hong Kong | Actual Ordinance 2025 section 26AE charges IIR and HKMTT for fiscal years beginning on/after **1 January 2025**; UTPR needs a separately appointed date. Scope is at least **EUR 750 million in 2 of 4 prior fiscal years**, with schedules/exclusions/safe harbours. See the individual source request under Sources. [hk-p2-act2025](<https://www.ird.gov.hk/eng/pdf/es12025292321.pdf>) |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    219,
    219
  ],
  "id": "R0144",
  "individual_subclaims": [
    {
      "bindings": [
        "hk-p2-act2025:charge-dates"
      ],
      "claim": "Hong Kong",
      "id": "R0144.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "hk-p2-act2025:charge-dates"
      ],
      "claim": "Actual Ordinance 2025 section 26AE charges IIR and HKMTT for fiscal years beginning on/after **1 January 2025**; UTPR needs a separately appointed date. Scope is at least **EUR 750 million in 2 of 4 prior fiscal years**, with schedules/exclusions/safe harbours. See the individual source request under Sources. [hk-p2-act2025](<https://www.ird.gov.hk/eng/pdf/es12025292321.pdf>)",
      "id": "R0144.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "IRO sections 26AE–26AF enacted by 2025 amendment",
      "block": "hk-p2-act2025:charge-dates",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/hk-p2-act2025-reading-order.txt",
      "capture_sha256": "fae66b4fe8de4bd3ac3efb6433ae5fa65e63a6ee7761f117720605ff4ea18496",
      "limitations": [
        "Actual2025amendingOrdinance26AE/26AFselectedread; remainingSchedulesandlaterUTPRappointeddate/full2026calculationnotcleared."
      ],
      "native_fragment_ids": [
        "N02064",
        "N02065",
        "N02066",
        "N02067",
        "N02068",
        "N02069",
        "N02070",
        "N02071",
        "N02072",
        "N02073",
        "N02074",
        "N02075",
        "N02076",
        "N02077",
        "N02078",
        "N02079",
        "N02080",
        "N02081",
        "N02082",
        "N02083",
        "N02084",
        "N02085",
        "N02086",
        "N02087",
        "N02088",
        "N02089",
        "N02090",
        "N02091",
        "N02092",
        "N02093",
        "N02094",
        "N02095"
      ],
      "official_url": "https://www.ird.gov.hk/eng/pdf/es12025292321.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N02084",
      "read_scope": "Actual extracted lines 1173–1290, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [
        "(8) The HKMTT is payable in relation to a fiscal year beginning on or after 1 January 2025. 26AF. Consistency with the OECD GloBE rules"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "hk-p2-act2025",
      "visual_proof": null
    }
  ],
  "old_lines": [
    224
  ],
  "section": "Pillar Two interaction",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0145

| Singapore | IRAS’s actual current guidance states IIR and DTT from fiscal years beginning **1 January 2025**, with the **750 million /2-of-4** scope test and no adopted UTPR in that guidance. Its 2026 update addresses Side-by-Side/SBTI and the Simplified ETR safe harbour from **31 December 2026**. See the individual source request under Sources. [sg-p2-iras](<https://www.iras.gov.sg/taxes/pillar-2-top-up-taxes/global-anti-base-erosion-%28globe%29-rules-and-domestic-top-up-tax-%28dtt%29>) |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    220,
    220
  ],
  "id": "R0145",
  "individual_subclaims": [
    {
      "bindings": [
        "sg-p2-iras:body"
      ],
      "claim": "Singapore",
      "id": "R0145.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "sg-p2-iras:body"
      ],
      "claim": "IRAS’s actual current guidance states IIR and DTT from fiscal years beginning **1 January 2025**, with the **750 million /2-of-4** scope test and no adopted UTPR in that guidance. Its 2026 update addresses Side-by-Side/SBTI and the Simplified ETR safe harbour from **31 December 2026**. See the individual source request under Sources. [sg-p2-iras](<https://www.iras.gov.sg/taxes/pillar-2-top-up-taxes/global-anti-base-erosion-%28globe%29-rules-and-domestic-top-up-tax-%28dtt%29>)",
      "id": "R0145.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "IRAS Pillar Two current scope/commencement and 2026 safe-harbour overview",
      "block": "sg-p2-iras:body",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/sg-p2-iras.txt",
      "capture_sha256": "553055c89e11c046c6faa326b0cda6bd4d58d743abc4fc94704f5ea9e3691886",
      "limitations": [
        "ActualcurrentIRASguidanceincluding2026overlayread; SSOMinimumTaxActretrieval403, nostatutoryfullcalculationclearance."
      ],
      "native_fragment_ids": [
        "N01891",
        "N01892",
        "N01893",
        "N01894",
        "N01895",
        "N01896",
        "N01897",
        "N01898",
        "N01899",
        "N01900",
        "N01901",
        "N01902",
        "N01903",
        "N01904",
        "N01905",
        "N01906",
        "N01907",
        "N01908",
        "N01909",
        "N01910",
        "N01911",
        "N01912",
        "N01913",
        "N01914",
        "N01915",
        "N01916",
        "N01917",
        "N01918",
        "N01919",
        "N01920",
        "N01921",
        "N01922",
        "N01923",
        "N01924",
        "N01925",
        "N01926",
        "N01927",
        "N01928",
        "N01929",
        "N01930",
        "N01931",
        "N01932",
        "N01933",
        "N01934",
        "N01935",
        "N01936",
        "N01937",
        "N01938",
        "N01939",
        "N01940",
        "N01941",
        "N01942",
        "N01943",
        "N01944",
        "N01945",
        "N01946",
        "N01947",
        "N01948"
      ],
      "official_url": "https://www.iras.gov.sg/taxes/pillar-2-top-up-taxes/global-anti-base-erosion-%28globe%29-rules-and-domestic-top-up-tax-%28dtt%29",
      "own_read_date": "2026-11-16",
      "quote_id": "N01925",
      "read_scope": "Actual extracted lines 1–37, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [
        "Harbour. Singapore will implement the Simplified ETR Safe Harbour from financial years commencing on or after 31 December 2026, per the applicability date provided under"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "sg-p2-iras",
      "visual_proof": null
    }
  ],
  "old_lines": [
    225
  ],
  "section": "Pillar Two interaction",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0146

| Madeira / Portugal | See the individual source request under Sources. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    221,
    221
  ],
  "id": "R0146",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Madeira / Portugal",
      "id": "R0146.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "See the individual source request under Sources.",
      "id": "R0146.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    226
  ],
  "section": "Pillar Two interaction",
  "source_read_record": null,
  "status": "workflow/research question or table label; no current rule asserted"
}
```

### R0147

| Mauritius | The actual Income Tax Act sections 50Q–50R now enact **15% QDMTT** for covered groups, with the **EUR 750 million /2-of-4** test and exclusions. The actual **2026 regulations GN 135/2026, regulation 29**, are deemed in operation from **1 July 2025**. “Considered but not yet enacted” is obsolete. See the individual source request under Sources. [mauritius-act2026-full](<https://www.mra.mu/download/ITAConsolidated.pdf>); [mauritius-qdmtt2026](<https://mra.mu/download/IT_QDMT_Reg26.pdf>) |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    222,
    222
  ],
  "id": "R0147",
  "individual_subclaims": [
    {
      "bindings": [
        "mauritius-act2026-full:QDMTT",
        "mauritius-qdmtt2026:commencement",
        "mauritius-act2026-full:QDMTT-charging"
      ],
      "claim": "Mauritius",
      "id": "R0147.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "mauritius-act2026-full:QDMTT",
        "mauritius-qdmtt2026:commencement",
        "mauritius-act2026-full:QDMTT-charging"
      ],
      "claim": "The actual Income Tax Act sections 50Q–50R now enact **15% QDMTT** for covered groups, with the **EUR 750 million /2-of-4** test and exclusions. The actual **2026 regulations GN 135/2026, regulation 29**, are deemed in operation from **1 July 2025**. “Considered but not yet enacted” is obsolete. See the individual source request under Sources. [mauritius-act2026-full](<https://www.mra.mu/download/ITAConsolidated.pdf>); [mauritius-qdmtt2026](<https://mra.mu/download/IT_QDMT_Reg26.pdf>)",
      "id": "R0147.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "Income Tax Act relevant minimum-tax definitions",
      "block": "mauritius-act2026-full:QDMTT",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/mauritius-act2026-full.txt",
      "capture_sha256": "efcf33d41fd4d2d3a33ec8eb98c76d6896865e15bf818849dd597beb9cd15933",
      "limitations": [
        "MRA2026internetconsolidationcoverforinformationonly/disclaimslegalresponsibility; selectedreadscopesonly, notwhole536pages. Prescribedsubstance/fullcalculationrulesunread."
      ],
      "native_fragment_ids": [
        "N01609",
        "N01610",
        "N01611",
        "N01612",
        "N01613",
        "N01614",
        "N01615",
        "N01616",
        "N01617",
        "N01618",
        "N01619",
        "N01620",
        "N01621",
        "N01622",
        "N01623"
      ],
      "official_url": "https://www.mra.mu/download/ITAConsolidated.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N01617",
      "read_scope": "Actual extracted lines 4360–4420, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "mauritius-act2026-full",
      "visual_proof": null
    },
    {
      "act_article": "GN 135/2026 regulation 29, neighboring 28 and opening definitions",
      "block": "mauritius-qdmtt2026:commencement",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/mauritius-qdmtt2026.txt",
      "capture_sha256": "1ba7a1276dff1554c66cbcca84a39992ae123173494f4a2b4c838742d18be12e",
      "limitations": [
        "ActualGazetteGN135/2026made28Jul/pub8Aug; selectedcover/definitions/29commencementwith28neighborsread, remainingcalculationrulesnotcleared."
      ],
      "native_fragment_ids": [
        "N01648",
        "N01649",
        "N01650",
        "N01651",
        "N01652",
        "N01653",
        "N01654",
        "N01655",
        "N01656"
      ],
      "official_url": "https://mra.mu/download/IT_QDMT_Reg26.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N01656",
      "read_scope": "Actual extracted lines 2155–2178, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [
        "These regulations shall be deemed to have come into operation on 1 July 2025. Made by the Minister on 28 July 2026."
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "mauritius-qdmtt2026",
      "visual_proof": null
    },
    {
      "act_article": "Income Tax Act sections 50Q–50R",
      "block": "mauritius-act2026-full:QDMTT-charging",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/mauritius-act2026-full.txt",
      "capture_sha256": "efcf33d41fd4d2d3a33ec8eb98c76d6896865e15bf818849dd597beb9cd15933",
      "limitations": [
        "MRA2026internetconsolidationcoverforinformationonly/disclaimslegalresponsibility; selectedreadscopesonly, notwhole536pages. Prescribedsubstance/fullcalculationrulesunread."
      ],
      "native_fragment_ids": [
        "N01624",
        "N01625",
        "N01626",
        "N01627",
        "N01628",
        "N01629",
        "N01630",
        "N01631",
        "N01632",
        "N01633",
        "N01634",
        "N01635",
        "N01636",
        "N01637",
        "N01638",
        "N01639",
        "N01640",
        "N01641",
        "N01642",
        "N01643",
        "N01644",
        "N01645",
        "N01646",
        "N01647"
      ],
      "official_url": "https://www.mra.mu/download/ITAConsolidated.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N01645",
      "read_scope": "Actual extracted lines 4620–4705, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "mauritius-act2026-full",
      "visual_proof": null
    }
  ],
  "old_lines": [
    227
  ],
  "section": "Pillar Two interaction",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0148

## Worked cases

```json
{
  "context_only_blocks": [],
  "current_lines": [
    224,
    224
  ],
  "id": "R0148",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "## Worked cases",
      "id": "R0148.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Worked cases",
  "source_read_record": null,
  "status": "heading"
}
```

### R0149

**Case 1: UAE percentage limit binds.** Supplied full-period adjusted total revenue is **AED 70,000,000**, already including **AED 3,400,000** non-qualifying revenue. Assume the CD 100 exclusions are absent, all other QFZP conditions are met and no special ministerial treatment applies. **5% × 70,000,000 = 3,500,000**, below the AED 5,000,000 ceiling; headroom is **AED 100,000**. This only satisfies this revenue test, not every QFZP condition. [uae-100](<https://mof.gov.ae/wp-content/uploads/2023/11/Cabinet-Decision-No.-100-of-2023-on-Determining-Qualifying-Income-for-the-Qualifying-Free-Zone-Person.pdf>); [uae-229](<https://tax.gov.ae/datafolder/Files/Pdf/2025/MD-No-229.pdf>).

```json
{
  "context_only_blocks": [],
  "current_lines": [
    226,
    226
  ],
  "id": "R0149",
  "individual_subclaims": [
    {
      "bindings": [
        "uae-100:de-minimis",
        "uae-229:de-minimis"
      ],
      "claim": "**Case 1: UAE percentage limit binds.** Supplied full-period adjusted total revenue is **AED 70,000,000**, already including **AED 3,400,000** non-qualifying revenue.",
      "id": "R0149.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-100:de-minimis",
        "uae-229:de-minimis"
      ],
      "claim": "Assume the CD 100 exclusions are absent, all other QFZP conditions are met and no special ministerial treatment applies. **5% × 70,000,000 = 3,500,000**, below the AED 5,000,000 ceiling",
      "id": "R0149.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-100:de-minimis",
        "uae-229:de-minimis"
      ],
      "claim": "headroom is **AED 100,000**.",
      "id": "R0149.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-100:de-minimis",
        "uae-229:de-minimis"
      ],
      "claim": "This only satisfies this revenue test, not every QFZP condition. [uae-100](<https://mof.gov.ae/wp-content/uploads/2023/11/Cabinet-Decision-No.-100-of-2023-on-Determining-Qualifying-Income-for-the-Qualifying-Free-Zone-Person.pdf>)",
      "id": "R0149.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-100:de-minimis",
        "uae-229:de-minimis"
      ],
      "claim": "[uae-229](<https://tax.gov.ae/datafolder/Files/Pdf/2025/MD-No-229.pdf>).",
      "id": "R0149.5",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "CD 100/2023 Article 4",
      "block": "uae-100:de-minimis",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/uae-100.txt",
      "capture_sha256": "ab4d1743e78d2c336d807b83fb336f668476878713a29fa68d5ca62f9cfaca73",
      "limitations": [
        "Ministry/FTA-hosted English law. January2026consolidation andMD229 explicitly not official English translations; Arabic original unread. No entity-specific licensing/application or unread cross-reference clearance."
      ],
      "native_fragment_ids": [
        "N00118",
        "N00119",
        "N00120",
        "N00121",
        "N00122",
        "N00123",
        "N00124",
        "N00125",
        "N00126",
        "N00127",
        "N00128",
        "N00129",
        "N00130"
      ],
      "official_url": "https://mof.gov.ae/wp-content/uploads/2023/11/Cabinet-Decision-No.-100-of-2023-on-Determining-Qualifying-Income-for-the-Qualifying-Free-Zone-Person.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00119",
      "read_scope": "Actual extracted lines 103–149, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "uae-100",
      "visual_proof": null
    },
    {
      "act_article": "MD 229/2025 Article 3",
      "block": "uae-229:de-minimis",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/uae-229.txt",
      "capture_sha256": "c88cc20050545d47b3fa798760db3a8bea253e48c7e300fe41682007a6b87a7c",
      "limitations": [
        "Ministry/FTA-hosted English law. January2026consolidation andMD229 explicitly not official English translations; Arabic original unread. No entity-specific licensing/application or unread cross-reference clearance."
      ],
      "native_fragment_ids": [
        "N00060",
        "N00061",
        "N00062",
        "N00063"
      ],
      "official_url": "https://tax.gov.ae/datafolder/Files/Pdf/2025/MD-No-229.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00062",
      "read_scope": "Actual extracted lines 253–261, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "uae-229",
      "visual_proof": null
    }
  ],
  "old_lines": [],
  "section": "Worked cases",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0150

```oa-check
name: UAE percentage cap binds
inputs:
  adjusted_total: 70000000
  nonqualifying: 3400000
steps:
  - percentage_cap: adjusted_total * 0.05
  - applicable_cap: min(percentage_cap, 5000000)
  - headroom: applicable_cap - nonqualifying
expected:
  percentage_cap: 3500000
  applicable_cap: 3500000
  headroom: 100000
```

```json
{
  "context_only_blocks": [],
  "current_lines": [
    228,
    241
  ],
  "id": "R0150",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "```oa-check\nname: UAE percentage cap binds\ninputs:\n  adjusted_total: 70000000\n  nonqualifying: 3400000\nsteps:\n  - percentage_cap: adjusted_total * 0.05\n  - applicable_cap: min(percentage_cap, 5000000)\n  - headroom: applicable_cap - nonqualifying\nexpected:\n  percentage_cap: 3500000\n  applicable_cap: 3500000\n  headroom: 100000\n```",
      "id": "R0150.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Worked cases",
  "source_read_record": null,
  "status": "recomputable supplied-input arithmetic"
}
```

### R0151

**Case 2: UAE fixed ceiling binds and is breached.** Supplied full-period adjusted total revenue is **AED 120,000,000**, including **AED 5,100,000** non-qualifying revenue, under the same scope assumptions. **5% × 120,000,000 = 6,000,000**, so the cap is **AED 5,000,000** and excess is **AED 100,000**. The ordinary failure consequence is QFZP loss from the period’s beginning and for 4 subsequent periods, not 9% on 100,000 alone. These are revenue comparisons, not corporate-tax calculations. [uae-100](<https://mof.gov.ae/wp-content/uploads/2023/11/Cabinet-Decision-No.-100-of-2023-on-Determining-Qualifying-Income-for-the-Qualifying-Free-Zone-Person.pdf>); [uae-229](<https://tax.gov.ae/datafolder/Files/Pdf/2025/MD-No-229.pdf>).

```json
{
  "context_only_blocks": [],
  "current_lines": [
    243,
    243
  ],
  "id": "R0151",
  "individual_subclaims": [
    {
      "bindings": [
        "uae-100:de-minimis",
        "uae-229:de-minimis",
        "uae-229:conditions"
      ],
      "claim": "**Case 2: UAE fixed ceiling binds and is breached.** Supplied full-period adjusted total revenue is **AED 120,000,000**, including **AED 5,100,000** non-qualifying revenue, under the same scope assumptions. **5% × 120,000,000 = 6,000,000**, so the cap is **AED 5,000,000** and excess is **AED 100,000**.",
      "id": "R0151.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-100:de-minimis",
        "uae-229:de-minimis",
        "uae-229:conditions"
      ],
      "claim": "The ordinary failure consequence is QFZP loss from the period’s beginning and for 4 subsequent periods, not 9% on 100,000 alone.",
      "id": "R0151.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-100:de-minimis",
        "uae-229:de-minimis",
        "uae-229:conditions"
      ],
      "claim": "These are revenue comparisons, not corporate-tax calculations. [uae-100](<https://mof.gov.ae/wp-content/uploads/2023/11/Cabinet-Decision-No.-100-of-2023-on-Determining-Qualifying-Income-for-the-Qualifying-Free-Zone-Person.pdf>)",
      "id": "R0151.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-100:de-minimis",
        "uae-229:de-minimis",
        "uae-229:conditions"
      ],
      "claim": "[uae-229](<https://tax.gov.ae/datafolder/Files/Pdf/2025/MD-No-229.pdf>).",
      "id": "R0151.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "CD 100/2023 Article 4",
      "block": "uae-100:de-minimis",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/uae-100.txt",
      "capture_sha256": "ab4d1743e78d2c336d807b83fb336f668476878713a29fa68d5ca62f9cfaca73",
      "limitations": [
        "Ministry/FTA-hosted English law. January2026consolidation andMD229 explicitly not official English translations; Arabic original unread. No entity-specific licensing/application or unread cross-reference clearance."
      ],
      "native_fragment_ids": [
        "N00118",
        "N00119",
        "N00120",
        "N00121",
        "N00122",
        "N00123",
        "N00124",
        "N00125",
        "N00126",
        "N00127",
        "N00128",
        "N00129",
        "N00130"
      ],
      "official_url": "https://mof.gov.ae/wp-content/uploads/2023/11/Cabinet-Decision-No.-100-of-2023-on-Determining-Qualifying-Income-for-the-Qualifying-Free-Zone-Person.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00119",
      "read_scope": "Actual extracted lines 103–149, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "uae-100",
      "visual_proof": null
    },
    {
      "act_article": "MD 229/2025 Article 3",
      "block": "uae-229:de-minimis",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/uae-229.txt",
      "capture_sha256": "c88cc20050545d47b3fa798760db3a8bea253e48c7e300fe41682007a6b87a7c",
      "limitations": [
        "Ministry/FTA-hosted English law. January2026consolidation andMD229 explicitly not official English translations; Arabic original unread. No entity-specific licensing/application or unread cross-reference clearance."
      ],
      "native_fragment_ids": [
        "N00060",
        "N00061",
        "N00062",
        "N00063"
      ],
      "official_url": "https://tax.gov.ae/datafolder/Files/Pdf/2025/MD-No-229.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00062",
      "read_scope": "Actual extracted lines 253–261, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "uae-229",
      "visual_proof": null
    },
    {
      "act_article": "MD 229/2025 Article 5",
      "block": "uae-229:conditions",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/uae-229.txt",
      "capture_sha256": "c88cc20050545d47b3fa798760db3a8bea253e48c7e300fe41682007a6b87a7c",
      "limitations": [
        "Ministry/FTA-hosted English law. January2026consolidation andMD229 explicitly not official English translations; Arabic original unread. No entity-specific licensing/application or unread cross-reference clearance."
      ],
      "native_fragment_ids": [
        "N00079",
        "N00080",
        "N00081",
        "N00082",
        "N00083",
        "N00084",
        "N00085"
      ],
      "official_url": "https://tax.gov.ae/datafolder/Files/Pdf/2025/MD-No-229.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00080",
      "read_scope": "Actual extracted lines 306–324, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "uae-229",
      "visual_proof": null
    }
  ],
  "old_lines": [],
  "section": "Worked cases",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0152

```oa-check
name: UAE fixed cap breach
inputs:
  adjusted_total: 120000000
  nonqualifying: 5100000
steps:
  - percentage_cap: adjusted_total * 0.05
  - applicable_cap: min(percentage_cap, 5000000)
  - excess: nonqualifying - applicable_cap
expected:
  percentage_cap: 6000000
  applicable_cap: 5000000
  excess: 100000
```

```json
{
  "context_only_blocks": [],
  "current_lines": [
    245,
    258
  ],
  "id": "R0152",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "```oa-check\nname: UAE fixed cap breach\ninputs:\n  adjusted_total: 120000000\n  nonqualifying: 5100000\nsteps:\n  - percentage_cap: adjusted_total * 0.05\n  - applicable_cap: min(percentage_cap, 5000000)\n  - excess: nonqualifying - applicable_cap\nexpected:\n  percentage_cap: 6000000\n  applicable_cap: 5000000\n  excess: 100000\n```",
      "id": "R0152.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Worked cases",
  "source_read_record": null,
  "status": "recomputable supplied-input arithmetic"
}
```

### R0153

## Output specification

```json
{
  "context_only_blocks": [],
  "current_lines": [
    260,
    260
  ],
  "id": "R0153",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "## Output specification",
      "id": "R0153.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    229
  ],
  "section": "Output specification",
  "source_read_record": null,
  "status": "heading"
}
```

### R0154

The reviewer brief must include:

```json
{
  "context_only_blocks": [],
  "current_lines": [
    262,
    262
  ],
  "id": "R0154",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "The reviewer brief must include:",
      "id": "R0154.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    231
  ],
  "section": "Output specification",
  "source_read_record": null,
  "status": "scope/workflow/refusal/protected disclaimer; no new statutory assertion"
}
```

### R0155

1. **Zone selection rationale:** commercial fit, alternatives, operating and exit costs; identify the actual jurisdiction and entity.

```json
{
  "context_only_blocks": [],
  "current_lines": [
    264,
    264
  ],
  "id": "R0155",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "1. **Zone selection rationale:** commercial fit, alternatives, operating and exit costs",
      "id": "R0155.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "identify the actual jurisdiction and entity.",
      "id": "R0155.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    233
  ],
  "section": "Output specification",
  "source_read_record": null,
  "status": "scope/workflow/refusal/protected disclaimer; no new statutory assertion"
}
```

### R0156

2. **Qualifying activity confirmation:** classify every revenue stream against the published current list and exceptions; attach the legal source or an individual unresolved question.

```json
{
  "context_only_blocks": [],
  "current_lines": [
    266,
    266
  ],
  "id": "R0156",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "2. **Qualifying activity confirmation:** classify every revenue stream against the published current list and exceptions",
      "id": "R0156.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "attach the legal source or an individual unresolved question.",
      "id": "R0156.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    234
  ],
  "section": "Output specification",
  "source_read_record": null,
  "status": "scope/workflow/refusal/protected disclaimer; no new statutory assertion"
}
```

### R0157

3. **Substance plan:** premises, named personnel, headcount/qualifications, CIGA, OPEX, outsourcing and decision-making, with only legally established minimums.

```json
{
  "context_only_blocks": [],
  "current_lines": [
    268,
    268
  ],
  "id": "R0157",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "3. **Substance plan:** premises, named personnel, headcount/qualifications, CIGA, OPEX, outsourcing and decision-making, with only legally established minimums.",
      "id": "R0157.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    235
  ],
  "section": "Output specification",
  "source_read_record": null,
  "status": "scope/workflow/refusal/protected disclaimer; no new statutory assertion"
}
```

### R0158

4. **De minimis tracking:** adjusted numerator/denominator, forecast/headroom, monitoring and failure periods; do not confuse revenue with profit or transaction count.

```json
{
  "context_only_blocks": [],
  "current_lines": [
    270,
    270
  ],
  "id": "R0158",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "4. **De minimis tracking:** adjusted numerator/denominator, forecast/headroom, monitoring and failure periods",
      "id": "R0158.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "do not confuse revenue with profit or transaction count.",
      "id": "R0158.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    236
  ],
  "section": "Output specification",
  "source_read_record": null,
  "status": "scope/workflow/refusal/protected disclaimer; no new statutory assertion"
}
```

### R0159

5. **Onshore-mainland plan:** actual UAE sales/distributor/licence route or Indian DTA removal/customs mechanics, rather than a presumed prohibition/exemption.

```json
{
  "context_only_blocks": [],
  "current_lines": [
    272,
    272
  ],
  "id": "R0159",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "5. **Onshore-mainland plan:** actual UAE sales/distributor/licence route or Indian DTA removal/customs mechanics, rather than a presumed prohibition/exemption.",
      "id": "R0159.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    237
  ],
  "section": "Output specification",
  "source_read_record": null,
  "status": "scope/workflow/refusal/protected disclaimer; no new statutory assertion"
}
```

### R0160

6. **Withholding position:** inbound/outbound payment and recipient classification, domestic charge/exemption and treaty LOB/PPT/beneficial-ownership tests with actual sources.

```json
{
  "context_only_blocks": [],
  "current_lines": [
    274,
    274
  ],
  "id": "R0160",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "6. **Withholding position:** inbound/outbound payment and recipient classification, domestic charge/exemption and treaty LOB/PPT/beneficial-ownership tests with actual sources.",
      "id": "R0160.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    238
  ],
  "section": "Output specification",
  "source_read_record": null,
  "status": "scope/workflow/refusal/protected disclaimer; no new statutory assertion"
}
```

### R0161

7. **Pillar Two:** group revenue/year/entity scope, jurisdictional ETR, domestic charge, foreign IIR/UTPR, exclusions/elections/safe harbours and source gaps. Model only when all required current rules and inputs are established.

```json
{
  "context_only_blocks": [],
  "current_lines": [
    276,
    276
  ],
  "id": "R0161",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "7. **Pillar Two:** group revenue/year/entity scope, jurisdictional ETR, domestic charge, foreign IIR/UTPR, exclusions/elections/safe harbours and source gaps.",
      "id": "R0161.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Model only when all required current rules and inputs are established.",
      "id": "R0161.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    239
  ],
  "section": "Output specification",
  "source_read_record": null,
  "status": "scope/workflow/refusal/protected disclaimer; no new statutory assertion"
}
```

### R0162

8. **Economic-substance compliance:** identify each applicable national statute/activity, reporting, records and consequence; no generic ESA checklist substitutes for the law.

```json
{
  "context_only_blocks": [],
  "current_lines": [
    278,
    278
  ],
  "id": "R0162",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "8. **Economic-substance compliance:** identify each applicable national statute/activity, reporting, records and consequence",
      "id": "R0162.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "no generic ESA checklist substitutes for the law.",
      "id": "R0162.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    240
  ],
  "section": "Output specification",
  "source_read_record": null,
  "status": "scope/workflow/refusal/protected disclaimer; no new statutory assertion"
}
```

### R0163

9. **Reviewer questions:** label each [T2]/[T3] judgement or unconfirmed rate/box/procedure, missing source and decision blocked. No incorporation recommendation rests on an unresolved favourable number.

```json
{
  "context_only_blocks": [],
  "current_lines": [
    280,
    280
  ],
  "id": "R0163",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "9. **Reviewer questions:** label each [T2]/[T3] judgement or unconfirmed rate/box/procedure, missing source and decision blocked.",
      "id": "R0163.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "No incorporation recommendation rests on an unresolved favourable number.",
      "id": "R0163.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    241
  ],
  "section": "Output specification",
  "source_read_record": null,
  "status": "scope/workflow/refusal/protected disclaimer; no new statutory assertion"
}
```

### R0164

## Self-checks

```json
{
  "context_only_blocks": [],
  "current_lines": [
    282,
    282
  ],
  "id": "R0164",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "## Self-checks",
      "id": "R0164.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    243
  ],
  "section": "Self-checks",
  "source_read_record": null,
  "status": "heading"
}
```

### R0165

- [ ] Actual current OECD FHTP regime result checked; no invented approved-zone list. [oecd-harmful](<https://www.oecd.org/en/topics/harmful-tax-practices.html>).

```json
{
  "context_only_blocks": [],
  "current_lines": [
    284,
    284
  ],
  "id": "R0165",
  "individual_subclaims": [
    {
      "bindings": [
        "oecd-harmful:overview"
      ],
      "claim": "- [ ] Actual current OECD FHTP regime result checked",
      "id": "R0165.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "oecd-harmful:overview"
      ],
      "claim": "no invented approved-zone list. [oecd-harmful](<https://www.oecd.org/en/topics/harmful-tax-practices.html>).",
      "id": "R0165.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "OECD harmful-tax-practices selected overview",
      "block": "oecd-harmful:overview",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/oecd-harmful-native-excerpts.txt",
      "capture_sha256": "451c87f22964cd601fc587c6e4bc1e88f97ed1af9659d54449cf0f4eb121ea13",
      "limitations": [
        "Selectedactualoverviewread; individualFHTPoutcomes/nationalESAstatutesnotcleared. Shortsource-nativeextracts, noapprovedzonelistinferred.",
        "Only tool Lnn locators and citation wrappers removed, retaining visible anchor text; raw response immutable."
      ],
      "native_fragment_ids": [
        "N02249",
        "N02250",
        "N02251",
        "N02252"
      ],
      "official_url": "https://www.oecd.org/en/topics/harmful-tax-practices.html",
      "own_read_date": "2026-11-16",
      "quote_id": "N02249",
      "read_scope": "Actual official web lines 3738–3741, personally read with immediate qualifications.",
      "short_exact_native_quote": [
        "assessment of preferential tax regimes"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "oecd-harmful",
      "visual_proof": null
    }
  ],
  "old_lines": [
    245
  ],
  "section": "Self-checks",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0166

- [ ] Activity matches the exact current list/definition, not analogy.

```json
{
  "context_only_blocks": [],
  "current_lines": [
    286,
    286
  ],
  "id": "R0166",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "- [ ] Activity matches the exact current list/definition, not analogy.",
      "id": "R0166.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    246
  ],
  "section": "Self-checks",
  "source_read_record": null,
  "status": "scope/workflow/refusal/protected disclaimer; no new statutory assertion"
}
```

### R0167

- [ ] Correct de minimis numerator/denominator and **lower 5%/AED 5 million** cap applied for UAE, with other regimes’ own rules. [uae-100](<https://mof.gov.ae/wp-content/uploads/2023/11/Cabinet-Decision-No.-100-of-2023-on-Determining-Qualifying-Income-for-the-Qualifying-Free-Zone-Person.pdf>); [uae-229](<https://tax.gov.ae/datafolder/Files/Pdf/2025/MD-No-229.pdf>).

```json
{
  "context_only_blocks": [],
  "current_lines": [
    288,
    288
  ],
  "id": "R0167",
  "individual_subclaims": [
    {
      "bindings": [
        "uae-100:de-minimis",
        "uae-229:de-minimis"
      ],
      "claim": "- [ ] Correct de minimis numerator/denominator and **lower 5%/AED 5 million** cap applied for UAE, with other regimes’ own rules. [uae-100](<https://mof.gov.ae/wp-content/uploads/2023/11/Cabinet-Decision-No.-100-of-2023-on-Determining-Qualifying-Income-for-the-Qualifying-Free-Zone-Person.pdf>)",
      "id": "R0167.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-100:de-minimis",
        "uae-229:de-minimis"
      ],
      "claim": "[uae-229](<https://tax.gov.ae/datafolder/Files/Pdf/2025/MD-No-229.pdf>).",
      "id": "R0167.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "CD 100/2023 Article 4",
      "block": "uae-100:de-minimis",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/uae-100.txt",
      "capture_sha256": "ab4d1743e78d2c336d807b83fb336f668476878713a29fa68d5ca62f9cfaca73",
      "limitations": [
        "Ministry/FTA-hosted English law. January2026consolidation andMD229 explicitly not official English translations; Arabic original unread. No entity-specific licensing/application or unread cross-reference clearance."
      ],
      "native_fragment_ids": [
        "N00118",
        "N00119",
        "N00120",
        "N00121",
        "N00122",
        "N00123",
        "N00124",
        "N00125",
        "N00126",
        "N00127",
        "N00128",
        "N00129",
        "N00130"
      ],
      "official_url": "https://mof.gov.ae/wp-content/uploads/2023/11/Cabinet-Decision-No.-100-of-2023-on-Determining-Qualifying-Income-for-the-Qualifying-Free-Zone-Person.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00122",
      "read_scope": "Actual extracted lines 103–149, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "uae-100",
      "visual_proof": null
    },
    {
      "act_article": "MD 229/2025 Article 3",
      "block": "uae-229:de-minimis",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/uae-229.txt",
      "capture_sha256": "c88cc20050545d47b3fa798760db3a8bea253e48c7e300fe41682007a6b87a7c",
      "limitations": [
        "Ministry/FTA-hosted English law. January2026consolidation andMD229 explicitly not official English translations; Arabic original unread. No entity-specific licensing/application or unread cross-reference clearance."
      ],
      "native_fragment_ids": [
        "N00060",
        "N00061",
        "N00062",
        "N00063"
      ],
      "official_url": "https://tax.gov.ae/datafolder/Files/Pdf/2025/MD-No-229.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00061",
      "read_scope": "Actual extracted lines 253–261, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "uae-229",
      "visual_proof": null
    }
  ],
  "old_lines": [
    247
  ],
  "section": "Self-checks",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0168

- [ ] Premises, employees, qualifications, OPEX, CIGA and permitted outsourcing are evidenced.

```json
{
  "context_only_blocks": [],
  "current_lines": [
    290,
    290
  ],
  "id": "R0168",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "- [ ] Premises, employees, qualifications, OPEX, CIGA and permitted outsourcing are evidenced.",
      "id": "R0168.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    248
  ],
  "section": "Self-checks",
  "source_read_record": null,
  "status": "scope/workflow/refusal/protected disclaimer; no new statutory assertion"
}
```

### R0169

- [ ] **EUR 750 million**, relevant prior-year/entity tests and local/foreign minimum-tax rules checked; no automatic 15%-headline comparison. [uae-142](<https://tax.gov.ae/Datafolder/Files/Legislation/Cabinet-Decision-No-142-of-2024-on-Top-up-Tax-on-MNEs.pdf>).

```json
{
  "context_only_blocks": [],
  "current_lines": [
    292,
    292
  ],
  "id": "R0169",
  "individual_subclaims": [
    {
      "bindings": [
        "uae-142:scope"
      ],
      "claim": "- [ ] **EUR 750 million**, relevant prior-year/entity tests and local/foreign minimum-tax rules checked",
      "id": "R0169.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-142:scope"
      ],
      "claim": "no automatic 15%-headline comparison. [uae-142](<https://tax.gov.ae/Datafolder/Files/Legislation/Cabinet-Decision-No-142-of-2024-on-Top-up-Tax-on-MNEs.pdf>).",
      "id": "R0169.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "CD 142/2024 Articles 1–3; Annex 1.1–1.5 with neighboring 1.6",
      "block": "uae-142:scope",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/uae-142.txt",
      "capture_sha256": "0bf87c650114188a0fca64ad2c614d1b8ef73bbfaf76139539a48b10120b7a86",
      "limitations": [
        "Ministry/FTA-hosted English law. January2026consolidation andMD229 explicitly not official English translations; Arabic original unread. No entity-specific licensing/application or unread cross-reference clearance."
      ],
      "native_fragment_ids": [
        "N00257",
        "N00258",
        "N00259",
        "N00260",
        "N00261",
        "N00262",
        "N00263",
        "N00264",
        "N00265",
        "N00266",
        "N00267",
        "N00268",
        "N00269",
        "N00270",
        "N00271",
        "N00272",
        "N00273",
        "N00274",
        "N00275",
        "N00276",
        "N00277",
        "N00278",
        "N00279",
        "N00280",
        "N00281",
        "N00282",
        "N00283",
        "N00284",
        "N00285",
        "N00286",
        "N00287",
        "N00288",
        "N00289",
        "N00290",
        "N00291",
        "N00292",
        "N00293",
        "N00294",
        "N00295",
        "N00296",
        "N00297",
        "N00298",
        "N00299",
        "N00300",
        "N00301"
      ],
      "official_url": "https://tax.gov.ae/Datafolder/Files/Legislation/Cabinet-Decision-No-142-of-2024-on-Top-up-Tax-on-MNEs.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00277",
      "read_scope": "Actual extracted lines 1–130, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "uae-142",
      "visual_proof": null
    }
  ],
  "old_lines": [
    249
  ],
  "section": "Self-checks",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0170

- [ ] Actual domestic-sales permissions, customs routing and arm’s-length pricing documented.

```json
{
  "context_only_blocks": [],
  "current_lines": [
    294,
    294
  ],
  "id": "R0170",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "- [ ] Actual domestic-sales permissions, customs routing and arm’s-length pricing documented.",
      "id": "R0170.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    250
  ],
  "section": "Self-checks",
  "source_read_record": null,
  "status": "scope/workflow/refusal/protected disclaimer; no new statutory assertion"
}
```

### R0171

- [ ] LOB, beneficial ownership and PPT tested under the actual treaty for material WHT flows.

```json
{
  "context_only_blocks": [],
  "current_lines": [
    296,
    296
  ],
  "id": "R0171",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "- [ ] LOB, beneficial ownership and PPT tested under the actual treaty for material WHT flows.",
      "id": "R0171.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    251
  ],
  "section": "Self-checks",
  "source_read_record": null,
  "status": "scope/workflow/refusal/protected disclaimer; no new statutory assertion"
}
```

### R0172

- [ ] Country-specific ESA obligations and exceptions documented where applicable.

```json
{
  "context_only_blocks": [],
  "current_lines": [
    298,
    298
  ],
  "id": "R0172",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "- [ ] Country-specific ESA obligations and exceptions documented where applicable.",
      "id": "R0172.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    252
  ],
  "section": "Self-checks",
  "source_read_record": null,
  "status": "scope/workflow/refusal/protected disclaimer; no new statutory assertion"
}
```

### R0173

- [ ] Audited accounts and TP-documentation duties established from the actual applicable thresholds/instruments.

```json
{
  "context_only_blocks": [],
  "current_lines": [
    300,
    300
  ],
  "id": "R0173",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "- [ ] Audited accounts and TP-documentation duties established from the actual applicable thresholds/instruments.",
      "id": "R0173.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    253
  ],
  "section": "Self-checks",
  "source_read_record": null,
  "status": "scope/workflow/refusal/protected disclaimer; no new statutory assertion"
}
```

### R0174

- [ ] Every [T2]/[T3] and individual source request is flagged for reviewer judgement before execution.

```json
{
  "context_only_blocks": [],
  "current_lines": [
    302,
    302
  ],
  "id": "R0174",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "- [ ] Every [T2]/[T3] and individual source request is flagged for reviewer judgement before execution.",
      "id": "R0174.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    254
  ],
  "section": "Self-checks",
  "source_read_record": null,
  "status": "scope/workflow/refusal/protected disclaimer; no new statutory assertion"
}
```

### R0175

## Prohibitions

```json
{
  "context_only_blocks": [],
  "current_lines": [
    304,
    304
  ],
  "id": "R0175",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "## Prohibitions",
      "id": "R0175.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    256
  ],
  "section": "Prohibitions",
  "source_read_record": null,
  "status": "heading"
}
```

### R0176

- **Do not** advise incorporation from an old FHTP result or an invented “OECD-approved zone” status; obtain the actual current regime outcome. [oecd-harmful](<https://www.oecd.org/en/topics/harmful-tax-practices.html>).

```json
{
  "context_only_blocks": [],
  "current_lines": [
    306,
    306
  ],
  "id": "R0176",
  "individual_subclaims": [
    {
      "bindings": [
        "oecd-harmful:overview"
      ],
      "claim": "- **Do not** advise incorporation from an old FHTP result or an invented “OECD-approved zone” status",
      "id": "R0176.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "oecd-harmful:overview"
      ],
      "claim": "obtain the actual current regime outcome. [oecd-harmful](<https://www.oecd.org/en/topics/harmful-tax-practices.html>).",
      "id": "R0176.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "OECD harmful-tax-practices selected overview",
      "block": "oecd-harmful:overview",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/oecd-harmful-native-excerpts.txt",
      "capture_sha256": "451c87f22964cd601fc587c6e4bc1e88f97ed1af9659d54449cf0f4eb121ea13",
      "limitations": [
        "Selectedactualoverviewread; individualFHTPoutcomes/nationalESAstatutesnotcleared. Shortsource-nativeextracts, noapprovedzonelistinferred.",
        "Only tool Lnn locators and citation wrappers removed, retaining visible anchor text; raw response immutable."
      ],
      "native_fragment_ids": [
        "N02249",
        "N02250",
        "N02251",
        "N02252"
      ],
      "official_url": "https://www.oecd.org/en/topics/harmful-tax-practices.html",
      "own_read_date": "2026-11-16",
      "quote_id": "N02249",
      "read_scope": "Actual official web lines 3738–3741, personally read with immediate qualifications.",
      "short_exact_native_quote": [
        "assessment of preferential tax regimes"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "oecd-harmful",
      "visual_proof": null
    }
  ],
  "old_lines": [
    258
  ],
  "section": "Prohibitions",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0177

- **Do not** classify a non-qualifying activity by analogy to a related listed activity.

```json
{
  "context_only_blocks": [],
  "current_lines": [
    308,
    308
  ],
  "id": "R0177",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "- **Do not** classify a non-qualifying activity by analogy to a related listed activity.",
      "id": "R0177.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    259
  ],
  "section": "Prohibitions",
  "source_read_record": null,
  "status": "scope/workflow/refusal/protected disclaimer; no new statutory assertion"
}
```

### R0178

- **Do not** treat a tax de minimis cap as legal permission for mainland sales, a transaction-count limit or a profit threshold. [uae-100](<https://mof.gov.ae/wp-content/uploads/2023/11/Cabinet-Decision-No.-100-of-2023-on-Determining-Qualifying-Income-for-the-Qualifying-Free-Zone-Person.pdf>).

```json
{
  "context_only_blocks": [],
  "current_lines": [
    310,
    310
  ],
  "id": "R0178",
  "individual_subclaims": [
    {
      "bindings": [
        "uae-100:de-minimis"
      ],
      "claim": "- **Do not** treat a tax de minimis cap as legal permission for mainland sales, a transaction-count limit or a profit threshold. [uae-100](<https://mof.gov.ae/wp-content/uploads/2023/11/Cabinet-Decision-No.-100-of-2023-on-Determining-Qualifying-Income-for-the-Qualifying-Free-Zone-Person.pdf>).",
      "id": "R0178.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "CD 100/2023 Article 4",
      "block": "uae-100:de-minimis",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/uae-100.txt",
      "capture_sha256": "ab4d1743e78d2c336d807b83fb336f668476878713a29fa68d5ca62f9cfaca73",
      "limitations": [
        "Ministry/FTA-hosted English law. January2026consolidation andMD229 explicitly not official English translations; Arabic original unread. No entity-specific licensing/application or unread cross-reference clearance."
      ],
      "native_fragment_ids": [
        "N00118",
        "N00119",
        "N00120",
        "N00121",
        "N00122",
        "N00123",
        "N00124",
        "N00125",
        "N00126",
        "N00127",
        "N00128",
        "N00129",
        "N00130"
      ],
      "official_url": "https://mof.gov.ae/wp-content/uploads/2023/11/Cabinet-Decision-No.-100-of-2023-on-Determining-Qualifying-Income-for-the-Qualifying-Free-Zone-Person.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00118",
      "read_scope": "Actual extracted lines 103–149, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "uae-100",
      "visual_proof": null
    }
  ],
  "old_lines": [
    260
  ],
  "section": "Prohibitions",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0179

- **Do not** ignore Pillar Two for a potentially covered **EUR 750 million** group or promise a full clawback; establish the legal scope, ETR adjustments and charging rule. [uae-142](<https://tax.gov.ae/Datafolder/Files/Legislation/Cabinet-Decision-No-142-of-2024-on-Top-up-Tax-on-MNEs.pdf>); [oecd-global](<https://www.oecd.org/en/topics/global-minimum-tax.html>).

```json
{
  "context_only_blocks": [],
  "current_lines": [
    312,
    312
  ],
  "id": "R0179",
  "individual_subclaims": [
    {
      "bindings": [
        "uae-142:scope",
        "oecd-global:overview"
      ],
      "claim": "- **Do not** ignore Pillar Two for a potentially covered **EUR 750 million** group or promise a full clawback",
      "id": "R0179.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-142:scope",
        "oecd-global:overview"
      ],
      "claim": "establish the legal scope, ETR adjustments and charging rule. [uae-142](<https://tax.gov.ae/Datafolder/Files/Legislation/Cabinet-Decision-No-142-of-2024-on-Top-up-Tax-on-MNEs.pdf>)",
      "id": "R0179.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [
        "uae-142:scope",
        "oecd-global:overview"
      ],
      "claim": "[oecd-global](<https://www.oecd.org/en/topics/global-minimum-tax.html>).",
      "id": "R0179.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [
    {
      "act_article": "CD 142/2024 Articles 1–3; Annex 1.1–1.5 with neighboring 1.6",
      "block": "uae-142:scope",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/uae-142.txt",
      "capture_sha256": "0bf87c650114188a0fca64ad2c614d1b8ef73bbfaf76139539a48b10120b7a86",
      "limitations": [
        "Ministry/FTA-hosted English law. January2026consolidation andMD229 explicitly not official English translations; Arabic original unread. No entity-specific licensing/application or unread cross-reference clearance."
      ],
      "native_fragment_ids": [
        "N00257",
        "N00258",
        "N00259",
        "N00260",
        "N00261",
        "N00262",
        "N00263",
        "N00264",
        "N00265",
        "N00266",
        "N00267",
        "N00268",
        "N00269",
        "N00270",
        "N00271",
        "N00272",
        "N00273",
        "N00274",
        "N00275",
        "N00276",
        "N00277",
        "N00278",
        "N00279",
        "N00280",
        "N00281",
        "N00282",
        "N00283",
        "N00284",
        "N00285",
        "N00286",
        "N00287",
        "N00288",
        "N00289",
        "N00290",
        "N00291",
        "N00292",
        "N00293",
        "N00294",
        "N00295",
        "N00296",
        "N00297",
        "N00298",
        "N00299",
        "N00300",
        "N00301"
      ],
      "official_url": "https://tax.gov.ae/Datafolder/Files/Legislation/Cabinet-Decision-No-142-of-2024-on-Top-up-Tax-on-MNEs.pdf",
      "own_read_date": "2026-11-16",
      "quote_id": "N00277",
      "read_scope": "Actual extracted lines 1–130, entire stated operative clause and immediate neighboring conditions personally read; unrelated remainder not whole-read.",
      "short_exact_native_quote": [],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "uae-142",
      "visual_proof": null
    },
    {
      "act_article": "OECD global-minimum-tax selected overview",
      "block": "oecd-global:overview",
      "capture": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/reporting-evidence/free-zones-sez-matrix/sources/oecd-global-native-excerpts.txt",
      "capture_sha256": "fcc245ec5302be8c7e27f4af5d45aa913ec7cb93796b1a18e2f6c06c775aadd0",
      "limitations": [
        "Selectedactualoverviewparagraphsread; legislative template, notdomesticlaw. Fullmodel/administrativeguidancenotread. Shortsource-nativeextractsinledger, notfullsitequotation.",
        "Only tool Lnn locators and citation wrappers removed, retaining visible anchor text; raw response immutable."
      ],
      "native_fragment_ids": [
        "N02245",
        "N02246",
        "N02247",
        "N02248"
      ],
      "official_url": "https://www.oecd.org/en/topics/global-minimum-tax.html",
      "own_read_date": "2026-11-16",
      "quote_id": "N02246",
      "read_scope": "Actual official web lines 3749–3771, personally read with immediate qualifications.",
      "short_exact_native_quote": [
        "15% minimum rate"
      ],
      "short_exact_native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
      "source": "oecd-global",
      "visual_proof": null
    }
  ],
  "old_lines": [
    261
  ],
  "section": "Prohibitions",
  "source_read_record": null,
  "status": "source-supported bounded rule or calculation"
}
```

### R0180

- **Do not** recommend IP holding without the relevant IP-box/nexus and asset/income conditions.

```json
{
  "context_only_blocks": [],
  "current_lines": [
    314,
    314
  ],
  "id": "R0180",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "- **Do not** recommend IP holding without the relevant IP-box/nexus and asset/income conditions.",
      "id": "R0180.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    262
  ],
  "section": "Prohibitions",
  "source_read_record": null,
  "status": "scope/workflow/refusal/protected disclaimer; no new statutory assertion"
}
```

### R0181

- **Do not** promise treaty access without the actual LOB/PPT and beneficial-ownership analysis.

```json
{
  "context_only_blocks": [],
  "current_lines": [
    316,
    316
  ],
  "id": "R0181",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "- **Do not** promise treaty access without the actual LOB/PPT and beneficial-ownership analysis.",
      "id": "R0181.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    263
  ],
  "section": "Prohibitions",
  "source_read_record": null,
  "status": "scope/workflow/refusal/protected disclaimer; no new statutory assertion"
}
```

### R0182

## Disclaimer

```json
{
  "context_only_blocks": [],
  "current_lines": [
    318,
    318
  ],
  "id": "R0182",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "## Disclaimer",
      "id": "R0182.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    265
  ],
  "section": "Disclaimer",
  "source_read_record": null,
  "status": "heading"
}
```

### R0183

This skill and its outputs are provided for informational and computational purposes only and do not constitute tax, legal, or financial advice. Zone regimes evolve with national budgets and OECD peer review. Pillar Two implementation has materially altered the benefit calculus for in-scope groups. Every output must be reviewed and signed off by a credentialed local tax counsel before any incorporation, restructuring, or election decision.

```json
{
  "context_only_blocks": [],
  "current_lines": [
    320,
    320
  ],
  "id": "R0183",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "This skill and its outputs are provided for informational and computational purposes only and do not constitute tax, legal, or financial advice.",
      "id": "R0183.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Zone regimes evolve with national budgets and OECD peer review.",
      "id": "R0183.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Pillar Two implementation has materially altered the benefit calculus for in-scope groups.",
      "id": "R0183.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Every output must be reviewed and signed off by a credentialed local tax counsel before any incorporation, restructuring, or election decision.",
      "id": "R0183.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    267
  ],
  "section": "Disclaimer",
  "source_read_record": null,
  "status": "scope/workflow/refusal/protected disclaimer; no new statutory assertion"
}
```

### R0184

## Sources

```json
{
  "context_only_blocks": [],
  "current_lines": [
    322,
    322
  ],
  "id": "R0184",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "## Sources",
      "id": "R0184.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": null,
  "status": "heading"
}
```

### R0185

Actual read date **2026-11-16** for the selected clauses listed below, with their neighboring definitions/exceptions. Partial reads do not clear the entire law, cross-referenced legislation, licence, return or entity-specific application. Raw source captures stay local. Government guidance and unofficial/republication limits are stated alongside the national rule and below.

```json
{
  "context_only_blocks": [],
  "current_lines": [
    324,
    324
  ],
  "id": "R0185",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Actual read date **2026-11-16** for the selected clauses listed below, with their neighboring definitions/exceptions.",
      "id": "R0185.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Partial reads do not clear the entire law, cross-referenced legislation, licence, return or entity-specific application.",
      "id": "R0185.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Raw source captures stay local.",
      "id": "R0185.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Government guidance and unofficial/republication limits are stated alongside the national rule and below.",
      "id": "R0185.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": null,
  "status": "scope/workflow/refusal/protected disclaimer; no new statutory assertion"
}
```

### R0186

| Source and actual scope | Official URL | Read on | Material source boundary |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    326,
    326
  ],
  "id": "R0186",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Source and actual scope",
      "id": "R0186.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Official URL",
      "id": "R0186.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Read on",
      "id": "R0186.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Material source boundary",
      "id": "R0186.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": null,
  "status": "workflow/research question or table label; no current rule asserted"
}
```

### R0187

| --- | --- | --- | --- |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    327,
    327
  ],
  "id": "R0187",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "---",
      "id": "R0187.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "---",
      "id": "R0187.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "---",
      "id": "R0187.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "---",
      "id": "R0187.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": null,
  "status": "table separator"
}
```

### R0188

| uae-229: activities, definitions-activity-conditions, de-minimis, IP, conditions, repeal-application | https://tax.gov.ae/datafolder/Files/Pdf/2025/MD-No-229.pdf | 2026-11-16 | English expressly unofficial; Arabic unread. Actual PDF page 10 formula visually read. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    328,
    328
  ],
  "id": "R0188",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "uae-229: activities, definitions-activity-conditions, de-minimis, IP, conditions, repeal-application",
      "id": "R0188.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://tax.gov.ae/datafolder/Files/Pdf/2025/MD-No-229.pdf",
      "id": "R0188.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0188.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "English expressly unofficial; Arabic unread. Actual PDF page 10 formula visually read.",
      "id": "R0188.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "uae-229",
  "status": "source record and limitation"
}
```

### R0189

| sa-sez-current: intro, income-wht, cloud | https://zatca.gov.sa/en/HelpCenter/guidelines/Documents/SEZ-Tax%26Customs-Procedures.pdf | 2026-11-16 | ZATCA manual under Council 468, not the complete statute or licence; detailed customs/VAT procedures not cleared. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    329,
    329
  ],
  "id": "R0189",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "sa-sez-current: intro, income-wht, cloud",
      "id": "R0189.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://zatca.gov.sa/en/HelpCenter/guidelines/Documents/SEZ-Tax%26Customs-Procedures.pdf",
      "id": "R0189.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0189.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "ZATCA manual under Council 468, not the complete statute or licence; detailed customs/VAT procedures not cleared.",
      "id": "R0189.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "sa-sez-current",
  "status": "source record and limitation"
}
```

### R0190

| hainan-extension: extension | https://policy.mofcom.gov.cn/claw/clawContent.shtml?id=103253 | 2026-11-16 | Government republication disclaims accuracy/currentness; original MOF text not recovered. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    330,
    330
  ],
  "id": "R0190",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "hainan-extension: extension",
      "id": "R0190.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://policy.mofcom.gov.cn/claw/clawContent.shtml?id=103253",
      "id": "R0190.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0190.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Government republication disclaims accuracy/currentness; original MOF text not recovered.",
      "id": "R0190.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "hainan-extension",
  "status": "source record and limitation"
}
```

### R0191

| qianhai-extension: extension | https://www.tid.gov.hk/en/tradecircular/files/2026/ci1712026a.pdf | 2026-11-16 | HK Trade Department reproduction of extension; full base eligibility not recovered. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    331,
    331
  ],
  "id": "R0191",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "qianhai-extension: extension",
      "id": "R0191.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://www.tid.gov.hk/en/tradecircular/files/2026/ci1712026a.pdf",
      "id": "R0191.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0191.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "HK Trade Department reproduction of extension; full base eligibility not recovered.",
      "id": "R0191.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "qianhai-extension",
  "status": "source record and limitation"
}
```

### R0192

| india-fa 2026: IFSC, rate | https://egazette.gov.in/WriteReadData/2026/271439.pdf | 2026-11-16 | Selected operative clauses/authority paragraphs read with neighbors; entity eligibility and unread cross-references not cleared. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    332,
    332
  ],
  "id": "R0192",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "india-fa 2026: IFSC, rate",
      "id": "R0192.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://egazette.gov.in/WriteReadData/2026/271439.pdf",
      "id": "R0192.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0192.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Selected operative clauses/authority paragraphs read with neighbors; entity eligibility and unread cross-references not cleared.",
      "id": "R0192.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "india-fa2026",
  "status": "source record and limitation"
}
```

### R0193

| oecd-global: overview | https://www.oecd.org/en/topics/global-minimum-tax.html | 2026-11-16 | Selected overview; model rules require domestic implementation. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    333,
    333
  ],
  "id": "R0193",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "oecd-global: overview",
      "id": "R0193.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://www.oecd.org/en/topics/global-minimum-tax.html",
      "id": "R0193.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0193.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Selected overview; model rules require domestic implementation.",
      "id": "R0193.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "oecd-global",
  "status": "source record and limitation"
}
```

### R0194

| uae-2026: rates, qualification, TP, TP-files, commencement | https://mof.gov.ae/wp-content/uploads/2026/01/Federal-Decree-Law-No.-47-of-2022-and-its-amendments-en-v13.1.26.pdf | 2026-11-16 | January 2026 English consolidation expressly unofficial; Arabic unread; selected articles only. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    334,
    334
  ],
  "id": "R0194",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "uae-2026: rates, qualification, TP, TP-files, commencement",
      "id": "R0194.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://mof.gov.ae/wp-content/uploads/2026/01/Federal-Decree-Law-No.-47-of-2022-and-its-amendments-en-v13.1.26.pdf",
      "id": "R0194.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0194.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "January 2026 English consolidation expressly unofficial; Arabic unread; selected articles only.",
      "id": "R0194.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "uae-2026",
  "status": "source record and limitation"
}
```

### R0195

| uae-100: definitions, income, de-minimis, PE-property, IP, substance, repeal-application | https://mof.gov.ae/wp-content/uploads/2023/11/Cabinet-Decision-No.-100-of-2023-on-Determining-Qualifying-Income-for-the-Qualifying-Free-Zone-Person.pdf | 2026-11-16 | Ministry-hosted English; Arabic original unread; entity/application conditions remain. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    335,
    335
  ],
  "id": "R0195",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "uae-100: definitions, income, de-minimis, PE-property, IP, substance, repeal-application",
      "id": "R0195.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://mof.gov.ae/wp-content/uploads/2023/11/Cabinet-Decision-No.-100-of-2023-on-Determining-Qualifying-Income-for-the-Qualifying-Free-Zone-Person.pdf",
      "id": "R0195.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0195.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Ministry-hosted English; Arabic original unread; entity/application conditions remain.",
      "id": "R0195.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "uae-100",
  "status": "source record and limitation"
}
```

### R0196

| uae-336: whole | https://mof.gov.ae/wp-content/uploads/2026/02/Ministerial-Decision-No.-336-of-2025-on-the-Specification-of-a-Competent-Authority-for-the-Purposes-of-Ministerial-Decision-No.-229-of-2025_-En.pdf | 2026-11-16 | Ministry-hosted English; Arabic unread; limited competent-authority rule. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    336,
    336
  ],
  "id": "R0196",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "uae-336: whole",
      "id": "R0196.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://mof.gov.ae/wp-content/uploads/2026/02/Ministerial-Decision-No.-336-of-2025-on-the-Specification-of-a-Competent-Authority-for-the-Purposes-of-Ministerial-Decision-No.-229-of-2025_-En.pdf",
      "id": "R0196.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0196.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Ministry-hosted English; Arabic unread; limited competent-authority rule.",
      "id": "R0196.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "uae-336",
  "status": "source record and limitation"
}
```

### R0197

| qfc-tax 2026: language, charge-local-source | https://qfcra-en.thomsonreuters.com/sites/default/files/net_file_store/QFCRA_7103_VER7.pdf | 2026-11-16 | Official QFCRA English original, Article 4; January 2026 version 7. Other Parts and licensing law unread. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    337,
    337
  ],
  "id": "R0197",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "qfc-tax 2026: language, charge-local-source",
      "id": "R0197.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://qfcra-en.thomsonreuters.com/sites/default/files/net_file_store/QFCRA_7103_VER7.pdf",
      "id": "R0197.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0197.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Official QFCRA English original, Article 4; January 2026 version 7. Other Parts and licensing law unread.",
      "id": "R0197.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "qfc-tax2026",
  "status": "source record and limitation"
}
```

### R0198

| qfc-rules 2026: rule 1A | https://qfcra-en.thomsonreuters.com/sites/default/files/net_file_store/QFCRA_8454_VER4.pdf | 2026-11-16 | Official QFCRA January 2026 version 4; Rule 1A and neighbors only. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    338,
    338
  ],
  "id": "R0198",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "qfc-rules 2026: rule 1A",
      "id": "R0198.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://qfcra-en.thomsonreuters.com/sites/default/files/net_file_store/QFCRA_8454_VER4.pdf",
      "id": "R0198.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0198.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Official QFCRA January 2026 version 4; Rule 1A and neighbors only.",
      "id": "R0198.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "qfc-rules2026",
  "status": "source record and limitation"
}
```

### R0199

| hainan-base: operative | https://fgk.chinatax.gov.cn/zcfgk/c102416/c5202204/content.html | 2026-11-16 | Selected operative clauses/authority paragraphs read with neighbors; entity eligibility and unread cross-references not cleared. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    339,
    339
  ],
  "id": "R0199",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "hainan-base: operative",
      "id": "R0199.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://fgk.chinatax.gov.cn/zcfgk/c102416/c5202204/content.html",
      "id": "R0199.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0199.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Selected operative clauses/authority paragraphs read with neighbors; entity eligibility and unread cross-references not cleared.",
      "id": "R0199.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "hainan-base",
  "status": "source record and limitation"
}
```

### R0200

| lingang-base: operative | https://www.chinatax.gov.cn/chinatax/n810341/n810765/c101653/202007/c5156590/content.html | 2026-11-16 | Selected operative clauses/authority paragraphs read with neighbors; entity eligibility and unread cross-references not cleared. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    340,
    340
  ],
  "id": "R0200",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "lingang-base: operative",
      "id": "R0200.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://www.chinatax.gov.cn/chinatax/n810341/n810765/c101653/202007/c5156590/content.html",
      "id": "R0200.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0200.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Selected operative clauses/authority paragraphs read with neighbors; entity eligibility and unread cross-references not cleared.",
      "id": "R0200.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "lingang-base",
  "status": "source record and limitation"
}
```

### R0201

| hengqin-base: operative | https://www.hengqin.gov.cn/macau_2022_en/regulations/documents/pgp/content/post_3744459.html | 2026-11-16 | Government English reference translation; Chinese prevails; full catalogue unread. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    341,
    341
  ],
  "id": "R0201",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "hengqin-base: operative",
      "id": "R0201.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://www.hengqin.gov.cn/macau_2022_en/regulations/documents/pgp/content/post_3744459.html",
      "id": "R0201.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0201.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Government English reference translation; Chinese prevails; full catalogue unread.",
      "id": "R0201.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "hengqin-base",
  "status": "source record and limitation"
}
```

### R0202

| hk-tax: scope-rates, scope-rates-table | https://www.ird.gov.hk/eng/tax/bus_pft.htm | 2026-11-16 | Selected operative clauses/authority paragraphs read with neighbors; entity eligibility and unread cross-references not cleared. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    342,
    342
  ],
  "id": "R0202",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "hk-tax: scope-rates, scope-rates-table",
      "id": "R0202.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://www.ird.gov.hk/eng/tax/bus_pft.htm",
      "id": "R0202.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0202.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Selected operative clauses/authority paragraphs read with neighbors; entity eligibility and unread cross-references not cleared.",
      "id": "R0202.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "hk-tax",
  "status": "source record and limitation"
}
```

### R0203

| hk-fsie: dates-scope, taxpayers-treatment | https://www.ird.gov.hk/eng/tax/bus_fsie.htm | 2026-11-16 | Selected operative clauses/authority paragraphs read with neighbors; entity eligibility and unread cross-references not cleared. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    343,
    343
  ],
  "id": "R0203",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "hk-fsie: dates-scope, taxpayers-treatment",
      "id": "R0203.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://www.ird.gov.hk/eng/tax/bus_fsie.htm",
      "id": "R0203.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0203.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Selected operative clauses/authority paragraphs read with neighbors; entity eligibility and unread cross-references not cleared.",
      "id": "R0203.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "hk-fsie",
  "status": "source record and limitation"
}
```

### R0204

| india-sez-web: section 30 | https://sezindia.gov.in/sites/default/files/SEZAct2005.pdf | 2026-11-16 | Actual 2005 Act section 30; current customs rules and notifications not cleared. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    344,
    344
  ],
  "id": "R0204",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "india-sez-web: section 30",
      "id": "R0204.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://sezindia.gov.in/sites/default/files/SEZAct2005.pdf",
      "id": "R0204.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0204.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Actual 2005 Act section 30; current customs rules and notifications not cleared.",
      "id": "R0204.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "india-sez-web",
  "status": "source record and limitation"
}
```

### R0205

| india 10 aa-web: section 10AA | https://www.incometaxindia.gov.in/hi/w/section-10aa-19 | 2026-11-16 | Explicit 2024(No 2) edition; new Act 144 continuity separately read; Covid extension not cleared. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    345,
    345
  ],
  "id": "R0205",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "india 10 aa-web: section 10AA",
      "id": "R0205.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://www.incometaxindia.gov.in/hi/w/section-10aa-19",
      "id": "R0205.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0205.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Explicit 2024(No 2) edition; new Act 144 continuity separately read; Covid extension not cleared.",
      "id": "R0205.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "india10aa-web",
  "status": "source record and limitation"
}
```

### R0206

| india-act 2025: commencement, section 144, section 147 | https://egazette.gov.in/WriteReadData/2025/265620.pdf | 2026-11-16 | Selected operative clauses/authority paragraphs read with neighbors; entity eligibility and unread cross-references not cleared. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    346,
    346
  ],
  "id": "R0206",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "india-act 2025: commencement, section 144, section 147",
      "id": "R0206.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://egazette.gov.in/WriteReadData/2025/265620.pdf",
      "id": "R0206.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0206.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Selected operative clauses/authority paragraphs read with neighbors; entity eligibility and unread cross-references not cleared.",
      "id": "R0206.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "india-act2025",
  "status": "source record and limitation"
}
```

### R0207

| panama-zlc-law: activities, fiscal | https://zolicol.gob.pa/wp-content/uploads/2025/06/LEY-8-DE-2016-que-reorganiza-la-ZLC-6.pdf | 2026-11-16 | Selected operative clauses/authority paragraphs read with neighbors; entity eligibility and unread cross-references not cleared. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    347,
    347
  ],
  "id": "R0207",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "panama-zlc-law: activities, fiscal",
      "id": "R0207.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://zolicol.gob.pa/wp-content/uploads/2025/06/LEY-8-DE-2016-que-reorganiza-la-ZLC-6.pdf",
      "id": "R0207.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0207.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Selected operative clauses/authority paragraphs read with neighbors; entity eligibility and unread cross-references not cleared.",
      "id": "R0207.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "panama-zlc-law",
  "status": "source record and limitation"
}
```

### R0208

| cr-law 8794: Article 20 g | https://www.pgrweb.go.cr/DOCS/NORMAS/1/VIGENTE/L/2010-2019/2010-2014/2010/1061B/CCB5F.HTML | 2026-11-16 | Actual 2010 amending law; complete current eligibility and transitions not cleared. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    348,
    348
  ],
  "id": "R0208",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "cr-law 8794: Article 20 g",
      "id": "R0208.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://www.pgrweb.go.cr/DOCS/NORMAS/1/VIGENTE/L/2010-2019/2010-2014/2010/1061B/CCB5F.HTML",
      "id": "R0208.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0208.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Actual 2010 amending law; complete current eligibility and transitions not cleared.",
      "id": "R0208.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "cr-law8794",
  "status": "source record and limitation"
}
```

### R0209

| dominican-web: FAQ 1-2 | https://cnzfe.gob.do/faqs/ | 2026-11-16 | Authority FAQ; law PDF recovery failed; full withholding/duration not confirmed. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    349,
    349
  ],
  "id": "R0209",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "dominican-web: FAQ 1-2",
      "id": "R0209.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://cnzfe.gob.do/faqs/",
      "id": "R0209.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0209.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Authority FAQ; law PDF recovery failed; full withholding/duration not confirmed.",
      "id": "R0209.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "dominican-web",
  "status": "source record and limitation"
}
```

### R0210

| uruguay-benefits: body | https://www.gub.uy/ministerio-economia-finanzas/politicas-y-gestion/beneficios-tributarios-para-zonas-francas | 2026-11-16 | MEF 2020 overview; current IMCD overlay separately read. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    350,
    350
  ],
  "id": "R0210",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "uruguay-benefits: body",
      "id": "R0210.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://www.gub.uy/ministerio-economia-finanzas/politicas-y-gestion/beneficios-tributarios-para-zonas-francas",
      "id": "R0210.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0210.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "MEF 2020 overview; current IMCD overlay separately read.",
      "id": "R0210.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "uruguay-benefits",
  "status": "source record and limitation"
}
```

### R0211

| uruguay-imcd 2026: scope | https://www.impo.com.uy/bases/decretos/254-2026 | 2026-11-16 | Actual decree published 13 November 2026; preamble/Articles 1–3 read; Title 21, commencement and computation unread. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    351,
    351
  ],
  "id": "R0211",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "uruguay-imcd 2026: scope",
      "id": "R0211.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://www.impo.com.uy/bases/decretos/254-2026",
      "id": "R0211.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0211.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Actual decree published 13 November 2026; preamble/Articles 1–3 read; Title 21, commencement and computation unread.",
      "id": "R0211.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "uruguay-imcd2026",
  "status": "source record and limitation"
}
```

### R0212

| bahamas-law 2024: sections 1-5 | https://laws.bahamas.gov.bs/cms/images/LEGISLATION/PRINCIPAL/2024/2024-0058/2024-0058_1.pdf | 2026-11-16 | Printed pages 3–7 visually read; selected native passages checked against images; full GloBE calculation unread. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    352,
    352
  ],
  "id": "R0212",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "bahamas-law 2024: sections 1-5",
      "id": "R0212.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://laws.bahamas.gov.bs/cms/images/LEGISLATION/PRINCIPAL/2024/2024-0058/2024-0058_1.pdf",
      "id": "R0212.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0212.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Printed pages 3–7 visually read; selected native passages checked against images; full GloBE calculation unread.",
      "id": "R0212.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "bahamas-law2024",
  "status": "source record and limitation"
}
```

### R0213

| bahamas-amend 2026: whole | https://laws.bahamas.gov.bs/cms/images/LEGISLATION/AMENDING/2026/2026-0025A/2026-0025A.pdf | 2026-11-16 | Actual amending Act sections 1–7 read; administrative changes do not remove the initial-year condition. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    353,
    353
  ],
  "id": "R0213",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "bahamas-amend 2026: whole",
      "id": "R0213.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://laws.bahamas.gov.bs/cms/images/LEGISLATION/AMENDING/2026/2026-0025A/2026-0025A.pdf",
      "id": "R0213.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0213.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Actual amending Act sections 1–7 read; administrative changes do not remove the initial-year condition.",
      "id": "R0213.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "bahamas-amend2026",
  "status": "source record and limitation"
}
```

### R0214

| bermuda-cit: rate, scope, commencement | https://www.bermudalaws.bm/Laws/Annual%20Law/Acts/2023/Corporate%20Income%20Tax%20Act%202023 | 2026-11-16 | Consolidated through 2025:12; later 2026 amendment unread; no full current entity clearance. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    354,
    354
  ],
  "id": "R0214",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "bermuda-cit: rate, scope, commencement",
      "id": "R0214.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://www.bermudalaws.bm/Laws/Annual%20Law/Acts/2023/Corporate%20Income%20Tax%20Act%202023",
      "id": "R0214.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0214.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Consolidated through 2025:12; later 2026 amendment unread; no full current entity clearance.",
      "id": "R0214.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "bermuda-cit",
  "status": "source record and limitation"
}
```

### R0215

| barbados-act 2024: rate | https://bra.gov.bb/attachment?file=Attachments%2FIncome+Tax+%28Amendment+and+Validation%29+Act%2C+2024-15.pdf&name=Income+Tax+%28Amendment+and+Validation%29+Act%2C+2024-15 | 2026-11-16 | Selected operative clauses/authority paragraphs read with neighbors; entity eligibility and unread cross-references not cleared. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    355,
    355
  ],
  "id": "R0215",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "barbados-act 2024: rate",
      "id": "R0215.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://bra.gov.bb/attachment?file=Attachments%2FIncome+Tax+%28Amendment+and+Validation%29+Act%2C+2024-15.pdf&name=Income+Tax+%28Amendment+and+Validation%29+Act%2C+2024-15",
      "id": "R0215.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0215.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Selected operative clauses/authority paragraphs read with neighbors; entity eligibility and unread cross-references not cleared.",
      "id": "R0215.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "barbados-act2024",
  "status": "source record and limitation"
}
```

### R0216

| barbados-act 2025: substance | https://bra.gov.bb/attachment?file=Attachments%2fIncome+Tax+(Amendment)+Act%2c+2025-30.pdf&name=Income+Tax+(Amendment)+Act%2c+2025-30 | 2026-11-16 | Selected operative clauses/authority paragraphs read with neighbors; entity eligibility and unread cross-references not cleared. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    356,
    356
  ],
  "id": "R0216",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "barbados-act 2025: substance",
      "id": "R0216.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://bra.gov.bb/attachment?file=Attachments%2fIncome+Tax+(Amendment)+Act%2c+2025-30.pdf&name=Income+Tax+(Amendment)+Act%2c+2025-30",
      "id": "R0216.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0216.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Selected operative clauses/authority paragraphs read with neighbors; entity eligibility and unread cross-references not cleared.",
      "id": "R0216.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "barbados-act2025",
  "status": "source record and limitation"
}
```

### R0217

| madeira 36 a: whole | https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/bf_rep/Pages/ebf-artigo-36-ordm-a.aspx | 2026-11-16 | Full actual 36-A paragraphs 1–18 read; complete EU State-aid approval and entity application not cleared. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    357,
    357
  ],
  "id": "R0217",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "madeira 36 a: whole",
      "id": "R0217.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/bf_rep/Pages/ebf-artigo-36-ordm-a.aspx",
      "id": "R0217.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0217.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Full actual 36-A paragraphs 1–18 read; complete EU State-aid approval and entity application not cleared.",
      "id": "R0217.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "madeira36a",
  "status": "source record and limitation"
}
```

### R0218

| gibraltar-corporate: body | https://www.gibraltar.gov.gi/income-tax-office/businesses-and-corporations/corporate | 2026-11-16 | Selected operative clauses/authority paragraphs read with neighbors; entity eligibility and unread cross-references not cleared. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    358,
    358
  ],
  "id": "R0218",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "gibraltar-corporate: body",
      "id": "R0218.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://www.gibraltar.gov.gi/income-tax-office/businesses-and-corporations/corporate",
      "id": "R0218.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0218.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Selected operative clauses/authority paragraphs read with neighbors; entity eligibility and unread cross-references not cleared.",
      "id": "R0218.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "gibraltar-corporate",
  "status": "source record and limitation"
}
```

### R0219

| mt-cap 123: company-rate | https://legislation.mt/eli/cap/123/eng/pdf | 2026-11-16 | Selected operative clauses/authority paragraphs read with neighbors; entity eligibility and unread cross-references not cleared. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    359,
    359
  ],
  "id": "R0219",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "mt-cap 123: company-rate",
      "id": "R0219.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://legislation.mt/eli/cap/123/eng/pdf",
      "id": "R0219.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0219.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Selected operative clauses/authority paragraphs read with neighbors; entity eligibility and unread cross-references not cleared.",
      "id": "R0219.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "mt-cap123",
  "status": "source record and limitation"
}
```

### R0220

| mt-cap 372: refunds | https://legislation.mt/eli/cap/372/eng/pdf | 2026-11-16 | Selected 48(4)/(4A) refund conditions; remaining historical 4 Ab and claims administration unread. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    360,
    360
  ],
  "id": "R0220",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "mt-cap 372: refunds",
      "id": "R0220.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://legislation.mt/eli/cap/372/eng/pdf",
      "id": "R0220.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0220.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Selected 48(4)/(4A) refund conditions; remaining historical 4 Ab and claims administration unread.",
      "id": "R0220.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "mt-cap372",
  "status": "source record and limitation"
}
```

### R0221

| lux-rates: body | https://impotsdirects.public.lu/fr/az/c/charg_fisc.html | 2026-11-16 | Selected operative clauses/authority paragraphs read with neighbors; entity eligibility and unread cross-references not cleared. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    361,
    361
  ],
  "id": "R0221",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "lux-rates: body",
      "id": "R0221.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://impotsdirects.public.lu/fr/az/c/charg_fisc.html",
      "id": "R0221.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0221.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Selected operative clauses/authority paragraphs read with neighbors; entity eligibility and unread cross-references not cleared.",
      "id": "R0221.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "lux-rates",
  "status": "source record and limitation"
}
```

### R0222

| lux-tariff: body | https://impotsdirects.public.lu/fr/az/t/tarif-applicable-collectivites/tarif-collect.html | 2026-11-16 | Selected operative clauses/authority paragraphs read with neighbors; entity eligibility and unread cross-references not cleared. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    362,
    362
  ],
  "id": "R0222",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "lux-tariff: body",
      "id": "R0222.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://impotsdirects.public.lu/fr/az/t/tarif-applicable-collectivites/tarif-collect.html",
      "id": "R0222.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0222.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Selected operative clauses/authority paragraphs read with neighbors; entity eligibility and unread cross-references not cleared.",
      "id": "R0222.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "lux-tariff",
  "status": "source record and limitation"
}
```

### R0223

| ireland-rates: body | https://www.revenue.ie/en/companies-and-charities/corporation-tax-for-companies/corporation-tax/basis-of-charge.aspx | 2026-11-16 | Selected operative clauses/authority paragraphs read with neighbors; entity eligibility and unread cross-references not cleared. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    363,
    363
  ],
  "id": "R0223",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "ireland-rates: body",
      "id": "R0223.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://www.revenue.ie/en/companies-and-charities/corporation-tax-for-companies/corporation-tax/basis-of-charge.aspx",
      "id": "R0223.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0223.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Selected operative clauses/authority paragraphs read with neighbors; entity eligibility and unread cross-references not cleared.",
      "id": "R0223.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "ireland-rates",
  "status": "source record and limitation"
}
```

### R0224

| jersey-company-web: body | https://www.gov.je/industry/businessadvicehub/businesstaxessocialsecurity/pages/companytax.aspx | 2026-11-16 | Selected operative clauses/authority paragraphs read with neighbors; entity eligibility and unread cross-references not cleared. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    364,
    364
  ],
  "id": "R0224",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "jersey-company-web: body",
      "id": "R0224.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://www.gov.je/industry/businessadvicehub/businesstaxessocialsecurity/pages/companytax.aspx",
      "id": "R0224.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0224.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Selected operative clauses/authority paragraphs read with neighbors; entity eligibility and unread cross-references not cleared.",
      "id": "R0224.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "jersey-company-web",
  "status": "source record and limitation"
}
```

### R0225

| jersey-law-web: scope-rate | https://jerseylaw.je/laws/current/l_7_2025 | 2026-11-16 | Official 2026 consolidation Articles 1–12; remaining calculations/cross-references unread. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    365,
    365
  ],
  "id": "R0225",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "jersey-law-web: scope-rate",
      "id": "R0225.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://jerseylaw.je/laws/current/l_7_2025",
      "id": "R0225.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0225.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Official 2026 consolidation Articles 1–12; remaining calculations/cross-references unread.",
      "id": "R0225.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "jersey-law-web",
  "status": "source record and limitation"
}
```

### R0226

| jersey-comm-web: commencement | https://jerseylaw.je/laws/current/l_7_2025 | 2026-11-16 | Actual Article 43 commencement; no additional filing rule inferred. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    366,
    366
  ],
  "id": "R0226",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "jersey-comm-web: commencement",
      "id": "R0226.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://jerseylaw.je/laws/current/l_7_2025",
      "id": "R0226.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0226.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Actual Article 43 commencement; no additional filing rule inferred.",
      "id": "R0226.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "jersey-comm-web",
  "status": "source record and limitation"
}
```

### R0227

| jersey-p 2-web: body | https://www.gov.je/taxesmoney/incometax/companies/guidelines/pages/oecdpillars.aspx | 2026-11-16 | Selected operative clauses/authority paragraphs read with neighbors; entity eligibility and unread cross-references not cleared. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    367,
    367
  ],
  "id": "R0227",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "jersey-p 2-web: body",
      "id": "R0227.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://www.gov.je/taxesmoney/incometax/companies/guidelines/pages/oecdpillars.aspx",
      "id": "R0227.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0227.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Selected operative clauses/authority paragraphs read with neighbors; entity eligibility and unread cross-references not cleared.",
      "id": "R0227.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "jersey-p2-web",
  "status": "source record and limitation"
}
```

### R0228

| monaco-current: scope, rate | https://legimonaco.mc/tnc/ordonnance/1964/03-19-3.152/ | 2026-11-16 | Selected operative clauses/authority paragraphs read with neighbors; entity eligibility and unread cross-references not cleared. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    368,
    368
  ],
  "id": "R0228",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "monaco-current: scope, rate",
      "id": "R0228.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://legimonaco.mc/tnc/ordonnance/1964/03-19-3.152/",
      "id": "R0228.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0228.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Selected operative clauses/authority paragraphs read with neighbors; entity eligibility and unread cross-references not cleared.",
      "id": "R0228.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "monaco-current",
  "status": "source record and limitation"
}
```

### R0229

| monaco-oct 2026: operative | https://journaldemonaco.gouv.mc/fr/Journaux/2026/Journal-8823/Ordonnance-Souveraine-n-12.211-du-23-octobre-2026-modifiant-l-Ordonnance-Souveraine-n-3.152-du-19-mars-1964-instituant-un-impot-sur-les-benefices-modifiee | 2026-11-16 | Selected operative clauses/authority paragraphs read with neighbors; entity eligibility and unread cross-references not cleared. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    369,
    369
  ],
  "id": "R0229",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "monaco-oct 2026: operative",
      "id": "R0229.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://journaldemonaco.gouv.mc/fr/Journaux/2026/Journal-8823/Ordonnance-Souveraine-n-12.211-du-23-octobre-2026-modifiant-l-Ordonnance-Souveraine-n-3.152-du-19-mars-1964-instituant-un-impot-sur-les-benefices-modifiee",
      "id": "R0229.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0229.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Selected operative clauses/authority paragraphs read with neighbors; entity eligibility and unread cross-references not cleared.",
      "id": "R0229.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "monaco-oct2026",
  "status": "source record and limitation"
}
```

### R0230

| andorra-cit: rate | https://www.e-tramits.ad/tramits/ca/impostos/is | 2026-11-16 | Selected operative clauses/authority paragraphs read with neighbors; entity eligibility and unread cross-references not cleared. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    370,
    370
  ],
  "id": "R0230",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "andorra-cit: rate",
      "id": "R0230.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://www.e-tramits.ad/tramits/ca/impostos/is",
      "id": "R0230.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0230.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Selected operative clauses/authority paragraphs read with neighbors; entity eligibility and unread cross-references not cleared.",
      "id": "R0230.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "andorra-cit",
  "status": "source record and limitation"
}
```

### R0231

| mauritius-act 2026-full: Freeport, rates, partial-exemption, QDMTT, QDMTT-charging | https://www.mra.mu/download/ITAConsolidated.pdf | 2026-11-16 | MRA informational internet consolidation disclaims legal responsibility; selected clauses, not all 536 pages. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    371,
    371
  ],
  "id": "R0231",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "mauritius-act 2026-full: Freeport, rates, partial-exemption, QDMTT, QDMTT-charging",
      "id": "R0231.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://www.mra.mu/download/ITAConsolidated.pdf",
      "id": "R0231.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0231.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "MRA informational internet consolidation disclaims legal responsibility; selected clauses, not all 536 pages.",
      "id": "R0231.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "mauritius-act2026-full",
  "status": "source record and limitation"
}
```

### R0232

| labuan-act 2026: scope-rates, deleted-election, non-trading | https://www.labuanfsa.gov.my/clients/asset_717D5286-17F8-4620-B852-83CA4FFCC30C/contentms/img/documents/regulations/legislation/2026/LBATA-updated-2026_19102026.pdf | 2026-11-16 | AGC cover: NOT AN AUTHENTIC TEXT. Gazette originals and detailed substance rules unread. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    372,
    372
  ],
  "id": "R0232",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "labuan-act 2026: scope-rates, deleted-election, non-trading",
      "id": "R0232.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://www.labuanfsa.gov.my/clients/asset_717D5286-17F8-4620-B852-83CA4FFCC30C/contentms/img/documents/regulations/legislation/2026/LBATA-updated-2026_19102026.pdf",
      "id": "R0232.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0232.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "AGC cover: NOT AN AUTHENTIC TEXT. Gazette originals and detailed substance rules unread.",
      "id": "R0232.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "labuan-act2026",
  "status": "source record and limitation"
}
```

### R0233

| nigeria-tax 2025: scope, commencement, free-zone | https://nass.gov.ng/documents/download/11249 | 2026-11-16 | Official copy has currency-glyph and incomplete/conjunctive-condition anomalies; no repair or filing clearance. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    373,
    373
  ],
  "id": "R0233",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "nigeria-tax 2025: scope, commencement, free-zone",
      "id": "R0233.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://nass.gov.ng/documents/download/11249",
      "id": "R0233.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0233.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Official copy has currency-glyph and incomplete/conjunctive-condition anomalies; no repair or filing clearance.",
      "id": "R0233.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "nigeria-tax2025",
  "status": "source record and limitation"
}
```

### R0234

| kenya-income 2026: rates, EPZ | https://www.kra.go.ke/images/publications/Income-Tax-Act-2026.pdf | 2026-11-16 | Selected operative clauses/authority paragraphs read with neighbors; entity eligibility and unread cross-references not cleared. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    374,
    374
  ],
  "id": "R0234",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "kenya-income 2026: rates, EPZ",
      "id": "R0234.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://www.kra.go.ke/images/publications/Income-Tax-Act-2026.pdf",
      "id": "R0234.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0234.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Selected operative clauses/authority paragraphs read with neighbors; entity eligibility and unread cross-references not cleared.",
      "id": "R0234.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "kenya-income2026",
  "status": "source record and limitation"
}
```

### R0235

| kenya-finance 2026: Third Schedule | https://www.kra.go.ke/images/publications/Finance-Act-2026.pdf | 2026-11-16 | Section 21 and commencement read; unrelated finance changes not whole-read. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    375,
    375
  ],
  "id": "R0235",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "kenya-finance 2026: Third Schedule",
      "id": "R0235.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://www.kra.go.ke/images/publications/Finance-Act-2026.pdf",
      "id": "R0235.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0235.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Section 21 and commencement read; unrelated finance changes not whole-read.",
      "id": "R0235.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "kenya-finance2026",
  "status": "source record and limitation"
}
```

### R0236

| sa-rates 2026: CIT | https://www.sars.gov.za/about/sars-tax-and-customs-system/budget/budget-2026-frequently-asked-questions/ | 2026-11-16 | SARS headline guidance; complete current section 12R not cleared. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    376,
    376
  ],
  "id": "R0236",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "sa-rates 2026: CIT",
      "id": "R0236.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://www.sars.gov.za/about/sars-tax-and-customs-system/budget/budget-2026-frequently-asked-questions/",
      "id": "R0236.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0236.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "SARS headline guidance; complete current section 12R not cleared.",
      "id": "R0236.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "sa-rates2026",
  "status": "source record and limitation"
}
```

### R0237

| botswana-companies: rates | https://www.burs.org.bw/index.php/tax/income-tax/companies | 2026-11-16 | BURS overview; full certification and 2026 legislative changes not cleared. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    377,
    377
  ],
  "id": "R0237",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "botswana-companies: rates",
      "id": "R0237.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://www.burs.org.bw/index.php/tax/income-tax/companies",
      "id": "R0237.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0237.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "BURS overview; full certification and 2026 legislative changes not cleared.",
      "id": "R0237.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "botswana-companies",
  "status": "source record and limitation"
}
```

### R0238

| oecd-harmful: overview | https://www.oecd.org/en/topics/harmful-tax-practices.html | 2026-11-16 | Selected overview; individual regime results and national ESA statutes not cleared. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    378,
    378
  ],
  "id": "R0238",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "oecd-harmful: overview",
      "id": "R0238.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://www.oecd.org/en/topics/harmful-tax-practices.html",
      "id": "R0238.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0238.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Selected overview; individual regime results and national ESA statutes not cleared.",
      "id": "R0238.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "oecd-harmful",
  "status": "source record and limitation"
}
```

### R0239

| uae-142: scope | https://tax.gov.ae/Datafolder/Files/Legislation/Cabinet-Decision-No-142-of-2024-on-Top-up-Tax-on-MNEs.pdf | 2026-11-16 | Main Articles 1–3 and annex 1.1–1.5 with neighboring 1.6 read; remaining calculations not cleared. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    379,
    379
  ],
  "id": "R0239",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "uae-142: scope",
      "id": "R0239.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://tax.gov.ae/Datafolder/Files/Legislation/Cabinet-Decision-No-142-of-2024-on-Top-up-Tax-on-MNEs.pdf",
      "id": "R0239.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0239.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Main Articles 1–3 and annex 1.1–1.5 with neighboring 1.6 read; remaining calculations not cleared.",
      "id": "R0239.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "uae-142",
  "status": "source record and limitation"
}
```

### R0240

| oecd-sbs 2026: intro | https://www.oecd.org/content/dam/oecd/en/topics/policy-sub-issues/global-minimum-tax/side-by-side-package.pdf | 2026-11-16 | OECD 2026, CC BY 4.0: pages 1–9/paragraphs 1–26 only; remaining 79 pages unread; no OECD endorsement. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    380,
    380
  ],
  "id": "R0240",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "oecd-sbs 2026: intro",
      "id": "R0240.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://www.oecd.org/content/dam/oecd/en/topics/policy-sub-issues/global-minimum-tax/side-by-side-package.pdf",
      "id": "R0240.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0240.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "OECD 2026, CC BY 4.0: pages 1–9/paragraphs 1–26 only; remaining 79 pages unread; no OECD endorsement.",
      "id": "R0240.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "oecd-sbs2026",
  "status": "source record and limitation"
}
```

### R0241

| hk-p 2-act 2025: charge-dates | https://www.ird.gov.hk/eng/pdf/es12025292321.pdf | 2026-11-16 | Actual 26AE–26AF; full schedules, calculation and later UTPR notice not cleared. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    381,
    381
  ],
  "id": "R0241",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "hk-p 2-act 2025: charge-dates",
      "id": "R0241.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://www.ird.gov.hk/eng/pdf/es12025292321.pdf",
      "id": "R0241.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0241.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Actual 26AE–26AF; full schedules, calculation and later UTPR notice not cleared.",
      "id": "R0241.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "hk-p2-act2025",
  "status": "source record and limitation"
}
```

### R0242

| sg-p 2-iras: body | https://www.iras.gov.sg/taxes/pillar-2-top-up-taxes/global-anti-base-erosion-%28globe%29-rules-and-domestic-top-up-tax-%28dtt%29 | 2026-11-16 | Current IRAS guidance including 2026 update; actual SSO Act route failed; not full statutory clearance. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    382,
    382
  ],
  "id": "R0242",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "sg-p 2-iras: body",
      "id": "R0242.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://www.iras.gov.sg/taxes/pillar-2-top-up-taxes/global-anti-base-erosion-%28globe%29-rules-and-domestic-top-up-tax-%28dtt%29",
      "id": "R0242.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0242.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Current IRAS guidance including 2026 update; actual SSO Act route failed; not full statutory clearance.",
      "id": "R0242.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "sg-p2-iras",
  "status": "source record and limitation"
}
```

### R0243

| mauritius-qdmtt 2026: commencement | https://mra.mu/download/IT_QDMT_Reg26.pdf | 2026-11-16 | Regulation 29, neighboring 28 and opening definitions read; remaining calculation rules not cleared. |

```json
{
  "context_only_blocks": [],
  "current_lines": [
    383,
    383
  ],
  "id": "R0243",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "mauritius-qdmtt 2026: commencement",
      "id": "R0243.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "https://mra.mu/download/IT_QDMT_Reg26.pdf",
      "id": "R0243.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "2026-11-16",
      "id": "R0243.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Regulation 29, neighboring 28 and opening definitions read; remaining calculation rules not cleared.",
      "id": "R0243.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Sources",
  "source_read_record": "mauritius-qdmtt2026",
  "status": "source record and limitation"
}
```

### R0244

### Not yet confirmed: individual national source requests

```json
{
  "context_only_blocks": [],
  "current_lines": [
    385,
    385
  ],
  "id": "R0244",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "### Not yet confirmed: individual national source requests",
      "id": "R0244.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "heading"
}
```

### R0245

Not yet confirmed: **UAE free zones:** the complete MD 84 audit standard and current prescribed TP-document thresholds; obtain those instruments before filing.

```json
{
  "context_only_blocks": [
    "uae-2026:qualification",
    "uae-2026:TP",
    "uae-2026:TP-files",
    "uae-229:conditions"
  ],
  "current_lines": [
    387,
    387
  ],
  "id": "R0245",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **UAE free zones:** the complete MD 84 audit standard and current prescribed TP-document thresholds",
      "id": "R0245.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "obtain those instruments before filing.",
      "id": "R0245.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    56
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0246

Not yet confirmed: **Important activity qualifiers:** the licence and full activity-specific application to a proposed business; a sector label is insufficient.

```json
{
  "context_only_blocks": [
    "uae-229:definitions-activity-conditions"
  ],
  "current_lines": [
    389,
    389
  ],
  "id": "R0246",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **Important activity qualifiers:** the licence and full activity-specific application to a proposed business",
      "id": "R0246.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "a sector label is insufficient.",
      "id": "R0246.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    63
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0247

Not yet confirmed: **Qualifying IP:** an asset’s eligibility and complete calculation in a proposed arrangement; no patent-only assumption or generic IP exemption.

```json
{
  "context_only_blocks": [
    "uae-100:definitions",
    "uae-100:IP",
    "uae-229:IP"
  ],
  "current_lines": [
    391,
    391
  ],
  "id": "R0247",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **Qualifying IP:** an asset’s eligibility and complete calculation in a proposed arrangement",
      "id": "R0247.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "no patent-only assumption or generic IP exemption.",
      "id": "R0247.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    64,
    262
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0248

Not yet confirmed: **UAE free zones:** each current registrar boundary, permitted activity, licence, claimed regulator/structure and VAT Designated Zone status below. Ordinary registrar/regulation recovery did not establish filing-ready current procedures; do not rely on the old marketing labels.

```json
{
  "context_only_blocks": [],
  "current_lines": [
    393,
    393
  ],
  "id": "R0248",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **UAE free zones:** each current registrar boundary, permitted activity, licence, claimed regulator/structure and VAT Designated Zone status below.",
      "id": "R0248.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Ordinary registrar/regulation recovery did not establish filing-ready current procedures",
      "id": "R0248.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "do not rely on the old marketing labels.",
      "id": "R0248.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    73,
    74,
    75,
    76,
    77,
    78,
    79,
    80,
    81,
    82,
    83,
    84,
    85,
    86,
    87
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0249

Not yet confirmed: **QFC is in Qatar:** the original common-law-jurisdiction, financial-services/asset-management licence and general “substance: yes” cells as complete current legal-entity/regulatory conditions. The tax provisions above do not establish permission to conduct regulated business. The regulations’ Article 4 makes their English text the official original; this source status differs from the UAE unofficial English translations.

```json
{
  "context_only_blocks": [
    "qfc-tax2026:language"
  ],
  "current_lines": [
    395,
    395
  ],
  "id": "R0249",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **QFC is in Qatar:** the original common-law-jurisdiction, financial-services/asset-management licence and general “substance: yes” cells as complete current legal-entity/regulatory conditions.",
      "id": "R0249.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "The tax provisions above do not establish permission to conduct regulated business.",
      "id": "R0249.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "The regulations’ Article 4 makes their English text the official original",
      "id": "R0249.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "this source status differs from the UAE unofficial English translations.",
      "id": "R0249.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    98,
    99,
    100
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0250

Not yet confirmed: **King Abdullah Economic City (KAEC):** entity start date, complete sector/activity eligibility, each payment’s WHT conditions and full customs/VAT procedure.

```json
{
  "context_only_blocks": [
    "sa-sez-current:income-wht"
  ],
  "current_lines": [
    397,
    397
  ],
  "id": "R0250",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **King Abdullah Economic City (KAEC):** entity start date, complete sector/activity eligibility, each payment’s WHT conditions and full customs/VAT procedure.",
      "id": "R0250.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    110
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0251

Not yet confirmed: **Jazan:** entity start date, complete sector/activity eligibility, each payment’s WHT conditions and full customs/VAT procedure.

```json
{
  "context_only_blocks": [
    "sa-sez-current:income-wht"
  ],
  "current_lines": [
    399,
    399
  ],
  "id": "R0251",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **Jazan:** entity start date, complete sector/activity eligibility, each payment’s WHT conditions and full customs/VAT procedure.",
      "id": "R0251.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    111
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0252

Not yet confirmed: **Ras Al Khair:** entity start date, complete sector/activity eligibility, each payment’s WHT conditions and full customs/VAT procedure.

```json
{
  "context_only_blocks": [
    "sa-sez-current:income-wht"
  ],
  "current_lines": [
    401,
    401
  ],
  "id": "R0252",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **Ras Al Khair:** entity start date, complete sector/activity eligibility, each payment’s WHT conditions and full customs/VAT procedure.",
      "id": "R0252.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    112
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0253

Not yet confirmed: **Cloud Computing SEZ:** the proposed operator’s current authorised cloud/data-centre activity and detailed transaction treatment.

```json
{
  "context_only_blocks": [
    "sa-sez-current:cloud"
  ],
  "current_lines": [
    403,
    403
  ],
  "id": "R0253",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **Cloud Computing SEZ:** the proposed operator’s current authorised cloud/data-centre activity and detailed transaction treatment.",
      "id": "R0253.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    113
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0254

Not yet confirmed: **NEOM:** the asserted bespoke tax regime for energy, tourism and urban technology, its eligibility, CIT, WHT and customs terms. The old “oxygen-based” sector label has no recovered operative support and must not be used as a tax category.

```json
{
  "context_only_blocks": [],
  "current_lines": [
    405,
    405
  ],
  "id": "R0254",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **NEOM:** the asserted bespoke tax regime for energy, tourism and urban technology, its eligibility, CIT, WHT and customs terms.",
      "id": "R0254.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "The old “oxygen-based” sector label has no recovered operative support and must not be used as a tax category.",
      "id": "R0254.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    114
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0255

Not yet confirmed: **Riyadh Integrated Logistics Bonded Zone (ILBZ):** the old **0% CIT for 50 years**, 0% WHT and 0% customs proposals, qualifying logistics/bonded re-export scope and commencement. The official GACA law route was located but the operative body was not recovered. Do not import the separate geographic-SEZ rates.

```json
{
  "context_only_blocks": [],
  "current_lines": [
    407,
    407
  ],
  "id": "R0255",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **Riyadh Integrated Logistics Bonded Zone (ILBZ):** the old **0% CIT for 50 years**, 0% WHT and 0% customs proposals, qualifying logistics/bonded re-export scope and commencement.",
      "id": "R0255.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "The official GACA law route was located but the operative body was not recovered.",
      "id": "R0255.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Do not import the separate geographic-SEZ rates.",
      "id": "R0255.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    115
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0256

Not yet confirmed: **Saudi Arabia SEZs:** Saudi domestic Pillar Two adoption/current commencement. The original categorical “not adopted” is not current-law proof. Check the applicable local rule and parent IIR/UTPR for an in-scope group; even a qualifying SEZ rate does not itself quantify top-up tax.

```json
{
  "context_only_blocks": [],
  "current_lines": [
    409,
    409
  ],
  "id": "R0256",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **Saudi Arabia SEZs:** Saudi domestic Pillar Two adoption/current commencement.",
      "id": "R0256.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "The original categorical “not adopted” is not current-law proof.",
      "id": "R0256.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Check the applicable local rule and parent IIR/UTPR for an in-scope group",
      "id": "R0256.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "even a qualifying SEZ rate does not itself quantify top-up tax.",
      "id": "R0256.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    117,
    223
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0257

Not yet confirmed: **Hainan Free Trade Port:** the current **25% ordinary-rate** comparator and **15% qualifying-talent IIT cap**, including current talent/residence conditions. The extension is read in MOFCOM’s government legal republication, whose completeness/currentness disclaimer remains relevant; original MOF publication not recovered.

```json
{
  "context_only_blocks": [
    "hainan-base:operative",
    "hainan-extension:extension"
  ],
  "current_lines": [
    411,
    411
  ],
  "id": "R0257",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **Hainan Free Trade Port:** the current **25% ordinary-rate** comparator and **15% qualifying-talent IIT cap**, including current talent/residence conditions.",
      "id": "R0257.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "The extension is read in MOFCOM’s government legal republication, whose completeness/currentness disclaimer remains relevant",
      "id": "R0257.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "original MOF publication not recovered.",
      "id": "R0257.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    25,
    125
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0258

Not yet confirmed: **Shanghai Lin-gang:** the annex catalogue/current recognition procedure and the proposed enterprise’s eligibility. This is not discretionary 15% simply because the address is in the FTZ.

```json
{
  "context_only_blocks": [
    "lingang-base:operative"
  ],
  "current_lines": [
    413,
    413
  ],
  "id": "R0258",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **Shanghai Lin-gang:** the annex catalogue/current recognition procedure and the proposed enterprise’s eligibility.",
      "id": "R0258.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "This is not discretionary 15% simply because the address is in the FTZ.",
      "id": "R0258.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    126
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0259

Not yet confirmed: **Shenzhen Qianhai:** the actual base **15%** rate’s complete current industry/modern-services/FinTech, area, main-income and substantive-operation conditions; ordinary mainland source recovery failed. Do not grant relief from the extension alone.

```json
{
  "context_only_blocks": [
    "qianhai-extension:extension"
  ],
  "current_lines": [
    415,
    415
  ],
  "id": "R0259",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **Shenzhen Qianhai:** the actual base **15%** rate’s complete current industry/modern-services/FinTech, area, main-income and substantive-operation conditions",
      "id": "R0259.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "ordinary mainland source recovery failed.",
      "id": "R0259.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Do not grant relief from the extension alone.",
      "id": "R0259.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    127
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0260

Not yet confirmed: **Hengqin (Guangdong-Macao):** the enterprise’s exact catalogue match and current implementation; the entire 150-item catalogue was not read.

```json
{
  "context_only_blocks": [
    "hengqin-base:operative"
  ],
  "current_lines": [
    417,
    417
  ],
  "id": "R0260",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **Hengqin (Guangdong-Macao):** the enterprise’s exact catalogue match and current implementation",
      "id": "R0260.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "the entire 150-item catalogue was not read.",
      "id": "R0260.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    128
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0261

Not yet confirmed: **General FTZs: Shanghai, Tianjin, Fujian, Guangdong:** the old **25%** general CIT comparator and exact current customs/foreign-exchange relaxations for each named FTZ. An FTZ address is not a preferential CIT rate. Obtain the specific national/zone instruments for the flow.

```json
{
  "context_only_blocks": [],
  "current_lines": [
    419,
    419
  ],
  "id": "R0261",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **General FTZs: Shanghai, Tianjin, Fujian, Guangdong:** the old **25%** general CIT comparator and exact current customs/foreign-exchange relaxations for each named FTZ.",
      "id": "R0261.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "An FTZ address is not a preferential CIT rate.",
      "id": "R0261.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Obtain the specific national/zone instruments for the flow.",
      "id": "R0261.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    129
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0262

Not yet confirmed: **Hong Kong:** the full two-tier connected-entity restriction and the proposed taxpayer’s source, FSIE exception and filing position. The minimum-tax overlay below is separately read.

```json
{
  "context_only_blocks": [
    "hk-tax:scope-rates",
    "hk-fsie:dates-scope",
    "hk-fsie:taxpayers-treatment",
    "hk-tax:scope-rates-table"
  ],
  "current_lines": [
    421,
    421
  ],
  "id": "R0262",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **Hong Kong:** the full two-tier connected-entity restriction and the proposed taxpayer’s source, FSIE exception and filing position.",
      "id": "R0262.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "The minimum-tax overlay below is separately read.",
      "id": "R0262.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    130
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0263

Not yet confirmed: **India SEZs and GIFT City:** current enactment/status of the **2022–2023 DESH Bill** proposal and replacement/transitional effects; a mid-2025 “not enacted” statement cannot decide 2026 law.

```json
{
  "context_only_blocks": [
    "india-sez-web:section30"
  ],
  "current_lines": [
    423,
    423
  ],
  "id": "R0263",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **India SEZs and GIFT City:** current enactment/status of the **2022–2023 DESH Bill** proposal and replacement/transitional effects",
      "id": "R0263.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "a mid-2025 “not enacted” statement cannot decide 2026 law.",
      "id": "R0263.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    134
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0264

Not yet confirmed: **Legacy section 10AA:** the particular unit’s eligibility and exact Covid-relaxation effect; do not use the old flat **30 June 2020** sunset or the conclusion that “most” new units have minimal benefit as a substitute for the statutory test.

```json
{
  "context_only_blocks": [
    "india10aa-web:section10AA",
    "india-act2025:section144",
    "india-act2025:commencement"
  ],
  "current_lines": [
    425,
    425
  ],
  "id": "R0264",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **Legacy section 10AA:** the particular unit’s eligibility and exact Covid-relaxation effect",
      "id": "R0264.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "do not use the old flat **30 June 2020** sunset or the conclusion that “most” new units have minimal benefit as a substitute for the statutory test.",
      "id": "R0264.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    140
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0265

Not yet confirmed: **India GST:** the complete current IGST section 16/notifications/refund route for this supply, including the **authorised-operations** condition for supplies to an SEZ developer/unit. The original unconditional zero-rating assertion is unusable; the official current portal returned 502, and the court-hosted Act PDF was image-only and not visually read.

```json
{
  "context_only_blocks": [],
  "current_lines": [
    427,
    427
  ],
  "id": "R0265",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **India GST:** the complete current IGST section 16/notifications/refund route for this supply, including the **authorised-operations** condition for supplies to an SEZ developer/unit.",
      "id": "R0265.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "The original unconditional zero-rating assertion is unusable",
      "id": "R0265.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "the official current portal returned 502, and the court-hosted Act PDF was image-only and not visually read.",
      "id": "R0265.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    141
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0266

Not yet confirmed: **GIFT City / IFSC:** IFSCA Act **2019** licensing and the proposed unit’s full eligibility/current filing route; this is not a blanket 20-year CIT exemption.

```json
{
  "context_only_blocks": [
    "india-fa2026:IFSC",
    "india-fa2026:rate",
    "india-act2025:section147"
  ],
  "current_lines": [
    429,
    429
  ],
  "id": "R0266",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **GIFT City / IFSC:** IFSCA Act **2019** licensing and the proposed unit’s full eligibility/current filing route",
      "id": "R0266.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "this is not a blanket 20-year CIT exemption.",
      "id": "R0266.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    142
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0267

Not yet confirmed: **Panama Colón Free Trade Zone:** the proposed re-export’s current customs-duty exemption and every transaction’s sourcing/eligibility; the former simple **0% re-export profits/customs** cell is not filing guidance.

```json
{
  "context_only_blocks": [
    "panama-zlc-law:activities",
    "panama-zlc-law:fiscal"
  ],
  "current_lines": [
    431,
    431
  ],
  "id": "R0267",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **Panama Colón Free Trade Zone:** the proposed re-export’s current customs-duty exemption and every transaction’s sourcing/eligibility",
      "id": "R0267.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "the former simple **0% re-export profits/customs** cell is not filing guidance.",
      "id": "R0267.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    150
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0268

Not yet confirmed: **Panama City of Knowledge / Ciudad del Saber:** exact current IT, training and R&D tax incentives, authorised entity/activity, instrument and duration. Colón Article 47’s recognition of separately licensed special regimes does not itself supply this regime’s exemption.

```json
{
  "context_only_blocks": [
    "panama-zlc-law:activities"
  ],
  "current_lines": [
    433,
    433
  ],
  "id": "R0268",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **Panama City of Knowledge / Ciudad del Saber:** exact current IT, training and R&D tax incentives, authorised entity/activity, instrument and duration.",
      "id": "R0268.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Colón Article 47’s recognition of separately licensed special regimes does not itself supply this regime’s exemption.",
      "id": "R0268.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    151
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0269

Not yet confirmed: **Costa Rica Zonas Francas:** complete current consolidated eligibility/category, manufacturing/services and location rules or later amendment effects; do not award the historical terms to every applicant.

```json
{
  "context_only_blocks": [
    "cr-law8794:Article20g"
  ],
  "current_lines": [
    435,
    435
  ],
  "id": "R0269",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **Costa Rica Zonas Francas:** complete current consolidated eligibility/category, manufacturing/services and location rules or later amendment effects",
      "id": "R0269.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "do not award the historical terms to every applicant.",
      "id": "R0269.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    152
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0270

Not yet confirmed: **Dominican Republic Zonas Francas:** actual current statutory eligibility, duration/renewal, export-oriented scope and the original blanket **100% withholding** claim; the law PDF recovery failed and the FAQ list does not prove all WHT is exempt.

```json
{
  "context_only_blocks": [
    "dominican-web:FAQ1-2"
  ],
  "current_lines": [
    437,
    437
  ],
  "id": "R0270",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **Dominican Republic Zonas Francas:** actual current statutory eligibility, duration/renewal, export-oriented scope and the original blanket **100% withholding** claim",
      "id": "R0270.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "the law PDF recovery failed and the FAQ list does not prove all WHT is exempt.",
      "id": "R0270.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    153
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0271

Not yet confirmed: **Honduras ZEDE:** any currently usable bespoke tax regime, vested-right/transitional effects or individual company entitlement. The official court announcement of **20 September 2024** identifies an unconstitutionality decision; its operative judgment was not recovered/read. “Politically contested” is not an adequate legal-status conclusion and the announcement alone does not clear an investment.

```json
{
  "context_only_blocks": [],
  "current_lines": [
    439,
    439
  ],
  "id": "R0271",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **Honduras ZEDE:** any currently usable bespoke tax regime, vested-right/transitional effects or individual company entitlement.",
      "id": "R0271.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "The official court announcement of **20 September 2024** identifies an unconstitutionality decision",
      "id": "R0271.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "its operative judgment was not recovered/read.",
      "id": "R0271.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "“Politically contested” is not an adequate legal-status conclusion and the announcement alone does not clear an investment.",
      "id": "R0271.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    154
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0272

Not yet confirmed: **Uruguay Zonas Francas:** the particular user’s current contract/activities and complete IMCD commencement/calculation under Title 21; no blanket 100% final-tax exemption.

```json
{
  "context_only_blocks": [
    "uruguay-benefits:body",
    "uruguay-imcd2026:scope"
  ],
  "current_lines": [
    441,
    441
  ],
  "id": "R0272",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **Uruguay Zonas Francas:** the particular user’s current contract/activities and complete IMCD commencement/calculation under Title 21",
      "id": "R0272.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "no blanket 100% final-tax exemption.",
      "id": "R0272.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    155
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0273

Not yet confirmed: **Cayman Islands:** the current no-CIT/no-WHT/no-capital-gains outcomes and Exempted Company conditions for the proposed entity; the government archive is not a complete current-law package. The old **QDMTT from 2025** assertion has no recovered enacted instrument and must not be used. Assess foreign IIR/UTPR exposure separately.

```json
{
  "context_only_blocks": [],
  "current_lines": [
    443,
    443
  ],
  "id": "R0273",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **Cayman Islands:** the current no-CIT/no-WHT/no-capital-gains outcomes and Exempted Company conditions for the proposed entity",
      "id": "R0273.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "the government archive is not a complete current-law package.",
      "id": "R0273.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "The old **QDMTT from 2025** assertion has no recovered enacted instrument and must not be used.",
      "id": "R0273.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Assess foreign IIR/UTPR exposure separately.",
      "id": "R0273.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    156,
    222
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0274

Not yet confirmed: **BVI:** current **0% CIT/no withholding**, Business Companies Act vehicle rules, ESA **2018** scope/updates and the old undefined “TBI tax responses”. Official ESA PDF routes failed; these topics remain separate source requests. No domestic Pillar Two charge or absence of one is established.

```json
{
  "context_only_blocks": [],
  "current_lines": [
    445,
    445
  ],
  "id": "R0274",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **BVI:** current **0% CIT/no withholding**, Business Companies Act vehicle rules, ESA **2018** scope/updates and the old undefined “TBI tax responses”.",
      "id": "R0274.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Official ESA PDF routes failed",
      "id": "R0274.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "these topics remain separate source requests.",
      "id": "R0274.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "No domestic Pillar Two charge or absence of one is established.",
      "id": "R0274.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    157
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0275

Not yet confirmed: **Bahamas:** the old general “no CIT” assertion outside scope and the group’s full computation/elections/filings.

```json
{
  "context_only_blocks": [
    "bahamas-law2024:sections1-5",
    "bahamas-amend2026:whole",
    "oecd-global:overview"
  ],
  "current_lines": [
    447,
    447
  ],
  "id": "R0275",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **Bahamas:** the old general “no CIT” assertion outside scope and the group’s full computation/elections/filings.",
      "id": "R0275.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    158,
    221
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0276

Not yet confirmed: **Bermuda:** the pre-2025 blanket 0% claim and the latest **2026** amendment’s full effect on the proposed entity/calculation; read the amended operative package before execution.

```json
{
  "context_only_blocks": [
    "bermuda-cit:rate",
    "bermuda-cit:scope",
    "bermuda-cit:commencement"
  ],
  "current_lines": [
    449,
    449
  ],
  "id": "R0276",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **Bermuda:** the pre-2025 blanket 0% claim and the latest **2026** amendment’s full effect on the proposed entity/calculation",
      "id": "R0276.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "read the amended operative package before execution.",
      "id": "R0276.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    159,
    220
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0277

Not yet confirmed: **Barbados:** complete current IP incentives and the proposed entity’s tax category/minimum-tax exposure.

```json
{
  "context_only_blocks": [
    "barbados-act2024:rate",
    "barbados-act2025:substance"
  ],
  "current_lines": [
    451,
    451
  ],
  "id": "R0277",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **Barbados:** complete current IP incentives and the proposed entity’s tax category/minimum-tax exposure.",
      "id": "R0277.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    160
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0278

Not yet confirmed: **Madeira IBC / Madeira Free Zone:** the particular licence, job-count/asset/benefit-cap computation and complete EU State-aid approval package. The statute’s conditions cannot be replaced by “employment minimums”.

```json
{
  "context_only_blocks": [
    "madeira36a:whole"
  ],
  "current_lines": [
    453,
    453
  ],
  "id": "R0278",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **Madeira IBC / Madeira Free Zone:** the particular licence, job-count/asset/benefit-cap computation and complete EU State-aid approval package.",
      "id": "R0278.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "The statute’s conditions cannot be replaced by “employment minimums”.",
      "id": "R0278.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    168
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0279

Not yet confirmed: **Azores:** exact current national/regional CIT reduction, eligible entity, tax year, surcharges and other benefit conditions. The region is not proved to have a classic Madeira-style IBC regime. Current source leads give differing headline figures and a regional budget proposal is not enacted proof; do not quote a rate from this matrix.

```json
{
  "context_only_blocks": [],
  "current_lines": [
    455,
    455
  ],
  "id": "R0279",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **Azores:** exact current national/regional CIT reduction, eligible entity, tax year, surcharges and other benefit conditions.",
      "id": "R0279.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "The region is not proved to have a classic Madeira-style IBC regime.",
      "id": "R0279.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Current source leads give differing headline figures and a regional budget proposal is not enacted proof",
      "id": "R0279.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "do not quote a rate from this matrix.",
      "id": "R0279.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    169
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0280

Not yet confirmed: **Cyprus:** the original **12.5%** general CIT rate’s currentness, **80% IP deduction** eligibility/nexus (route to `ip-patent-box-matrix`) and shipping tonnage-tax scope. Current official 2026 tax-reform/return routes were located but returned 403; search excerpts suggesting a changed rate are not an operative source read. Do not use the old cell as current law.

```json
{
  "context_only_blocks": [],
  "current_lines": [
    457,
    457
  ],
  "id": "R0280",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **Cyprus:** the original **12.5%** general CIT rate’s currentness, **80% IP deduction** eligibility/nexus (route to `ip-patent-box-matrix`) and shipping tonnage-tax scope.",
      "id": "R0280.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Current official 2026 tax-reform/return routes were located but returned 403",
      "id": "R0280.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "search excerpts suggesting a changed rate are not an operative source read.",
      "id": "R0280.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Do not use the old cell as current law.",
      "id": "R0280.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    170
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0281

Not yet confirmed: **Gibraltar:** exact territorial-source/PE application and current minimum-tax package for the proposed entity.

```json
{
  "context_only_blocks": [
    "gibraltar-corporate:body"
  ],
  "current_lines": [
    459,
    459
  ],
  "id": "R0281",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **Gibraltar:** exact territorial-source/PE application and current minimum-tax package for the proposed entity.",
      "id": "R0281.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    171
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0282

Not yet confirmed: **Malta:** actual refund eligibility/administration, other company elections and any asserted Maltese **15% QDMTT**. The old automatic-QDMTT claim is withdrawn pending operative proof; local delay/IIR/UTPR and foreign group exposure are separate questions.

```json
{
  "context_only_blocks": [
    "mt-cap123:company-rate",
    "mt-cap372:refunds"
  ],
  "current_lines": [
    461,
    461
  ],
  "id": "R0282",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **Malta:** actual refund eligibility/administration, other company elections and any asserted Maltese **15% QDMTT**.",
      "id": "R0282.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "The old automatic-QDMTT claim is withdrawn pending operative proof",
      "id": "R0282.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "local delay/IIR/UTPR and foreign group exposure are separate questions.",
      "id": "R0282.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    172
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0283

Not yet confirmed: **Luxembourg:** the entity’s band/municipality, SOPARFI participation conditions, **80% IP box** and complete current QDMTT rules.

```json
{
  "context_only_blocks": [
    "lux-rates:body",
    "lux-tariff:body"
  ],
  "current_lines": [
    463,
    463
  ],
  "id": "R0283",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **Luxembourg:** the entity’s band/municipality, SOPARFI participation conditions, **80% IP box** and complete current QDMTT rules.",
      "id": "R0283.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    173
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0284

Not yet confirmed: **Ireland / IFSC legacy / section 110:** the particular section 110 securitisation SPV, KDB IP regime and current Pillar Two commencement/calculation, including the old **from 2024** assertion. The legacy IFSC label is not a separate general tax holiday.

```json
{
  "context_only_blocks": [
    "ireland-rates:body"
  ],
  "current_lines": [
    465,
    465
  ],
  "id": "R0284",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **Ireland / IFSC legacy / section 110:** the particular section 110 securitisation SPV, KDB IP regime and current Pillar Two commencement/calculation, including the old **from 2024** assertion.",
      "id": "R0284.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "The legacy IFSC label is not a separate general tax holiday.",
      "id": "R0284.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    174
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0285

Not yet confirmed: **Isle of Man:** the old general **0%**, banking/large-retailer **10%**, property-rental **20%**, category exceptions and the **15% DMTT proposed-for 2025** statement as current enactment. Official current Pillar Two/rate leads were found but operative recovery failed; a past proposal is not present-law clearance.

```json
{
  "context_only_blocks": [],
  "current_lines": [
    467,
    467
  ],
  "id": "R0285",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **Isle of Man:** the old general **0%**, banking/large-retailer **10%**, property-rental **20%**, category exceptions and the **15% DMTT proposed-for 2025** statement as current enactment.",
      "id": "R0285.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Official current Pillar Two/rate leads were found but operative recovery failed",
      "id": "R0285.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "a past proposal is not present-law clearance.",
      "id": "R0285.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    175
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0286

Not yet confirmed: **Jersey:** entity-specific company category/MCIT exclusions, credit and calculation, and IIR operative details.

```json
{
  "context_only_blocks": [
    "jersey-company-web:body",
    "jersey-law-web:scope-rate",
    "jersey-law-web:commencement",
    "jersey-p2-web:body"
  ],
  "current_lines": [
    469,
    469
  ],
  "id": "R0286",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **Jersey:** entity-specific company category/MCIT exclusions, credit and calculation, and IIR operative details.",
      "id": "R0286.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    176
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0287

Not yet confirmed: **Guernsey:** the separate Guernsey **0% standard/10% financial-services/20% utilities** proposals, full exceptions and current **15% IIR/QDMTT** enactment/commencement. Do not extend Jersey law across jurisdictions or treat the old joint 2025 proposal cell as current legal evidence.

```json
{
  "context_only_blocks": [],
  "current_lines": [
    471,
    471
  ],
  "id": "R0287",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **Guernsey:** the separate Guernsey **0% standard/10% financial-services/20% utilities** proposals, full exceptions and current **15% IIR/QDMTT** enactment/commencement.",
      "id": "R0287.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Do not extend Jersey law across jurisdictions or treat the old joint 2025 proposal cell as current legal evidence.",
      "id": "R0287.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    176
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0288

Not yet confirmed: **Monaco:** the proposed business’s source/threshold calculation and individual-resident PIT, including French-nationality treaty exceptions; “residents generally exempt” is not a clearance.

```json
{
  "context_only_blocks": [
    "monaco-current:scope",
    "monaco-current:rate",
    "monaco-oct2026:operative"
  ],
  "current_lines": [
    473,
    473
  ],
  "id": "R0288",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **Monaco:** the proposed business’s source/threshold calculation and individual-resident PIT, including French-nationality treaty exceptions",
      "id": "R0288.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "“residents generally exempt” is not a clearance.",
      "id": "R0288.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    177
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0289

Not yet confirmed: **Andorra:** the proposed entity’s category, tax base and concessions; the overview is not the entire current statute.

```json
{
  "context_only_blocks": [
    "andorra-cit:rate"
  ],
  "current_lines": [
    475,
    475
  ],
  "id": "R0289",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **Andorra:** the proposed entity’s category, tax base and concessions",
      "id": "R0289.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "the overview is not the entire current statute.",
      "id": "R0289.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    178
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0290

Not yet confirmed: **San Marino:** actual current operative law for the **17%** IGR/company rate and reduced new-enterprise rates/eligibility. The development-agency/chamber overview advertises 17% and incentives, but a mixed public/private promotional page is not the required operative law. Do not grant a concession solely from that summary.

```json
{
  "context_only_blocks": [],
  "current_lines": [
    477,
    477
  ],
  "id": "R0290",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **San Marino:** actual current operative law for the **17%** IGR/company rate and reduced new-enterprise rates/eligibility.",
      "id": "R0290.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "The development-agency/chamber overview advertises 17% and incentives, but a mixed public/private promotional page is not the required operative law.",
      "id": "R0290.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Do not grant a concession solely from that summary.",
      "id": "R0290.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    179
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0291

Not yet confirmed: **Mauritius Global Business Licence:** all applicable prescribed substance rules, the proposed income category and the old **GBL 2 abolition post 2018** transitional/legal-vehicle assertion.

```json
{
  "context_only_blocks": [
    "mauritius-act2026-full:rates",
    "mauritius-act2026-full:partial-exemption"
  ],
  "current_lines": [
    479,
    479
  ],
  "id": "R0291",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **Mauritius Global Business Licence:** all applicable prescribed substance rules, the proposed income category and the old **GBL 2 abolition post 2018** transitional/legal-vehicle assertion.",
      "id": "R0291.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    187
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0292

Not yet confirmed: **Mauritius Freeport:** the proposed freeport activity, export/local mix, geographic claim and customs-duty exemption. An income-tax rate is not a customs waiver.

```json
{
  "context_only_blocks": [
    "mauritius-act2026-full:Freeport",
    "mauritius-act2026-full:rates"
  ],
  "current_lines": [
    481,
    481
  ],
  "id": "R0292",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **Mauritius Freeport:** the proposed freeport activity, export/local mix, geographic claim and customs-duty exemption.",
      "id": "R0292.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "An income-tax rate is not a customs waiver.",
      "id": "R0292.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    188
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0293

Not yet confirmed: **Tanger Free Zone, Morocco:** current replacement/transitional treatment of the old **0% for 5 years /8.75% thereafter** proposal, qualifying export/industrial-acceleration-zone scope, and the applicable current CGI. Do not apply the historical rates to a 2026 license without the actual current code and transitional articles.

```json
{
  "context_only_blocks": [],
  "current_lines": [
    483,
    483
  ],
  "id": "R0293",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **Tanger Free Zone, Morocco:** current replacement/transitional treatment of the old **0% for 5 years /8.75% thereafter** proposal, qualifying export/industrial-acceleration-zone scope, and the applicable current CGI.",
      "id": "R0293.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Do not apply the historical rates to a 2026 license without the actual current code and transitional articles.",
      "id": "R0293.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    190
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0294

Not yet confirmed: **Egypt: Suez Canal Economic Zone / NUCA:** the complete statutory basis/eligibility of reduced CIT, investment deduction, customs or VAT incentives for each regime; NUCA is not automatically the same legal tax zone. An investment-cost deduction is not a reduced CIT rate: do not convert an advertised **50%** incentive into **11.25%** tax by simply halving 22.5%. The actual GAFI law route failed, so no such computation is cleared.

```json
{
  "context_only_blocks": [],
  "current_lines": [
    485,
    485
  ],
  "id": "R0294",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **Egypt: Suez Canal Economic Zone / NUCA:** the complete statutory basis/eligibility of reduced CIT, investment deduction, customs or VAT incentives for each regime",
      "id": "R0294.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "NUCA is not automatically the same legal tax zone.",
      "id": "R0294.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "An investment-cost deduction is not a reduced CIT rate: do not convert an advertised **50%** incentive into **11.25%** tax by simply halving 22.5%.",
      "id": "R0294.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "The actual GAFI law route failed, so no such computation is cleared.",
      "id": "R0294.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    191
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0295

Not yet confirmed: **Nigeria: Lagos, Calabar, Lekki FTZs:** a reliable complete current text/application: the official NASS copy has a currency-glyph anomaly in section 57, conjunctive Second Schedule 3 conditions and incomplete paragraph 9; no repair is invented. Exact domestic-sales limits, future 2028 effect, customs and the proposed entity’s treatment require authoritative resolution before reliance.

```json
{
  "context_only_blocks": [
    "nigeria-tax2025:scope",
    "nigeria-tax2025:free-zone",
    "nigeria-tax2025:commencement"
  ],
  "current_lines": [
    487,
    487
  ],
  "id": "R0295",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **Nigeria: Lagos, Calabar, Lekki FTZs:** a reliable complete current text/application: the official NASS copy has a currency-glyph anomaly in section 57, conjunctive Second Schedule 3 conditions and incomplete paragraph 9",
      "id": "R0295.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "no repair is invented.",
      "id": "R0295.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Exact domestic-sales limits, future 2028 effect, customs and the proposed entity’s treatment require authoritative resolution before reliance.",
      "id": "R0295.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    192
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0296

Not yet confirmed: **Kenya EPZs / SEZs:** the proposed enterprise’s full approvals and customs-duty waiver; EPZ and SEZ are not interchangeable.

```json
{
  "context_only_blocks": [
    "kenya-income2026:rates",
    "kenya-income2026:EPZ",
    "kenya-finance2026:ThirdSchedule"
  ],
  "current_lines": [
    489,
    489
  ],
  "id": "R0296",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **Kenya EPZs / SEZs:** the proposed enterprise’s full approvals and customs-duty waiver",
      "id": "R0296.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "EPZ and SEZ are not interchangeable.",
      "id": "R0296.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    193
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0297

Not yet confirmed: **South Africa SEZs:** complete current Income Tax Act section 12R conditions, anti-avoidance/legislative changes, approved location and entity eligibility. The authority overview and a Budget proposal do not establish the full statute.

```json
{
  "context_only_blocks": [
    "sa-rates2026:CIT"
  ],
  "current_lines": [
    491,
    491
  ],
  "id": "R0297",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **South Africa SEZs:** complete current Income Tax Act section 12R conditions, anti-avoidance/legislative changes, approved location and entity eligibility.",
      "id": "R0297.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "The authority overview and a Budget proposal do not establish the full statute.",
      "id": "R0297.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    194
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0298

Not yet confirmed: **Botswana IFSC:** complete current IFSC certification/financial-service conditions and 2026 tax-law changes; no individual approval or concession follows from the overview alone.

```json
{
  "context_only_blocks": [
    "botswana-companies:rates"
  ],
  "current_lines": [
    493,
    493
  ],
  "id": "R0298",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **Botswana IFSC:** complete current IFSC certification/financial-service conditions and 2026 tax-law changes",
      "id": "R0298.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "no individual approval or concession follows from the overview alone.",
      "id": "R0298.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    195
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0299

Not yet confirmed: **Substance and economic-substance laws:** each activity’s exact statutory definition, exclusions, entity/residence test, CIGA, return and penalty in **BVI; Cayman; Bermuda; Bahamas; Jersey; Guernsey; Isle of Man; Anguilla; Turks and Caicos (TCI); and Mauritius**, each independently. These jurisdictions do not share one ESA statute or nine identical activity tests. Public-register exposure, penalties and mandatory information exchange to a beneficial owner’s country require the specific legal trigger; they are not universal automatic consequences.

```json
{
  "context_only_blocks": [],
  "current_lines": [
    495,
    495
  ],
  "id": "R0299",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **Substance and economic-substance laws:** each activity’s exact statutory definition, exclusions, entity/residence test, CIGA, return and penalty in **BVI",
      "id": "R0299.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Cayman",
      "id": "R0299.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Bermuda",
      "id": "R0299.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Bahamas",
      "id": "R0299.4",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Jersey",
      "id": "R0299.5",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Guernsey",
      "id": "R0299.6",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Isle of Man",
      "id": "R0299.7",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Anguilla",
      "id": "R0299.8",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Turks and Caicos (TCI)",
      "id": "R0299.9",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "and Mauritius**, each independently.",
      "id": "R0299.10",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "These jurisdictions do not share one ESA statute or nine identical activity tests.",
      "id": "R0299.11",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Public-register exposure, penalties and mandatory information exchange to a beneficial owner’s country require the specific legal trigger",
      "id": "R0299.12",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "they are not universal automatic consequences.",
      "id": "R0299.13",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    209
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0300

Not yet confirmed: **Substance and economic-substance laws:** each selected regime’s actual latest FHTP result and each national ESA instrument. Do not treat a country’s inclusion in one OECD workstream as approval of every zone.

```json
{
  "context_only_blocks": [
    "oecd-harmful:overview"
  ],
  "current_lines": [
    497,
    497
  ],
  "id": "R0300",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **Substance and economic-substance laws:** each selected regime’s actual latest FHTP result and each national ESA instrument.",
      "id": "R0300.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Do not treat a country’s inclusion in one OECD workstream as approval of every zone.",
      "id": "R0300.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    26,
    39,
    209,
    245,
    258
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0301

Not yet confirmed: **UAE:** the entire operative calculation/current implementing decisions for the proposed group. QFZP 0% alone does not settle the group’s final ETR.

```json
{
  "context_only_blocks": [
    "uae-142:scope"
  ],
  "current_lines": [
    499,
    499
  ],
  "id": "R0301",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **UAE:** the entire operative calculation/current implementing decisions for the proposed group.",
      "id": "R0301.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "QFZP 0% alone does not settle the group’s final ETR.",
      "id": "R0301.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    219
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0302

Not yet confirmed: **Cayman:** any enacted domestic QDMTT and commencement. Do not use the old “effective 2025” assertion. Foreign parent IIR/UTPR exposure still requires its actual law.

```json
{
  "context_only_blocks": [],
  "current_lines": [
    501,
    501
  ],
  "id": "R0302",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **Cayman:** any enacted domestic QDMTT and commencement.",
      "id": "R0302.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Do not use the old “effective 2025” assertion.",
      "id": "R0302.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Foreign parent IIR/UTPR exposure still requires its actual law.",
      "id": "R0302.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    222
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0303

Not yet confirmed: **Saudi SEZs:** domestic implementation/current commencement; a 5% zone rate is insufficient to prove either no local tax or a particular foreign top-up amount.

```json
{
  "context_only_blocks": [],
  "current_lines": [
    503,
    503
  ],
  "id": "R0303",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **Saudi SEZs:** domestic implementation/current commencement",
      "id": "R0303.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "a 5% zone rate is insufficient to prove either no local tax or a particular foreign top-up amount.",
      "id": "R0303.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    223
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0304

Not yet confirmed: **Hong Kong:** complete current computation, any later UTPR notice and the proposed Mainland-China-source-income allocation; source of a receipt alone does not answer group/location rules.

```json
{
  "context_only_blocks": [
    "hk-p2-act2025:charge-dates"
  ],
  "current_lines": [
    505,
    505
  ],
  "id": "R0304",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **Hong Kong:** complete current computation, any later UTPR notice and the proposed Mainland-China-source-income allocation",
      "id": "R0304.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "source of a receipt alone does not answer group/location rules.",
      "id": "R0304.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    224
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0305

Not yet confirmed: **Singapore:** actual statutory/commencement text and complete current group/election conditions; the SSO Act route returned 403. Do not claim all OECD changes applied domestically in January 2026.

```json
{
  "context_only_blocks": [
    "sg-p2-iras:body"
  ],
  "current_lines": [
    507,
    507
  ],
  "id": "R0305",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **Singapore:** actual statutory/commencement text and complete current group/election conditions",
      "id": "R0305.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "the SSO Act route returned 403.",
      "id": "R0305.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "Do not claim all OECD changes applied domestically in January 2026.",
      "id": "R0305.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    225
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0306

Not yet confirmed: **Madeira / Portugal:** full Portuguese enacted QDMTT scope, commencement, calculation and current implementation. The official legislative routes returned only application shells. A below 15% Madeira benefit is a reason to test the group, not proof that the benefit is withdrawn or recovered in full.

```json
{
  "context_only_blocks": [],
  "current_lines": [
    509,
    509
  ],
  "id": "R0306",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **Madeira / Portugal:** full Portuguese enacted QDMTT scope, commencement, calculation and current implementation.",
      "id": "R0306.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "The official legislative routes returned only application shells.",
      "id": "R0306.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "A below 15% Madeira benefit is a reason to test the group, not proof that the benefit is withdrawn or recovered in full.",
      "id": "R0306.3",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    226
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0307

Not yet confirmed: **Mauritius:** the full group calculation/elections and applicable reporting/period mechanics.

```json
{
  "context_only_blocks": [
    "mauritius-act2026-full:QDMTT",
    "mauritius-qdmtt2026:commencement",
    "mauritius-act2026-full:QDMTT-charging"
  ],
  "current_lines": [
    511,
    511
  ],
  "id": "R0307",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **Mauritius:** the full group calculation/elections and applicable reporting/period mechanics.",
      "id": "R0307.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    227
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

### R0308

Not yet confirmed: **Zone counts:** the original approximate 50-zone description and 45 UAE zones plus 3 financial-centres count as current populations. QFC must not be counted as a UAE centre.

```json
{
  "context_only_blocks": [],
  "current_lines": [
    513,
    513
  ],
  "id": "R0308",
  "individual_subclaims": [
    {
      "bindings": [],
      "claim": "Not yet confirmed: **Zone counts:** the original approximate 50-zone description and 45 UAE zones plus 3 financial-centres count as current populations.",
      "id": "R0308.1",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    },
    {
      "bindings": [],
      "claim": "QFC must not be counted as a UAE centre.",
      "id": "R0308.2",
      "qualification": "Interpret with the entire parent and its explicit conditions/source limits; a subclaim is not an independent unqualified instruction."
    }
  ],
  "native_bindings": [],
  "old_lines": [
    20,
    52
  ],
  "section": "Not yet confirmed: individual national source requests",
  "source_read_record": null,
  "status": "individual source-limited non-usable reservation"
}
```

## Original-topic destinations

The complete original-topic destination table is in `../free-zones-sez-matrix/old-topic-map.json`.
