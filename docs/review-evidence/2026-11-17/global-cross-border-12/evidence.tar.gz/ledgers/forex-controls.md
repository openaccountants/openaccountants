# forex-controls figure and rule ledger

Public projection; canonical private SHA256: `1e629beed892227c031083bd797ab7c9d5e0c28cb590cd998b1f31f4f1b7aea7`. Complete captured/native source passages remain local. The JSON companion preserves every retained evidence field.

## Whole rule groups

### 1

# Forex controls and cross-border money movement

```json
{
  "figures": [],
  "id": 1,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 15,
  "operative_bindings": [],
  "section": "Scope",
  "source_keys": []
}
```

### 2

## Scope

```json
{
  "figures": [],
  "id": 2,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 17,
  "operative_bindings": [],
  "section": "Scope",
  "source_keys": []
}
```

### 3

Use this Guide to separate exchange permission, bank evidence, investment registration, tax collection and information reporting for founders, freelancers and other individuals or businesses moving money across borders. Nationality alone does not decide the answer: establish the person's relevant residence, entity, transaction purpose, direction, currency conversion and applicable period. A declaration threshold is not necessarily a transfer ceiling, and a bank's commercial acceptance does not establish tax compliance.

```json
{
  "figures": [],
  "id": 3,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 19,
  "operative_bindings": [],
  "section": "Scope",
  "source_keys": []
}
```

### 4

> **Based on work by [Artin (@ar-gen-tin)](https://github.com/ar-gen-tin/panrise)**, licensed under MIT. Adapted for the OpenAccountants format.

```json
{
  "figures": [],
  "id": 4,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 21,
  "operative_bindings": [],
  "section": "Scope",
  "source_keys": []
}
```

### 5

Not yet approved by an accountant. Rules were checked on 16 November 2026. It retains the original country, offshore-income and inquiry-response topics. The specific unresolved propositions in Sources cannot support a transfer, return, exemption or entity recommendation.

```json
{
  "figures": [
    "16",
    "2026"
  ],
  "id": 5,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 23,
  "operative_bindings": [],
  "section": "Scope",
  "source_keys": []
}
```

### 6

## Ask the client first

```json
{
  "figures": [],
  "id": 6,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 25,
  "operative_bindings": [],
  "section": "Ask the client first",
  "source_keys": []
}
```

### 7

Read the existing case, contracts, bank correspondence and returns before asking for missing facts. Establish:

```json
{
  "figures": [],
  "id": 7,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 27,
  "operative_bindings": [],
  "section": "Ask the client first",
  "source_keys": []
}
```

### 8

- The sender, owner and beneficiary, the relevant residence of each, and whether the sender is an individual, partnership or company.

```json
{
  "figures": [],
  "id": 8,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 29,
  "operative_bindings": [],
  "section": "Ask the client first",
  "source_keys": []
}
```

### 9

- The actual economic purpose: salary, independent services, goods, gift or family support, dividend, loan, investment, capital contribution or liquidation. Distinguish personal from company money.

```json
{
  "figures": [],
  "id": 9,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 30,
  "operative_bindings": [],
  "section": "Ask the client first",
  "source_keys": []
}
```

### 10

- Origin, destination, currencies, conversion into local currency, payment channel, dates, amount and relevant cumulative prior transactions; identify any physical cash separately.

```json
{
  "figures": [],
  "id": 10,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 31,
  "operative_bindings": [],
  "section": "Ask the client first",
  "source_keys": []
}
```

### 11

- Contracts, invoices, employment and dividend records, ownership, source of funds, prior foreign-exchange declarations/approvals, tax paid and the exact bank or tax-authority request and deadline.

```json
{
  "figures": [],
  "id": 11,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 32,
  "operative_bindings": [],
  "section": "Ask the client first",
  "source_keys": []
}
```

### 12

Do not substitute a foreign company, another person's quota or an inaccurate payment description for the correct legal route. A foreign account does not decide where income is taxable or discharge reporting duties.

```json
{
  "figures": [],
  "id": 12,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 34,
  "operative_bindings": [],
  "section": "Ask the client first",
  "source_keys": []
}
```

### 13

## The method, step by step

```json
{
  "figures": [],
  "id": 13,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 36,
  "operative_bindings": [],
  "section": "The method, step by step",
  "source_keys": []
}
```

### 14

### Start with the actual route

```json
{
  "figures": [],
  "id": 14,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 38,
  "operative_bindings": [],
  "section": "Start with the actual route",
  "source_keys": []
}
```

### 15

| Jurisdiction / transaction | Threshold or supported rule | Primary source |

```json
{
  "figures": [],
  "id": 15,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 40,
  "operative_bindings": [],
  "section": "Start with the actual route",
  "source_keys": []
}
```

### 16

| Mainland China personal current-account conversion | Annual convenience amount: USD 50,000, computed unit conversion of source 5万美元 (5 × 10,000); genuine current-account transactions above it can use supporting evidence. It is not permission for prohibited capital uses | [SAFE Shanghai personal exchange explanation](https://www.safe.gov.cn/shanghai/2019/1213/1198.html) |

```json
{
  "figures": [
    "50,000",
    "5",
    "10,000"
  ],
  "id": 16,
  "kind": "source-cited rule with actually read conditions",
  "line": 42,
  "operative_bindings": [
    {
      "locator": "Main numbered1",
      "quote_id": "CNQA-001",
      "read_date": "2026-11-16",
      "source": "CNQA",
      "url": "https://www.safe.gov.cn/shanghai/2019/1213/1198.html"
    },
    {
      "locator": "Main numbered2/3",
      "quote_id": "CNQA-002",
      "read_date": "2026-11-16",
      "source": "CNQA",
      "url": "https://www.safe.gov.cn/shanghai/2019/1213/1198.html"
    },
    {
      "locator": "Final warning",
      "quote_id": "CNQA-003",
      "read_date": "2026-11-16",
      "source": "CNQA",
      "url": "https://www.safe.gov.cn/shanghai/2019/1213/1198.html"
    }
  ],
  "section": "Start with the actual route",
  "source_keys": [
    "CNQA"
  ]
}
```

### 17

| India resident-individual LRS | Ordinary USD 250,000 per financial year, April-March, for permitted current/capital transactions; purpose-specific higher facilities below; excludes corporates, partnerships, HUFs and trusts | [RBI Master Direction, Liberalised Remittance Scheme](https://rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=10192) |

```json
{
  "figures": [
    "250,000"
  ],
  "id": 17,
  "kind": "source-cited rule with actually read conditions",
  "line": 43,
  "operative_bindings": [
    {
      "locator": "A1",
      "quote_id": "LRS-015",
      "read_date": "2026-11-16",
      "source": "LRS",
      "url": "https://rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=10192"
    },
    {
      "locator": "A1",
      "quote_id": "LRS-016",
      "read_date": "2026-11-16",
      "source": "LRS",
      "url": "https://rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=10192"
    },
    {
      "locator": "A4",
      "quote_id": "LRS-017",
      "read_date": "2026-11-16",
      "source": "LRS",
      "url": "https://rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=10192"
    },
    {
      "locator": "A5",
      "quote_id": "LRS-018",
      "read_date": "2026-11-16",
      "source": "LRS",
      "url": "https://rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=10192"
    },
    {
      "locator": "A7g/h",
      "quote_id": "LRS-019",
      "read_date": "2026-11-16",
      "source": "LRS",
      "url": "https://rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=10192"
    },
    {
      "locator": "A16",
      "quote_id": "LRS-020",
      "read_date": "2026-11-16",
      "source": "LRS",
      "url": "https://rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=10192"
    },
    {
      "locator": "A17",
      "quote_id": "LRS-021",
      "read_date": "2026-11-16",
      "source": "LRS",
      "url": "https://rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=10192"
    },
    {
      "locator": "A6/A17",
      "quote_id": "LRS-022",
      "read_date": "2026-11-16",
      "source": "LRS",
      "url": "https://rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=10192"
    }
  ],
  "section": "Start with the actual route",
  "source_keys": [
    "LRS"
  ]
}
```

### 18

| India LRS tax collection from 1 April 2026 | Ordinary section 394 Table 7 rates: 2% for education/medical and 20% for other purposes on amounts exceeding INR 1,000,000, computed from the source ten lakh rupees (10 × 100,000), subject to the statutory exclusions below | [Income-tax Act2025 as amended by Finance Act2026](https://www.incometaxindia.gov.in/documents/d/guest/income_tax_act_2025_as_amended_by_fa_act_2026-pdf) |

```json
{
  "figures": [
    "1",
    "2026",
    "394",
    "7",
    "2%",
    "20%",
    "1,000,000",
    "10",
    "100,000"
  ],
  "id": 18,
  "kind": "source-cited rule with actually read conditions",
  "line": 44,
  "operative_bindings": [
    {
      "locator": "394(1)Table7",
      "quote_id": "INTCS-023",
      "read_date": "2026-11-16",
      "source": "INTCS",
      "url": "https://www.incometaxindia.gov.in/documents/d/guest/income_tax_act_2025_as_amended_by_fa_act_2026-pdf"
    },
    {
      "locator": "394(1)Table7(a)",
      "quote_id": "INTCS-024",
      "read_date": "2026-11-16",
      "source": "INTCS",
      "url": "https://www.incometaxindia.gov.in/documents/d/guest/income_tax_act_2025_as_amended_by_fa_act_2026-pdf"
    },
    {
      "locator": "394(1)Table7(b)",
      "quote_id": "INTCS-025",
      "read_date": "2026-11-16",
      "source": "INTCS",
      "url": "https://www.incometaxindia.gov.in/documents/d/guest/income_tax_act_2025_as_amended_by_fa_act_2026-pdf"
    },
    {
      "locator": "394(1)(c)",
      "quote_id": "INTCS-026",
      "read_date": "2026-11-16",
      "source": "INTCS",
      "url": "https://www.incometaxindia.gov.in/documents/d/guest/income_tax_act_2025_as_amended_by_fa_act_2026-pdf"
    },
    {
      "locator": "FinanceAct2026footnote88b",
      "quote_id": "INTCS-027",
      "read_date": "2026-11-16",
      "source": "INTCS",
      "url": "https://www.incometaxindia.gov.in/documents/d/guest/income_tax_act_2025_as_amended_by_fa_act_2026-pdf"
    },
    {
      "locator": "394(4)(a),sameamountselleralreadycollected",
      "quote_id": "INTCS-028",
      "read_date": "2026-11-16",
      "source": "INTCS",
      "url": "https://www.incometaxindia.gov.in/documents/d/guest/income_tax_act_2025_as_amended_by_fa_act_2026-pdf"
    }
  ],
  "section": "Start with the actual route",
  "source_keys": [
    "INTCS"
  ]
}
```

### 19

| Brazil | Use an institution authorised for foreign exchange or its correspondent; compare the total effective cost, including tax and fees. The cash-reais rule below is not a USD daily transfer limit | [Banco Central do Brasil, Cartilha de Câmbio2026](https://aprendervalor.bcb.gov.br/content/estabilidadefinanceira/politica_cambial/Cartilha_cambio_2026.pdf) |

```json
{
  "figures": [],
  "id": 19,
  "kind": "source-cited rule with actually read conditions",
  "line": 45,
  "operative_bindings": [
    {
      "locator": "Pages7/9",
      "quote_id": "BR-029",
      "read_date": "2026-11-16",
      "source": "BR",
      "url": "https://aprendervalor.bcb.gov.br/content/estabilidadefinanceira/politica_cambial/Cartilha_cambio_2026.pdf"
    },
    {
      "locator": "Page14",
      "quote_id": "BR-030",
      "read_date": "2026-11-16",
      "source": "BR",
      "url": "https://aprendervalor.bcb.gov.br/content/estabilidadefinanceira/politica_cambial/Cartilha_cambio_2026.pdf"
    },
    {
      "locator": "Page14",
      "quote_id": "BR-031",
      "read_date": "2026-11-16",
      "source": "BR",
      "url": "https://aprendervalor.bcb.gov.br/content/estabilidadefinanceira/politica_cambial/Cartilha_cambio_2026.pdf"
    },
    {
      "locator": "Pages6/9",
      "quote_id": "BR-032",
      "read_date": "2026-11-16",
      "source": "BR",
      "url": "https://aprendervalor.bcb.gov.br/content/estabilidadefinanceira/politica_cambial/Cartilha_cambio_2026.pdf"
    }
  ],
  "section": "Start with the actual route",
  "source_keys": [
    "BR"
  ]
}
```

### 20

| Taiwan conversion involving NTD | A transaction of TWD 500,000 or more, computed from source 新臺幣50萬元 (50 × 10,000), enters the declaration framework. Different annual bank-route limits and supporting-document rules also apply | [CBC declaration regulations,26December2022revision](https://www.cbc.gov.tw/tw/dl-171561-a2f2e7bbd39d4e2c8abc05b2f3e5bc7c.html) [CBC current inward/outward funds FAQ](https://www.cbc.gov.tw/tw/cp-1179-101135-49647-1.html) |

```json
{
  "figures": [
    "500,000",
    "50",
    "10,000"
  ],
  "id": 20,
  "kind": "source-cited rule with actually read conditions",
  "line": 46,
  "operative_bindings": [
    {
      "locator": "Article2",
      "quote_id": "TWLAW-033",
      "read_date": "2026-11-16",
      "source": "TWLAW",
      "url": "https://www.cbc.gov.tw/tw/dl-171561-a2f2e7bbd39d4e2c8abc05b2f3e5bc7c.html"
    },
    {
      "locator": "Article3(10)",
      "quote_id": "TWLAW-034",
      "read_date": "2026-11-16",
      "source": "TWLAW",
      "url": "https://www.cbc.gov.tw/tw/dl-171561-a2f2e7bbd39d4e2c8abc05b2f3e5bc7c.html"
    },
    {
      "locator": "Article5(1)",
      "quote_id": "TWLAW-035",
      "read_date": "2026-11-16",
      "source": "TWLAW",
      "url": "https://www.cbc.gov.tw/tw/dl-171561-a2f2e7bbd39d4e2c8abc05b2f3e5bc7c.html"
    },
    {
      "locator": "Article5(2)",
      "quote_id": "TWLAW-036",
      "read_date": "2026-11-16",
      "source": "TWLAW",
      "url": "https://www.cbc.gov.tw/tw/dl-171561-a2f2e7bbd39d4e2c8abc05b2f3e5bc7c.html"
    },
    {
      "locator": "Article4(1)(5)",
      "quote_id": "TWLAW-037",
      "read_date": "2026-11-16",
      "source": "TWLAW",
      "url": "https://www.cbc.gov.tw/tw/dl-171561-a2f2e7bbd39d4e2c8abc05b2f3e5bc7c.html"
    },
    {
      "locator": "IIopening",
      "quote_id": "TWFAQ-043",
      "read_date": "2026-11-16",
      "source": "TWFAQ",
      "url": "https://www.cbc.gov.tw/tw/cp-1179-101135-49647-1.html"
    },
    {
      "locator": "II(b)companies",
      "quote_id": "TWFAQ-044",
      "read_date": "2026-11-16",
      "source": "TWFAQ",
      "url": "https://www.cbc.gov.tw/tw/cp-1179-101135-49647-1.html"
    },
    {
      "locator": "II(b)individual/group",
      "quote_id": "TWFAQ-045",
      "read_date": "2026-11-16",
      "source": "TWFAQ",
      "url": "https://www.cbc.gov.tw/tw/cp-1179-101135-49647-1.html"
    },
    {
      "locator": "II(b)nonresident",
      "quote_id": "TWFAQ-046",
      "read_date": "2026-11-16",
      "source": "TWFAQ",
      "url": "https://www.cbc.gov.tw/tw/cp-1179-101135-49647-1.html"
    }
  ],
  "section": "Start with the actual route",
  "source_keys": [
    "TWLAW",
    "TWFAQ"
  ]
}
```

### 21

| South Korea | Identify transaction type, payment/receipt and method separately; capital and specified payment procedures differ | [Bank of Korea, foreign-exchange transaction procedures](https://www.bok.or.kr/eng/main/contents.do?menuNo=400191) |

```json
{
  "figures": [],
  "id": 21,
  "kind": "source-cited rule with actually read conditions",
  "line": 47,
  "operative_bindings": [
    {
      "locator": "Openingframework",
      "quote_id": "KR-047",
      "read_date": "2026-11-16",
      "source": "KR",
      "url": "https://www.bok.or.kr/eng/main/contents.do?menuNo=400191"
    },
    {
      "locator": "Capitalpaymentparagraph",
      "quote_id": "KR-048",
      "read_date": "2026-11-16",
      "source": "KR",
      "url": "https://www.bok.or.kr/eng/main/contents.do?menuNo=400191"
    },
    {
      "locator": "Currentpaymentparagraph",
      "quote_id": "KR-049",
      "read_date": "2026-11-16",
      "source": "KR",
      "url": "https://www.bok.or.kr/eng/main/contents.do?menuNo=400191"
    }
  ],
  "section": "Start with the actual route",
  "source_keys": [
    "KR"
  ]
}
```

### 22

| Japan payment reports | The BOJ describes reporting of resident/nonresident payments exceeding JPY 30,000,000, with a customs-cleared goods exception; capital reports are separate | [BOJ, balance-of-payments source-report explanation](https://www.boj.or.jp/en/statistics/outline/exp/exbpsm6.htm) |

```json
{
  "figures": [
    "30,000,000"
  ],
  "id": 22,
  "kind": "source-cited rule with actually read conditions",
  "line": 48,
  "operative_bindings": [
    {
      "locator": "Reports on paymentetc",
      "quote_id": "JP-050",
      "read_date": "2026-11-16",
      "source": "JP",
      "url": "https://www.boj.or.jp/en/statistics/outline/exp/exbpsm6.htm"
    },
    {
      "locator": "Goods exception",
      "quote_id": "JP-051",
      "read_date": "2026-11-16",
      "source": "JP",
      "url": "https://www.boj.or.jp/en/statistics/outline/exp/exbpsm6.htm"
    },
    {
      "locator": "Capital-reportheading",
      "quote_id": "JP-052",
      "read_date": "2026-11-16",
      "source": "JP",
      "url": "https://www.boj.or.jp/en/statistics/outline/exp/exbpsm6.htm"
    }
  ],
  "section": "Start with the actual route",
  "source_keys": [
    "JP"
  ]
}
```

### 23

| Hong Kong | Basic Law Article 112 provides no foreign-exchange controls and free capital flow; this does not decide tax, beneficial ownership or bank acceptance | [Hong Kong Basic Law Articles111–112](https://www.basiclaw.gov.hk/en/basiclaw/chapter5.html) |

```json
{
  "figures": [
    "112"
  ],
  "id": 23,
  "kind": "source-cited rule with actually read conditions",
  "line": 49,
  "operative_bindings": [
    {
      "locator": "Article112",
      "quote_id": "HK-053",
      "read_date": "2026-11-16",
      "source": "HK",
      "url": "https://www.basiclaw.gov.hk/en/basiclaw/chapter5.html"
    },
    {
      "locator": "Article112",
      "quote_id": "HK-054",
      "read_date": "2026-11-16",
      "source": "HK",
      "url": "https://www.basiclaw.gov.hk/en/basiclaw/chapter5.html"
    }
  ],
  "section": "Start with the actual route",
  "source_keys": [
    "HK"
  ]
}
```

### 24

| United States | Distinguish FBAR, Form 8938 and financial-institution cash reporting. None of the thresholds below is a general wire-transfer ceiling | [FinCEN foreign bank and financial account reporting](https://www.fincen.gov/report-foreign-bank-and-financial-accounts) [IRS Form8938 continuous-use instructions,revision11/2021](https://www.irs.gov/instructions/i8938) [FinCEN CTR FAQ17,aggregation](https://www.fincen.gov/resources/frequently-asked-questions-regarding-fincen-currency-transaction-report-ctr) |

```json
{
  "figures": [
    "8938",
    "938"
  ],
  "id": 24,
  "kind": "source-cited rule with actually read conditions",
  "line": 50,
  "operative_bindings": [
    {
      "locator": "WhoMustFile",
      "quote_id": "FBAR-057",
      "read_date": "2026-11-16",
      "source": "FBAR",
      "url": "https://www.fincen.gov/report-foreign-bank-and-financial-accounts"
    },
    {
      "locator": "WhoMustFile",
      "quote_id": "FBAR-058",
      "read_date": "2026-11-16",
      "source": "FBAR",
      "url": "https://www.fincen.gov/report-foreign-bank-and-financial-accounts"
    },
    {
      "locator": "WhoMustFile",
      "quote_id": "FBAR-059",
      "read_date": "2026-11-16",
      "source": "FBAR",
      "url": "https://www.fincen.gov/report-foreign-bank-and-financial-accounts"
    },
    {
      "locator": "USsingle/separate",
      "quote_id": "IRS8938-060",
      "read_date": "2026-11-16",
      "source": "IRS8938",
      "url": "https://www.irs.gov/instructions/i8938"
    },
    {
      "locator": "USsingle/separateanytime",
      "quote_id": "IRS8938-061",
      "read_date": "2026-11-16",
      "source": "IRS8938",
      "url": "https://www.irs.gov/instructions/i8938"
    },
    {
      "locator": "USjointyearend",
      "quote_id": "IRS8938-062",
      "read_date": "2026-11-16",
      "source": "IRS8938",
      "url": "https://www.irs.gov/instructions/i8938"
    },
    {
      "locator": "USjointanytime",
      "quote_id": "IRS8938-063",
      "read_date": "2026-11-16",
      "source": "IRS8938",
      "url": "https://www.irs.gov/instructions/i8938"
    },
    {
      "locator": "Abroadsingle/separateyearend",
      "quote_id": "IRS8938-064",
      "read_date": "2026-11-16",
      "source": "IRS8938",
      "url": "https://www.irs.gov/instructions/i8938"
    },
    {
      "locator": "Abroadsingle/separateanytime",
      "quote_id": "IRS8938-065",
      "read_date": "2026-11-16",
      "source": "IRS8938",
      "url": "https://www.irs.gov/instructions/i8938"
    },
    {
      "locator": "Abroadjointyearend",
      "quote_id": "IRS8938-066",
      "read_date": "2026-11-16",
      "source": "IRS8938",
      "url": "https://www.irs.gov/instructions/i8938"
    },
    {
      "locator": "Abroadjointanytime",
      "quote_id": "IRS8938-067",
      "read_date": "2026-11-16",
      "source": "IRS8938",
      "url": "https://www.irs.gov/instructions/i8938"
    },
    {
      "locator": "Presenceabroad",
      "quote_id": "IRS8938-068",
      "read_date": "2026-11-16",
      "source": "IRS8938",
      "url": "https://www.irs.gov/instructions/i8938"
    },
    {
      "locator": "FAQ17",
      "quote_id": "CTR-069",
      "read_date": "2026-11-16",
      "source": "CTR",
      "url": "https://www.fincen.gov/resources/frequently-asked-questions-regarding-fincen-currency-transaction-report-ctr"
    },
    {
      "locator": "FAQ17",
      "quote_id": "CTR-070",
      "read_date": "2026-11-16",
      "source": "CTR",
      "url": "https://www.fincen.gov/resources/frequently-asked-questions-regarding-fincen-currency-transaction-report-ctr"
    },
    {
      "locator": "FAQ17",
      "quote_id": "CTR-071",
      "read_date": "2026-11-16",
      "source": "CTR",
      "url": "https://www.fincen.gov/resources/frequently-asked-questions-regarding-fincen-currency-transaction-report-ctr"
    }
  ],
  "section": "Start with the actual route",
  "source_keys": [
    "FBAR",
    "IRS8938",
    "CTR"
  ]
}
```

### 25

| European Union | Article 63 capital/payment freedom operates within its Treaty chapter; Article 65 preserves specified tax, prudential, reporting and public-policy/security measures within its limits | [TFEU Article63](https://publications.europa.eu/resource/cellar/9912914b-f9a7-4f78-b34e-d3e6a2d71f67.0005.01/DOC_1) [TFEU Article65](https://publications.europa.eu/resource/cellar/f07ba7d3-e51a-4b86-915f-771a9e18ece7.0005.01/DOC_1) |

```json
{
  "figures": [
    "63",
    "65",
    "3",
    "5"
  ],
  "id": 25,
  "kind": "source-cited rule with actually read conditions",
  "line": 51,
  "operative_bindings": [
    {
      "locator": "Article63(1)/(2)",
      "quote_id": "EU63-074",
      "read_date": "2026-11-16",
      "source": "EU63",
      "url": "https://publications.europa.eu/resource/cellar/9912914b-f9a7-4f78-b34e-d3e6a2d71f67.0005.01/DOC_1"
    },
    {
      "locator": "Article65(1)(b)",
      "quote_id": "EU65-075",
      "read_date": "2026-11-16",
      "source": "EU65",
      "url": "https://publications.europa.eu/resource/cellar/f07ba7d3-e51a-4b86-915f-771a9e18ece7.0005.01/DOC_1"
    },
    {
      "locator": "Article65(3)",
      "quote_id": "EU65-076",
      "read_date": "2026-11-16",
      "source": "EU65",
      "url": "https://publications.europa.eu/resource/cellar/f07ba7d3-e51a-4b86-915f-771a9e18ece7.0005.01/DOC_1"
    }
  ],
  "section": "Start with the actual route",
  "source_keys": [
    "EU63",
    "EU65"
  ]
}
```

### 26

| UAE tax distinction | Official government guidance distinguishes no individual income tax from 5% VAT and separate business corporate tax | [UAEgovernment taxation overview](https://u.ae/en/information-and-services/finance-and-investment/taxation) |

```json
{
  "figures": [
    "5%"
  ],
  "id": 26,
  "kind": "source-cited rule with actually read conditions",
  "line": 52,
  "operative_bindings": [
    {
      "locator": "Mainintro",
      "quote_id": "UAETAX-072",
      "read_date": "2026-11-16",
      "source": "UAETAX",
      "url": "https://u.ae/en/information-and-services/finance-and-investment/taxation"
    },
    {
      "locator": "MainintroVAT",
      "quote_id": "UAETAX-073",
      "read_date": "2026-11-16",
      "source": "UAETAX",
      "url": "https://u.ae/en/information-and-services/finance-and-investment/taxation"
    }
  ],
  "section": "Start with the actual route",
  "source_keys": [
    "UAETAX"
  ]
}
```

### 27

### Mainland China: personal, trade and capital routes

```json
{
  "figures": [],
  "id": 27,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 54,
  "operative_bindings": [],
  "section": "Mainland China: personal, trade and capital routes",
  "source_keys": []
}
```

### 28

The SAFE explanation distinguishes personal foreign-currency settlement and resident-individual purchases within the USD 50,000 annual convenience amount from documented genuine current-account transactions above it. Education, travel and medical purposes are examples; exceeding the convenience amount does not itself prohibit a genuine current-account payment. Personal purchases must not be used for the listed closed capital purposes, including overseas property, securities or the specified life/investment-return insurance. A blanket statement that every business-related receipt is forbidden is also inaccurate: the explanation expressly includes overseas labour income among current-account settlement examples. [SAFE Shanghai personal exchange explanation](https://www.safe.gov.cn/shanghai/2019/1213/1198.html)

```json
{
  "figures": [
    "50,000"
  ],
  "id": 28,
  "kind": "source-cited rule with actually read conditions",
  "line": 56,
  "operative_bindings": [
    {
      "locator": "Main numbered1",
      "quote_id": "CNQA-001",
      "read_date": "2026-11-16",
      "source": "CNQA",
      "url": "https://www.safe.gov.cn/shanghai/2019/1213/1198.html"
    },
    {
      "locator": "Main numbered2/3",
      "quote_id": "CNQA-002",
      "read_date": "2026-11-16",
      "source": "CNQA",
      "url": "https://www.safe.gov.cn/shanghai/2019/1213/1198.html"
    },
    {
      "locator": "Final warning",
      "quote_id": "CNQA-003",
      "read_date": "2026-11-16",
      "source": "CNQA",
      "url": "https://www.safe.gov.cn/shanghai/2019/1213/1198.html"
    }
  ],
  "section": "Mainland China: personal, trade and capital routes",
  "source_keys": [
    "CNQA"
  ]
}
```

### 29

Use true purpose and evidence. Do not submit false documents, borrow or lend another person's quota, split transactions to evade quota/authenticity management, or use underground exchange channels. These prohibitions are not advice to keep each payment just below an amount. [SAFE Shanghai personal exchange explanation](https://www.safe.gov.cn/shanghai/2019/1213/1198.html) [SAFE Current Account Guidelines2020, watch-list clauses](https://www.safe.gov.cn/beijing/file/file/20250901/f03a39d891024861a8ce859dab124f06.pdf)

```json
{
  "figures": [],
  "id": 29,
  "kind": "source-cited rule with actually read conditions",
  "line": 58,
  "operative_bindings": [
    {
      "locator": "Main numbered1",
      "quote_id": "CNQA-001",
      "read_date": "2026-11-16",
      "source": "CNQA",
      "url": "https://www.safe.gov.cn/shanghai/2019/1213/1198.html"
    },
    {
      "locator": "Main numbered2/3",
      "quote_id": "CNQA-002",
      "read_date": "2026-11-16",
      "source": "CNQA",
      "url": "https://www.safe.gov.cn/shanghai/2019/1213/1198.html"
    },
    {
      "locator": "Final warning",
      "quote_id": "CNQA-003",
      "read_date": "2026-11-16",
      "source": "CNQA",
      "url": "https://www.safe.gov.cn/shanghai/2019/1213/1198.html"
    },
    {
      "locator": "Article62(3)",
      "quote_id": "CNWATCH-008",
      "read_date": "2026-11-16",
      "source": "CNWATCH",
      "url": "https://www.safe.gov.cn/beijing/file/file/20250901/f03a39d891024861a8ce859dab124f06.pdf"
    },
    {
      "locator": "Article62(3)/Annex6",
      "quote_id": "CNWATCH-009",
      "read_date": "2026-11-16",
      "source": "CNWATCH",
      "url": "https://www.safe.gov.cn/beijing/file/file/20250901/f03a39d891024861a8ce859dab124f06.pdf"
    },
    {
      "locator": "Article62(1)",
      "quote_id": "CNWATCH-010",
      "read_date": "2026-11-16",
      "source": "CNWATCH",
      "url": "https://www.safe.gov.cn/beijing/file/file/20250901/f03a39d891024861a8ce859dab124f06.pdf"
    }
  ],
  "section": "Mainland China: personal, trade and capital routes",
  "source_keys": [
    "CNQA",
    "CNWATCH"
  ]
}
```

### 30

For company trade, distinguish the genuine underlying transaction and the bank's document/authenticity review from capital-account registration or approval. The Foreign Exchange Administration Regulations Articles 12-14 require genuine lawful current-account transactions and relevant payment documents. Article 17 requires outward direct/securities investment registration under the applicable rules and prior approval or filing where the State requires it; it does not establish the old universal ODI dollar threshold. Article 22 makes capital-payment approval conditional on the rules applicable to that payment. This foundational 2008 instrument is not a complete current ODI procedure or evidence that every company transaction requires SAFE approval. [China Foreign Exchange Administration Regulations, Order532](https://www.safe.gov.cn/neimenggu/file/file/20170728/b663448ec2f74289b194838d47b8df95.pdf)

```json
{
  "figures": [
    "12",
    "14",
    "17",
    "22",
    "2008"
  ],
  "id": 30,
  "kind": "source-cited rule with actually read conditions",
  "line": 60,
  "operative_bindings": [
    {
      "locator": "Article12",
      "quote_id": "CNFX-004",
      "read_date": "2026-11-16",
      "source": "CNFX",
      "url": "https://www.safe.gov.cn/neimenggu/file/file/20170728/b663448ec2f74289b194838d47b8df95.pdf"
    },
    {
      "locator": "Article17",
      "quote_id": "CNFX-005",
      "read_date": "2026-11-16",
      "source": "CNFX",
      "url": "https://www.safe.gov.cn/neimenggu/file/file/20170728/b663448ec2f74289b194838d47b8df95.pdf"
    },
    {
      "locator": "Articles39/40",
      "quote_id": "CNFX-006",
      "read_date": "2026-11-16",
      "source": "CNFX",
      "url": "https://www.safe.gov.cn/neimenggu/file/file/20170728/b663448ec2f74289b194838d47b8df95.pdf"
    },
    {
      "locator": "Articles39/40",
      "quote_id": "CNFX-007",
      "read_date": "2026-11-16",
      "source": "CNFX",
      "url": "https://www.safe.gov.cn/neimenggu/file/file/20170728/b663448ec2f74289b194838d47b8df95.pdf"
    }
  ],
  "section": "Mainland China: personal, trade and capital routes",
  "source_keys": [
    "CNFX"
  ]
}
```

### 31

A Hong Kong company can receive its own genuine revenue under Hong Kong's capital framework, but that does not determine a mainland founder's investment, remuneration, service, dividend, residence or tax obligations. For a proposed salary retain the employment/work-location record; for a dividend retain ownership and the resolution; for services retain the contract, performance and actual invoice; for family support retain the true relationship and purpose. These are evidence prompts, not verified mandatory Chinese payment codes or clearance of those arrangements. The old provider and offshore-retention recommendations remain individually held in Sources. [Hong Kong Basic Law Articles111–112](https://www.basiclaw.gov.hk/en/basiclaw/chapter5.html) [China Foreign Exchange Administration Regulations, Order532](https://www.safe.gov.cn/neimenggu/file/file/20170728/b663448ec2f74289b194838d47b8df95.pdf)

```json
{
  "figures": [],
  "id": 31,
  "kind": "source-cited rule with actually read conditions",
  "line": 62,
  "operative_bindings": [
    {
      "locator": "Article12",
      "quote_id": "CNFX-004",
      "read_date": "2026-11-16",
      "source": "CNFX",
      "url": "https://www.safe.gov.cn/neimenggu/file/file/20170728/b663448ec2f74289b194838d47b8df95.pdf"
    },
    {
      "locator": "Article17",
      "quote_id": "CNFX-005",
      "read_date": "2026-11-16",
      "source": "CNFX",
      "url": "https://www.safe.gov.cn/neimenggu/file/file/20170728/b663448ec2f74289b194838d47b8df95.pdf"
    },
    {
      "locator": "Articles39/40",
      "quote_id": "CNFX-006",
      "read_date": "2026-11-16",
      "source": "CNFX",
      "url": "https://www.safe.gov.cn/neimenggu/file/file/20170728/b663448ec2f74289b194838d47b8df95.pdf"
    },
    {
      "locator": "Articles39/40",
      "quote_id": "CNFX-007",
      "read_date": "2026-11-16",
      "source": "CNFX",
      "url": "https://www.safe.gov.cn/neimenggu/file/file/20170728/b663448ec2f74289b194838d47b8df95.pdf"
    },
    {
      "locator": "Article112",
      "quote_id": "HK-053",
      "read_date": "2026-11-16",
      "source": "HK",
      "url": "https://www.basiclaw.gov.hk/en/basiclaw/chapter5.html"
    },
    {
      "locator": "Article112",
      "quote_id": "HK-054",
      "read_date": "2026-11-16",
      "source": "HK",
      "url": "https://www.basiclaw.gov.hk/en/basiclaw/chapter5.html"
    }
  ],
  "section": "Mainland China: personal, trade and capital routes",
  "source_keys": [
    "HK",
    "CNFX"
  ]
}
```

### 32

### India: LRS is not company or ODI clearance

```json
{
  "figures": [],
  "id": 32,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 64,
  "operative_bindings": [],
  "section": "India: LRS is not company or ODI clearance",
  "source_keys": []
}
```

### 33

RBI's LRS direction permits resident individuals, including minors under its guardian/Form A2 procedure, to remit up to USD 250,000 per financial year for permitted purposes. It does not extend the individual scheme to corporate, partnership, HUF or trust remitters. Prohibited FEMA/current-account transactions, prohibited destinations or persons, and overseas margin/margin-call remittances do not become permissible because they fit the amount. Family consolidation for capital investment requires compliance with the co-owner/co-partner conditions; one resident cannot use a gift to replenish another resident's overseas foreign-currency account. [RBI Master Direction, Liberalised Remittance Scheme](https://rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=10192)

```json
{
  "figures": [
    "250,000"
  ],
  "id": 33,
  "kind": "source-cited rule with actually read conditions",
  "line": 66,
  "operative_bindings": [
    {
      "locator": "A1",
      "quote_id": "LRS-015",
      "read_date": "2026-11-16",
      "source": "LRS",
      "url": "https://rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=10192"
    },
    {
      "locator": "A1",
      "quote_id": "LRS-016",
      "read_date": "2026-11-16",
      "source": "LRS",
      "url": "https://rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=10192"
    },
    {
      "locator": "A4",
      "quote_id": "LRS-017",
      "read_date": "2026-11-16",
      "source": "LRS",
      "url": "https://rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=10192"
    },
    {
      "locator": "A5",
      "quote_id": "LRS-018",
      "read_date": "2026-11-16",
      "source": "LRS",
      "url": "https://rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=10192"
    },
    {
      "locator": "A7g/h",
      "quote_id": "LRS-019",
      "read_date": "2026-11-16",
      "source": "LRS",
      "url": "https://rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=10192"
    },
    {
      "locator": "A16",
      "quote_id": "LRS-020",
      "read_date": "2026-11-16",
      "source": "LRS",
      "url": "https://rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=10192"
    },
    {
      "locator": "A17",
      "quote_id": "LRS-021",
      "read_date": "2026-11-16",
      "source": "LRS",
      "url": "https://rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=10192"
    },
    {
      "locator": "A6/A17",
      "quote_id": "LRS-022",
      "read_date": "2026-11-16",
      "source": "LRS",
      "url": "https://rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=10192"
    }
  ],
  "section": "India: LRS is not company or ODI clearance",
  "source_keys": [
    "LRS"
  ]
}
```

### 34

Paragraph 7 contains purpose-specific facilities: medical treatment above the ordinary amount can use the specified doctor/hospital estimate under general permission, and studies can use the foreign institution's estimate without prior RBI permission. Qualifying employer-borne business visits are treated outside LRS subject to bona fides. Emigration follows its prescribed-country amount/ordinary amount and incidental-expense conditions, excluding investment simply to earn immigration points. Other excess releases require the applicable RBI permission. [RBI Master Direction, Liberalised Remittance Scheme](https://rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=10192)

```json
{
  "figures": [
    "7"
  ],
  "id": 34,
  "kind": "source-cited rule with actually read conditions",
  "line": 68,
  "operative_bindings": [
    {
      "locator": "A1",
      "quote_id": "LRS-015",
      "read_date": "2026-11-16",
      "source": "LRS",
      "url": "https://rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=10192"
    },
    {
      "locator": "A1",
      "quote_id": "LRS-016",
      "read_date": "2026-11-16",
      "source": "LRS",
      "url": "https://rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=10192"
    },
    {
      "locator": "A4",
      "quote_id": "LRS-017",
      "read_date": "2026-11-16",
      "source": "LRS",
      "url": "https://rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=10192"
    },
    {
      "locator": "A5",
      "quote_id": "LRS-018",
      "read_date": "2026-11-16",
      "source": "LRS",
      "url": "https://rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=10192"
    },
    {
      "locator": "A7g/h",
      "quote_id": "LRS-019",
      "read_date": "2026-11-16",
      "source": "LRS",
      "url": "https://rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=10192"
    },
    {
      "locator": "A16",
      "quote_id": "LRS-020",
      "read_date": "2026-11-16",
      "source": "LRS",
      "url": "https://rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=10192"
    },
    {
      "locator": "A17",
      "quote_id": "LRS-021",
      "read_date": "2026-11-16",
      "source": "LRS",
      "url": "https://rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=10192"
    },
    {
      "locator": "A6/A17",
      "quote_id": "LRS-022",
      "read_date": "2026-11-16",
      "source": "LRS",
      "url": "https://rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=10192"
    }
  ],
  "section": "India: LRS is not company or ODI clearance",
  "source_keys": [
    "LRS"
  ]
}
```

### 35

PAN and the authorised dealer's Form A2 process form part of the direction. The direction refers overseas direct and portfolio investment to the 2022 overseas-investment rules: an LLC or Pte. Ltd. is not automatically an eligible investment. Do not treat a proposed foreign-company capital contribution, loan, round-trip structure or retention of foreign business receipts as cleared by the LRS amount alone. Paragraph 17 allows an LRS investor to retain/reinvest investment income, but requires the received/realised/unspent/unused foreign exchange, unless reinvested, to be repatriated and surrendered within its 180-day rule; resident-individual ODI must instead comply with the specified 2022 investment framework. That is not general permission to retain all foreign business revenue. The remaining transaction-specific ODI and Indian foreign-income/credit rules are listed in Sources. [RBI Master Direction, Liberalised Remittance Scheme](https://rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=10192)

```json
{
  "figures": [
    "2022",
    "17",
    "180",
    "2022"
  ],
  "id": 35,
  "kind": "source-cited rule with actually read conditions",
  "line": 70,
  "operative_bindings": [
    {
      "locator": "A1",
      "quote_id": "LRS-015",
      "read_date": "2026-11-16",
      "source": "LRS",
      "url": "https://rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=10192"
    },
    {
      "locator": "A1",
      "quote_id": "LRS-016",
      "read_date": "2026-11-16",
      "source": "LRS",
      "url": "https://rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=10192"
    },
    {
      "locator": "A4",
      "quote_id": "LRS-017",
      "read_date": "2026-11-16",
      "source": "LRS",
      "url": "https://rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=10192"
    },
    {
      "locator": "A5",
      "quote_id": "LRS-018",
      "read_date": "2026-11-16",
      "source": "LRS",
      "url": "https://rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=10192"
    },
    {
      "locator": "A7g/h",
      "quote_id": "LRS-019",
      "read_date": "2026-11-16",
      "source": "LRS",
      "url": "https://rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=10192"
    },
    {
      "locator": "A16",
      "quote_id": "LRS-020",
      "read_date": "2026-11-16",
      "source": "LRS",
      "url": "https://rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=10192"
    },
    {
      "locator": "A17",
      "quote_id": "LRS-021",
      "read_date": "2026-11-16",
      "source": "LRS",
      "url": "https://rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=10192"
    },
    {
      "locator": "A6/A17",
      "quote_id": "LRS-022",
      "read_date": "2026-11-16",
      "source": "LRS",
      "url": "https://rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=10192"
    }
  ],
  "section": "India: LRS is not company or ODI clearance",
  "source_keys": [
    "LRS"
  ]
}
```

### 36

For a normal LRS remittance under Income-tax Act 2025 section 394(1), Table 7, as amended by Finance Act 2026 with effect from 1 April 2026, the authorised dealer collects 2% for education/medical purposes and 20% for other purposes on the amount/aggregate exceeding INR 1,000,000. Collection is at debit or receipt, whichever is earlier. Section 394(4) excludes qualifying education remittances funded by a loan from the specified section 129(3)(b) financial institution and prevents dealer collection on the same amount on which the overseas tour-package seller has already collected tax. Section 394(5) also addresses amounts on which the buyer is liable to deduct, and has deducted, tax under the other provisions. The tour-package seller is a separate Table 8 category; do not confuse its rate with the LRS threshold. [Income-tax Act2025 as amended by Finance Act2026](https://www.incometaxindia.gov.in/documents/d/guest/income_tax_act_2025_as_amended_by_fa_act_2026-pdf)

```json
{
  "figures": [
    "2025",
    "394",
    "1",
    "7",
    "2026",
    "1",
    "2026",
    "2%",
    "20%",
    "1,000,000",
    "394",
    "4",
    "129",
    "3",
    "394",
    "5",
    "8"
  ],
  "id": 36,
  "kind": "source-cited rule with actually read conditions",
  "line": 72,
  "operative_bindings": [
    {
      "locator": "394(1)Table7",
      "quote_id": "INTCS-023",
      "read_date": "2026-11-16",
      "source": "INTCS",
      "url": "https://www.incometaxindia.gov.in/documents/d/guest/income_tax_act_2025_as_amended_by_fa_act_2026-pdf"
    },
    {
      "locator": "394(1)Table7(a)",
      "quote_id": "INTCS-024",
      "read_date": "2026-11-16",
      "source": "INTCS",
      "url": "https://www.incometaxindia.gov.in/documents/d/guest/income_tax_act_2025_as_amended_by_fa_act_2026-pdf"
    },
    {
      "locator": "394(1)Table7(b)",
      "quote_id": "INTCS-025",
      "read_date": "2026-11-16",
      "source": "INTCS",
      "url": "https://www.incometaxindia.gov.in/documents/d/guest/income_tax_act_2025_as_amended_by_fa_act_2026-pdf"
    },
    {
      "locator": "394(1)(c)",
      "quote_id": "INTCS-026",
      "read_date": "2026-11-16",
      "source": "INTCS",
      "url": "https://www.incometaxindia.gov.in/documents/d/guest/income_tax_act_2025_as_amended_by_fa_act_2026-pdf"
    },
    {
      "locator": "FinanceAct2026footnote88b",
      "quote_id": "INTCS-027",
      "read_date": "2026-11-16",
      "source": "INTCS",
      "url": "https://www.incometaxindia.gov.in/documents/d/guest/income_tax_act_2025_as_amended_by_fa_act_2026-pdf"
    },
    {
      "locator": "394(4)(a),sameamountselleralreadycollected",
      "quote_id": "INTCS-028",
      "read_date": "2026-11-16",
      "source": "INTCS",
      "url": "https://www.incometaxindia.gov.in/documents/d/guest/income_tax_act_2025_as_amended_by_fa_act_2026-pdf"
    }
  ],
  "section": "India: LRS is not company or ODI clearance",
  "source_keys": [
    "INTCS"
  ]
}
```

### 37

These are ordinary statutory rates for a correctly classified remittance, with no higher-rate identifier/default issue and no lower-rate certificate assumed. Section 395 permits the specified lower-collection certificate route and requires the tax-collection certificate. Reconcile that certificate and the actual return/credit position; the present source read does not promise an automatic refund or a final tax cost equal to the collection. [Income-tax Act2025 as amended by Finance Act2026](https://www.incometaxindia.gov.in/documents/d/guest/income_tax_act_2025_as_amended_by_fa_act_2026-pdf)

```json
{
  "figures": [
    "395"
  ],
  "id": 37,
  "kind": "source-cited rule with actually read conditions",
  "line": 74,
  "operative_bindings": [
    {
      "locator": "394(1)Table7",
      "quote_id": "INTCS-023",
      "read_date": "2026-11-16",
      "source": "INTCS",
      "url": "https://www.incometaxindia.gov.in/documents/d/guest/income_tax_act_2025_as_amended_by_fa_act_2026-pdf"
    },
    {
      "locator": "394(1)Table7(a)",
      "quote_id": "INTCS-024",
      "read_date": "2026-11-16",
      "source": "INTCS",
      "url": "https://www.incometaxindia.gov.in/documents/d/guest/income_tax_act_2025_as_amended_by_fa_act_2026-pdf"
    },
    {
      "locator": "394(1)Table7(b)",
      "quote_id": "INTCS-025",
      "read_date": "2026-11-16",
      "source": "INTCS",
      "url": "https://www.incometaxindia.gov.in/documents/d/guest/income_tax_act_2025_as_amended_by_fa_act_2026-pdf"
    },
    {
      "locator": "394(1)(c)",
      "quote_id": "INTCS-026",
      "read_date": "2026-11-16",
      "source": "INTCS",
      "url": "https://www.incometaxindia.gov.in/documents/d/guest/income_tax_act_2025_as_amended_by_fa_act_2026-pdf"
    },
    {
      "locator": "FinanceAct2026footnote88b",
      "quote_id": "INTCS-027",
      "read_date": "2026-11-16",
      "source": "INTCS",
      "url": "https://www.incometaxindia.gov.in/documents/d/guest/income_tax_act_2025_as_amended_by_fa_act_2026-pdf"
    },
    {
      "locator": "394(4)(a),sameamountselleralreadycollected",
      "quote_id": "INTCS-028",
      "read_date": "2026-11-16",
      "source": "INTCS",
      "url": "https://www.incometaxindia.gov.in/documents/d/guest/income_tax_act_2025_as_amended_by_fa_act_2026-pdf"
    }
  ],
  "section": "India: LRS is not company or ODI clearance",
  "source_keys": [
    "INTCS"
  ]
}
```

### 38

### Brazil: payment channel, documentation and IOF

```json
{
  "figures": [],
  "id": 38,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 76,
  "operative_bindings": [],
  "section": "Brazil: payment channel, documentation and IOF",
  "source_keys": []
}
```

### 39

The Banco Central's 2026 exchange booklet directs the sender to an authorised foreign-exchange institution or correspondent and requires identification of sender and beneficiary. For an outward payment order, up to R$10,000 may be delivered through the described payment instruments, including cash reais; above it the booklet specifies debit from an eligible deposit/payment account or cheque. The inward counterpart has its corresponding account-credit/cheque rule. This is a reais settlement-method boundary, not the old USD 10,000 daily no-document allowance. [Banco Central do Brasil, Cartilha de Câmbio2026](https://aprendervalor.bcb.gov.br/content/estabilidadefinanceira/politica_cambial/Cartilha_cambio_2026.pdf)

```json
{
  "figures": [
    "2026",
    "10,000",
    "10,000"
  ],
  "id": 39,
  "kind": "source-cited rule with actually read conditions",
  "line": 78,
  "operative_bindings": [
    {
      "locator": "Pages7/9",
      "quote_id": "BR-029",
      "read_date": "2026-11-16",
      "source": "BR",
      "url": "https://aprendervalor.bcb.gov.br/content/estabilidadefinanceira/politica_cambial/Cartilha_cambio_2026.pdf"
    },
    {
      "locator": "Page14",
      "quote_id": "BR-030",
      "read_date": "2026-11-16",
      "source": "BR",
      "url": "https://aprendervalor.bcb.gov.br/content/estabilidadefinanceira/politica_cambial/Cartilha_cambio_2026.pdf"
    },
    {
      "locator": "Page14",
      "quote_id": "BR-031",
      "read_date": "2026-11-16",
      "source": "BR",
      "url": "https://aprendervalor.bcb.gov.br/content/estabilidadefinanceira/politica_cambial/Cartilha_cambio_2026.pdf"
    },
    {
      "locator": "Pages6/9",
      "quote_id": "BR-032",
      "read_date": "2026-11-16",
      "source": "BR",
      "url": "https://aprendervalor.bcb.gov.br/content/estabilidadefinanceira/politica_cambial/Cartilha_cambio_2026.pdf"
    }
  ],
  "section": "Brazil: payment channel, documentation and IOF",
  "source_keys": [
    "BR"
  ]
}
```

### 40

Ask for the Valor Efetivo Total (VET): the booklet explains that it includes the exchange rate, IOF and fees/commissions and must be supplied by the institution and shown on the exchange contract or receipt. The exact IOF rate and current transaction-specific documentation depend on the operation; the old numerical IOF range and “US LLC + Mercury avoids the rules” proposition cannot be used from this Guide. [Banco Central do Brasil, Cartilha de Câmbio2026](https://aprendervalor.bcb.gov.br/content/estabilidadefinanceira/politica_cambial/Cartilha_cambio_2026.pdf)

```json
{
  "figures": [],
  "id": 40,
  "kind": "source-cited rule with actually read conditions",
  "line": 80,
  "operative_bindings": [
    {
      "locator": "Pages7/9",
      "quote_id": "BR-029",
      "read_date": "2026-11-16",
      "source": "BR",
      "url": "https://aprendervalor.bcb.gov.br/content/estabilidadefinanceira/politica_cambial/Cartilha_cambio_2026.pdf"
    },
    {
      "locator": "Page14",
      "quote_id": "BR-030",
      "read_date": "2026-11-16",
      "source": "BR",
      "url": "https://aprendervalor.bcb.gov.br/content/estabilidadefinanceira/politica_cambial/Cartilha_cambio_2026.pdf"
    },
    {
      "locator": "Page14",
      "quote_id": "BR-031",
      "read_date": "2026-11-16",
      "source": "BR",
      "url": "https://aprendervalor.bcb.gov.br/content/estabilidadefinanceira/politica_cambial/Cartilha_cambio_2026.pdf"
    },
    {
      "locator": "Pages6/9",
      "quote_id": "BR-032",
      "read_date": "2026-11-16",
      "source": "BR",
      "url": "https://aprendervalor.bcb.gov.br/content/estabilidadefinanceira/politica_cambial/Cartilha_cambio_2026.pdf"
    }
  ],
  "section": "Brazil: payment channel, documentation and IOF",
  "source_keys": [
    "BR"
  ]
}
```

### 41

### Taiwan: three different questions

```json
{
  "figures": [],
  "id": 41,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 82,
  "operative_bindings": [],
  "section": "Taiwan: three different questions",
  "source_keys": []
}
```

### 42

First, distinguish foreign-currency movements without NTD conversion from settlement involving NTD. The CBC FAQ describes the former as free; for the latter, each exchange transaction reaching TWD 500,000 is subject to the declaration regulations. Articles 2-3 of the regulations govern the declaration and relevant person categories; do not substitute nationality or the former annual TWD amount for this per-transaction test. [CBC current inward/outward funds FAQ](https://www.cbc.gov.tw/tw/cp-1179-101135-49647-1.html) [CBC declaration regulations,26December2022revision](https://www.cbc.gov.tw/tw/dl-171561-a2f2e7bbd39d4e2c8abc05b2f3e5bc7c.html)

```json
{
  "figures": [
    "500,000",
    "2",
    "3"
  ],
  "id": 42,
  "kind": "source-cited rule with actually read conditions",
  "line": 84,
  "operative_bindings": [
    {
      "locator": "Article2",
      "quote_id": "TWLAW-033",
      "read_date": "2026-11-16",
      "source": "TWLAW",
      "url": "https://www.cbc.gov.tw/tw/dl-171561-a2f2e7bbd39d4e2c8abc05b2f3e5bc7c.html"
    },
    {
      "locator": "Article3(10)",
      "quote_id": "TWLAW-034",
      "read_date": "2026-11-16",
      "source": "TWLAW",
      "url": "https://www.cbc.gov.tw/tw/dl-171561-a2f2e7bbd39d4e2c8abc05b2f3e5bc7c.html"
    },
    {
      "locator": "Article5(1)",
      "quote_id": "TWLAW-035",
      "read_date": "2026-11-16",
      "source": "TWLAW",
      "url": "https://www.cbc.gov.tw/tw/dl-171561-a2f2e7bbd39d4e2c8abc05b2f3e5bc7c.html"
    },
    {
      "locator": "Article5(2)",
      "quote_id": "TWLAW-036",
      "read_date": "2026-11-16",
      "source": "TWLAW",
      "url": "https://www.cbc.gov.tw/tw/dl-171561-a2f2e7bbd39d4e2c8abc05b2f3e5bc7c.html"
    },
    {
      "locator": "Article4(1)(5)",
      "quote_id": "TWLAW-037",
      "read_date": "2026-11-16",
      "source": "TWLAW",
      "url": "https://www.cbc.gov.tw/tw/dl-171561-a2f2e7bbd39d4e2c8abc05b2f3e5bc7c.html"
    },
    {
      "locator": "IIopening",
      "quote_id": "TWFAQ-043",
      "read_date": "2026-11-16",
      "source": "TWFAQ",
      "url": "https://www.cbc.gov.tw/tw/cp-1179-101135-49647-1.html"
    },
    {
      "locator": "II(b)companies",
      "quote_id": "TWFAQ-044",
      "read_date": "2026-11-16",
      "source": "TWFAQ",
      "url": "https://www.cbc.gov.tw/tw/cp-1179-101135-49647-1.html"
    },
    {
      "locator": "II(b)individual/group",
      "quote_id": "TWFAQ-045",
      "read_date": "2026-11-16",
      "source": "TWFAQ",
      "url": "https://www.cbc.gov.tw/tw/cp-1179-101135-49647-1.html"
    },
    {
      "locator": "II(b)nonresident",
      "quote_id": "TWFAQ-046",
      "read_date": "2026-11-16",
      "source": "TWFAQ",
      "url": "https://www.cbc.gov.tw/tw/cp-1179-101135-49647-1.html"
    }
  ],
  "section": "Taiwan: three different questions",
  "source_keys": [
    "TWFAQ",
    "TWLAW"
  ]
}
```

### 43

Second, distinguish the annual direct-to-bank route. CBC's 31 October 2024 Order under Article 7 raised the Article 4(1)(3)/6(1)(1) company amount from USD 50,000,000 to USD 100,000,000 and individual/group amount from USD 5,000,000 to USD 10,000,000, effective 1 November 2024. The 26 December 2022 regulation PDF still prints the previous amounts; apply the later order rather than treating the two documents as competing current answers. The current FAQ gives those raised annual amounts and USD 100,000 per transaction for nonresidents, with supporting documents and CBC approval through the bank above the relevant amount. These are distinct categories, not a uniform resident transfer cap. [CBC31October2024annual-settlement adjustment order](https://www.cbc.gov.tw/tw/dl-212210-8b20d63a34cf4b098a130e529e3f0e45.html) [CBC declaration regulations,26December2022revision](https://www.cbc.gov.tw/tw/dl-171561-a2f2e7bbd39d4e2c8abc05b2f3e5bc7c.html) [CBC current inward/outward funds FAQ](https://www.cbc.gov.tw/tw/cp-1179-101135-49647-1.html)

```json
{
  "figures": [
    "31",
    "2024",
    "7",
    "4",
    "1",
    "3",
    "6",
    "1",
    "1",
    "50,000,000",
    "100,000,000",
    "5,000,000",
    "10,000,000",
    "1",
    "2024",
    "26",
    "2022",
    "100,000"
  ],
  "id": 43,
  "kind": "source-cited rule with actually read conditions",
  "line": 86,
  "operative_bindings": [
    {
      "locator": "Article2",
      "quote_id": "TWLAW-033",
      "read_date": "2026-11-16",
      "source": "TWLAW",
      "url": "https://www.cbc.gov.tw/tw/dl-171561-a2f2e7bbd39d4e2c8abc05b2f3e5bc7c.html"
    },
    {
      "locator": "Article3(10)",
      "quote_id": "TWLAW-034",
      "read_date": "2026-11-16",
      "source": "TWLAW",
      "url": "https://www.cbc.gov.tw/tw/dl-171561-a2f2e7bbd39d4e2c8abc05b2f3e5bc7c.html"
    },
    {
      "locator": "Article5(1)",
      "quote_id": "TWLAW-035",
      "read_date": "2026-11-16",
      "source": "TWLAW",
      "url": "https://www.cbc.gov.tw/tw/dl-171561-a2f2e7bbd39d4e2c8abc05b2f3e5bc7c.html"
    },
    {
      "locator": "Article5(2)",
      "quote_id": "TWLAW-036",
      "read_date": "2026-11-16",
      "source": "TWLAW",
      "url": "https://www.cbc.gov.tw/tw/dl-171561-a2f2e7bbd39d4e2c8abc05b2f3e5bc7c.html"
    },
    {
      "locator": "Article4(1)(5)",
      "quote_id": "TWLAW-037",
      "read_date": "2026-11-16",
      "source": "TWLAW",
      "url": "https://www.cbc.gov.tw/tw/dl-171561-a2f2e7bbd39d4e2c8abc05b2f3e5bc7c.html"
    },
    {
      "locator": "Clause1old",
      "quote_id": "TWORDER-038",
      "read_date": "2026-11-16",
      "source": "TWORDER",
      "url": "https://www.cbc.gov.tw/tw/dl-212210-8b20d63a34cf4b098a130e529e3f0e45.html"
    },
    {
      "locator": "Clause1new",
      "quote_id": "TWORDER-039",
      "read_date": "2026-11-16",
      "source": "TWORDER",
      "url": "https://www.cbc.gov.tw/tw/dl-212210-8b20d63a34cf4b098a130e529e3f0e45.html"
    },
    {
      "locator": "Clause2old",
      "quote_id": "TWORDER-040",
      "read_date": "2026-11-16",
      "source": "TWORDER",
      "url": "https://www.cbc.gov.tw/tw/dl-212210-8b20d63a34cf4b098a130e529e3f0e45.html"
    },
    {
      "locator": "Clause2new",
      "quote_id": "TWORDER-041",
      "read_date": "2026-11-16",
      "source": "TWORDER",
      "url": "https://www.cbc.gov.tw/tw/dl-212210-8b20d63a34cf4b098a130e529e3f0e45.html"
    },
    {
      "locator": "Commencement",
      "quote_id": "TWORDER-042",
      "read_date": "2026-11-16",
      "source": "TWORDER",
      "url": "https://www.cbc.gov.tw/tw/dl-212210-8b20d63a34cf4b098a130e529e3f0e45.html"
    },
    {
      "locator": "IIopening",
      "quote_id": "TWFAQ-043",
      "read_date": "2026-11-16",
      "source": "TWFAQ",
      "url": "https://www.cbc.gov.tw/tw/cp-1179-101135-49647-1.html"
    },
    {
      "locator": "II(b)companies",
      "quote_id": "TWFAQ-044",
      "read_date": "2026-11-16",
      "source": "TWFAQ",
      "url": "https://www.cbc.gov.tw/tw/cp-1179-101135-49647-1.html"
    },
    {
      "locator": "II(b)individual/group",
      "quote_id": "TWFAQ-045",
      "read_date": "2026-11-16",
      "source": "TWFAQ",
      "url": "https://www.cbc.gov.tw/tw/cp-1179-101135-49647-1.html"
    },
    {
      "locator": "II(b)nonresident",
      "quote_id": "TWFAQ-046",
      "read_date": "2026-11-16",
      "source": "TWFAQ",
      "url": "https://www.cbc.gov.tw/tw/cp-1179-101135-49647-1.html"
    }
  ],
  "section": "Taiwan: three different questions",
  "source_keys": [
    "TWORDER",
    "TWLAW",
    "TWFAQ"
  ]
}
```

### 44

Third, identify transactions and documents independently. Article 4 and the FAQ separately address goods/services and approved investment. Article 5 requires supporting documents for specified cases, including company transactions of USD 1,000,000 or more and individual/group transactions of USD 500,000 or more, as well as the other listed investment/underlying-transaction cases. Investment approval, OBU tax treatment and CFC status are not resolved by passing the exchange declaration test. [CBC declaration regulations,26December2022revision](https://www.cbc.gov.tw/tw/dl-171561-a2f2e7bbd39d4e2c8abc05b2f3e5bc7c.html) [CBC current inward/outward funds FAQ](https://www.cbc.gov.tw/tw/cp-1179-101135-49647-1.html)

```json
{
  "figures": [
    "4",
    "5",
    "1,000,000",
    "500,000"
  ],
  "id": 44,
  "kind": "source-cited rule with actually read conditions",
  "line": 88,
  "operative_bindings": [
    {
      "locator": "Article2",
      "quote_id": "TWLAW-033",
      "read_date": "2026-11-16",
      "source": "TWLAW",
      "url": "https://www.cbc.gov.tw/tw/dl-171561-a2f2e7bbd39d4e2c8abc05b2f3e5bc7c.html"
    },
    {
      "locator": "Article3(10)",
      "quote_id": "TWLAW-034",
      "read_date": "2026-11-16",
      "source": "TWLAW",
      "url": "https://www.cbc.gov.tw/tw/dl-171561-a2f2e7bbd39d4e2c8abc05b2f3e5bc7c.html"
    },
    {
      "locator": "Article5(1)",
      "quote_id": "TWLAW-035",
      "read_date": "2026-11-16",
      "source": "TWLAW",
      "url": "https://www.cbc.gov.tw/tw/dl-171561-a2f2e7bbd39d4e2c8abc05b2f3e5bc7c.html"
    },
    {
      "locator": "Article5(2)",
      "quote_id": "TWLAW-036",
      "read_date": "2026-11-16",
      "source": "TWLAW",
      "url": "https://www.cbc.gov.tw/tw/dl-171561-a2f2e7bbd39d4e2c8abc05b2f3e5bc7c.html"
    },
    {
      "locator": "Article4(1)(5)",
      "quote_id": "TWLAW-037",
      "read_date": "2026-11-16",
      "source": "TWLAW",
      "url": "https://www.cbc.gov.tw/tw/dl-171561-a2f2e7bbd39d4e2c8abc05b2f3e5bc7c.html"
    },
    {
      "locator": "IIopening",
      "quote_id": "TWFAQ-043",
      "read_date": "2026-11-16",
      "source": "TWFAQ",
      "url": "https://www.cbc.gov.tw/tw/cp-1179-101135-49647-1.html"
    },
    {
      "locator": "II(b)companies",
      "quote_id": "TWFAQ-044",
      "read_date": "2026-11-16",
      "source": "TWFAQ",
      "url": "https://www.cbc.gov.tw/tw/cp-1179-101135-49647-1.html"
    },
    {
      "locator": "II(b)individual/group",
      "quote_id": "TWFAQ-045",
      "read_date": "2026-11-16",
      "source": "TWFAQ",
      "url": "https://www.cbc.gov.tw/tw/cp-1179-101135-49647-1.html"
    },
    {
      "locator": "II(b)nonresident",
      "quote_id": "TWFAQ-046",
      "read_date": "2026-11-16",
      "source": "TWFAQ",
      "url": "https://www.cbc.gov.tw/tw/cp-1179-101135-49647-1.html"
    }
  ],
  "section": "Taiwan: three different questions",
  "source_keys": [
    "TWLAW",
    "TWFAQ"
  ]
}
```

### 45

### South Korea and Japan

```json
{
  "figures": [],
  "id": 45,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 90,
  "operative_bindings": [],
  "section": "South Korea and Japan",
  "source_keys": []
}
```

### 46

The Bank of Korea's English procedural explanation separates current transactions, capital transactions and payment methods. It describes evidential documents for current payments, specified notification/confirmation cases, and capital routes requiring their applicable procedures. Its numerical donation/other examples are not a sufficient current consolidated 2026 clearance for the former country matrix. Establish the actual remitter, investment/payment type and current designated-bank/authority procedure before using a numerical exception. The exact old Korean amounts are preserved as non-usable research items in Sources. [Bank of Korea, foreign-exchange transaction procedures](https://www.bok.or.kr/eng/main/contents.do?menuNo=400191)

```json
{
  "figures": [
    "2026"
  ],
  "id": 46,
  "kind": "source-cited rule with actually read conditions",
  "line": 92,
  "operative_bindings": [
    {
      "locator": "Openingframework",
      "quote_id": "KR-047",
      "read_date": "2026-11-16",
      "source": "KR",
      "url": "https://www.bok.or.kr/eng/main/contents.do?menuNo=400191"
    },
    {
      "locator": "Capitalpaymentparagraph",
      "quote_id": "KR-048",
      "read_date": "2026-11-16",
      "source": "KR",
      "url": "https://www.bok.or.kr/eng/main/contents.do?menuNo=400191"
    },
    {
      "locator": "Currentpaymentparagraph",
      "quote_id": "KR-049",
      "read_date": "2026-11-16",
      "source": "KR",
      "url": "https://www.bok.or.kr/eng/main/contents.do?menuNo=400191"
    }
  ],
  "section": "South Korea and Japan",
  "source_keys": [
    "KR"
  ]
}
```

### 47

BOJ's reporting explanation says FEFTA payment/receipt reporting captures resident/nonresident payments exceeding JPY 30,000,000, subject to its stated exceptions, including payments for goods whose export/import has been cleared through customs. Capital-transaction reporting under Article 55-3 is separate. This is reporting scope, not proof that every remittance is unlimited, every filing is post-transaction, or FEFTA restrictions concern only sensitive-sector investment. [BOJ, balance-of-payments source-report explanation](https://www.boj.or.jp/en/statistics/outline/exp/exbpsm6.htm)

```json
{
  "figures": [
    "30,000,000",
    "55",
    "3"
  ],
  "id": 47,
  "kind": "source-cited rule with actually read conditions",
  "line": 94,
  "operative_bindings": [
    {
      "locator": "Reports on paymentetc",
      "quote_id": "JP-050",
      "read_date": "2026-11-16",
      "source": "JP",
      "url": "https://www.boj.or.jp/en/statistics/outline/exp/exbpsm6.htm"
    },
    {
      "locator": "Goods exception",
      "quote_id": "JP-051",
      "read_date": "2026-11-16",
      "source": "JP",
      "url": "https://www.boj.or.jp/en/statistics/outline/exp/exbpsm6.htm"
    },
    {
      "locator": "Capital-reportheading",
      "quote_id": "JP-052",
      "read_date": "2026-11-16",
      "source": "JP",
      "url": "https://www.boj.or.jp/en/statistics/outline/exp/exbpsm6.htm"
    }
  ],
  "section": "South Korea and Japan",
  "source_keys": [
    "JP"
  ]
}
```

### 48

### Hong Kong, Singapore and the UAE

```json
{
  "figures": [],
  "id": 48,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 96,
  "operative_bindings": [],
  "section": "Hong Kong, Singapore and the UAE",
  "source_keys": []
}
```

### 49

Hong Kong Basic Law Article 112 provides no foreign-exchange controls, free convertibility and free capital flow. HKMA explains the linked-rate system's HKD 7.75-7.85 per USD band; the band is not a guaranteed customer dealing rate or evidence that Hong Kong is the best jurisdiction for a particular founder. Formation, fees, tax and payment-provider eligibility require their own facts. [Hong Kong Basic Law Articles111–112](https://www.basiclaw.gov.hk/en/basiclaw/chapter5.html) [HKMA Linked Exchange Rate System](https://www.hkma.gov.hk/eng/key-functions/money/linked-exchange-rate-system/)

```json
{
  "figures": [
    "112",
    "7.75",
    "7.85"
  ],
  "id": 49,
  "kind": "source-cited rule with actually read conditions",
  "line": 98,
  "operative_bindings": [
    {
      "locator": "Article112",
      "quote_id": "HK-053",
      "read_date": "2026-11-16",
      "source": "HK",
      "url": "https://www.basiclaw.gov.hk/en/basiclaw/chapter5.html"
    },
    {
      "locator": "Article112",
      "quote_id": "HK-054",
      "read_date": "2026-11-16",
      "source": "HK",
      "url": "https://www.basiclaw.gov.hk/en/basiclaw/chapter5.html"
    },
    {
      "locator": "Openingparagraph",
      "quote_id": "HKLINK-055",
      "read_date": "2026-11-16",
      "source": "HKLINK",
      "url": "https://www.hkma.gov.hk/eng/key-functions/money/linked-exchange-rate-system/"
    },
    {
      "locator": "Mainframework",
      "quote_id": "HKLINK-056",
      "read_date": "2026-11-16",
      "source": "HKLINK",
      "url": "https://www.hkma.gov.hk/eng/key-functions/money/linked-exchange-rate-system/"
    }
  ],
  "section": "Hong Kong, Singapore and the UAE",
  "source_keys": [
    "HK",
    "HKLINK"
  ]
}
```

### 50

For Singapore, the original statements about unrestricted MAS transactions, no reporting for most transfers, founder suitability and the interaction with another country's CFC rules remain separate non-usable propositions in Sources. A Singapore entity or account does not by itself answer the sender's home-country exchange/tax questions.

```json
{
  "figures": [],
  "id": 50,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 100,
  "operative_bindings": [],
  "section": "Hong Kong, Singapore and the UAE",
  "source_keys": []
}
```

### 51

The UAE government's tax page expressly states that it does not levy income tax on individuals and distinguishes 5% VAT from corporate tax on corporations/businesses. The old “5% personal income tax from January 2026” is corrected. This does not exempt a natural person's business from all corporate-tax questions or substantiate the original blanket capital/profit repatriation and any-currency transfer statements. [UAEgovernment taxation overview](https://u.ae/en/information-and-services/finance-and-investment/taxation)

```json
{
  "figures": [
    "5%",
    "5%",
    "2026"
  ],
  "id": 51,
  "kind": "source-cited rule with actually read conditions",
  "line": 102,
  "operative_bindings": [
    {
      "locator": "Mainintro",
      "quote_id": "UAETAX-072",
      "read_date": "2026-11-16",
      "source": "UAETAX",
      "url": "https://u.ae/en/information-and-services/finance-and-investment/taxation"
    },
    {
      "locator": "MainintroVAT",
      "quote_id": "UAETAX-073",
      "read_date": "2026-11-16",
      "source": "UAETAX",
      "url": "https://u.ae/en/information-and-services/finance-and-investment/taxation"
    }
  ],
  "section": "Hong Kong, Singapore and the UAE",
  "source_keys": [
    "UAETAX"
  ]
}
```

### 52

### United States: separate reports, separate tests

```json
{
  "figures": [],
  "id": 52,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 104,
  "operative_bindings": [],
  "section": "United States: separate reports, separate tests",
  "source_keys": []
}
```

### 53

| Report | Threshold and supported test | Primary source |

```json
{
  "figures": [],
  "id": 53,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 106,
  "operative_bindings": [],
  "section": "United States: separate reports, separate tests",
  "source_keys": []
}
```

### 54

| FBAR, FinCEN Form 114 | US person with the relevant financial interest or signature/other authority over foreign financial accounts; aggregate account value exceeding USD 10,000 at any time in the calendar year. Consider the stated exceptions; it is not a per-account test | [FinCEN foreign bank and financial account reporting](https://www.fincen.gov/report-foreign-bank-and-financial-accounts) |

```json
{
  "figures": [
    "114",
    "10,000"
  ],
  "id": 54,
  "kind": "source-cited rule with actually read conditions",
  "line": 108,
  "operative_bindings": [
    {
      "locator": "WhoMustFile",
      "quote_id": "FBAR-057",
      "read_date": "2026-11-16",
      "source": "FBAR",
      "url": "https://www.fincen.gov/report-foreign-bank-and-financial-accounts"
    },
    {
      "locator": "WhoMustFile",
      "quote_id": "FBAR-058",
      "read_date": "2026-11-16",
      "source": "FBAR",
      "url": "https://www.fincen.gov/report-foreign-bank-and-financial-accounts"
    },
    {
      "locator": "WhoMustFile",
      "quote_id": "FBAR-059",
      "read_date": "2026-11-16",
      "source": "FBAR",
      "url": "https://www.fincen.gov/report-foreign-bank-and-financial-accounts"
    }
  ],
  "section": "United States: separate reports, separate tests",
  "source_keys": [
    "FBAR"
  ]
}
```

### 55

| Form 8938, specified individual living in the US | Unmarried or married filing separately: more than USD 50,000 year-end or USD 75,000 at any time. Married filing jointly: more than USD 100,000 or USD 150,000 respectively | [IRS Form8938 continuous-use instructions,revision11/2021](https://www.irs.gov/instructions/i8938) |

```json
{
  "figures": [
    "8938",
    "50,000",
    "75,000",
    "100,000",
    "150,000",
    "938"
  ],
  "id": 55,
  "kind": "source-cited rule with actually read conditions",
  "line": 109,
  "operative_bindings": [
    {
      "locator": "USsingle/separate",
      "quote_id": "IRS8938-060",
      "read_date": "2026-11-16",
      "source": "IRS8938",
      "url": "https://www.irs.gov/instructions/i8938"
    },
    {
      "locator": "USsingle/separateanytime",
      "quote_id": "IRS8938-061",
      "read_date": "2026-11-16",
      "source": "IRS8938",
      "url": "https://www.irs.gov/instructions/i8938"
    },
    {
      "locator": "USjointyearend",
      "quote_id": "IRS8938-062",
      "read_date": "2026-11-16",
      "source": "IRS8938",
      "url": "https://www.irs.gov/instructions/i8938"
    },
    {
      "locator": "USjointanytime",
      "quote_id": "IRS8938-063",
      "read_date": "2026-11-16",
      "source": "IRS8938",
      "url": "https://www.irs.gov/instructions/i8938"
    },
    {
      "locator": "Abroadsingle/separateyearend",
      "quote_id": "IRS8938-064",
      "read_date": "2026-11-16",
      "source": "IRS8938",
      "url": "https://www.irs.gov/instructions/i8938"
    },
    {
      "locator": "Abroadsingle/separateanytime",
      "quote_id": "IRS8938-065",
      "read_date": "2026-11-16",
      "source": "IRS8938",
      "url": "https://www.irs.gov/instructions/i8938"
    },
    {
      "locator": "Abroadjointyearend",
      "quote_id": "IRS8938-066",
      "read_date": "2026-11-16",
      "source": "IRS8938",
      "url": "https://www.irs.gov/instructions/i8938"
    },
    {
      "locator": "Abroadjointanytime",
      "quote_id": "IRS8938-067",
      "read_date": "2026-11-16",
      "source": "IRS8938",
      "url": "https://www.irs.gov/instructions/i8938"
    },
    {
      "locator": "Presenceabroad",
      "quote_id": "IRS8938-068",
      "read_date": "2026-11-16",
      "source": "IRS8938",
      "url": "https://www.irs.gov/instructions/i8938"
    }
  ],
  "section": "United States: separate reports, separate tests",
  "source_keys": [
    "IRS8938"
  ]
}
```

### 56

| Form 8938, qualifying individual living abroad | Unmarried or married filing separately: more than USD 200,000 year-end or USD 300,000 at any time. Married filing jointly: more than USD 400,000 or USD 600,000 respectively | [IRS Form8938 continuous-use instructions,revision11/2021](https://www.irs.gov/instructions/i8938) |

```json
{
  "figures": [
    "8938",
    "200,000",
    "300,000",
    "400,000",
    "600,000",
    "938"
  ],
  "id": 56,
  "kind": "source-cited rule with actually read conditions",
  "line": 110,
  "operative_bindings": [
    {
      "locator": "USsingle/separate",
      "quote_id": "IRS8938-060",
      "read_date": "2026-11-16",
      "source": "IRS8938",
      "url": "https://www.irs.gov/instructions/i8938"
    },
    {
      "locator": "USsingle/separateanytime",
      "quote_id": "IRS8938-061",
      "read_date": "2026-11-16",
      "source": "IRS8938",
      "url": "https://www.irs.gov/instructions/i8938"
    },
    {
      "locator": "USjointyearend",
      "quote_id": "IRS8938-062",
      "read_date": "2026-11-16",
      "source": "IRS8938",
      "url": "https://www.irs.gov/instructions/i8938"
    },
    {
      "locator": "USjointanytime",
      "quote_id": "IRS8938-063",
      "read_date": "2026-11-16",
      "source": "IRS8938",
      "url": "https://www.irs.gov/instructions/i8938"
    },
    {
      "locator": "Abroadsingle/separateyearend",
      "quote_id": "IRS8938-064",
      "read_date": "2026-11-16",
      "source": "IRS8938",
      "url": "https://www.irs.gov/instructions/i8938"
    },
    {
      "locator": "Abroadsingle/separateanytime",
      "quote_id": "IRS8938-065",
      "read_date": "2026-11-16",
      "source": "IRS8938",
      "url": "https://www.irs.gov/instructions/i8938"
    },
    {
      "locator": "Abroadjointyearend",
      "quote_id": "IRS8938-066",
      "read_date": "2026-11-16",
      "source": "IRS8938",
      "url": "https://www.irs.gov/instructions/i8938"
    },
    {
      "locator": "Abroadjointanytime",
      "quote_id": "IRS8938-067",
      "read_date": "2026-11-16",
      "source": "IRS8938",
      "url": "https://www.irs.gov/instructions/i8938"
    },
    {
      "locator": "Presenceabroad",
      "quote_id": "IRS8938-068",
      "read_date": "2026-11-16",
      "source": "IRS8938",
      "url": "https://www.irs.gov/instructions/i8938"
    }
  ],
  "section": "United States: separate reports, separate tests",
  "source_keys": [
    "IRS8938"
  ]
}
```

### 57

| CTR | The financial institution's cash-in or cash-out reporting; known transactions by/on behalf of the same person aggregate within one business day and trigger reporting above USD 10,000. Cash-in and cash-out are not netted | [FinCEN CTR FAQ17,aggregation](https://www.fincen.gov/resources/frequently-asked-questions-regarding-fincen-currency-transaction-report-ctr) |

```json
{
  "figures": [
    "10,000"
  ],
  "id": 57,
  "kind": "source-cited rule with actually read conditions",
  "line": 111,
  "operative_bindings": [
    {
      "locator": "FAQ17",
      "quote_id": "CTR-069",
      "read_date": "2026-11-16",
      "source": "CTR",
      "url": "https://www.fincen.gov/resources/frequently-asked-questions-regarding-fincen-currency-transaction-report-ctr"
    },
    {
      "locator": "FAQ17",
      "quote_id": "CTR-070",
      "read_date": "2026-11-16",
      "source": "CTR",
      "url": "https://www.fincen.gov/resources/frequently-asked-questions-regarding-fincen-currency-transaction-report-ctr"
    },
    {
      "locator": "FAQ17",
      "quote_id": "CTR-071",
      "read_date": "2026-11-16",
      "source": "CTR",
      "url": "https://www.fincen.gov/resources/frequently-asked-questions-regarding-fincen-currency-transaction-report-ctr"
    }
  ],
  "section": "United States: separate reports, separate tests",
  "source_keys": [
    "CTR"
  ]
}
```

### 58

For Form 8938, establish that the person and assets are within scope and no exception applies. The abroad threshold requires a foreign tax home and the applicable bona fide-residence or 330-full-days presence test; living abroad in ordinary speech is insufficient. No income-tax-return filing obligation means no Form 8938 obligation under the instructions. The form does not replace FBAR. The table is for specified individuals, not the separate specified-domestic-entity test. [IRS Form8938 continuous-use instructions,revision11/2021](https://www.irs.gov/instructions/i8938)

```json
{
  "figures": [
    "8938",
    "330",
    "8938",
    "938"
  ],
  "id": 58,
  "kind": "source-cited rule with actually read conditions",
  "line": 113,
  "operative_bindings": [
    {
      "locator": "USsingle/separate",
      "quote_id": "IRS8938-060",
      "read_date": "2026-11-16",
      "source": "IRS8938",
      "url": "https://www.irs.gov/instructions/i8938"
    },
    {
      "locator": "USsingle/separateanytime",
      "quote_id": "IRS8938-061",
      "read_date": "2026-11-16",
      "source": "IRS8938",
      "url": "https://www.irs.gov/instructions/i8938"
    },
    {
      "locator": "USjointyearend",
      "quote_id": "IRS8938-062",
      "read_date": "2026-11-16",
      "source": "IRS8938",
      "url": "https://www.irs.gov/instructions/i8938"
    },
    {
      "locator": "USjointanytime",
      "quote_id": "IRS8938-063",
      "read_date": "2026-11-16",
      "source": "IRS8938",
      "url": "https://www.irs.gov/instructions/i8938"
    },
    {
      "locator": "Abroadsingle/separateyearend",
      "quote_id": "IRS8938-064",
      "read_date": "2026-11-16",
      "source": "IRS8938",
      "url": "https://www.irs.gov/instructions/i8938"
    },
    {
      "locator": "Abroadsingle/separateanytime",
      "quote_id": "IRS8938-065",
      "read_date": "2026-11-16",
      "source": "IRS8938",
      "url": "https://www.irs.gov/instructions/i8938"
    },
    {
      "locator": "Abroadjointyearend",
      "quote_id": "IRS8938-066",
      "read_date": "2026-11-16",
      "source": "IRS8938",
      "url": "https://www.irs.gov/instructions/i8938"
    },
    {
      "locator": "Abroadjointanytime",
      "quote_id": "IRS8938-067",
      "read_date": "2026-11-16",
      "source": "IRS8938",
      "url": "https://www.irs.gov/instructions/i8938"
    },
    {
      "locator": "Presenceabroad",
      "quote_id": "IRS8938-068",
      "read_date": "2026-11-16",
      "source": "IRS8938",
      "url": "https://www.irs.gov/instructions/i8938"
    }
  ],
  "section": "United States: separate reports, separate tests",
  "source_keys": [
    "IRS8938"
  ]
}
```

### 59

These are reporting triggers, not complete transfer, sanctions, bank-compliance or penalty rules. Do not use a wire amount as if it were cash, split payments to evade reporting, or rely on the original fixed per-account FBAR penalty/short Form 8938 escalation table. Exact offence/year-specific sanctions and the structuring offence require the actual applicable law; the former figures remain held in Sources. [FinCEN foreign bank and financial account reporting](https://www.fincen.gov/report-foreign-bank-and-financial-accounts) [FinCEN CTR FAQ17,aggregation](https://www.fincen.gov/resources/frequently-asked-questions-regarding-fincen-currency-transaction-report-ctr)

```json
{
  "figures": [
    "8938"
  ],
  "id": 59,
  "kind": "source-cited rule with actually read conditions",
  "line": 115,
  "operative_bindings": [
    {
      "locator": "WhoMustFile",
      "quote_id": "FBAR-057",
      "read_date": "2026-11-16",
      "source": "FBAR",
      "url": "https://www.fincen.gov/report-foreign-bank-and-financial-accounts"
    },
    {
      "locator": "WhoMustFile",
      "quote_id": "FBAR-058",
      "read_date": "2026-11-16",
      "source": "FBAR",
      "url": "https://www.fincen.gov/report-foreign-bank-and-financial-accounts"
    },
    {
      "locator": "WhoMustFile",
      "quote_id": "FBAR-059",
      "read_date": "2026-11-16",
      "source": "FBAR",
      "url": "https://www.fincen.gov/report-foreign-bank-and-financial-accounts"
    },
    {
      "locator": "FAQ17",
      "quote_id": "CTR-069",
      "read_date": "2026-11-16",
      "source": "CTR",
      "url": "https://www.fincen.gov/resources/frequently-asked-questions-regarding-fincen-currency-transaction-report-ctr"
    },
    {
      "locator": "FAQ17",
      "quote_id": "CTR-070",
      "read_date": "2026-11-16",
      "source": "CTR",
      "url": "https://www.fincen.gov/resources/frequently-asked-questions-regarding-fincen-currency-transaction-report-ctr"
    },
    {
      "locator": "FAQ17",
      "quote_id": "CTR-071",
      "read_date": "2026-11-16",
      "source": "CTR",
      "url": "https://www.fincen.gov/resources/frequently-asked-questions-regarding-fincen-currency-transaction-report-ctr"
    }
  ],
  "section": "United States: separate reports, separate tests",
  "source_keys": [
    "FBAR",
    "CTR"
  ]
}
```

### 60

### European Union: capital freedom, cash and payment charges

```json
{
  "figures": [],
  "id": 60,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 117,
  "operative_bindings": [],
  "section": "European Union: capital freedom, cash and payment charges",
  "source_keys": []
}
```

### 61

TFEU Article 63 prohibits capital and payment restrictions within the framework of its chapter, including movements with third countries. Article 65 permits the specified tax distinctions, anti-infringement/prudential measures, administrative/statistical declarations and public-policy/security measures, subject to its conditions and prohibition on arbitrary discrimination or disguised restriction. It is not a universal waiver of national tax/account reporting or all other chapter exceptions. [TFEU Article63](https://publications.europa.eu/resource/cellar/9912914b-f9a7-4f78-b34e-d3e6a2d71f67.0005.01/DOC_1) [TFEU Article65](https://publications.europa.eu/resource/cellar/f07ba7d3-e51a-4b86-915f-771a9e18ece7.0005.01/DOC_1)

```json
{
  "figures": [
    "63",
    "65",
    "3",
    "5"
  ],
  "id": 61,
  "kind": "source-cited rule with actually read conditions",
  "line": 119,
  "operative_bindings": [
    {
      "locator": "Article63(1)/(2)",
      "quote_id": "EU63-074",
      "read_date": "2026-11-16",
      "source": "EU63",
      "url": "https://publications.europa.eu/resource/cellar/9912914b-f9a7-4f78-b34e-d3e6a2d71f67.0005.01/DOC_1"
    },
    {
      "locator": "Article65(1)(b)",
      "quote_id": "EU65-075",
      "read_date": "2026-11-16",
      "source": "EU65",
      "url": "https://publications.europa.eu/resource/cellar/f07ba7d3-e51a-4b86-915f-771a9e18ece7.0005.01/DOC_1"
    },
    {
      "locator": "Article65(3)",
      "quote_id": "EU65-076",
      "read_date": "2026-11-16",
      "source": "EU65",
      "url": "https://publications.europa.eu/resource/cellar/f07ba7d3-e51a-4b86-915f-771a9e18ece7.0005.01/DOC_1"
    }
  ],
  "section": "European Union: capital freedom, cash and payment charges",
  "source_keys": [
    "EU63",
    "EU65"
  ]
}
```

### 62

Regulation 2018/1672 Articles 1-3 requires a carrier entering or leaving the Union with defined cash worth EUR 10,000 or more to declare it and make it available for control; incorrect/incomplete information or failure to make it available does not fulfil the duty. “Cash” is the regulation's defined category, including relevant bearer instruments and listed stores of value, rather than every electronic bank balance. The rule is an external-Union border rule; do not restate it as all intra-EU crossings or only amounts strictly greater than the threshold. Separate national controls and unaccompanied-cash rules need their own applicable scope. [RegulationEU2018/1672cashcontrols](https://publications.europa.eu/resource/cellar/71d1af91-e611-11e8-b690-01aa75ed71a1.0006.03/DOC_1)

```json
{
  "figures": [
    "2018",
    "1672",
    "1",
    "3",
    "10,000"
  ],
  "id": 62,
  "kind": "source-cited rule with actually read conditions",
  "line": 121,
  "operative_bindings": [
    {
      "locator": "Article3(1)",
      "quote_id": "EUCASH-077",
      "read_date": "2026-11-16",
      "source": "EUCASH",
      "url": "https://publications.europa.eu/resource/cellar/71d1af91-e611-11e8-b690-01aa75ed71a1.0006.03/DOC_1"
    },
    {
      "locator": "Article3(1)",
      "quote_id": "EUCASH-078",
      "read_date": "2026-11-16",
      "source": "EUCASH",
      "url": "https://publications.europa.eu/resource/cellar/71d1af91-e611-11e8-b690-01aa75ed71a1.0006.03/DOC_1"
    }
  ],
  "section": "European Union: capital freedom, cash and payment charges",
  "source_keys": [
    "EUCASH"
  ]
}
```

### 63

Regulation 2021/1230 Article 3 equalises the provider's charges for cross-border euro payments with corresponding national payments; it extends to another national currency only under the regulation's notification framework. The provider must identify the corresponding national payment. Currency-conversion charges are excluded from that equality rule. Article 3(5), added by Regulation 2024/886, disapplies Article 3(1) for a cross-border instant credit transfer in euro by a provider in a non-euro Member State where Regulation 260/2012 Article 5b(1) would require a lower charge for the same transfer. Article 5b(1) caps instant-transfer charges at those for other credit transfers of corresponding type; its ordinary provider compliance dates are 9 January 2025 in euro Member States and 9 January 2027 in non-euro Member States. Check the applicable transition, including Article 16(9) for a state introducing the euro; do not assume a uniform 2026 instant-transfer fee cap. Under amended Article 6(2), failure to communicate the IBAN and, where appropriate under Regulation 260/2012, the related BIC can permit additional charges only if appropriate, in line with costs, agreed and disclosed in good time before the user is bound. SEPA or the euro label is not a promise that all transfers/FX are free or that all domestic and cross-border procedures are identical. [RegulationEU2021/1230cross-borderpayments](https://publications.europa.eu/resource/cellar/2b7c281b-f0d1-11eb-a71c-01aa75ed71a1.0006.03/DOC_1) [RegulationEU2024/886, current cross-border charge amendments](https://publications.europa.eu/resource/cellar/d395dbf7-e597-11ee-8b2b-01aa75ed71a1.0006.03/DOC_1)

```json
{
  "figures": [
    "2021",
    "1230",
    "3",
    "3",
    "5",
    "2024",
    "886",
    "3",
    "1",
    "260",
    "2012",
    "1",
    "1",
    "9",
    "2025",
    "9",
    "2027",
    "16",
    "9",
    "2026",
    "6",
    "2",
    "260",
    "2012",
    "024"
  ],
  "id": 63,
  "kind": "source-cited rule with actually read conditions",
  "line": 123,
  "operative_bindings": [
    {
      "locator": "Article3(4)",
      "quote_id": "EUCHARGES-079",
      "read_date": "2026-11-16",
      "source": "EUCHARGES",
      "url": "https://publications.europa.eu/resource/cellar/2b7c281b-f0d1-11eb-a71c-01aa75ed71a1.0006.03/DOC_1"
    },
    {
      "locator": "Article3(1)",
      "quote_id": "EUCHARGES-080",
      "read_date": "2026-11-16",
      "source": "EUCHARGES",
      "url": "https://publications.europa.eu/resource/cellar/2b7c281b-f0d1-11eb-a71c-01aa75ed71a1.0006.03/DOC_1"
    },
    {
      "locator": "Article2(1),newArticle3(5)",
      "quote_id": "EU2024-081",
      "read_date": "2026-11-16",
      "source": "EU2024",
      "url": "https://publications.europa.eu/resource/cellar/d395dbf7-e597-11ee-8b2b-01aa75ed71a1.0006.03/DOC_1"
    },
    {
      "locator": "InsertedArticle5b(3),non-europroviderdate",
      "quote_id": "EU2024-082",
      "read_date": "2026-11-16",
      "source": "EU2024",
      "url": "https://publications.europa.eu/resource/cellar/d395dbf7-e597-11ee-8b2b-01aa75ed71a1.0006.03/DOC_1"
    },
    {
      "locator": "Article2(2),newArticle6(2)",
      "quote_id": "EU2024-083",
      "read_date": "2026-11-16",
      "source": "EU2024",
      "url": "https://publications.europa.eu/resource/cellar/d395dbf7-e597-11ee-8b2b-01aa75ed71a1.0006.03/DOC_1"
    }
  ],
  "section": "European Union: capital freedom, cash and payment charges",
  "source_keys": [
    "EUCHARGES",
    "EU2024"
  ]
}
```

### 64

### China: foreign income, credit and the actual notice

```json
{
  "figures": [],
  "id": 64,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 125,
  "operative_bindings": [],
  "section": "China: foreign income, credit and the actual notice",
  "source_keys": []
}
```

### 65

The official resident-individual foreign-income announcement distinguishes comprehensive income, business income and other categories. Comprehensive income is combined with domestic comprehensive income; business is separately combined under its rules, with foreign losses not offset against domestic or another country's business income and carried within the relevant country rules. Other categories use their separate calculation. A single gross-income ratio for every kind of income is therefore incorrect. [China resident-individual foreign-income announcement2020No3](https://12366.chinatax.gov.cn/bzds/082/082-5-4.html)

```json
{
  "figures": [],
  "id": 65,
  "kind": "source-cited rule with actually read conditions",
  "line": 127,
  "operative_bindings": [
    {
      "locator": "II/III",
      "quote_id": "CNIT-011",
      "read_date": "2026-11-16",
      "source": "CNIT",
      "url": "https://12366.chinatax.gov.cn/bzds/082/082-5-4.html"
    },
    {
      "locator": "VI",
      "quote_id": "CNIT-012",
      "read_date": "2026-11-16",
      "source": "CNIT",
      "url": "https://12366.chinatax.gov.cn/bzds/082/082-5-4.html"
    },
    {
      "locator": "VII",
      "quote_id": "CNIT-013",
      "read_date": "2026-11-16",
      "source": "CNIT",
      "url": "https://12366.chinatax.gov.cn/bzds/082/082-5-4.html"
    },
    {
      "locator": "III",
      "quote_id": "CNIT-014",
      "read_date": "2026-11-16",
      "source": "CNIT",
      "url": "https://12366.chinatax.gov.cn/bzds/082/082-5-4.html"
    }
  ],
  "section": "China: foreign income, credit and the actual notice",
  "source_keys": [
    "CNIT"
  ]
}
```

### 66

For the country credit limit, the announcement separately allocates computed comprehensive-income tax by that country's comprehensive-income amount over total comprehensive-income amount, business-income tax by the relevant taxable-business-income ratio, and the Chinese-law tax for other categories, then sums the category limits for that country. Creditable foreign income tax must be legally due and actually paid; treaty-not-due or wrongly paid tax, interest/penalties, compensated tax and tax on exempt foreign income are excluded under the stated rules. Conditional treaty tax sparing is separate. Credit is limited to the lower eligible foreign tax or country limit; excess can be carried to the following five tax years within the rule, not refunded by China merely because it exceeds that year's credit limit. [China resident-individual foreign-income announcement2020No3](https://12366.chinatax.gov.cn/bzds/082/082-5-4.html)

```json
{
  "figures": [],
  "id": 66,
  "kind": "source-cited rule with actually read conditions",
  "line": 129,
  "operative_bindings": [
    {
      "locator": "II/III",
      "quote_id": "CNIT-011",
      "read_date": "2026-11-16",
      "source": "CNIT",
      "url": "https://12366.chinatax.gov.cn/bzds/082/082-5-4.html"
    },
    {
      "locator": "VI",
      "quote_id": "CNIT-012",
      "read_date": "2026-11-16",
      "source": "CNIT",
      "url": "https://12366.chinatax.gov.cn/bzds/082/082-5-4.html"
    },
    {
      "locator": "VII",
      "quote_id": "CNIT-013",
      "read_date": "2026-11-16",
      "source": "CNIT",
      "url": "https://12366.chinatax.gov.cn/bzds/082/082-5-4.html"
    },
    {
      "locator": "III",
      "quote_id": "CNIT-014",
      "read_date": "2026-11-16",
      "source": "CNIT",
      "url": "https://12366.chinatax.gov.cn/bzds/082/082-5-4.html"
    }
  ],
  "section": "China: foreign income, credit and the actual notice",
  "source_keys": [
    "CNIT"
  ]
}
```

### 67

A resident individual with foreign income files from 1 March to 30 June of the following year under the announcement: for 2025 income that is 1 March-30 June 2026. Apply the announcement's tax-year, competent-office and documentary rules; retain foreign assessments/certificates and payment evidence, or its permitted alternative evidence. Its limited prior-year credit/correction route requires the actual conditions. The old mobile-app click path is not a verified current filing procedure. [China resident-individual foreign-income announcement2020No3](https://12366.chinatax.gov.cn/bzds/082/082-5-4.html)

```json
{
  "figures": [
    "1",
    "30",
    "2025",
    "1",
    "30",
    "2026"
  ],
  "id": 67,
  "kind": "source-cited rule with actually read conditions",
  "line": 131,
  "operative_bindings": [
    {
      "locator": "II/III",
      "quote_id": "CNIT-011",
      "read_date": "2026-11-16",
      "source": "CNIT",
      "url": "https://12366.chinatax.gov.cn/bzds/082/082-5-4.html"
    },
    {
      "locator": "VI",
      "quote_id": "CNIT-012",
      "read_date": "2026-11-16",
      "source": "CNIT",
      "url": "https://12366.chinatax.gov.cn/bzds/082/082-5-4.html"
    },
    {
      "locator": "VII",
      "quote_id": "CNIT-013",
      "read_date": "2026-11-16",
      "source": "CNIT",
      "url": "https://12366.chinatax.gov.cn/bzds/082/082-5-4.html"
    },
    {
      "locator": "III",
      "quote_id": "CNIT-014",
      "read_date": "2026-11-16",
      "source": "CNIT",
      "url": "https://12366.chinatax.gov.cn/bzds/082/082-5-4.html"
    }
  ],
  "section": "China: foreign income, credit and the actual notice",
  "source_keys": [
    "CNIT"
  ]
}
```

### 68

CRS is an information-exchange framework, not an exemption from a person's return or proof that every foreign account is automatically reported to China. The independently reviewed EU Annex I definitions distinguish reportable accounts, persons, controlling persons and reportable jurisdictions; that EU source is a framework example, not evidence of every national exchange relationship. [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1) Determine the reporting institution/account/holder or controlling-person status, the relevant reporting-jurisdiction list and actual exchange relationship under the applicable year's law. Use the separately reviewed `fatca-crs-automatic-exchange.md` for those tests; specific country-list/relationship and the old wealth-band-enforcement assertions remain held here. Neither a US account nor an offshore company establishes secrecy or non-taxability.

```json
{
  "figures": [],
  "id": 68,
  "kind": "source-cited rule with actually read conditions",
  "line": 133,
  "operative_bindings": [
    {
      "locator": "AnnexISectionVIII(D)(1)",
      "quote_id": "CRSREUSE-073",
      "read_date": "2026-11-16",
      "source": "CRSREUSE",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    }
  ],
  "section": "China: foreign income, credit and the actual notice",
  "source_keys": [
    "CRSREUSE"
  ]
}
```

### 69

For a compliance reminder, risk/interview notice or formal audit notice, preserve the exact document, identity of the issuing office, tax years, requested records, service date and stated response date. Reconcile bank receipts, company ownership, salary/fees/dividends, returns and foreign tax evidence. Preserve documents and obtain representation appropriate to the notice; do not assign a universal low/medium urgency or invent a fixed response period from the notice's informal label. These are case-handling steps, not a verified Chinese statutory notice taxonomy or guaranteed penalty concession.

```json
{
  "figures": [],
  "id": 69,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 135,
  "operative_bindings": [],
  "section": "China: foreign income, credit and the actual notice",
  "source_keys": []
}
```

### 70

### Enforcement: classify the offence before quoting a sanction

```json
{
  "figures": [],
  "id": 70,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 137,
  "operative_bindings": [],
  "section": "Enforcement: classify the offence before quoting a sanction",
  "source_keys": []
}
```

### 71

The Current Account Foreign Exchange Business Guidelines (2020), Articles 62-63 and Annex 6, address evasion of quota/authenticity controls. The 2026 effective-law catalogue and the official amendment notes were checked for the used clauses; the earlier Notice 2015/49 was repealed by the 2020 instrument and is not the operative authority here. It distinguishes quota-lending warnings and repeat conduct from borrowing/other evasion that enters the watch list. The stated monitoring period is the listing calendar year plus the next two consecutive years; listed people use identity and transaction-value supporting documents, with strict authenticity review. It is not a uniform two-year prohibition on all exchange purchases or automatic account-freeze rule. The later official catalogue and the used amendment scopes do not change this monitoring/document rule. [SAFE Current Account Guidelines2020, watch-list clauses](https://www.safe.gov.cn/beijing/file/file/20250901/f03a39d891024861a8ce859dab124f06.pdf)

```json
{
  "figures": [
    "2020",
    "62",
    "63",
    "6",
    "2026",
    "2015",
    "49",
    "2020"
  ],
  "id": 71,
  "kind": "source-cited rule with actually read conditions",
  "line": 139,
  "operative_bindings": [
    {
      "locator": "Article62(3)",
      "quote_id": "CNWATCH-008",
      "read_date": "2026-11-16",
      "source": "CNWATCH",
      "url": "https://www.safe.gov.cn/beijing/file/file/20250901/f03a39d891024861a8ce859dab124f06.pdf"
    },
    {
      "locator": "Article62(3)/Annex6",
      "quote_id": "CNWATCH-009",
      "read_date": "2026-11-16",
      "source": "CNWATCH",
      "url": "https://www.safe.gov.cn/beijing/file/file/20250901/f03a39d891024861a8ce859dab124f06.pdf"
    },
    {
      "locator": "Article62(1)",
      "quote_id": "CNWATCH-010",
      "read_date": "2026-11-16",
      "source": "CNWATCH",
      "url": "https://www.safe.gov.cn/beijing/file/file/20250901/f03a39d891024861a8ce859dab124f06.pdf"
    }
  ],
  "section": "Enforcement: classify the offence before quoting a sanction",
  "source_keys": [
    "CNWATCH"
  ]
}
```

### 72

The Foreign Exchange Administration Regulations distinguish offences. Article 39 unlawful outward transfer/evasion and Article 40 unlawful exchange acquisition provide ordinary fines up to 30% of the offence amount, and serious-case fines from 30% up to that amount, alongside their correction/return and possible criminal-liability provisions. Other offences have their own provisions; a 30% figure is not a universal mandatory fine, and these clauses do not establish the old fixed imprisonment or income-tax-penalty claims. [China Foreign Exchange Administration Regulations, Order532](https://www.safe.gov.cn/neimenggu/file/file/20170728/b663448ec2f74289b194838d47b8df95.pdf)

```json
{
  "figures": [
    "39",
    "40",
    "30%",
    "30%",
    "30%"
  ],
  "id": 72,
  "kind": "source-cited rule with actually read conditions",
  "line": 141,
  "operative_bindings": [
    {
      "locator": "Article12",
      "quote_id": "CNFX-004",
      "read_date": "2026-11-16",
      "source": "CNFX",
      "url": "https://www.safe.gov.cn/neimenggu/file/file/20170728/b663448ec2f74289b194838d47b8df95.pdf"
    },
    {
      "locator": "Article17",
      "quote_id": "CNFX-005",
      "read_date": "2026-11-16",
      "source": "CNFX",
      "url": "https://www.safe.gov.cn/neimenggu/file/file/20170728/b663448ec2f74289b194838d47b8df95.pdf"
    },
    {
      "locator": "Articles39/40",
      "quote_id": "CNFX-006",
      "read_date": "2026-11-16",
      "source": "CNFX",
      "url": "https://www.safe.gov.cn/neimenggu/file/file/20170728/b663448ec2f74289b194838d47b8df95.pdf"
    },
    {
      "locator": "Articles39/40",
      "quote_id": "CNFX-007",
      "read_date": "2026-11-16",
      "source": "CNFX",
      "url": "https://www.safe.gov.cn/neimenggu/file/file/20170728/b663448ec2f74289b194838d47b8df95.pdf"
    }
  ],
  "section": "Enforcement: classify the offence before quoting a sanction",
  "source_keys": [
    "CNFX"
  ]
}
```

### 73

## Worked cases

```json
{
  "figures": [],
  "id": 73,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 143,
  "operative_bindings": [],
  "section": "Worked cases",
  "source_keys": []
}
```

### 74

### Case 1: ordinary India LRS collection, two purposes

```json
{
  "figures": [
    "1"
  ],
  "id": 74,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 145,
  "operative_bindings": [],
  "section": "Case 1: ordinary India LRS collection, two purposes",
  "source_keys": []
}
```

### 75

Assume an eligible resident individual makes a single permitted INR 1,600,000 LRS remittance in the relevant financial year after 1 April 2026, with no earlier LRS remittance, qualifying education loan, tour-package overlap, tax-deduction exclusion, higher-rate identifier/default issue or lower certificate. The threshold excess is INR 1,600,000 - INR 1,000,000 = INR 600,000. For qualifying education/medical use, normal collection is INR 600,000 × 2% = INR 12,000; for another purpose it is INR 600,000 × 20% = INR 120,000. This compares statutory collection under the assumptions; it does not establish ODI eligibility, the FX conversion, the person's final tax, or a refund. [Income-tax Act2025 as amended by Finance Act2026](https://www.incometaxindia.gov.in/documents/d/guest/income_tax_act_2025_as_amended_by_fa_act_2026-pdf)

```json
{
  "figures": [
    "1,600,000",
    "1",
    "2026",
    "1,600,000",
    "1,000,000",
    "600,000",
    "600,000",
    "2%",
    "12,000",
    "600,000",
    "20%",
    "120,000"
  ],
  "id": 75,
  "kind": "source-cited rule with actually read conditions",
  "line": 147,
  "operative_bindings": [
    {
      "locator": "394(1)Table7",
      "quote_id": "INTCS-023",
      "read_date": "2026-11-16",
      "source": "INTCS",
      "url": "https://www.incometaxindia.gov.in/documents/d/guest/income_tax_act_2025_as_amended_by_fa_act_2026-pdf"
    },
    {
      "locator": "394(1)Table7(a)",
      "quote_id": "INTCS-024",
      "read_date": "2026-11-16",
      "source": "INTCS",
      "url": "https://www.incometaxindia.gov.in/documents/d/guest/income_tax_act_2025_as_amended_by_fa_act_2026-pdf"
    },
    {
      "locator": "394(1)Table7(b)",
      "quote_id": "INTCS-025",
      "read_date": "2026-11-16",
      "source": "INTCS",
      "url": "https://www.incometaxindia.gov.in/documents/d/guest/income_tax_act_2025_as_amended_by_fa_act_2026-pdf"
    },
    {
      "locator": "394(1)(c)",
      "quote_id": "INTCS-026",
      "read_date": "2026-11-16",
      "source": "INTCS",
      "url": "https://www.incometaxindia.gov.in/documents/d/guest/income_tax_act_2025_as_amended_by_fa_act_2026-pdf"
    },
    {
      "locator": "FinanceAct2026footnote88b",
      "quote_id": "INTCS-027",
      "read_date": "2026-11-16",
      "source": "INTCS",
      "url": "https://www.incometaxindia.gov.in/documents/d/guest/income_tax_act_2025_as_amended_by_fa_act_2026-pdf"
    },
    {
      "locator": "394(4)(a),sameamountselleralreadycollected",
      "quote_id": "INTCS-028",
      "read_date": "2026-11-16",
      "source": "INTCS",
      "url": "https://www.incometaxindia.gov.in/documents/d/guest/income_tax_act_2025_as_amended_by_fa_act_2026-pdf"
    }
  ],
  "section": "Case 1: ordinary India LRS collection, two purposes",
  "source_keys": [
    "INTCS"
  ]
}
```

### 76

### Case 2: China credit limit keeps income categories separate

```json
{
  "figures": [
    "2"
  ],
  "id": 76,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 166,
  "operative_bindings": [],
  "section": "Case 2: China credit limit keeps income categories separate",
  "source_keys": []
}
```

### 77

Assume a Chinese resident has only comprehensive income for the illustrated computation, with hypothetical Chinese-law computed comprehensive tax of RMB 90,000, total comprehensive-income amount RMB 600,000 and the relevant country's comprehensive-income amount RMB 200,000. Assume eligible legally due foreign income tax of RMB 40,000 actually paid, no treaty tax-sparing or other-category amount, and no prior carry-forward. The category/country limit is RMB 90,000 × RMB 200,000 / RMB 600,000 = RMB 30,000. Current credit is the lower of RMB 40,000 and RMB 30,000 = RMB 30,000; excess RMB 10,000 is a potential carry-forward subject to the following-five-tax-years rule and actual evidence/remaining-limit conditions. The RMB 90,000 and income amounts are supplied assumptions, not derived Chinese rates or a gross-worldwide-income shortcut. Other income categories would require their separate components. [China resident-individual foreign-income announcement2020No3](https://12366.chinatax.gov.cn/bzds/082/082-5-4.html)

```json
{
  "figures": [
    "90,000",
    "600,000",
    "200,000",
    "40,000",
    "90,000",
    "200,000",
    "600,000",
    "30,000",
    "40,000",
    "30,000",
    "30,000",
    "10,000",
    "90,000"
  ],
  "id": 77,
  "kind": "source-cited rule with actually read conditions",
  "line": 168,
  "operative_bindings": [
    {
      "locator": "II/III",
      "quote_id": "CNIT-011",
      "read_date": "2026-11-16",
      "source": "CNIT",
      "url": "https://12366.chinatax.gov.cn/bzds/082/082-5-4.html"
    },
    {
      "locator": "VI",
      "quote_id": "CNIT-012",
      "read_date": "2026-11-16",
      "source": "CNIT",
      "url": "https://12366.chinatax.gov.cn/bzds/082/082-5-4.html"
    },
    {
      "locator": "VII",
      "quote_id": "CNIT-013",
      "read_date": "2026-11-16",
      "source": "CNIT",
      "url": "https://12366.chinatax.gov.cn/bzds/082/082-5-4.html"
    },
    {
      "locator": "III",
      "quote_id": "CNIT-014",
      "read_date": "2026-11-16",
      "source": "CNIT",
      "url": "https://12366.chinatax.gov.cn/bzds/082/082-5-4.html"
    }
  ],
  "section": "Case 2: China credit limit keeps income categories separate",
  "source_keys": [
    "CNIT"
  ]
}
```

### 78

## When to refuse or refer

```json
{
  "figures": [],
  "id": 78,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 187,
  "operative_bindings": [],
  "section": "When to refuse or refer",
  "source_keys": []
}
```

### 79

Stop a transfer recommendation or filing conclusion if residence/entity/purpose, current route, decisive documents or an actual notice deadline is missing. Refer transactions needing investment approval, sanctions/AML review, a disputed foreign-tax credit or offence-specific advice to the appropriate qualified adviser. A company in Hong Kong, Singapore or the US, an OBU account, a provider name or offshore retention is not an exemption. Do not divide payments, lend quotas, misdescribe a salary/service/dividend as family support, or destroy records.

```json
{
  "figures": [],
  "id": 79,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 189,
  "operative_bindings": [],
  "section": "When to refuse or refer",
  "source_keys": []
}
```

### 80

For a reviewable output, record each obligation separately: permission/registration, bank declaration and documents, collection and final tax, annual account reporting, physical-cash reporting, and the relevant source/period. An amount cleared for one question does not answer the others.

```json
{
  "figures": [],
  "id": 80,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 191,
  "operative_bindings": [],
  "section": "When to refuse or refer",
  "source_keys": []
}
```

### 81

The original personal/company, investment, offshore-income, CFC, payment-provider, penalty and inquiry topics remain within the research record. The precise unresolved items below require actual source work before use; they are not alternative current rules.

```json
{
  "figures": [],
  "id": 81,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 193,
  "operative_bindings": [],
  "section": "When to refuse or refer",
  "source_keys": []
}
```

### 82

*Original content: [Artin (@ar-gen-tin)](https://github.com/ar-gen-tin/panrise) — MIT License.*

```json
{
  "figures": [],
  "id": 82,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 195,
  "operative_bindings": [],
  "section": "When to refuse or refer",
  "source_keys": []
}
```

### 83

*OpenAccountants — open-source accounting skills for AI — info@openaaccountants.com*

```json
{
  "figures": [],
  "id": 83,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 197,
  "operative_bindings": [],
  "section": "When to refuse or refer",
  "source_keys": []
}
```

### 84

## Sources

```json
{
  "figures": [],
  "id": 84,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 199,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 85

Read dates identify the actual operative scopes, including bounded reuse of already completed independent work; they do not mean every page of a linked site or instrument was read. The scanned Taiwan order was personally read as an image; its empty text extraction was not counted as a read. Older foundational sources have the stated limits. A failed download, bare landing page or search snippet was not treated as operative authority.

```json
{
  "figures": [],
  "id": 85,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 201,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 86

| Official source | Actually read scope and limits | Read on |

```json
{
  "figures": [],
  "id": 86,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 203,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 87

| [SAFE Shanghai personal exchange explanation](https://www.safe.gov.cn/shanghai/2019/1213/1198.html) | Read for Whole used main explanation: annual convenience amounts, genuine current-account over-amount evidence, listed prohibited capital uses and truthful-purpose/quota warnings. 2019 official explanation, corroborated by the current-account and currentness captures; not all capital-account procedures | 2026-11-16 |

```json
{
  "figures": [
    "2019",
    "2026",
    "11",
    "16"
  ],
  "id": 87,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 205,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 88

| [China Foreign Exchange Administration Regulations, Order532](https://www.safe.gov.cn/neimenggu/file/file/20170728/b663448ec2f74289b194838d47b8df95.pdf) | Read for Articles12–23 and39–48; definitions52 and commencement54 read; currentness catalogue item1. 2008 foundational instrument remains in the2026 effective-law catalogue; no complete current ODI execution clearance | 2026-11-16 |

```json
{
  "figures": [
    "32",
    "2",
    "23",
    "9",
    "48",
    "2",
    "4",
    "2008",
    "026",
    "2026",
    "11",
    "16"
  ],
  "id": 88,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 206,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 89

| [SAFE Current Account Guidelines2020, watch-list clauses](https://www.safe.gov.cn/beijing/file/file/20250901/f03a39d891024861a8ce859dab124f06.pdf) | Read for Articles62–63,Annex6 and repeal-list item21; current instrument introduction; bounded2026 catalogue and2023/2024 amendment notes checked. Actual operative2020 source replaces repealed2015/49; not a whole-current-account-law review | 2026-11-16 |

```json
{
  "figures": [
    "020",
    "2",
    "63,",
    "1",
    "026",
    "023",
    "2024",
    "020",
    "015",
    "49",
    "2026",
    "11",
    "16"
  ],
  "id": 89,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 207,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 90

| [China resident-individual foreign-income announcement2020No3](https://12366.chinatax.gov.cn/bzds/082/082-5-4.html) | Read for Whole used announcement II–XIV; country/category credit formulas and exclusions,actual-tax evidence,carry-forward,filing window and source-year rules. Actual official legal web body read; no current mobile-app procedure or offence-specific penalty law | 2026-11-16 |

```json
{
  "figures": [
    "2026",
    "11",
    "16"
  ],
  "id": 90,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 208,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 91

| [RBI Master Direction, Liberalised Remittance Scheme](https://rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=10192) | Read for A1–7,13–19 and B1–5; ordinary amount,all used exclusions and purpose-specific facilities,form/PAN,retention and repatriation. Actual used clauses read in full including allA7 exceptions; referred2022 ODI instruments not read in full | 2026-11-16 |

```json
{
  "figures": [
    "7,13",
    "19",
    "5",
    "022",
    "2026",
    "11",
    "16"
  ],
  "id": 91,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 209,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 92

| [Income-tax Act2025 as amended by Finance Act2026](https://www.incometaxindia.gov.in/documents/d/guest/income_tax_act_2025_as_amended_by_fa_act_2026-pdf) | Read for Section394(1)–(5) including allTable7/8/exclusions and2026effective footnotes;395(3)–(4) actual separately read in web-forex-tax-operative capture. Actual official686-page PDF used scope read through official web, direct download403 retained; not entire Act read,refund/high-rate rules not cleared | 2026-11-16 |

```json
{
  "figures": [
    "025",
    "026",
    "94",
    "1",
    "5",
    "8",
    "395",
    "3",
    "4",
    "86",
    "03",
    "2026",
    "11",
    "16"
  ],
  "id": 92,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 210,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 93

| [Banco Central do Brasil, Cartilha de Câmbio2026](https://aprendervalor.bcb.gov.br/content/estabilidadefinanceira/politica_cambial/Cartilha_cambio_2026.pdf) | Read for Intro authorised institution/identity; inbound payment orderp6–7; outboundp9–10; wholeVETp14. Actual used complete payment-method paragraphs read; not current IOF operation-specific legislation | 2026-11-16 |

```json
{
  "figures": [
    "026",
    "7",
    "10",
    "4",
    "2026",
    "11",
    "16"
  ],
  "id": 93,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 211,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 94

| [CBC declaration regulations,26December2022revision](https://www.cbc.gov.tw/tw/dl-171561-a2f2e7bbd39d4e2c8abc05b2f3e5bc7c.html) | Read for Articles1–7in full,including definitions,per-transaction,annual,document and approval routes;2024Article7Order overlays4/6amounts. This current-linked2022PDF replaces older retrievedPDF; printed5m/50m expressly overlaid,not silently used as current | 2026-11-16 |

```json
{
  "figures": [
    "2026",
    "11",
    "16"
  ],
  "id": 94,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 212,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 95

| [CBC31October2024annual-settlement adjustment order](https://www.cbc.gov.tw/tw/dl-212210-8b20d63a34cf4b098a130e529e3f0e45.html) | Read for Whole single-page scanned order: authorityArticle7,amended4(1)(3)/6(1)(1),both raisedamounts,effective1November2024. Personally read actual rendered scan; own complete operative transcription; pdftotext was empty,not evidence of reading | 2026-11-16 |

```json
{
  "figures": [
    "1",
    "3",
    "6",
    "1",
    "1",
    "024",
    "2026",
    "11",
    "16"
  ],
  "id": 95,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 213,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 96

| [CBC current inward/outward funds FAQ](https://www.cbc.gov.tw/tw/cp-1179-101135-49647-1.html) | Read for Whole substantiveI/II(a)/(b):NTD distinction,declaration threshold,goods/services/investment anddirect-bank/above-amount route. LiveofficialFAQ matches2024Order; oldpage publicationdate doesnot overrideactualoperativeorder | 2026-11-16 |

```json
{
  "figures": [
    "2026",
    "11",
    "16"
  ],
  "id": 96,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 214,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 97

| [Bank of Korea, foreign-exchange transaction procedures](https://www.bok.or.kr/eng/main/contents.do?menuNo=400191) | Read for MainTransactionType,Payment/Receipt andmethod framework with neighbor numerical examples assessed for scope. OlderEnglishpage is not adequatecurrent2026numeric-clearance; only bounded procedure distinction adopted | 2026-11-16 |

```json
{
  "figures": [
    "2026",
    "11",
    "16"
  ],
  "id": 97,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 215,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 98

| [BOJ, balance-of-payments source-report explanation](https://www.boj.or.jp/en/statistics/outline/exp/exbpsm6.htm) | Read for Introreportingframework and completepayment-reportArticle55paragraph inclcustoms exception;capital-reportArticle55-3scope. Officialexplanation/TentativeEnglishtranslation;notallFEFTArestrictionsorfilingdeadlines | 2026-11-16 |

```json
{
  "figures": [
    "5",
    "2026",
    "11",
    "16"
  ],
  "id": 98,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 216,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 99

| [Hong Kong Basic Law Articles111–112](https://www.basiclaw.gov.hk/en/basiclaw/chapter5.html) | Read for Articles111–112complete;112freeconvertibility/capitalmovement/controlpolicy. Constitutionalcapitalframework,notbank/provider/taxacceptance | 2026-11-16 |

```json
{
  "figures": [
    "11",
    "112",
    "11",
    "2026",
    "11",
    "16"
  ],
  "id": 99,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 217,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 100

| [HKMA Linked Exchange Rate System](https://www.hkma.gov.hk/eng/key-functions/money/linked-exchange-rate-system/) | Read for Mainopeningdescription andneighborLERScontext. Actual currencyboardband description;notguaranteedcustomerFXrate | 2026-11-16 |

```json
{
  "figures": [
    "2026",
    "11",
    "16"
  ],
  "id": 100,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 218,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 101

| [FinCEN foreign bank and financial account reporting](https://www.fincen.gov/report-foreign-bank-and-financial-accounts) | Read for WholeusedWhoMustFilemain:USperson,foreignaccountinterest/signatureauthority andaggregatethreshold;agent/institutionfilingboundary. Reportingtestonly;offence-specificsanctionsnotread | 2026-11-16 |

```json
{
  "figures": [
    "2026",
    "11",
    "16"
  ],
  "id": 101,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 219,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 102

| [IRS Form8938 continuous-use instructions,revision11/2021](https://www.irs.gov/instructions/i8938) | Read for Continuous-useintro;Purpose/WhenHow/WhoMustFile/SpecifiedIndividual;completeindividualUS/abroadthresholds andpresencebranches. Currentservedcontinuous-useinstructions checked16Nov2026; notretitledas2026revision;nooffence-specificpenaltyclearance | 2026-11-16 |

```json
{
  "figures": [
    "938",
    "1",
    "2021",
    "026",
    "2026",
    "11",
    "16"
  ],
  "id": 102,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 220,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 103

| [FinCEN CTR FAQ17,aggregation](https://www.fincen.gov/resources/frequently-asked-questions-regarding-fincen-currency-transaction-report-ctr) | Read for FullFAQ17andneighbor16/18:knownsameperson,onebusinessday,cashin/outnonnetting. ActualoperativeFAQread;notallCTRexemptionsorstructuringoffencelaw | 2026-11-16 |

```json
{
  "figures": [
    "7,",
    "6",
    "18",
    "2026",
    "11",
    "16"
  ],
  "id": 103,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 221,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 104

| [UAEgovernment taxation overview](https://u.ae/en/information-and-services/finance-and-investment/taxation) | Read for Wholesubstantivetaxationintro,noindividualincometax,5%VATandbusinesscorporatetaxdistinction. NoFX/repatriationorall-natural-person-businessCTclearance | 2026-11-16 |

```json
{
  "figures": [
    "5%",
    "2026",
    "11",
    "16"
  ],
  "id": 104,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 222,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 105

| [TFEU Article63](https://publications.europa.eu/resource/cellar/9912914b-f9a7-4f78-b34e-d3e6a2d71f67.0005.01/DOC_1) | Read for WholeArticle63(1)/(2). ActuallyreadoperativeXHTML,notRDFmetadata | 2026-11-16 |

```json
{
  "figures": [
    "3",
    "3",
    "1",
    "2",
    "2026",
    "11",
    "16"
  ],
  "id": 105,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 223,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 106

| [TFEU Article65](https://publications.europa.eu/resource/cellar/f07ba7d3-e51a-4b86-915f-771a9e18ece7.0005.01/DOC_1) | Read for WholeArticle65(1)–(4),includinglimitsandnon-discrimination. ActuallyreadoperativeXHTML;noallotherchapterexceptionclearance | 2026-11-16 |

```json
{
  "figures": [
    "5",
    "5",
    "1",
    "4",
    "2026",
    "11",
    "16"
  ],
  "id": 106,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 224,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 107

| [RegulationEU2018/1672cashcontrols](https://publications.europa.eu/resource/cellar/71d1af91-e611-11e8-b690-01aa75ed71a1.0006.03/DOC_1) | Read for Articles1–3completeincldefinitions/control/declarationconditions;recital9nationalintraUnionboundary. ExternalUnionaccompanied-cashrule,notallnational/unaccompanieddetails | 2026-11-16 |

```json
{
  "figures": [
    "018",
    "2026",
    "11",
    "16"
  ],
  "id": 107,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 225,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 108

| [RegulationEU2021/1230cross-borderpayments](https://publications.europa.eu/resource/cellar/2b7c281b-f0d1-11eb-a71c-01aa75ed71a1.0006.03/DOC_1) | Read for Article3(1)–(4)infullandneighborrelevantdefinitions. Equalproviderchargesforcorrespondingpayments,notalltransfer/FXfree | 2026-11-16 |

```json
{
  "figures": [
    "021",
    "1",
    "4",
    "2026",
    "11",
    "16"
  ],
  "id": 108,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 226,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 109

| [RegulationEU2024/886, current cross-border charge amendments](https://publications.europa.eu/resource/cellar/d395dbf7-e597-11ee-8b2b-01aa75ed71a1.0006.03/DOC_1) | Read for Article2infull:new2021/1230Article3(5)and6(2);Article1inserted260/2012Article5b(1)–(3)infullandArticle16(9)transition;Article6entryinforce. ActualoperativeXHTMLread,notEUR-LexchallengeorRDF;onlyusedchargeandtransitionclauses,notwholeinstrumentclearance | 2026-11-16 |

```json
{
  "figures": [
    "024",
    "886",
    "021",
    "5",
    "2",
    "60",
    "1",
    "3",
    "6",
    "9",
    "2026",
    "11",
    "16"
  ],
  "id": 109,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 227,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 110

| [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1) | Read for AnnexI,SectionVIIIReportableAccount/ReportableJurisdiction/person/controlling-persondefinitions. Sameprimarybodyexacthash;completedfullindependentreviewFATCA282d0195appliesonceforunchangedframeworkdefinitionsonly;noactualnationalcountrylistclearance | 2026-11-16 |

```json
{
  "figures": [
    "2011",
    "16",
    "1",
    "2026",
    "2026",
    "11",
    "16"
  ],
  "id": 110,
  "kind": "heading/internal workflow/human attribution/hypothetical supplied case input/arithmetic or source boundary",
  "line": 228,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 111

### Not yet confirmed

```json
{
  "figures": [],
  "id": 111,
  "kind": "individually non-usable original proposition",
  "line": 230,
  "operative_bindings": [],
  "section": "Not yet confirmed",
  "source_keys": []
}
```

### 112

The following original propositions remain individually non-usable for a bank instruction, tax filing or entity recommendation. They are preserved as research leads, not silently dropped or presented as applicable alternatives.

```json
{
  "figures": [],
  "id": 112,
  "kind": "individually non-usable original proposition",
  "line": 232,
  "operative_bindings": [],
  "section": "Not yet confirmed",
  "source_keys": []
}
```

### 113

| Original proposition / topic | Precise unresolved condition or correction boundary |

```json
{
  "figures": [],
  "id": 113,
  "kind": "individually non-usable original proposition",
  "line": 234,
  "operative_bindings": [],
  "section": "Not yet confirmed",
  "source_keys": []
}
```

### 114

| Mainland recommended HK Ltd → HK bank → Stripe HK | No verified provider availability, acceptance, licensing, ownership/funding or tax suitability; no general founder recommendation |

```json
{
  "figures": [],
  "id": 114,
  "kind": "individually non-usable original proposition",
  "line": 236,
  "operative_bindings": [],
  "section": "Not yet confirmed",
  "source_keys": []
}
```

### 115

| Mainland “keep offshore; remit living expenses only” | Actual residence, ownership, income classification, ODI and repatriation/return duties not cleared; offshore retention is not an exemption |

```json
{
  "figures": [],
  "id": 115,
  "kind": "individually non-usable original proposition",
  "line": 237,
  "operative_bindings": [],
  "section": "Not yet confirmed",
  "source_keys": []
}
```

### 116

| Mainland HK salary / service-fee route | Actual HK employment-tax territorial/benefit rules, mainland service registration/VAT/invoice and payment classification not independently cleared here |

```json
{
  "figures": [],
  "id": 116,
  "kind": "individually non-usable original proposition",
  "line": 238,
  "operative_bindings": [],
  "section": "Not yet confirmed",
  "source_keys": []
}
```

### 117

| Mainland all capital transactions SAFE-approved / ODI above USD 5,000,000 needs NDRC+MOFCOM+SAFE | Foundational registration/prior-filing distinction corrected above; current actor/project-specific approval/filing and dollar thresholds not established |

```json
{
  "figures": [
    "5,000,000"
  ],
  "id": 117,
  "kind": "individually non-usable original proposition",
  "line": 239,
  "operative_bindings": [],
  "section": "Not yet confirmed",
  "source_keys": []
}
```

### 118

| Mainland profit repatriation from an overseas subsidiary | Current tax/payment classification, ownership and supporting-document route not cleared for a transaction |

```json
{
  "figures": [],
  "id": 118,
  "kind": "individually non-usable original proposition",
  "line": 240,
  "operative_bindings": [],
  "section": "Not yet confirmed",
  "source_keys": []
}
```

### 119

| Mainland universal inbound review above USD 5,000 or USD 50,000 | No actual law or bank policy proving those uniform human-review triggers; repeat/rapid transfers and mismatched purpose require the actual bank's facts and request |

```json
{
  "figures": [
    "5,000",
    "50,000"
  ],
  "id": 119,
  "kind": "individually non-usable original proposition",
  "line": 241,
  "operative_bindings": [],
  "section": "Not yet confirmed",
  "source_keys": []
}
```

### 120

| Mainland mandatory salary 职工报酬 / dividend 利润汇回 / service 服务贸易收入 / family 经常转移 codes | Exact current reporting code, responsible declarant and required documents not verified; evidence prompts above are not mandatory codes |

```json
{
  "figures": [],
  "id": 120,
  "kind": "individually non-usable original proposition",
  "line": 242,
  "operative_bindings": [],
  "section": "Not yet confirmed",
  "source_keys": []
}
```

### 121

| China/HK/Singapore/EU CRS country and exchange assertions | Exact year's reportable-jurisdiction list, activated relationship, FI/account/holder and exceptions required; no automatic-all-accounts claim |

```json
{
  "figures": [],
  "id": 121,
  "kind": "individually non-usable original proposition",
  "line": 243,
  "operative_bindings": [],
  "section": "Not yet confirmed",
  "source_keys": []
}
```

### 122

| US CRS exception as a privacy strategy | Actual cross-border information duties and applicable FATCA/other exchange channels required; no secrecy or tax exemption conclusion |

```json
{
  "figures": [],
  "id": 122,
  "kind": "individually non-usable original proposition",
  "line": 244,
  "operative_bindings": [],
  "section": "Not yet confirmed",
  "source_keys": []
}
```

### 123

| Alleged 2025 CRS expansion to wealth below USD 1,000,000 | No operative announcement read establishing that wealth-band policy or a universal reporting threshold |

```json
{
  "figures": [
    "2025",
    "1,000,000"
  ],
  "id": 123,
  "kind": "individually non-usable original proposition",
  "line": 245,
  "operative_bindings": [],
  "section": "Not yet confirmed",
  "source_keys": []
}
```

### 124

| China account freezes / two-year purchase ban | Current notice, offence and authority required; watch-list monitoring/document rule is corrected above, not a blanket freeze/ban |

```json
{
  "figures": [],
  "id": 124,
  "kind": "individually non-usable original proposition",
  "line": 246,
  "operative_bindings": [],
  "section": "Not yet confirmed",
  "source_keys": []
}
```

### 125

| China underground exchange: five-ten years above RMB 1,000,000 | Exact offence, statutory elements, current threshold and sentencing range not established by the FX administrative clauses |

```json
{
  "figures": [
    "1,000,000"
  ],
  "id": 125,
  "kind": "individually non-usable original proposition",
  "line": 247,
  "operative_bindings": [],
  "section": "Not yet confirmed",
  "source_keys": []
}
```

### 126

| China income-tax default: 50%-500% and 0.05% per day | Offence-specific current assessment, surcharge/fine law, base and exceptions not read; not cleared by an FX penalty source |

```json
{
  "figures": [
    "50%",
    "500%",
    "0.05%"
  ],
  "id": 126,
  "kind": "individually non-usable original proposition",
  "line": 248,
  "operative_bindings": [],
  "section": "Not yet confirmed",
  "source_keys": []
}
```

### 127

| China voluntary correction: fine below 50% | No verified universal concession or automatic outcome; actual offence/procedure required |

```json
{
  "figures": [
    "50%"
  ],
  "id": 127,
  "kind": "individually non-usable original proposition",
  "line": 249,
  "operative_bindings": [],
  "section": "Not yet confirmed",
  "source_keys": []
}
```

### 128

| China criminal liability above RMB 100,000 and 10% of tax | Current Criminal Law Article 201, interpretation, cumulative elements and exceptions not read; old shorthand unusable |

```json
{
  "figures": [
    "100,000",
    "10%",
    "201"
  ],
  "id": 128,
  "kind": "individually non-usable original proposition",
  "line": 250,
  "operative_bindings": [],
  "section": "Not yet confirmed",
  "source_keys": []
}
```

### 129

| China mobile app “其他收入 → 境外所得（附表三）” | Current actual filing workflow, form and access not verified; official announcement's filing/evidence rules do not prove this click path |

```json
{
  "figures": [],
  "id": 129,
  "kind": "individually non-usable original proposition",
  "line": 251,
  "operative_bindings": [],
  "section": "Not yet confirmed",
  "source_keys": []
}
```

### 130

| China risk/interview notice response within 30 days; low/medium/high labels | Actual issued notice and applicable procedure control; no uniform deadline or urgency taxonomy substantiated |

```json
{
  "figures": [
    "30"
  ],
  "id": 130,
  "kind": "individually non-usable original proposition",
  "line": 252,
  "operative_bindings": [],
  "section": "Not yet confirmed",
  "source_keys": []
}
```

### 131

| India Wyoming LLC + Mercury / Singapore Pte. Ltd. and “LRS normally enough” | Current investment route, provider acceptance, control, tax and reporting not cleared by an individual dollar amount |

```json
{
  "figures": [],
  "id": 131,
  "kind": "individually non-usable original proposition",
  "line": 253,
  "operative_bindings": [],
  "section": "Not yet confirmed",
  "source_keys": []
}
```

### 132

| India all current trade free / automatic ODI for most / round-trip structures | Exact 2022 framework and actor/transaction exceptions not read for a transaction; no automatic-route conclusion |

```json
{
  "figures": [
    "2022"
  ],
  "id": 132,
  "kind": "individually non-usable original proposition",
  "line": 254,
  "operative_bindings": [],
  "section": "Not yet confirmed",
  "source_keys": []
}
```

### 133

| India keeping foreign revenue offshore / domestic subsidiary | Actual export-realisation/repatriation, beneficial ownership, residence, business presence and corporate obligations needed |

```json
{
  "figures": [],
  "id": 133,
  "kind": "individually non-usable original proposition",
  "line": 255,
  "operative_bindings": [],
  "section": "Not yet confirmed",
  "source_keys": []
}
```

### 134

| India all residents taxed worldwide / salary, fees, dividends and gains | Resident-and-ordinarily-resident/RNOR/nonresident scope, source/deeming, category and actual year need the operative law; original universal statement not usable |

```json
{
  "figures": [],
  "id": 134,
  "kind": "individually non-usable original proposition",
  "line": 256,
  "operative_bindings": [],
  "section": "Not yet confirmed",
  "source_keys": []
}
```

### 135

| India US/SG/UK/UAE treaties eliminate double tax / Form 67 always required | Actual treaty, credit method, current successor provisions, form and conditions not independently read here; no guaranteed relief |

```json
{
  "figures": [
    "67"
  ],
  "id": 135,
  "kind": "individually non-usable original proposition",
  "line": 257,
  "operative_bindings": [],
  "section": "Not yet confirmed",
  "source_keys": []
}
```

### 136

| India automatic TCS refund and rate exceptions | Ordinary current Table 7 rates/exclusions corrected; actual return-credit/refund, higher-rate identifiers/default, lower-certificate and other applicable conditions needed |

```json
{
  "figures": [
    "7"
  ],
  "id": 136,
  "kind": "individually non-usable original proposition",
  "line": 258,
  "operative_bindings": [],
  "section": "Not yet confirmed",
  "source_keys": []
}
```

### 137

| Brazil USD 10,000 daily no-document limit / every transaction a bank exchange contract | False amount/context corrected; current product/document and permitted non-bank/correspondent channels require actual route, not a universal bank-only claim |

```json
{
  "figures": [
    "10,000"
  ],
  "id": 137,
  "kind": "individually non-usable original proposition",
  "line": 259,
  "operative_bindings": [],
  "section": "Not yet confirmed",
  "source_keys": []
}
```

### 138

| Brazil IOF 0.38%-6.38% | Current operation-specific legislation, amendments, rate and effective date not cleared; VET includes IOF but does not establish that old range |

```json
{
  "figures": [
    "0.38%",
    "6.38%"
  ],
  "id": 138,
  "kind": "individually non-usable original proposition",
  "line": 260,
  "operative_bindings": [],
  "section": "Not yet confirmed",
  "source_keys": []
}
```

### 139

| Brazil US LLC + Mercury avoids domestic complexity | No verified avoidance of residence, business, FX, IOF, reporting or provider conditions |

```json
{
  "figures": [],
  "id": 139,
  "kind": "individually non-usable original proposition",
  "line": 261,
  "operative_bindings": [],
  "section": "Not yet confirmed",
  "source_keys": []
}
```

### 140

| Taiwan annual TWD 5,000,000 / approximately USD 150,000 threshold | Replaced by actual TWD 500,000 per-transaction declaration test; no unsupported spot conversion or annual TWD alternative |

```json
{
  "figures": [
    "5,000,000",
    "150,000",
    "500,000"
  ],
  "id": 140,
  "kind": "individually non-usable original proposition",
  "line": 262,
  "operative_bindings": [],
  "section": "Not yet confirmed",
  "source_keys": []
}
```

### 141

| Taiwan MOEA investment report above TWD 5,000,000 | Competent-authority investment law and current amount/process not established by the CBC declaration rules |

```json
{
  "figures": [
    "5,000,000"
  ],
  "id": 141,
  "kind": "individually non-usable original proposition",
  "line": 263,
  "operative_bindings": [],
  "section": "Not yet confirmed",
  "source_keys": []
}
```

### 142

| Taiwan OBU interest tax exemption / offshore income separation | Actual account/person/income/exemption and reporting conditions not read; account label alone is insufficient |

```json
{
  "figures": [],
  "id": 142,
  "kind": "individually non-usable original proposition",
  "line": 264,
  "operative_bindings": [],
  "section": "Not yet confirmed",
  "source_keys": []
}
```

### 143

| Taiwan Hong Kong cultural proximity / cheaper than Singapore | No verified cost comparison or jurisdiction suitability; formation/banking fees and facts required |

```json
{
  "figures": [],
  "id": 143,
  "kind": "individually non-usable original proposition",
  "line": 265,
  "operative_bindings": [],
  "section": "Not yet confirmed",
  "source_keys": []
}
```

### 144

| Taiwan Singapore avoids CFC; 17% versus 14% comparison | No verified cost comparison or automatic nominal-rate escape; CFC jurisdiction, control, income and substance tests need actual law |

```json
{
  "figures": [
    "17%",
    "14%"
  ],
  "id": 144,
  "kind": "individually non-usable original proposition",
  "line": 266,
  "operative_bindings": [],
  "section": "Not yet confirmed",
  "source_keys": []
}
```

### 145

| Taiwan CFC over 50%, low-tax below 14%, income below NT$7,000,000 or real substance | Current combined control, low-tax jurisdiction test, entity/individual rules, exemption bases and substance conditions not independently read here |

```json
{
  "figures": [
    "50%",
    "14%",
    "7,000,000"
  ],
  "id": 145,
  "kind": "individually non-usable original proposition",
  "line": 267,
  "operative_bindings": [],
  "section": "Not yet confirmed",
  "source_keys": []
}
```

### 146

| Korea USD 50,000 transaction/no-doc and annual reporting amounts | Current 2026 regulation and particular purpose/person not established; older BOK procedural-page examples not treated as updated numerical law |

```json
{
  "figures": [
    "50,000",
    "2026"
  ],
  "id": 146,
  "kind": "individually non-usable original proposition",
  "line": 268,
  "operative_bindings": [],
  "section": "Not yet confirmed",
  "source_keys": []
}
```

### 147

| Korea US LLC or Singapore Pte. Ltd. recommendation | Investment, funding, provider and home-country tax/FX suitability not verified |

```json
{
  "figures": [],
  "id": 147,
  "kind": "individually non-usable original proposition",
  "line": 269,
  "operative_bindings": [],
  "section": "Not yet confirmed",
  "source_keys": []
}
```

### 148

| Korea investment above USD 1,000,000 / ODI above USD 10,000,000 | Current investment type, designated-bank/BOK authority, reporting/approval and threshold not independently cleared |

```json
{
  "figures": [
    "1,000,000",
    "10,000,000"
  ],
  "id": 148,
  "kind": "individually non-usable original proposition",
  "line": 270,
  "operative_bindings": [],
  "section": "Not yet confirmed",
  "source_keys": []
}
```

### 149

| Japan no individual limits / any structure works / sensitive-sector restrictions only / all large reports post-facto / approximately USD 200,000 conversion | Actual restriction, sanctions, investment and filing-timing scope not read; BOJ payment-report threshold is not that clearance |

```json
{
  "figures": [
    "200,000"
  ],
  "id": 149,
  "kind": "individually non-usable original proposition",
  "line": 271,
  "operative_bindings": [],
  "section": "Not yet confirmed",
  "source_keys": []
}
```

### 150

| Hong Kong unlimited holding/conversion and “number-one founder choice” | Article 112 capital framework supported; no universal bank/product acceptance, best-choice ranking, price or tax-suitability conclusion |

```json
{
  "figures": [
    "112"
  ],
  "id": 150,
  "kind": "individually non-usable original proposition",
  "line": 272,
  "operative_bindings": [],
  "section": "Not yet confirmed",
  "source_keys": []
}
```

### 151

| Singapore zero controls / unrestricted MAS transactions / no reporting for most transfers | Actual current primary exchange/reporting and transaction rules not read sufficiently; no blanket clearance |

```json
{
  "figures": [],
  "id": 151,
  "kind": "individually non-usable original proposition",
  "line": 273,
  "operative_bindings": [],
  "section": "Not yet confirmed",
  "source_keys": []
}
```

### 152

| US no limits moving money in/out / structuring offence | Actual applicable restrictions, sanctions, transaction route and offence provisions not comprehensively read; reporting amounts do not establish unrestricted transfer permission |

```json
{
  "figures": [],
  "id": 152,
  "kind": "individually non-usable original proposition",
  "line": 274,
  "operative_bindings": [],
  "section": "Not yet confirmed",
  "source_keys": []
}
```

### 153

| US FBAR USD 10,000 per account per year penalty | Current offence/year-specific civil/criminal rules, inflation adjustments and reporting-unit case law not read; old per-account tariff unusable |

```json
{
  "figures": [
    "10,000"
  ],
  "id": 153,
  "kind": "individually non-usable original proposition",
  "line": 275,
  "operative_bindings": [],
  "section": "Not yet confirmed",
  "source_keys": []
}
```

### 154

| US Form 8938 USD 10,000 plus USD 10,000 each 30 days | Exact offence, notice/cure, maximum, exceptions and current procedure not read; thresholds above do not clear penalties |

```json
{
  "figures": [
    "8938",
    "10,000",
    "10,000",
    "30"
  ],
  "id": 154,
  "kind": "individually non-usable original proposition",
  "line": 276,
  "operative_bindings": [],
  "section": "Not yet confirmed",
  "source_keys": []
}
```

### 155

| UAE zero controls / unlimited capital or profit repatriation / every currency | Actual banking, investment, entity and transaction restrictions not read; government's tax page cannot prove those claims |

```json
{
  "figures": [],
  "id": 155,
  "kind": "individually non-usable original proposition",
  "line": 277,
  "operative_bindings": [],
  "section": "Not yet confirmed",
  "source_keys": []
}
```

### 156

| UAE 5% personal income tax from January 2026 | Corrected against official government statement: no individual income tax; 5% is VAT, with separate business corporate-tax questions |

```json
{
  "figures": [
    "5%",
    "2026",
    "5%"
  ],
  "id": 156,
  "kind": "individually non-usable original proposition",
  "line": 278,
  "operative_bindings": [],
  "section": "Not yet confirmed",
  "source_keys": []
}
```

### 157

| EU all electronic transfers unlimited / every cross-border payment identical / French foreign-account reporting | Treaty chapter and equal-charge rule bounded above; actual sanctions, route, conversion and national tax/account-reporting rules needed |

```json
{
  "figures": [],
  "id": 157,
  "kind": "individually non-usable original proposition",
  "line": 279,
  "operative_bindings": [],
  "section": "Not yet confirmed",
  "source_keys": []
}
```

### 158

The original broad 2024-2026 freshness statement is replaced by the dated scope above. No current bank quote, live form submission, provider approval or human accountant approval is implied.

```json
{
  "figures": [
    "2024",
    "2026"
  ],
  "id": 158,
  "kind": "individually non-usable original proposition",
  "line": 281,
  "operative_bindings": [],
  "section": "Not yet confirmed",
  "source_keys": []
}
```

## Short exact native registry

```json
{
  "BR-029": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "R$10 mil"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://aprendervalor.bcb.gov.br/content/estabilidadefinanceira/politica_cambial/Cartilha_cambio_2026.pdf",
    "operative_locator": "Pages7/9",
    "source_key": "BR"
  },
  "BR-030": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "Valor Efetivo Total"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://aprendervalor.bcb.gov.br/content/estabilidadefinanceira/politica_cambial/Cartilha_cambio_2026.pdf",
    "operative_locator": "Page14",
    "source_key": "BR"
  },
  "BR-031": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "Imposto sobre Operações Financeiras"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://aprendervalor.bcb.gov.br/content/estabilidadefinanceira/politica_cambial/Cartilha_cambio_2026.pdf",
    "operative_locator": "Page14",
    "source_key": "BR"
  },
  "BR-032": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "identificação"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://aprendervalor.bcb.gov.br/content/estabilidadefinanceira/politica_cambial/Cartilha_cambio_2026.pdf",
    "operative_locator": "Pages6/9",
    "source_key": "BR"
  },
  "CNFX-004": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "真实、合法的交易"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.safe.gov.cn/neimenggu/file/file/20170728/b663448ec2f74289b194838d47b8df95.pdf",
    "operative_locator": "Article12",
    "source_key": "CNFX"
  },
  "CNFX-005": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "办理登记"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.safe.gov.cn/neimenggu/file/file/20170728/b663448ec2f74289b194838d47b8df95.pdf",
    "operative_locator": "Article17",
    "source_key": "CNFX"
  },
  "CNFX-006": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "30%以下"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.safe.gov.cn/neimenggu/file/file/20170728/b663448ec2f74289b194838d47b8df95.pdf",
    "operative_locator": "Articles39/40",
    "source_key": "CNFX"
  },
  "CNFX-007": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "30%以上等值以下"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.safe.gov.cn/neimenggu/file/file/20170728/b663448ec2f74289b194838d47b8df95.pdf",
    "operative_locator": "Articles39/40",
    "source_key": "CNFX"
  },
  "CNIT-011": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "综合所得"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://12366.chinatax.gov.cn/bzds/082/082-5-4.html",
    "operative_locator": "II/III",
    "source_key": "CNIT"
  },
  "CNIT-012": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "以后五个纳税年度"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://12366.chinatax.gov.cn/bzds/082/082-5-4.html",
    "operative_locator": "VI",
    "source_key": "CNIT"
  },
  "CNIT-013": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "次年3月1日至6月30日"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://12366.chinatax.gov.cn/bzds/082/082-5-4.html",
    "operative_locator": "VII",
    "source_key": "CNIT"
  },
  "CNIT-014": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "应纳税额"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://12366.chinatax.gov.cn/bzds/082/082-5-4.html",
    "operative_locator": "III",
    "source_key": "CNIT"
  },
  "CNQA-001": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "每人每年等值5万美元"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.safe.gov.cn/shanghai/2019/1213/1198.html",
    "operative_locator": "Main numbered1",
    "source_key": "CNQA"
  },
  "CNQA-002": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "超过个人年度额度"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.safe.gov.cn/shanghai/2019/1213/1198.html",
    "operative_locator": "Main numbered2/3",
    "source_key": "CNQA"
  },
  "CNQA-003": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "不得出借本人或借用他人额度"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.safe.gov.cn/shanghai/2019/1213/1198.html",
    "operative_locator": "Final warning",
    "source_key": "CNQA"
  },
  "CNWATCH-008": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "当年及之后连续 2 年"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.safe.gov.cn/beijing/file/file/20250901/f03a39d891024861a8ce859dab124f06.pdf",
    "operative_locator": "Article62(3)",
    "source_key": "CNWATCH"
  },
  "CNWATCH-009": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "有交易额的相关材料"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.safe.gov.cn/beijing/file/file/20250901/f03a39d891024861a8ce859dab124f06.pdf",
    "operative_locator": "Article62(3)/Annex6",
    "source_key": "CNWATCH"
  },
  "CNWATCH-010": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "若上述个人再次出现"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.safe.gov.cn/beijing/file/file/20250901/f03a39d891024861a8ce859dab124f06.pdf",
    "operative_locator": "Article62(1)",
    "source_key": "CNWATCH"
  },
  "CRSREUSE-073": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1",
    "operative_locator": "AnnexISectionVIII(D)(1)",
    "source_key": "CRSREUSE"
  },
  "CTR-069": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "single business day"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.fincen.gov/resources/frequently-asked-questions-regarding-fincen-currency-transaction-report-ctr",
    "operative_locator": "FAQ17",
    "source_key": "CTR"
  },
  "CTR-070": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "$10,000"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.fincen.gov/resources/frequently-asked-questions-regarding-fincen-currency-transaction-report-ctr",
    "operative_locator": "FAQ17",
    "source_key": "CTR"
  },
  "CTR-071": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "should not off-set"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.fincen.gov/resources/frequently-asked-questions-regarding-fincen-currency-transaction-report-ctr",
    "operative_locator": "FAQ17",
    "source_key": "CTR"
  },
  "EU2024-081": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "Paragraph 1 of this Article shall not apply"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://publications.europa.eu/resource/cellar/d395dbf7-e597-11ee-8b2b-01aa75ed71a1.0006.03/DOC_1",
    "operative_locator": "Article2(1),newArticle3(5)",
    "source_key": "EU2024"
  },
  "EU2024-082": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "9 January 2027"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://publications.europa.eu/resource/cellar/d395dbf7-e597-11ee-8b2b-01aa75ed71a1.0006.03/DOC_1",
    "operative_locator": "InsertedArticle5b(3),non-europroviderdate",
    "source_key": "EU2024"
  },
  "EU2024-083": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "additional charges"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://publications.europa.eu/resource/cellar/d395dbf7-e597-11ee-8b2b-01aa75ed71a1.0006.03/DOC_1",
    "operative_locator": "Article2(2),newArticle6(2)",
    "source_key": "EU2024"
  },
  "EU63-074": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "between Member States and third countries"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://publications.europa.eu/resource/cellar/9912914b-f9a7-4f78-b34e-d3e6a2d71f67.0005.01/DOC_1",
    "operative_locator": "Article63(1)/(2)",
    "source_key": "EU63"
  },
  "EU65-075": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "taxation"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://publications.europa.eu/resource/cellar/f07ba7d3-e51a-4b86-915f-771a9e18ece7.0005.01/DOC_1",
    "operative_locator": "Article65(1)(b)",
    "source_key": "EU65"
  },
  "EU65-076": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "arbitrary discrimination or a disguised restriction"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://publications.europa.eu/resource/cellar/f07ba7d3-e51a-4b86-915f-771a9e18ece7.0005.01/DOC_1",
    "operative_locator": "Article65(3)",
    "source_key": "EU65"
  },
  "EUCASH-077": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "EUR 10 000 or more"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://publications.europa.eu/resource/cellar/71d1af91-e611-11e8-b690-01aa75ed71a1.0006.03/DOC_1",
    "operative_locator": "Article3(1)",
    "source_key": "EUCASH"
  },
  "EUCASH-078": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "entering or leaving the Union"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://publications.europa.eu/resource/cellar/71d1af91-e611-11e8-b690-01aa75ed71a1.0006.03/DOC_1",
    "operative_locator": "Article3(1)",
    "source_key": "EUCASH"
  },
  "EUCHARGES-079": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "currency conversion charges"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://publications.europa.eu/resource/cellar/2b7c281b-f0d1-11eb-a71c-01aa75ed71a1.0006.03/DOC_1",
    "operative_locator": "Article3(4)",
    "source_key": "EUCHARGES"
  },
  "EUCHARGES-080": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "corresponding national payments"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://publications.europa.eu/resource/cellar/2b7c281b-f0d1-11eb-a71c-01aa75ed71a1.0006.03/DOC_1",
    "operative_locator": "Article3(1)",
    "source_key": "EUCHARGES"
  },
  "FBAR-057": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "aggregate value"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.fincen.gov/report-foreign-bank-and-financial-accounts",
    "operative_locator": "WhoMustFile",
    "source_key": "FBAR"
  },
  "FBAR-058": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "$10,000"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.fincen.gov/report-foreign-bank-and-financial-accounts",
    "operative_locator": "WhoMustFile",
    "source_key": "FBAR"
  },
  "FBAR-059": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "financial interest"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.fincen.gov/report-foreign-bank-and-financial-accounts",
    "operative_locator": "WhoMustFile",
    "source_key": "FBAR"
  },
  "HK-053": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "freely convertible"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.basiclaw.gov.hk/en/basiclaw/chapter5.html",
    "operative_locator": "Article112",
    "source_key": "HK"
  },
  "HK-054": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "free flow of capital"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.basiclaw.gov.hk/en/basiclaw/chapter5.html",
    "operative_locator": "Article112",
    "source_key": "HK"
  },
  "HKLINK-055": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "HK$7.75-7.85"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.hkma.gov.hk/eng/key-functions/money/linked-exchange-rate-system/",
    "operative_locator": "Openingparagraph",
    "source_key": "HKLINK"
  },
  "HKLINK-056": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "Currency Board"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.hkma.gov.hk/eng/key-functions/money/linked-exchange-rate-system/",
    "operative_locator": "Mainframework",
    "source_key": "HKLINK"
  },
  "INTCS-023": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "exceeding ten"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.incometaxindia.gov.in/documents/d/guest/income_tax_act_2025_as_amended_by_fa_act_2026-pdf",
    "operative_locator": "394(1)Table7",
    "source_key": "INTCS"
  },
  "INTCS-024": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "2%"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.incometaxindia.gov.in/documents/d/guest/income_tax_act_2025_as_amended_by_fa_act_2026-pdf",
    "operative_locator": "394(1)Table7(a)",
    "source_key": "INTCS"
  },
  "INTCS-025": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "20%"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.incometaxindia.gov.in/documents/d/guest/income_tax_act_2025_as_amended_by_fa_act_2026-pdf",
    "operative_locator": "394(1)Table7(b)",
    "source_key": "INTCS"
  },
  "INTCS-026": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "whichever is earlier"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.incometaxindia.gov.in/documents/d/guest/income_tax_act_2025_as_amended_by_fa_act_2026-pdf",
    "operative_locator": "394(1)(c)",
    "source_key": "INTCS"
  },
  "INTCS-027": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "1-4-2026"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.incometaxindia.gov.in/documents/d/guest/income_tax_act_2025_as_amended_by_fa_act_2026-pdf",
    "operative_locator": "FinanceAct2026footnote88b",
    "source_key": "INTCS"
  },
  "INTCS-028": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "tax has been collected"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.incometaxindia.gov.in/documents/d/guest/income_tax_act_2025_as_amended_by_fa_act_2026-pdf",
    "operative_locator": "394(4)(a),sameamountselleralreadycollected",
    "source_key": "INTCS"
  },
  "IRS8938-060": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "$50,000"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.irs.gov/instructions/i8938",
    "operative_locator": "USsingle/separate",
    "source_key": "IRS8938"
  },
  "IRS8938-061": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "$75,000"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.irs.gov/instructions/i8938",
    "operative_locator": "USsingle/separateanytime",
    "source_key": "IRS8938"
  },
  "IRS8938-062": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "$100,000"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.irs.gov/instructions/i8938",
    "operative_locator": "USjointyearend",
    "source_key": "IRS8938"
  },
  "IRS8938-063": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "$150,000"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.irs.gov/instructions/i8938",
    "operative_locator": "USjointanytime",
    "source_key": "IRS8938"
  },
  "IRS8938-064": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "$200,000"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.irs.gov/instructions/i8938",
    "operative_locator": "Abroadsingle/separateyearend",
    "source_key": "IRS8938"
  },
  "IRS8938-065": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "$300,000"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.irs.gov/instructions/i8938",
    "operative_locator": "Abroadsingle/separateanytime",
    "source_key": "IRS8938"
  },
  "IRS8938-066": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "$400,000"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.irs.gov/instructions/i8938",
    "operative_locator": "Abroadjointyearend",
    "source_key": "IRS8938"
  },
  "IRS8938-067": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "$600,000"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.irs.gov/instructions/i8938",
    "operative_locator": "Abroadjointanytime",
    "source_key": "IRS8938"
  },
  "IRS8938-068": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "330 full days"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.irs.gov/instructions/i8938",
    "operative_locator": "Presenceabroad",
    "source_key": "IRS8938"
  },
  "JP-050": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "30 million yen"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.boj.or.jp/en/statistics/outline/exp/exbpsm6.htm",
    "operative_locator": "Reports on paymentetc",
    "source_key": "JP"
  },
  "JP-051": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "Japanese customs"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.boj.or.jp/en/statistics/outline/exp/exbpsm6.htm",
    "operative_locator": "Goods exception",
    "source_key": "JP"
  },
  "JP-052": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "Article 55-3"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.boj.or.jp/en/statistics/outline/exp/exbpsm6.htm",
    "operative_locator": "Capital-reportheading",
    "source_key": "JP"
  },
  "KR-047": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "transaction type"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.bok.or.kr/eng/main/contents.do?menuNo=400191",
    "operative_locator": "Openingframework",
    "source_key": "KR"
  },
  "KR-048": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "prior notification"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.bok.or.kr/eng/main/contents.do?menuNo=400191",
    "operative_locator": "Capitalpaymentparagraph",
    "source_key": "KR"
  },
  "KR-049": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "evidential documents"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.bok.or.kr/eng/main/contents.do?menuNo=400191",
    "operative_locator": "Currentpaymentparagraph",
    "source_key": "KR"
  },
  "LRS-015": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "2,50,000"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=10192",
    "operative_locator": "A1",
    "source_key": "LRS"
  },
  "LRS-016": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "April-March"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=10192",
    "operative_locator": "A1",
    "source_key": "LRS"
  },
  "LRS-017": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "co-owners/co-partners"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=10192",
    "operative_locator": "A4",
    "source_key": "LRS"
  },
  "LRS-018": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "margins or margin calls"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=10192",
    "operative_locator": "A5",
    "source_key": "LRS"
  },
  "LRS-019": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "estimate"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=10192",
    "operative_locator": "A7g/h",
    "source_key": "LRS"
  },
  "LRS-020": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "Permanent Account Number"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=10192",
    "operative_locator": "A16",
    "source_key": "LRS"
  },
  "LRS-021": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "180 days"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=10192",
    "operative_locator": "A17",
    "source_key": "LRS"
  },
  "LRS-022": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "2022"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=10192",
    "operative_locator": "A6/A17",
    "source_key": "LRS"
  },
  "TWFAQ-043": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "新臺幣50萬元以上"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.cbc.gov.tw/tw/cp-1179-101135-49647-1.html",
    "operative_locator": "IIopening",
    "source_key": "TWFAQ"
  },
  "TWFAQ-044": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "1億美元"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.cbc.gov.tw/tw/cp-1179-101135-49647-1.html",
    "operative_locator": "II(b)companies",
    "source_key": "TWFAQ"
  },
  "TWFAQ-045": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "1千萬美元"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.cbc.gov.tw/tw/cp-1179-101135-49647-1.html",
    "operative_locator": "II(b)individual/group",
    "source_key": "TWFAQ"
  },
  "TWFAQ-046": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "10萬美元"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.cbc.gov.tw/tw/cp-1179-101135-49647-1.html",
    "operative_locator": "II(b)nonresident",
    "source_key": "TWFAQ"
  },
  "TWLAW-033": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "新臺幣五十萬元以上"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.cbc.gov.tw/tw/dl-171561-a2f2e7bbd39d4e2c8abc05b2f3e5bc7c.html",
    "operative_locator": "Article2",
    "source_key": "TWLAW"
  },
  "TWLAW-034": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "年滿十八歲"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.cbc.gov.tw/tw/dl-171561-a2f2e7bbd39d4e2c8abc05b2f3e5bc7c.html",
    "operative_locator": "Article3(10)",
    "source_key": "TWLAW"
  },
  "TWLAW-035": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "等值一百萬美元以上"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.cbc.gov.tw/tw/dl-171561-a2f2e7bbd39d4e2c8abc05b2f3e5bc7c.html",
    "operative_locator": "Article5(1)",
    "source_key": "TWLAW"
  },
  "TWLAW-036": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "等值五十萬美元以上"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.cbc.gov.tw/tw/dl-171561-a2f2e7bbd39d4e2c8abc05b2f3e5bc7c.html",
    "operative_locator": "Article5(2)",
    "source_key": "TWLAW"
  },
  "TWLAW-037": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "等值十萬美元"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.cbc.gov.tw/tw/dl-171561-a2f2e7bbd39d4e2c8abc05b2f3e5bc7c.html",
    "operative_locator": "Article4(1)(5)",
    "source_key": "TWLAW"
  },
  "TWORDER-038": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "等值五千萬美元"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.cbc.gov.tw/tw/dl-212210-8b20d63a34cf4b098a130e529e3f0e45.html",
    "operative_locator": "Clause1old",
    "source_key": "TWORDER"
  },
  "TWORDER-039": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "等值一億美元"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.cbc.gov.tw/tw/dl-212210-8b20d63a34cf4b098a130e529e3f0e45.html",
    "operative_locator": "Clause1new",
    "source_key": "TWORDER"
  },
  "TWORDER-040": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "等值五百萬美元"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.cbc.gov.tw/tw/dl-212210-8b20d63a34cf4b098a130e529e3f0e45.html",
    "operative_locator": "Clause2old",
    "source_key": "TWORDER"
  },
  "TWORDER-041": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "等值一千萬美元"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.cbc.gov.tw/tw/dl-212210-8b20d63a34cf4b098a130e529e3f0e45.html",
    "operative_locator": "Clause2new",
    "source_key": "TWORDER"
  },
  "TWORDER-042": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "一百十三年十一月一日"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.cbc.gov.tw/tw/dl-212210-8b20d63a34cf4b098a130e529e3f0e45.html",
    "operative_locator": "Commencement",
    "source_key": "TWORDER"
  },
  "UAETAX-072": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "does not levy income tax on individuals"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://u.ae/en/information-and-services/finance-and-investment/taxation",
    "operative_locator": "Mainintro",
    "source_key": "UAETAX"
  },
  "UAETAX-073": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "5 per cent"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://u.ae/en/information-and-services/finance-and-investment/taxation",
    "operative_locator": "MainintroVAT",
    "source_key": "UAETAX"
  }
}
```

## Original-topic destinations

The complete original-topic destination table is in `../forex-controls/old-topic-map.json`.
