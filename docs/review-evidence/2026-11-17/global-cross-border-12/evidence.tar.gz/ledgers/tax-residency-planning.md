# tax-residency-planning figure and rule ledger

Public projection; canonical private SHA256: `6a18a2c0b32d94d588b810b599fb588d1b24cc7962e9d20673b1c11e46a31c27`. Complete captured/native source passages remain local. The JSON companion preserves every retained evidence field.

## Whole rule groups

### AU-FINANCIAL-YEAR

The financial year is a period of12months beginning on1July; it is not a calendar-year default.

```json
{
  "act_article_or_scope": "ITAA1997 s995-1 financial year definition",
  "actual_read_on": "2026-11-16",
  "id": "AU-FINANCIAL-YEAR",
  "official_url": "https://www.legislation.gov.au/C2004A05138/2026-10-01/2026-10-01/text/original/epub/OEBPS/document_10/document_10.html",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "**Australia.** ITAA 1936 s 6 has separate ordinary-residence, domicile, more-than-half-income-year and specified Commonwealth superannuation routes, with their actual exceptions. A short stay does not defeat an Australian domicile or ordinary residence. The general financial year is 12 months beginning 1 July; approved substituted accounting periods and statutory exceptions must be checked. Resident ordinary and statutory income generally have worldwide scope; foreign-resident source and specifically included income are separate from exemptions and temporary-resident concessions. [Current residence definition](https://www.legislation.gov.au/C1936A00027/2026-10-01/2026-10-01/text/original/epub/OEBPS/document_1/document_1.html); [income-year and scope provisions](https://www.legislation.gov.au/C2004A05138/2026-10-01/2026-10-01/text/original/epub/OEBPS/document_1/document_1.html).",
    "line": 55
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/au-itaa1997-v10.txt",
  "source_sha256": "b8c7c388f0d9e051458a3a3ab2726048fbe508f8fb4c803a099766c7cf5de3bd",
  "source_version_basis": "Compilation268 dated1October2026, authorized current text; not whole12volume read."
}
```

### AU-INCOME-YEAR

An income year generally follows the financial year, subject to the company and adopted accounting-period exceptions and notes.

```json
{
  "act_article_or_scope": "ITAA1997 s4-10(1)–(2), including notes",
  "actual_read_on": "2026-11-16",
  "id": "AU-INCOME-YEAR",
  "official_url": "https://www.legislation.gov.au/C2004A05138/2026-10-01/2026-10-01/text/original/epub/OEBPS/document_1/document_1.html",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "**Australia.** ITAA 1936 s 6 has separate ordinary-residence, domicile, more-than-half-income-year and specified Commonwealth superannuation routes, with their actual exceptions. A short stay does not defeat an Australian domicile or ordinary residence. The general financial year is 12 months beginning 1 July; approved substituted accounting periods and statutory exceptions must be checked. Resident ordinary and statutory income generally have worldwide scope; foreign-resident source and specifically included income are separate from exemptions and temporary-resident concessions. [Current residence definition](https://www.legislation.gov.au/C1936A00027/2026-10-01/2026-10-01/text/original/epub/OEBPS/document_1/document_1.html); [income-year and scope provisions](https://www.legislation.gov.au/C2004A05138/2026-10-01/2026-10-01/text/original/epub/OEBPS/document_1/document_1.html).",
    "line": 55
  },
  "short_exact_native_quotes": [
    "4‑10 How to work out how much income tax you must pay (1) You must pay income tax for each *financial year. (2) Your income"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/au-itaa1997-v1.txt",
  "source_sha256": "bdac4c68764af13bba951364469422db9f76249cbc3e509f0c4a7809e8c7d83d",
  "source_version_basis": "Compilation268 dated1October2026"
}
```

### AU-RESIDENCE

Individual residence has ordinary residence, domicile, more-than-half-year and specified superannuation routes. Company incorporation and business/management or voting-control routes differ.

```json
{
  "act_article_or_scope": "ITAA1936 s6(1) resident definition, individual and company limbs",
  "actual_read_on": "2026-11-16",
  "id": "AU-RESIDENCE",
  "official_url": "https://www.legislation.gov.au/C1936A00027/2026-10-01/2026-10-01/text/original/epub/OEBPS/document_1/document_1.html",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "**Australia.** ITAA 1936 s 6 has separate ordinary-residence, domicile, more-than-half-income-year and specified Commonwealth superannuation routes, with their actual exceptions. A short stay does not defeat an Australian domicile or ordinary residence. The general financial year is 12 months beginning 1 July; approved substituted accounting periods and statutory exceptions must be checked. Resident ordinary and statutory income generally have worldwide scope; foreign-resident source and specifically included income are separate from exemptions and temporary-resident concessions. [Current residence definition](https://www.legislation.gov.au/C1936A00027/2026-10-01/2026-10-01/text/original/epub/OEBPS/document_1/document_1.html); [income-year and scope provisions](https://www.legislation.gov.au/C2004A05138/2026-10-01/2026-10-01/text/original/epub/OEBPS/document_1/document_1.html).",
    "line": 55
  },
  "short_exact_native_quotes": [
    "resident or resident of Australia means: (a) a person, other than a company, who resides in Australia and includes a person: (i) whose domicile is"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/au-itaa1936-v1.txt",
  "source_sha256": "cae0963b7533f82f48cb2759bdb6b5281abdb0e3a1f40c173bbf94ec6df00d1c",
  "source_version_basis": "1October2026 compilation; actual retained text497–505 personally reread; earlier web line numbering is not retained-text numbering."
}
```

### AU-ORDINARY-INCOME-SCOPE

A resident generally has worldwide ordinary-income scope. A foreign resident has Australian-source ordinary income and other specifically included ordinary income; other exemption provisions remain separate.

```json
{
  "act_article_or_scope": "ITAA1997 s6-5(1)–(4)",
  "actual_read_on": "2026-11-16",
  "id": "AU-ORDINARY-INCOME-SCOPE",
  "official_url": "https://www.legislation.gov.au/C2004A05138/2026-10-01/2026-10-01/text/original/epub/OEBPS/document_1/document_1.html",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "**Australia.** ITAA 1936 s 6 has separate ordinary-residence, domicile, more-than-half-income-year and specified Commonwealth superannuation routes, with their actual exceptions. A short stay does not defeat an Australian domicile or ordinary residence. The general financial year is 12 months beginning 1 July; approved substituted accounting periods and statutory exceptions must be checked. Resident ordinary and statutory income generally have worldwide scope; foreign-resident source and specifically included income are separate from exemptions and temporary-resident concessions. [Current residence definition](https://www.legislation.gov.au/C1936A00027/2026-10-01/2026-10-01/text/original/epub/OEBPS/document_1/document_1.html); [income-year and scope provisions](https://www.legislation.gov.au/C2004A05138/2026-10-01/2026-10-01/text/original/epub/OEBPS/document_1/document_1.html).",
    "line": 55
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/au-itaa1997-v1.txt",
  "source_sha256": "bdac4c68764af13bba951364469422db9f76249cbc3e509f0c4a7809e8c7d83d",
  "source_version_basis": "Compilation268 dated1October2026"
}
```

### AU-STATUTORY-INCOME-SCOPE

Statutory income has its own inclusion, receipt and residence/source rules, including specifically included income beyond the source limb.

```json
{
  "act_article_or_scope": "ITAA1997 s6-10(1)–(5)",
  "actual_read_on": "2026-11-16",
  "id": "AU-STATUTORY-INCOME-SCOPE",
  "official_url": "https://www.legislation.gov.au/C2004A05138/2026-10-01/2026-10-01/text/original/epub/OEBPS/document_1/document_1.html",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "**Australia.** ITAA 1936 s 6 has separate ordinary-residence, domicile, more-than-half-income-year and specified Commonwealth superannuation routes, with their actual exceptions. A short stay does not defeat an Australian domicile or ordinary residence. The general financial year is 12 months beginning 1 July; approved substituted accounting periods and statutory exceptions must be checked. Resident ordinary and statutory income generally have worldwide scope; foreign-resident source and specifically included income are separate from exemptions and temporary-resident concessions. [Current residence definition](https://www.legislation.gov.au/C1936A00027/2026-10-01/2026-10-01/text/original/epub/OEBPS/document_1/document_1.html); [income-year and scope provisions](https://www.legislation.gov.au/C2004A05138/2026-10-01/2026-10-01/text/original/epub/OEBPS/document_1/document_1.html).",
    "line": 55
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/au-itaa1997-v1.txt",
  "source_sha256": "bdac4c68764af13bba951364469422db9f76249cbc3e509f0c4a7809e8c7d83d",
  "source_version_basis": "Compilation268 dated1October2026"
}
```

### AU-I1-EVENT

I1 occurs when residence ceases. It covers assets except specified855-15items1/3 and linkeditem4rights, computes gain/loss from market value and cost/reduced cost, and has an indirect-property interest reset and pre1985exception.

```json
{
  "act_article_or_scope": "ITAA1997 s104-160(1)–(5)",
  "actual_read_on": "2026-11-16",
  "id": "AU-I1-EVENT",
  "official_url": "https://www.legislation.gov.au/C2004A05138/2026-10-01/2026-10-01/text/original/epub/OEBPS/document_3/document_3.html",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "| Australia | CGT event I1 generally covers relevant assets outside the specified taxable-Australian-property exceptions when residence ceases, rather than deeming disposal of all TAP. Pre 20 September 1985 assets are disregarded under the provision. An individual may choose to disregard all covered I1 gains/losses, with future-TAP consequences until an ownership-ending event or resumed residence. Temporary-resident and asset-category rules must be resolved. Sources: [ITAA1997 s104-160(1)–(5)](https://www.legislation.gov.au/C2004A05138/2026-10-01/2026-10-01/text/original/epub/OEBPS/document_3/document_3.html); [ITAA1997 s855-15 all5items and notes](https://www.legislation.gov.au/C2004A05138/2026-10-01/2026-10-01/text/original/epub/OEBPS/document_9/document_9.html). |",
    "line": 132
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/res-au-law.txt",
  "source_sha256": "f7cc8357901110c3994c86e446a96abdecef5e42fbd6620d340f39a3842372e2",
  "source_version_basis": "Compilation268 dated1October2026; actual retained source personally reread3977–4010"
}
```

### AU-I1-INDIVIDUAL-CHOICE

An individual can choose to disregard gains/losses from all covered I1assets. They become TAP until an ownership-ending CGT event or resumed residence. The specific2006historical-transition note must also be checked.

```json
{
  "act_article_or_scope": "ITAA1997 s104-165(2)–(3) including historical transition note",
  "actual_read_on": "2026-11-16",
  "id": "AU-I1-INDIVIDUAL-CHOICE",
  "official_url": "https://www.legislation.gov.au/C2004A05138/2026-10-01/2026-10-01/text/original/epub/OEBPS/document_3/document_3.html",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "| Australia | CGT event I1 generally covers relevant assets outside the specified taxable-Australian-property exceptions when residence ceases, rather than deeming disposal of all TAP. Pre 20 September 1985 assets are disregarded under the provision. An individual may choose to disregard all covered I1 gains/losses, with future-TAP consequences until an ownership-ending event or resumed residence. Temporary-resident and asset-category rules must be resolved. Sources: [ITAA1997 s104-160(1)–(5)](https://www.legislation.gov.au/C2004A05138/2026-10-01/2026-10-01/text/original/epub/OEBPS/document_3/document_3.html); [ITAA1997 s855-15 all5items and notes](https://www.legislation.gov.au/C2004A05138/2026-10-01/2026-10-01/text/original/epub/OEBPS/document_9/document_9.html). |",
    "line": 132
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/res-au-law.txt",
  "source_sha256": "f7cc8357901110c3994c86e446a96abdecef5e42fbd6620d340f39a3842372e2",
  "source_version_basis": "Compilation268 dated1October2026"
}
```

### AU-TAP-CATEGORIES

The five TAP categories include direct property, qualifying indirect property, specified PE business assets, linked rights/options and prior I1choice assets. I1does not exclude every TAP category.

```json
{
  "act_article_or_scope": "ITAA1997 s855-15 all5items and notes,855-16",
  "actual_read_on": "2026-11-16",
  "id": "AU-TAP-CATEGORIES",
  "official_url": "https://www.legislation.gov.au/C2004A05138/2026-10-01/2026-10-01/text/original/epub/OEBPS/document_9/document_9.html",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "| Australia | CGT event I1 generally covers relevant assets outside the specified taxable-Australian-property exceptions when residence ceases, rather than deeming disposal of all TAP. Pre 20 September 1985 assets are disregarded under the provision. An individual may choose to disregard all covered I1 gains/losses, with future-TAP consequences until an ownership-ending event or resumed residence. Temporary-resident and asset-category rules must be resolved. Sources: [ITAA1997 s104-160(1)–(5)](https://www.legislation.gov.au/C2004A05138/2026-10-01/2026-10-01/text/original/epub/OEBPS/document_3/document_3.html); [ITAA1997 s855-15 all5items and notes](https://www.legislation.gov.au/C2004A05138/2026-10-01/2026-10-01/text/original/epub/OEBPS/document_9/document_9.html). |",
    "line": 132
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/au-itaa1997-v9.txt",
  "source_sha256": "0cc93983f65719a57e8af837ed93b49381184c1823da1d0c0c790613f3760f60",
  "source_version_basis": "Compilation268 dated1October2026; entire assignedtable/notes nativebody"
}
```

### AU-TEMP-RESIDENT-CGT

Temporary-resident CGT disregard depends on hypothetical foreign-resident treatment, with an explicit I1exception for qualifying start-up ESS rights and shares.

```json
{
  "act_article_or_scope": "ITAA1997 s768-915(1)–(2)",
  "actual_read_on": "2026-11-16",
  "id": "AU-TEMP-RESIDENT-CGT",
  "official_url": "https://www.legislation.gov.au/C2004A05138/2026-10-01/2026-10-01/text/original/epub/OEBPS/document_9/document_9.html",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "| Australia | CGT event I1 generally covers relevant assets outside the specified taxable-Australian-property exceptions when residence ceases, rather than deeming disposal of all TAP. Pre 20 September 1985 assets are disregarded under the provision. An individual may choose to disregard all covered I1 gains/losses, with future-TAP consequences until an ownership-ending event or resumed residence. Temporary-resident and asset-category rules must be resolved. Sources: [ITAA1997 s104-160(1)–(5)](https://www.legislation.gov.au/C2004A05138/2026-10-01/2026-10-01/text/original/epub/OEBPS/document_3/document_3.html); [ITAA1997 s855-15 all5items and notes](https://www.legislation.gov.au/C2004A05138/2026-10-01/2026-10-01/text/original/epub/OEBPS/document_9/document_9.html). |",
    "line": 132
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/au-itaa1997-v9.txt",
  "source_sha256": "0cc93983f65719a57e8af837ed93b49381184c1823da1d0c0c790613f3760f60",
  "source_version_basis": "Compilation268 dated1October2026"
}
```

### AU-TEMP-RESIDENT-DEFINITION

Temporary tax residence requires the visa and claimant/spouse social-security-residence conditions, subject to the historical qualification-loss exclusion. A visa label alone is insufficient.

```json
{
  "act_article_or_scope": "ITAA1997 s995-1 temporary resident definition and exclusion",
  "actual_read_on": "2026-11-16",
  "id": "AU-TEMP-RESIDENT-DEFINITION",
  "official_url": "https://www.legislation.gov.au/C2004A05138/2026-10-01/2026-10-01/text/original/epub/OEBPS/document_10/document_10.html",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "| Australia | CGT event I1 generally covers relevant assets outside the specified taxable-Australian-property exceptions when residence ceases, rather than deeming disposal of all TAP. Pre 20 September 1985 assets are disregarded under the provision. An individual may choose to disregard all covered I1 gains/losses, with future-TAP consequences until an ownership-ending event or resumed residence. Temporary-resident and asset-category rules must be resolved. Sources: [ITAA1997 s104-160(1)–(5)](https://www.legislation.gov.au/C2004A05138/2026-10-01/2026-10-01/text/original/epub/OEBPS/document_3/document_3.html); [ITAA1997 s855-15 all5items and notes](https://www.legislation.gov.au/C2004A05138/2026-10-01/2026-10-01/text/original/epub/OEBPS/document_9/document_9.html). |",
    "line": 132
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/au-itaa1997-v10.txt",
  "source_sha256": "b8c7c388f0d9e051458a3a3ab2726048fbe508f8fb4c803a099766c7cf5de3bd",
  "source_version_basis": "Compilation268 dated1October2026"
}
```

### US-CFC-GENERAL

The general CFC gate is more than50% of vote or value owned under958(a)/(b) by US shareholders on any day. It is not limited to one individual owning50% directly.

```json
{
  "act_article_or_scope": "IRC957(a)",
  "actual_read_on": "2026-11-16",
  "id": "US-CFC-GENERAL",
  "official_url": "https://uscode.house.gov/us/usc/t26/s957/",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "Foreign tax credits apply under their own categories and limitations; taxes on excluded income cannot simply be credited again. A foreign corporation can trigger Subpart F and, for the applicable post 2025 taxable years, net CFC tested income rules. The general CFC test is more than 50% vote or value owned by US shareholders, with direct/indirect/constructive attribution; a US shareholder generally meets a 10% vote/value gate. Special insurance and possession rules exist. New 2026 pro-rata timing must be applied using the actual foreign corporation's taxable year. Sources: [Foreign tax credit or deduction paragraph](https://www.irs.gov/instructions/i2555); [IRC957(a)](https://uscode.house.gov/us/usc/t26/s957/); [IRC951A(a)–(d)](https://uscode.house.gov/us/usc/t26/s951A/); [PL119-21 s70354(c)](https://uscode.house.gov/us/usc/t26/s951/).",
    "line": 112
  },
  "short_exact_native_quotes": [
    "(a) General rule For purposes of this title, the term “controlled foreign corporation” means any foreign corporation if more than 50 percent of⁠— (1) the"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/us-code957.txt",
  "source_sha256": "8d30cd78be7beae6f52d63f6ad635f93e52e41979b8414dfae916a1c1a4c8467",
  "source_version_basis": "Text through Public Law119-142 of10November2026"
}
```

### US-CFC-INSURANCE

The special insurance CFC rule has more-than25% vote/value ownership and a75% premiums condition, within the specified insurance-income scope.

```json
{
  "act_article_or_scope": "IRC957(b)",
  "actual_read_on": "2026-11-16",
  "id": "US-CFC-INSURANCE",
  "official_url": "https://uscode.house.gov/us/usc/t26/s957/",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "Foreign tax credits apply under their own categories and limitations; taxes on excluded income cannot simply be credited again. A foreign corporation can trigger Subpart F and, for the applicable post 2025 taxable years, net CFC tested income rules. The general CFC test is more than 50% vote or value owned by US shareholders, with direct/indirect/constructive attribution; a US shareholder generally meets a 10% vote/value gate. Special insurance and possession rules exist. New 2026 pro-rata timing must be applied using the actual foreign corporation's taxable year. Sources: [Foreign tax credit or deduction paragraph](https://www.irs.gov/instructions/i2555); [IRC957(a)](https://uscode.house.gov/us/usc/t26/s957/); [IRC951A(a)–(d)](https://uscode.house.gov/us/usc/t26/s951A/); [PL119-21 s70354(c)](https://uscode.house.gov/us/usc/t26/s951/).",
    "line": 112
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/us-code957.txt",
  "source_sha256": "8d30cd78be7beae6f52d63f6ad635f93e52e41979b8414dfae916a1c1a4c8467",
  "source_version_basis": "Text through Public Law119-142 of10November2026"
}
```

### US-CFC-PERSON-EXCEPTIONS

The US-person definition has conditional Puerto Rico and Guam/American Samoa/Northern Mariana Islands exceptions.

```json
{
  "act_article_or_scope": "IRC957(c)",
  "actual_read_on": "2026-11-16",
  "id": "US-CFC-PERSON-EXCEPTIONS",
  "official_url": "https://uscode.house.gov/us/usc/t26/s957/",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "Foreign tax credits apply under their own categories and limitations; taxes on excluded income cannot simply be credited again. A foreign corporation can trigger Subpart F and, for the applicable post 2025 taxable years, net CFC tested income rules. The general CFC test is more than 50% vote or value owned by US shareholders, with direct/indirect/constructive attribution; a US shareholder generally meets a 10% vote/value gate. Special insurance and possession rules exist. New 2026 pro-rata timing must be applied using the actual foreign corporation's taxable year. Sources: [Foreign tax credit or deduction paragraph](https://www.irs.gov/instructions/i2555); [IRC957(a)](https://uscode.house.gov/us/usc/t26/s957/); [IRC951A(a)–(d)](https://uscode.house.gov/us/usc/t26/s951A/); [PL119-21 s70354(c)](https://uscode.house.gov/us/usc/t26/s951/).",
    "line": 112
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/us-code957.txt",
  "source_sha256": "8d30cd78be7beae6f52d63f6ad635f93e52e41979b8414dfae916a1c1a4c8467",
  "source_version_basis": "Text through Public Law119-142 of10November2026"
}
```

### US-CFC-INCLUSION-TIMING

The current Subpart F pro-rata rule follows specified ownership/status periods and shareholder-year timing. Section956has a distinct last-CFC-day ownership condition.

```json
{
  "act_article_or_scope": "IRC951(a)(1)–(4)",
  "actual_read_on": "2026-11-16",
  "id": "US-CFC-INCLUSION-TIMING",
  "official_url": "https://uscode.house.gov/us/usc/t26/s951/",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "Foreign tax credits apply under their own categories and limitations; taxes on excluded income cannot simply be credited again. A foreign corporation can trigger Subpart F and, for the applicable post 2025 taxable years, net CFC tested income rules. The general CFC test is more than 50% vote or value owned by US shareholders, with direct/indirect/constructive attribution; a US shareholder generally meets a 10% vote/value gate. Special insurance and possession rules exist. New 2026 pro-rata timing must be applied using the actual foreign corporation's taxable year. Sources: [Foreign tax credit or deduction paragraph](https://www.irs.gov/instructions/i2555); [IRC957(a)](https://uscode.house.gov/us/usc/t26/s957/); [IRC951A(a)–(d)](https://uscode.house.gov/us/usc/t26/s951A/); [PL119-21 s70354(c)](https://uscode.house.gov/us/usc/t26/s951/).",
    "line": 112
  },
  "short_exact_native_quotes": [
    "(a) Amounts included (1) In general If a foreign corporation is a controlled foreign corporation at any time during a taxable year of the foreign"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/us-code951.txt",
  "source_sha256": "5f58ba0b95609a5c60e813089005857d4becec5e895dd50952dee080de3983cc",
  "source_version_basis": "Text through Public Law119-142 of10November2026; effectivegateinUS-CFC-2026-EFFECTIVE"
}
```

### US-CFC-SHAREHOLDER

A US shareholder generally is a US person owning at least10% vote or value under direct/indirect and constructive ownership rules.

```json
{
  "act_article_or_scope": "IRC951(b)",
  "actual_read_on": "2026-11-16",
  "id": "US-CFC-SHAREHOLDER",
  "official_url": "https://uscode.house.gov/us/usc/t26/s951/",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "Foreign tax credits apply under their own categories and limitations; taxes on excluded income cannot simply be credited again. A foreign corporation can trigger Subpart F and, for the applicable post 2025 taxable years, net CFC tested income rules. The general CFC test is more than 50% vote or value owned by US shareholders, with direct/indirect/constructive attribution; a US shareholder generally meets a 10% vote/value gate. Special insurance and possession rules exist. New 2026 pro-rata timing must be applied using the actual foreign corporation's taxable year. Sources: [Foreign tax credit or deduction paragraph](https://www.irs.gov/instructions/i2555); [IRC957(a)](https://uscode.house.gov/us/usc/t26/s957/); [IRC951A(a)–(d)](https://uscode.house.gov/us/usc/t26/s951A/); [PL119-21 s70354(c)](https://uscode.house.gov/us/usc/t26/s951/).",
    "line": 112
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/us-code951.txt",
  "source_sha256": "5f58ba0b95609a5c60e813089005857d4becec5e895dd50952dee080de3983cc",
  "source_version_basis": "Text through Public Law119-142 of10November2026"
}
```

### US-CFC-2026-EFFECTIVE

The2025timing amendments apply to foreign-corporation taxable years beginning after31December2025, with a specified dividend-transition rule.

```json
{
  "act_article_or_scope": "PL119-21 s70354(c), effective-date and dividend-transition note",
  "actual_read_on": "2026-11-16",
  "id": "US-CFC-2026-EFFECTIVE",
  "official_url": "https://uscode.house.gov/us/usc/t26/s951/",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "Foreign tax credits apply under their own categories and limitations; taxes on excluded income cannot simply be credited again. A foreign corporation can trigger Subpart F and, for the applicable post 2025 taxable years, net CFC tested income rules. The general CFC test is more than 50% vote or value owned by US shareholders, with direct/indirect/constructive attribution; a US shareholder generally meets a 10% vote/value gate. Special insurance and possession rules exist. New 2026 pro-rata timing must be applied using the actual foreign corporation's taxable year. Sources: [Foreign tax credit or deduction paragraph](https://www.irs.gov/instructions/i2555); [IRC957(a)](https://uscode.house.gov/us/usc/t26/s957/); [IRC951A(a)–(d)](https://uscode.house.gov/us/usc/t26/s951A/); [PL119-21 s70354(c)](https://uscode.house.gov/us/usc/t26/s951/).",
    "line": 112
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/us-code951.txt",
  "source_sha256": "5f58ba0b95609a5c60e813089005857d4becec5e895dd50952dee080de3983cc",
  "source_version_basis": "Text through Public Law119-142 of10November2026"
}
```

### US-NCTI-STATUTE

Net CFC tested income follows the statutory tested-income, loss, pro-rata and coordination conditions; it is not an automatic charge on all foreign-company profits.

```json
{
  "act_article_or_scope": "IRC951A(a)–(d)",
  "actual_read_on": "2026-11-16",
  "id": "US-NCTI-STATUTE",
  "official_url": "https://uscode.house.gov/us/usc/t26/s951A/",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "Foreign tax credits apply under their own categories and limitations; taxes on excluded income cannot simply be credited again. A foreign corporation can trigger Subpart F and, for the applicable post 2025 taxable years, net CFC tested income rules. The general CFC test is more than 50% vote or value owned by US shareholders, with direct/indirect/constructive attribution; a US shareholder generally meets a 10% vote/value gate. Special insurance and possession rules exist. New 2026 pro-rata timing must be applied using the actual foreign corporation's taxable year. Sources: [Foreign tax credit or deduction paragraph](https://www.irs.gov/instructions/i2555); [IRC957(a)](https://uscode.house.gov/us/usc/t26/s957/); [IRC951A(a)–(d)](https://uscode.house.gov/us/usc/t26/s951A/); [PL119-21 s70354(c)](https://uscode.house.gov/us/usc/t26/s951/).",
    "line": 112
  },
  "short_exact_native_quotes": [
    "§951A. Net CFC tested income included in gross income of United States shareholders (a) In general Each person who is a United States shareholder of"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/us-code951a.txt",
  "source_sha256": "0c1c006579afdffab60e93b55caf671e0c2f23b3bf696064d4a95a6bda027415",
  "source_version_basis": "Text through Public Law119-142 of10November2026; effectivedatesseparateUS-NCTI-EFFECTIVE"
}
```

### US-NCTI-EFFECTIVE

The terminology/structural amendments apply to taxable years beginning after31December2025. Section70354timing amendments use the foreign corporation taxable-year gate.

```json
{
  "act_article_or_scope": "IRC951A2025effective-date notes",
  "actual_read_on": "2026-11-16",
  "id": "US-NCTI-EFFECTIVE",
  "official_url": "https://uscode.house.gov/us/usc/t26/s951A/",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "Foreign tax credits apply under their own categories and limitations; taxes on excluded income cannot simply be credited again. A foreign corporation can trigger Subpart F and, for the applicable post 2025 taxable years, net CFC tested income rules. The general CFC test is more than 50% vote or value owned by US shareholders, with direct/indirect/constructive attribution; a US shareholder generally meets a 10% vote/value gate. Special insurance and possession rules exist. New 2026 pro-rata timing must be applied using the actual foreign corporation's taxable year. Sources: [Foreign tax credit or deduction paragraph](https://www.irs.gov/instructions/i2555); [IRC957(a)](https://uscode.house.gov/us/usc/t26/s957/); [IRC951A(a)–(d)](https://uscode.house.gov/us/usc/t26/s951A/); [PL119-21 s70354(c)](https://uscode.house.gov/us/usc/t26/s951/).",
    "line": 112
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/us-code951a.txt",
  "source_sha256": "0c1c006579afdffab60e93b55caf671e0c2f23b3bf696064d4a95a6bda027415",
  "source_version_basis": "Text through Public Law119-142 of10November2026"
}
```

### US-5472-DE-DEFINITION

A wholly foreign-owned domestic disregarded entity is classified separately as a corporation for limited6038Apurposes, without universal income-tax corporate classification.

```json
{
  "act_article_or_scope": "Foreign-owned US DE definition",
  "actual_read_on": "2026-11-16",
  "id": "US-5472-DE-DEFINITION",
  "official_url": "https://www.irs.gov/instructions/i5472",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "Form 5471 duties depend on the actual reporting category, attribution, exceptions and current forms. The retained December 2025 instructions describe a USD 10000 initial section 6038 failure penalty per annual accounting period/foreign corporation and additional notice-based penalties; they are not a final 2026 form execution manual. A domestic disregarded single-member LLC is not a foreign corporation merely because its owner lives abroad. Corporate election, local-country classification, US trade/business and foreign-owned disregarded entity reporting still require separate checks. The retained December 2024 Form 5472 instructions are the source basis, rather than a final 2026 filing manual. Form 5472 with a proforma 1120 can apply to a foreign-owned domestic disregarded entity with reportable related-party transactions, even without an entity income-tax return. Sources: [Penalties:failure6038informationandreliefneighbors](https://www.irs.gov/instructions/i5471); [Foreign-owned US DE definition](https://www.irs.gov/instructions/i5472).",
    "line": 114
  },
  "short_exact_native_quotes": [
    "A foreign-owned U.S. DE is a domestic DE that is wholly owned by a foreign person. For tax years beginning on or after January 1,"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/us-i5472.txt",
  "source_sha256": "bf65112db109632af86baba4eb0087563e2f7a2e00034f64f3cbadb03209e6bd",
  "source_version_basis": "Retained authorityinstructions; nofinal2026formexecutionclaim"
}
```

### US-5472-FILING-EXCEPTIONS

A reporting corporation generally files for reportable related-party transactions. The six published exceptions and exceptions unavailable to foreign-owned disregarded entities must be checked.

```json
{
  "act_article_or_scope": "Who Must File and all6exceptions plusDEexceptionnote",
  "actual_read_on": "2026-11-16",
  "id": "US-5472-FILING-EXCEPTIONS",
  "official_url": "https://www.irs.gov/instructions/i5472",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "Form 5471 duties depend on the actual reporting category, attribution, exceptions and current forms. The retained December 2025 instructions describe a USD 10000 initial section 6038 failure penalty per annual accounting period/foreign corporation and additional notice-based penalties; they are not a final 2026 form execution manual. A domestic disregarded single-member LLC is not a foreign corporation merely because its owner lives abroad. Corporate election, local-country classification, US trade/business and foreign-owned disregarded entity reporting still require separate checks. The retained December 2024 Form 5472 instructions are the source basis, rather than a final 2026 filing manual. Form 5472 with a proforma 1120 can apply to a foreign-owned domestic disregarded entity with reportable related-party transactions, even without an entity income-tax return. Sources: [Penalties:failure6038informationandreliefneighbors](https://www.irs.gov/instructions/i5471); [Foreign-owned US DE definition](https://www.irs.gov/instructions/i5472).",
    "line": 114
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/us-i5472.txt",
  "source_sha256": "bf65112db109632af86baba4eb0087563e2f7a2e00034f64f3cbadb03209e6bd",
  "source_version_basis": "Retained authorityinstructions; actual1892–1986read"
}
```

### US-5472-PROFORMA

A covered foreign-owned disregarded entity attaches5472to a proforma1120by its applicable due date, including extensions. Owner-year and calendar-year fallback conditions apply.

```json
{
  "act_article_or_scope": "When and Where To File, Foreign-owned US DEs paragraph",
  "actual_read_on": "2026-11-16",
  "id": "US-5472-PROFORMA",
  "official_url": "https://www.irs.gov/instructions/i5472",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "Form 5471 duties depend on the actual reporting category, attribution, exceptions and current forms. The retained December 2025 instructions describe a USD 10000 initial section 6038 failure penalty per annual accounting period/foreign corporation and additional notice-based penalties; they are not a final 2026 form execution manual. A domestic disregarded single-member LLC is not a foreign corporation merely because its owner lives abroad. Corporate election, local-country classification, US trade/business and foreign-owned disregarded entity reporting still require separate checks. The retained December 2024 Form 5472 instructions are the source basis, rather than a final 2026 filing manual. Form 5472 with a proforma 1120 can apply to a foreign-owned domestic disregarded entity with reportable related-party transactions, even without an entity income-tax return. Sources: [Penalties:failure6038informationandreliefneighbors](https://www.irs.gov/instructions/i5471); [Foreign-owned US DE definition](https://www.irs.gov/instructions/i5472).",
    "line": 114
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/us-i5472.txt",
  "source_sha256": "bf65112db109632af86baba4eb0087563e2f7a2e00034f64f3cbadb03209e6bd",
  "source_version_basis": "Retained authorityinstructions; source-specificcurrentformversionmustbefinalregistered"
}
```

### US-5471-6038-PENALTIES

The December2025instructions describe a10000initial penalty per annual period/per foreign corporation; after90days from IRS notice,10000per30-day period or fraction, capped at50000additional. Credit reductions and relief are separate.

```json
{
  "act_article_or_scope": "Penalties:failure6038informationandreliefneighbors",
  "actual_read_on": "2026-11-16",
  "id": "US-5471-6038-PENALTIES",
  "official_url": "https://www.irs.gov/instructions/i5471",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "Form 5471 duties depend on the actual reporting category, attribution, exceptions and current forms. The retained December 2025 instructions describe a USD 10000 initial section 6038 failure penalty per annual accounting period/foreign corporation and additional notice-based penalties; they are not a final 2026 form execution manual. A domestic disregarded single-member LLC is not a foreign corporation merely because its owner lives abroad. Corporate election, local-country classification, US trade/business and foreign-owned disregarded entity reporting still require separate checks. The retained December 2024 Form 5472 instructions are the source basis, rather than a final 2026 filing manual. Form 5472 with a proforma 1120 can apply to a foreign-owned domestic disregarded entity with reportable related-party transactions, even without an entity income-tax return. Sources: [Penalties:failure6038informationandreliefneighbors](https://www.irs.gov/instructions/i5471); [Foreign-owned US DE definition](https://www.irs.gov/instructions/i5472).",
    "line": 114
  },
  "short_exact_native_quotes": [
    "A $10,000 penalty is imposed for each annual accounting period of each foreign corporation for failure to furnish the information required by section 6038(a) within"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/us-i5471.txt",
  "source_sha256": "7f286e98c542bf317f7f052560878759dcf930a5b45346946bd80f8b4ae8beda",
  "source_version_basis": "December2025instructions; NOTfinal2026formcategoryclearance"
}
```

### NL-DOMESTIC-PERSON

Dutch residence depends on permanent residence/stay and actual personal circumstances, including home, family, work and other connections; not a universal183-day test.

```json
{
  "act_article_or_scope": "Current authority guidance, Natuurlijke personen",
  "actual_read_on": "2026-11-16",
  "id": "NL-DOMESTIC-PERSON",
  "official_url": "https://www.belastingdienst.nl/wps/wcm/connect/bldcontentnl/belastingdienst/zakelijk/internationaal/vermogen/common_reporting_standard/regels",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "**Netherlands.** Belastingdienst's current guidance weighs actual home/stay, family, work, insurance, doctor, associations and schooling. Company policy decisions, management, administration, incorporation and legal form are different facts. A bank's CRS classification need not settle the income-tax assessment. This is the authority's factual guidance; a treaty conflict still needs the relevant bilateral article. [Published residence factors](https://www.belastingdienst.nl/wps/wcm/connect/bldcontentnl/belastingdienst/zakelijk/internationaal/vermogen/common_reporting_standard/regels).",
    "line": 57
  },
  "short_exact_native_quotes": [
    "Als natuurlijk persoon bent u fiscaal inwoner van Nederland als u uw permanente woon- of verblijfplaats in Nederland hebt. Daarbij kijken we onder meer of"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/nl-domestic-facts.txt",
  "source_sha256": "59eed41892c76019ab415e9fd32905519ef76dd9754d21887ee5af750840249a",
  "source_version_basis": "Actual current official page read16November2026; statutoryAWR4cross-check still pending."
}
```

### NL-DOMESTIC-COMPANY

Company residence considers actual policy decisions, directors, administration, shareholder/location and legal-form facts; incorporation alone does not settle the case.

```json
{
  "act_article_or_scope": "Current authority guidance, Organisaties",
  "actual_read_on": "2026-11-16",
  "id": "NL-DOMESTIC-COMPANY",
  "official_url": "https://www.belastingdienst.nl/wps/wcm/connect/bldcontentnl/belastingdienst/zakelijk/internationaal/vermogen/common_reporting_standard/regels",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "**Netherlands.** Belastingdienst's current guidance weighs actual home/stay, family, work, insurance, doctor, associations and schooling. Company policy decisions, management, administration, incorporation and legal form are different facts. A bank's CRS classification need not settle the income-tax assessment. This is the authority's factual guidance; a treaty conflict still needs the relevant bilateral article. [Published residence factors](https://www.belastingdienst.nl/wps/wcm/connect/bldcontentnl/belastingdienst/zakelijk/internationaal/vermogen/common_reporting_standard/regels).",
    "line": 57
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/nl-domestic-facts.txt",
  "source_sha256": "59eed41892c76019ab415e9fd32905519ef76dd9754d21887ee5af750840249a",
  "source_version_basis": "Actual current official page read16November2026; no person-specific conclusion."
}
```

### NL-CRS-NOT-FINAL-TAX

The tax authority can take a different tax-residence position from financial institutions; a bank record is not conclusive tax evidence.

```json
{
  "act_article_or_scope": "Current authority guidance, Let op",
  "actual_read_on": "2026-11-16",
  "id": "NL-CRS-NOT-FINAL-TAX",
  "official_url": "https://www.belastingdienst.nl/wps/wcm/connect/bldcontentnl/belastingdienst/zakelijk/internationaal/vermogen/common_reporting_standard/regels",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "**Netherlands.** Belastingdienst's current guidance weighs actual home/stay, family, work, insurance, doctor, associations and schooling. Company policy decisions, management, administration, incorporation and legal form are different facts. A bank's CRS classification need not settle the income-tax assessment. This is the authority's factual guidance; a treaty conflict still needs the relevant bilateral article. [Published residence factors](https://www.belastingdienst.nl/wps/wcm/connect/bldcontentnl/belastingdienst/zakelijk/internationaal/vermogen/common_reporting_standard/regels).",
    "line": 57
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/nl-domestic-facts.txt",
  "source_sha256": "59eed41892c76019ab415e9fd32905519ef76dd9754d21887ee5af750840249a",
  "source_version_basis": "Actual current official page read16November2026."
}
```

### CR-SELFEMPLOYED-ZERO

Annual self-employed income throughCRC6244000is outside the charge in the published2026chart.

```json
{
  "act_article_or_scope": "2026ratechart, section2 annual self-employed first row",
  "actual_read_on": "2026-11-16",
  "id": "CR-SELFEMPLOYED-ZERO",
  "official_url": "https://www.hacienda.go.cr/docs/TramosRenta2026.pdf",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "| Costa Rica | The authority’s 2025 presentation for the 2024 closure describes domestic profitable-activity scope irrespective of nationality and the listed contractual connections; it is dated guidance, not the recovered full current Code. [Actual scope presentation pp2–4](https://www.hacienda.go.cr/docs/CHARLAISU-2024-27-02-2025.pdf). The official 2026 self-employed annual bands are zero through CRC 6244000,10% on the excess through 8329000,15% through 10414000,20% through 20872000 and 25% above. Employment has different monthly bands. Rentista permission does not itself classify work income. Sources: [2026ratechart](https://www.hacienda.go.cr/docs/TramosRenta2026.pdf). |",
    "line": 86
  },
  "short_exact_native_quotes": [
    "Las rentas de hasta ¢6.244.000,00 (seis millones No están sujetas al impuesto doscientos cuarenta y cuatro mil colones) anuales"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/cr-rates2026-official.txt",
  "source_sha256": "8ba3b7c1039ad53a93d4647842895b2f39bdd1f3fc2144b98eda5b9728ffc14b",
  "source_version_basis": "Official2026chart; whole rendered one-page chart personally visually checked."
}
```

### CR-SELFEMPLOYED-10

The excess aboveCRC6244000throughCRC8329000has10%marginal rate.

```json
{
  "act_article_or_scope": "2026ratechart, section2 annual self-employed second row",
  "actual_read_on": "2026-11-16",
  "id": "CR-SELFEMPLOYED-10",
  "official_url": "https://www.hacienda.go.cr/docs/TramosRenta2026.pdf",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "| Costa Rica | The authority’s 2025 presentation for the 2024 closure describes domestic profitable-activity scope irrespective of nationality and the listed contractual connections; it is dated guidance, not the recovered full current Code. [Actual scope presentation pp2–4](https://www.hacienda.go.cr/docs/CHARLAISU-2024-27-02-2025.pdf). The official 2026 self-employed annual bands are zero through CRC 6244000,10% on the excess through 8329000,15% through 10414000,20% through 20872000 and 25% above. Employment has different monthly bands. Rentista permission does not itself classify work income. Sources: [2026ratechart](https://www.hacienda.go.cr/docs/TramosRenta2026.pdf). |",
    "line": 86
  },
  "short_exact_native_quotes": [
    "Sobre el exceso de ¢6.244.000,00 (seis"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/cr-rates2026-official.txt",
  "source_sha256": "8ba3b7c1039ad53a93d4647842895b2f39bdd1f3fc2144b98eda5b9728ffc14b",
  "source_version_basis": "Official2026chart; actual chart manually visually checked."
}
```

### CR-SELFEMPLOYED-15

The excess aboveCRC8329000throughCRC10414000has15%marginal rate.

```json
{
  "act_article_or_scope": "2026ratechart, section2 annual self-employed third row",
  "actual_read_on": "2026-11-16",
  "id": "CR-SELFEMPLOYED-15",
  "official_url": "https://www.hacienda.go.cr/docs/TramosRenta2026.pdf",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "| Costa Rica | The authority’s 2025 presentation for the 2024 closure describes domestic profitable-activity scope irrespective of nationality and the listed contractual connections; it is dated guidance, not the recovered full current Code. [Actual scope presentation pp2–4](https://www.hacienda.go.cr/docs/CHARLAISU-2024-27-02-2025.pdf). The official 2026 self-employed annual bands are zero through CRC 6244000,10% on the excess through 8329000,15% through 10414000,20% through 20872000 and 25% above. Employment has different monthly bands. Rentista permission does not itself classify work income. Sources: [2026ratechart](https://www.hacienda.go.cr/docs/TramosRenta2026.pdf). |",
    "line": 86
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/cr-rates2026-official.txt",
  "source_sha256": "8ba3b7c1039ad53a93d4647842895b2f39bdd1f3fc2144b98eda5b9728ffc14b",
  "source_version_basis": "Official2026chart; actual chart manually visually checked."
}
```

### CR-SELFEMPLOYED-20

The excess aboveCRC10414000throughCRC20872000has20%marginal rate.

```json
{
  "act_article_or_scope": "2026ratechart, section2 annual self-employed fourth row",
  "actual_read_on": "2026-11-16",
  "id": "CR-SELFEMPLOYED-20",
  "official_url": "https://www.hacienda.go.cr/docs/TramosRenta2026.pdf",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "| Costa Rica | The authority’s 2025 presentation for the 2024 closure describes domestic profitable-activity scope irrespective of nationality and the listed contractual connections; it is dated guidance, not the recovered full current Code. [Actual scope presentation pp2–4](https://www.hacienda.go.cr/docs/CHARLAISU-2024-27-02-2025.pdf). The official 2026 self-employed annual bands are zero through CRC 6244000,10% on the excess through 8329000,15% through 10414000,20% through 20872000 and 25% above. Employment has different monthly bands. Rentista permission does not itself classify work income. Sources: [2026ratechart](https://www.hacienda.go.cr/docs/TramosRenta2026.pdf). |",
    "line": 86
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/cr-rates2026-official.txt",
  "source_sha256": "8ba3b7c1039ad53a93d4647842895b2f39bdd1f3fc2144b98eda5b9728ffc14b",
  "source_version_basis": "Official2026chart; actual chart manually visually checked."
}
```

### CR-SELFEMPLOYED-25

The excess aboveCRC20872000has25%marginal rate.

```json
{
  "act_article_or_scope": "2026ratechart, section2 annual self-employed final row",
  "actual_read_on": "2026-11-16",
  "id": "CR-SELFEMPLOYED-25",
  "official_url": "https://www.hacienda.go.cr/docs/TramosRenta2026.pdf",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "| Costa Rica | The authority’s 2025 presentation for the 2024 closure describes domestic profitable-activity scope irrespective of nationality and the listed contractual connections; it is dated guidance, not the recovered full current Code. [Actual scope presentation pp2–4](https://www.hacienda.go.cr/docs/CHARLAISU-2024-27-02-2025.pdf). The official 2026 self-employed annual bands are zero through CRC 6244000,10% on the excess through 8329000,15% through 10414000,20% through 20872000 and 25% above. Employment has different monthly bands. Rentista permission does not itself classify work income. Sources: [2026ratechart](https://www.hacienda.go.cr/docs/TramosRenta2026.pdf). |",
    "line": 86
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/cr-rates2026-official.txt",
  "source_sha256": "8ba3b7c1039ad53a93d4647842895b2f39bdd1f3fc2144b98eda5b9728ffc14b",
  "source_version_basis": "Official2026chart; actual chart manually visually checked."
}
```

### MY-MM2H-NATURE

MM2His a conditional long-term social visit pass/multiple-entry immigration programme, not an income-tax exemption.

```json
{
  "act_article_or_scope": "MM2H Topic1, What is the MM2H Programme?",
  "actual_read_on": "2026-11-16",
  "copyright_basis": "Actual FAQ footer: copyright reserved. No claim of public-domain FAQ text.",
  "id": "MY-MM2H-NATURE",
  "official_url": "https://www.motac.gov.my/en/frequently-asked-questions-faqs/",
  "quote_mode": "Short literal official FAQ extracts; <=25 words across the entire copyright-reserved source. Actual full operative paragraphs read, precise locators retained; no invented quotation.",
  "section": {
    "actual_text": "| Malaysia | The authority-hosted 2026 Act general resident tariff runs from 0% to 30%, under its actual chargeable-income bands and exception categories. The actual foreign-income exemption source has conditions for resident individuals, excludes partnership income received in Malaysia, and addresses subject-to-foreign-tax exceptions and records. Its 2024 extension commencing 1 January 2027 must not be described as a new 2026 exemption. MM2H is a category-dependent long-term social visit programme; MM2H permits general employment/business activity only in the Platinum category under the current FAQ; other categories need the relevant separate pass. Sources: [ITA1967Schedule1PartIparagraph1and1Aneighbor](https://www.hasil.gov.my/wp-content/uploads/Income-Tax-Act-1967-online-version-as-at-1-January-2026.pdf); [20June2024DGguideline5.2.2.1–2 allactualtax/deemed-taxconditions;5.2.4recordkeeping;PDFpp27–32](https://www.hasil.gov.my/wp-content/uploads/20240620-guidelines-tax-treatment-in-relation-to-income-received-from-abroad-amendment-june-2024.pdf); [PU(A)451/2024 native paragraphs1–2](https://lom.agc.gov.my/ilims/upload/portal/akta/outputp/2584396/PUA%20451_2024.pdf); [MM2H Topic2](https://www.motac.gov.my/en/frequently-asked-questions-faqs/). |",
    "line": 89
  },
  "short_exact_native_quotes": [
    "Long-Term Social Visit Pass"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/my-mm2h-faq.txt",
  "source_sha256": "d8ff44b2d423310f8cef4c837e3c6b889dbf9eea0838d0b831c5db72d71e73ee",
  "source_version_basis": "Current published official English FAQ personally read16November2026; finalnativeMalaycorroboration pending."
}
```

### MY-MM2H-WORK

Current authority FAQ allows employment/business/investment under Platinum only; other categories need the actual related pass, rather than assuming MM2H supplies general work permission.

```json
{
  "act_article_or_scope": "MM2H Topic2, work/business question",
  "actual_read_on": "2026-11-16",
  "copyright_basis": "Actual FAQ footer: copyright reserved. No claim of public-domain FAQ text.",
  "id": "MY-MM2H-WORK",
  "official_url": "https://www.motac.gov.my/en/frequently-asked-questions-faqs/",
  "quote_mode": "Short literal official FAQ extracts; <=25 words across the entire copyright-reserved source. Actual full operative paragraphs read, precise locators retained; no invented quotation.",
  "section": {
    "actual_text": "| Malaysia | The authority-hosted 2026 Act general resident tariff runs from 0% to 30%, under its actual chargeable-income bands and exception categories. The actual foreign-income exemption source has conditions for resident individuals, excludes partnership income received in Malaysia, and addresses subject-to-foreign-tax exceptions and records. Its 2024 extension commencing 1 January 2027 must not be described as a new 2026 exemption. MM2H is a category-dependent long-term social visit programme; MM2H permits general employment/business activity only in the Platinum category under the current FAQ; other categories need the relevant separate pass. Sources: [ITA1967Schedule1PartIparagraph1and1Aneighbor](https://www.hasil.gov.my/wp-content/uploads/Income-Tax-Act-1967-online-version-as-at-1-January-2026.pdf); [20June2024DGguideline5.2.2.1–2 allactualtax/deemed-taxconditions;5.2.4recordkeeping;PDFpp27–32](https://www.hasil.gov.my/wp-content/uploads/20240620-guidelines-tax-treatment-in-relation-to-income-received-from-abroad-amendment-june-2024.pdf); [PU(A)451/2024 native paragraphs1–2](https://lom.agc.gov.my/ilims/upload/portal/akta/outputp/2584396/PUA%20451_2024.pdf); [MM2H Topic2](https://www.motac.gov.my/en/frequently-asked-questions-faqs/). |",
    "line": 89
  },
  "short_exact_native_quotes": [
    "Employment opportunities and business/investment activities are ONLY allowed for the Platinum Category."
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/my-mm2h-faq.txt",
  "source_sha256": "d8ff44b2d423310f8cef4c837e3c6b889dbf9eea0838d0b831c5db72d71e73ee",
  "source_version_basis": "Current published official English FAQ personally read16November2026; no automatictaxresidence conclusion."
}
```

### ES-NOMAD-FUNDS

The teleworker funds rule is200%SMImonthly; first accompanying person75%SMIand eachadditional25%, with ownership, legality and availability of funds proved.

```json
{
  "act_article_or_scope": "Documentación que acredite los recursos económicos, all3paragraphs",
  "actual_read_on": "2026-11-16",
  "id": "ES-NOMAD-FUNDS",
  "official_url": "https://www.exteriores.gob.es/Consulados/miami/es/ServiciosConsulares/Paginas/index.aspx?scca=Visados&scco=Estados+Unidos&scd=196&scs=Visados+Nacionales+-+Visado+de+residencia+para+teletrabajo+%28n%C3%B3mada+digital%29",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "Spain's telework visa is generally up to 1 year or the shorter work period. Under Law 14/2013, the residence authorisation can be up to 3 years or the shorter work period, with conditional 2-year renewals. The official consular funds test is 200% of SMI for the teleworker,75% for the first accompanying person and 25% for each additional person; the old fixed EUR 2520 is not a current universal threshold. Foreign-employer work, qualifications/experience, actual existing relationship and social-insurance conditions apply. Self-employed Spanish clients are limited to 20% of activity under the immigration rule. LIRPF Art 93's elective regime requires no Spanish residence in the preceding 5 tax periods, a qualifying reason for the move and the relevant activity/no-PE conditions and exceptions. It covers the move year and the following 5 tax periods. Its ordinary base has 24% through EUR 600000 and 47% above; the separately defined investment-income base has different bands. A nomad visa alone neither elects nor proves eligibility for this regime. Sources: [Law14/2013 Art74bis all2paragraphs](https://www.boe.es/buscar/act.php?id=BOE-A-2013-10074); [Documentación que acredite los recursos económicos](https://www.exteriores.gob.es/Consulados/miami/es/ServiciosConsulares/Paginas/index.aspx?scca=Visados&scco=Estados+Unidos&scd=196&scs=Visados+Nacionales+-+Visado+de+residencia+para+teletrabajo+%28n%C3%B3mada+digital%29); [LIRPF93(1)](https://www.boe.es/buscar/act.php?id=BOE-A-2006-20764).",
    "line": 96
  },
  "short_exact_native_quotes": [
    "Documentación que acredite los recursos económicos a) Teletrabajador: cantidad que represente mensualmente el 200% del salario mínimo interprofesional (SMI). b) Familiares del teletrabajador: al menos"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/es-nomad-consulate.txt",
  "source_sha256": "69971f4a7612d1b7a0f507fdc46168cfe2a317af0c943c02a6fc311bb3d54e42",
  "source_version_basis": "Current official Miami consular page with2026fees link; datedread16November2026."
}
```

### ES-NOMAD-CLIENT-SCOPE

Employees work only for employers outside Spain; qualifying self-employed work for Spanish businesses cannot exceed20%of activity.

```json
{
  "act_article_or_scope": "Información general, remote-work and employer/client paragraphs",
  "actual_read_on": "2026-11-16",
  "id": "ES-NOMAD-CLIENT-SCOPE",
  "official_url": "https://www.exteriores.gob.es/Consulados/miami/es/ServiciosConsulares/Paginas/index.aspx?scca=Visados&scco=Estados+Unidos&scd=196&scs=Visados+Nacionales+-+Visado+de+residencia+para+teletrabajo+%28n%C3%B3mada+digital%29",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "Spain's telework visa is generally up to 1 year or the shorter work period. Under Law 14/2013, the residence authorisation can be up to 3 years or the shorter work period, with conditional 2-year renewals. The official consular funds test is 200% of SMI for the teleworker,75% for the first accompanying person and 25% for each additional person; the old fixed EUR 2520 is not a current universal threshold. Foreign-employer work, qualifications/experience, actual existing relationship and social-insurance conditions apply. Self-employed Spanish clients are limited to 20% of activity under the immigration rule. LIRPF Art 93's elective regime requires no Spanish residence in the preceding 5 tax periods, a qualifying reason for the move and the relevant activity/no-PE conditions and exceptions. It covers the move year and the following 5 tax periods. Its ordinary base has 24% through EUR 600000 and 47% above; the separately defined investment-income base has different bands. A nomad visa alone neither elects nor proves eligibility for this regime. Sources: [Law14/2013 Art74bis all2paragraphs](https://www.boe.es/buscar/act.php?id=BOE-A-2013-10074); [Documentación que acredite los recursos económicos](https://www.exteriores.gob.es/Consulados/miami/es/ServiciosConsulares/Paginas/index.aspx?scca=Visados&scco=Estados+Unidos&scd=196&scs=Visados+Nacionales+-+Visado+de+residencia+para+teletrabajo+%28n%C3%B3mada+digital%29); [LIRPF93(1)](https://www.boe.es/buscar/act.php?id=BOE-A-2006-20764).",
    "line": 96
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/es-nomad-consulate.txt",
  "source_sha256": "69971f4a7612d1b7a0f507fdc46168cfe2a317af0c943c02a6fc311bb3d54e42",
  "source_version_basis": "Current official consular page read16November2026; nationalLaw14/2013separately read."
}
```

### ES-NOMAD-DURATION

The visa is valid1year or the shorter authorisation period; permission during its validity and optionalTIEare distinct from a longer residence authorisation.

```json
{
  "act_article_or_scope": "Validez del visado and following TIE paragraph",
  "actual_read_on": "2026-11-16",
  "id": "ES-NOMAD-DURATION",
  "official_url": "https://www.exteriores.gob.es/Consulados/miami/es/ServiciosConsulares/Paginas/index.aspx?scca=Visados&scco=Estados+Unidos&scd=196&scs=Visados+Nacionales+-+Visado+de+residencia+para+teletrabajo+%28n%C3%B3mada+digital%29",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "Spain's telework visa is generally up to 1 year or the shorter work period. Under Law 14/2013, the residence authorisation can be up to 3 years or the shorter work period, with conditional 2-year renewals. The official consular funds test is 200% of SMI for the teleworker,75% for the first accompanying person and 25% for each additional person; the old fixed EUR 2520 is not a current universal threshold. Foreign-employer work, qualifications/experience, actual existing relationship and social-insurance conditions apply. Self-employed Spanish clients are limited to 20% of activity under the immigration rule. LIRPF Art 93's elective regime requires no Spanish residence in the preceding 5 tax periods, a qualifying reason for the move and the relevant activity/no-PE conditions and exceptions. It covers the move year and the following 5 tax periods. Its ordinary base has 24% through EUR 600000 and 47% above; the separately defined investment-income base has different bands. A nomad visa alone neither elects nor proves eligibility for this regime. Sources: [Law14/2013 Art74bis all2paragraphs](https://www.boe.es/buscar/act.php?id=BOE-A-2013-10074); [Documentación que acredite los recursos económicos](https://www.exteriores.gob.es/Consulados/miami/es/ServiciosConsulares/Paginas/index.aspx?scca=Visados&scco=Estados+Unidos&scd=196&scs=Visados+Nacionales+-+Visado+de+residencia+para+teletrabajo+%28n%C3%B3mada+digital%29); [LIRPF93(1)](https://www.boe.es/buscar/act.php?id=BOE-A-2006-20764).",
    "line": 96
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/es-nomad-consulate.txt",
  "source_sha256": "69971f4a7612d1b7a0f507fdc46168cfe2a317af0c943c02a6fc311bb3d54e42",
  "source_version_basis": "Current official consular page read16November2026; extraction stops before unrelated news/menu."
}
```

### DE-DOMESTIC-HOME

Available retained/usable accommodation can establish domestic residence without a183-day requirement.

```json
{
  "act_article_or_scope": "AO8 whole operative sentence",
  "actual_read_on": "2026-11-16",
  "id": "DE-DOMESTIC-HOME",
  "official_url": "https://www.gesetze-im-internet.de/ao_1977/__8.html",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "**Germany.** EStG 1 and AO 8–9 look to a residence held in circumstances indicating it will be retained/used, or ordinary residence; continuous presence beyond 6 months generally creates ordinary residence from the start, with the specified private-visit exception. An Abmeldung is evidence of registration, not the statutory date on which all tax residence necessarily ends. [EStG 1](https://www.gesetze-im-internet.de/estg/__1.html), [AO 8](https://www.gesetze-im-internet.de/ao_1977/__8.html), [AO 9](https://www.gesetze-im-internet.de/ao_1977/__9.html).",
    "line": 43
  },
  "short_exact_native_quotes": [
    "Einen Wohnsitz hat jemand dort, wo er eine Wohnung unter Umständen innehat, die darauf schließen lassen, dass er die Wohnung beibehalten und benutzen wird."
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/de-ao8.txt",
  "source_sha256": "d18c0ed3ce2d012a5ec22ed401e450795cd2553db5e629301bffae03eb86f2bb",
  "source_version_basis": "Current official native text actually read16November2026."
}
```

### DE-ORDINARY-STAY

Ordinary residence has actual-circumstances test; more than6continuous months counts from start with short breaks ignored; private-visit/treatment exception requires not more than1year.

```json
{
  "act_article_or_scope": "AO9 all3sentences",
  "actual_read_on": "2026-11-16",
  "id": "DE-ORDINARY-STAY",
  "official_url": "https://www.gesetze-im-internet.de/ao_1977/__9.html",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "**Germany.** EStG 1 and AO 8–9 look to a residence held in circumstances indicating it will be retained/used, or ordinary residence; continuous presence beyond 6 months generally creates ordinary residence from the start, with the specified private-visit exception. An Abmeldung is evidence of registration, not the statutory date on which all tax residence necessarily ends. [EStG 1](https://www.gesetze-im-internet.de/estg/__1.html), [AO 8](https://www.gesetze-im-internet.de/ao_1977/__8.html), [AO 9](https://www.gesetze-im-internet.de/ao_1977/__9.html).",
    "line": 43
  },
  "short_exact_native_quotes": [
    "Den gewöhnlichen Aufenthalt hat jemand dort, wo er sich unter Umständen aufhält, die erkennen lassen, dass er an diesem Ort oder in diesem Gebiet nicht"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/de-ao9.txt",
  "source_sha256": "7c4a07af7465a5ae12d55c868bfe28803b79ee2588c12de36911d3848e770592",
  "source_version_basis": "Current official native text personally read."
}
```

### DE-DOMESTIC-LIABILITY

Natural persons with domestic residence or ordinary residence have unlimited liability; deregistration is not the statutory definition.

```json
{
  "act_article_or_scope": "EStG1(1), opening residence sentence",
  "actual_read_on": "2026-11-16",
  "id": "DE-DOMESTIC-LIABILITY",
  "official_url": "https://www.gesetze-im-internet.de/estg/__1.html",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "**Germany.** EStG 1 and AO 8–9 look to a residence held in circumstances indicating it will be retained/used, or ordinary residence; continuous presence beyond 6 months generally creates ordinary residence from the start, with the specified private-visit exception. An Abmeldung is evidence of registration, not the statutory date on which all tax residence necessarily ends. [EStG 1](https://www.gesetze-im-internet.de/estg/__1.html), [AO 8](https://www.gesetze-im-internet.de/ao_1977/__8.html), [AO 9](https://www.gesetze-im-internet.de/ao_1977/__9.html).",
    "line": 43
  },
  "short_exact_native_quotes": [
    "(1) 1Natürliche Personen, die im Inland einen Wohnsitz oder ihren gewöhnlichen Aufenthalt haben, sind unbeschränkt einkommensteuerpflichtig."
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/de-estg1.txt",
  "source_sha256": "2df7d25083c50427464c9b64ee2f052afc92d78f091b95c5a156344af7d272f5",
  "source_version_basis": "Current official native text personally read; paragraphs2–4 also read, not asserted universally in this claim."
}
```

### GE-RESIDENCE-COMPLETE

Georgia residence is ordinarily183+days over continuous12months ending in the year, for the whole current year; special status, public-service, actual-stay additions/exclusions, partial days and prior-period restrictions apply.

```json
{
  "act_article_or_scope": "TaxCode34(1)–(8), all alternatives/counting/exclusions",
  "actual_read_on": "2026-11-16",
  "id": "GE-RESIDENCE-COMPLETE",
  "official_url": "https://www.matsne.gov.ge/ka/document/view/1043717",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "**Georgia.** Tax Code 34 generally makes a person resident for the whole current tax year after 183 or more days within a continuous 12-calendar-month period ending in it. Its actual-stay rules include specified absences, exclude specified diplomatic/public-service/transit/treatment/leisure presence, and count any part of a qualifying day. Prior-period days cannot automatically be reused for the following period. Public-service and special granted-status routes are separate. [Native current Code 34](https://www.matsne.gov.ge/ka/document/view/1043717).",
    "line": 59
  },
  "short_exact_native_quotes": [
    "მუხლი 34. საქართველოს რეზიდენტი და არარეზიდენტი ფიზიკური პირები 1. ფიზიკურ პირებად ითვლებიან: ა) საქართველოს მოქალაქეები; ბ) უცხო ქვეყნის მოქალაქეები; გ) მოქალაქეობის არმქონე პირები. 2. საქართველოს"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/ge-code-native.txt",
  "source_sha256": "184c60e61357aa4c3c3d743479b8c032ae3b123a0e837f55d5432adb5111befa",
  "source_version_basis": "Native consolidated Code current28October2026; own full operative clause and neighbours read."
}
```

### GE-MICRO-ELIGIBILITY

Micro status has no-hired-labour/independent-person/30000gross-receipts condition, application and prohibited-activity/threshold exceptions; it is distinct from small-business1%.

```json
{
  "act_article_or_scope": "TaxCode84–85 complete",
  "actual_read_on": "2026-11-16",
  "id": "GE-MICRO-ELIGIBILITY",
  "official_url": "https://www.matsne.gov.ge/ka/document/view/1043717",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "| Georgia | Microbusiness is distinct from small business: qualifying independent natural persons with no hired labour and annual gross income not above GEL 30000 can have micro status. Small-business status generally taxes qualifying Georgian-source receipts, excluding wages/excluded categories, at 1%;3% begins with the crossing month when gross income exceeds GEL 500000, with the specific GEL 700000 wine/agrotourism rule. Two consecutive excess years and other cancellation conditions are separate. Foreign-source exemption does not cover Georgian-source services just because a client is abroad. Sources: [TaxCode84–85 complete](https://www.matsne.gov.ge/ka/document/view/1043717). |",
    "line": 87
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/ge-code-native.txt",
  "source_sha256": "184c60e61357aa4c3c3d743479b8c032ae3b123a0e837f55d5432adb5111befa",
  "source_version_basis": "Native Code current28October2026."
}
```

### GE-MICRO-EXEMPTION

A micro-status individual has the stated income-tax exemption, under the actual eligibility and status rules.

```json
{
  "act_article_or_scope": "TaxCode86 whole",
  "actual_read_on": "2026-11-16",
  "id": "GE-MICRO-EXEMPTION",
  "official_url": "https://www.matsne.gov.ge/ka/document/view/1043717",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "| Georgia | Microbusiness is distinct from small business: qualifying independent natural persons with no hired labour and annual gross income not above GEL 30000 can have micro status. Small-business status generally taxes qualifying Georgian-source receipts, excluding wages/excluded categories, at 1%;3% begins with the crossing month when gross income exceeds GEL 500000, with the specific GEL 700000 wine/agrotourism rule. Two consecutive excess years and other cancellation conditions are separate. Foreign-source exemption does not cover Georgian-source services just because a client is abroad. Sources: [TaxCode84–85 complete](https://www.matsne.gov.ge/ka/document/view/1043717). |",
    "line": 87
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/ge-code-native.txt",
  "source_sha256": "184c60e61357aa4c3c3d743479b8c032ae3b123a0e837f55d5432adb5111befa",
  "source_version_basis": "Native Code current28October2026."
}
```

### GE-SMALL-ELIGIBILITY

Small status is for eligible entrepreneur natural persons; prohibited activities and separately excluded receipts depend on the actual delegated rules.

```json
{
  "act_article_or_scope": "TaxCode88 whole",
  "actual_read_on": "2026-11-16",
  "id": "GE-SMALL-ELIGIBILITY",
  "official_url": "https://www.matsne.gov.ge/ka/document/view/1043717",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "| Georgia | Microbusiness is distinct from small business: qualifying independent natural persons with no hired labour and annual gross income not above GEL 30000 can have micro status. Small-business status generally taxes qualifying Georgian-source receipts, excluding wages/excluded categories, at 1%;3% begins with the crossing month when gross income exceeds GEL 500000, with the specific GEL 700000 wine/agrotourism rule. Two consecutive excess years and other cancellation conditions are separate. Foreign-source exemption does not cover Georgian-source services just because a client is abroad. Sources: [TaxCode84–85 complete](https://www.matsne.gov.ge/ka/document/view/1043717). |",
    "line": 87
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/ge-code-native.txt",
  "source_sha256": "184c60e61357aa4c3c3d743479b8c032ae3b123a0e837f55d5432adb5111befa",
  "source_version_basis": "Native Code current28October2026; Government415prohibited-list instrument not yet personally recovered."
}
```

### GE-SMALL-CANCELLATION

Two consecutive excess years above500000ordinary/700000wine-and-agro threshold and specified other events can cancel status with their own timing.

```json
{
  "act_article_or_scope": "TaxCode89 whole",
  "actual_read_on": "2026-11-16",
  "id": "GE-SMALL-CANCELLATION",
  "official_url": "https://www.matsne.gov.ge/ka/document/view/1043717",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "| Georgia | Microbusiness is distinct from small business: qualifying independent natural persons with no hired labour and annual gross income not above GEL 30000 can have micro status. Small-business status generally taxes qualifying Georgian-source receipts, excluding wages/excluded categories, at 1%;3% begins with the crossing month when gross income exceeds GEL 500000, with the specific GEL 700000 wine/agrotourism rule. Two consecutive excess years and other cancellation conditions are separate. Foreign-source exemption does not cover Georgian-source services just because a client is abroad. Sources: [TaxCode84–85 complete](https://www.matsne.gov.ge/ka/document/view/1043717). |",
    "line": 87
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/ge-code-native.txt",
  "source_sha256": "184c60e61357aa4c3c3d743479b8c032ae3b123a0e837f55d5432adb5111befa",
  "source_version_basis": "Native Code current28October2026."
}
```

### GE-SMALL-RATES-BASE

Qualifying Georgian-source receipts excluding wages/excluded categories have1%rate; crossing500000or specified700000threshold changes to3%from start of crossing month through year end; it is not a net-profit tax.

```json
{
  "act_article_or_scope": "TaxCode90 all paragraphs",
  "actual_read_on": "2026-11-16",
  "id": "GE-SMALL-RATES-BASE",
  "official_url": "https://www.matsne.gov.ge/ka/document/view/1043717",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "| Georgia | Microbusiness is distinct from small business: qualifying independent natural persons with no hired labour and annual gross income not above GEL 30000 can have micro status. Small-business status generally taxes qualifying Georgian-source receipts, excluding wages/excluded categories, at 1%;3% begins with the crossing month when gross income exceeds GEL 500000, with the specific GEL 700000 wine/agrotourism rule. Two consecutive excess years and other cancellation conditions are separate. Foreign-source exemption does not cover Georgian-source services just because a client is abroad. Sources: [TaxCode84–85 complete](https://www.matsne.gov.ge/ka/document/view/1043717). |",
    "line": 87
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/ge-code-native.txt",
  "source_sha256": "184c60e61357aa4c3c3d743479b8c032ae3b123a0e837f55d5432adb5111befa",
  "source_version_basis": "Native Code current28October2026."
}
```

### PY-IRP-CATEGORIES

IRP covers Paraguayan-source individual capital and personal-service income under separate base/rate rules.

```json
{
  "act_article_or_scope": "Law6380 Art47 whole",
  "actual_read_on": "2026-11-16",
  "id": "PY-IRP-CATEGORIES",
  "official_url": "https://www.dnit.gov.py/en/web/portal-institucional/w/ley-n-6380-19",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "| Paraguay | Law 6380 covers resident individuals' Paraguayan-source income; local activity and specified services abroad to IRE/IRP taxpayers matter. Personal-service IRP has the gross-income scope exceeding G 80000000 and progressive 8%,9%,10% net-income bands at G 50000000 and G 150000000, subject to the statutory base/expense rules. “Flat 10%” and universal foreign-client 0 are incomplete. Sources: [Law6380 Art49 whole](https://www.dnit.gov.py/en/web/portal-institucional/w/ley-n-6380-19). |",
    "line": 88
  },
  "short_exact_native_quotes": [
    "Artículo 47. Hecho Generador. Créase un impuesto anual que gravará las rentas obtenidas por las personas físicas y que se denominará Impuesto a la Renta"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/py-income-law.txt",
  "source_sha256": "219adce72caf5c420b22707bf818a2b9fcd3eb98d101a9c24a07c1020439196d",
  "source_version_basis": "Official native Law6380 body personally read16November2026; do not infer every2026amendment absent."
}
```

### PY-SOURCE

Domestic activity and specified services abroad to IRE/IRPtaxpayers create Paraguayan-source income; a foreign client does not by itself exempt local work.

```json
{
  "act_article_or_scope": "Law6380 Art48 whole",
  "actual_read_on": "2026-11-16",
  "id": "PY-SOURCE",
  "official_url": "https://www.dnit.gov.py/en/web/portal-institucional/w/ley-n-6380-19",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "| Paraguay | Law 6380 covers resident individuals' Paraguayan-source income; local activity and specified services abroad to IRE/IRP taxpayers matter. Personal-service IRP has the gross-income scope exceeding G 80000000 and progressive 8%,9%,10% net-income bands at G 50000000 and G 150000000, subject to the statutory base/expense rules. “Flat 10%” and universal foreign-client 0 are incomplete. Sources: [Law6380 Art49 whole](https://www.dnit.gov.py/en/web/portal-institucional/w/ley-n-6380-19). |",
    "line": 88
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/py-income-law.txt",
  "source_sha256": "219adce72caf5c420b22707bf818a2b9fcd3eb98d101a9c24a07c1020439196d",
  "source_version_basis": "Official native Law6380 body personally read."
}
```

### PY-RESIDENT-SCOPE

Resident natural persons and specified succession/other persons fall within the actual taxpayer provisions; no general visa-based residence conclusion follows.

```json
{
  "act_article_or_scope": "Law6380 Art49 whole",
  "actual_read_on": "2026-11-16",
  "id": "PY-RESIDENT-SCOPE",
  "official_url": "https://www.dnit.gov.py/en/web/portal-institucional/w/ley-n-6380-19",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "| Paraguay | Law 6380 covers resident individuals' Paraguayan-source income; local activity and specified services abroad to IRE/IRP taxpayers matter. Personal-service IRP has the gross-income scope exceeding G 80000000 and progressive 8%,9%,10% net-income bands at G 50000000 and G 150000000, subject to the statutory base/expense rules. “Flat 10%” and universal foreign-client 0 are incomplete. Sources: [Law6380 Art49 whole](https://www.dnit.gov.py/en/web/portal-institucional/w/ley-n-6380-19). |",
    "line": 88
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/py-income-law.txt",
  "source_sha256": "219adce72caf5c420b22707bf818a2b9fcd3eb98d101a9c24a07c1020439196d",
  "source_version_basis": "Official native Law6380 body personally read; separate migration/residence procedure not cleared."
}
```

### PY-SERVICE-80M

Personal-service IRP scope includes actual remuneration categories and annual gross-income threshold exceedingG80000000, with first-year and cessation rules.

```json
{
  "act_article_or_scope": "Law6380 Art62 whole",
  "actual_read_on": "2026-11-16",
  "id": "PY-SERVICE-80M",
  "official_url": "https://www.dnit.gov.py/en/web/portal-institucional/w/ley-n-6380-19",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "| Paraguay | Law 6380 covers resident individuals' Paraguayan-source income; local activity and specified services abroad to IRE/IRP taxpayers matter. Personal-service IRP has the gross-income scope exceeding G 80000000 and progressive 8%,9%,10% net-income bands at G 50000000 and G 150000000, subject to the statutory base/expense rules. “Flat 10%” and universal foreign-client 0 are incomplete. Sources: [Law6380 Art49 whole](https://www.dnit.gov.py/en/web/portal-institucional/w/ley-n-6380-19). |",
    "line": 88
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/py-income-law.txt",
  "source_sha256": "219adce72caf5c420b22707bf818a2b9fcd3eb98d101a9c24a07c1020439196d",
  "source_version_basis": "Official native Law6380 body personally read."
}
```

### PY-SERVICE-RATES

Personal-service progressive rates are8%/9%/10%on the statutory net-income bands atG50000000/G150000000; gross threshold and expense conditions remain separate.

```json
{
  "act_article_or_scope": "Law6380 Art69 complete table and paragraph",
  "actual_read_on": "2026-11-16",
  "id": "PY-SERVICE-RATES",
  "official_url": "https://www.dnit.gov.py/en/web/portal-institucional/w/ley-n-6380-19",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "| Paraguay | Law 6380 covers resident individuals' Paraguayan-source income; local activity and specified services abroad to IRE/IRP taxpayers matter. Personal-service IRP has the gross-income scope exceeding G 80000000 and progressive 8%,9%,10% net-income bands at G 50000000 and G 150000000, subject to the statutory base/expense rules. “Flat 10%” and universal foreign-client 0 are incomplete. Sources: [Law6380 Art49 whole](https://www.dnit.gov.py/en/web/portal-institucional/w/ley-n-6380-19). |",
    "line": 88
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/py-income-law.txt",
  "source_sha256": "219adce72caf5c420b22707bf818a2b9fcd3eb98d101a9c24a07c1020439196d",
  "source_version_basis": "Official native Law6380 body personally read."
}
```

### CN-DOMICILE

Domicile means habitual residence due to household registration, family or economic interests; passport/address labels alone do not resolve it.

```json
{
  "act_article_or_scope": "IITImplementingRegulation Art2 whole",
  "actual_read_on": "2026-11-16",
  "id": "CN-DOMICILE",
  "official_url": "https://tianjin.chinatax.gov.cn/11200000000/0300/030004/03000418/20260727143743677.shtml",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "**China.** The domestic test includes domicile or, without domicile, at least 183 days in the calendar tax year. Domicile means habitual residence because of household registration, family or economic interests. The nondomiciled foreign-paid foreign-income concession has a separate continuous-6-year/183-day rule, filing conditions and reset after a qualifying absence of more than 30 days. A Chinese passport plus a Dubai address does not establish nonresidence from China. [Native implementing regulation, Arts 2–5](https://tianjin.chinatax.gov.cn/11200000000/0300/030004/03000418/20260727143743677.shtml).",
    "line": 67
  },
  "short_exact_native_quotes": [
    "第二条 个人所得税法所称在中国境内有住所，是指因户籍、家庭、经济利益关系而在中国境内习惯性居住；所称从中国境内和境外取得的所得，分别是指来源于中国境内的所得和来源于中国境外的所得。"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/cn-iit-regulation.txt",
  "source_sha256": "3740e2ed900eed9a14935bb606d4beb4ef27967eb30837d12617a08acb2c27d5",
  "source_version_basis": "Current official tax-authority reproduction of2018StateCouncilDecree707, published2026; native operative/neighbour scope read."
}
```

### CN-LOCAL-SOURCE

Work performed in China and specified property/rights and payer income are Chinese-source regardless of payment location, unless otherwise provided.

```json
{
  "act_article_or_scope": "IITImplementingRegulation Art3 all5items",
  "actual_read_on": "2026-11-16",
  "id": "CN-LOCAL-SOURCE",
  "official_url": "https://tianjin.chinatax.gov.cn/11200000000/0300/030004/03000418/20260727143743677.shtml",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "**China.** The domestic test includes domicile or, without domicile, at least 183 days in the calendar tax year. Domicile means habitual residence because of household registration, family or economic interests. The nondomiciled foreign-paid foreign-income concession has a separate continuous-6-year/183-day rule, filing conditions and reset after a qualifying absence of more than 30 days. A Chinese passport plus a Dubai address does not establish nonresidence from China. [Native implementing regulation, Arts 2–5](https://tianjin.chinatax.gov.cn/11200000000/0300/030004/03000418/20260727143743677.shtml).",
    "line": 67
  },
  "short_exact_native_quotes": [
    "第三条 除国务院财政、税务主管部门另有规定外，下列所得，不论支付地点是否在中国境内，均为来源于中国境内的所得： （一）因任职、受雇、履约等在中国境内提供劳务取得的所得； （二）将财产出租给承租人在中国境内使用而取得的所得； （三）许可各种特许权在中国境内使用而取得的所得； （四）转让中国境内的不动产等财产或者在中国境内转让其他财产取得的所得； （五）从中国境内企业、事业单位、其他组织以及居民个人取得的利息、股息、红利所得。"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/cn-iit-regulation.txt",
  "source_sha256": "3740e2ed900eed9a14935bb606d4beb4ef27967eb30837d12617a08acb2c27d5",
  "source_version_basis": "Official native reproduction personally read."
}
```

### CN-NONDOMICILED-6YEAR

The nondomiciled foreign-paid foreign-income exemption has fewer-than6continuous183-day years, notification and more-than30day qualifying absence reset; not a universal passport exemption.

```json
{
  "act_article_or_scope": "IITImplementingRegulation Art4 whole",
  "actual_read_on": "2026-11-16",
  "id": "CN-NONDOMICILED-6YEAR",
  "official_url": "https://tianjin.chinatax.gov.cn/11200000000/0300/030004/03000418/20260727143743677.shtml",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "**China.** The domestic test includes domicile or, without domicile, at least 183 days in the calendar tax year. Domicile means habitual residence because of household registration, family or economic interests. The nondomiciled foreign-paid foreign-income concession has a separate continuous-6-year/183-day rule, filing conditions and reset after a qualifying absence of more than 30 days. A Chinese passport plus a Dubai address does not establish nonresidence from China. [Native implementing regulation, Arts 2–5](https://tianjin.chinatax.gov.cn/11200000000/0300/030004/03000418/20260727143743677.shtml).",
    "line": 67
  },
  "short_exact_native_quotes": [
    "第四条 在中国境内无住所的个人，在中国境内居住累计满183天的年度连续不满六年的，经向主管税务机关备案，其来源于中国境外且由境外单位或者个人支付的所得，免予缴纳个人所得税;在中国境内居住累计满183天的任一年度中有一次离境超过30天的，其在中国境内居住累计满183天的年度的连续年限重新起算。"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/cn-iit-regulation.txt",
  "source_sha256": "3740e2ed900eed9a14935bb606d4beb4ef27967eb30837d12617a08acb2c27d5",
  "source_version_basis": "Official native reproduction personally read."
}
```

### CN-90DAY-EMPLOYER

The nondomiciled no-more-than90day exemption concerns specified Chinese-source income paid by foreign employer and not borne by its China establishment; it is not domestic residence test.

```json
{
  "act_article_or_scope": "IITImplementingRegulation Art5 whole",
  "actual_read_on": "2026-11-16",
  "id": "CN-90DAY-EMPLOYER",
  "official_url": "https://tianjin.chinatax.gov.cn/11200000000/0300/030004/03000418/20260727143743677.shtml",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "**China.** The domestic test includes domicile or, without domicile, at least 183 days in the calendar tax year. Domicile means habitual residence because of household registration, family or economic interests. The nondomiciled foreign-paid foreign-income concession has a separate continuous-6-year/183-day rule, filing conditions and reset after a qualifying absence of more than 30 days. A Chinese passport plus a Dubai address does not establish nonresidence from China. [Native implementing regulation, Arts 2–5](https://tianjin.chinatax.gov.cn/11200000000/0300/030004/03000418/20260727143743677.shtml).",
    "line": 67
  },
  "short_exact_native_quotes": [
    "第五条 在中国境内无住所的个人，在一个纳税年度内在中国境内居住累计不超过90天的，其来源于中国境内的所得，由境外雇主支付并且不由该雇主在中国境内的机构、场所负担的部分，免予缴纳个人所得税。"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/cn-iit-regulation.txt",
  "source_sha256": "3740e2ed900eed9a14935bb606d4beb4ef27967eb30837d12617a08acb2c27d5",
  "source_version_basis": "Official native reproduction personally read; neighbour condition retained to prevent blanket exemption."
}
```

### MY-RESIDENCE-COMPLETE

Malaysia individual residence has182-day, linked-period/qualifiedabsence,90day/prior3of4, preceding3/followingyear, partial-day and citizen public-service routes.

```json
{
  "act_article_or_scope": "ITA1967 s7(1)(a)–(d),(1A),(1B),(2), printed50–52",
  "actual_read_on": "2026-11-16",
  "id": "MY-RESIDENCE-COMPLETE",
  "official_url": "https://www.hasil.gov.my/wp-content/uploads/Income-Tax-Act-1967-online-version-as-at-1-January-2026.pdf",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "**Malaysia.** Section 7 uses 182 days, a linked-period route with specified temporary absences, a 90-day route with 3 qualifying years in the previous 4, and a preceding-3/following-year residence route. Partial days and the specified citizen public-service deeming rule also matter. MM2H's immigration stay requirement does not replace these tax tests. The authority-hosted Act is expressly an updated online text as at 1 January 2026, rather than an assertion that every later legislative change has been incorporated. [ITA 1967 s 7](https://www.hasil.gov.my/wp-content/uploads/Income-Tax-Act-1967-online-version-as-at-1-January-2026.pdf), printed 50–52.",
    "line": 61
  },
  "short_exact_native_quotes": [
    "Residence: individuals 7. (1) For the purposes of this Act, an individual is resident in Malaysia for the basis year for a particular year of"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/my-ita2026-section7-web-native.txt",
  "source_sha256": "fd8fc39d59a35f13ddc3d434a6d3757f927a0f9ebf3f2e571cb3de020fce97af",
  "source_version_basis": "Authority-hosted updated online text as at1January2026; expressly not an authentic reprint. Actual web PDF read, CLI500recovery failure separately retained."
}
```

### JP-RESIDENCE

Japan domestic resident means domicile or continuous residence at least1year, rather than universal183days.

```json
{
  "act_article_or_scope": "NTA2010 resident-scope opening sentence",
  "actual_read_on": "2026-11-16",
  "id": "JP-RESIDENCE",
  "official_url": "https://www.nta.go.jp/taxes/shiraberu/taxanswer/shotoku/2010.htm",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "**Japan.** A domicile in Japan or a continuous residence of at least 1 year is a domestic resident route; staying below 183 days does not displace a domicile. Nonpermanent-resident status has a separate noncitizenship and 5-of-10-year condition, and limited foreign-source/remittance treatment rather than blanket exemption. [NTA No 2010](https://www.nta.go.jp/taxes/shiraberu/taxanswer/shotoku/2010.htm).",
    "line": 49
  },
  "short_exact_native_quotes": [
    "居住者とは、日本国内に住所があるかまたは現在まで引き続いて1年以上居所がある個人をいいます。"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/jp-residence.txt",
  "source_sha256": "2ed1ca97c5ccaa4a676c3448c687814a0fef988243e9fc849a16d783764d1f4e",
  "source_version_basis": "Native NTA current taxanswer as at1April2026, own actual operative body read."
}
```

### JP-NONPERMANENT

Nonpermanent-resident status requires noncitizenship and at most5years in preceding10; foreign-source scope depends on Japanese payment/remittance rather than blanket exemption.

```json
{
  "act_article_or_scope": "NTA2010 nonpermanent-resident definition and scope, both paragraphs",
  "actual_read_on": "2026-11-16",
  "id": "JP-NONPERMANENT",
  "official_url": "https://www.nta.go.jp/taxes/shiraberu/taxanswer/shotoku/2010.htm",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "**Japan.** A domicile in Japan or a continuous residence of at least 1 year is a domestic resident route; staying below 183 days does not displace a domicile. Nonpermanent-resident status has a separate noncitizenship and 5-of-10-year condition, and limited foreign-source/remittance treatment rather than blanket exemption. [NTA No 2010](https://www.nta.go.jp/taxes/shiraberu/taxanswer/shotoku/2010.htm).",
    "line": 49
  },
  "short_exact_native_quotes": [
    "非永住者とは、居住者のうち日本国籍がなく、かつ、過去10年以内の間に日本国内に住所または居所を有していた期間の合計が5年以下である個人をいいます。 非永住者は、所得税法に規定する国外で生じた所得（国外源泉所得）以外の所得と、国外源泉所得で日本国内において支払われ、または日本国内に送金されたものに対して課税されます。"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/jp-residence.txt",
  "source_sha256": "2ed1ca97c5ccaa4a676c3448c687814a0fef988243e9fc849a16d783764d1f4e",
  "source_version_basis": "Native NTA as at1April2026, actual scope and neighbours read."
}
```

### TH-CODE41

Local work/employer/property income is chargeable irrespective of payment location. Foreign-income/remittance rule and at-least180tax-year-day residence definition are distinct, subject to P161/P162 chronology.

```json
{
  "act_article_or_scope": "RevenueCode41 all3paragraphs and linked directive notes",
  "actual_read_on": "2026-11-16",
  "id": "TH-CODE41",
  "official_url": "https://www.rd.go.th/5937.html",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "**Thailand.** Revenue Code 41 treats at least 180 days in a tax year as residence for its foreign-income rule; that rule differs from taxation of local work, employer activities and property regardless of payment location. Apply the foreign-income and remittance chronology below. [Native Code 41](https://www.rd.go.th/5937.html).",
    "line": 63
  },
  "short_exact_native_quotes": [
    "มาตรา 41 ผู้มีเงินได้พึงประเมินตามมาตรา 40 ในปีภาษีที่ล่วงมาแล้วเนื่องจากหน้าที่งานหรือกิจการที่ทำในประเทศไทย หรือเนื่องจากกิจการของนายจ้างในประเทศไทย หรือเนื่องจากทรัพย์สินที่อยู่ในประเทศไทย"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/th-code38-64.txt",
  "source_sha256": "234ad68f03368d1e0bb1b5212f0698cb282980e5cd56f6730a3a64c6822f60f9",
  "source_version_basis": "Current published official native Code body; exact P161/P162 implementation separately read, not inferred solely from code wording."
}
```

### PT-RESIDENCE-TESTS

Portugal domestic residence includes more-than183days in any12monthperiod beginning/ending year OR qualifying habitual home, with crew/publicservice alternatives and overnight-day counting.

```json
{
  "act_article_or_scope": "CIRS16(1)–(2) complete",
  "actual_read_on": "2026-11-16",
  "id": "PT-RESIDENCE-TESTS",
  "official_url": "https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/cirs_rep/Pages/irs16.aspx",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "**Portugal.** CIRS 16 includes more than 183 days in any 12-month period beginning or ending in the year, or a home in circumstances indicating an intention to maintain and occupy it as habitual residence. A counted day includes an overnight stay. Arrival/departure can create a partial resident period, but the prior-year, departure-year and following-year provisions can restore whole-year residence. [CIRS 16](https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/cirs_rep/Pages/irs16.aspx).",
    "line": 45
  },
  "short_exact_native_quotes": [
    "1 - São residentes em território português as pessoas que, no ano a que respeitam os rendimentos: a) Hajam nele permanecido mais de 183 dias,"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/res-pt-residence.txt",
  "source_sha256": "7a007399c68a2e0ea1477e795806a4699068352c3851d777a2ae904b73564c21",
  "source_version_basis": "Actual authority consolidation retained14November2026, personally read16November2026."
}
```

### PT-RESIDENCE-START-END

Partial residence start/end follows first/last qualifying stay with prior-year and14/16wholeyear exceptions; test individual members separately.

```json
{
  "act_article_or_scope": "CIRS16(3)–(5)",
  "actual_read_on": "2026-11-16",
  "id": "PT-RESIDENCE-START-END",
  "official_url": "https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/cirs_rep/Pages/irs16.aspx",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "**Portugal.** CIRS 16 includes more than 183 days in any 12-month period beginning or ending in the year, or a home in circumstances indicating an intention to maintain and occupy it as habitual residence. A counted day includes an overnight stay. Arrival/departure can create a partial resident period, but the prior-year, departure-year and following-year provisions can restore whole-year residence. [CIRS 16](https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/cirs_rep/Pages/irs16.aspx).",
    "line": 45
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/res-pt-residence.txt",
  "source_sha256": "7a007399c68a2e0ea1477e795806a4699068352c3851d777a2ae904b73564c21",
  "source_version_basis": "Authority consolidation retained14November2026; personally read16November2026."
}
```

### PT-CITIZEN-LOWTAX-RESIDENCE

Portuguese-citizen move to listed low-tax jurisdiction has departure-year plus4year residence rule, reasonable-ground proof exception and cessation on qualifying different-jurisdiction residence.

```json
{
  "act_article_or_scope": "CIRS16(6)–(7)",
  "actual_read_on": "2026-11-16",
  "id": "PT-CITIZEN-LOWTAX-RESIDENCE",
  "official_url": "https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/cirs_rep/Pages/irs16.aspx",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "**Portugal.** CIRS 16 includes more than 183 days in any 12-month period beginning or ending in the year, or a home in circumstances indicating an intention to maintain and occupy it as habitual residence. A counted day includes an overnight stay. Arrival/departure can create a partial resident period, but the prior-year, departure-year and following-year provisions can restore whole-year residence. [CIRS 16](https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/cirs_rep/Pages/irs16.aspx).",
    "line": 45
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/res-pt-residence.txt",
  "source_sha256": "7a007399c68a2e0ea1477e795806a4699068352c3851d777a2ae904b73564c21",
  "source_version_basis": "Authority current consolidation personally read; applicable list must be checked in the actual case."
}
```

### PT-WHOLEYEAR-RESTORE

Whole departure-year residence can follow more-than183days plus subsequent otherwise taxable income, subject to foreign-tax/EU-EEA cooperation or60%comparison exception; following-year return can also restore whole-year residence.

```json
{
  "act_article_or_scope": "CIRS16(14)–(16)",
  "actual_read_on": "2026-11-16",
  "id": "PT-WHOLEYEAR-RESTORE",
  "official_url": "https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/cirs_rep/Pages/irs16.aspx",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "**Portugal.** CIRS 16 includes more than 183 days in any 12-month period beginning or ending in the year, or a home in circumstances indicating an intention to maintain and occupy it as habitual residence. A counted day includes an overnight stay. Arrival/departure can create a partial resident period, but the prior-year, departure-year and following-year provisions can restore whole-year residence. [CIRS 16](https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/cirs_rep/Pages/irs16.aspx).",
    "line": 45
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/res-pt-residence.txt",
  "source_sha256": "7a007399c68a2e0ea1477e795806a4699068352c3851d777a2ae904b73564c21",
  "source_version_basis": "Authority consolidation personally read; all exception limbs quoted."
}
```

### PT-NHR-TRANSITION-COMPLETE

NHR repeal preserves specified existing/2023/2024transitional applicants and household cases, actual date/document/registration gates and remaining-period rules.

```json
{
  "act_article_or_scope": "EmbeddedLaw82/2023 Art236(3)–(5), all protected categories and registration",
  "actual_read_on": "2026-11-16",
  "id": "PT-NHR-TRANSITION-COMPLETE",
  "official_url": "https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/cirs_rep/Pages/irs16.aspx",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "Portugal's temporary-stay and residence-visa routes for foreign remote work are distinct. The remote-work funding test is four times the applicable continental minimum wage, averaged over the preceding 3 months. With the 2026 continental minimum of EUR 920, the derived income amount is EUR 3680 monthly. Distinguish either visa from the conditional 2-year residence permit, renewable for 3 years. Portuguese citizens moving to a listed low-tax jurisdiction also need CIRS Art 16(6)–(7): residence can continue for the departure year and 4 further years, subject to the stated reasonable-ground and different-jurisdiction exceptions. Repeal of NHR does not erase protected existing or transitional cases. IFICI requires its own qualifying activities, prior 5-year nonresidence and registration conditions; its 20% net employment/self-employment treatment for 10 consecutive years is not a D8 entitlement. Sources: [RegulatoryDecree4/2022 inserted31-A(1)](https://files.dre.pt/1s/2022/09/19000/0002800097.pdf); [DecreeLaw139/2025 Arts2–3](https://files.diariodarepublica.pt/1s/2025/12/24900/0001400016.pdf); [AIMA Notes](https://aima.gov.pt/pt/trabalhar/autorizacao-de-residencia-para-o-exercicio-de-atividade-profissional-prestada-de-forma-remota-com-visto-de-residencia-para-o-exe); [CIRS16(6)–(7)](https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/cirs_rep/Pages/irs16.aspx); [EBF58A(1)](https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/bf_rep/Pages/ebf58a.aspx).",
    "line": 94
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/res-pt-residence.txt",
  "source_sha256": "7a007399c68a2e0ea1477e795806a4699068352c3851d777a2ae904b73564c21",
  "source_version_basis": "Authority embedded transitional text, own complete operative and neighbouring read."
}
```

### PT-IFICI-ELIGIBLE

IFICI requires becoming domestic resident, no residence in preceding5years and actual listed qualifying teaching/research/investment/highskill/entity/RD/startup/regional activity; a nomad visa alone is insufficient.

```json
{
  "act_article_or_scope": "EBF58A(1), all activity classes",
  "actual_read_on": "2026-11-16",
  "id": "PT-IFICI-ELIGIBLE",
  "official_url": "https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/bf_rep/Pages/ebf58a.aspx",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "Portugal's temporary-stay and residence-visa routes for foreign remote work are distinct. The remote-work funding test is four times the applicable continental minimum wage, averaged over the preceding 3 months. With the 2026 continental minimum of EUR 920, the derived income amount is EUR 3680 monthly. Distinguish either visa from the conditional 2-year residence permit, renewable for 3 years. Portuguese citizens moving to a listed low-tax jurisdiction also need CIRS Art 16(6)–(7): residence can continue for the departure year and 4 further years, subject to the stated reasonable-ground and different-jurisdiction exceptions. Repeal of NHR does not erase protected existing or transitional cases. IFICI requires its own qualifying activities, prior 5-year nonresidence and registration conditions; its 20% net employment/self-employment treatment for 10 consecutive years is not a D8 entitlement. Sources: [RegulatoryDecree4/2022 inserted31-A(1)](https://files.dre.pt/1s/2022/09/19000/0002800097.pdf); [DecreeLaw139/2025 Arts2–3](https://files.diariodarepublica.pt/1s/2025/12/24900/0001400016.pdf); [AIMA Notes](https://aima.gov.pt/pt/trabalhar/autorizacao-de-residencia-para-o-exercicio-de-atividade-profissional-prestada-de-forma-remota-com-visto-de-residencia-para-o-exe); [CIRS16(6)–(7)](https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/cirs_rep/Pages/irs16.aspx); [EBF58A(1)](https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/bf_rep/Pages/ebf58a.aspx).",
    "line": 94
  },
  "short_exact_native_quotes": [
    "1 - Beneficiam do regime de incentivo fiscal à investigação científica e inovação os sujeitos passivos que, tornando-se fiscalmente residentes nos termos dos n.os 1"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/res-pt-ifici.txt",
  "source_sha256": "636756b1f5f291c546c35896ffb7915cd1c378b7c64f61c8994752d3b9a468a4",
  "source_version_basis": "Authority current consolidation personally read; implementing-registration instrument not yet personally read."
}
```

### PT-IFICI-RATE-PERIOD

20%special rate concerns netA/Bqualifying income for10consecutiveyears with optional aggregation, annual residence/activity and specified6monthtransition/remainder resumption conditions.

```json
{
  "act_article_or_scope": "EBF58A(2)–(5)",
  "actual_read_on": "2026-11-16",
  "id": "PT-IFICI-RATE-PERIOD",
  "official_url": "https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/bf_rep/Pages/ebf58a.aspx",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "Portugal's temporary-stay and residence-visa routes for foreign remote work are distinct. The remote-work funding test is four times the applicable continental minimum wage, averaged over the preceding 3 months. With the 2026 continental minimum of EUR 920, the derived income amount is EUR 3680 monthly. Distinguish either visa from the conditional 2-year residence permit, renewable for 3 years. Portuguese citizens moving to a listed low-tax jurisdiction also need CIRS Art 16(6)–(7): residence can continue for the departure year and 4 further years, subject to the stated reasonable-ground and different-jurisdiction exceptions. Repeal of NHR does not erase protected existing or transitional cases. IFICI requires its own qualifying activities, prior 5-year nonresidence and registration conditions; its 20% net employment/self-employment treatment for 10 consecutive years is not a D8 entitlement. Sources: [RegulatoryDecree4/2022 inserted31-A(1)](https://files.dre.pt/1s/2022/09/19000/0002800097.pdf); [DecreeLaw139/2025 Arts2–3](https://files.diariodarepublica.pt/1s/2025/12/24900/0001400016.pdf); [AIMA Notes](https://aima.gov.pt/pt/trabalhar/autorizacao-de-residencia-para-o-exercicio-de-atividade-profissional-prestada-de-forma-remota-com-visto-de-residencia-para-o-exe); [CIRS16(6)–(7)](https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/cirs_rep/Pages/irs16.aspx); [EBF58A(1)](https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/bf_rep/Pages/ebf58a.aspx).",
    "line": 94
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/res-pt-ifici.txt",
  "source_sha256": "636756b1f5f291c546c35896ffb7915cd1c378b7c64f61c8994752d3b9a468a4",
  "source_version_basis": "Authority current consolidation personally read."
}
```

### PT-IFICI-REGISTRATION

Actual registration authorities, late registration remaining-period and interim rules are distinct; do not infer a filing deadline from the statutory cross-reference alone.

```json
{
  "act_article_or_scope": "EBF58A(6)–(9)",
  "actual_read_on": "2026-11-16",
  "id": "PT-IFICI-REGISTRATION",
  "official_url": "https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/bf_rep/Pages/ebf58a.aspx",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "Portugal's temporary-stay and residence-visa routes for foreign remote work are distinct. The remote-work funding test is four times the applicable continental minimum wage, averaged over the preceding 3 months. With the 2026 continental minimum of EUR 920, the derived income amount is EUR 3680 monthly. Distinguish either visa from the conditional 2-year residence permit, renewable for 3 years. Portuguese citizens moving to a listed low-tax jurisdiction also need CIRS Art 16(6)–(7): residence can continue for the departure year and 4 further years, subject to the stated reasonable-ground and different-jurisdiction exceptions. Repeal of NHR does not erase protected existing or transitional cases. IFICI requires its own qualifying activities, prior 5-year nonresidence and registration conditions; its 20% net employment/self-employment treatment for 10 consecutive years is not a D8 entitlement. Sources: [RegulatoryDecree4/2022 inserted31-A(1)](https://files.dre.pt/1s/2022/09/19000/0002800097.pdf); [DecreeLaw139/2025 Arts2–3](https://files.diariodarepublica.pt/1s/2025/12/24900/0001400016.pdf); [AIMA Notes](https://aima.gov.pt/pt/trabalhar/autorizacao-de-residencia-para-o-exercicio-de-atividade-profissional-prestada-de-forma-remota-com-visto-de-residencia-para-o-exe); [CIRS16(6)–(7)](https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/cirs_rep/Pages/irs16.aspx); [EBF58A(1)](https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/bf_rep/Pages/ebf58a.aspx).",
    "line": 94
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/res-pt-ifici.txt",
  "source_sha256": "636756b1f5f291c546c35896ffb7915cd1c378b7c64f61c8994752d3b9a468a4",
  "source_version_basis": "Authority consolidation personally read; final current portaria overlay remains pending."
}
```

### PT-IFICI-EXCLUSIONS

Prior/currentNHR,12Achoice, excluded qualifying job and once-only restrictions apply.

```json
{
  "act_article_or_scope": "EBF58A(10)–(12)",
  "actual_read_on": "2026-11-16",
  "id": "PT-IFICI-EXCLUSIONS",
  "official_url": "https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/bf_rep/Pages/ebf58a.aspx",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "Portugal's temporary-stay and residence-visa routes for foreign remote work are distinct. The remote-work funding test is four times the applicable continental minimum wage, averaged over the preceding 3 months. With the 2026 continental minimum of EUR 920, the derived income amount is EUR 3680 monthly. Distinguish either visa from the conditional 2-year residence permit, renewable for 3 years. Portuguese citizens moving to a listed low-tax jurisdiction also need CIRS Art 16(6)–(7): residence can continue for the departure year and 4 further years, subject to the stated reasonable-ground and different-jurisdiction exceptions. Repeal of NHR does not erase protected existing or transitional cases. IFICI requires its own qualifying activities, prior 5-year nonresidence and registration conditions; its 20% net employment/self-employment treatment for 10 consecutive years is not a D8 entitlement. Sources: [RegulatoryDecree4/2022 inserted31-A(1)](https://files.dre.pt/1s/2022/09/19000/0002800097.pdf); [DecreeLaw139/2025 Arts2–3](https://files.diariodarepublica.pt/1s/2025/12/24900/0001400016.pdf); [AIMA Notes](https://aima.gov.pt/pt/trabalhar/autorizacao-de-residencia-para-o-exercicio-de-atividade-profissional-prestada-de-forma-remota-com-visto-de-residencia-para-o-exe); [CIRS16(6)–(7)](https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/cirs_rep/Pages/irs16.aspx); [EBF58A(1)](https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/bf_rep/Pages/ebf58a.aspx).",
    "line": 94
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/res-pt-ifici.txt",
  "source_sha256": "636756b1f5f291c546c35896ffb7915cd1c378b7c64f61c8994752d3b9a468a4",
  "source_version_basis": "Authority consolidation personally read."
}
```

### DE-EXIT-EVENTS

Departure, gratuitous transfer outside unlimited-liability scope and loss/restriction of German share-gain taxing rights have specified event timing and market-value/basis consequences.

```json
{
  "act_article_or_scope": "AStG6(1), whole events/timing/basis paragraph",
  "actual_read_on": "2026-11-16",
  "id": "DE-EXIT-EVENTS",
  "official_url": "https://www.gesetze-im-internet.de/astg/__6.html",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "| Germany | AStG 6 covers specified loss/restriction of taxing rights, cessation of unlimited liability and gifts to persons outside it. Generally 7 years of unlimited liability in the preceding 12 years, linked to EStG 17's at-least 1% direct/indirect holding at any time in the preceding 5 years. Seven equal annual instalments require application, normally security, and have acceleration/reporting conditions; not an EU-only 5 year deferral. Return relief has separate 7 year/up-to 5 additional-year conditions. Sources: [AStG6(1)](https://www.gesetze-im-internet.de/astg/__6.html); [EStG17(1) full share/predecessor paragraph](https://www.gesetze-im-internet.de/estg/__17.html). |",
    "line": 130
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/res-de-exit.txt",
  "source_sha256": "00aa56e70325cf6d386d63350654b5b5baa1cf837ca2a97106b6158b5fa79ed0",
  "source_version_basis": "Official current native text retained14November, personally reread16November;21application notes separately read."
}
```

### DE-EXIT-LOOKBACK

Specified natural persons generally need7of12years unlimited liability, with donor/predecessor and overlap/re-entry rules.

```json
{
  "act_article_or_scope": "AStG6(2), full predecessor/overlap/re-entry conditions",
  "actual_read_on": "2026-11-16",
  "id": "DE-EXIT-LOOKBACK",
  "official_url": "https://www.gesetze-im-internet.de/astg/__6.html",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "| Germany | AStG 6 covers specified loss/restriction of taxing rights, cessation of unlimited liability and gifts to persons outside it. Generally 7 years of unlimited liability in the preceding 12 years, linked to EStG 17's at-least 1% direct/indirect holding at any time in the preceding 5 years. Seven equal annual instalments require application, normally security, and have acceleration/reporting conditions; not an EU-only 5 year deferral. Return relief has separate 7 year/up-to 5 additional-year conditions. Sources: [AStG6(1)](https://www.gesetze-im-internet.de/astg/__6.html); [EStG17(1) full share/predecessor paragraph](https://www.gesetze-im-internet.de/estg/__17.html). |",
    "line": 130
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/res-de-exit.txt",
  "source_sha256": "00aa56e70325cf6d386d63350654b5b5baa1cf837ca2a97106b6158b5fa79ed0",
  "source_version_basis": "Official current native source personally read."
}
```

### DE-EXIT-RETURN

Return relief has7year period, retained shares, distribution/return-of-capital quarter-value limit, restored taxing rights, death-transfer exception and application for up to5moreyears while return intent continues.

```json
{
  "act_article_or_scope": "AStG6(3), full paragraph",
  "actual_read_on": "2026-11-16",
  "id": "DE-EXIT-RETURN",
  "official_url": "https://www.gesetze-im-internet.de/astg/__6.html",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "| Germany | AStG 6 covers specified loss/restriction of taxing rights, cessation of unlimited liability and gifts to persons outside it. Generally 7 years of unlimited liability in the preceding 12 years, linked to EStG 17's at-least 1% direct/indirect holding at any time in the preceding 5 years. Seven equal annual instalments require application, normally security, and have acceleration/reporting conditions; not an EU-only 5 year deferral. Return relief has separate 7 year/up-to 5 additional-year conditions. Sources: [AStG6(1)](https://www.gesetze-im-internet.de/astg/__6.html); [EStG17(1) full share/predecessor paragraph](https://www.gesetze-im-internet.de/estg/__17.html). |",
    "line": 130
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/res-de-exit.txt",
  "source_sha256": "00aa56e70325cf6d386d63350654b5b5baa1cf837ca2a97106b6158b5fa79ed0",
  "source_version_basis": "Official current native text personally read."
}
```

### DE-EXIT-INSTALMENTS

Application for7equal annual instalments generally needs security, first1month then31July dates, no instalment interest, actual acceleration events and special return-intent deferral/interest conditions.

```json
{
  "act_article_or_scope": "AStG6(4), full paragraph and all acceleration conditions",
  "actual_read_on": "2026-11-16",
  "id": "DE-EXIT-INSTALMENTS",
  "official_url": "https://www.gesetze-im-internet.de/astg/__6.html",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "| Germany | AStG 6 covers specified loss/restriction of taxing rights, cessation of unlimited liability and gifts to persons outside it. Generally 7 years of unlimited liability in the preceding 12 years, linked to EStG 17's at-least 1% direct/indirect holding at any time in the preceding 5 years. Seven equal annual instalments require application, normally security, and have acceleration/reporting conditions; not an EU-only 5 year deferral. Return relief has separate 7 year/up-to 5 additional-year conditions. Sources: [AStG6(1)](https://www.gesetze-im-internet.de/astg/__6.html); [EStG17(1) full share/predecessor paragraph](https://www.gesetze-im-internet.de/estg/__17.html). |",
    "line": 130
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/res-de-exit.txt",
  "source_sha256": "00aa56e70325cf6d386d63350654b5b5baa1cf837ca2a97106b6158b5fa79ed0",
  "source_version_basis": "Official current native source personally read."
}
```

### DE-EXIT-REPORTING

Covered events reported within1month; annual31July address/continuedownership report and electronic/hardship exceptions apply.

```json
{
  "act_article_or_scope": "AStG6(5), full electronic/reporting and hardship conditions",
  "actual_read_on": "2026-11-16",
  "id": "DE-EXIT-REPORTING",
  "official_url": "https://www.gesetze-im-internet.de/astg/__6.html",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "| Germany | AStG 6 covers specified loss/restriction of taxing rights, cessation of unlimited liability and gifts to persons outside it. Generally 7 years of unlimited liability in the preceding 12 years, linked to EStG 17's at-least 1% direct/indirect holding at any time in the preceding 5 years. Seven equal annual instalments require application, normally security, and have acceleration/reporting conditions; not an EU-only 5 year deferral. Return relief has separate 7 year/up-to 5 additional-year conditions. Sources: [AStG6(1)](https://www.gesetze-im-internet.de/astg/__6.html); [EStG17(1) full share/predecessor paragraph](https://www.gesetze-im-internet.de/estg/__17.html). |",
    "line": 130
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/res-de-exit.txt",
  "source_sha256": "00aa56e70325cf6d386d63350654b5b5baa1cf837ca2a97106b6158b5fa79ed0",
  "source_version_basis": "Official current native source personally read."
}
```

### DE-EXIT-SHARE-1PERCENT

Linked share gate is at least1%direct/indirect at any time in preceding5years, with predecessor and instrument definitions; not morethan1%held5fullyears.

```json
{
  "act_article_or_scope": "EStG17(1) full share/predecessor paragraph",
  "actual_read_on": "2026-11-16",
  "id": "DE-EXIT-SHARE-1PERCENT",
  "official_url": "https://www.gesetze-im-internet.de/estg/__17.html",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "| Germany | AStG 6 covers specified loss/restriction of taxing rights, cessation of unlimited liability and gifts to persons outside it. Generally 7 years of unlimited liability in the preceding 12 years, linked to EStG 17's at-least 1% direct/indirect holding at any time in the preceding 5 years. Seven equal annual instalments require application, normally security, and have acceleration/reporting conditions; not an EU-only 5 year deferral. Return relief has separate 7 year/up-to 5 additional-year conditions. Sources: [AStG6(1)](https://www.gesetze-im-internet.de/astg/__6.html); [EStG17(1) full share/predecessor paragraph](https://www.gesetze-im-internet.de/estg/__17.html). |",
    "line": 130
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/res-de-share.txt",
  "source_sha256": "b4183f968a36f57079bf46b2ca49e0f336b0a2736724c8b12f94b7e26c179f19",
  "source_version_basis": "Official current native source personally read; full17and neighbour application pointer read."
}
```

### CN-RESIDENCE-YEAR

Domicile OR nondomiciled183calendar-year-day rule determines resident status and resident/nonresident worldwide/source scope; year1January–31December.

```json
{
  "act_article_or_scope": "IITLaw Art1 all3paragraphs",
  "actual_read_on": "2026-11-16",
  "id": "CN-RESIDENCE-YEAR",
  "official_url": "https://tianjin.chinatax.gov.cn/11200000000/0300/030004/03000418/20260727143202317.shtml",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "**China.** The domestic test includes domicile or, without domicile, at least 183 days in the calendar tax year. Domicile means habitual residence because of household registration, family or economic interests. The nondomiciled foreign-paid foreign-income concession has a separate continuous-6-year/183-day rule, filing conditions and reset after a qualifying absence of more than 30 days. A Chinese passport plus a Dubai address does not establish nonresidence from China. [Native implementing regulation, Arts 2–5](https://tianjin.chinatax.gov.cn/11200000000/0300/030004/03000418/20260727143743677.shtml).",
    "line": 67
  },
  "short_exact_native_quotes": [
    "第一条 在中国境内有住所，或者无住所而一个纳税年度内在中国境内居住累计满一百八十三天的个人，为居民个人。居民个人从中国境内和境外取得的所得，依照本法规定缴纳个人所得税。 在中国境内无住所又不居住，或者无住所而一个纳税年度内在中国境内居住累计不满一百八十三天的个人，为非居民个人。非居民个人从中国境内取得的所得，依照本法规定缴纳个人所得税。 纳税年度，自公历一月一日起至十二月三十一日止。"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/cn-iit-law.txt",
  "source_sha256": "83e462d972eec48da60c6111c7901f3e64c7d054290673e3a108a1b0ace71cf0",
  "source_version_basis": "Official native law reproduction marked全文有效; actual full131line page personally read16November2026, retainedHTTP200body."
}
```

### US-SPT-GATES

Calendar-year raw SPT requires31current days AND183weighted current/prior1/3/secondprior1/6days; examples assume all days count and no separate status/exception overrides.

```json
{
  "act_article_or_scope": "IRS SPT opening actual test and all weights",
  "actual_read_on": "2026-11-16",
  "id": "US-SPT-GATES",
  "official_url": "https://www.irs.gov/individuals/international-taxpayers/substantial-presence-test",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "**United States.** A noncitizen's raw substantial-presence test requires at least 31 current-year days and at least 183 weighted days: all current-year days + one-third of the preceding year's days + one-sixth of the second preceding year's days. Apply the statutory excluded-day classes first, and consider the closer-connection exception, green-card test and applicable treaty separately. Form 8843 and Form 8840 have distinct purposes and conditions. The closer-connection exception generally requires fewer than 183 actual current-year days, a foreign tax home throughout the year, closer foreign connections and no disqualifying permanent-resident steps; the special two-foreign-country path has further conditions. [IRS presence test](https://www.irs.gov/individuals/international-taxpayers/substantial-presence-test); [closer connection](https://www.irs.gov/individuals/international-taxpayers/closer-connection-exception-to-the-substantial-presence-test).",
    "line": 39
  },
  "short_exact_native_quotes": [
    "You will be considered a United States resident for tax purposes if you meet the substantial presence test for the calendar year. To meet this"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/res-us-spt.txt",
  "source_sha256": "77b2dc5bedde2f1c7a0f0bed793dbc67fc106bd99bbe45921af2395702020ad0",
  "source_version_basis": "Official page last updated14March2026, retained14November2026, personally read16November2026."
}
```

### US-SPT-EXCLUDED-DAYS

Any part of day generally counts for SPT, subject to Canadian/Mexican commuting, under24htransit, foreign-vessel crew, arisingmedical condition and exemptindividual rules; source defines USterritorial scope.

```json
{
  "act_article_or_scope": "Days of presence, all5exclusion categories and territorial scope",
  "actual_read_on": "2026-11-16",
  "id": "US-SPT-EXCLUDED-DAYS",
  "official_url": "https://www.irs.gov/individuals/international-taxpayers/substantial-presence-test",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "**United States.** A noncitizen's raw substantial-presence test requires at least 31 current-year days and at least 183 weighted days: all current-year days + one-third of the preceding year's days + one-sixth of the second preceding year's days. Apply the statutory excluded-day classes first, and consider the closer-connection exception, green-card test and applicable treaty separately. Form 8843 and Form 8840 have distinct purposes and conditions. The closer-connection exception generally requires fewer than 183 actual current-year days, a foreign tax home throughout the year, closer foreign connections and no disqualifying permanent-resident steps; the special two-foreign-country path has further conditions. [IRS presence test](https://www.irs.gov/individuals/international-taxpayers/substantial-presence-test); [closer connection](https://www.irs.gov/individuals/international-taxpayers/closer-connection-exception-to-the-substantial-presence-test).",
    "line": 39
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/res-us-spt.txt",
  "source_sha256": "77b2dc5bedde2f1c7a0f0bed793dbc67fc106bd99bbe45921af2395702020ad0",
  "source_version_basis": "Official page updated14March2026, own operative and neighbour read."
}
```

### US-SPT-8843

Exemptindividual is an excluded-day class not universal tax exemption;8843formalities and timelyfiling/clear-and-convincing relief matter for specified exclusions.

```json
{
  "act_article_or_scope": "Exempt individual all4categories/Form8843timeliness/hardship",
  "actual_read_on": "2026-11-16",
  "id": "US-SPT-8843",
  "official_url": "https://www.irs.gov/individuals/international-taxpayers/substantial-presence-test",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "**United States.** A noncitizen's raw substantial-presence test requires at least 31 current-year days and at least 183 weighted days: all current-year days + one-third of the preceding year's days + one-sixth of the second preceding year's days. Apply the statutory excluded-day classes first, and consider the closer-connection exception, green-card test and applicable treaty separately. Form 8843 and Form 8840 have distinct purposes and conditions. The closer-connection exception generally requires fewer than 183 actual current-year days, a foreign tax home throughout the year, closer foreign connections and no disqualifying permanent-resident steps; the special two-foreign-country path has further conditions. [IRS presence test](https://www.irs.gov/individuals/international-taxpayers/substantial-presence-test); [closer connection](https://www.irs.gov/individuals/international-taxpayers/closer-connection-exception-to-the-substantial-presence-test).",
    "line": 39
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/res-us-spt.txt",
  "source_sha256": "77b2dc5bedde2f1c7a0f0bed793dbc67fc106bd99bbe45921af2395702020ad0",
  "source_version_basis": "Official current guidance personally read."
}
```

### US-CLOSER-GENERAL

RawSPTcan yield nonresident exception only with actualcurrentdays<183, whole-year foreign taxhome/closerconnection and no disqualifying permanentresidentsteps, subject to two-country alternative and filing.

```json
{
  "act_article_or_scope": "General closer-connection prerequisites, all4items",
  "actual_read_on": "2026-11-16",
  "id": "US-CLOSER-GENERAL",
  "official_url": "https://www.irs.gov/individuals/international-taxpayers/closer-connection-exception-to-the-substantial-presence-test",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "**United States.** A noncitizen's raw substantial-presence test requires at least 31 current-year days and at least 183 weighted days: all current-year days + one-third of the preceding year's days + one-sixth of the second preceding year's days. Apply the statutory excluded-day classes first, and consider the closer-connection exception, green-card test and applicable treaty separately. Form 8843 and Form 8840 have distinct purposes and conditions. The closer-connection exception generally requires fewer than 183 actual current-year days, a foreign tax home throughout the year, closer foreign connections and no disqualifying permanent-resident steps; the special two-foreign-country path has further conditions. [IRS presence test](https://www.irs.gov/individuals/international-taxpayers/substantial-presence-test); [closer connection](https://www.irs.gov/individuals/international-taxpayers/closer-connection-exception-to-the-substantial-presence-test).",
    "line": 39
  },
  "short_exact_native_quotes": [
    "Even if you met the substantial presence test, you can still be treated as a nonresident of the United States for U.S. tax purposes, within"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/us-closer.txt",
  "source_sha256": "160d664319580a6ac2f62cbbaf4f6af3fda7c6c42486f415b6f44edd192cbc86",
  "source_version_basis": "Current official guidance actually read; personal case not determined."
}
```

### US-CLOSER-TWO-COUNTRIES

Two-country route requires full-year chained taxhomes/closerconnections plus resident taxation for full year or respective periods; more than2countries not within this published route.

```json
{
  "act_article_or_scope": "Two-foreign-country exception, all5conditions",
  "actual_read_on": "2026-11-16",
  "id": "US-CLOSER-TWO-COUNTRIES",
  "official_url": "https://www.irs.gov/individuals/international-taxpayers/closer-connection-exception-to-the-substantial-presence-test",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "**United States.** A noncitizen's raw substantial-presence test requires at least 31 current-year days and at least 183 weighted days: all current-year days + one-third of the preceding year's days + one-sixth of the second preceding year's days. Apply the statutory excluded-day classes first, and consider the closer-connection exception, green-card test and applicable treaty separately. Form 8843 and Form 8840 have distinct purposes and conditions. The closer-connection exception generally requires fewer than 183 actual current-year days, a foreign tax home throughout the year, closer foreign connections and no disqualifying permanent-resident steps; the special two-foreign-country path has further conditions. [IRS presence test](https://www.irs.gov/individuals/international-taxpayers/substantial-presence-test); [closer connection](https://www.irs.gov/individuals/international-taxpayers/closer-connection-exception-to-the-substantial-presence-test).",
    "line": 39
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/us-closer.txt",
  "source_sha256": "160d664319580a6ac2f62cbbaf4f6af3fda7c6c42486f415b6f44edd192cbc86",
  "source_version_basis": "Current official guidance personally read1400–1536retained and web operative scope."
}
```

### US-CLOSER-FACTS

Actual documents/home/family/belongings/social/business/licence/voting/charity facts matter; a qualifying permanent home is continuously available rather than only short visits.

```json
{
  "act_article_or_scope": "Closer-connection factors and continuous-availability note",
  "actual_read_on": "2026-11-16",
  "id": "US-CLOSER-FACTS",
  "official_url": "https://www.irs.gov/individuals/international-taxpayers/closer-connection-exception-to-the-substantial-presence-test",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "**United States.** A noncitizen's raw substantial-presence test requires at least 31 current-year days and at least 183 weighted days: all current-year days + one-third of the preceding year's days + one-sixth of the second preceding year's days. Apply the statutory excluded-day classes first, and consider the closer-connection exception, green-card test and applicable treaty separately. Form 8843 and Form 8840 have distinct purposes and conditions. The closer-connection exception generally requires fewer than 183 actual current-year days, a foreign tax home throughout the year, closer foreign connections and no disqualifying permanent-resident steps; the special two-foreign-country path has further conditions. [IRS presence test](https://www.irs.gov/individuals/international-taxpayers/substantial-presence-test); [closer connection](https://www.irs.gov/individuals/international-taxpayers/closer-connection-exception-to-the-substantial-presence-test).",
    "line": 39
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/us-closer.txt",
  "source_sha256": "160d664319580a6ac2f62cbbaf4f6af3fda7c6c42486f415b6f44edd192cbc86",
  "source_version_basis": "Current official guidance personally read."
}
```

### US-CLOSER-8840

8840has distinct filing role; late filing can deny closer-connection exception absent clear-and-convincing reasonable-compliance proof.

```json
{
  "act_article_or_scope": "Claim/Form8840 and timely-filing exception",
  "actual_read_on": "2026-11-16",
  "id": "US-CLOSER-8840",
  "official_url": "https://www.irs.gov/individuals/international-taxpayers/closer-connection-exception-to-the-substantial-presence-test",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "**United States.** A noncitizen's raw substantial-presence test requires at least 31 current-year days and at least 183 weighted days: all current-year days + one-third of the preceding year's days + one-sixth of the second preceding year's days. Apply the statutory excluded-day classes first, and consider the closer-connection exception, green-card test and applicable treaty separately. Form 8843 and Form 8840 have distinct purposes and conditions. The closer-connection exception generally requires fewer than 183 actual current-year days, a foreign tax home throughout the year, closer foreign connections and no disqualifying permanent-resident steps; the special two-foreign-country path has further conditions. [IRS presence test](https://www.irs.gov/individuals/international-taxpayers/substantial-presence-test); [closer connection](https://www.irs.gov/individuals/international-taxpayers/closer-connection-exception-to-the-substantial-presence-test).",
    "line": 39
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/us-closer.txt",
  "source_sha256": "160d664319580a6ac2f62cbbaf4f6af3fda7c6c42486f415b6f44edd192cbc86",
  "source_version_basis": "Current official guidance personally read."
}
```

### US-WORLDWIDE-CITIZENS

UScitizens/residentaliens generally remain subject to ordinary filing/payment rules and worldwide tax abroad; claiming special relief requires the relevant return, not automatic nontaxability.

```json
{
  "act_article_or_scope": "Worldwide-income/general filing paragraph and relief-return sentence",
  "actual_read_on": "2026-11-16",
  "id": "US-WORLDWIDE-CITIZENS",
  "official_url": "https://www.irs.gov/individuals/international-taxpayers/us-citizens-and-resident-aliens-abroad",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "US citizens generally remain within worldwide-income taxation abroad; return filing depends on the applicable filing thresholds and special duties, not whether tax is ultimately payable. The FEIE is conditional relief for qualifying foreign earned income, not all business profits, investment returns or self-employment tax. For 2026 the maximum is USD 132900 for a fully qualifying year; tax home/foreign abode, bona fide residence or physical-presence conditions, excluded-income credits and tax-rate stacking matter. Bona fide residence is not the 330-full-day test: the latter is a separate physical-presence test over 12 consecutive months. Sources: [Worldwide-income/general filing paragraph and relief-return sentence](https://www.irs.gov/individuals/international-taxpayers/us-citizens-and-resident-aliens-abroad); [2026instructions opening maximum](https://www.irs.gov/instructions/i2555); [Other rules](https://www.irs.gov/individuals/international-taxpayers/foreign-earned-income-exclusion).",
    "line": 110
  },
  "short_exact_native_quotes": [
    "If you are a U.S. citizen or resident alien, the rules for filing income, estate, and gift tax returns and paying estimated tax are generally"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/res-us-citizen.txt",
  "source_sha256": "d8e6c4e4797bd6e095f9d0c05bcbe5b0b7e9f9de29b9dd54c2336dae7dcbe5d5",
  "source_version_basis": "Official current published guidance, actual operative scope personally read; specific filing threshold rules separate."
}
```

### US-FEIE-2026-LIMIT

Maximum2026FEIEis132900for a fully qualifying period and eligible foreign earned income; case inputs are assumptions, not eligibility proof.

```json
{
  "act_article_or_scope": "2026instructions opening maximum",
  "actual_read_on": "2026-11-16",
  "id": "US-FEIE-2026-LIMIT",
  "official_url": "https://www.irs.gov/instructions/i2555",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "US citizens generally remain within worldwide-income taxation abroad; return filing depends on the applicable filing thresholds and special duties, not whether tax is ultimately payable. The FEIE is conditional relief for qualifying foreign earned income, not all business profits, investment returns or self-employment tax. For 2026 the maximum is USD 132900 for a fully qualifying year; tax home/foreign abode, bona fide residence or physical-presence conditions, excluded-income credits and tax-rate stacking matter. Bona fide residence is not the 330-full-day test: the latter is a separate physical-presence test over 12 consecutive months. Sources: [Worldwide-income/general filing paragraph and relief-return sentence](https://www.irs.gov/individuals/international-taxpayers/us-citizens-and-resident-aliens-abroad); [2026instructions opening maximum](https://www.irs.gov/instructions/i2555); [Other rules](https://www.irs.gov/individuals/international-taxpayers/foreign-earned-income-exclusion).",
    "line": 110
  },
  "short_exact_native_quotes": [
    "For 2026, the maximum exclusion amount has increased to $132,900."
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/res-us-feie.txt",
  "source_sha256": "cd2b4a994c2f997f9a533666eafb8e4c18b3419ecf66d2f8da7b6275f8bebcf1",
  "source_version_basis": "Actual IRS2026instructions retained14November2026, personally read16November2026."
}
```

### US-FEIE-QUALIFICATION

Foreign taxhome AND bona-fide residence OR physicalpresence qualification apply; USabode and government-employment exclusions and special combat circumstances matter.

```json
{
  "act_article_or_scope": "Who Qualifies and whole taxhome/abode discussion, including combat exception",
  "actual_read_on": "2026-11-16",
  "id": "US-FEIE-QUALIFICATION",
  "official_url": "https://www.irs.gov/instructions/i2555",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "US citizens generally remain within worldwide-income taxation abroad; return filing depends on the applicable filing thresholds and special duties, not whether tax is ultimately payable. The FEIE is conditional relief for qualifying foreign earned income, not all business profits, investment returns or self-employment tax. For 2026 the maximum is USD 132900 for a fully qualifying year; tax home/foreign abode, bona fide residence or physical-presence conditions, excluded-income credits and tax-rate stacking matter. Bona fide residence is not the 330-full-day test: the latter is a separate physical-presence test over 12 consecutive months. Sources: [Worldwide-income/general filing paragraph and relief-return sentence](https://www.irs.gov/individuals/international-taxpayers/us-citizens-and-resident-aliens-abroad); [2026instructions opening maximum](https://www.irs.gov/instructions/i2555); [Other rules](https://www.irs.gov/individuals/international-taxpayers/foreign-earned-income-exclusion).",
    "line": 110
  },
  "short_exact_native_quotes": [
    "You may qualify for the foreign earned income exclusion and the housing exclusion or deduction"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/res-us-feie.txt",
  "source_sha256": "cd2b4a994c2f997f9a533666eafb8e4c18b3419ecf66d2f8da7b6275f8bebcf1",
  "source_version_basis": "Actual2026IRS instructions, all operative and neighbouring paragraphs personally read."
}
```

### US-FEIE-CREDIT-INTERACTION

Foreign income taxes allocated to excluded income cannot be credited/deducted again; partially excluded income requires allocation.

```json
{
  "act_article_or_scope": "Foreign tax credit or deduction paragraph",
  "actual_read_on": "2026-11-16",
  "id": "US-FEIE-CREDIT-INTERACTION",
  "official_url": "https://www.irs.gov/instructions/i2555",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "US citizens generally remain within worldwide-income taxation abroad; return filing depends on the applicable filing thresholds and special duties, not whether tax is ultimately payable. The FEIE is conditional relief for qualifying foreign earned income, not all business profits, investment returns or self-employment tax. For 2026 the maximum is USD 132900 for a fully qualifying year; tax home/foreign abode, bona fide residence or physical-presence conditions, excluded-income credits and tax-rate stacking matter. Bona fide residence is not the 330-full-day test: the latter is a separate physical-presence test over 12 consecutive months. Sources: [Worldwide-income/general filing paragraph and relief-return sentence](https://www.irs.gov/individuals/international-taxpayers/us-citizens-and-resident-aliens-abroad); [2026instructions opening maximum](https://www.irs.gov/instructions/i2555); [Other rules](https://www.irs.gov/individuals/international-taxpayers/foreign-earned-income-exclusion).",
    "line": 110
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/res-us-feie.txt",
  "source_sha256": "cd2b4a994c2f997f9a533666eafb8e4c18b3419ecf66d2f8da7b6275f8bebcf1",
  "source_version_basis": "Actual2026IRS instructions personally read."
}
```

### US-FEIE-STACKING

Remaining income is taxed at rates applicable without the exclusion; exclusion amount is not a tax saving or tax bill.

```json
{
  "act_article_or_scope": "Figuring Tax on Income Not Excluded whole paragraph",
  "actual_read_on": "2026-11-16",
  "id": "US-FEIE-STACKING",
  "official_url": "https://www.irs.gov/instructions/i2555",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "US citizens generally remain within worldwide-income taxation abroad; return filing depends on the applicable filing thresholds and special duties, not whether tax is ultimately payable. The FEIE is conditional relief for qualifying foreign earned income, not all business profits, investment returns or self-employment tax. For 2026 the maximum is USD 132900 for a fully qualifying year; tax home/foreign abode, bona fide residence or physical-presence conditions, excluded-income credits and tax-rate stacking matter. Bona fide residence is not the 330-full-day test: the latter is a separate physical-presence test over 12 consecutive months. Sources: [Worldwide-income/general filing paragraph and relief-return sentence](https://www.irs.gov/individuals/international-taxpayers/us-citizens-and-resident-aliens-abroad); [2026instructions opening maximum](https://www.irs.gov/instructions/i2555); [Other rules](https://www.irs.gov/individuals/international-taxpayers/foreign-earned-income-exclusion).",
    "line": 110
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/res-us-feie.txt",
  "source_sha256": "cd2b4a994c2f997f9a533666eafb8e4c18b3419ecf66d2f8da7b6275f8bebcf1",
  "source_version_basis": "Actual2026IRS instructions personally read."
}
```

### US-FEIE-BONA-FIDE

Bona-fide residence covers uninterrupted entire taxyear with citizen/residentalien treaty-national conditions and actual indefinite-stay intent; it is separate from330full-days test. Lines13a/13b deny bona-fide status after a foreign nonresidence statement where the foreign authority holds the person outside income-tax laws for nonresidence, or has not made an adverse determination of that nonresident status.

```json
{
  "act_article_or_scope": "Actual2026i2555 PartII BonaFideResidenceTest and Lines10/12a/12b/13a/13b, retained source403–415 plus neighbours389–419",
  "actual_read_on": "2026-11-16",
  "correction_own_read_on": "2026-11-16",
  "id": "US-FEIE-BONA-FIDE",
  "official_url": "https://www.irs.gov/instructions/i2555",
  "quote_mode": "Full assigned actual public-law operative clause, losslessly split into ordered contiguous native fragments <=25 words and <=240 characters; manually read operative scope and neighbours.",
  "section": {
    "actual_text": "US citizens generally remain within worldwide-income taxation abroad; return filing depends on the applicable filing thresholds and special duties, not whether tax is ultimately payable. The FEIE is conditional relief for qualifying foreign earned income, not all business profits, investment returns or self-employment tax. For 2026 the maximum is USD 132900 for a fully qualifying year; tax home/foreign abode, bona fide residence or physical-presence conditions, excluded-income credits and tax-rate stacking matter. Bona fide residence is not the 330-full-day test: the latter is a separate physical-presence test over 12 consecutive months. Sources: [Worldwide-income/general filing paragraph and relief-return sentence](https://www.irs.gov/individuals/international-taxpayers/us-citizens-and-resident-aliens-abroad); [2026instructions opening maximum](https://www.irs.gov/instructions/i2555); [Other rules](https://www.irs.gov/individuals/international-taxpayers/foreign-earned-income-exclusion).",
    "line": 110
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/res-us-feie.txt",
  "source_sha256": "cd2b4a994c2f997f9a533666eafb8e4c18b3419ecf66d2f8da7b6275f8bebcf1",
  "source_version_basis": "Actual2026IRS instructions personally read."
}
```

### US-FEIE-330DAYS

Physicalpresence route generally330fullforeign days within12consecutivemonths; full day is midnight24h; internationalwaters and special spousal resident election rules matter.

```json
{
  "act_article_or_scope": "Physical Presence Test all3paragraphs plus12monthperiod notes",
  "actual_read_on": "2026-11-16",
  "id": "US-FEIE-330DAYS",
  "official_url": "https://www.irs.gov/instructions/i2555",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "US citizens generally remain within worldwide-income taxation abroad; return filing depends on the applicable filing thresholds and special duties, not whether tax is ultimately payable. The FEIE is conditional relief for qualifying foreign earned income, not all business profits, investment returns or self-employment tax. For 2026 the maximum is USD 132900 for a fully qualifying year; tax home/foreign abode, bona fide residence or physical-presence conditions, excluded-income credits and tax-rate stacking matter. Bona fide residence is not the 330-full-day test: the latter is a separate physical-presence test over 12 consecutive months. Sources: [Worldwide-income/general filing paragraph and relief-return sentence](https://www.irs.gov/individuals/international-taxpayers/us-citizens-and-resident-aliens-abroad); [2026instructions opening maximum](https://www.irs.gov/instructions/i2555); [Other rules](https://www.irs.gov/individuals/international-taxpayers/foreign-earned-income-exclusion).",
    "line": 110
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/res-us-feie.txt",
  "source_sha256": "cd2b4a994c2f997f9a533666eafb8e4c18b3419ecf66d2f8da7b6275f8bebcf1",
  "source_version_basis": "Actual2026IRS instructions personally read."
}
```

### US-FEIE-INCOME-SCOPE

Only qualifying foreign personal-service compensation is earned income forFEIE; corporate distributions, pensions, investment income, USgovernment employment and specified timing/trust categories are excluded.

```json
{
  "act_article_or_scope": "Foreign Earned Income definition and excluded income types",
  "actual_read_on": "2026-11-16",
  "id": "US-FEIE-INCOME-SCOPE",
  "official_url": "https://www.irs.gov/instructions/i2555",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "US citizens generally remain within worldwide-income taxation abroad; return filing depends on the applicable filing thresholds and special duties, not whether tax is ultimately payable. The FEIE is conditional relief for qualifying foreign earned income, not all business profits, investment returns or self-employment tax. For 2026 the maximum is USD 132900 for a fully qualifying year; tax home/foreign abode, bona fide residence or physical-presence conditions, excluded-income credits and tax-rate stacking matter. Bona fide residence is not the 330-full-day test: the latter is a separate physical-presence test over 12 consecutive months. Sources: [Worldwide-income/general filing paragraph and relief-return sentence](https://www.irs.gov/individuals/international-taxpayers/us-citizens-and-resident-aliens-abroad); [2026instructions opening maximum](https://www.irs.gov/instructions/i2555); [Other rules](https://www.irs.gov/individuals/international-taxpayers/foreign-earned-income-exclusion).",
    "line": 110
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/res-us-feie.txt",
  "source_sha256": "cd2b4a994c2f997f9a533666eafb8e4c18b3419ecf66d2f8da7b6275f8bebcf1",
  "source_version_basis": "Actual2026IRS instructions personally read."
}
```

### US-FEIE-SELFEMPLOYMENT

FEIEcan apply to qualifying self-employment income but does not reduce self-employment tax; housing deduction differs from employee housing exclusion.

```json
{
  "act_article_or_scope": "Other rules, complete self-employment paragraph",
  "actual_read_on": "2026-11-16",
  "id": "US-FEIE-SELFEMPLOYMENT",
  "official_url": "https://www.irs.gov/individuals/international-taxpayers/foreign-earned-income-exclusion",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "US citizens generally remain within worldwide-income taxation abroad; return filing depends on the applicable filing thresholds and special duties, not whether tax is ultimately payable. The FEIE is conditional relief for qualifying foreign earned income, not all business profits, investment returns or self-employment tax. For 2026 the maximum is USD 132900 for a fully qualifying year; tax home/foreign abode, bona fide residence or physical-presence conditions, excluded-income credits and tax-rate stacking matter. Bona fide residence is not the 330-full-day test: the latter is a separate physical-presence test over 12 consecutive months. Sources: [Worldwide-income/general filing paragraph and relief-return sentence](https://www.irs.gov/individuals/international-taxpayers/us-citizens-and-resident-aliens-abroad); [2026instructions opening maximum](https://www.irs.gov/instructions/i2555); [Other rules](https://www.irs.gov/individuals/international-taxpayers/foreign-earned-income-exclusion).",
    "line": 110
  },
  "short_exact_native_quotes": [
    "Self-employment income: A qualifying individual may claim the foreign earned income exclusion on foreign earned self-employment income. The excluded amount will reduce your regular income"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/us-feie-landing.txt",
  "source_sha256": "c87cb36ad68324cbb7111e1ce29e85204f8c41ce858542e956d9448dab0e0f8d",
  "source_version_basis": "Actual official landing body97–150personally read16November2026; its stale historical maximums are not used for2026."
}
```

### US-LLC-DEFAULTS

Domestic2+members generally partnership unless corporate election;1member disregarded unless corporate election; employment/excise treatment separate.

```json
{
  "act_article_or_scope": "Opening complete LLC classification paragraph",
  "actual_read_on": "2026-11-16",
  "id": "US-LLC-DEFAULTS",
  "official_url": "https://www.irs.gov/businesses/small-businesses-self-employed/single-member-limited-liability-companies",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "**A: US-citizen digital nomad.** Test owner/entity classification, work source, foreign tax home and either FEIE residence/presence test, eligible FTC and social-insurance duties. Wyoming/Delaware LLC is a possible legal form, not a guaranteed solution. Mercury/Wise are original commercial examples, not verified bank recommendations. Sources: [Opening complete LLC classification paragraph](https://www.irs.gov/businesses/small-businesses-self-employed/single-member-limited-liability-companies); [Opening service source and treaty-exception paragraphs](https://www.irs.gov/individuals/international-taxpayers/source-of-income-personal-service-income); [Who Qualifies and whole taxhome/abode discussion](https://www.irs.gov/instructions/i2555).",
    "line": 151
  },
  "short_exact_native_quotes": [
    "A Limited Liability Company (LLC) is an entity created by state statute. Depending on elections made by the LLC and the number of members, the"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/us-method-6.txt",
  "source_sha256": "d37a0b74b30a86fda860d21d827d8d1cfa1105579333ee963536397cf152503c",
  "source_version_basis": "Official page last updated27July2026, retained14November, personally reread16November."
}
```

### US-LLC-OWNER-SE

Disregarded LLC activity flows to actualowner return; individual trade/business owner subject to ordinary net-earnings selfemployment rules; entity-owner division treatment differs.

```json
{
  "act_article_or_scope": "Owner of single-member LLC, all operative paragraphs",
  "actual_read_on": "2026-11-16",
  "id": "US-LLC-OWNER-SE",
  "official_url": "https://www.irs.gov/businesses/small-businesses-self-employed/single-member-limited-liability-companies",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "**A: US-citizen digital nomad.** Test owner/entity classification, work source, foreign tax home and either FEIE residence/presence test, eligible FTC and social-insurance duties. Wyoming/Delaware LLC is a possible legal form, not a guaranteed solution. Mercury/Wise are original commercial examples, not verified bank recommendations. Sources: [Opening complete LLC classification paragraph](https://www.irs.gov/businesses/small-businesses-self-employed/single-member-limited-liability-companies); [Opening service source and treaty-exception paragraphs](https://www.irs.gov/individuals/international-taxpayers/source-of-income-personal-service-income); [Who Qualifies and whole taxhome/abode discussion](https://www.irs.gov/instructions/i2555).",
    "line": 151
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/us-method-6.txt",
  "source_sha256": "d37a0b74b30a86fda860d21d827d8d1cfa1105579333ee963536397cf152503c",
  "source_version_basis": "Official published guidance updated27July2026, actual body read."
}
```

### US-SERVICES-SOURCE

Place of actual service generally controls USsource irrespective of contract/payment/payer; actual exceptions including applicable treaty must be established.

```json
{
  "act_article_or_scope": "Opening service source and treaty-exception paragraphs",
  "actual_read_on": "2026-11-16",
  "id": "US-SERVICES-SOURCE",
  "official_url": "https://www.irs.gov/individuals/international-taxpayers/source-of-income-personal-service-income",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "**A: US-citizen digital nomad.** Test owner/entity classification, work source, foreign tax home and either FEIE residence/presence test, eligible FTC and social-insurance duties. Wyoming/Delaware LLC is a possible legal form, not a guaranteed solution. Mercury/Wise are original commercial examples, not verified bank recommendations. Sources: [Opening complete LLC classification paragraph](https://www.irs.gov/businesses/small-businesses-self-employed/single-member-limited-liability-companies); [Opening service source and treaty-exception paragraphs](https://www.irs.gov/individuals/international-taxpayers/source-of-income-personal-service-income); [Who Qualifies and whole taxhome/abode discussion](https://www.irs.gov/instructions/i2555).",
    "line": 151
  },
  "short_exact_native_quotes": [
    "All wages and any other compensation for services performed in the United States (U.S.) are generally considered to be from sources in the U.S.. The"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/cb-source.txt",
  "source_sha256": "4be9483945e92d916e2da8c12234578a267d6a5d0e7ce65029bcee81c2a5787a",
  "source_version_basis": "Actual retained official guidance personally read; individual treaty not assumed."
}
```

### US-SERVICES-ALLOCATION

Mixed-location personal service requires accurate allocation, generally time-based except specified fringes and qualifying alternative bases.

```json
{
  "act_article_or_scope": "Allocation of personal service income, full operative paragraph",
  "actual_read_on": "2026-11-16",
  "id": "US-SERVICES-ALLOCATION",
  "official_url": "https://www.irs.gov/individuals/international-taxpayers/source-of-income-personal-service-income",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "**A: US-citizen digital nomad.** Test owner/entity classification, work source, foreign tax home and either FEIE residence/presence test, eligible FTC and social-insurance duties. Wyoming/Delaware LLC is a possible legal form, not a guaranteed solution. Mercury/Wise are original commercial examples, not verified bank recommendations. Sources: [Opening complete LLC classification paragraph](https://www.irs.gov/businesses/small-businesses-self-employed/single-member-limited-liability-companies); [Opening service source and treaty-exception paragraphs](https://www.irs.gov/individuals/international-taxpayers/source-of-income-personal-service-income); [Who Qualifies and whole taxhome/abode discussion](https://www.irs.gov/instructions/i2555).",
    "line": 151
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/cb-source.txt",
  "source_sha256": "4be9483945e92d916e2da8c12234578a267d6a5d0e7ce65029bcee81c2a5787a",
  "source_version_basis": "Official retained body personally read; no claim that timeallocation universally covers all fringe benefits."
}
```

### US-FBAR-LANDING

USpersonfinancialinterest/signatureauthorityforeignaccountsaggregateexceeding10000anytimeduringcalendar has published filing rule, subject to detailed instructions not yet fully read.

```json
{
  "act_article_or_scope": "Who Must File, complete paragraph",
  "actual_read_on": "2026-11-16",
  "id": "US-FBAR-LANDING",
  "official_url": "https://www.fincen.gov/report-foreign-bank-and-financial-accounts",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "FBAR is separate: the FinCEN landing rule covers US persons with financial interest or signature authority over foreign accounts exceeding USD 10000 in aggregate at any time during the calendar year, subject to the detailed rules/exceptions. Mercury or Wise names do not settle account location, filing status, eligibility, fees or a bank's acceptance of a customer. Sources: [Who Must File](https://www.fincen.gov/report-foreign-bank-and-financial-accounts).",
    "line": 116
  },
  "short_exact_native_quotes": [
    "A United States person that has a financial interest in or signature authority over foreign financial accounts must file an"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/fincen-fbar.txt",
  "source_sha256": "a3a4054b447246624913c479b6482ce616a29ce5c9d9773f0b1c396d05ce1ba8",
  "source_version_basis": "Actual full79line web landing read16November2026; HTTP200retained; full line-item instructions not yet read."
}
```

### AE-NO-PIT

The recovered official FAQ says UAE does not levy income tax on individuals; original5%PITfromJanuary2026is contradicted.

```json
{
  "act_article_or_scope": "Individual income-tax FAQ, question and answer",
  "actual_read_on": "2026-11-16",
  "id": "AE-NO-PIT",
  "official_url": "https://u.ae/en/Help/FAQs/finance-and-investment",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "The UAE does not levy the original purported 5% personal income tax from January 2026. Natural-person business activity has a separate corporate-tax scope where calendar-year business turnover exceeds AED 1 million; wages, Personal Investment Income and Real Estate Investment Income are excluded under the published conditions. This is not a tax on every individual's receipts. Free-zone incorporation and its separate qualifying-person/income rules cannot be replaced by a universal 9% + 5% calculation. The old >AED375000 condition concerns a separate taxable-income threshold: the FTA-hosted CD116/2022 text sets ordinary 0% treatment on the portion up to AED375000 and 9% on the excess, once per taxable person’s combined businesses, with anti-fragmentation conditions. It is expressly an unofficial English translation; native Arabic116 and complete current company-tax execution are not cleared here. [Actual decision Arts2–3](https://tax.gov.ae/Datafolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%20No.%20116%20of%202022%20-%20for%20publishing.pdf). [Government FAQ](https://u.ae/en/Help/FAQs/finance-and-investment); [FTA natural persons](https://www.tax.gov.ae/en/taxes/corporate.tax/corporate.tax.topics/basis.of.taxation.natural.person.aspx).",
    "line": 71
  },
  "short_exact_native_quotes": [
    "Does the UAE levy income tax on individuals? No, the UAE does not levy income tax on individuals."
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/res-uae-pit.txt",
  "source_sha256": "84484cc37aaad52ccdf56389a0ac561f328ae58d5b5130b908961db35b8e326f",
  "source_version_basis": "Official published FAQ retained14November2026, personally read16November2026; businessCTscope separate."
}
```

### AE-NATURAL-BUSINESS-CT

Naturalperson UAEbusiness/businessactivity AND calendar-year turnoverexceedingAED1million determine publishedCTscope; wage/personal-investment/real-estate-investment receipts excluded; not5%PITon allreceipts.

```json
{
  "act_article_or_scope": "Basis of Taxation Natural Person, all charge/nonregistration/exclusion paragraphs",
  "actual_read_on": "2026-11-16",
  "id": "AE-NATURAL-BUSINESS-CT",
  "official_url": "https://www.tax.gov.ae/en/taxes/corporate.tax/corporate.tax.topics/basis.of.taxation.natural.person.aspx",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "The UAE does not levy the original purported 5% personal income tax from January 2026. Natural-person business activity has a separate corporate-tax scope where calendar-year business turnover exceeds AED 1 million; wages, Personal Investment Income and Real Estate Investment Income are excluded under the published conditions. This is not a tax on every individual's receipts. Free-zone incorporation and its separate qualifying-person/income rules cannot be replaced by a universal 9% + 5% calculation. The old >AED375000 condition concerns a separate taxable-income threshold: the FTA-hosted CD116/2022 text sets ordinary 0% treatment on the portion up to AED375000 and 9% on the excess, once per taxable person’s combined businesses, with anti-fragmentation conditions. It is expressly an unofficial English translation; native Arabic116 and complete current company-tax execution are not cleared here. [Actual decision Arts2–3](https://tax.gov.ae/Datafolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%20No.%20116%20of%202022%20-%20for%20publishing.pdf). [Government FAQ](https://u.ae/en/Help/FAQs/finance-and-investment); [FTA natural persons](https://www.tax.gov.ae/en/taxes/corporate.tax/corporate.tax.topics/basis.of.taxation.natural.person.aspx).",
    "line": 71
  },
  "short_exact_native_quotes": [
    "A Natural Person is subject to Corporate Tax only if: They Conduct Business or Business Activity in the UAE; and Total Turnover derived from Business"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/res-uae-natural.txt",
  "source_sha256": "bf600bc19c07417ece18bb9688acb6d24d14d3d4cfaf8c0056354b22ef04b652",
  "source_version_basis": "Current published FTA page updated6May2024, actual body retained14November2026and own whole read16November2026."
}
```

### AE-VIRTUAL-DURATION

Actual foreign-organisation remote work permit is1year subject to renewal without a local guarantor/host; not automatictaxresidence.

```json
{
  "act_article_or_scope": "Virtual work permit, opening permission paragraph",
  "actual_read_on": "2026-11-16",
  "id": "AE-VIRTUAL-DURATION",
  "official_url": "https://www.gdrfad.gov.ae/en/services/f52024e3-b812-11ed-5210-4cd98f768936",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "Dubai's virtual-work permit is 1 year subject to renewal; the current GDRFA external-employer income requirement is at least USD 3500 monthly, not the original USD 5000. A residence permit does not introduce 5% PIT. Sources: [Terms And Conditions](https://www.gdrfad.gov.ae/en/services/f52024e3-b812-11ed-5210-4cd98f768936).",
    "line": 104
  },
  "short_exact_native_quotes": [
    "When a foreigner engages in remote work for an organization outside the country, they are given a residence permit for virtual work without a guarantor"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/res-ae-virtual.txt",
  "source_sha256": "f83eff383dcd9459688ae397647bc88d6a71c2f7d585827ce57c74ff5bddb4b0",
  "source_version_basis": "Actual GDRFA official service page retained14November2026, whole page personally read16November2026."
}
```

### AE-VIRTUAL-FUNDS

Outside-organisation remote-work proof and income at leastUSD3500monthly or other-currency equivalent apply, not oldUSD5000.

```json
{
  "act_article_or_scope": "Terms And Conditions, first2conditions",
  "actual_read_on": "2026-11-16",
  "id": "AE-VIRTUAL-FUNDS",
  "official_url": "https://www.gdrfad.gov.ae/en/services/f52024e3-b812-11ed-5210-4cd98f768936",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "Dubai's virtual-work permit is 1 year subject to renewal; the current GDRFA external-employer income requirement is at least USD 3500 monthly, not the original USD 5000. A residence permit does not introduce 5% PIT. Sources: [Terms And Conditions](https://www.gdrfad.gov.ae/en/services/f52024e3-b812-11ed-5210-4cd98f768936).",
    "line": 104
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/res-ae-virtual.txt",
  "source_sha256": "f83eff383dcd9459688ae397647bc88d6a71c2f7d585827ce57c74ff5bddb4b0",
  "source_version_basis": "Actual GDRFA official service page personally read, remaining passport/insurance/medical/IDterms also read; no all-in cost claim."
}
```

### AE-CD85-4(1)

Native Art4(1) contains usual/main residence and centre of personal/financial interests plus authentic ORministerialconditions wording; English unofficial conjunction differs, so do not silently substitute it.

```json
{
  "act_article_or_scope": "CabinetDecision85/2022 Art4(1), native PDFpage2",
  "actual_read_on": "2026-11-16",
  "id": "AE-CD85-4(1)",
  "official_url": "https://tax.gov.ae/DataFolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing%20Ar.pdf",
  "quote_mode": "Own manual literal visual transcription; complete assigned clause losslessly split into <=25whitespace-word fragments",
  "section": {
    "actual_text": "**UAE.** Keep the alternative natural-person routes in Cabinet Decision 85/2022 Art 4 separate: the native usual/main-place-of-residence and personal/financial-interests route OR the ministerial-criteria limb in Art4(1); 183 or more days during a relevant consecutive 12 months; or the qualified 90-or-more-day route, with nationality/residence-permit and permanent-home or employment/business conditions. MD 27/2023 supplies detailed meanings and counting rules. The Arabic Art 4(1) wording must be retained accurately; the authority-hosted English translation is expressly unofficial and differs in its conjunction. Treaty certificates require the relevant treaty's separate test. [Native Cabinet Decision](https://tax.gov.ae/DataFolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing%20Ar.pdf); [native MD 27](https://tax.gov.ae//Datafolder/Files/Legislation/Corporate%20Tax/Ministerial%20Decision%20No.%2027%20of%202023%20-%20For%20publishing%20Arabic.pdf).",
    "line": 47
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/ae-cd85-native.pdf",
  "source_sha256": "80f036e4dd7877836cb0b194409a3dbb784344b9171f5f66b170c97387eefd35",
  "source_version_basis": "Actual native PDF personally visually read; no unofficial English substitution",
  "visual_evidence_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/ae-cd85-native-visual-read.json"
}
```

### AE-CD85-4(2)

UAE183or more days in relevant12consecutive months is a separate naturalperson residence route.

```json
{
  "act_article_or_scope": "CabinetDecision85/2022 Art4(2), native PDFpage2",
  "actual_read_on": "2026-11-16",
  "id": "AE-CD85-4(2)",
  "official_url": "https://tax.gov.ae/DataFolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing%20Ar.pdf",
  "quote_mode": "Own manual literal visual transcription; complete assigned clause losslessly split into <=25whitespace-word fragments",
  "section": {
    "actual_text": "**UAE.** Keep the alternative natural-person routes in Cabinet Decision 85/2022 Art 4 separate: the native usual/main-place-of-residence and personal/financial-interests route OR the ministerial-criteria limb in Art4(1); 183 or more days during a relevant consecutive 12 months; or the qualified 90-or-more-day route, with nationality/residence-permit and permanent-home or employment/business conditions. MD 27/2023 supplies detailed meanings and counting rules. The Arabic Art 4(1) wording must be retained accurately; the authority-hosted English translation is expressly unofficial and differs in its conjunction. Treaty certificates require the relevant treaty's separate test. [Native Cabinet Decision](https://tax.gov.ae/DataFolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing%20Ar.pdf); [native MD 27](https://tax.gov.ae//Datafolder/Files/Legislation/Corporate%20Tax/Ministerial%20Decision%20No.%2027%20of%202023%20-%20For%20publishing%20Arabic.pdf).",
    "line": 47
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/ae-cd85-native.pdf",
  "source_sha256": "80f036e4dd7877836cb0b194409a3dbb784344b9171f5f66b170c97387eefd35",
  "source_version_basis": "Actual native PDF personally visually read; no unofficial English substitution",
  "visual_evidence_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/ae-cd85-native-visual-read.json"
}
```

### AE-CD85-4(3)

UAE90or more days route also requires UAE/GCCnationality or valid residence permit plus a stated home/work limb.

```json
{
  "act_article_or_scope": "CabinetDecision85/2022 Art4(3), native PDFpage2",
  "actual_read_on": "2026-11-16",
  "id": "AE-CD85-4(3)",
  "official_url": "https://tax.gov.ae/DataFolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing%20Ar.pdf",
  "quote_mode": "Own manual literal visual transcription; complete assigned clause losslessly split into <=25whitespace-word fragments",
  "section": {
    "actual_text": "**UAE.** Keep the alternative natural-person routes in Cabinet Decision 85/2022 Art 4 separate: the native usual/main-place-of-residence and personal/financial-interests route OR the ministerial-criteria limb in Art4(1); 183 or more days during a relevant consecutive 12 months; or the qualified 90-or-more-day route, with nationality/residence-permit and permanent-home or employment/business conditions. MD 27/2023 supplies detailed meanings and counting rules. The Arabic Art 4(1) wording must be retained accurately; the authority-hosted English translation is expressly unofficial and differs in its conjunction. Treaty certificates require the relevant treaty's separate test. [Native Cabinet Decision](https://tax.gov.ae/DataFolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing%20Ar.pdf); [native MD 27](https://tax.gov.ae//Datafolder/Files/Legislation/Corporate%20Tax/Ministerial%20Decision%20No.%2027%20of%202023%20-%20For%20publishing%20Arabic.pdf).",
    "line": 47
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/ae-cd85-native.pdf",
  "source_sha256": "80f036e4dd7877836cb0b194409a3dbb784344b9171f5f66b170c97387eefd35",
  "source_version_basis": "Actual native PDF personally visually read; no unofficial English substitution",
  "visual_evidence_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/ae-cd85-native-visual-read.json"
}
```

### AE-CD85-4(3)(a)

Qualified90day route can use a permanenthome in UAE.

```json
{
  "act_article_or_scope": "CabinetDecision85/2022 Art4(3)(a), native PDFpage2",
  "actual_read_on": "2026-11-16",
  "id": "AE-CD85-4(3)(a)",
  "official_url": "https://tax.gov.ae/DataFolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing%20Ar.pdf",
  "quote_mode": "Own manual literal visual transcription; complete assigned clause losslessly split into <=25whitespace-word fragments",
  "section": {
    "actual_text": "**UAE.** Keep the alternative natural-person routes in Cabinet Decision 85/2022 Art 4 separate: the native usual/main-place-of-residence and personal/financial-interests route OR the ministerial-criteria limb in Art4(1); 183 or more days during a relevant consecutive 12 months; or the qualified 90-or-more-day route, with nationality/residence-permit and permanent-home or employment/business conditions. MD 27/2023 supplies detailed meanings and counting rules. The Arabic Art 4(1) wording must be retained accurately; the authority-hosted English translation is expressly unofficial and differs in its conjunction. Treaty certificates require the relevant treaty's separate test. [Native Cabinet Decision](https://tax.gov.ae/DataFolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing%20Ar.pdf); [native MD 27](https://tax.gov.ae//Datafolder/Files/Legislation/Corporate%20Tax/Ministerial%20Decision%20No.%2027%20of%202023%20-%20For%20publishing%20Arabic.pdf).",
    "line": 47
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/ae-cd85-native.pdf",
  "source_sha256": "80f036e4dd7877836cb0b194409a3dbb784344b9171f5f66b170c97387eefd35",
  "source_version_basis": "Actual native PDF personally visually read; no unofficial English substitution",
  "visual_evidence_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/ae-cd85-native-visual-read.json"
}
```

### AE-CD85-4(3)(b)

Qualified90day route alternatively uses UAEemployment/business.

```json
{
  "act_article_or_scope": "CabinetDecision85/2022 Art4(3)(b), native PDFpage2",
  "actual_read_on": "2026-11-16",
  "id": "AE-CD85-4(3)(b)",
  "official_url": "https://tax.gov.ae/DataFolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing%20Ar.pdf",
  "quote_mode": "Own manual literal visual transcription; complete assigned clause losslessly split into <=25whitespace-word fragments",
  "section": {
    "actual_text": "**UAE.** Keep the alternative natural-person routes in Cabinet Decision 85/2022 Art 4 separate: the native usual/main-place-of-residence and personal/financial-interests route OR the ministerial-criteria limb in Art4(1); 183 or more days during a relevant consecutive 12 months; or the qualified 90-or-more-day route, with nationality/residence-permit and permanent-home or employment/business conditions. MD 27/2023 supplies detailed meanings and counting rules. The Arabic Art 4(1) wording must be retained accurately; the authority-hosted English translation is expressly unofficial and differs in its conjunction. Treaty certificates require the relevant treaty's separate test. [Native Cabinet Decision](https://tax.gov.ae/DataFolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing%20Ar.pdf); [native MD 27](https://tax.gov.ae//Datafolder/Files/Legislation/Corporate%20Tax/Ministerial%20Decision%20No.%2027%20of%202023%20-%20For%20publishing%20Arabic.pdf).",
    "line": 47
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/ae-cd85-native.pdf",
  "source_sha256": "80f036e4dd7877836cb0b194409a3dbb784344b9171f5f66b170c97387eefd35",
  "source_version_basis": "Actual native PDF personally visually read; no unofficial English substitution",
  "visual_evidence_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/ae-cd85-native-visual-read.json"
}
```

### AE-CD85-6(1)

An internationalagreement specific tax-residence test controls residence for that agreement.

```json
{
  "act_article_or_scope": "CabinetDecision85/2022 Art6(1), native PDFpage3",
  "actual_read_on": "2026-11-16",
  "id": "AE-CD85-6(1)",
  "official_url": "https://tax.gov.ae/DataFolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing%20Ar.pdf",
  "quote_mode": "Own manual literal visual transcription; complete assigned clause losslessly split into <=25whitespace-word fragments",
  "section": {
    "actual_text": "**UAE.** Keep the alternative natural-person routes in Cabinet Decision 85/2022 Art 4 separate: the native usual/main-place-of-residence and personal/financial-interests route OR the ministerial-criteria limb in Art4(1); 183 or more days during a relevant consecutive 12 months; or the qualified 90-or-more-day route, with nationality/residence-permit and permanent-home or employment/business conditions. MD 27/2023 supplies detailed meanings and counting rules. The Arabic Art 4(1) wording must be retained accurately; the authority-hosted English translation is expressly unofficial and differs in its conjunction. Treaty certificates require the relevant treaty's separate test. [Native Cabinet Decision](https://tax.gov.ae/DataFolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing%20Ar.pdf); [native MD 27](https://tax.gov.ae//Datafolder/Files/Legislation/Corporate%20Tax/Ministerial%20Decision%20No.%2027%20of%202023%20-%20For%20publishing%20Arabic.pdf).",
    "line": 47
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/ae-cd85-native.pdf",
  "source_sha256": "80f036e4dd7877836cb0b194409a3dbb784344b9171f5f66b170c97387eefd35",
  "source_version_basis": "Actual native PDF personally visually read; no unofficial English substitution",
  "visual_evidence_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/ae-cd85-native-visual-read.json"
}
```

### AE-CD85-9

CabinetDecision85effective1March2023.

```json
{
  "act_article_or_scope": "CabinetDecision85/2022 Art9, native PDFpage3",
  "actual_read_on": "2026-11-16",
  "id": "AE-CD85-9",
  "official_url": "https://tax.gov.ae/DataFolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing%20Ar.pdf",
  "quote_mode": "Own manual literal visual transcription; complete assigned clause losslessly split into <=25whitespace-word fragments",
  "section": {
    "actual_text": "**UAE.** Keep the alternative natural-person routes in Cabinet Decision 85/2022 Art 4 separate: the native usual/main-place-of-residence and personal/financial-interests route OR the ministerial-criteria limb in Art4(1); 183 or more days during a relevant consecutive 12 months; or the qualified 90-or-more-day route, with nationality/residence-permit and permanent-home or employment/business conditions. MD 27/2023 supplies detailed meanings and counting rules. The Arabic Art 4(1) wording must be retained accurately; the authority-hosted English translation is expressly unofficial and differs in its conjunction. Treaty certificates require the relevant treaty's separate test. [Native Cabinet Decision](https://tax.gov.ae/DataFolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing%20Ar.pdf); [native MD 27](https://tax.gov.ae//Datafolder/Files/Legislation/Corporate%20Tax/Ministerial%20Decision%20No.%2027%20of%202023%20-%20For%20publishing%20Arabic.pdf).",
    "line": 47
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/ae-cd85-native.pdf",
  "source_sha256": "80f036e4dd7877836cb0b194409a3dbb784344b9171f5f66b170c97387eefd35",
  "source_version_basis": "Actual native PDF personally visually read; no unofficial English substitution",
  "visual_evidence_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/ae-cd85-native-visual-read.json"
}
```

### AE-MD27-1

Calendar days/months; every full or partial day physically present counts in the relevant consecutive12months; actual presence days need not themselves be consecutive for183/90day tests.

```json
{
  "act_article_or_scope": "MinisterialDecision27/2023 Art3(1)–(3), actualArabicPDFp2",
  "actual_read_on": "2026-11-16",
  "correction_own_read_on": "2026-11-16",
  "final_native_delta_evidence": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/final-native-delta/resolutions.json",
  "id": "AE-MD27-1",
  "official_url": "https://tax.gov.ae//Datafolder/Files/Legislation/Corporate%20Tax/Ministerial%20Decision%20No.%2027%20of%202023%20-%20For%20publishing%20Arabic.pdf",
  "quote_mode": "Full assigned actual public-law operative clause, losslessly split into ordered contiguous native fragments <=25 words and <=240 characters; manually read operative scope and neighbours.",
  "section": {
    "actual_text": "**UAE.** Keep the alternative natural-person routes in Cabinet Decision 85/2022 Art 4 separate: the native usual/main-place-of-residence and personal/financial-interests route OR the ministerial-criteria limb in Art4(1); 183 or more days during a relevant consecutive 12 months; or the qualified 90-or-more-day route, with nationality/residence-permit and permanent-home or employment/business conditions. MD 27/2023 supplies detailed meanings and counting rules. The Arabic Art 4(1) wording must be retained accurately; the authority-hosted English translation is expressly unofficial and differs in its conjunction. Treaty certificates require the relevant treaty's separate test. [Native Cabinet Decision](https://tax.gov.ae/DataFolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing%20Ar.pdf); [native MD 27](https://tax.gov.ae//Datafolder/Files/Legislation/Corporate%20Tax/Ministerial%20Decision%20No.%2027%20of%202023%20-%20For%20publishing%20Arabic.pdf).",
    "line": 47
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/ae-residence27-ar.pdf",
  "source_sha256": "76a113486dc5fccf9a1c802ca4ee4932a922b4f2bef1dc2dc13ebbec04f1e6f4",
  "source_validation": "Own word-for-word comparison of every assigned manual clause against all3 actual rendered Arabic MD27 PDF pages16November2026. Art2(4) connective, Art4(1) repeated duration noun, Art6(1)(a) alternative OR and singular service, and Art6(1)(b) employment-income/part wording corrected explicitly. No substitution of unofficial English and no false machine literal-match claim for garbled Arabic PDF extraction. Source-layout line breaks are normalized; visual source diacritics are not claimed to be encoded identically.",
  "source_version_basis": "Actual native PDF personally visually read; no unofficial English substitution",
  "visual_evidence_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/ae-md27-native-visual-read.json"
}
```

### AE-MD27-2

Usual/main residence concerns the territory of habitual/normal living and the stable,more-than-transient pattern where most time is spent relative to other territories. Closest/most-significant personal/economic ties determine the interests centre; occupation,family/social/cultural ties,business/property administration and other relevant facts matter.

```json
{
  "act_article_or_scope": "MinisterialDecision27/2023 Art2(1)–(4), actualArabicPDFp1",
  "actual_read_on": "2026-11-16",
  "correction_own_read_on": "2026-11-16",
  "final_native_delta_evidence": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/final-native-delta/resolutions.json",
  "id": "AE-MD27-2",
  "official_url": "https://tax.gov.ae//Datafolder/Files/Legislation/Corporate%20Tax/Ministerial%20Decision%20No.%2027%20of%202023%20-%20For%20publishing%20Arabic.pdf",
  "quote_mode": "Full assigned actual public-law operative clause, losslessly split into ordered contiguous native fragments <=25 words and <=240 characters; manually read operative scope and neighbours.",
  "section": {
    "actual_text": "**UAE.** Keep the alternative natural-person routes in Cabinet Decision 85/2022 Art 4 separate: the native usual/main-place-of-residence and personal/financial-interests route OR the ministerial-criteria limb in Art4(1); 183 or more days during a relevant consecutive 12 months; or the qualified 90-or-more-day route, with nationality/residence-permit and permanent-home or employment/business conditions. MD 27/2023 supplies detailed meanings and counting rules. The Arabic Art 4(1) wording must be retained accurately; the authority-hosted English translation is expressly unofficial and differs in its conjunction. Treaty certificates require the relevant treaty's separate test. [Native Cabinet Decision](https://tax.gov.ae/DataFolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing%20Ar.pdf); [native MD 27](https://tax.gov.ae//Datafolder/Files/Legislation/Corporate%20Tax/Ministerial%20Decision%20No.%2027%20of%202023%20-%20For%20publishing%20Arabic.pdf).",
    "line": 47
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/ae-residence27-ar.pdf",
  "source_sha256": "76a113486dc5fccf9a1c802ca4ee4932a922b4f2bef1dc2dc13ebbec04f1e6f4",
  "source_validation": "Own word-for-word comparison of every assigned manual clause against all3 actual rendered Arabic MD27 PDF pages16November2026. Art2(4) connective, Art4(1) repeated duration noun, Art6(1)(a) alternative OR and singular service, and Art6(1)(b) employment-income/part wording corrected explicitly. No substitution of unofficial English and no false machine literal-match claim for garbled Arabic PDF extraction. Source-layout line breaks are normalized; visual source diacritics are not claimed to be encoded identically.",
  "source_version_basis": "Actual native PDF personally visually read; no unofficial English substitution",
  "visual_evidence_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/ae-md27-native-visual-read.json"
}
```

### AE-MD27-3

FTA discretion to disregard presence days for183/90tests requires an event outside the individual’s control,arising while already present,not reasonably foreseeable/preventable,and preventing departure as originally planned.

```json
{
  "act_article_or_scope": "MinisterialDecision27/2023 Art4(1)–(2), actualArabicPDFp2",
  "actual_read_on": "2026-11-16",
  "correction_own_read_on": "2026-11-16",
  "final_native_delta_evidence": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/final-native-delta/resolutions.json",
  "id": "AE-MD27-3",
  "official_url": "https://tax.gov.ae//Datafolder/Files/Legislation/Corporate%20Tax/Ministerial%20Decision%20No.%2027%20of%202023%20-%20For%20publishing%20Arabic.pdf",
  "quote_mode": "Full assigned actual public-law operative clause, losslessly split into ordered contiguous native fragments <=25 words and <=240 characters; manually read operative scope and neighbours.",
  "section": {
    "actual_text": "**UAE.** Keep the alternative natural-person routes in Cabinet Decision 85/2022 Art 4 separate: the native usual/main-place-of-residence and personal/financial-interests route OR the ministerial-criteria limb in Art4(1); 183 or more days during a relevant consecutive 12 months; or the qualified 90-or-more-day route, with nationality/residence-permit and permanent-home or employment/business conditions. MD 27/2023 supplies detailed meanings and counting rules. The Arabic Art 4(1) wording must be retained accurately; the authority-hosted English translation is expressly unofficial and differs in its conjunction. Treaty certificates require the relevant treaty's separate test. [Native Cabinet Decision](https://tax.gov.ae/DataFolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing%20Ar.pdf); [native MD 27](https://tax.gov.ae//Datafolder/Files/Legislation/Corporate%20Tax/Ministerial%20Decision%20No.%2027%20of%202023%20-%20For%20publishing%20Arabic.pdf).",
    "line": 47
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/ae-residence27-ar.pdf",
  "source_sha256": "76a113486dc5fccf9a1c802ca4ee4932a922b4f2bef1dc2dc13ebbec04f1e6f4",
  "source_validation": "Own word-for-word comparison of every assigned manual clause against all3 actual rendered Arabic MD27 PDF pages16November2026. Art2(4) connective, Art4(1) repeated duration noun, Art6(1)(a) alternative OR and singular service, and Art6(1)(b) employment-income/part wording corrected explicitly. No substitution of unofficial English and no false machine literal-match claim for garbled Arabic PDF extraction. Source-layout line breaks are normalized; visual source diacritics are not claimed to be encoded identically.",
  "source_version_basis": "Actual native PDF personally visually read; no unofficial English substitution",
  "visual_evidence_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/ae-md27-native-visual-read.json"
}
```

### AE-MD27-4

Permanent accommodation may be a house,flat,furnished room or other dwelling,but must be continuously available for regular stable occupation rather than occasional/short stays; ownership is unnecessary and rental/other occupancy can qualify.

```json
{
  "act_article_or_scope": "MinisterialDecision27/2023 Art5(1)–(3), actualArabicPDFp2",
  "actual_read_on": "2026-11-16",
  "correction_own_read_on": "2026-11-16",
  "final_native_delta_evidence": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/final-native-delta/resolutions.json",
  "id": "AE-MD27-4",
  "official_url": "https://tax.gov.ae//Datafolder/Files/Legislation/Corporate%20Tax/Ministerial%20Decision%20No.%2027%20of%202023%20-%20For%20publishing%20Arabic.pdf",
  "quote_mode": "Full assigned actual public-law operative clause, losslessly split into ordered contiguous native fragments <=25 words and <=240 characters; manually read operative scope and neighbours.",
  "section": {
    "actual_text": "**UAE.** Keep the alternative natural-person routes in Cabinet Decision 85/2022 Art 4 separate: the native usual/main-place-of-residence and personal/financial-interests route OR the ministerial-criteria limb in Art4(1); 183 or more days during a relevant consecutive 12 months; or the qualified 90-or-more-day route, with nationality/residence-permit and permanent-home or employment/business conditions. MD 27/2023 supplies detailed meanings and counting rules. The Arabic Art 4(1) wording must be retained accurately; the authority-hosted English translation is expressly unofficial and differs in its conjunction. Treaty certificates require the relevant treaty's separate test. [Native Cabinet Decision](https://tax.gov.ae/DataFolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing%20Ar.pdf); [native MD 27](https://tax.gov.ae//Datafolder/Files/Legislation/Corporate%20Tax/Ministerial%20Decision%20No.%2027%20of%202023%20-%20For%20publishing%20Arabic.pdf).",
    "line": 47
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/ae-residence27-ar.pdf",
  "source_sha256": "76a113486dc5fccf9a1c802ca4ee4932a922b4f2bef1dc2dc13ebbec04f1e6f4",
  "source_validation": "Own word-for-word comparison of every assigned manual clause against all3 actual rendered Arabic MD27 PDF pages16November2026. Art2(4) connective, Art4(1) repeated duration noun, Art6(1)(a) alternative OR and singular service, and Art6(1)(b) employment-income/part wording corrected explicitly. No substitution of unofficial English and no false machine literal-match claim for garbled Arabic PDF extraction. Source-layout line breaks are normalized; visual source diacritics are not claimed to be encoded identically.",
  "source_version_basis": "Actual native PDF personally visually read; no unofficial English substitution",
  "visual_evidence_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/ae-md27-native-visual-read.json"
}
```

### AE-MD27-5

Employment includes the prescribed UAE employer contract/services under direction or supervision for remuneration,or a continuing relationship deriving all/a substantial part of employment income from one party as wages for UAE work; fixed/indefinite and full/parttime can qualify; uncontracted voluntary roles excluded. Publication and effect1March2023.

```json
{
  "act_article_or_scope": "MinisterialDecision27/2023 Art6(1)–(3) andArt8, actualArabicPDFpp2–3",
  "actual_read_on": "2026-11-16",
  "correction_own_read_on": "2026-11-16",
  "final_native_delta_evidence": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/final-native-delta/resolutions.json",
  "id": "AE-MD27-5",
  "official_url": "https://tax.gov.ae//Datafolder/Files/Legislation/Corporate%20Tax/Ministerial%20Decision%20No.%2027%20of%202023%20-%20For%20publishing%20Arabic.pdf",
  "quote_mode": "Full assigned actual public-law operative clause, losslessly split into ordered contiguous native fragments <=25 words and <=240 characters; manually read operative scope and neighbours.",
  "section": {
    "actual_text": "**UAE.** Keep the alternative natural-person routes in Cabinet Decision 85/2022 Art 4 separate: the native usual/main-place-of-residence and personal/financial-interests route OR the ministerial-criteria limb in Art4(1); 183 or more days during a relevant consecutive 12 months; or the qualified 90-or-more-day route, with nationality/residence-permit and permanent-home or employment/business conditions. MD 27/2023 supplies detailed meanings and counting rules. The Arabic Art 4(1) wording must be retained accurately; the authority-hosted English translation is expressly unofficial and differs in its conjunction. Treaty certificates require the relevant treaty's separate test. [Native Cabinet Decision](https://tax.gov.ae/DataFolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing%20Ar.pdf); [native MD 27](https://tax.gov.ae//Datafolder/Files/Legislation/Corporate%20Tax/Ministerial%20Decision%20No.%2027%20of%202023%20-%20For%20publishing%20Arabic.pdf).",
    "line": 47
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/ae-residence27-ar.pdf",
  "source_sha256": "76a113486dc5fccf9a1c802ca4ee4932a922b4f2bef1dc2dc13ebbec04f1e6f4",
  "source_validation": "Own word-for-word comparison of every assigned manual clause against all3 actual rendered Arabic MD27 PDF pages16November2026. Art2(4) connective, Art4(1) repeated duration noun, Art6(1)(a) alternative OR and singular service, and Art6(1)(b) employment-income/part wording corrected explicitly. No substitution of unofficial English and no false machine literal-match claim for garbled Arabic PDF extraction. Source-layout line breaks are normalized; visual source diacritics are not claimed to be encoded identically.",
  "source_version_basis": "Actual native PDF personally visually read; no unofficial English substitution",
  "visual_evidence_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/ae-md27-native-visual-read.json"
}
```

### US-EXPAT-COVERED-GATES

Covered gates include5yearaveragetax indexed amount, networthatleast2million OR5yearcompliancecertification failure; apply877Aexceptions and applicable index separately.

```json
{
  "act_article_or_scope": "IRC877(a)(2), cross-reference by877A(g)(1)",
  "actual_read_on": "2026-11-16",
  "id": "US-EXPAT-COVERED-GATES",
  "official_url": "https://uscode.house.gov/us/usc/t26/s877/",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "| United States | IRC 877A concerns covered expatriation, not an ordinary overseas move by a citizen. For 2026 the indexed average-tax gate is more than USD 211000 and the net-worth gate is at least USD 2000000; failure to certify 5 years' compliance is a separate route. Dual-birth/minor exceptions have their own conditions and do not cure certification failure. The 2026 USD 910000 indexed covered-gain exclusion is not a lifetime 800000 exclusion. Eligible mark-to-market tax can have property-specific irrevocable deferral with security, interest and waiver conditions; deferred-compensation, specified accounts and nongrantor trusts have different rules. Sources: [IRC877(a)(2)](https://uscode.house.gov/us/usc/t26/s877/); [IRC877A(a) complete](https://uscode.house.gov/us/usc/t26/s877A/); [RevProc2025-32 s4.37](https://www.irs.gov/irb/2025-45_IRB). |",
    "line": 131
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/us-code877.txt",
  "source_sha256": "0738cfe86bc89be33959367900d46b0787d57b1466f37fae837e65c836a9da1b",
  "source_version_basis": "Actual Code throughPL119-142/10November2026, own operative/neighbour read."
}
```

### US-EXPAT-MARKET-VALUE

CoveredpropertydeemedFMVsalepreviousday with gain/loss/basis adjustments and indexedexclusion; propertyexceptions in(c) separate, no universal lifetime800000exclusion.

```json
{
  "act_article_or_scope": "IRC877A(a) complete",
  "actual_read_on": "2026-11-16",
  "id": "US-EXPAT-MARKET-VALUE",
  "official_url": "https://uscode.house.gov/us/usc/t26/s877A/",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "| United States | IRC 877A concerns covered expatriation, not an ordinary overseas move by a citizen. For 2026 the indexed average-tax gate is more than USD 211000 and the net-worth gate is at least USD 2000000; failure to certify 5 years' compliance is a separate route. Dual-birth/minor exceptions have their own conditions and do not cure certification failure. The 2026 USD 910000 indexed covered-gain exclusion is not a lifetime 800000 exclusion. Eligible mark-to-market tax can have property-specific irrevocable deferral with security, interest and waiver conditions; deferred-compensation, specified accounts and nongrantor trusts have different rules. Sources: [IRC877(a)(2)](https://uscode.house.gov/us/usc/t26/s877/); [IRC877A(a) complete](https://uscode.house.gov/us/usc/t26/s877A/); [RevProc2025-32 s4.37](https://www.irs.gov/irb/2025-45_IRB). |",
    "line": 131
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/us-code877A.txt",
  "source_sha256": "50501bef0a8da910c45355ed2b37aa28c282d2f6a0014a34e04fec8df0803ac6",
  "source_version_basis": "Actual Code throughPL119-142/10November2026, whole303line source personally read."
}
```

### US-EXPAT-PROPERTY-DEFERRAL

Property-specific irrevocable payment deferral election requires adequate security, treaty collection waiver, interest and actual disposal/death/security-failure endpoints.

```json
{
  "act_article_or_scope": "IRC877A(b) all7paragraphs",
  "actual_read_on": "2026-11-16",
  "id": "US-EXPAT-PROPERTY-DEFERRAL",
  "official_url": "https://uscode.house.gov/us/usc/t26/s877A/",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "| United States | IRC 877A concerns covered expatriation, not an ordinary overseas move by a citizen. For 2026 the indexed average-tax gate is more than USD 211000 and the net-worth gate is at least USD 2000000; failure to certify 5 years' compliance is a separate route. Dual-birth/minor exceptions have their own conditions and do not cure certification failure. The 2026 USD 910000 indexed covered-gain exclusion is not a lifetime 800000 exclusion. Eligible mark-to-market tax can have property-specific irrevocable deferral with security, interest and waiver conditions; deferred-compensation, specified accounts and nongrantor trusts have different rules. Sources: [IRC877(a)(2)](https://uscode.house.gov/us/usc/t26/s877/); [IRC877A(a) complete](https://uscode.house.gov/us/usc/t26/s877A/); [RevProc2025-32 s4.37](https://www.irs.gov/irb/2025-45_IRB). |",
    "line": 131
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/us-code877A.txt",
  "source_sha256": "50501bef0a8da910c45355ed2b37aa28c282d2f6a0014a34e04fec8df0803ac6",
  "source_version_basis": "Current Code personally read, complete operative/neighbours."
}
```

### US-EXPAT-SPECIAL-ASSETS

Deferredcompensation, specifiedtaxdeferredaccounts and nongrantortrustinterests have separate treatment, not generic mark-to-market.

```json
{
  "act_article_or_scope": "IRC877A(c), all3exceptions",
  "actual_read_on": "2026-11-16",
  "id": "US-EXPAT-SPECIAL-ASSETS",
  "official_url": "https://uscode.house.gov/us/usc/t26/s877A/",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "| United States | IRC 877A concerns covered expatriation, not an ordinary overseas move by a citizen. For 2026 the indexed average-tax gate is more than USD 211000 and the net-worth gate is at least USD 2000000; failure to certify 5 years' compliance is a separate route. Dual-birth/minor exceptions have their own conditions and do not cure certification failure. The 2026 USD 910000 indexed covered-gain exclusion is not a lifetime 800000 exclusion. Eligible mark-to-market tax can have property-specific irrevocable deferral with security, interest and waiver conditions; deferred-compensation, specified accounts and nongrantor trusts have different rules. Sources: [IRC877(a)(2)](https://uscode.house.gov/us/usc/t26/s877/); [IRC877A(a) complete](https://uscode.house.gov/us/usc/t26/s877A/); [RevProc2025-32 s4.37](https://www.irs.gov/irb/2025-45_IRB). |",
    "line": 131
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/us-code877A.txt",
  "source_sha256": "50501bef0a8da910c45355ed2b37aa28c282d2f6a0014a34e04fec8df0803ac6",
  "source_version_basis": "Current Code actual(c)–(f)all personally read; detailed calculation under(d)–(f)not supplied by this Guide."
}
```

### US-EXPAT-DUAL-MINOR

Birthdual-citizen and minor financialgateexceptions have actual foreigncitizenship/taxresidence/USlookback or18.5age/10year conditions; do not cure certification gate.

```json
{
  "act_article_or_scope": "IRC877A(g)(1), all exceptions and return-to-tax-status condition",
  "actual_read_on": "2026-11-16",
  "id": "US-EXPAT-DUAL-MINOR",
  "official_url": "https://uscode.house.gov/us/usc/t26/s877A/",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "| United States | IRC 877A concerns covered expatriation, not an ordinary overseas move by a citizen. For 2026 the indexed average-tax gate is more than USD 211000 and the net-worth gate is at least USD 2000000; failure to certify 5 years' compliance is a separate route. Dual-birth/minor exceptions have their own conditions and do not cure certification failure. The 2026 USD 910000 indexed covered-gain exclusion is not a lifetime 800000 exclusion. Eligible mark-to-market tax can have property-specific irrevocable deferral with security, interest and waiver conditions; deferred-compensation, specified accounts and nongrantor trusts have different rules. Sources: [IRC877(a)(2)](https://uscode.house.gov/us/usc/t26/s877/); [IRC877A(a) complete](https://uscode.house.gov/us/usc/t26/s877A/); [RevProc2025-32 s4.37](https://www.irs.gov/irb/2025-45_IRB). |",
    "line": 131
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/us-code877A.txt",
  "source_sha256": "50501bef0a8da910c45355ed2b37aa28c282d2f6a0014a34e04fec8df0803ac6",
  "source_version_basis": "Current Code personally read."
}
```

### US-EXPAT-EVENT-DEFINITIONS

Actual relinquishment or longtermLPRcessation determines expatriate/date, including formal approval conditions; an ordinary move alone is insufficient.

```json
{
  "act_article_or_scope": "IRC877A(g)(2)–(5)",
  "actual_read_on": "2026-11-16",
  "id": "US-EXPAT-EVENT-DEFINITIONS",
  "official_url": "https://uscode.house.gov/us/usc/t26/s877A/",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "| United States | IRC 877A concerns covered expatriation, not an ordinary overseas move by a citizen. For 2026 the indexed average-tax gate is more than USD 211000 and the net-worth gate is at least USD 2000000; failure to certify 5 years' compliance is a separate route. Dual-birth/minor exceptions have their own conditions and do not cure certification failure. The 2026 USD 910000 indexed covered-gain exclusion is not a lifetime 800000 exclusion. Eligible mark-to-market tax can have property-specific irrevocable deferral with security, interest and waiver conditions; deferred-compensation, specified accounts and nongrantor trusts have different rules. Sources: [IRC877(a)(2)](https://uscode.house.gov/us/usc/t26/s877/); [IRC877A(a) complete](https://uscode.house.gov/us/usc/t26/s877A/); [RevProc2025-32 s4.37](https://www.irs.gov/irb/2025-45_IRB). |",
    "line": 131
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/us-code877A.txt",
  "source_sha256": "50501bef0a8da910c45355ed2b37aa28c282d2f6a0014a34e04fec8df0803ac6",
  "source_version_basis": "Current Code personally read."
}
```

### US-EXPAT-LPR-8OF15

Longtermresident generallyLPRin8of15taxyears, with specified foreign-treaty-resident nonwaiveryears excluded.

```json
{
  "act_article_or_scope": "IRC877(e)(2) complete",
  "actual_read_on": "2026-11-16",
  "id": "US-EXPAT-LPR-8OF15",
  "official_url": "https://uscode.house.gov/us/usc/t26/s877/",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "| United States | IRC 877A concerns covered expatriation, not an ordinary overseas move by a citizen. For 2026 the indexed average-tax gate is more than USD 211000 and the net-worth gate is at least USD 2000000; failure to certify 5 years' compliance is a separate route. Dual-birth/minor exceptions have their own conditions and do not cure certification failure. The 2026 USD 910000 indexed covered-gain exclusion is not a lifetime 800000 exclusion. Eligible mark-to-market tax can have property-specific irrevocable deferral with security, interest and waiver conditions; deferred-compensation, specified accounts and nongrantor trusts have different rules. Sources: [IRC877(a)(2)](https://uscode.house.gov/us/usc/t26/s877/); [IRC877A(a) complete](https://uscode.house.gov/us/usc/t26/s877A/); [RevProc2025-32 s4.37](https://www.irs.gov/irb/2025-45_IRB). |",
    "line": 131
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/us-code877.txt",
  "source_sha256": "0738cfe86bc89be33959367900d46b0787d57b1466f37fae837e65c836a9da1b",
  "source_version_basis": "Current Code personally read; no invented full-calendar-year daycount."
}
```

### US-EXPAT-2026-TAX-INDEX

Forcalendar2026coveredaverage5yearnettaxgate is more than211000, subject to877A(g)exceptions.

```json
{
  "act_article_or_scope": "RevProc2025-32 s4.37",
  "actual_read_on": "2026-11-16",
  "id": "US-EXPAT-2026-TAX-INDEX",
  "official_url": "https://www.irs.gov/irb/2025-45_IRB",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "| United States | IRC 877A concerns covered expatriation, not an ordinary overseas move by a citizen. For 2026 the indexed average-tax gate is more than USD 211000 and the net-worth gate is at least USD 2000000; failure to certify 5 years' compliance is a separate route. Dual-birth/minor exceptions have their own conditions and do not cure certification failure. The 2026 USD 910000 indexed covered-gain exclusion is not a lifetime 800000 exclusion. Eligible mark-to-market tax can have property-specific irrevocable deferral with security, interest and waiver conditions; deferred-compensation, specified accounts and nongrantor trusts have different rules. Sources: [IRC877(a)(2)](https://uscode.house.gov/us/usc/t26/s877/); [IRC877A(a) complete](https://uscode.house.gov/us/usc/t26/s877A/); [RevProc2025-32 s4.37](https://www.irs.gov/irb/2025-45_IRB). |",
    "line": 131
  },
  "short_exact_native_quotes": [
    ".37 Expatriation to Avoid Tax. For calendar year 2026, under § 877A(g)(1)(A), unless an exception under § 877A(g)(1)(B) applies, an individual is a covered expatriate"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/us-qbi-rp2025-32.txt",
  "source_sha256": "c90ca042e094ba5520f005676afc33436d30626b24a01f30a645e9031c392a26",
  "source_version_basis": "Actual retained InternalRevenueBulletin operative paragraph and s5effective-date clauses personally reread16November2026."
}
```

### US-EXPAT-2026-GAIN-INDEX

For taxableyearsbeginning2026coveredgaininclusion reduced not below0by910000under877A(a)(3).

```json
{
  "act_article_or_scope": "RevProc2025-32 s4.38",
  "actual_read_on": "2026-11-16",
  "id": "US-EXPAT-2026-GAIN-INDEX",
  "official_url": "https://www.irs.gov/irb/2025-45_IRB",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "| United States | IRC 877A concerns covered expatriation, not an ordinary overseas move by a citizen. For 2026 the indexed average-tax gate is more than USD 211000 and the net-worth gate is at least USD 2000000; failure to certify 5 years' compliance is a separate route. Dual-birth/minor exceptions have their own conditions and do not cure certification failure. The 2026 USD 910000 indexed covered-gain exclusion is not a lifetime 800000 exclusion. Eligible mark-to-market tax can have property-specific irrevocable deferral with security, interest and waiver conditions; deferred-compensation, specified accounts and nongrantor trusts have different rules. Sources: [IRC877(a)(2)](https://uscode.house.gov/us/usc/t26/s877/); [IRC877A(a) complete](https://uscode.house.gov/us/usc/t26/s877A/); [RevProc2025-32 s4.37](https://www.irs.gov/irb/2025-45_IRB). |",
    "line": 131
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/us-qbi-rp2025-32.txt",
  "source_sha256": "c90ca042e094ba5520f005676afc33436d30626b24a01f30a645e9031c392a26",
  "source_version_basis": "Actual published2026index, operative/native/effective-date scope read."
}
```

### US-FEIE-2026-INDEX-CORROBORATION

Taxyearsbeginning2026FEIEmaximum132900under911(b)(2)(D)(i), separately conditioned by actual qualification and eligible earned income.

```json
{
  "act_article_or_scope": "RevProc2025-32 s4.39",
  "actual_read_on": "2026-11-16",
  "id": "US-FEIE-2026-INDEX-CORROBORATION",
  "official_url": "https://www.irs.gov/irb/2025-45_IRB",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "US citizens generally remain within worldwide-income taxation abroad; return filing depends on the applicable filing thresholds and special duties, not whether tax is ultimately payable. The FEIE is conditional relief for qualifying foreign earned income, not all business profits, investment returns or self-employment tax. For 2026 the maximum is USD 132900 for a fully qualifying year; tax home/foreign abode, bona fide residence or physical-presence conditions, excluded-income credits and tax-rate stacking matter. Bona fide residence is not the 330-full-day test: the latter is a separate physical-presence test over 12 consecutive months. Sources: [Worldwide-income/general filing paragraph and relief-return sentence](https://www.irs.gov/individuals/international-taxpayers/us-citizens-and-resident-aliens-abroad); [2026instructions opening maximum](https://www.irs.gov/instructions/i2555); [Other rules](https://www.irs.gov/individuals/international-taxpayers/foreign-earned-income-exclusion).",
    "line": 110
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/us-qbi-rp2025-32.txt",
  "source_sha256": "c90ca042e094ba5520f005676afc33436d30626b24a01f30a645e9031c392a26",
  "source_version_basis": "Actual published2026index and neighbours personally read."
}
```

### CA-DEPARTURE-SCOPE

Cessation-of-residence deemed disposition excludes specifiedCanadianproperty/PEassets/excludedrights, eligibleprearrival/inheritedassets under60months/120monthlookback and election-relatedproperty; employee-trustspecialrule and reacquisition remain separate.

```json
{
  "act_article_or_scope": "ITA128.1(4)(a)–(c), complete including all(b)exceptions",
  "actual_read_on": "2026-11-16",
  "id": "CA-DEPARTURE-SCOPE",
  "official_url": "https://laws-lois.justice.gc.ca/eng/acts/I-3.3/section-128.1.html",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "| Canada | Departure disposition has exclusions for specified Canadian property, businesses, rights and other statutory cases. Pre-arrival/inherited-property and the 60-month/10-year rule matter. T1243 computation, T1161 information and T1244 deferral/security have distinct scopes; a generic all-property/no-exceptions statement is wrong. Sources: [ITA128.1(4)(a)–(c)](https://laws-lois.justice.gc.ca/eng/acts/I-3.3/section-128.1.html); [Reporting deemed disposition](https://www.canada.ca/en/revenue-agency/services/tax/international-non-residents/individuals-leaving-entering-canada-non-residents/dispositions-property.html). |",
    "line": 133
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/ca-ita1281.txt",
  "source_sha256": "041773d41fb70c29f3468d15a0de0899e691ebee03d287c91e028da4c6d4f5a9",
  "source_version_basis": "Actual current JusticeLaw source personally read selected128.1(4)/(9)/(10), not wholeAct; fullcrossreferencedforms not presumed current2026."
}
```

### CA-DEPARTURE-1243

T1243computes reported departure gains/losses separately from T1161information and T1244paymentdeferral; retained page describes2025return, not final2026filinginstructions.

```json
{
  "act_article_or_scope": "Reporting deemed disposition, T1243paragraph",
  "actual_read_on": "2026-11-16",
  "id": "CA-DEPARTURE-1243",
  "official_url": "https://www.canada.ca/en/revenue-agency/services/tax/international-non-residents/individuals-leaving-entering-canada-non-residents/dispositions-property.html",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "| Canada | Departure disposition has exclusions for specified Canadian property, businesses, rights and other statutory cases. Pre-arrival/inherited-property and the 60-month/10-year rule matter. T1243 computation, T1161 information and T1244 deferral/security have distinct scopes; a generic all-property/no-exceptions statement is wrong. Sources: [ITA128.1(4)(a)–(c)](https://laws-lois.justice.gc.ca/eng/acts/I-3.3/section-128.1.html); [Reporting deemed disposition](https://www.canada.ca/en/revenue-agency/services/tax/international-non-residents/individuals-leaving-entering-canada-non-residents/dispositions-property.html). |",
    "line": 133
  },
  "short_exact_native_quotes": [
    "To calculate and report any capital gains (or losses) on property that you are deemed to have disposed of on the date you ceased"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/ca-exit-guide.txt",
  "source_sha256": "7fc171630ea970d56d7e2ac2a279bb8e4c88a2abb7af7d4354f432816bacd6ac",
  "source_version_basis": "Actually read CRApublished2025return-basis guidance; current statute independently read."
}
```

### NL-AB-5PERCENT

Atleast5%direct/indirectaloneorwithfiscalpartner, per-class/options/rights/profit/cooperative and linealfamilyextensions; not a universalmorethan5%gate.

```json
{
  "act_article_or_scope": "2026explanation14.2 complete share/instrument scope and familyextension",
  "actual_read_on": "2026-11-16",
  "id": "NL-AB-5PERCENT",
  "official_url": "https://www.belastingdienst.nl/wps/wcm/connect/fisin/fisin2026/aanmerkelijk_belang",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "| Netherlands | Substantial-interest scope includes generally at least 5% and statutory extensions. Post 15 September 2015 protective assessments can persist indefinitely; prechange 10 year cancellation treatment is not universal current law. Payment triggers, deferral/security and treaty rights require the exact case. Sources: [2026explanation14.2 complete share/instrument scope and familyextension](https://www.belastingdienst.nl/wps/wcm/connect/fisin/fisin2026/aanmerkelijk_belang); [Substantialinterest emigration section](https://www.belastingdienst.nl/wps/wcm/connect/nl/buitenland/content/conserverende-aanslag-bij-emigratie). |",
    "line": 135
  },
  "short_exact_native_quotes": [
    "U hebt een aanmerkelijk belang als u, eventueel samen met uw fiscale partner, direct of indirect minimaal 5% hebt van: de aandelen (ook per soort)"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/nl-ab2026.txt",
  "source_sha256": "bb13065b98b769040d7c53647e63228c481840c30b2313710a6d63ffaacbc3f6",
  "source_version_basis": "Actual native2026authorityexplanation personally read, specific current income/collectionstatutes notyetpersonallyrecovered; registeredURLmustmatchretrievalmanifest."
}
```

### NL-EXIT-ASSESSMENT-DURATION

Deemeddisposal createsbox2protectiveassessment, pre15September2015at15:15versuslaterdeferral/dischargeconditions differ; disposal/dividend/companycessation reporting/payment triggers apply.

```json
{
  "act_article_or_scope": "Substantialinterest emigration section, all3paragraphs",
  "actual_read_on": "2026-11-16",
  "id": "NL-EXIT-ASSESSMENT-DURATION",
  "official_url": "https://www.belastingdienst.nl/wps/wcm/connect/nl/buitenland/content/conserverende-aanslag-bij-emigratie",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "| Netherlands | Substantial-interest scope includes generally at least 5% and statutory extensions. Post 15 September 2015 protective assessments can persist indefinitely; prechange 10 year cancellation treatment is not universal current law. Payment triggers, deferral/security and treaty rights require the exact case. Sources: [2026explanation14.2 complete share/instrument scope and familyextension](https://www.belastingdienst.nl/wps/wcm/connect/fisin/fisin2026/aanmerkelijk_belang); [Substantialinterest emigration section](https://www.belastingdienst.nl/wps/wcm/connect/nl/buitenland/content/conserverende-aanslag-bij-emigratie). |",
    "line": 135
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/nl-exit-native.txt",
  "source_sha256": "06560de15fd3c69f2e9ba5e79695288aef69f2e75a22f93210ce2f06f563f04d",
  "source_version_basis": "Actual current nativeauthoritypage read; ownwholeoperative body and neighbours, not personal-taxassessment conclusion."
}
```

### NL-EXIT-DEFERRAL-SECURITY

AutomaticEU/EEAdeferral versus application/conditions, subsequent nonEUmove and security rules require actual incomecomponent/country facts.

```json
{
  "act_article_or_scope": "Paymentdeferral/application/latermove/security full assigned operative sections",
  "actual_read_on": "2026-11-16",
  "id": "NL-EXIT-DEFERRAL-SECURITY",
  "official_url": "https://www.belastingdienst.nl/wps/wcm/connect/nl/buitenland/content/conserverende-aanslag-bij-emigratie",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "| Netherlands | Substantial-interest scope includes generally at least 5% and statutory extensions. Post 15 September 2015 protective assessments can persist indefinitely; prechange 10 year cancellation treatment is not universal current law. Payment triggers, deferral/security and treaty rights require the exact case. Sources: [2026explanation14.2 complete share/instrument scope and familyextension](https://www.belastingdienst.nl/wps/wcm/connect/fisin/fisin2026/aanmerkelijk_belang); [Substantialinterest emigration section](https://www.belastingdienst.nl/wps/wcm/connect/nl/buitenland/content/conserverende-aanslag-bij-emigratie). |",
    "line": 135
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/nl-exit-native.txt",
  "source_sha256": "06560de15fd3c69f2e9ba5e79695288aef69f2e75a22f93210ce2f06f563f04d",
  "source_version_basis": "Actual currentauthoritypage personally read; scope includes sharesecurityexception forNO/IS/LI, not universal security."
}
```

### FR-EXIT-SCOPE

Generally6of10priorFrenchresidenceyears; householdshareprofitsatleast50%ORvalueexceeds800000; earnoutcategorydistinct.

```json
{
  "act_article_or_scope": "CGI167bisI(1), both households/earnoutparagraphs",
  "actual_read_on": "2026-11-16",
  "id": "FR-EXIT-SCOPE",
  "official_url": "https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000048806379",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "| France | CGI 167 bis generally requires 6 of 10 prior residence years and household share rights exceeding EUR 800000 or at least 50% profits, with separate earnout/deferred-gain categories. Automatic/requested payment suspension and conditions differ from discharge after 2 years or 5 years when the relevant value exceeds EUR 2570000. Equality at EUR 2570000 belongs to the 2 year side of that value test. Other events, filings and outstanding categories can remain relevant. Sources: [CGI167bisI(1)](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000048806379). |",
    "line": 134
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/fr-cgi167bis-web-native.txt",
  "source_sha256": "d1a27f76e068e710cf46de59c8f05cb0d9049dd13ec003ace0cf6b8dad8e8306",
  "source_version_basis": "Légifrance article version effective1January2024, personally read wholeI–X/operative neighbours16November2026 via actualweb. OrdinaryCLI403retained. Derivednative.txt removes only web link-format wrappers, preserving native displayed words; rawresponseSHAseparatelyretained."
}
```

### FR-EXIT-PAYMENT-SUSPENSION

Automatic versus requested suspension depends on EU/qualifying administrative and recovery assistance/noncooperative-country status; declaration, representative and security requirements and recovery-limitation effects apply under actualIV–VI. No work-related security waiver is established by the assigned current text.

```json
{
  "act_article_or_scope": "CGI167bisIV–VI, complete assigned clauses",
  "actual_read_on": "2026-11-16",
  "id": "FR-EXIT-PAYMENT-SUSPENSION",
  "official_url": "https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000048806379",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "| France | CGI 167 bis generally requires 6 of 10 prior residence years and household share rights exceeding EUR 800000 or at least 50% profits, with separate earnout/deferred-gain categories. Automatic/requested payment suspension and conditions differ from discharge after 2 years or 5 years when the relevant value exceeds EUR 2570000. Equality at EUR 2570000 belongs to the 2 year side of that value test. Other events, filings and outstanding categories can remain relevant. Sources: [CGI167bisI(1)](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000048806379). |",
    "line": 134
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/fr-cgi167bis-web-native.txt",
  "source_sha256": "d1a27f76e068e710cf46de59c8f05cb0d9049dd13ec003ace0cf6b8dad8e8306",
  "source_version_basis": "Légifrance article version effective1January2024, personally read wholeI–X/operative neighbours16November2026 via actualweb. OrdinaryCLI403retained. Derivednative.txt removes only web link-format wrappers, preserving native displayed words; rawresponseSHAseparatelyretained."
}
```

### FR-EXIT-2OR5YEAR-DISCHARGE

Specific latentgainliability may discharge after2years,5ifvalueexceeds2.57million; qualifyingretention/exchange/return/death/donation conditions and deferredgain/earnoutcategories differ.

```json
{
  "act_article_or_scope": "CGI167bisVII(2)–(4), all retained-asset/death/donation/return/earnoutconditions",
  "actual_read_on": "2026-11-16",
  "id": "FR-EXIT-2OR5YEAR-DISCHARGE",
  "official_url": "https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000048806379",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "| France | CGI 167 bis generally requires 6 of 10 prior residence years and household share rights exceeding EUR 800000 or at least 50% profits, with separate earnout/deferred-gain categories. Automatic/requested payment suspension and conditions differ from discharge after 2 years or 5 years when the relevant value exceeds EUR 2570000. Equality at EUR 2570000 belongs to the 2 year side of that value test. Other events, filings and outstanding categories can remain relevant. Sources: [CGI167bisI(1)](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000048806379). |",
    "line": 134
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/fr-cgi167bis-web-native.txt",
  "source_sha256": "d1a27f76e068e710cf46de59c8f05cb0d9049dd13ec003ace0cf6b8dad8e8306",
  "source_version_basis": "Légifrance article version effective1January2024, personally read wholeI–X/operative neighbours16November2026 via actualweb. OrdinaryCLI403retained. Derivednative.txt removes only web link-format wrappers, preserving native displayed words; rawresponseSHAseparatelyretained."
}
```

### FR-EXIT-FILING

Departure-yearfollowingfiling and actual annual/event/continued-suspensionformalities and requested-suspension proof apply; this Guide gives no universal filingdate from countrylabels.

```json
{
  "act_article_or_scope": "CGI167bisIX–X all formalities and application provision",
  "actual_read_on": "2026-11-16",
  "id": "FR-EXIT-FILING",
  "official_url": "https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000048806379",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "| France | CGI 167 bis generally requires 6 of 10 prior residence years and household share rights exceeding EUR 800000 or at least 50% profits, with separate earnout/deferred-gain categories. Automatic/requested payment suspension and conditions differ from discharge after 2 years or 5 years when the relevant value exceeds EUR 2570000. Equality at EUR 2570000 belongs to the 2 year side of that value test. Other events, filings and outstanding categories can remain relevant. Sources: [CGI167bisI(1)](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000048806379). |",
    "line": 134
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/fr-cgi167bis-web-native.txt",
  "source_sha256": "d1a27f76e068e710cf46de59c8f05cb0d9049dd13ec003ace0cf6b8dad8e8306",
  "source_version_basis": "Légifrance article version effective1January2024, personally read wholeI–X/operative neighbours16November2026 via actualweb. OrdinaryCLI403retained. Derivednative.txt removes only web link-format wrappers, preserving native displayed words; rawresponseSHAseparatelyretained."
}
```

### EU883-PERSONAL-MATERIAL-SCOPE

EUcoordination applies only to its actual persons/material schemes and exclusions, with equal-treatment conditions; nationality/residence and branch facts precede application.

```json
{
  "act_article_or_scope": "Reg883/2004 Arts2–4 complete",
  "actual_read_on": "2026-11-16",
  "id": "EU883-PERSONAL-MATERIAL-SCOPE",
  "official_url": "https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "Income-tax residence does not determine social-insurance coverage. EU coordination assigns applicable legislation under its own work/posting/multistate rules. The SSA's September 2026 table lists 31 US totalization agreements, including Romania from 1 September 2026; an agreement's actual personal/material scope, detached-worker or self-employed rules and coverage certificate must be established. An agreement is not an automatic exemption from both systems. Sources: [Reg883/2004 Art11 all5paragraphs](https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1); [POMS GN01701.005 country/effective-date table](https://secure.ssa.gov/apps10/poms.nsf/lnx/0201701005).",
    "line": 124
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/eu883-retained.txt",
  "source_sha256": "fe0f959b1fea62409e8fa27eb1288fc2204c316ee897fd0520201337a300fc87",
  "source_version_basis": "Actual retained official XHTML2019-07-31consolidation008.001, downloaded15November2026; own operative/neighbour read16November2026. EarlierEUR-Lexrobot/CLI202failures retained honestly; not wholelaw read or automaticthirdcountry/EEA/Swiss extension proof."
}
```

### EU883-SINGLE-APPLICABLE-LAW

Within scope, one MemberStatelegislation applies under actual activity/nonactivity/civilservice/unemployment/service/sea/air rules, subject to12–16; income-taxresidence alone is not selection rule.

```json
{
  "act_article_or_scope": "Reg883/2004 Art11 all5paragraphs",
  "actual_read_on": "2026-11-16",
  "id": "EU883-SINGLE-APPLICABLE-LAW",
  "official_url": "https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "Income-tax residence does not determine social-insurance coverage. EU coordination assigns applicable legislation under its own work/posting/multistate rules. The SSA's September 2026 table lists 31 US totalization agreements, including Romania from 1 September 2026; an agreement's actual personal/material scope, detached-worker or self-employed rules and coverage certificate must be established. An agreement is not an automatic exemption from both systems. Sources: [Reg883/2004 Art11 all5paragraphs](https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1); [POMS GN01701.005 country/effective-date table](https://secure.ssa.gov/apps10/poms.nsf/lnx/0201701005).",
    "line": 124
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/eu883-retained.txt",
  "source_sha256": "fe0f959b1fea62409e8fa27eb1288fc2204c316ee897fd0520201337a300fc87",
  "source_version_basis": "Actual retained official XHTML2019-07-31consolidation008.001, downloaded15November2026; own operative/neighbour read16November2026. EarlierEUR-Lexrobot/CLI202failures retained honestly; not wholelaw read or automaticthirdcountry/EEA/Swiss extension proof."
}
```

### EU883-POSTING

Employerposting has employeractivity, workonbehalf, anticipated24monthlimit and nonreplacement conditions; normal selfemployment/similaractivity posting has its own24monthcondition.

```json
{
  "act_article_or_scope": "Reg883/2004 Art12 bothparagraphs",
  "actual_read_on": "2026-11-16",
  "id": "EU883-POSTING",
  "official_url": "https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "Income-tax residence does not determine social-insurance coverage. EU coordination assigns applicable legislation under its own work/posting/multistate rules. The SSA's September 2026 table lists 31 US totalization agreements, including Romania from 1 September 2026; an agreement's actual personal/material scope, detached-worker or self-employed rules and coverage certificate must be established. An agreement is not an automatic exemption from both systems. Sources: [Reg883/2004 Art11 all5paragraphs](https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1); [POMS GN01701.005 country/effective-date table](https://secure.ssa.gov/apps10/poms.nsf/lnx/0201701005).",
    "line": 124
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/eu883-retained.txt",
  "source_sha256": "fe0f959b1fea62409e8fa27eb1288fc2204c316ee897fd0520201337a300fc87",
  "source_version_basis": "Actual retained official XHTML2019-07-31consolidation008.001, downloaded15November2026; own operative/neighbour read16November2026. EarlierEUR-Lexrobot/CLI202failures retained honestly; not wholelaw read or automaticthirdcountry/EEA/Swiss extension proof."
}
```

### EU883-MULTISTATE

Multistate employee employer/residence/substantialactivity tests differ from selfemployedcentreinterest and mixedemployed/selfemployed/civilservice routes; allactivities/income treated within selectedlaw.

```json
{
  "act_article_or_scope": "Reg883/2004 Art13 all5paragraphs",
  "actual_read_on": "2026-11-16",
  "id": "EU883-MULTISTATE",
  "official_url": "https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "Income-tax residence does not determine social-insurance coverage. EU coordination assigns applicable legislation under its own work/posting/multistate rules. The SSA's September 2026 table lists 31 US totalization agreements, including Romania from 1 September 2026; an agreement's actual personal/material scope, detached-worker or self-employed rules and coverage certificate must be established. An agreement is not an automatic exemption from both systems. Sources: [Reg883/2004 Art11 all5paragraphs](https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1); [POMS GN01701.005 country/effective-date table](https://secure.ssa.gov/apps10/poms.nsf/lnx/0201701005).",
    "line": 124
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/eu883-retained.txt",
  "source_sha256": "fe0f959b1fea62409e8fa27eb1288fc2204c316ee897fd0520201337a300fc87",
  "source_version_basis": "Actual retained official XHTML2019-07-31consolidation008.001, downloaded15November2026; own operative/neighbour read16November2026. EarlierEUR-Lexrobot/CLI202failures retained honestly; not wholelaw read or automaticthirdcountry/EEA/Swiss extension proof."
}
```

### EU883-EXCEPTIONS

Competentauthorities may agree exceptions in actualpersons/categories interests; pensioner request exemption has no employment/selfemployment condition.

```json
{
  "act_article_or_scope": "Reg883/2004 Art16 bothparagraphs",
  "actual_read_on": "2026-11-16",
  "id": "EU883-EXCEPTIONS",
  "official_url": "https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "Income-tax residence does not determine social-insurance coverage. EU coordination assigns applicable legislation under its own work/posting/multistate rules. The SSA's September 2026 table lists 31 US totalization agreements, including Romania from 1 September 2026; an agreement's actual personal/material scope, detached-worker or self-employed rules and coverage certificate must be established. An agreement is not an automatic exemption from both systems. Sources: [Reg883/2004 Art11 all5paragraphs](https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1); [POMS GN01701.005 country/effective-date table](https://secure.ssa.gov/apps10/poms.nsf/lnx/0201701005).",
    "line": 124
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/eu883-retained.txt",
  "source_sha256": "fe0f959b1fea62409e8fa27eb1288fc2204c316ee897fd0520201337a300fc87",
  "source_version_basis": "Actual retained official XHTML2019-07-31consolidation008.001, downloaded15November2026; own operative/neighbour read16November2026. EarlierEUR-Lexrobot/CLI202failures retained honestly; not wholelaw read or automaticthirdcountry/EEA/Swiss extension proof."
}
```

### TH-LTR-17-SCOPE

The 17% withholding treatment is for qualifying foreign Highly-Skilled Professional LTR employment with eligible target-industry companies/partnerships under the specified laws and DG conditions, rather than all LTR holders.

```json
{
  "act_article_or_scope": "RD743 Art3 first paragraph, printed30/PDF2; exact article header, all linked employer-law and ordinary-rate conditions",
  "actual_read_on": "2026-11-16",
  "correction_own_read_on": "2026-11-16",
  "final_native_delta_evidence": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/final-native-delta/resolutions.json",
  "id": "TH-LTR-17-SCOPE",
  "official_url": "https://ltr.boi.go.th/documents/Royal%20Decree%20issued%20under%20the%20Revenue%20Code%20No.743%20(TH).pdf",
  "quote_mode": "Full assigned actual public-law operative clause, losslessly split into ordered contiguous native fragments <=25 words and <=240 characters; manually read operative scope and neighbours.",
  "section": {
    "actual_text": "Thailand's LTR is an initial 5 years and conditional further 5 years. Decree 743 Arts 3–4 apply the 17% rate to qualifying Highly-Skilled Professional employment with the specified eligible employers; the alternative normal withholding, consent, no-refund/no-credit and return conditions matter. Notification 427 additionally requires the qualifying employer's notice and applies relief to income from the notice-receipt date, with timely PND95 filing and loss of relief for a noncompliant year. Art 5's exemption for the other 3 named LTR categories is a separate foreign-income rule expressly referring to prior tax years. “All LTR holders pay 17%” is incorrect. [Native Decree 743](https://ltr.boi.go.th/documents/Royal%20Decree%20issued%20under%20the%20Revenue%20Code%20No.743%20(TH).pdf); [implementing Notification 427](https://ltr.boi.go.th/documents/Notification%20of%20Income%20Tax%20No.%20427%20(TH).pdf). Do not execute a same-year foreign-income exemption without resolving that provision's exact application.",
    "line": 106
  },
  "short_exact_native_quotes": [
    "มาตรา ๓ ให้ลดอัตราภาษีเงินได้ในการหักภาษี ณ ที่จ่าย และคงจัดเก็บในอัตราร้อยละ สิ บ เจ็ ด ของเงิ น ได้ ส าหรั บ เงิ น ได้ พึ ง ประเมิ น ที่ ค"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/th-rd743.pdf",
  "source_sha256": "ed4c42450dd004c8a939ddfb3d699390413c29f9f8eca3ae71fef704a16818c2",
  "source_validation": "Own actual rendered PDF2–3 re-read16November2026. Complete article headers are line-anchored with whole Thai numeral tokens; no prefix match to cross-reference50. Printed margin headers only removed from extracted body. Each complete assigned clause manually compared against the actual rendered operative pages.",
  "source_version_basis": "Native RoyalDecree743/2565 or DGNotification427 as specified; own full visual read16November2026. Fresh independent visual extract review pending.",
  "visual_evidence_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/thai-manual-native-extracts.json"
}
```

### TH-LTR-17-LOWER-WITHHOLDING

Where the normal statutory withholding is lower, the special exclusion route requires allowing the payer to withhold 17%; it is not an unconditional reduction below normal tax.

```json
{
  "act_article_or_scope": "RD743 Art3 second paragraph whole, printed30/PDF2; first-paragraph dependency, lower ordinary withholding and consent",
  "actual_read_on": "2026-11-16",
  "correction_own_read_on": "2026-11-16",
  "final_native_delta_evidence": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/final-native-delta/resolutions.json",
  "id": "TH-LTR-17-LOWER-WITHHOLDING",
  "official_url": "https://ltr.boi.go.th/documents/Royal%20Decree%20issued%20under%20the%20Revenue%20Code%20No.743%20(TH).pdf",
  "quote_mode": "Full assigned actual public-law operative clause, losslessly split into ordered contiguous native fragments <=25 words and <=240 characters; manually read operative scope and neighbours.",
  "section": {
    "actual_text": "Thailand's LTR is an initial 5 years and conditional further 5 years. Decree 743 Arts 3–4 apply the 17% rate to qualifying Highly-Skilled Professional employment with the specified eligible employers; the alternative normal withholding, consent, no-refund/no-credit and return conditions matter. Notification 427 additionally requires the qualifying employer's notice and applies relief to income from the notice-receipt date, with timely PND95 filing and loss of relief for a noncompliant year. Art 5's exemption for the other 3 named LTR categories is a separate foreign-income rule expressly referring to prior tax years. “All LTR holders pay 17%” is incorrect. [Native Decree 743](https://ltr.boi.go.th/documents/Royal%20Decree%20issued%20under%20the%20Revenue%20Code%20No.743%20(TH).pdf); [implementing Notification 427](https://ltr.boi.go.th/documents/Notification%20of%20Income%20Tax%20No.%20427%20(TH).pdf). Do not execute a same-year foreign-income exemption without resolving that provision's exact application.",
    "line": 106
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/th-rd743.pdf",
  "source_sha256": "ed4c42450dd004c8a939ddfb3d699390413c29f9f8eca3ae71fef704a16818c2",
  "source_validation": "Own actual rendered PDF2–3 re-read16November2026. Complete article headers are line-anchored with whole Thai numeral tokens; no prefix match to cross-reference50. Printed margin headers only removed from extracted body. Each complete assigned clause manually compared against the actual rendered operative pages.",
  "source_version_basis": "Native RoyalDecree743/2565 or DGNotification427 as specified; own full visual read16November2026. Fresh independent visual extract review pending.",
  "visual_evidence_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/thai-manual-native-extracts.json"
}
```

### TH-LTR-17-FINALITY

The excluded-income treatment has the actual no-refund/no-credit condition, including partial claims, and declaration of excluded income remains required; other elected section40(4)/(8) items need their own full conditions.

```json
{
  "act_article_or_scope": "RD743 Art4 all3 paragraphs, printed30–31/PDF2–3; full no-refund/credit, s40(4)/(8) election and excluded-income declaration clauses",
  "actual_read_on": "2026-11-16",
  "correction_own_read_on": "2026-11-16",
  "final_native_delta_evidence": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/final-native-delta/resolutions.json",
  "id": "TH-LTR-17-FINALITY",
  "official_url": "https://ltr.boi.go.th/documents/Royal%20Decree%20issued%20under%20the%20Revenue%20Code%20No.743%20(TH).pdf",
  "quote_mode": "Full assigned actual public-law operative clause, losslessly split into ordered contiguous native fragments <=25 words and <=240 characters; manually read operative scope and neighbours.",
  "section": {
    "actual_text": "Thailand's LTR is an initial 5 years and conditional further 5 years. Decree 743 Arts 3–4 apply the 17% rate to qualifying Highly-Skilled Professional employment with the specified eligible employers; the alternative normal withholding, consent, no-refund/no-credit and return conditions matter. Notification 427 additionally requires the qualifying employer's notice and applies relief to income from the notice-receipt date, with timely PND95 filing and loss of relief for a noncompliant year. Art 5's exemption for the other 3 named LTR categories is a separate foreign-income rule expressly referring to prior tax years. “All LTR holders pay 17%” is incorrect. [Native Decree 743](https://ltr.boi.go.th/documents/Royal%20Decree%20issued%20under%20the%20Revenue%20Code%20No.743%20(TH).pdf); [implementing Notification 427](https://ltr.boi.go.th/documents/Notification%20of%20Income%20Tax%20No.%20427%20(TH).pdf). Do not execute a same-year foreign-income exemption without resolving that provision's exact application.",
    "line": 106
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/th-rd743.pdf",
  "source_sha256": "ed4c42450dd004c8a939ddfb3d699390413c29f9f8eca3ae71fef704a16818c2",
  "source_validation": "Own actual rendered PDF2–3 re-read16November2026. Complete article headers are line-anchored with whole Thai numeral tokens; no prefix match to cross-reference50. Printed margin headers only removed from extracted body. Each complete assigned clause manually compared against the actual rendered operative pages.",
  "source_version_basis": "Native RoyalDecree743/2565 or DGNotification427 as specified; own full visual read16November2026. Fresh independent visual extract review pending.",
  "visual_evidence_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/thai-manual-native-extracts.json"
}
```

### TH-LTR-FOREIGN-INCOME

The separate foreign-income exemption names wealthy-global, foreign-pensioner and work-from-Thailand LTR categories, specified prior-tax-year foreign work/business/property income and actual remittance; a blanket same-year/all-LTR exemption is not established.

```json
{
  "act_article_or_scope": "RD743 Art5 whole, printed31/PDF3; named3categories, specialLTR, s40/prior-year/foreign-source/remittance clause",
  "actual_read_on": "2026-11-16",
  "correction_own_read_on": "2026-11-16",
  "final_native_delta_evidence": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/final-native-delta/resolutions.json",
  "id": "TH-LTR-FOREIGN-INCOME",
  "official_url": "https://ltr.boi.go.th/documents/Royal%20Decree%20issued%20under%20the%20Revenue%20Code%20No.743%20(TH).pdf",
  "quote_mode": "Full assigned actual public-law operative clause, losslessly split into ordered contiguous native fragments <=25 words and <=240 characters; manually read operative scope and neighbours.",
  "section": {
    "actual_text": "Thailand's LTR is an initial 5 years and conditional further 5 years. Decree 743 Arts 3–4 apply the 17% rate to qualifying Highly-Skilled Professional employment with the specified eligible employers; the alternative normal withholding, consent, no-refund/no-credit and return conditions matter. Notification 427 additionally requires the qualifying employer's notice and applies relief to income from the notice-receipt date, with timely PND95 filing and loss of relief for a noncompliant year. Art 5's exemption for the other 3 named LTR categories is a separate foreign-income rule expressly referring to prior tax years. “All LTR holders pay 17%” is incorrect. [Native Decree 743](https://ltr.boi.go.th/documents/Royal%20Decree%20issued%20under%20the%20Revenue%20Code%20No.743%20(TH).pdf); [implementing Notification 427](https://ltr.boi.go.th/documents/Notification%20of%20Income%20Tax%20No.%20427%20(TH).pdf). Do not execute a same-year foreign-income exemption without resolving that provision's exact application.",
    "line": 106
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/th-rd743.pdf",
  "source_sha256": "ed4c42450dd004c8a939ddfb3d699390413c29f9f8eca3ae71fef704a16818c2",
  "source_validation": "Own actual rendered PDF2–3 re-read16November2026. Complete article headers are line-anchored with whole Thai numeral tokens; no prefix match to cross-reference50. Printed margin headers only removed from extracted body. Each complete assigned clause manually compared against the actual rendered operative pages.",
  "source_version_basis": "Native RoyalDecree743/2565 or DGNotification427 as specified; own full visual read16November2026. Fresh independent visual extract review pending.",
  "visual_evidence_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/thai-manual-native-extracts.json"
}
```

### TH-LTR-COMPLIANCE

DG qualifications/procedures/conditions apply and noncompliance terminates benefits for the affected tax year.

```json
{
  "act_article_or_scope": "RD743 Arts6–7 whole, printed31/PDF3; linked conditions and affected-tax-year loss of entitlement",
  "actual_read_on": "2026-11-16",
  "correction_own_read_on": "2026-11-16",
  "final_native_delta_evidence": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/final-native-delta/resolutions.json",
  "id": "TH-LTR-COMPLIANCE",
  "official_url": "https://ltr.boi.go.th/documents/Royal%20Decree%20issued%20under%20the%20Revenue%20Code%20No.743%20(TH).pdf",
  "quote_mode": "Full assigned actual public-law operative clause, losslessly split into ordered contiguous native fragments <=25 words and <=240 characters; manually read operative scope and neighbours.",
  "section": {
    "actual_text": "Thailand's LTR is an initial 5 years and conditional further 5 years. Decree 743 Arts 3–4 apply the 17% rate to qualifying Highly-Skilled Professional employment with the specified eligible employers; the alternative normal withholding, consent, no-refund/no-credit and return conditions matter. Notification 427 additionally requires the qualifying employer's notice and applies relief to income from the notice-receipt date, with timely PND95 filing and loss of relief for a noncompliant year. Art 5's exemption for the other 3 named LTR categories is a separate foreign-income rule expressly referring to prior tax years. “All LTR holders pay 17%” is incorrect. [Native Decree 743](https://ltr.boi.go.th/documents/Royal%20Decree%20issued%20under%20the%20Revenue%20Code%20No.743%20(TH).pdf); [implementing Notification 427](https://ltr.boi.go.th/documents/Notification%20of%20Income%20Tax%20No.%20427%20(TH).pdf). Do not execute a same-year foreign-income exemption without resolving that provision's exact application.",
    "line": 106
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/th-rd743.pdf",
  "source_sha256": "ed4c42450dd004c8a939ddfb3d699390413c29f9f8eca3ae71fef704a16818c2",
  "source_validation": "Own actual rendered PDF2–3 re-read16November2026. Complete article headers are line-anchored with whole Thai numeral tokens; no prefix match to cross-reference50. Printed margin headers only removed from extracted body. Each complete assigned clause manually compared against the actual rendered operative pages.",
  "source_version_basis": "Native RoyalDecree743/2565 or DGNotification427 as specified; own full visual read16November2026. Fresh independent visual extract review pending.",
  "visual_evidence_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/thai-manual-native-extracts.json"
}
```

### TH-LTR-EMPLOYER-NOTICE

The qualifying employer must notify the actual person and supporting material; relief starts for income received from the office's receipt date, applies to actual eligible-employer employment income and is not an automatic visa-date entitlement. Eligibility requires specialLTR visa and continuing BOI qualification; actual eligible employment contract, named employee list and employment/visa/work-permit documents must reach the appropriate local revenue office by the last day of the first claim tax year using the required media. Income relief starts on actual notice receipt, not visa issue; other employer-activity income is excluded.

```json
{
  "act_article_or_scope": "Notification427para2(1)/(2),3lead/3(1)/(2),appendixnotes1–2; all3actualPDFpages visually read; manual native transcription",
  "actual_read_on": "2026-11-16",
  "correction_own_read_on": "2026-11-16",
  "id": "TH-LTR-EMPLOYER-NOTICE",
  "official_url": "https://ltr.boi.go.th/documents/Notification%20of%20Income%20Tax%20No.%20427%20(TH).pdf",
  "quote_mode": "Full assigned actual public-law operative clause, losslessly split into ordered contiguous native fragments <=25 words and <=240 characters; manually read operative scope and neighbours.",
  "section": {
    "actual_text": "Thailand's LTR is an initial 5 years and conditional further 5 years. Decree 743 Arts 3–4 apply the 17% rate to qualifying Highly-Skilled Professional employment with the specified eligible employers; the alternative normal withholding, consent, no-refund/no-credit and return conditions matter. Notification 427 additionally requires the qualifying employer's notice and applies relief to income from the notice-receipt date, with timely PND95 filing and loss of relief for a noncompliant year. Art 5's exemption for the other 3 named LTR categories is a separate foreign-income rule expressly referring to prior tax years. “All LTR holders pay 17%” is incorrect. [Native Decree 743](https://ltr.boi.go.th/documents/Royal%20Decree%20issued%20under%20the%20Revenue%20Code%20No.743%20(TH).pdf); [implementing Notification 427](https://ltr.boi.go.th/documents/Notification%20of%20Income%20Tax%20No.%20427%20(TH).pdf). Do not execute a same-year foreign-income exemption without resolving that provision's exact application.",
    "line": 106
  },
  "short_exact_native_quotes": [
    "ข้อ ๒ คนต่างด้าวกลุ่มผู้มีทักษะเชี่ยวชาญพิเศษ หรือคนต่างด้าวกลุ่มประชากรโลกผู้มีความมั่งคั่งสูง กลุ่มผู้เกษียณอายุจากต่างประเทศ หรือกลุ่มที่ต้องการทำงานจากประเทศไทย ที่จะได้รับสิทธิลดอัตราหรือยกเว้นภาษีเงินได้ตามมาตรา ๓ มาตรา ๔ หรือมาตรา ๕"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/th-notification427.pdf",
  "source_sha256": "ffff6a36c8fef349ea9926839d85c243ed4b2c4ad4ec27901fbb5c94092cb09f",
  "source_validation": "Own manual transcription from actual rendered3page officialPDF; garbled encoded pdftotext is not literal-match proof.",
  "source_version_basis": "Native RoyalDecree743/2565 or DGNotification427 as specified; own full visual read16November2026. Fresh independent visual extract review pending.",
  "visual_evidence_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/thai-manual-native-extracts.json"
}
```

### TH-LTR-PND95

PND95 must be filed by the statutory/extended time; failure of the employee conditions removes exemption for that tax year. Notice effective1September2565/2022.

```json
{
  "act_article_or_scope": "Notification427para3(3)/(4) and4 whole; actualPDFp2 manually visually reread",
  "actual_read_on": "2026-11-16",
  "correction_own_read_on": "2026-11-16",
  "id": "TH-LTR-PND95",
  "official_url": "https://ltr.boi.go.th/documents/Notification%20of%20Income%20Tax%20No.%20427%20(TH).pdf",
  "quote_mode": "Full assigned actual public-law operative clause, losslessly split into ordered contiguous native fragments <=25 words and <=240 characters; manually read operative scope and neighbours.",
  "section": {
    "actual_text": "Thailand's LTR is an initial 5 years and conditional further 5 years. Decree 743 Arts 3–4 apply the 17% rate to qualifying Highly-Skilled Professional employment with the specified eligible employers; the alternative normal withholding, consent, no-refund/no-credit and return conditions matter. Notification 427 additionally requires the qualifying employer's notice and applies relief to income from the notice-receipt date, with timely PND95 filing and loss of relief for a noncompliant year. Art 5's exemption for the other 3 named LTR categories is a separate foreign-income rule expressly referring to prior tax years. “All LTR holders pay 17%” is incorrect. [Native Decree 743](https://ltr.boi.go.th/documents/Royal%20Decree%20issued%20under%20the%20Revenue%20Code%20No.743%20(TH).pdf); [implementing Notification 427](https://ltr.boi.go.th/documents/Notification%20of%20Income%20Tax%20No.%20427%20(TH).pdf). Do not execute a same-year foreign-income exemption without resolving that provision's exact application.",
    "line": 106
  },
  "short_exact_native_quotes": [
    "(๓) ต้องยื่นแบบแสดงรายการภาษีเงินได้บุคคลธรรมดาสำหรับคนต่างด้าวผู้มีเงินได้จากการจ้างแรงงาน (ภ.ง.ด.๙๕) สำหรับปีภาษีที่ประสงค์จะใช้สิทธิลดอัตราหรือยกเว้นภาษีเงินได้ ตามกำหนดเวลาที่กฎหมายกำหนดหรือที่ได้รับการขยายกำหนดเวลา (๔)"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/th-notification427.pdf",
  "source_sha256": "ffff6a36c8fef349ea9926839d85c243ed4b2c4ad4ec27901fbb5c94092cb09f",
  "source_validation": "Own manual transcription from actual rendered3page officialPDF; garbled encoded pdftotext is not literal-match proof.",
  "source_version_basis": "Native RoyalDecree743/2565 or DGNotification427 as specified; own full visual read16November2026. Fresh independent visual extract review pending.",
  "visual_evidence_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/thai-manual-native-extracts.json"
}
```

### KY-ARCHIVED-PIT

Archived Cayman government page says no income tax; this dated archive is not an all-taxes/all-foreign-rights assurance.

```json
{
  "act_article_or_scope": "Archived government economy page, Taxes paragraph",
  "actual_read_on": "2026-11-16",
  "id": "KY-ARCHIVED-PIT",
  "official_url": "https://cigarchives.gov.ky/economy",
  "quote_mode": "Short literal source-native fragments; full operative paragraphs and neighbours personally read. Discontinuous fragments remain separate; no claim of contiguous whole-paragraph reconstruction.",
  "section": {
    "actual_text": "Cayman's current Ministry describes duties/fees and an indirect consumption-based model and expressly preserves other countries' taxing rights. Its archived government page expressly says no income tax. A final current-law conclusion must disclose this dated basis; the old “total tax freedom” promise and universal USD 18000–24000 annual residence cost have no source support in that material. [Current Ministry](https://gov.ky/web/mfsc/regulation); archived government economy page retained in the evidence. Sources: [Archived government economy page](https://cigarchives.gov.ky/economy); [Taxation section](https://gov.ky/web/mfsc/regulation).",
    "line": 73
  },
  "short_exact_native_quotes": [
    "There is no income tax"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/ky-tax-archive-web.txt",
  "source_sha256": "1711dbff5d9467ffe6f665eb3d431000dc1714e48ddc5dd0eeaeadba378746c0",
  "source_version_basis": "Actual whole40line archived page read16November2026, operative20–25. Page contains2019/2020economiccontext; currentMinistry guidance separately read; CLI403honestly retained."
}
```

### KY-CURRENT-INDIRECT-MODEL

Current Ministry describes duties/fees and indirect consumption model and expressly preserves other countries taxing rights.

```json
{
  "act_article_or_scope": "Taxation section, revenue model and other-country rights paragraphs",
  "actual_read_on": "2026-11-16",
  "id": "KY-CURRENT-INDIRECT-MODEL",
  "official_url": "https://gov.ky/web/mfsc/regulation",
  "quote_mode": "Short literal source-native fragments; full operative paragraphs and neighbours personally read. Discontinuous fragments remain separate; no claim of contiguous whole-paragraph reconstruction.",
  "section": {
    "actual_text": "Cayman's current Ministry describes duties/fees and an indirect consumption-based model and expressly preserves other countries' taxing rights. Its archived government page expressly says no income tax. A final current-law conclusion must disclose this dated basis; the old “total tax freedom” promise and universal USD 18000–24000 annual residence cost have no source support in that material. [Current Ministry](https://gov.ky/web/mfsc/regulation); archived government economy page retained in the evidence. Sources: [Archived government economy page](https://cigarchives.gov.ky/economy); [Taxation section](https://gov.ky/web/mfsc/regulation).",
    "line": 73
  },
  "short_exact_native_quotes": [
    "duties and fees"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/ky-current-taxation.txt",
  "source_sha256": "4558c0096a20e0040887aa17738a62c44e94f9910286b2b1f82ed7b529743cdb",
  "source_version_basis": "Own actual full current official Taxation subsection and operative neighbours read16November2026; no statutory negative search inferred."
}
```

### BS-NO-PIT-DATED

The dated2024official guidance states no domestic PITregime, not absence of immigration/business/social/property/foreign duties.

```json
{
  "act_article_or_scope": "2024MAPguidance printed3, taxesscope section",
  "actual_read_on": "2026-11-16",
  "id": "BS-NO-PIT-DATED",
  "official_url": "https://cdn.bahamas.gov.bs/tenant/tenantministryoffinance/documents/All%20Documents/BAHAMAS-JAPANMAPGUIDANCEDOCUMENT-20240718120503.pdf",
  "quote_mode": "Short literal source-native fragments; full operative paragraphs and neighbours personally read. Discontinuous fragments remain separate; no claim of contiguous whole-paragraph reconstruction.",
  "section": {
    "actual_text": "The Bahamas finance authority's dated MAP guidance expressly says it has no personal income-tax regime. That does not eliminate business, insurance, consumption, property, immigration or foreign-country obligations. The old approximately USD 1000 annual cost is not an established all-in permanent-residence cost. The current economic-permanent-residence route requires at least BSD 1000000 in qualifying real estate or Central Bank zero-coupon bonds, held for at least 10 years. The BSD 200 nonrefundable processing fee is not an all-in residence cost. The historical no-PIT source and current immigration conditions have different dates. Sources: [2024MAPguidance printed3](https://cdn.bahamas.gov.bs/tenant/tenantministryoffinance/documents/All%20Documents/BAHAMAS-JAPANMAPGUIDANCEDOCUMENT-20240718120503.pdf); [Economicpermanentresidence eligibility and application processing fee](https://www.immigration.gov.bs/residence/permanent-residence/).",
    "line": 75
  },
  "short_exact_native_quotes": [
    "The Bahamas does not have a domestic personal income tax regime."
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/bs-map.txt",
  "source_sha256": "c4ae36d1cdfc8341b04937782c9d21badb38f76667566f0b0eb5f837dbfe0de0",
  "source_version_basis": "Actual whole12page official MAPguidance read16November2026; dated18July2024file/sourcebasis explicitly retained."
}
```

### BS-ECONOMIC-RESIDENCE

Published economicroute needs minimum1million investment via realestate or CentralBankzerocouponbonds held10years;200processingfee not universal1000annualtotal. Other eligibilitycategories separately exist.

```json
{
  "act_article_or_scope": "Economicpermanentresidence eligibility and application processing fee",
  "actual_read_on": "2026-11-16",
  "id": "BS-ECONOMIC-RESIDENCE",
  "official_url": "https://www.immigration.gov.bs/residence/permanent-residence/",
  "quote_mode": "Short literal source-native fragments; full operative paragraphs and neighbours personally read. Discontinuous fragments remain separate; no claim of contiguous whole-paragraph reconstruction.",
  "section": {
    "actual_text": "The Bahamas finance authority's dated MAP guidance expressly says it has no personal income-tax regime. That does not eliminate business, insurance, consumption, property, immigration or foreign-country obligations. The old approximately USD 1000 annual cost is not an established all-in permanent-residence cost. The current economic-permanent-residence route requires at least BSD 1000000 in qualifying real estate or Central Bank zero-coupon bonds, held for at least 10 years. The BSD 200 nonrefundable processing fee is not an all-in residence cost. The historical no-PIT source and current immigration conditions have different dates. Sources: [2024MAPguidance printed3](https://cdn.bahamas.gov.bs/tenant/tenantministryoffinance/documents/All%20Documents/BAHAMAS-JAPANMAPGUIDANCEDOCUMENT-20240718120503.pdf); [Economicpermanentresidence eligibility and application processing fee](https://www.immigration.gov.bs/residence/permanent-residence/).",
    "line": 75
  },
  "short_exact_native_quotes": [
    "$1.0 million"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/bs-residence-web.txt",
  "source_sha256": "92b901a7d0161897c5c237c10b4d374ad120fef9764d3d26eab6398f76b15c1e",
  "source_version_basis": "Own actual full operative official page9–64and neighbouring/footer context read16November2026; actual webbody retained; freshCLIremote-close failure retained."
}
```

### MC-PIT-SCOPE

Government describes resident/Monegasque PITabsence, exception for Frenchnationals under1963bilateralconvention, and actual/effective-establishment condition.

```json
{
  "act_article_or_scope": "Fiscalité des personnes physiques paragraph",
  "actual_read_on": "2026-11-16",
  "id": "MC-PIT-SCOPE",
  "official_url": "https://monservicepublic.gouv.mc/thematiques/fiscalite/informations-sur-la-fiscalite/informations-generales/la-fiscalite-monegasque",
  "quote_mode": "Short literal source-native fragments; full operative paragraphs and neighbours personally read. Discontinuous fragments remain separate; no claim of contiguous whole-paragraph reconstruction.",
  "section": {
    "actual_text": "Monaco's current government personal-tax guidance has the French-national treaty exception. Its residence-permit financial-resource test does not establish a universal EUR 500000 deposit for everyone. A permit, bank's commercial deposit policy and tax residence are different questions. The original “ultra-high-net-worth only” label is not a statutory eligibility rule. Sources: [Fiscalité des personnes physiques paragraph](https://monservicepublic.gouv.mc/thematiques/fiscalite/informations-sur-la-fiscalite/informations-generales/la-fiscalite-monegasque); [Conditions](https://monservicepublic.gouv.mc/en/themes/nationality-and-residency/residency/new-entrants/how-to-apply-for-a-residence-permit).",
    "line": 77
  },
  "short_exact_native_quotes": [
    "à l’exception des nationaux français"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/mc-tax-native.txt",
  "source_sha256": "183f6671ecb32ad1a41f0ff54bd9b87c00d789b87ff11bebc7a5811dcf31282b",
  "source_version_basis": "Current nativegovernmentpage actual operative and neighbours personally read16November2026; sourceupdate27August2026."
}
```

### MC-RESIDENCE-RESOURCES

Permit resource criteria include alternatives and a sufficient-savings measure dependent on the bank, rather than universal500000deposit or ultrawealth-only rule.

```json
{
  "act_article_or_scope": "OfficialConditions1651–1655; documentary neighbours2602–2609/2672–2673",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": [
    "Resources may be evidenced through salary, professional income from an independent commercial activity or a company, sufficient savings, or support by a relative/spouse/cohabiting partner.",
    "The bank providing the reference judges sufficient savings; there is no universal EUR500000 deposit in these conditions.",
    "Support evidence includes the supporting person’s letter and their financial-resource evidence; savings evidence includes an approved-format Monaco bank reference less than1month old. Individual other evidence is determined with the residence section."
  ],
  "correction_own_read_on": "2026-11-16",
  "id": "MC-RESIDENCE-RESOURCES",
  "official_url": "https://monservicepublic.gouv.mc/en/themes/nationality-and-residency/residency/new-entrants/how-to-apply-for-a-residence-permit",
  "quote_mode": "Permitted short claim-bound native extracts retained within total per-source quote cap; full original condition paraphrase and exact locators supplied. Does not claim full native-clause reproduction.",
  "section": {
    "actual_text": "Monaco's current government personal-tax guidance has the French-national treaty exception. Its residence-permit financial-resource test does not establish a universal EUR 500000 deposit for everyone. A permit, bank's commercial deposit policy and tax residence are different questions. The original “ultra-high-net-worth only” label is not a statutory eligibility rule. Sources: [Fiscalité des personnes physiques paragraph](https://monservicepublic.gouv.mc/thematiques/fiscalite/informations-sur-la-fiscalite/informations-generales/la-fiscalite-monegasque); [Conditions](https://monservicepublic.gouv.mc/en/themes/nationality-and-residency/residency/new-entrants/how-to-apply-for-a-residence-permit).",
    "line": 77
  },
  "short_exact_native_quotes": [
    "salary"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/mc-residence.txt",
  "source_sha256": "bf2a431eccf4330ce51f2c2fb3684722062cae175d8d7abbcfeb983bce34065d",
  "source_version_basis": "Actual official English permit conditions and supporting-document sections personally read16November2026; not a privatebankcontract or taxresidence certificate."
}
```

### US-TOTALIZATION-31-COUNTRY-TABLE

Actual current SSA table has31countryagreements includingRomaniaeffective1September2026; count is independently recomputed from source rows, not a fabricated literal31quotation.

```json
{
  "act_article_or_scope": "POMS GN01701.005 country/effective-date table, all31countries",
  "actual_read_on": "2026-11-16",
  "id": "US-TOTALIZATION-31-COUNTRY-TABLE",
  "official_url": "https://secure.ssa.gov/apps10/poms.nsf/lnx/0201701005",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "Income-tax residence does not determine social-insurance coverage. EU coordination assigns applicable legislation under its own work/posting/multistate rules. The SSA's September 2026 table lists 31 US totalization agreements, including Romania from 1 September 2026; an agreement's actual personal/material scope, detached-worker or self-employed rules and coverage certificate must be established. An agreement is not an automatic exemption from both systems. Sources: [Reg883/2004 Art11 all5paragraphs](https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1); [POMS GN01701.005 country/effective-date table](https://secure.ssa.gov/apps10/poms.nsf/lnx/0201701005).",
    "line": 124
  },
  "short_exact_native_quotes": [
    "Country Effective Date"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/us-ssa-agreements.txt",
  "source_sha256": "6d533b233b7ac3e2cdd6f65c1076e2c522d608921ebff81de61b56e306e4d143",
  "source_version_basis": "SSA TN20/17September2026actualtable personally read; independent count storedssa-table-derived.json. UKonecountrywith2differentprovisiondates; footer not a country."
}
```

### PT-REMOTE-RESIDENCE-VISA

Remote-workresidencevisa application requires actual foreignwork/service evidence, average3monthlyprofessionalearningsatleast4RMMGand taxresidence proof; this is not automatic tax-relief entitlement.

```json
{
  "act_article_or_scope": "RegulatoryDecree4/2022 inserted31-A(1), complete; printed41/PDF14",
  "actual_read_on": "2026-11-16",
  "id": "PT-REMOTE-RESIDENCE-VISA",
  "official_url": "https://files.dre.pt/1s/2022/09/19000/0002800097.pdf",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "Portugal's temporary-stay and residence-visa routes for foreign remote work are distinct. The remote-work funding test is four times the applicable continental minimum wage, averaged over the preceding 3 months. With the 2026 continental minimum of EUR 920, the derived income amount is EUR 3680 monthly. Distinguish either visa from the conditional 2-year residence permit, renewable for 3 years. Portuguese citizens moving to a listed low-tax jurisdiction also need CIRS Art 16(6)–(7): residence can continue for the departure year and 4 further years, subject to the stated reasonable-ground and different-jurisdiction exceptions. Repeal of NHR does not erase protected existing or transitional cases. IFICI requires its own qualifying activities, prior 5-year nonresidence and registration conditions; its 20% net employment/self-employment treatment for 10 consecutive years is not a D8 entitlement. Sources: [RegulatoryDecree4/2022 inserted31-A(1)](https://files.dre.pt/1s/2022/09/19000/0002800097.pdf); [DecreeLaw139/2025 Arts2–3](https://files.diariodarepublica.pt/1s/2025/12/24900/0001400016.pdf); [AIMA Notes](https://aima.gov.pt/pt/trabalhar/autorizacao-de-residencia-para-o-exercicio-de-atividade-profissional-prestada-de-forma-remota-com-visto-de-residencia-para-o-exe); [CIRS16(6)–(7)](https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/cirs_rep/Pages/irs16.aspx); [EBF58A(1)](https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/bf_rep/Pages/ebf58a.aspx).",
    "line": 94
  },
  "short_exact_native_quotes": [
    "1 — O pedido de visto de residência para o exercício de atividade profissional prestada de forma remota, previsto no artigo 61.º-B da Lei n.º"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/pt-remote-reg2022.txt",
  "source_sha256": "d9ae29c9a207265b8605f003ff37eebe24dc486f28e2d919fd6753de9c6b9649",
  "source_version_basis": "Actual native2022instrument personally read operative and neighbours. Quoted31A1only; legacy in-country31A2route not asserted as current instruction; currentAIMApermitpage separately read."
}
```

### PT-REMOTE-TEMP-VISA

Temporary-stay remote-workvisa is a distinctroute with documentaryalternatives,3monthaverage4RMMGand taxresidence proof; do not collapse all D8routes into1yearplusrenewal.

```json
{
  "act_article_or_scope": "RegulatoryDecree4/2022 inserted18-B, whole assigned clause",
  "actual_read_on": "2026-11-16",
  "id": "PT-REMOTE-TEMP-VISA",
  "official_url": "https://files.dre.pt/1s/2022/09/19000/0002800097.pdf",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "Portugal's temporary-stay and residence-visa routes for foreign remote work are distinct. The remote-work funding test is four times the applicable continental minimum wage, averaged over the preceding 3 months. With the 2026 continental minimum of EUR 920, the derived income amount is EUR 3680 monthly. Distinguish either visa from the conditional 2-year residence permit, renewable for 3 years. Portuguese citizens moving to a listed low-tax jurisdiction also need CIRS Art 16(6)–(7): residence can continue for the departure year and 4 further years, subject to the stated reasonable-ground and different-jurisdiction exceptions. Repeal of NHR does not erase protected existing or transitional cases. IFICI requires its own qualifying activities, prior 5-year nonresidence and registration conditions; its 20% net employment/self-employment treatment for 10 consecutive years is not a D8 entitlement. Sources: [RegulatoryDecree4/2022 inserted31-A(1)](https://files.dre.pt/1s/2022/09/19000/0002800097.pdf); [DecreeLaw139/2025 Arts2–3](https://files.diariodarepublica.pt/1s/2025/12/24900/0001400016.pdf); [AIMA Notes](https://aima.gov.pt/pt/trabalhar/autorizacao-de-residencia-para-o-exercicio-de-atividade-profissional-prestada-de-forma-remota-com-visto-de-residencia-para-o-exe); [CIRS16(6)–(7)](https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/cirs_rep/Pages/irs16.aspx); [EBF58A(1)](https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/bf_rep/Pages/ebf58a.aspx).",
    "line": 94
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/pt-remote-reg2022.txt",
  "source_sha256": "d9ae29c9a207265b8605f003ff37eebe24dc486f28e2d919fd6753de9c6b9649",
  "source_version_basis": "Actual native2022instrument operative/neighbours personally read; general visa duration not supplied from this single clause."
}
```

### PT-2026-CONTINENTAL-MINWAGE

ContinentalRMMGisEUR920for2026; derived4times visa-resource amount is3680, not original3500. The multiplier/sourceperiod must also be established.

```json
{
  "act_article_or_scope": "DecreeLaw139/2025 Arts2–3, mainland scope and920amount",
  "actual_read_on": "2026-11-16",
  "id": "PT-2026-CONTINENTAL-MINWAGE",
  "official_url": "https://files.diariodarepublica.pt/1s/2025/12/24900/0001400016.pdf",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "Portugal's temporary-stay and residence-visa routes for foreign remote work are distinct. The remote-work funding test is four times the applicable continental minimum wage, averaged over the preceding 3 months. With the 2026 continental minimum of EUR 920, the derived income amount is EUR 3680 monthly. Distinguish either visa from the conditional 2-year residence permit, renewable for 3 years. Portuguese citizens moving to a listed low-tax jurisdiction also need CIRS Art 16(6)–(7): residence can continue for the departure year and 4 further years, subject to the stated reasonable-ground and different-jurisdiction exceptions. Repeal of NHR does not erase protected existing or transitional cases. IFICI requires its own qualifying activities, prior 5-year nonresidence and registration conditions; its 20% net employment/self-employment treatment for 10 consecutive years is not a D8 entitlement. Sources: [RegulatoryDecree4/2022 inserted31-A(1)](https://files.dre.pt/1s/2022/09/19000/0002800097.pdf); [DecreeLaw139/2025 Arts2–3](https://files.diariodarepublica.pt/1s/2025/12/24900/0001400016.pdf); [AIMA Notes](https://aima.gov.pt/pt/trabalhar/autorizacao-de-residencia-para-o-exercicio-de-atividade-profissional-prestada-de-forma-remota-com-visto-de-residencia-para-o-exe); [CIRS16(6)–(7)](https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/cirs_rep/Pages/irs16.aspx); [EBF58A(1)](https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/bf_rep/Pages/ebf58a.aspx).",
    "line": 94
  },
  "short_exact_native_quotes": [
    "Âmbito territorial O presente decreto-lei é aplicável a todo o território continental. Artigo 3.º Valor da"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/pt-minwage2026.txt",
  "source_sha256": "0b304e271d356f68a959a30ae17fc303e44d79467d1bd08498b1a698ad4f818b",
  "source_version_basis": "Native actual3pagePDF personally read; decree dated2025-12-29, effects2026-01-01inArt7."
}
```

### PT-2026-MINWAGE-EFFECT

Decree enters dayafterpublication and produces2026-01-01effects;920source not a2025amount.

```json
{
  "act_article_or_scope": "DecreeLaw139/2025 Art7 complete",
  "actual_read_on": "2026-11-16",
  "id": "PT-2026-MINWAGE-EFFECT",
  "official_url": "https://files.diariodarepublica.pt/1s/2025/12/24900/0001400016.pdf",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "Portugal's temporary-stay and residence-visa routes for foreign remote work are distinct. The remote-work funding test is four times the applicable continental minimum wage, averaged over the preceding 3 months. With the 2026 continental minimum of EUR 920, the derived income amount is EUR 3680 monthly. Distinguish either visa from the conditional 2-year residence permit, renewable for 3 years. Portuguese citizens moving to a listed low-tax jurisdiction also need CIRS Art 16(6)–(7): residence can continue for the departure year and 4 further years, subject to the stated reasonable-ground and different-jurisdiction exceptions. Repeal of NHR does not erase protected existing or transitional cases. IFICI requires its own qualifying activities, prior 5-year nonresidence and registration conditions; its 20% net employment/self-employment treatment for 10 consecutive years is not a D8 entitlement. Sources: [RegulatoryDecree4/2022 inserted31-A(1)](https://files.dre.pt/1s/2022/09/19000/0002800097.pdf); [DecreeLaw139/2025 Arts2–3](https://files.diariodarepublica.pt/1s/2025/12/24900/0001400016.pdf); [AIMA Notes](https://aima.gov.pt/pt/trabalhar/autorizacao-de-residencia-para-o-exercicio-de-atividade-profissional-prestada-de-forma-remota-com-visto-de-residencia-para-o-exe); [CIRS16(6)–(7)](https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/cirs_rep/Pages/irs16.aspx); [EBF58A(1)](https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/bf_rep/Pages/ebf58a.aspx).",
    "line": 94
  },
  "short_exact_native_quotes": [
    "Entrada em vigor e produção de efeitos O presente"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/pt-minwage2026.txt",
  "source_sha256": "0b304e271d356f68a959a30ae17fc303e44d79467d1bd08498b1a698ad4f818b",
  "source_version_basis": "Actual whole3page native source visually/text read; operative/neighbours personally read."
}
```

### PT-REMOTE-PERMIT-DURATION

Conditional remote-workresidencepermit has2years fromtitleissue and successive3yearrenewals; visa and permit differ.

```json
{
  "act_article_or_scope": "AIMA Notes, remote-work temporary-residence permit duration",
  "actual_read_on": "2026-11-16",
  "id": "PT-REMOTE-PERMIT-DURATION",
  "official_url": "https://aima.gov.pt/pt/trabalhar/autorizacao-de-residencia-para-o-exercicio-de-atividade-profissional-prestada-de-forma-remota-com-visto-de-residencia-para-o-exe",
  "quote_mode": "Short literal source-native fragments; full operative paragraphs and neighbours personally read. Discontinuous fragments remain separate; no claim of contiguous whole-paragraph reconstruction.",
  "section": {
    "actual_text": "Portugal's temporary-stay and residence-visa routes for foreign remote work are distinct. The remote-work funding test is four times the applicable continental minimum wage, averaged over the preceding 3 months. With the 2026 continental minimum of EUR 920, the derived income amount is EUR 3680 monthly. Distinguish either visa from the conditional 2-year residence permit, renewable for 3 years. Portuguese citizens moving to a listed low-tax jurisdiction also need CIRS Art 16(6)–(7): residence can continue for the departure year and 4 further years, subject to the stated reasonable-ground and different-jurisdiction exceptions. Repeal of NHR does not erase protected existing or transitional cases. IFICI requires its own qualifying activities, prior 5-year nonresidence and registration conditions; its 20% net employment/self-employment treatment for 10 consecutive years is not a D8 entitlement. Sources: [RegulatoryDecree4/2022 inserted31-A(1)](https://files.dre.pt/1s/2022/09/19000/0002800097.pdf); [DecreeLaw139/2025 Arts2–3](https://files.diariodarepublica.pt/1s/2025/12/24900/0001400016.pdf); [AIMA Notes](https://aima.gov.pt/pt/trabalhar/autorizacao-de-residencia-para-o-exercicio-de-atividade-profissional-prestada-de-forma-remota-com-visto-de-residencia-para-o-exe); [CIRS16(6)–(7)](https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/cirs_rep/Pages/irs16.aspx); [EBF58A(1)](https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/bf_rep/Pages/ebf58a.aspx).",
    "line": 94
  },
  "short_exact_native_quotes": [
    "dois anos contados a partir da data da emissão"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/pt-nomad-aima-curl.txt",
  "source_sha256": "610377a6960969b4fb978acc2a270adf58b4e0c80fbc500249c4991d0774741d",
  "source_version_basis": "Own actual current AIMA operative532–630read, including documents/impediments/legalframework; freshsuccessfulretainedsource not initialTLSfailure."
}
```

### ES-REMOTE-GENERAL-PREREQUISITES

Specificnomadpermission additionally needs actual general entry/residence requirements, criminalrecord/declaration/insurance/resources/fees and publicpolicy conditions; immigrationstatus does not waive tax/social obligations.

```json
{
  "act_article_or_scope": "Law14/2013 Art62 alloperativeparagraphs",
  "actual_read_on": "2026-11-16",
  "id": "ES-REMOTE-GENERAL-PREREQUISITES",
  "official_url": "https://www.boe.es/buscar/act.php?id=BOE-A-2013-10074",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "Spain's telework visa is generally up to 1 year or the shorter work period. Under Law 14/2013, the residence authorisation can be up to 3 years or the shorter work period, with conditional 2-year renewals. The official consular funds test is 200% of SMI for the teleworker,75% for the first accompanying person and 25% for each additional person; the old fixed EUR 2520 is not a current universal threshold. Foreign-employer work, qualifications/experience, actual existing relationship and social-insurance conditions apply. Self-employed Spanish clients are limited to 20% of activity under the immigration rule. LIRPF Art 93's elective regime requires no Spanish residence in the preceding 5 tax periods, a qualifying reason for the move and the relevant activity/no-PE conditions and exceptions. It covers the move year and the following 5 tax periods. Its ordinary base has 24% through EUR 600000 and 47% above; the separately defined investment-income base has different bands. A nomad visa alone neither elects nor proves eligibility for this regime. Sources: [Law14/2013 Art74bis all2paragraphs](https://www.boe.es/buscar/act.php?id=BOE-A-2013-10074); [Documentación que acredite los recursos económicos](https://www.exteriores.gob.es/Consulados/miami/es/ServiciosConsulares/Paginas/index.aspx?scca=Visados&scco=Estados+Unidos&scd=196&scs=Visados+Nacionales+-+Visado+de+residencia+para+teletrabajo+%28n%C3%B3mada+digital%29); [LIRPF93(1)](https://www.boe.es/buscar/act.php?id=BOE-A-2006-20764).",
    "line": 96
  },
  "short_exact_native_quotes": [
    "Artículo 62. Requisitos generales para la estancia o residencia. 1. Sin perjuicio de la acreditación de los requisitos específicos previstos para cada visado o autorización,"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/es-nomad.txt",
  "source_sha256": "cc3af1f97ca5f6fb1c5336bf72026ec15ace0d6f0740085c735f8105c3ef3a4e",
  "source_version_basis": "Actual currentBOEbody personally read4893–5015, all62plus63opening;62latestamendmentinforce2023-05-10as shown. Not wholeLaw."
}
```

### ES-REMOTE-DEFINITION

Foreign-companytelework scope differs for employees and professionals; professional Spanishcompanyactivitynotabove20%; qualifyinggraduate/postgraduate/trainingor3yearprofessionalexperience route.

```json
{
  "act_article_or_scope": "Law14/2013 Art74bis all2paragraphs",
  "actual_read_on": "2026-11-16",
  "id": "ES-REMOTE-DEFINITION",
  "official_url": "https://www.boe.es/buscar/act.php?id=BOE-A-2013-10074",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "Spain's telework visa is generally up to 1 year or the shorter work period. Under Law 14/2013, the residence authorisation can be up to 3 years or the shorter work period, with conditional 2-year renewals. The official consular funds test is 200% of SMI for the teleworker,75% for the first accompanying person and 25% for each additional person; the old fixed EUR 2520 is not a current universal threshold. Foreign-employer work, qualifications/experience, actual existing relationship and social-insurance conditions apply. Self-employed Spanish clients are limited to 20% of activity under the immigration rule. LIRPF Art 93's elective regime requires no Spanish residence in the preceding 5 tax periods, a qualifying reason for the move and the relevant activity/no-PE conditions and exceptions. It covers the move year and the following 5 tax periods. Its ordinary base has 24% through EUR 600000 and 47% above; the separately defined investment-income base has different bands. A nomad visa alone neither elects nor proves eligibility for this regime. Sources: [Law14/2013 Art74bis all2paragraphs](https://www.boe.es/buscar/act.php?id=BOE-A-2013-10074); [Documentación que acredite los recursos económicos](https://www.exteriores.gob.es/Consulados/miami/es/ServiciosConsulares/Paginas/index.aspx?scca=Visados&scco=Estados+Unidos&scd=196&scs=Visados+Nacionales+-+Visado+de+residencia+para+teletrabajo+%28n%C3%B3mada+digital%29); [LIRPF93(1)](https://www.boe.es/buscar/act.php?id=BOE-A-2006-20764).",
    "line": 96
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/es-nomad.txt",
  "source_sha256": "cc3af1f97ca5f6fb1c5336bf72026ec15ace0d6f0740085c735f8105c3ef3a4e",
  "source_version_basis": "Actual currentBOE74bis–quinquiesallpersonallyread5790–5897; provisions added2022-12-23."
}
```

### ES-REMOTE-RELATIONSHIP

Atleast1year realcontinuouscompanyactivity, remoteproof and at least3monthprior actualemployment/commercialrelationship with foreigncompanyplusauthorisedremote terms apply.

```json
{
  "act_article_or_scope": "Law14/2013 Art74ter all4conditions",
  "actual_read_on": "2026-11-16",
  "id": "ES-REMOTE-RELATIONSHIP",
  "official_url": "https://www.boe.es/buscar/act.php?id=BOE-A-2013-10074",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "Spain's telework visa is generally up to 1 year or the shorter work period. Under Law 14/2013, the residence authorisation can be up to 3 years or the shorter work period, with conditional 2-year renewals. The official consular funds test is 200% of SMI for the teleworker,75% for the first accompanying person and 25% for each additional person; the old fixed EUR 2520 is not a current universal threshold. Foreign-employer work, qualifications/experience, actual existing relationship and social-insurance conditions apply. Self-employed Spanish clients are limited to 20% of activity under the immigration rule. LIRPF Art 93's elective regime requires no Spanish residence in the preceding 5 tax periods, a qualifying reason for the move and the relevant activity/no-PE conditions and exceptions. It covers the move year and the following 5 tax periods. Its ordinary base has 24% through EUR 600000 and 47% above; the separately defined investment-income base has different bands. A nomad visa alone neither elects nor proves eligibility for this regime. Sources: [Law14/2013 Art74bis all2paragraphs](https://www.boe.es/buscar/act.php?id=BOE-A-2013-10074); [Documentación que acredite los recursos económicos](https://www.exteriores.gob.es/Consulados/miami/es/ServiciosConsulares/Paginas/index.aspx?scca=Visados&scco=Estados+Unidos&scd=196&scs=Visados+Nacionales+-+Visado+de+residencia+para+teletrabajo+%28n%C3%B3mada+digital%29); [LIRPF93(1)](https://www.boe.es/buscar/act.php?id=BOE-A-2006-20764).",
    "line": 96
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/es-nomad.txt",
  "source_sha256": "cc3af1f97ca5f6fb1c5336bf72026ec15ace0d6f0740085c735f8105c3ef3a4e",
  "source_version_basis": "Actual currentBOEwholeoperative/neighbours personally read."
}
```

### ES-REMOTE-VISA-1YEAR

Visaupto1yearor shorterworkperiod; sufficientpermissionduringvalidity; continuationapplicationwithin60calendardaysbeforeexpiryrequiresmaintainedconditions.

```json
{
  "act_article_or_scope": "Law14/2013 Art74quater all3paragraphs",
  "actual_read_on": "2026-11-16",
  "id": "ES-REMOTE-VISA-1YEAR",
  "official_url": "https://www.boe.es/buscar/act.php?id=BOE-A-2013-10074",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "Spain's telework visa is generally up to 1 year or the shorter work period. Under Law 14/2013, the residence authorisation can be up to 3 years or the shorter work period, with conditional 2-year renewals. The official consular funds test is 200% of SMI for the teleworker,75% for the first accompanying person and 25% for each additional person; the old fixed EUR 2520 is not a current universal threshold. Foreign-employer work, qualifications/experience, actual existing relationship and social-insurance conditions apply. Self-employed Spanish clients are limited to 20% of activity under the immigration rule. LIRPF Art 93's elective regime requires no Spanish residence in the preceding 5 tax periods, a qualifying reason for the move and the relevant activity/no-PE conditions and exceptions. It covers the move year and the following 5 tax periods. Its ordinary base has 24% through EUR 600000 and 47% above; the separately defined investment-income base has different bands. A nomad visa alone neither elects nor proves eligibility for this regime. Sources: [Law14/2013 Art74bis all2paragraphs](https://www.boe.es/buscar/act.php?id=BOE-A-2013-10074); [Documentación que acredite los recursos económicos](https://www.exteriores.gob.es/Consulados/miami/es/ServiciosConsulares/Paginas/index.aspx?scca=Visados&scco=Estados+Unidos&scd=196&scs=Visados+Nacionales+-+Visado+de+residencia+para+teletrabajo+%28n%C3%B3mada+digital%29); [LIRPF93(1)](https://www.boe.es/buscar/act.php?id=BOE-A-2006-20764).",
    "line": 96
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/es-nomad.txt",
  "source_sha256": "cc3af1f97ca5f6fb1c5336bf72026ec15ace0d6f0740085c735f8105c3ef3a4e",
  "source_version_basis": "Actual currentBOEwholeoperative/neighbours personally read; not a final proceduralfilingclearance."
}
```

### ES-REMOTE-PERMIT-3PLUS2

Legallypresentforeignerscanrequestnationallyvalidremotepermit, maximum3yearsor shorterworkperiod and conditional2yearrenewals; no universalone-yearpermission.

```json
{
  "act_article_or_scope": "Law14/2013 Art74quinquies all3paragraphs",
  "actual_read_on": "2026-11-16",
  "id": "ES-REMOTE-PERMIT-3PLUS2",
  "official_url": "https://www.boe.es/buscar/act.php?id=BOE-A-2013-10074",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "Spain's telework visa is generally up to 1 year or the shorter work period. Under Law 14/2013, the residence authorisation can be up to 3 years or the shorter work period, with conditional 2-year renewals. The official consular funds test is 200% of SMI for the teleworker,75% for the first accompanying person and 25% for each additional person; the old fixed EUR 2520 is not a current universal threshold. Foreign-employer work, qualifications/experience, actual existing relationship and social-insurance conditions apply. Self-employed Spanish clients are limited to 20% of activity under the immigration rule. LIRPF Art 93's elective regime requires no Spanish residence in the preceding 5 tax periods, a qualifying reason for the move and the relevant activity/no-PE conditions and exceptions. It covers the move year and the following 5 tax periods. Its ordinary base has 24% through EUR 600000 and 47% above; the separately defined investment-income base has different bands. A nomad visa alone neither elects nor proves eligibility for this regime. Sources: [Law14/2013 Art74bis all2paragraphs](https://www.boe.es/buscar/act.php?id=BOE-A-2013-10074); [Documentación que acredite los recursos económicos](https://www.exteriores.gob.es/Consulados/miami/es/ServiciosConsulares/Paginas/index.aspx?scca=Visados&scco=Estados+Unidos&scd=196&scs=Visados+Nacionales+-+Visado+de+residencia+para+teletrabajo+%28n%C3%B3mada+digital%29); [LIRPF93(1)](https://www.boe.es/buscar/act.php?id=BOE-A-2006-20764).",
    "line": 96
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/es-nomad.txt",
  "source_sha256": "cc3af1f97ca5f6fb1c5336bf72026ec15ace0d6f0740085c735f8105c3ef3a4e",
  "source_version_basis": "Actual currentBOEwholeoperative/neighbours personally read."
}
```

### ES-ARTICLE93-ELIGIBILITY

Displaced-person election has actual5priornonresidentperiods, qualifyingmove/category and noPEexceptspecifiedentrepreneur/highskillcases; move-yearplus5periods; nomadvisaalone not fulltaxeligibilityproof.

```json
{
  "act_article_or_scope": "LIRPF93(1), complete election,6periods, all eligibility and PEexceptions",
  "actual_read_on": "2026-11-16",
  "id": "ES-ARTICLE93-ELIGIBILITY",
  "official_url": "https://www.boe.es/buscar/act.php?id=BOE-A-2006-20764",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "Spain's telework visa is generally up to 1 year or the shorter work period. Under Law 14/2013, the residence authorisation can be up to 3 years or the shorter work period, with conditional 2-year renewals. The official consular funds test is 200% of SMI for the teleworker,75% for the first accompanying person and 25% for each additional person; the old fixed EUR 2520 is not a current universal threshold. Foreign-employer work, qualifications/experience, actual existing relationship and social-insurance conditions apply. Self-employed Spanish clients are limited to 20% of activity under the immigration rule. LIRPF Art 93's elective regime requires no Spanish residence in the preceding 5 tax periods, a qualifying reason for the move and the relevant activity/no-PE conditions and exceptions. It covers the move year and the following 5 tax periods. Its ordinary base has 24% through EUR 600000 and 47% above; the separately defined investment-income base has different bands. A nomad visa alone neither elects nor proves eligibility for this regime. Sources: [Law14/2013 Art74bis all2paragraphs](https://www.boe.es/buscar/act.php?id=BOE-A-2013-10074); [Documentación que acredite los recursos económicos](https://www.exteriores.gob.es/Consulados/miami/es/ServiciosConsulares/Paginas/index.aspx?scca=Visados&scco=Estados+Unidos&scd=196&scs=Visados+Nacionales+-+Visado+de+residencia+para+teletrabajo+%28n%C3%B3mada+digital%29); [LIRPF93(1)](https://www.boe.es/buscar/act.php?id=BOE-A-2006-20764).",
    "line": 96
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/es-residence.txt",
  "source_sha256": "b18d0de5cb1a677d552e23d64e171c094b0c18bf17a09d717ef9b282b5e10fbe",
  "source_version_basis": "Actual BOEconsolidation2026-11-11, ownwhole93(1)–(3)read with92closing/94opening neighbours; current2025savingsamendment noted."
}
```

### ES-ARTICLE93-RATE-BASE

Specialregime has statutorysource/baseandnonoffset rules,24%upto600000ordinarybaseand47%excess, separatesavingsbands and actualwithholdingcondition; not flat24%on everyreceipt.

```json
{
  "act_article_or_scope": "LIRPF93(2), all source/base/tables/withholdingconditions",
  "actual_read_on": "2026-11-16",
  "id": "ES-ARTICLE93-RATE-BASE",
  "official_url": "https://www.boe.es/buscar/act.php?id=BOE-A-2006-20764",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "Spain's telework visa is generally up to 1 year or the shorter work period. Under Law 14/2013, the residence authorisation can be up to 3 years or the shorter work period, with conditional 2-year renewals. The official consular funds test is 200% of SMI for the teleworker,75% for the first accompanying person and 25% for each additional person; the old fixed EUR 2520 is not a current universal threshold. Foreign-employer work, qualifications/experience, actual existing relationship and social-insurance conditions apply. Self-employed Spanish clients are limited to 20% of activity under the immigration rule. LIRPF Art 93's elective regime requires no Spanish residence in the preceding 5 tax periods, a qualifying reason for the move and the relevant activity/no-PE conditions and exceptions. It covers the move year and the following 5 tax periods. Its ordinary base has 24% through EUR 600000 and 47% above; the separately defined investment-income base has different bands. A nomad visa alone neither elects nor proves eligibility for this regime. Sources: [Law14/2013 Art74bis all2paragraphs](https://www.boe.es/buscar/act.php?id=BOE-A-2013-10074); [Documentación que acredite los recursos económicos](https://www.exteriores.gob.es/Consulados/miami/es/ServiciosConsulares/Paginas/index.aspx?scca=Visados&scco=Estados+Unidos&scd=196&scs=Visados+Nacionales+-+Visado+de+residencia+para+teletrabajo+%28n%C3%B3mada+digital%29); [LIRPF93(1)](https://www.boe.es/buscar/act.php?id=BOE-A-2006-20764).",
    "line": 96
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/es-residence.txt",
  "source_sha256": "b18d0de5cb1a677d552e23d64e171c094b0c18bf17a09d717ef9b282b5e10fbe",
  "source_version_basis": "Actual currentBOE93(2)wholepersonallyread; source2025-01-01savingschange and2026-11-11compilation basis kept; no net-taxbillfromtheseheadlines."
}
```

### TH-P161-REMITTANCE

Resident foreign work/business/property income in the relevant income year is included in the remittance year even when remitted in a later tax year; pre2024 carveout is retained.

```json
{
  "act_article_or_scope": "OrderP161/2566 paragraph1, as annotated byP162",
  "actual_read_on": "2026-11-16",
  "id": "TH-P161-REMITTANCE",
  "official_url": "https://www.rd.go.th/fileadmin/user_upload/kormor/newlaw/dn161A.pdf",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "| Thailand | Local-source work/business can be taxable irrespective of payment abroad. The current published ordinary PIT schedule runs from 0% to 35%, with 35% above THB 5 million, subject to the actual base, exemptions and other calculation methods. For qualifying residents, P161/P162 cover foreign-source income arising from 1 January 2024 and later remitted, including later-year remittance; pre 2024 income is treated separately. LTR 17% concerns qualifying Highly-Skilled Professional employment. Decree 743 Art 5 separately names 3 other LTR categories and specified foreign income from prior tax years; an unconditional same-year foreign-income exemption is not established by that wording. Sources: [RevenueCode41 all3paragraphs and linked directive notes](https://www.rd.go.th/5937.html); [CurrentRDnative2017-onwardtableandbothstatutoryexemption/effectnotes](https://www.rd.go.th/59670.html); [OrderP161/2566 paragraph1](https://www.rd.go.th/fileadmin/user_upload/kormor/newlaw/dn161A.pdf); [OrderP162/2566 sole operative amendment](https://www.rd.go.th/fileadmin/user_upload/kormor/newlaw/dn162A.pdf); [Royal Decree743/2565 Art5; printed31/PDF3](https://ltr.boi.go.th/documents/Royal%20Decree%20issued%20under%20the%20Revenue%20Code%20No.743%20(TH).pdf). |",
    "line": 90
  },
  "short_exact_native_quotes": [
    "ข้อ 1 บุคคลซึ่งเป็น ผู้อยู่ในประเทศไทยตามมาตรา 41 วรรคสาม แห่งประมวลรัษฎากร ที่มีเงินได้พึงประเมินเนื่องจากหน้าที่งานหรือกิจการที่ทำในต่างประเทศ หรือเนื่องจากทรัพย์สินที่อยู่ใน ต่างประเทศ ตามมาตรา 41"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/th-p161.txt",
  "source_sha256": "a8707701a127f7299a939ba6b08ec3f5725b0ce994dd5a7c50f6bac52ff371f7",
  "source_version_basis": "Actual complete one-page official native PDF; amended paragraph is expressly annotated with20November2023order."
}
```

### TH-P161-EFFECT

Conflicting administrative practice is revoked; operative remittance commencement is1January2024, distinct from income-arising cutoff.

```json
{
  "act_article_or_scope": "OrderP161/2566 paragraphs2–3",
  "actual_read_on": "2026-11-16",
  "id": "TH-P161-EFFECT",
  "official_url": "https://www.rd.go.th/fileadmin/user_upload/kormor/newlaw/dn161A.pdf",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "| Thailand | Local-source work/business can be taxable irrespective of payment abroad. The current published ordinary PIT schedule runs from 0% to 35%, with 35% above THB 5 million, subject to the actual base, exemptions and other calculation methods. For qualifying residents, P161/P162 cover foreign-source income arising from 1 January 2024 and later remitted, including later-year remittance; pre 2024 income is treated separately. LTR 17% concerns qualifying Highly-Skilled Professional employment. Decree 743 Art 5 separately names 3 other LTR categories and specified foreign income from prior tax years; an unconditional same-year foreign-income exemption is not established by that wording. Sources: [RevenueCode41 all3paragraphs and linked directive notes](https://www.rd.go.th/5937.html); [CurrentRDnative2017-onwardtableandbothstatutoryexemption/effectnotes](https://www.rd.go.th/59670.html); [OrderP161/2566 paragraph1](https://www.rd.go.th/fileadmin/user_upload/kormor/newlaw/dn161A.pdf); [OrderP162/2566 sole operative amendment](https://www.rd.go.th/fileadmin/user_upload/kormor/newlaw/dn162A.pdf); [Royal Decree743/2565 Art5; printed31/PDF3](https://ltr.boi.go.th/documents/Royal%20Decree%20issued%20under%20the%20Revenue%20Code%20No.743%20(TH).pdf). |",
    "line": 90
  },
  "short_exact_native_quotes": [
    "ข้อ 2 บรรดาระเบียบ ข้อบังคับ คำสั่ง หนังสือตอบข้อหารือ หรือทางปฏิบัติใดที่ขั ดหรือแย้งกับ คำสั่งนี้ให้เป็นอันยกเลิก ข้อ 3"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/th-p161.txt",
  "source_sha256": "a8707701a127f7299a939ba6b08ec3f5725b0ce994dd5a7c50f6bac52ff371f7",
  "source_version_basis": "Actual full official native PDF read with paragraph1."
}
```

### TH-P162-CUTOFF

P161 paragraph1 does not apply to assessable income arising before1January2024; it is not merely a same-year-remittance rule.

```json
{
  "act_article_or_scope": "OrderP162/2566 sole operative amendment",
  "actual_read_on": "2026-11-16",
  "id": "TH-P162-CUTOFF",
  "official_url": "https://www.rd.go.th/fileadmin/user_upload/kormor/newlaw/dn162A.pdf",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "| Thailand | Local-source work/business can be taxable irrespective of payment abroad. The current published ordinary PIT schedule runs from 0% to 35%, with 35% above THB 5 million, subject to the actual base, exemptions and other calculation methods. For qualifying residents, P161/P162 cover foreign-source income arising from 1 January 2024 and later remitted, including later-year remittance; pre 2024 income is treated separately. LTR 17% concerns qualifying Highly-Skilled Professional employment. Decree 743 Art 5 separately names 3 other LTR categories and specified foreign income from prior tax years; an unconditional same-year foreign-income exemption is not established by that wording. Sources: [RevenueCode41 all3paragraphs and linked directive notes](https://www.rd.go.th/5937.html); [CurrentRDnative2017-onwardtableandbothstatutoryexemption/effectnotes](https://www.rd.go.th/59670.html); [OrderP161/2566 paragraph1](https://www.rd.go.th/fileadmin/user_upload/kormor/newlaw/dn161A.pdf); [OrderP162/2566 sole operative amendment](https://www.rd.go.th/fileadmin/user_upload/kormor/newlaw/dn162A.pdf); [Royal Decree743/2565 Art5; printed31/PDF3](https://ltr.boi.go.th/documents/Royal%20Decree%20issued%20under%20the%20Revenue%20Code%20No.743%20(TH).pdf). |",
    "line": 90
  },
  "short_exact_native_quotes": [
    "ให้เพิ่มความต่อไปนี้เป็นวรรคสองของข้อ ๑ ของคำสั่งกรมสรรพากรที่ ป.๑๖๑/๒๕๖๖ เรื่อง การเสียภาษีเงินได้ตามมาตรา ๔๑ วรรคสอง แห่งประมวลรัษฎากร ลงวันที่ ๑๕ กันยายน พ.ศ. ๒๕๖๖"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/th-p162.txt",
  "source_sha256": "55989d8db97ca1abfe83f624e4d1e373d883ba656a109351d39f175fec54aac7",
  "source_version_basis": "20November2023order; actual complete one-page PDF read."
}
```

### MY-FSI-EXTENSION-EFFECT

2024amendment replaces31December2026 with31December2036 but itself commences1January2027; underlying2026exemption conditions require separate source.

```json
{
  "act_article_or_scope": "PU(A)451/2024 native paragraphs1–2",
  "actual_read_on": "2026-11-16",
  "id": "MY-FSI-EXTENSION-EFFECT",
  "official_url": "https://lom.agc.gov.my/ilims/upload/portal/akta/outputp/2584396/PUA%20451_2024.pdf",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "| Malaysia | The authority-hosted 2026 Act general resident tariff runs from 0% to 30%, under its actual chargeable-income bands and exception categories. The actual foreign-income exemption source has conditions for resident individuals, excludes partnership income received in Malaysia, and addresses subject-to-foreign-tax exceptions and records. Its 2024 extension commencing 1 January 2027 must not be described as a new 2026 exemption. MM2H is a category-dependent long-term social visit programme; MM2H permits general employment/business activity only in the Platinum category under the current FAQ; other categories need the relevant separate pass. Sources: [ITA1967Schedule1PartIparagraph1and1Aneighbor](https://www.hasil.gov.my/wp-content/uploads/Income-Tax-Act-1967-online-version-as-at-1-January-2026.pdf); [20June2024DGguideline5.2.2.1–2 allactualtax/deemed-taxconditions;5.2.4recordkeeping;PDFpp27–32](https://www.hasil.gov.my/wp-content/uploads/20240620-guidelines-tax-treatment-in-relation-to-income-received-from-abroad-amendment-june-2024.pdf); [PU(A)451/2024 native paragraphs1–2](https://lom.agc.gov.my/ilims/upload/portal/akta/outputp/2584396/PUA%20451_2024.pdf); [MM2H Topic2](https://www.motac.gov.my/en/frequently-asked-questions-faqs/). |",
    "line": 89
  },
  "short_exact_native_quotes": [
    "Nama dan permulaan kuat kuasa 1. (1) Perintah ini bolehlah dinamakan Perintah Cukai Pendapatan (Pengecualian) (No. 5) 2022 (Pindaan) 2024. (2) Perintah ini mula berkuat"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/my-fsi-extension.txt",
  "source_sha256": "e685a080b692e80fad591152a497355cb3520c04690c4b12e9376400858e5c05",
  "source_version_basis": "FederalGazette24December2024, actual all3pages read; Malay operative native text, English translation also read."
}
```

### GE-FOREIGN-SOURCE-EXEMPTION

Resident natural-person foreign-source income/benefit is exempt under this limb; actual104source classification remains essential.

```json
{
  "act_article_or_scope": "TaxCode82(1)(ფ)",
  "actual_read_on": "2026-11-16",
  "id": "GE-FOREIGN-SOURCE-EXEMPTION",
  "official_url": "https://www.matsne.gov.ge/ka/document/view/1043717",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "| Georgia | Microbusiness is distinct from small business: qualifying independent natural persons with no hired labour and annual gross income not above GEL 30000 can have micro status. Small-business status generally taxes qualifying Georgian-source receipts, excluding wages/excluded categories, at 1%;3% begins with the crossing month when gross income exceeds GEL 500000, with the specific GEL 700000 wine/agrotourism rule. Two consecutive excess years and other cancellation conditions are separate. Foreign-source exemption does not cover Georgian-source services just because a client is abroad. Sources: [TaxCode84–85 complete](https://www.matsne.gov.ge/ka/document/view/1043717). |",
    "line": 87
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/ge-code-native.txt",
  "source_sha256": "184c60e61357aa4c3c3d743479b8c032ae3b123a0e837f55d5432adb5111befa",
  "source_version_basis": "Actual native consolidated body28October2026, personally read with whole82/84–90/104 scopes."
}
```

### GE-SERVICES-SOURCE

Local employment and goods plus all specified service-source limbs apply; cross-border client location alone does not establish foreign source.

```json
{
  "act_article_or_scope": "TaxCode104(1)(a)–(g) all domestic work/service source limbs",
  "actual_read_on": "2026-11-16",
  "id": "GE-SERVICES-SOURCE",
  "official_url": "https://www.matsne.gov.ge/ka/document/view/1043717",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "| Georgia | Microbusiness is distinct from small business: qualifying independent natural persons with no hired labour and annual gross income not above GEL 30000 can have micro status. Small-business status generally taxes qualifying Georgian-source receipts, excluding wages/excluded categories, at 1%;3% begins with the crossing month when gross income exceeds GEL 500000, with the specific GEL 700000 wine/agrotourism rule. Two consecutive excess years and other cancellation conditions are separate. Foreign-source exemption does not cover Georgian-source services just because a client is abroad. Sources: [TaxCode84–85 complete](https://www.matsne.gov.ge/ka/document/view/1043717). |",
    "line": 87
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/ge-code-native.txt",
  "source_sha256": "184c60e61357aa4c3c3d743479b8c032ae3b123a0e837f55d5432adb5111befa",
  "source_version_basis": "Actual native consolidation28October2026; full104and105opening personally reread."
}
```

### GE-RECEIPT-LOCATION

Receipt location is disregarded when determining source under104(1); overseas payment does not erase Georgian source.

```json
{
  "act_article_or_scope": "TaxCode104(2), actual source11213; bounded by104heading and105heading",
  "actual_read_on": "2026-11-16",
  "correction_own_read_on": "2026-11-16",
  "id": "GE-RECEIPT-LOCATION",
  "official_url": "https://www.matsne.gov.ge/ka/document/view/1043717",
  "quote_mode": "Full assigned actual public-law operative clause, losslessly split into ordered contiguous native fragments <=25 words and <=240 characters; manually read operative scope and neighbours.",
  "section": {
    "actual_text": "| Georgia | Microbusiness is distinct from small business: qualifying independent natural persons with no hired labour and annual gross income not above GEL 30000 can have micro status. Small-business status generally taxes qualifying Georgian-source receipts, excluding wages/excluded categories, at 1%;3% begins with the crossing month when gross income exceeds GEL 500000, with the specific GEL 700000 wine/agrotourism rule. Two consecutive excess years and other cancellation conditions are separate. Foreign-source exemption does not cover Georgian-source services just because a client is abroad. Sources: [TaxCode84–85 complete](https://www.matsne.gov.ge/ka/document/view/1043717). |",
    "line": 87
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/ge-code-native.txt",
  "source_sha256": "184c60e61357aa4c3c3d743479b8c032ae3b123a0e837f55d5432adb5111befa",
  "source_version_basis": "Actual native consolidation28October2026; all104 personally read."
}
```

### GR-2026-CHANGE-CATEGORY

2026Art13 repeals5038Art12(7); former short-stay/visa-waiver in-country route cannot be repeated as current unconditional access.

```json
{
  "act_article_or_scope": "Law5275/2026Art13 introductory operative amendments, printed451",
  "actual_read_on": "2026-11-16",
  "id": "GR-2026-CHANGE-CATEGORY",
  "official_url": "https://migration.gov.gr/wp-content/uploads/2026/02/%CE%A6%CE%95%CE%9A%CE%9117_6.2.2025.pdf",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "Greece's Art 68 route is a national visa up to 12 months for remote work for employers/clients outside Greece. The ordinary resources test is EUR 3500 net monthly under the stated conditions, plus 20% spouse/partner and 15% each child. A separate conditional 2-year residence permit can follow an application before visa expiry. Law 5275/2026 Art 13 repealed the former Art 12(7) short-stay/visa-waiver in-country path. The conditional Art 5C 50% relief for qualifying Greek employment/sole-business income lasts 7 tax years; it requires its own previous 5-of-6-year nonresidence, eligible prior country, actual qualifying activity, intended 2-year stay and application/approval conditions. The 2026 A1096 procedure overlay covers specified applications from 28 July 2025 and pending then, including public employment. A nomad visa does not itself establish Art 5C eligibility. Sources: [Law5038/2023 Art68(2)(e)](https://migration.gov.gr/wp-content/uploads/2023/04/%CE%9A%CF%8E%CE%B4%CE%B9%CE%BA%CE%B1%CF%82-%CE%9C%CE%B5%CF%84%CE%B1%CE%BD%CE%AC%CF%83%CF%84%CE%B5%CF%85%CF%83%CE%B7%CF%82.pdf); [Law5275/2026Art13 introductory operative amendments](https://migration.gov.gr/wp-content/uploads/2026/02/%CE%A6%CE%95%CE%9A%CE%9117_6.2.2025.pdf); [A1138/2025 Art1(2) substitutingA1087Art3(1)](https://www.aade.gr/sites/default/files/2025-10/a1138fek.pdf); [A1087/2021Art5(1)](https://www.aade.gr/sites/default/files/2025-10/%CE%91.1087_2021.pdf); [A1096/2026 Art2 complete](https://www.aade.gr/sites/default/files/2026-05/a1096_2026_0.pdf).",
    "line": 102
  },
  "short_exact_native_quotes": [
    "Στο άρθρο 12 του Κώδικα Μετανάστευσης (ν. 5038/2023, Α’ 81), περί της δυνατότητας μεταβολής κα- τηγορίας άδειας διαμονής, επέρχονται οι ακόλουθες τροποποιήσεις: α) στην παρ."
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/gr-law5275-full.txt",
  "source_sha256": "64187a2da99f6b7d7e030da7bc3cfb4fbff82b9872272a5af5b3c30dcaa3abfe",
  "source_version_basis": "Actual GazetteA17/6February2026 controls despite misnamed2025URL; own fullArts11–14 and69 read."
}
```

### GR-A1096-2026-VERIFICATION

Employment eligibility verification uses ERGANI/publicHR interoperability with documentary fallback; last sentence ofA1087Art3(5)repealed.

```json
{
  "act_article_or_scope": "A1096/2026 Art1, all amendments, actualPDFpp3–4",
  "actual_read_on": "2026-11-16",
  "id": "GR-A1096-2026-VERIFICATION",
  "official_url": "https://www.aade.gr/sites/default/files/2026-05/a1096_2026_0.pdf",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "Greece's Art 68 route is a national visa up to 12 months for remote work for employers/clients outside Greece. The ordinary resources test is EUR 3500 net monthly under the stated conditions, plus 20% spouse/partner and 15% each child. A separate conditional 2-year residence permit can follow an application before visa expiry. Law 5275/2026 Art 13 repealed the former Art 12(7) short-stay/visa-waiver in-country path. The conditional Art 5C 50% relief for qualifying Greek employment/sole-business income lasts 7 tax years; it requires its own previous 5-of-6-year nonresidence, eligible prior country, actual qualifying activity, intended 2-year stay and application/approval conditions. The 2026 A1096 procedure overlay covers specified applications from 28 July 2025 and pending then, including public employment. A nomad visa does not itself establish Art 5C eligibility. Sources: [Law5038/2023 Art68(2)(e)](https://migration.gov.gr/wp-content/uploads/2023/04/%CE%9A%CF%8E%CE%B4%CE%B9%CE%BA%CE%B1%CF%82-%CE%9C%CE%B5%CF%84%CE%B1%CE%BD%CE%AC%CF%83%CF%84%CE%B5%CF%85%CF%83%CE%B7%CF%82.pdf); [Law5275/2026Art13 introductory operative amendments](https://migration.gov.gr/wp-content/uploads/2026/02/%CE%A6%CE%95%CE%9A%CE%9117_6.2.2025.pdf); [A1138/2025 Art1(2) substitutingA1087Art3(1)](https://www.aade.gr/sites/default/files/2025-10/a1138fek.pdf); [A1087/2021Art5(1)](https://www.aade.gr/sites/default/files/2025-10/%CE%91.1087_2021.pdf); [A1096/2026 Art2 complete](https://www.aade.gr/sites/default/files/2026-05/a1096_2026_0.pdf).",
    "line": 102
  },
  "short_exact_native_quotes": [
    "Τροποποιούμε την υπό στοιχεία Α. 1087/2021 απόφαση του Υφυπουργού Οικονομικών και του Διοικητή της ΑΑΔΕ «Διαδικασία και προϋποθέσεις υπαγωγής στις διατάξεις του άρθρου 5Γ του"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/gr-a1096-web.txt",
  "source_sha256": "4fad7618632dd860cb1035f3e09f8cfedf6a72b02be5609cf9a35b2009831ff8",
  "source_version_basis": "Actual all5pages read; current2026operative administrative instrument; not a claim that every application is approved."
}
```

### GR-A1096-2026-EFFECT

Publication commencement and express coverage of applications submitted from28July2025 and pending then; not a new application deadline.

```json
{
  "act_article_or_scope": "A1096/2026 Art2 complete",
  "actual_read_on": "2026-11-16",
  "id": "GR-A1096-2026-EFFECT",
  "official_url": "https://www.aade.gr/sites/default/files/2026-05/a1096_2026_0.pdf",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "Greece's Art 68 route is a national visa up to 12 months for remote work for employers/clients outside Greece. The ordinary resources test is EUR 3500 net monthly under the stated conditions, plus 20% spouse/partner and 15% each child. A separate conditional 2-year residence permit can follow an application before visa expiry. Law 5275/2026 Art 13 repealed the former Art 12(7) short-stay/visa-waiver in-country path. The conditional Art 5C 50% relief for qualifying Greek employment/sole-business income lasts 7 tax years; it requires its own previous 5-of-6-year nonresidence, eligible prior country, actual qualifying activity, intended 2-year stay and application/approval conditions. The 2026 A1096 procedure overlay covers specified applications from 28 July 2025 and pending then, including public employment. A nomad visa does not itself establish Art 5C eligibility. Sources: [Law5038/2023 Art68(2)(e)](https://migration.gov.gr/wp-content/uploads/2023/04/%CE%9A%CF%8E%CE%B4%CE%B9%CE%BA%CE%B1%CF%82-%CE%9C%CE%B5%CF%84%CE%B1%CE%BD%CE%AC%CF%83%CF%84%CE%B5%CF%85%CF%83%CE%B7%CF%82.pdf); [Law5275/2026Art13 introductory operative amendments](https://migration.gov.gr/wp-content/uploads/2026/02/%CE%A6%CE%95%CE%9A%CE%9117_6.2.2025.pdf); [A1138/2025 Art1(2) substitutingA1087Art3(1)](https://www.aade.gr/sites/default/files/2025-10/a1138fek.pdf); [A1087/2021Art5(1)](https://www.aade.gr/sites/default/files/2025-10/%CE%91.1087_2021.pdf); [A1096/2026 Art2 complete](https://www.aade.gr/sites/default/files/2026-05/a1096_2026_0.pdf).",
    "line": 102
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/gr-a1096-web.txt",
  "source_sha256": "4fad7618632dd860cb1035f3e09f8cfedf6a72b02be5609cf9a35b2009831ff8",
  "source_version_basis": "ActualPDFp4 and adjacentArt1read; GazetteB2500/4May2026 and corrigendumB2672/13May2026 separately identified in actual authority source."
}
```

### GR-NOMAD-VISA

NonEU remote work/services for employers/clients outsideGreece has national visa up to12months, conditional on actual documents and noGreek-employer work. Actual ICT means, declaration/noGreekemployer, foreign contract/work evidence with fixed-term duration covering visa, multiple foreign clients and own-company evidence apply.

```json
{
  "act_article_or_scope": "Law5038/2023Art68(1) and2intro/2(a)–(d), printed4155left/PDF53",
  "actual_read_on": "2026-11-16",
  "correction_own_read_on": "2026-11-16",
  "id": "GR-NOMAD-VISA",
  "official_url": "https://migration.gov.gr/wp-content/uploads/2023/04/%CE%9A%CF%8E%CE%B4%CE%B9%CE%BA%CE%B1%CF%82-%CE%9C%CE%B5%CF%84%CE%B1%CE%BD%CE%AC%CF%83%CF%84%CE%B5%CF%85%CF%83%CE%B7%CF%82.pdf",
  "quote_mode": "Full assigned actual public-law operative clause, losslessly split into ordered contiguous native fragments <=25 words and <=240 characters; manually read operative scope and neighbours.",
  "section": {
    "actual_text": "Greece's Art 68 route is a national visa up to 12 months for remote work for employers/clients outside Greece. The ordinary resources test is EUR 3500 net monthly under the stated conditions, plus 20% spouse/partner and 15% each child. A separate conditional 2-year residence permit can follow an application before visa expiry. Law 5275/2026 Art 13 repealed the former Art 12(7) short-stay/visa-waiver in-country path. The conditional Art 5C 50% relief for qualifying Greek employment/sole-business income lasts 7 tax years; it requires its own previous 5-of-6-year nonresidence, eligible prior country, actual qualifying activity, intended 2-year stay and application/approval conditions. The 2026 A1096 procedure overlay covers specified applications from 28 July 2025 and pending then, including public employment. A nomad visa does not itself establish Art 5C eligibility. Sources: [Law5038/2023 Art68(2)(e)](https://migration.gov.gr/wp-content/uploads/2023/04/%CE%9A%CF%8E%CE%B4%CE%B9%CE%BA%CE%B1%CF%82-%CE%9C%CE%B5%CF%84%CE%B1%CE%BD%CE%AC%CF%83%CF%84%CE%B5%CF%85%CF%83%CE%B7%CF%82.pdf); [Law5275/2026Art13 introductory operative amendments](https://migration.gov.gr/wp-content/uploads/2026/02/%CE%A6%CE%95%CE%9A%CE%9117_6.2.2025.pdf); [A1138/2025 Art1(2) substitutingA1087Art3(1)](https://www.aade.gr/sites/default/files/2025-10/a1138fek.pdf); [A1087/2021Art5(1)](https://www.aade.gr/sites/default/files/2025-10/%CE%91.1087_2021.pdf); [A1096/2026 Art2 complete](https://www.aade.gr/sites/default/files/2026-05/a1096_2026_0.pdf).",
    "line": 102
  },
  "short_exact_native_quotes": [
    "1. Σε πολίτες τρίτων χωρών αυτοαπασχολούμενους, ελεύθερους επαγγελματίες ή μισθωτούς που δύνανται να παρέχουν την εργασία τους στο πλαίσιο σύμβασης εργασίας ή παροχής υπηρεσιών ή"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/gr-art68-assigned-reading-order.txt",
  "source_sha256": "2576c1ed79ea2d83510d9082234b4b7cb350df7be3db121da3b5070afa1cb23d",
  "source_validation": "Own full actualPDFp53 rendered and visually read16November2026. Native body derives from separate Poppler left/right crops in correct column order; each assigned full clause retained including source hyphenation. ActualPDFSHA separately recorded in source register.",
  "source_version_basis": "Actual nativeGazette allArt68/67/69opening visually/textually read;2column layout explicitly preserved; updatedArt12route separately2026overlay."
}
```

### GR-NOMAD-FUNDS

Stable resources3500monthly, employment/service funds net of required work-country taxes;20%spouse/partner and15%perchild additions. Stable means must cover living without welfare; employment/service proof OR bank proof, with relevant work-country-tax deduction.

```json
{
  "act_article_or_scope": "Law5038/2023Art68(2)(e), printed4155left-bottom continued right-top/PDF53",
  "actual_read_on": "2026-11-16",
  "correction_own_read_on": "2026-11-16",
  "id": "GR-NOMAD-FUNDS",
  "official_url": "https://migration.gov.gr/wp-content/uploads/2023/04/%CE%9A%CF%8E%CE%B4%CE%B9%CE%BA%CE%B1%CF%82-%CE%9C%CE%B5%CF%84%CE%B1%CE%BD%CE%AC%CF%83%CF%84%CE%B5%CF%85%CF%83%CE%B7%CF%82.pdf",
  "quote_mode": "Full assigned actual public-law operative clause, losslessly split into ordered contiguous native fragments <=25 words and <=240 characters; manually read operative scope and neighbours.",
  "section": {
    "actual_text": "Greece's Art 68 route is a national visa up to 12 months for remote work for employers/clients outside Greece. The ordinary resources test is EUR 3500 net monthly under the stated conditions, plus 20% spouse/partner and 15% each child. A separate conditional 2-year residence permit can follow an application before visa expiry. Law 5275/2026 Art 13 repealed the former Art 12(7) short-stay/visa-waiver in-country path. The conditional Art 5C 50% relief for qualifying Greek employment/sole-business income lasts 7 tax years; it requires its own previous 5-of-6-year nonresidence, eligible prior country, actual qualifying activity, intended 2-year stay and application/approval conditions. The 2026 A1096 procedure overlay covers specified applications from 28 July 2025 and pending then, including public employment. A nomad visa does not itself establish Art 5C eligibility. Sources: [Law5038/2023 Art68(2)(e)](https://migration.gov.gr/wp-content/uploads/2023/04/%CE%9A%CF%8E%CE%B4%CE%B9%CE%BA%CE%B1%CF%82-%CE%9C%CE%B5%CF%84%CE%B1%CE%BD%CE%AC%CF%83%CF%84%CE%B5%CF%85%CF%83%CE%B7%CF%82.pdf); [Law5275/2026Art13 introductory operative amendments](https://migration.gov.gr/wp-content/uploads/2026/02/%CE%A6%CE%95%CE%9A%CE%9117_6.2.2025.pdf); [A1138/2025 Art1(2) substitutingA1087Art3(1)](https://www.aade.gr/sites/default/files/2025-10/a1138fek.pdf); [A1087/2021Art5(1)](https://www.aade.gr/sites/default/files/2025-10/%CE%91.1087_2021.pdf); [A1096/2026 Art2 complete](https://www.aade.gr/sites/default/files/2026-05/a1096_2026_0.pdf).",
    "line": 102
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/gr-art68-assigned-reading-order.txt",
  "source_sha256": "2576c1ed79ea2d83510d9082234b4b7cb350df7be3db121da3b5070afa1cb23d",
  "source_validation": "Own full actualPDFp53 rendered and visually read16November2026. Native body derives from separate Poppler left/right crops in correct column order; each assigned full clause retained including source hyphenation. ActualPDFSHA separately recorded in source register.",
  "source_version_basis": "Actual full2(e)anddocuments/family/permitneighbors personally read; not alltaxes eliminated by netfunds measure."
}
```

### GR-NOMAD-PERMIT

Continuedparagraph2conditions and application beforevisaexpiry can yield2yearpermit under actual conditional crossreferences. Actual discretionary grant andArt163(8)/Art8/application-office crossreferences retained.

```json
{
  "act_article_or_scope": "Law5038/2023Art68(4) whole, printed4155right/PDF53",
  "actual_read_on": "2026-11-16",
  "correction_own_read_on": "2026-11-16",
  "id": "GR-NOMAD-PERMIT",
  "official_url": "https://migration.gov.gr/wp-content/uploads/2023/04/%CE%9A%CF%8E%CE%B4%CE%B9%CE%BA%CE%B1%CF%82-%CE%9C%CE%B5%CF%84%CE%B1%CE%BD%CE%AC%CF%83%CF%84%CE%B5%CF%85%CF%83%CE%B7%CF%82.pdf",
  "quote_mode": "Full assigned actual public-law operative clause, losslessly split into ordered contiguous native fragments <=25 words and <=240 characters; manually read operative scope and neighbours.",
  "section": {
    "actual_text": "Greece's Art 68 route is a national visa up to 12 months for remote work for employers/clients outside Greece. The ordinary resources test is EUR 3500 net monthly under the stated conditions, plus 20% spouse/partner and 15% each child. A separate conditional 2-year residence permit can follow an application before visa expiry. Law 5275/2026 Art 13 repealed the former Art 12(7) short-stay/visa-waiver in-country path. The conditional Art 5C 50% relief for qualifying Greek employment/sole-business income lasts 7 tax years; it requires its own previous 5-of-6-year nonresidence, eligible prior country, actual qualifying activity, intended 2-year stay and application/approval conditions. The 2026 A1096 procedure overlay covers specified applications from 28 July 2025 and pending then, including public employment. A nomad visa does not itself establish Art 5C eligibility. Sources: [Law5038/2023 Art68(2)(e)](https://migration.gov.gr/wp-content/uploads/2023/04/%CE%9A%CF%8E%CE%B4%CE%B9%CE%BA%CE%B1%CF%82-%CE%9C%CE%B5%CF%84%CE%B1%CE%BD%CE%AC%CF%83%CF%84%CE%B5%CF%85%CF%83%CE%B7%CF%82.pdf); [Law5275/2026Art13 introductory operative amendments](https://migration.gov.gr/wp-content/uploads/2026/02/%CE%A6%CE%95%CE%9A%CE%9117_6.2.2025.pdf); [A1138/2025 Art1(2) substitutingA1087Art3(1)](https://www.aade.gr/sites/default/files/2025-10/a1138fek.pdf); [A1087/2021Art5(1)](https://www.aade.gr/sites/default/files/2025-10/%CE%91.1087_2021.pdf); [A1096/2026 Art2 complete](https://www.aade.gr/sites/default/files/2026-05/a1096_2026_0.pdf).",
    "line": 102
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/gr-art68-assigned-reading-order.txt",
  "source_sha256": "2576c1ed79ea2d83510d9082234b4b7cb350df7be3db121da3b5070afa1cb23d",
  "source_validation": "Own full actualPDFp53 rendered and visually read16November2026. Native body derives from separate Poppler left/right crops in correct column order; each assigned full clause retained including source hyphenation. ActualPDFSHA separately recorded in source register.",
  "source_version_basis": "Actual wholeArt68(4)read; no automatic conversion or unrestricted local work inferred."
}
```

### PA-RESIDENCE-INDIVIDUAL

More than183continuous/alternate days in fiscalyear OR immediately precedingyear, OR permanenthome established inPanama; not a universal183days calendar-year-only test.

```json
{
  "act_article_or_scope": "Gazette30184 printed3, Resolution201-8394/2024 consideration reproducing FiscalCode762-N, first2paragraphs",
  "actual_read_on": "2026-11-16",
  "id": "PA-RESIDENCE-INDIVIDUAL",
  "manual_visual_read_record": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/panama-manual-native.json",
  "official_url": "https://s3-legispan.asamblea.gob.pa/legispan/GACETAS/2020/2024/30184_2024.pdf",
  "quote_mode": "Own visual manual native transcription of actual PDF; short split is lossless; independent visual verification required, no machine-text literal-match assertion.",
  "section": {
    "actual_text": "**Panama.** Art 762-N, reproduced by DGI's Resolution 201-8394/2024, uses more than 183 continuous or alternate days in the fiscal year or immediately preceding year, or an established permanent home. Company direction/administration conditions are separate. The resolution removes the specific 2022 original migration-certificate requirement but maintains the 2016 certificate procedure; DGI can still request migration evidence. [Official Gazette 30184](https://s3-legispan.asamblea.gob.pa/legispan/GACETAS/2020/2024/30184_2024.pdf), printed 3–4.",
    "line": 53
  },
  "short_exact_native_quotes": [
    "Se consideran residentes fiscales de la República de Panamá las personas naturales que permanezcan en el territorio nacional por más de ciento ochenta y tres"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/pa-gazette30184.pdf",
  "source_sha256": "2d863d78d241592169e1bc2bbe0716a0780aee29ff723a305bbd01e00ed7fa74",
  "source_version_basis": "Resolution27November2024, publishedGazette24December2024; actual Gazette images printed3–4 personally read; no2026consolidatedCode claim."
}
```

### PA-RESIDENCE-COMPANY

Domestic companies require materialdirection/administration inPanama; foreigncompanies additionallyregisteredPublicRegistry. Incorporation/personresidence cannot substitute for company test.

```json
{
  "act_article_or_scope": "Gazette30184 printed3, reproduced FiscalCode762-N corporate paragraphs",
  "actual_read_on": "2026-11-16",
  "id": "PA-RESIDENCE-COMPANY",
  "manual_visual_read_record": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/panama-manual-native.json",
  "official_url": "https://s3-legispan.asamblea.gob.pa/legispan/GACETAS/2020/2024/30184_2024.pdf",
  "quote_mode": "Own visual manual native transcription of actual PDF; short split is lossless; independent visual verification required, no machine-text literal-match assertion.",
  "section": {
    "actual_text": "**Panama.** Art 762-N, reproduced by DGI's Resolution 201-8394/2024, uses more than 183 continuous or alternate days in the fiscal year or immediately preceding year, or an established permanent home. Company direction/administration conditions are separate. The resolution removes the specific 2022 original migration-certificate requirement but maintains the 2016 certificate procedure; DGI can still request migration evidence. [Official Gazette 30184](https://s3-legispan.asamblea.gob.pa/legispan/GACETAS/2020/2024/30184_2024.pdf), printed 3–4.",
    "line": 53
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/pa-gazette30184.pdf",
  "source_sha256": "2d863d78d241592169e1bc2bbe0716a0780aee29ff723a305bbd01e00ed7fa74",
  "source_version_basis": "Resolution27November2024, publishedGazette24December2024; actual Gazette images printed3–4 personally read; no2026consolidatedCode claim."
}
```

### PA-TRC-REPEAL-AND-RETAIN

2022amendingresolutionrepealed;2016certificateproceduremaintained;publicationcommencement. Removingoriginalmovementcertificatecondition doesnot eliminate all evidence discretion.

```json
{
  "act_article_or_scope": "Gazette30184 printed4, Resolution201-8394 PRIMERO/SEGUNDO/TERCERO",
  "actual_read_on": "2026-11-16",
  "id": "PA-TRC-REPEAL-AND-RETAIN",
  "manual_visual_read_record": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/panama-manual-native.json",
  "official_url": "https://s3-legispan.asamblea.gob.pa/legispan/GACETAS/2020/2024/30184_2024.pdf",
  "quote_mode": "Own visual manual native transcription of actual PDF; short split is lossless; independent visual verification required, no machine-text literal-match assertion.",
  "section": {
    "actual_text": "**Panama.** Art 762-N, reproduced by DGI's Resolution 201-8394/2024, uses more than 183 continuous or alternate days in the fiscal year or immediately preceding year, or an established permanent home. Company direction/administration conditions are separate. The resolution removes the specific 2022 original migration-certificate requirement but maintains the 2016 certificate procedure; DGI can still request migration evidence. [Official Gazette 30184](https://s3-legispan.asamblea.gob.pa/legispan/GACETAS/2020/2024/30184_2024.pdf), printed 3–4.",
    "line": 53
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/pa-gazette30184.pdf",
  "source_sha256": "2d863d78d241592169e1bc2bbe0716a0780aee29ff723a305bbd01e00ed7fa74",
  "source_version_basis": "Resolution27November2024, publishedGazette24December2024; actual Gazette images printed3–4 personally read; no2026consolidatedCode claim."
}
```

### PA-TRC-EVIDENCE-POWER

DGI may still require migrationinformation/certifications tosupportpendingcertificateprocess despite directdatabaseaccess.

```json
{
  "act_article_or_scope": "Gazette30184 printed4, second complete consideration, final qualifying limb",
  "actual_read_on": "2026-11-16",
  "id": "PA-TRC-EVIDENCE-POWER",
  "manual_visual_read_record": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/panama-manual-native.json",
  "official_url": "https://s3-legispan.asamblea.gob.pa/legispan/GACETAS/2020/2024/30184_2024.pdf",
  "quote_mode": "Own visual manual native transcription of actual PDF; short split is lossless; independent visual verification required, no machine-text literal-match assertion.",
  "section": {
    "actual_text": "**Panama.** Art 762-N, reproduced by DGI's Resolution 201-8394/2024, uses more than 183 continuous or alternate days in the fiscal year or immediately preceding year, or an established permanent home. Company direction/administration conditions are separate. The resolution removes the specific 2022 original migration-certificate requirement but maintains the 2016 certificate procedure; DGI can still request migration evidence. [Official Gazette 30184](https://s3-legispan.asamblea.gob.pa/legispan/GACETAS/2020/2024/30184_2024.pdf), printed 3–4.",
    "line": 53
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/pa-gazette30184.pdf",
  "source_sha256": "2d863d78d241592169e1bc2bbe0716a0780aee29ff723a305bbd01e00ed7fa74",
  "source_version_basis": "Resolution27November2024, publishedGazette24December2024; actual Gazette images printed3–4 personally read; no2026consolidatedCode claim."
}
```

### PA-PERSONAL-RATE

Published individualtariff0through11000;15%excessupto50000;5850plus25%excess50000. Apply actual taxable base, not all foreign-client receipts exempt.

```json
{
  "act_article_or_scope": "DGI IncomeTax individual tariff, all3bands",
  "actual_read_on": "2026-11-16",
  "id": "PA-PERSONAL-RATE",
  "official_url": "https://dgi.mef.gob.pa/DInforme/Tarifa",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "| Panama | Establish actual Panama source. The published individual tariff is zero through PAB 11,000,15% on the excess through PAB 50,000 and 25% above, applied to the actual statutory base; the historical 2011 official compilation and current DGI rate table do not prove that all foreign-client remote services are exempt. Friendly Nations is an immigration category, not a digital-nomad tax exemption or “easy” approval guarantee. Sources: [DGI IncomeTax individual tariff](https://dgi.mef.gob.pa/DInforme/Tarifa). |",
    "line": 85
  },
  "short_exact_native_quotes": [
    "Hasta B/.11,000.00 El impuesto será del 0% De más de B/.11,000.00 hasta B/.50,000.00 El impuesto será el 15% por el excedente de B/. 11,000.00 hasta"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/pa-personal-rate.txt",
  "source_sha256": "620b2e7ab57429d88120299b2f835dec482c301f46c1a18e1fd1d7b210b9b986",
  "source_version_basis": "Actual current authority tariff body personally read with source/base context in dated2011officialCode; no whole2026Codeconsolidation claim."
}
```

### SG-RESIDENCE-183

Annualprecedingcalendar-year basis and at least183dayforeignstay/work route; normalresidentcitizen/PR category separately explained.

```json
{
  "act_article_or_scope": "IRAS source299–311 (annual basis and complete opening resident branches)",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": [
    "Assessment uses income of the preceding calendar year. The citizen/PR route requires normal Singapore residence subject to temporary absence.",
    "The foreigner route requires at least183 days of stay/work in the previous calendar year; alternative administrative routes are separate."
  ],
  "correction_own_read_on": "2026-11-16",
  "id": "SG-RESIDENCE-183",
  "official_url": "https://www.iras.gov.sg/taxes/individual-income-tax/basics-of-individual-income-tax/tax-residency-and-tax-rates/working-out-my-tax-residency",
  "quote_mode": "Permitted short claim-bound native extracts retained within total per-source quote cap; full original condition paraphrase and exact locators supplied. Does not claim full native-clause reproduction.",
  "section": {
    "actual_text": "**Singapore.** Residence is assessed annually on the preceding calendar-year basis. IRAS distinguishes citizens/PRs normally resident, foreigners present/working at least 183 days, a continuous 3-year concession, and a 2-calendar-year employment concession with at least 183 continuous days including immediately adjacent presence. Directors, public entertainers and professionals are excluded from that last concession. A work pass initially treated as resident is reviewed on tax clearance. [IRAS current residence guidance](https://www.iras.gov.sg/taxes/individual-income-tax/basics-of-individual-income-tax/tax-residency-and-tax-rates/working-out-my-tax-residency).",
    "line": 51
  },
  "short_exact_native_quotes": [
    "at least 183 days"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/sg-iras-residence-web.txt",
  "source_sha256": "c9b5138b23d1d867e977e5afff08ecb6c68d92f3049fa092c923628a29ee7e40",
  "source_version_basis": "Current official guidance updated12May2026, full operative/exclusion/concession and examples scope personally read; ordinary currentstatute opening returned403, not read."
}
```

### SG-RESIDENCE-THREE-YEARS

Continuous3consecutiveyearstay/work administrativeconcession, including less183daysfirst/thirdyear under actual conditions.

```json
{
  "act_article_or_scope": "IRAS source347, with opening303–311 and examples349–357",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": [
    "A foreigner continuously staying or working in Singapore across3 consecutive calendar years is treated as resident for all3 years under the administrative concession, including where first/third-year presence is below183 days."
  ],
  "correction_own_read_on": "2026-11-16",
  "id": "SG-RESIDENCE-THREE-YEARS",
  "official_url": "https://www.iras.gov.sg/taxes/individual-income-tax/basics-of-individual-income-tax/tax-residency-and-tax-rates/working-out-my-tax-residency",
  "quote_mode": "Permitted short claim-bound native extracts retained within total per-source quote cap; full original condition paraphrase and exact locators supplied. Does not claim full native-clause reproduction.",
  "section": {
    "actual_text": "**Singapore.** Residence is assessed annually on the preceding calendar-year basis. IRAS distinguishes citizens/PRs normally resident, foreigners present/working at least 183 days, a continuous 3-year concession, and a 2-calendar-year employment concession with at least 183 continuous days including immediately adjacent presence. Directors, public entertainers and professionals are excluded from that last concession. A work pass initially treated as resident is reviewed on tax clearance. [IRAS current residence guidance](https://www.iras.gov.sg/taxes/individual-income-tax/basics-of-individual-income-tax/tax-residency-and-tax-rates/working-out-my-tax-residency).",
    "line": 51
  },
  "short_exact_native_quotes": [
    "3 consecutive years"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/sg-iras-residence-web.txt",
  "source_sha256": "c9b5138b23d1d867e977e5afff08ecb6c68d92f3049fa092c923628a29ee7e40",
  "source_version_basis": "12May2026authorityguidance, not claimed statutory183daytext."
}
```

### SG-RESIDENCE-TWO-YEARS

Employmentmuststraddle2calendaryears;continuousstayincludingimmediatelyadjacentpresence183days;directors/publicentertainers/professionalsexcluded.

```json
{
  "act_article_or_scope": "IRAS source308–309/359–363; actual employee examples365–398",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": [
    "Employment must extend across2 calendar years AND employment plus presence directly before/after it must form a continuous period of at least183 days.",
    "The concession concerns foreign employees; directors, public entertainers and professionals are excluded. The opening list states entry from1January2007.",
    "Continuing to stay into a second year without employment straddling that year does not itself satisfy this concession."
  ],
  "correction_own_read_on": "2026-11-16",
  "id": "SG-RESIDENCE-TWO-YEARS",
  "official_url": "https://www.iras.gov.sg/taxes/individual-income-tax/basics-of-individual-income-tax/tax-residency-and-tax-rates/working-out-my-tax-residency",
  "quote_mode": "Permitted short claim-bound native extracts retained within total per-source quote cap; full original condition paraphrase and exact locators supplied. Does not claim full native-clause reproduction.",
  "section": {
    "actual_text": "**Singapore.** Residence is assessed annually on the preceding calendar-year basis. IRAS distinguishes citizens/PRs normally resident, foreigners present/working at least 183 days, a continuous 3-year concession, and a 2-calendar-year employment concession with at least 183 continuous days including immediately adjacent presence. Directors, public entertainers and professionals are excluded from that last concession. A work pass initially treated as resident is reviewed on tax clearance. [IRAS current residence guidance](https://www.iras.gov.sg/taxes/individual-income-tax/basics-of-individual-income-tax/tax-residency-and-tax-rates/working-out-my-tax-residency).",
    "line": 51
  },
  "short_exact_native_quotes": [
    "straddling 2 calendar years"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/sg-iras-residence-web.txt",
  "source_sha256": "c9b5138b23d1d867e977e5afff08ecb6c68d92f3049fa092c923628a29ee7e40",
  "source_version_basis": "12May2026guidance entireoperativeandallneighbor examples personally read; short distinct native fragments, full conditions stated in own paraphrase."
}
```

### SG-WORKPASS-REVIEW

Workpassinitialresidentclassification is reviewed usingactualresidencerules atcessationtaxclearance;notpermanentimmigration-basedtaxstatus.

```json
{
  "act_article_or_scope": "IRAS actual source311; day-count neighbours315–317",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": [
    "A work pass valid for at least1year initially permits resident classification. At cessation tax clearance the authority reassesses using actual residence rules; a stay below183 days is classified nonresident under that stated review paragraph.",
    "Employment-day counting includes weekends/public holidays and temporary or employment-incidental absences, under the stated authority explanation."
  ],
  "correction_own_read_on": "2026-11-16",
  "id": "SG-WORKPASS-REVIEW",
  "official_url": "https://www.iras.gov.sg/taxes/individual-income-tax/basics-of-individual-income-tax/tax-residency-and-tax-rates/working-out-my-tax-residency",
  "quote_mode": "Permitted short claim-bound native extracts retained within total per-source quote cap; full original condition paraphrase and exact locators supplied. Does not claim full native-clause reproduction.",
  "section": {
    "actual_text": "**Singapore.** Residence is assessed annually on the preceding calendar-year basis. IRAS distinguishes citizens/PRs normally resident, foreigners present/working at least 183 days, a continuous 3-year concession, and a 2-calendar-year employment concession with at least 183 continuous days including immediately adjacent presence. Directors, public entertainers and professionals are excluded from that last concession. A work pass initially treated as resident is reviewed on tax clearance. [IRAS current residence guidance](https://www.iras.gov.sg/taxes/individual-income-tax/basics-of-individual-income-tax/tax-residency-and-tax-rates/working-out-my-tax-residency).",
    "line": 51
  },
  "short_exact_native_quotes": [
    "tax clearance"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/sg-iras-residence-web.txt",
  "source_sha256": "c9b5138b23d1d867e977e5afff08ecb6c68d92f3049fa092c923628a29ee7e40",
  "source_version_basis": "12May2026guidance actualwholeoperativeparagraph read."
}
```

### EE-RESIDENCE-ALTERNATIVES

Home inEstoniaORatleast183daysin12consecutivecalendarmonths;diplomatrouteexists;under183immigrationstaydoesnotdefeathome.

```json
{
  "act_article_or_scope": "EMTA source350–354 complete at-least-one lead/list;356–361/419–436 neighbours",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": [
    "Any one condition suffices: a home in Estonia; physical presence for at least183 days within12 successive calendar months; or being an Estonian diplomat posted abroad.",
    "Home depends on actual permanent/main use and availability; ownership or a population-register entry alone is not decisive. Day counting and treaty residence are separate questions."
  ],
  "correction_own_read_on": "2026-11-16",
  "id": "EE-RESIDENCE-ALTERNATIVES",
  "official_url": "https://www.emta.ee/eraklient/valismaalasele-mitteresidendile/maksuresidentsus/residentsuse-maaramine",
  "quote_mode": "Permitted short claim-bound native extracts retained within total per-source quote cap; full original condition paraphrase and exact locators supplied. Does not claim full native-clause reproduction.",
  "section": {
    "actual_text": "**Estonia.** A home or the 183-day/12-month route can establish domestic residence; see the separate immigration discussion below. **Paraguay:** establish the resident-person scope of Law 6380 and the actual local activity; a migration permit or the word “territorial” cannot by itself prove a foreign-client exemption. No unrecovered universal Paraguay day-count rule is supplied. Sources: [EMTA native Residentsusemääramine:Residendi mõiste and actual home/daycount neighbors](https://www.emta.ee/eraklient/valismaalasele-mitteresidendile/maksuresidentsus/residentsuse-maaramine); [Law6380 Art49 whole](https://www.dnit.gov.py/en/web/portal-institucional/w/ley-n-6380-19).",
    "line": 65
  },
  "short_exact_native_quotes": [
    "elukoht on Eestis"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/ee-residence-web.txt",
  "source_sha256": "1b7c2d88bbee05dcd12f34eb734a0c2d7551d28b195afaab4b7dff4988163c1e",
  "source_version_basis": "Actual fresh native authoritybody344–444read16November; legal-linkedRiigiTeataja returned5lineshell, not statute read."
}
```

### EE-RESIDENCE-FORM

Notifyactualresidencechange viaFormR;homechange/dateand treaty-basedotherstateresidence requireactualfacts/certification, not allproperty ownershipautomaticresidence.

```json
{
  "act_article_or_scope": "EMTA actual361/378 notification;390 change date;394–402 and419–447 treaty/certificate neighbours",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": [
    "A person informs the authority of changed residence circumstances and submits FormR. The actual change of permanent/settled/main home determines the change date; transient-presence periods use the day-count rules.",
    "When treaty residence differs, the other state’s tax-authority-confirmed certificate and its actual start/end dates are considered. An Estonian domestic resident becomes registered nonresident from the other treaty-residence start date on the required facts/certificate.",
    "Property ownership and registration alone do not establish a home; later evidence can cause retrospective recording from the actual relevant date."
  ],
  "correction_own_read_on": "2026-11-16",
  "id": "EE-RESIDENCE-FORM",
  "official_url": "https://www.emta.ee/eraklient/valismaalasele-mitteresidendile/maksuresidentsus/residentsuse-maaramine",
  "quote_mode": "Permitted short claim-bound native extracts retained within total per-source quote cap; full original condition paraphrase and exact locators supplied. Does not claim full native-clause reproduction.",
  "section": {
    "actual_text": "**Estonia.** A home or the 183-day/12-month route can establish domestic residence; see the separate immigration discussion below. **Paraguay:** establish the resident-person scope of Law 6380 and the actual local activity; a migration permit or the word “territorial” cannot by itself prove a foreign-client exemption. No unrecovered universal Paraguay day-count rule is supplied. Sources: [EMTA native Residentsusemääramine:Residendi mõiste and actual home/daycount neighbors](https://www.emta.ee/eraklient/valismaalasele-mitteresidendile/maksuresidentsus/residentsuse-maaramine); [Law6380 Art49 whole](https://www.dnit.gov.py/en/web/portal-institucional/w/ley-n-6380-19).",
    "line": 65
  },
  "short_exact_native_quotes": [
    "vorm R"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/ee-residence-web.txt",
  "source_sha256": "1b7c2d88bbee05dcd12f34eb734a0c2d7551d28b195afaab4b7dff4988163c1e",
  "source_version_basis": "Actual operativeandhome/daycountneighbors344–444read; dateofotherstatetreatyresidencematter."
}
```

### GR-5C-LEGAL-ELIGIBILITY

5of6previousyearnonresidence, qualifyingEU/EEA/admincooperationpriorstate, actualGreekqualifyingemployment and2yearstayintention cumulative;2026publicemploymentexclusiondeletion separatelyoverlaid.

```json
{
  "act_article_or_scope": "A1138/2025 Art1(2) substitutingA1087Art3(1), printed67012",
  "actual_read_on": "2026-11-16",
  "id": "GR-5C-LEGAL-ELIGIBILITY",
  "official_url": "https://www.aade.gr/sites/default/files/2025-10/a1138fek.pdf",
  "quote_mode": "Actual precise legal operative paragraph, deduplicated from personally opened official PDF text, split losslessly into <=25-word fragments. Returned web line labels removed only; no claim of visual glyph verification.",
  "section": {
    "actual_text": "Greece's Art 68 route is a national visa up to 12 months for remote work for employers/clients outside Greece. The ordinary resources test is EUR 3500 net monthly under the stated conditions, plus 20% spouse/partner and 15% each child. A separate conditional 2-year residence permit can follow an application before visa expiry. Law 5275/2026 Art 13 repealed the former Art 12(7) short-stay/visa-waiver in-country path. The conditional Art 5C 50% relief for qualifying Greek employment/sole-business income lasts 7 tax years; it requires its own previous 5-of-6-year nonresidence, eligible prior country, actual qualifying activity, intended 2-year stay and application/approval conditions. The 2026 A1096 procedure overlay covers specified applications from 28 July 2025 and pending then, including public employment. A nomad visa does not itself establish Art 5C eligibility. Sources: [Law5038/2023 Art68(2)(e)](https://migration.gov.gr/wp-content/uploads/2023/04/%CE%9A%CF%8E%CE%B4%CE%B9%CE%BA%CE%B1%CF%82-%CE%9C%CE%B5%CF%84%CE%B1%CE%BD%CE%AC%CF%83%CF%84%CE%B5%CF%85%CF%83%CE%B7%CF%82.pdf); [Law5275/2026Art13 introductory operative amendments](https://migration.gov.gr/wp-content/uploads/2026/02/%CE%A6%CE%95%CE%9A%CE%9117_6.2.2025.pdf); [A1138/2025 Art1(2) substitutingA1087Art3(1)](https://www.aade.gr/sites/default/files/2025-10/a1138fek.pdf); [A1087/2021Art5(1)](https://www.aade.gr/sites/default/files/2025-10/%CE%91.1087_2021.pdf); [A1096/2026 Art2 complete](https://www.aade.gr/sites/default/files/2026-05/a1096_2026_0.pdf).",
    "line": 102
  },
  "short_exact_native_quotes": [
    "1. Φυσικό πρόσωπο, που μεταφέρει τη φορολογική κα\u0002τοικία του στην Ελλάδα υπάγεται σε φορολόγηση, όπως ορίζεται στην παρ. 1 του άρθρου 5 της παρούσας, για"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/gr-a1138-native-web.txt",
  "source_sha256": "fa6cb0534ce095dd98bf153dbaaa87c0999b455061a12512294cfaf46a1053ed",
  "source_version_basis": "GazetteB5301/3October2025, own complete operative0–581 except unreturnedline545; full3conditions/documents read; A1096/2026expressly deletes nowobsoleteArt3(5)lastsentence."
}
```

### GR-5C-PRIOR-STATE

Administrative-cooperationalternative means internationalconvention allowingallinformation necessary toapplycontractingstatestaxlegislation;AADEchecksapplicantpriorstate.

```json
{
  "act_article_or_scope": "A1087Art3(4) as substituted2025, printed67013",
  "actual_read_on": "2026-11-16",
  "id": "GR-5C-PRIOR-STATE",
  "official_url": "https://www.aade.gr/sites/default/files/2025-10/a1138fek.pdf",
  "quote_mode": "Actual precise legal operative paragraph, deduplicated from personally opened official PDF text, split losslessly into <=25-word fragments. Returned web line labels removed only; no claim of visual glyph verification.",
  "section": {
    "actual_text": "Greece's Art 68 route is a national visa up to 12 months for remote work for employers/clients outside Greece. The ordinary resources test is EUR 3500 net monthly under the stated conditions, plus 20% spouse/partner and 15% each child. A separate conditional 2-year residence permit can follow an application before visa expiry. Law 5275/2026 Art 13 repealed the former Art 12(7) short-stay/visa-waiver in-country path. The conditional Art 5C 50% relief for qualifying Greek employment/sole-business income lasts 7 tax years; it requires its own previous 5-of-6-year nonresidence, eligible prior country, actual qualifying activity, intended 2-year stay and application/approval conditions. The 2026 A1096 procedure overlay covers specified applications from 28 July 2025 and pending then, including public employment. A nomad visa does not itself establish Art 5C eligibility. Sources: [Law5038/2023 Art68(2)(e)](https://migration.gov.gr/wp-content/uploads/2023/04/%CE%9A%CF%8E%CE%B4%CE%B9%CE%BA%CE%B1%CF%82-%CE%9C%CE%B5%CF%84%CE%B1%CE%BD%CE%AC%CF%83%CF%84%CE%B5%CF%85%CF%83%CE%B7%CF%82.pdf); [Law5275/2026Art13 introductory operative amendments](https://migration.gov.gr/wp-content/uploads/2026/02/%CE%A6%CE%95%CE%9A%CE%9117_6.2.2025.pdf); [A1138/2025 Art1(2) substitutingA1087Art3(1)](https://www.aade.gr/sites/default/files/2025-10/a1138fek.pdf); [A1087/2021Art5(1)](https://www.aade.gr/sites/default/files/2025-10/%CE%91.1087_2021.pdf); [A1096/2026 Art2 complete](https://www.aade.gr/sites/default/files/2026-05/a1096_2026_0.pdf).",
    "line": 102
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/gr-a1138-native-web.txt",
  "source_sha256": "fa6cb0534ce095dd98bf153dbaaa87c0999b455061a12512294cfaf46a1053ed",
  "source_version_basis": "Actual2025operativelegalclause read with2026overlay; no inventedlistofeligiblecountries."
}
```

### GR-5C-SOLE-BUSINESS

Qualifyingindividualsolebusinessrequires actualbusinesscommencementdeclaration andspecifiedsupportingconditions;notanyforeignclientnomadworkautomaticrelief.

```json
{
  "act_article_or_scope": "A1087Art3(7) as substituted2025, printed67014",
  "actual_read_on": "2026-11-16",
  "id": "GR-5C-SOLE-BUSINESS",
  "official_url": "https://www.aade.gr/sites/default/files/2025-10/a1138fek.pdf",
  "quote_mode": "Actual precise legal operative paragraph, deduplicated from personally opened official PDF text, split losslessly into <=25-word fragments. Returned web line labels removed only; no claim of visual glyph verification.",
  "section": {
    "actual_text": "Greece's Art 68 route is a national visa up to 12 months for remote work for employers/clients outside Greece. The ordinary resources test is EUR 3500 net monthly under the stated conditions, plus 20% spouse/partner and 15% each child. A separate conditional 2-year residence permit can follow an application before visa expiry. Law 5275/2026 Art 13 repealed the former Art 12(7) short-stay/visa-waiver in-country path. The conditional Art 5C 50% relief for qualifying Greek employment/sole-business income lasts 7 tax years; it requires its own previous 5-of-6-year nonresidence, eligible prior country, actual qualifying activity, intended 2-year stay and application/approval conditions. The 2026 A1096 procedure overlay covers specified applications from 28 July 2025 and pending then, including public employment. A nomad visa does not itself establish Art 5C eligibility. Sources: [Law5038/2023 Art68(2)(e)](https://migration.gov.gr/wp-content/uploads/2023/04/%CE%9A%CF%8E%CE%B4%CE%B9%CE%BA%CE%B1%CF%82-%CE%9C%CE%B5%CF%84%CE%B1%CE%BD%CE%AC%CF%83%CF%84%CE%B5%CF%85%CF%83%CE%B7%CF%82.pdf); [Law5275/2026Art13 introductory operative amendments](https://migration.gov.gr/wp-content/uploads/2026/02/%CE%A6%CE%95%CE%9A%CE%9117_6.2.2025.pdf); [A1138/2025 Art1(2) substitutingA1087Art3(1)](https://www.aade.gr/sites/default/files/2025-10/a1138fek.pdf); [A1087/2021Art5(1)](https://www.aade.gr/sites/default/files/2025-10/%CE%91.1087_2021.pdf); [A1096/2026 Art2 complete](https://www.aade.gr/sites/default/files/2026-05/a1096_2026_0.pdf).",
    "line": 102
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/gr-a1138-native-web.txt",
  "source_sha256": "fa6cb0534ce095dd98bf153dbaaa87c0999b455061a12512294cfaf46a1053ed",
  "source_version_basis": "Actual2025legaloperative paragraph; fullneighbor3(6)/(8)read,2026procedureoverlayread."
}
```

### GR-5C-CATEGORY-CONDITIONS

BothGreekemployment/businesscategoriescanqualifyonlywhereeachhasitsconditions;otherwise reductiononlyeligiblecategory.

```json
{
  "act_article_or_scope": "A1087Art3(8) as substituted2025, printed67014",
  "actual_read_on": "2026-11-16",
  "id": "GR-5C-CATEGORY-CONDITIONS",
  "official_url": "https://www.aade.gr/sites/default/files/2025-10/a1138fek.pdf",
  "quote_mode": "Actual precise legal operative paragraph, deduplicated from personally opened official PDF text, split losslessly into <=25-word fragments. Returned web line labels removed only; no claim of visual glyph verification.",
  "section": {
    "actual_text": "Greece's Art 68 route is a national visa up to 12 months for remote work for employers/clients outside Greece. The ordinary resources test is EUR 3500 net monthly under the stated conditions, plus 20% spouse/partner and 15% each child. A separate conditional 2-year residence permit can follow an application before visa expiry. Law 5275/2026 Art 13 repealed the former Art 12(7) short-stay/visa-waiver in-country path. The conditional Art 5C 50% relief for qualifying Greek employment/sole-business income lasts 7 tax years; it requires its own previous 5-of-6-year nonresidence, eligible prior country, actual qualifying activity, intended 2-year stay and application/approval conditions. The 2026 A1096 procedure overlay covers specified applications from 28 July 2025 and pending then, including public employment. A nomad visa does not itself establish Art 5C eligibility. Sources: [Law5038/2023 Art68(2)(e)](https://migration.gov.gr/wp-content/uploads/2023/04/%CE%9A%CF%8E%CE%B4%CE%B9%CE%BA%CE%B1%CF%82-%CE%9C%CE%B5%CF%84%CE%B1%CE%BD%CE%AC%CF%83%CF%84%CE%B5%CF%85%CF%83%CE%B7%CF%82.pdf); [Law5275/2026Art13 introductory operative amendments](https://migration.gov.gr/wp-content/uploads/2026/02/%CE%A6%CE%95%CE%9A%CE%9117_6.2.2025.pdf); [A1138/2025 Art1(2) substitutingA1087Art3(1)](https://www.aade.gr/sites/default/files/2025-10/a1138fek.pdf); [A1087/2021Art5(1)](https://www.aade.gr/sites/default/files/2025-10/%CE%91.1087_2021.pdf); [A1096/2026 Art2 complete](https://www.aade.gr/sites/default/files/2026-05/a1096_2026_0.pdf).",
    "line": 102
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/gr-a1138-native-web.txt",
  "source_sha256": "fa6cb0534ce095dd98bf153dbaaa87c0999b455061a12512294cfaf46a1053ed",
  "source_version_basis": "Actual2025legaloperative paragraph, not a blanket50%discounttoallworldwideincome."
}
```

### GR-5C-SEVEN-YEARS

Approvedregimeendsautomaticallyafter7taxyears, cannotextendbeyond7;actualeligibilitycontinuesandcessationrulesseparate.

```json
{
  "act_article_or_scope": "A1087Art4(7) as substituted2025, printed67015",
  "actual_read_on": "2026-11-16",
  "id": "GR-5C-SEVEN-YEARS",
  "official_url": "https://www.aade.gr/sites/default/files/2025-10/a1138fek.pdf",
  "quote_mode": "Actual precise legal operative paragraph, deduplicated from personally opened official PDF text, split losslessly into <=25-word fragments. Returned web line labels removed only; no claim of visual glyph verification.",
  "section": {
    "actual_text": "Greece's Art 68 route is a national visa up to 12 months for remote work for employers/clients outside Greece. The ordinary resources test is EUR 3500 net monthly under the stated conditions, plus 20% spouse/partner and 15% each child. A separate conditional 2-year residence permit can follow an application before visa expiry. Law 5275/2026 Art 13 repealed the former Art 12(7) short-stay/visa-waiver in-country path. The conditional Art 5C 50% relief for qualifying Greek employment/sole-business income lasts 7 tax years; it requires its own previous 5-of-6-year nonresidence, eligible prior country, actual qualifying activity, intended 2-year stay and application/approval conditions. The 2026 A1096 procedure overlay covers specified applications from 28 July 2025 and pending then, including public employment. A nomad visa does not itself establish Art 5C eligibility. Sources: [Law5038/2023 Art68(2)(e)](https://migration.gov.gr/wp-content/uploads/2023/04/%CE%9A%CF%8E%CE%B4%CE%B9%CE%BA%CE%B1%CF%82-%CE%9C%CE%B5%CF%84%CE%B1%CE%BD%CE%AC%CF%83%CF%84%CE%B5%CF%85%CF%83%CE%B7%CF%82.pdf); [Law5275/2026Art13 introductory operative amendments](https://migration.gov.gr/wp-content/uploads/2026/02/%CE%A6%CE%95%CE%9A%CE%9117_6.2.2025.pdf); [A1138/2025 Art1(2) substitutingA1087Art3(1)](https://www.aade.gr/sites/default/files/2025-10/a1138fek.pdf); [A1087/2021Art5(1)](https://www.aade.gr/sites/default/files/2025-10/%CE%91.1087_2021.pdf); [A1096/2026 Art2 complete](https://www.aade.gr/sites/default/files/2026-05/a1096_2026_0.pdf).",
    "line": 102
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/gr-a1138-native-web.txt",
  "source_sha256": "fa6cb0534ce095dd98bf153dbaaa87c0999b455061a12512294cfaf46a1053ed",
  "source_version_basis": "Actual2025legaloperative paragraph;2026A1096doesnotalterthisperiodinitsreadoperativeamendments."
}
```

### GR-5C-FIFTY-BASE

Baselegal50%exemptionconcerns actualGreekemployment/businessincome afteracceptedapplication, withspecifiedcrossreference; historicalsolidaritywording notclaimedcurrent2026tax.

```json
{
  "act_article_or_scope": "A1087/2021Art5(1), actualbaselegalparagraphPDFp11",
  "actual_read_on": "2026-11-16",
  "id": "GR-5C-FIFTY-BASE",
  "official_url": "https://www.aade.gr/sites/default/files/2025-10/%CE%91.1087_2021.pdf",
  "quote_mode": "Actual precise legal operative paragraph, deduplicated from personally opened official PDF text, split losslessly into <=25-word fragments. Returned web line labels removed only; no claim of visual glyph verification.",
  "section": {
    "actual_text": "Greece's Art 68 route is a national visa up to 12 months for remote work for employers/clients outside Greece. The ordinary resources test is EUR 3500 net monthly under the stated conditions, plus 20% spouse/partner and 15% each child. A separate conditional 2-year residence permit can follow an application before visa expiry. Law 5275/2026 Art 13 repealed the former Art 12(7) short-stay/visa-waiver in-country path. The conditional Art 5C 50% relief for qualifying Greek employment/sole-business income lasts 7 tax years; it requires its own previous 5-of-6-year nonresidence, eligible prior country, actual qualifying activity, intended 2-year stay and application/approval conditions. The 2026 A1096 procedure overlay covers specified applications from 28 July 2025 and pending then, including public employment. A nomad visa does not itself establish Art 5C eligibility. Sources: [Law5038/2023 Art68(2)(e)](https://migration.gov.gr/wp-content/uploads/2023/04/%CE%9A%CF%8E%CE%B4%CE%B9%CE%BA%CE%B1%CF%82-%CE%9C%CE%B5%CF%84%CE%B1%CE%BD%CE%AC%CF%83%CF%84%CE%B5%CF%85%CF%83%CE%B7%CF%82.pdf); [Law5275/2026Art13 introductory operative amendments](https://migration.gov.gr/wp-content/uploads/2026/02/%CE%A6%CE%95%CE%9A%CE%9117_6.2.2025.pdf); [A1138/2025 Art1(2) substitutingA1087Art3(1)](https://www.aade.gr/sites/default/files/2025-10/a1138fek.pdf); [A1087/2021Art5(1)](https://www.aade.gr/sites/default/files/2025-10/%CE%91.1087_2021.pdf); [A1096/2026 Art2 complete](https://www.aade.gr/sites/default/files/2026-05/a1096_2026_0.pdf).",
    "line": 102
  },
  "short_exact_native_quotes": [
    "1. Εφόσον γίνει δεκτή η αίτηση, σύμφωνα με τη διαδικασία που ορίζεται στην παρούσα, το φυσικό πρόσωπο απαλλάσσεται από τον φόρο εισοδήματος και από την"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/gr-a1087-native-web.txt",
  "source_sha256": "aa23e599285ff1f65bca69d8366db3265051b566b93c7244d21eb46b4602630f",
  "source_version_basis": "BASE2021text, despite2025-10filelocation; notmislabelledconsolidation. Current2025A1138Art1(4)amendedreturnparagraph additionallyconfirms50%;2025FAQcurrentbaseand2026procedureoverlaypersonallyread."
}
```

### GR-5C-FIFTY-2025-CORROBORATION

2025operativeamendmentexpresslyretains50%ofincomeadmittedtospecialregime;thispartconfirmstherate,notaseparatefilinginstruction.

```json
{
  "act_article_or_scope": "A1138/2025Art1(4), substitutedA1087Art5(9), printed67017 returned548–551",
  "actual_read_on": "2026-11-16",
  "id": "GR-5C-FIFTY-2025-CORROBORATION",
  "official_url": "https://www.aade.gr/sites/default/files/2025-10/a1138fek.pdf",
  "quote_mode": "Actual precise legal operative paragraph, deduplicated from personally opened official PDF text, split losslessly into <=25-word fragments. Returned web line labels removed only; no claim of visual glyph verification.",
  "section": {
    "actual_text": "Greece's Art 68 route is a national visa up to 12 months for remote work for employers/clients outside Greece. The ordinary resources test is EUR 3500 net monthly under the stated conditions, plus 20% spouse/partner and 15% each child. A separate conditional 2-year residence permit can follow an application before visa expiry. Law 5275/2026 Art 13 repealed the former Art 12(7) short-stay/visa-waiver in-country path. The conditional Art 5C 50% relief for qualifying Greek employment/sole-business income lasts 7 tax years; it requires its own previous 5-of-6-year nonresidence, eligible prior country, actual qualifying activity, intended 2-year stay and application/approval conditions. The 2026 A1096 procedure overlay covers specified applications from 28 July 2025 and pending then, including public employment. A nomad visa does not itself establish Art 5C eligibility. Sources: [Law5038/2023 Art68(2)(e)](https://migration.gov.gr/wp-content/uploads/2023/04/%CE%9A%CF%8E%CE%B4%CE%B9%CE%BA%CE%B1%CF%82-%CE%9C%CE%B5%CF%84%CE%B1%CE%BD%CE%AC%CF%83%CF%84%CE%B5%CF%85%CF%83%CE%B7%CF%82.pdf); [Law5275/2026Art13 introductory operative amendments](https://migration.gov.gr/wp-content/uploads/2026/02/%CE%A6%CE%95%CE%9A%CE%9117_6.2.2025.pdf); [A1138/2025 Art1(2) substitutingA1087Art3(1)](https://www.aade.gr/sites/default/files/2025-10/a1138fek.pdf); [A1087/2021Art5(1)](https://www.aade.gr/sites/default/files/2025-10/%CE%91.1087_2021.pdf); [A1096/2026 Art2 complete](https://www.aade.gr/sites/default/files/2026-05/a1096_2026_0.pdf).",
    "line": 102
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/gr-a1138-native-web.txt",
  "source_sha256": "fa6cb0534ce095dd98bf153dbaaa87c0999b455061a12512294cfaf46a1053ed",
  "source_version_basis": "Actual2025gazetteoperativecontextread; line545notreturnedandnotquoted, therefore nofullfilingmanualclaimed."
}
```

### UK-SRT-ORDER

EachUKtaxyeartestedseparately;183daysresident;under183 requires actual automaticoverseas/automaticUK/ties order withexceptional/deemingcountingconditions.

```json
{
  "act_article_or_scope": "RDR3section1 complete summary/order/counting references",
  "actual_read_on": "2026-11-16",
  "id": "UK-SRT-ORDER",
  "official_url": "https://www.gov.uk/government/publications/rdr3-statutory-residence-test-srt/guidance-note-for-statutory-residence-test-srt-rdr3",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "**UK.** The tax year runs from 6 April to 5 April. Apply the automatic overseas tests, automatic UK tests and sufficient-ties test in their legal order. Fewer than 183 days does not alone establish nonresidence; an available home, work and ties can matter. Each tax year is tested separately. [RDR 3 current guidance](https://www.gov.uk/government/publications/rdr3-statutory-residence-test-srt/guidance-note-for-statutory-residence-test-srt-rdr3); [departure procedure](https://www.gov.uk/tax-right-retire-abroad-return-to-uk).",
    "line": 41
  },
  "short_exact_native_quotes": [
    "1. Statutory Residence Test (SRT) The SRT came into effect on 6 April 2013. You can read further information on the full"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/uk-rdr3.txt",
  "source_sha256": "89ea9047d1ded213a6a534e4c0cd0e487c9be1e1b8c1c621f4807b16800de5f9",
  "source_version_basis": "Actual current authorityguidance wholeoperative550–1019personallyread;OGLv3expresslicence atretained533; FA2013Sch45notpersonallyrecovered, no statutoryfulltestexecutionclaim."
}
```

### UK-SPLIT-ALL-CASES

UKresidentyearcanbesplitonlyundercompleteapplicableconditions;departurecases1–3/arrival4–8, allapplicablecasesandpriorityrules;notautomaticfractionalrateforeveryreceipt.

```json
{
  "act_article_or_scope": "RDR3section6 complete",
  "actual_read_on": "2026-11-16",
  "id": "UK-SPLIT-ALL-CASES",
  "official_url": "https://www.gov.uk/government/publications/rdr3-statutory-residence-test-srt/guidance-note-for-statutory-residence-test-srt-rdr3",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "UK split-year treatment has 8 defined cases: departures 1–3 and arrivals 4–8, each with complete conditions and priority rules. It is not an elective division into independently taxed halves for every receipt. Germany follows the actual statutory residence/ordinary-residence facts, with source taxation and annual-rate consequences separately. Australia's cessation date is factual and a partial-year position must be tested under the actual law. Sources: [RDR3section6 complete](https://www.gov.uk/government/publications/rdr3-statutory-residence-test-srt/guidance-note-for-statutory-residence-test-srt-rdr3).",
    "line": 141
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/uk-rdr3.txt",
  "source_sha256": "89ea9047d1ded213a6a534e4c0cd0e487c9be1e1b8c1c621f4807b16800de5f9",
  "source_version_basis": "Current authorityguidance personally read with overseas/UK/ties/deceased/tempnonresneighbors; OGLv3."
}
```

### UK-DEPARTURE-NOTIFICATION

6April–5April;actualpermanent/full-taxyearwork/foreignnationaldeparture;nonSelfAssessmentP85vsSelfAssessmentSA109/commercialsoftware/post;specifiedUKemployerfulltaxyearP85stillrequiredwithSA109.

```json
{
  "act_article_or_scope": "When toinformHMRC, taxyear, andwholeHowtotellHMRC",
  "actual_read_on": "2026-11-16",
  "id": "UK-DEPARTURE-NOTIFICATION",
  "official_url": "https://www.gov.uk/tax-right-retire-abroad-return-to-uk",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "Departure reporting and tax residence are different tasks. A UK non-Self-Assessment departure generally uses P85; a Self-Assessment filer reports residence through SA109, with the published special P85 condition for certain UK-employer departures. An Abmeldung, lease, utility bill, bank account or tax residence certificate is evidence of a particular fact, not universal proof that the former country has relinquished taxation. File each return or information form when that country's actual duty requires it; do not invent mandatory returns in both countries where none exists. Sources: [When toinformHMRC](https://www.gov.uk/tax-right-retire-abroad-return-to-uk).",
    "line": 145
  },
  "short_exact_native_quotes": [
    "You must tell HM Revenue and Customs (HMRC) if any of the following apply, you’re: leaving the UK to live abroad permanently going to work"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/uk-departure.txt",
  "source_sha256": "ac4697802b08a44516dfae6167827ea4a5ebd625275f44e611f4b72fc20220ef",
  "source_version_basis": "Actual currentauthoritywholeoperativeparagraphspersonallyread; OGLlicenced; no newfilingdeadline beyond actualscope inGuide."
}
```

### HR-NOMAD-FUNDS-STATUTORY

Nomadmonthlyfundsareatleast2.5prior-yearaveragenetmonthlysalary;eachadditionalfamily/partner adds10%ofaveragesalary, not10%ofprincipalrequirement.

```json
{
  "act_article_or_scope": "RegNN14/2021 Art2(3)complete, withArts1–6personallyread",
  "actual_read_on": "2026-11-16",
  "id": "HR-NOMAD-FUNDS-STATUTORY",
  "official_url": "https://narodne-novine.nn.hr/clanci/sluzbeni/2021_02_14_273.html",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "Croatia's current permission can extend to 18 months, with shorter-stay extension and later-application conditions. The current published funds amount is EUR 3622.50 per month for the principal. The regulation uses 2.5 times the prior-year average monthly net salary, plus 10% of that average for each additional qualifying family member or partner; alternative period-total evidence is also published. The 2020 tax amendment introduced an exemption for specified digital-nomad receipts from work for a foreign employer/business. It did not create an arbitrary first-tax-year exemption for every receipt. The complete current tax-law overlay remains specifically reserved below; the immigration conditions above are separately recovered current authority rules. Sources: [ActNN40/2025Art12substitutingArt61(1)](https://narodne-novine.nn.hr/clanci/sluzbeni/2025_03_40_545.html); [RegNN14/2021 Art2(3)complete](https://narodne-novine.nn.hr/clanci/sluzbeni/2021_02_14_273.html); [RegNN3/2026 all3articles](https://narodne-novine.nn.hr/clanci/sluzbeni/full/2026_01_3_10.html); [MUPdigitalnomadproof-of-funds currentprincipalamountparagraph](https://mup.gov.hr/aliens-281621/286833).",
    "line": 98
  },
  "short_exact_native_quotes": [
    "(3) Iznimno od stavaka 1. i 2. ovog članka, državljanin treće zemlje koji podnosi zahtjev za odobrenje privremenog boravka u svrhu boravka digitalnog nomada, mora"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/hr-funds2021.txt",
  "source_sha256": "517467e5caf7ad1450645358ab8037103e57ad4a1f9da278fef04369c02ebe8b",
  "source_version_basis": "Actual whole6articleofficialregulationread16November2026; amended2026overlay separatelyreadleavesthisparagraphunchanged."
}
```

### HR-NOMAD-FUNDS-2026-OVERLAY

2026amendmentchangesgeneralArt2(1)andaddsother-purposesArt2(4);nomadArt2(3)2.5formula unchanged;8thdayafterpublicationcommencement.

```json
{
  "act_article_or_scope": "RegNN3/2026 all3articles",
  "actual_read_on": "2026-11-16",
  "id": "HR-NOMAD-FUNDS-2026-OVERLAY",
  "official_url": "https://narodne-novine.nn.hr/clanci/sluzbeni/full/2026_01_3_10.html",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "Croatia's current permission can extend to 18 months, with shorter-stay extension and later-application conditions. The current published funds amount is EUR 3622.50 per month for the principal. The regulation uses 2.5 times the prior-year average monthly net salary, plus 10% of that average for each additional qualifying family member or partner; alternative period-total evidence is also published. The 2020 tax amendment introduced an exemption for specified digital-nomad receipts from work for a foreign employer/business. It did not create an arbitrary first-tax-year exemption for every receipt. The complete current tax-law overlay remains specifically reserved below; the immigration conditions above are separately recovered current authority rules. Sources: [ActNN40/2025Art12substitutingArt61(1)](https://narodne-novine.nn.hr/clanci/sluzbeni/2025_03_40_545.html); [RegNN14/2021 Art2(3)complete](https://narodne-novine.nn.hr/clanci/sluzbeni/2021_02_14_273.html); [RegNN3/2026 all3articles](https://narodne-novine.nn.hr/clanci/sluzbeni/full/2026_01_3_10.html); [MUPdigitalnomadproof-of-funds currentprincipalamountparagraph](https://mup.gov.hr/aliens-281621/286833).",
    "line": 98
  },
  "short_exact_native_quotes": [
    "Članak 1. U Uredbi o načinu izračuna i visini sredstava za uzdržavanje državljanina treće zemlje u Republici Hrvatskoj (»Narodne novine«, broj 14/21.), u članku 1."
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/hr-funds2026.txt",
  "source_sha256": "d518f2639ec678d428e720dc53982651c67a7f2215c93266b4d767c4a26b09db",
  "source_version_basis": "Actual all3articlesandpreliminariespersonallyread16November2026, published9January2026;notinferredfromsearchsnippets."
}
```

### HR-NOMAD-18MONTHS-STATUTORY

Nomadtemporaryresidenceupto18months, onceextensionwithinthattotal;notuniversal1yearnonrenewablerule.

```json
{
  "act_article_or_scope": "ActNN40/2025Art12substitutingArt61(1), completeparagraph",
  "actual_read_on": "2026-11-16",
  "id": "HR-NOMAD-18MONTHS-STATUTORY",
  "official_url": "https://narodne-novine.nn.hr/clanci/sluzbeni/2025_03_40_545.html",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "Croatia's current permission can extend to 18 months, with shorter-stay extension and later-application conditions. The current published funds amount is EUR 3622.50 per month for the principal. The regulation uses 2.5 times the prior-year average monthly net salary, plus 10% of that average for each additional qualifying family member or partner; alternative period-total evidence is also published. The 2020 tax amendment introduced an exemption for specified digital-nomad receipts from work for a foreign employer/business. It did not create an arbitrary first-tax-year exemption for every receipt. The complete current tax-law overlay remains specifically reserved below; the immigration conditions above are separately recovered current authority rules. Sources: [ActNN40/2025Art12substitutingArt61(1)](https://narodne-novine.nn.hr/clanci/sluzbeni/2025_03_40_545.html); [RegNN14/2021 Art2(3)complete](https://narodne-novine.nn.hr/clanci/sluzbeni/2021_02_14_273.html); [RegNN3/2026 all3articles](https://narodne-novine.nn.hr/clanci/sluzbeni/full/2026_01_3_10.html); [MUPdigitalnomadproof-of-funds currentprincipalamountparagraph](https://mup.gov.hr/aliens-281621/286833).",
    "line": 98
  },
  "short_exact_native_quotes": [
    "»(1) Odobrenje za privremeni boravak izdaje se na: – rok važenja do godine dana, osim ako ovim Zakonom nije drukčije propisano – rok važenja do"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/hr-immigration2025.txt",
  "source_sha256": "ae619fccd0ec40a70f2bdcdc87c0fc4d8de02274ef1e25c1e138724e89286898",
  "source_version_basis": "OwnactualArts9–13and96commencementread, notwhole96articleAct. General8thdayeffect; specific2026exceptionsotherprovisions, not nomad18months."
}
```

### HR-NOMAD-REAPPLICATION

Newnomadapplicationafter6monthsofexpiryofspecifiedpriornomad/otherpurpose/family/partnershippermissions;notautomaticback-to-backnewpermission.

```json
{
  "act_article_or_scope": "ActNN40/2025Art9substitutingArt57(4), bothlimbs",
  "actual_read_on": "2026-11-16",
  "id": "HR-NOMAD-REAPPLICATION",
  "official_url": "https://narodne-novine.nn.hr/clanci/sluzbeni/2025_03_40_545.html",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "Croatia's current permission can extend to 18 months, with shorter-stay extension and later-application conditions. The current published funds amount is EUR 3622.50 per month for the principal. The regulation uses 2.5 times the prior-year average monthly net salary, plus 10% of that average for each additional qualifying family member or partner; alternative period-total evidence is also published. The 2020 tax amendment introduced an exemption for specified digital-nomad receipts from work for a foreign employer/business. It did not create an arbitrary first-tax-year exemption for every receipt. The complete current tax-law overlay remains specifically reserved below; the immigration conditions above are separately recovered current authority rules. Sources: [ActNN40/2025Art12substitutingArt61(1)](https://narodne-novine.nn.hr/clanci/sluzbeni/2025_03_40_545.html); [RegNN14/2021 Art2(3)complete](https://narodne-novine.nn.hr/clanci/sluzbeni/2021_02_14_273.html); [RegNN3/2026 all3articles](https://narodne-novine.nn.hr/clanci/sluzbeni/full/2026_01_3_10.html); [MUPdigitalnomadproof-of-funds currentprincipalamountparagraph](https://mup.gov.hr/aliens-281621/286833).",
    "line": 98
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/hr-immigration2025.txt",
  "source_sha256": "ae619fccd0ec40a70f2bdcdc87c0fc4d8de02274ef1e25c1e138724e89286898",
  "source_version_basis": "ActualArt9andall9–13neighborsread; notclaimwholeconsolidatedimmigrationlawread."
}
```

### HR-2025-COMMENCEMENT

8thdayafterpublicationgeneralcommencement;specifiedsanction/employergatesalone1January2026exceptions, not delayofnomad18months.

```json
{
  "act_article_or_scope": "ActNN40/2025Art96whole",
  "actual_read_on": "2026-11-16",
  "id": "HR-2025-COMMENCEMENT",
  "official_url": "https://narodne-novine.nn.hr/clanci/sluzbeni/2025_03_40_545.html",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "Croatia's current permission can extend to 18 months, with shorter-stay extension and later-application conditions. The current published funds amount is EUR 3622.50 per month for the principal. The regulation uses 2.5 times the prior-year average monthly net salary, plus 10% of that average for each additional qualifying family member or partner; alternative period-total evidence is also published. The 2020 tax amendment introduced an exemption for specified digital-nomad receipts from work for a foreign employer/business. It did not create an arbitrary first-tax-year exemption for every receipt. The complete current tax-law overlay remains specifically reserved below; the immigration conditions above are separately recovered current authority rules. Sources: [ActNN40/2025Art12substitutingArt61(1)](https://narodne-novine.nn.hr/clanci/sluzbeni/2025_03_40_545.html); [RegNN14/2021 Art2(3)complete](https://narodne-novine.nn.hr/clanci/sluzbeni/2021_02_14_273.html); [RegNN3/2026 all3articles](https://narodne-novine.nn.hr/clanci/sluzbeni/full/2026_01_3_10.html); [MUPdigitalnomadproof-of-funds currentprincipalamountparagraph](https://mup.gov.hr/aliens-281621/286833).",
    "line": 98
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/hr-immigration2025.txt",
  "source_sha256": "ae619fccd0ec40a70f2bdcdc87c0fc4d8de02274ef1e25c1e138724e89286898",
  "source_version_basis": "Published7March2025; actualfinalArt96plus95neighborread; earlierembeddedarticle92readnotmisdescribedascommencement."
}
```

### HR-CURRENT-PUBLISHED-FUNDS

CurrentauthoritypublishedprincipalminimumEUR3622.50monthly;regulatoryformulaandfamilyadditionsseparatelycited;thisisnotaperfect-taxresidencecertificate.

```json
{
  "act_article_or_scope": "CurrentMUP actual413 and417;405/409 formula/family neighbours",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": [
    "The current principal monthly minimum is EUR3622.50, proved by a bank statement establishing regular income OR payslips covering the preceding6months.",
    "As an alternative for the proposed full stay, the published bank balance is EUR43470 for12months or EUR65205 for18months. These equal12/18 times the monthly figure.",
    "The legal2.5-times-prior-year-average rule and10%-of-average additions for each qualifying family member/partner remain in separate statute rows; the published principal is not the whole-family total."
  ],
  "correction_own_read_on": "2026-11-16",
  "id": "HR-CURRENT-PUBLISHED-FUNDS",
  "official_url": "https://mup.gov.hr/aliens-281621/286833",
  "quote_mode": "Permitted short claim-bound native extracts retained within total per-source quote cap; full original condition paraphrase and exact locators supplied. Does not claim full native-clause reproduction.",
  "section": {
    "actual_text": "Croatia's current permission can extend to 18 months, with shorter-stay extension and later-application conditions. The current published funds amount is EUR 3622.50 per month for the principal. The regulation uses 2.5 times the prior-year average monthly net salary, plus 10% of that average for each additional qualifying family member or partner; alternative period-total evidence is also published. The 2020 tax amendment introduced an exemption for specified digital-nomad receipts from work for a foreign employer/business. It did not create an arbitrary first-tax-year exemption for every receipt. The complete current tax-law overlay remains specifically reserved below; the immigration conditions above are separately recovered current authority rules. Sources: [ActNN40/2025Art12substitutingArt61(1)](https://narodne-novine.nn.hr/clanci/sluzbeni/2025_03_40_545.html); [RegNN14/2021 Art2(3)complete](https://narodne-novine.nn.hr/clanci/sluzbeni/2021_02_14_273.html); [RegNN3/2026 all3articles](https://narodne-novine.nn.hr/clanci/sluzbeni/full/2026_01_3_10.html); [MUPdigitalnomadproof-of-funds currentprincipalamountparagraph](https://mup.gov.hr/aliens-281621/286833).",
    "line": 98
  },
  "short_exact_native_quotes": [
    "minimum of 3.622,50 EUR"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/hr-nomad.txt",
  "source_sha256": "02ec7e2543821155b4f5a4eda1694118fa6aaae88e28fc34b1c125627e2c483c",
  "source_version_basis": "CurrentactualMUPpagewholeoperativepermission/funds/requirementsread, regulation14/21and3/26directlyread; shortliteralnumericfragment withinquotationlimit."
}
```

### PT-COMPANY-RESIDENCE

Corporate/entitiesseatOReffectivemanagementinPortugalcanestablishIRCresidence;coveredentities/foreignentitieswithoutseatmanagementhaveothercharged-incomeconditions. Singaporeincorporationalone doesnot resolvePortuguesecompanyresidence.

```json
{
  "act_article_or_scope": "CIRC2(1)–(3), wholearticleand republicationnote",
  "actual_read_on": "2026-11-16",
  "id": "PT-COMPANY-RESIDENCE",
  "official_url": "https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/CIRC_2R/Pages/irc2.aspx",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "A Singapore-incorporated company actually managed from Portugal needs a Portuguese domestic seat/effective-management analysis as well as any Singapore rules and applicable treaty. Minutes and an incorporation address cannot replace the facts about who makes strategic decisions. A home office or co-working place needs the relevant domestic and treaty fixed-place/agency tests; service-PE provisions exist only where actually applicable. There is no worldwide 90–183 day PE safe harbour. If the actual law and treaty establish a PE, compute the relevant charge and attributable profits under those provisions; do not tax all company receipts simply because a workspace exists. Keep day and decision records, but withholding local signatures or recording overseas board meetings does not cure contrary facts. Sources: [CIRC2(1)–(3)](https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/CIRC_2R/Pages/irc2.aspx); [Current authority guidance](https://www.belastingdienst.nl/wps/wcm/connect/bldcontentnl/belastingdienst/zakelijk/internationaal/vermogen/common_reporting_standard/regels).",
    "line": 120
  },
  "short_exact_native_quotes": [
    "Artigo 2.º Sujeitos passivos 1 — São sujeitos passivos do IRC: a) As sociedades comerciais ou civis sob forma comercial, as cooperativas, as empresas públicas"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/pt-company-circ2.txt",
  "source_sha256": "afe65c4b488d75d9a61a49238227138c80f4350fbf75ce8b63c26a9959890815",
  "source_version_basis": "Actual authority-hosted currentarticle, owncompletearticle550–562read16November2026 withheading/republicationnote; Articleunchangedby2014republicationnotclaimednew2026enactment."
}
```

### MY-RESIDENT-TARIFF

Generalstatutorychargeable-incometable0%through30%,withspecifiedexceptionparagraphs;nonresidentperson30%separateparagraph;notflat30%onallresidentgrossreceipts.

```json
{
  "act_article_or_scope": "ITA1967Schedule1PartIparagraph1and1Aneighbor, printed572–573",
  "actual_read_on": "2026-11-16",
  "id": "MY-RESIDENT-TARIFF",
  "official_url": "https://www.hasil.gov.my/wp-content/uploads/Income-Tax-Act-1967-online-version-as-at-1-January-2026.pdf",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "| Malaysia | The authority-hosted 2026 Act general resident tariff runs from 0% to 30%, under its actual chargeable-income bands and exception categories. The actual foreign-income exemption source has conditions for resident individuals, excludes partnership income received in Malaysia, and addresses subject-to-foreign-tax exceptions and records. Its 2024 extension commencing 1 January 2027 must not be described as a new 2026 exemption. MM2H is a category-dependent long-term social visit programme; MM2H permits general employment/business activity only in the Platinum category under the current FAQ; other categories need the relevant separate pass. Sources: [ITA1967Schedule1PartIparagraph1and1Aneighbor](https://www.hasil.gov.my/wp-content/uploads/Income-Tax-Act-1967-online-version-as-at-1-January-2026.pdf); [20June2024DGguideline5.2.2.1–2 allactualtax/deemed-taxconditions;5.2.4recordkeeping;PDFpp27–32](https://www.hasil.gov.my/wp-content/uploads/20240620-guidelines-tax-treatment-in-relation-to-income-received-from-abroad-amendment-june-2024.pdf); [PU(A)451/2024 native paragraphs1–2](https://lom.agc.gov.my/ilims/upload/portal/akta/outputp/2584396/PUA%20451_2024.pdf); [MM2H Topic2](https://www.motac.gov.my/en/frequently-asked-questions-faqs/). |",
    "line": 89
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/my-ita2026-operative-web.txt",
  "source_sha256": "fbd7f2e2e86dc56730bfb6fb13b81f4f94c884b425541e06f43a0ae8b3172ee8",
  "source_version_basis": "Actual official onlineupdatedActasat1January2026expressnotauthenticreprint; nativelegislationEnglishbodywholeindivtable/exceptionopeningactuallyread,notall853pages."
}
```

### TH-ORDINARY-PIT-TARIFF

Publishednetschedule0%exemptionto150000and5/10/15/20/25/30/35progression;35%above5million, not4million. Notesidentifyunderlying470/2551and44/2560effect;otherbase/deductions/calculationmethodsseparate.

```json
{
  "act_article_or_scope": "CurrentRDnative2017-onwardtableandbothstatutoryexemption/effectnotes",
  "actual_read_on": "2026-11-16",
  "id": "TH-ORDINARY-PIT-TARIFF",
  "official_url": "https://www.rd.go.th/59670.html",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "| Thailand | Local-source work/business can be taxable irrespective of payment abroad. The current published ordinary PIT schedule runs from 0% to 35%, with 35% above THB 5 million, subject to the actual base, exemptions and other calculation methods. For qualifying residents, P161/P162 cover foreign-source income arising from 1 January 2024 and later remitted, including later-year remittance; pre 2024 income is treated separately. LTR 17% concerns qualifying Highly-Skilled Professional employment. Decree 743 Art 5 separately names 3 other LTR categories and specified foreign income from prior tax years; an unconditional same-year foreign-income exemption is not established by that wording. Sources: [RevenueCode41 all3paragraphs and linked directive notes](https://www.rd.go.th/5937.html); [CurrentRDnative2017-onwardtableandbothstatutoryexemption/effectnotes](https://www.rd.go.th/59670.html); [OrderP161/2566 paragraph1](https://www.rd.go.th/fileadmin/user_upload/kormor/newlaw/dn161A.pdf); [OrderP162/2566 sole operative amendment](https://www.rd.go.th/fileadmin/user_upload/kormor/newlaw/dn162A.pdf); [Royal Decree743/2565 Art5; printed31/PDF3](https://ltr.boi.go.th/documents/Royal%20Decree%20issued%20under%20the%20Revenue%20Code%20No.743%20(TH).pdf). |",
    "line": 90
  },
  "short_exact_native_quotes": [
    "ขั้นเงินได้สุทธิตั้งแต่เงินได้สุทธิจำนวนสูงสุดของขั้นอัตราภาษี ภาษีสูงสุดในแต่ละขั้นเงินได้ภาษีสะสมสูงสุดของขั้น 0 - 150,000 150,000 5 ยกเว้น* 0 เกิน 150,000 -"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/th-rate-native.txt",
  "source_sha256": "f69c7ed2984ffff9ad80842e1d2b846b1c777e03c064dea8496e2fc7862d0426",
  "source_version_basis": "Actual nativeauthoritytableandnotesread266–282;published2017onward,updated9January2021,notmislabelled2026consolidatedstatutorytariff."
}
```

### TH-LTR-PERMISSION-DURATION

Initial5yearpermissioncanextend5moreyearsoncontinuingqualifications;notunconditional10yearvisa.

```json
{
  "act_article_or_scope": "BOILTRprivileges:10asteriskdurationqualificationclause",
  "actual_read_on": "2026-11-16",
  "id": "TH-LTR-PERMISSION-DURATION",
  "official_url": "https://ltr.boi.go.th/",
  "quote_mode": "Precise short literal native fragments from assigned operative scope; parts are distinct, with no invented ellipsis or generic inherited anchor.",
  "section": {
    "actual_text": "Thailand's LTR is an initial 5 years and conditional further 5 years. Decree 743 Arts 3–4 apply the 17% rate to qualifying Highly-Skilled Professional employment with the specified eligible employers; the alternative normal withholding, consent, no-refund/no-credit and return conditions matter. Notification 427 additionally requires the qualifying employer's notice and applies relief to income from the notice-receipt date, with timely PND95 filing and loss of relief for a noncompliant year. Art 5's exemption for the other 3 named LTR categories is a separate foreign-income rule expressly referring to prior tax years. “All LTR holders pay 17%” is incorrect. [Native Decree 743](https://ltr.boi.go.th/documents/Royal%20Decree%20issued%20under%20the%20Revenue%20Code%20No.743%20(TH).pdf); [implementing Notification 427](https://ltr.boi.go.th/documents/Notification%20of%20Income%20Tax%20No.%20427%20(TH).pdf). Do not execute a same-year foreign-income exemption without resolving that provision's exact application.",
    "line": 106
  },
  "short_exact_native_quotes": [
    "first time for five years which can be extended for 5 more years if qualifications are met."
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/res-thai-ltr.txt",
  "source_sha256": "4efc2dfd05c32ff718f1723702fcf6cbb1a5f28ceae5b9160238cbf99b20b01c",
  "source_version_basis": "Actual officialBOIretained14November2026bodyreadpersonally16November;nativeRD743andnotification427taxtreatmentseparate, noinferencefrommarketingforeignexemptionphrase."
}
```

### TREATY-INDIVIDUAL-SEQUENCE

Publishedconventionalsequenceisillustrative: actualDTAeligibleperson/residencearticlerequired;homeavailabilitynotownership;centrelinks/habitualfrequencydurationregularity;dual/neithernationalityrequiresactualtreatycompetent-authorityroute.

```json
{
  "act_article_or_scope": "HS3022026 Residence tie-breaker rules, allhome/centre/habitual/nationality paragraphs",
  "actual_read_on": "2026-11-16",
  "id": "TREATY-INDIVIDUAL-SEQUENCE",
  "official_url": "https://www.gov.uk/government/publications/dual-residents-hs302-self-assessment-helpsheet/dual-residents-2026-hs302",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "Establish a genuine intended residence with contemporaneous records; deliberately choosing one country does not make every other country relinquish its claim. Apply the actual bilateral residence article only after both domestic tests and treaty eligibility are established. The conventional individual sequence is permanent home, centre of vital interests where homes are available in both states, habitual abode if necessary, nationality, and finally competent-authority agreement for dual/neither nationality. A rented-out home is tested on actual availability, not the mere existence of any tenancy. Preserve leases, utility use, border records, bank/business evidence, family/school evidence and TRCs for the particular limbs they prove. No universal 24–36 month MAP resolution guarantee is supplied. Sources: [HS3022026 Residence tie-breaker rules](https://www.gov.uk/government/publications/dual-residents-hs302-self-assessment-helpsheet/dual-residents-2026-hs302).",
    "line": 147
  },
  "short_exact_native_quotes": [
    "Residence tie-breaker rules To find out which of the 2 countries you’re a resident in, for the purpose of claiming relief, you need to check"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/cb-residence.txt",
  "source_sha256": "9e0339b5c5103ad20fe0f4b1cbb93f65b8066703b64c58bc3fa1588cb070e6c0",
  "source_version_basis": "Actual2026HMRChelpsheetwhole170linereturnedbodypersonallyread;OGLsource; notallbilateraltreatiesorcompanytie-breakersread;IRSSPTinsteadofhelpsheetroundedexampleused."
}
```

### TREATY-RESIDENCE-EVIDENCE

Certificatecoversactualdomesticresidenceforrelevantperiod andspecificUKreliefclaimprocedure;notuniversalproofallformercountrytaxingrightscease.

```json
{
  "act_article_or_scope": "HS3022026 Certificate of overseas residence paragraph",
  "actual_read_on": "2026-11-16",
  "id": "TREATY-RESIDENCE-EVIDENCE",
  "official_url": "https://www.gov.uk/government/publications/dual-residents-hs302-self-assessment-helpsheet/dual-residents-2026-hs302",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "Establish a genuine intended residence with contemporaneous records; deliberately choosing one country does not make every other country relinquish its claim. Apply the actual bilateral residence article only after both domestic tests and treaty eligibility are established. The conventional individual sequence is permanent home, centre of vital interests where homes are available in both states, habitual abode if necessary, nationality, and finally competent-authority agreement for dual/neither nationality. A rented-out home is tested on actual availability, not the mere existence of any tenancy. Preserve leases, utility use, border records, bank/business evidence, family/school evidence and TRCs for the particular limbs they prove. No universal 24–36 month MAP resolution guarantee is supplied. Sources: [HS3022026 Residence tie-breaker rules](https://www.gov.uk/government/publications/dual-residents-hs302-self-assessment-helpsheet/dual-residents-2026-hs302).",
    "line": 147
  },
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/cb-residence.txt",
  "source_sha256": "9e0339b5c5103ad20fe0f4b1cbb93f65b8066703b64c58bc3fa1588cb070e6c0",
  "source_version_basis": "Actual2026HMRChelpsheetoperativeandneighborsread;OGLsource;UScitizenship/specificclaimexception followsandwasread, notuniversalcertificatecompulsioninGuide."
}
```

### PE-COMMENTARY-2025-CONDITIONAL

Commentarybelow50%worktimeobservationusesany12monthperiodbeginning/endingfiscalyearandactualconduct;atleast50%needsfactsandcircumstances/commercialreason, notautomaticPE. Commentarynotbilateraltreatylaw.

```json
{
  "act_article_or_scope": "OECD2025UpdateArt5Commentary44.8–44.16, printed15–16; actual retained584–651, neighbours44.4–44.17",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": [
    "44.8: For a person using a home or another relevant place for enterprise activities, use below50% of that person’s total working time for that enterprise over any12months beginning or ending in the fiscal year generally does not make it an enterprise place of business; exceptional cases are acknowledged, though not expected in most such arrangements.",
    "44.9: Actual conduct controls time measurement; contract terms and enterprise policies assist only where consistent with conduct.",
    "44.10: At or above50%, the result depends on all facts and circumstances; the threshold does not itself establish a PE.",
    "44.11–12: A relevant commercial reason exists where physical presence in that state facilitates the enterprise’s business, for example access to needed people/resources, alternative local premises, or direct business engagement facilitated by that location.",
    "44.13: Productive character is not the criterion; where several reasons exist, one genuine commercial reason can satisfy that indicator.",
    "44.14: Intermittent/incidental or minor customer engagement is insufficient on its own; assess the individual activity against the enterprise’s overall business.",
    "44.15: The person’s presence must be connected to carrying on the business; allowing the location solely to recruit/retain that person is insufficient.",
    "44.16: A location permitted solely to reduce costs, such as office expenditure, is not itself a commercial reason to perform the business there.",
    "This is Commentary analysis, not operative bilateral treaty text, and does not settle fixed-place, permanence, disposal, agency or other actual legal requirements."
  ],
  "correction_own_read_on": "2026-11-16",
  "id": "PE-COMMENTARY-2025-CONDITIONAL",
  "official_url": "https://www.oecd.org/content/dam/oecd/en/publications/reports/2025/11/the-2025-update-to-the-oecd-model-tax-convention_c7031e1b/5798080f-en.pdf",
  "quote_mode": "Permitted short claim-bound native extracts retained within total per-source quote cap; full original condition paraphrase and exact locators supplied. Does not claim full native-clause reproduction.",
  "section": {
    "actual_text": "The 2025 OECD Commentary's remote-work discussion is commentary, not a replacement for a bilateral treaty. Its below 50% working-time observation and commercial-reason analysis are conditional; at least 50% is not an automatic PE. Apply its analysis only where the actual bilateral treaty and domestic law make it relevant. Sources: [2025UpdateArt5Commentary44.8–44.16; actual44.4–44.17andneighborsread](https://www.oecd.org/content/dam/oecd/en/publications/reports/2025/11/the-2025-update-to-the-oecd-model-tax-convention_c7031e1b/5798080f-en.pdf).",
    "line": 122
  },
  "short_exact_native_quotes": [
    "less than 50 per cent"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/cb-oecd-update.txt",
  "source_sha256": "7f04f215513ee8bab3acf0cacf9b36e6855cf531108221aed11f5f4a5d0a1067",
  "source_version_basis": "Actual retained2025officialPDFscopepersonallyreread16November2026; only23quotedwordsacrossentiresource, sourcecopyrightboundaryexplicit. Fullconditionspreciselyparaphrasedratherthanfalselyclaimedfullyquoted."
}
```

### MY-FSI-AUTHORITY-CONDITIONAL

Datedauthorityguidelineexcludespartnershipincomefromresidentindividualforeign-incomeexemptionandrequiresforeignsubject-to-taxwithspecifieddeemed-taxexceptions;records/returndeclarationremainnecessary. OriginalPU234notpersonallyrecovered;2027extension separatelyactuallegalread. Notblanketforeign-client0%.

```json
{
  "act_article_or_scope": "DG20June2024guideline5.2.2.1–2, printed25–26;5.2.4 printed29–30; retained extraction66–223, complete table columns separately read",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": [
    "5.2.2.1: The dated exemption concerns foreign income received in Malaysia by a resident individual during1January2022–31December2026, excluding partnership income, with the required foreign-tax condition.",
    "5.2.2.2(a): Foreign income tax or withholding tax paid or payable can satisfy the tax condition.",
    "5.2.2.2(b), nondividend column: absence of foreign tax is accepted under the specified foreign tax system, an individual income amount below the foreign taxability level, or a tax-incentive exemption.",
    "Dividend column(i): foreign dividends may satisfy the condition through underlying tax.",
    "Dividend column(ii): dividends from underlying operating profits may meet the condition where no underlying tax results from unabsorbed losses/capital allowances, capital gains, qualifying substantive tax incentives, or the foreign tax-consolidation regime.",
    "5.2.4.1: Keep dividend vouchers, assessments or other evidence underITA82/82A showing foreign taxation, as appropriate.",
    "5.2.4.2: The return declaration includes income type/amount, source country, applicable foreign tax amount, individual untaxed-income/underlying-tax facts and reasons, foreign exemption/incentive confirmation or approval, and any further prescribed information; the foreign headline-rate field is for the specified company/LLP/IIP categories, not automatically every individual.",
    "5.2.4.3: Retain supporting evidence for audit. The text’s printed cross-reference to5.2.5.1 is preserved as a source irregularity, not silently corrected into a new legal obligation.",
    "This actual dated guideline does not replace the unrecovered originalPU(A)234/2022; actualPU(A)451/2024 begins1January2027 and separately extends the date. No blanket foreign-client exemption or final2027 execution clearance is inferred."
  ],
  "correction_own_read_on": "2026-11-16",
  "id": "MY-FSI-AUTHORITY-CONDITIONAL",
  "official_url": "https://www.hasil.gov.my/wp-content/uploads/20240620-guidelines-tax-treatment-in-relation-to-income-received-from-abroad-amendment-june-2024.pdf",
  "quote_mode": "Permitted short claim-bound native extracts retained within total per-source quote cap; full original condition paraphrase and exact locators supplied. Does not claim full native-clause reproduction.",
  "section": {
    "actual_text": "| Malaysia | The authority-hosted 2026 Act general resident tariff runs from 0% to 30%, under its actual chargeable-income bands and exception categories. The actual foreign-income exemption source has conditions for resident individuals, excludes partnership income received in Malaysia, and addresses subject-to-foreign-tax exceptions and records. Its 2024 extension commencing 1 January 2027 must not be described as a new 2026 exemption. MM2H is a category-dependent long-term social visit programme; MM2H permits general employment/business activity only in the Platinum category under the current FAQ; other categories need the relevant separate pass. Sources: [ITA1967Schedule1PartIparagraph1and1Aneighbor](https://www.hasil.gov.my/wp-content/uploads/Income-Tax-Act-1967-online-version-as-at-1-January-2026.pdf); [20June2024DGguideline5.2.2.1–2 allactualtax/deemed-taxconditions;5.2.4recordkeeping;PDFpp27–32](https://www.hasil.gov.my/wp-content/uploads/20240620-guidelines-tax-treatment-in-relation-to-income-received-from-abroad-amendment-june-2024.pdf); [PU(A)451/2024 native paragraphs1–2](https://lom.agc.gov.my/ilims/upload/portal/akta/outputp/2584396/PUA%20451_2024.pdf); [MM2H Topic2](https://www.motac.gov.my/en/frequently-asked-questions-faqs/). |",
    "line": 89
  },
  "short_exact_native_quotes": [
    "All foreign income other than partnership income"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/my-fsi-guideline-web.txt",
  "source_sha256": "3cf176316f7f3753eee1c93fd6232d6bf21782f57580c07031326f88f468ad51",
  "source_version_basis": "Actual official2024guideline web-PDF extraction personally read printed25–30, operative5.2.2.1–2 and5.2.4 with complete table-column order and examples/neighbours. Retained extraction66–223. Not whole-instrument/current2027 execution clearance; source printed39-page numbering and source cross-reference irregularity retained honestly."
}
```

### US-NONRESIDENT-ECI

NonresidentforeignownerneedsactualUSTB/ECIanalysis;USsourceconnectionwithstatutory/election/asset-use/businessactivity/limitedforeignsourceandyear-timingexceptions; foreignownershipor100000revenueisnotgeneralexemption.

```json
{
  "act_article_or_scope": "IRS ECIwholeoperativegeneralrule/allconnectedcategories/exceptions/timing",
  "actual_read_on": "2026-11-16",
  "id": "US-NONRESIDENT-ECI",
  "official_url": "https://www.irs.gov/individuals/international-taxpayers/effectively-connected-income-eci",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "**B: non-US digital nomad below USD 100000 revenue.** That revenue level creates no general US-LLC exemption or residence safe harbour. Test US presence, US trade/business/ECI and separate source income, local residence/source and LLC information returns. The old near-zero tax and approximately USD 1500 all-in annual-cost promises remain individually unsupported. Sources: [IRS ECIwholeoperativegeneralrule/allconnectedcategories/exceptions/timing](https://www.irs.gov/individuals/international-taxpayers/effectively-connected-income-eci); [IRS FDAPdefinitionandexclusions/nonECIscope operativeopening](https://www.irs.gov/individuals/international-taxpayers/fixed-determinable-annual-periodical-fdap-income); [Who Must File and all6exceptions plusDEexceptionnote](https://www.irs.gov/instructions/i5472).",
    "line": 153
  },
  "short_exact_native_quotes": [
    "Generally, when a foreign person is engaged in a trade or business in the United States (USTB), all United States (U.S.) source income connected with"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/us-eci-current.txt",
  "source_sha256": "0e39c6fd8f5556ede9192815b05957035bea9f42e292e4770331ebd106b936df",
  "source_version_basis": "Own full actual retained compactbodyread16November2026; freshownordinaryHTTP200retrievalthen normalizedbodyexactmatchedthatpersonallyreadbody; actualIRSupdate18August2026."
}
```

### US-NONRESIDENT-FDAP

SeparateUSsourceFDAPandECIclassification/scoperemainnecessary; nonECIgrossmethodandtreatyconditionscannotbeignoredbyusingdomesticLLC.

```json
{
  "act_article_or_scope": "IRS FDAPdefinitionandexclusions/nonECIscope operativeopening",
  "actual_read_on": "2026-11-16",
  "id": "US-NONRESIDENT-FDAP",
  "official_url": "https://www.irs.gov/individuals/international-taxpayers/fixed-determinable-annual-periodical-fdap-income",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "**B: non-US digital nomad below USD 100000 revenue.** That revenue level creates no general US-LLC exemption or residence safe harbour. Test US presence, US trade/business/ECI and separate source income, local residence/source and LLC information returns. The old near-zero tax and approximately USD 1500 all-in annual-cost promises remain individually unsupported. Sources: [IRS ECIwholeoperativegeneralrule/allconnectedcategories/exceptions/timing](https://www.irs.gov/individuals/international-taxpayers/effectively-connected-income-eci); [IRS FDAPdefinitionandexclusions/nonECIscope operativeopening](https://www.irs.gov/individuals/international-taxpayers/fixed-determinable-annual-periodical-fdap-income); [Who Must File and all6exceptions plusDEexceptionnote](https://www.irs.gov/instructions/i5472).",
    "line": 153
  },
  "short_exact_native_quotes": [
    "Fixed, determinable, annual, or periodical (FDAP) income is all income except: Gains derived from the sale of real or personal property (including market discount and"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/us-fdap-current.txt",
  "source_sha256": "e25e3b51f2f5c428a458fff43d838f4dccae862ab155feee253be0ba5af17d85",
  "source_version_basis": "OwnfullactualcompactFDAPbodyreadincludingCG183testdistinction,FIRPTAandotherexceptions;freshownHTTP200normalizedbodyidentical; actualIRSupdate23July2026."
}
```

### US-SE-NET-EARNINGS-SCOPE

SelfemploymentusesactualnetearningsandScheduleSE/workerclassification, notgrossLLCrevenueorblanketnationalityassumption;FEIEdoesnotwaiveapplicablesocialtax/totalizationanalysis.

```json
{
  "act_article_or_scope": "IRS Who must pay SE tax? completeoperativefirstconditions/notes",
  "actual_read_on": "2026-11-16",
  "id": "US-SE-NET-EARNINGS-SCOPE",
  "official_url": "https://www.irs.gov/businesses/small-businesses-self-employed/self-employment-tax-social-security-and-medicare-taxes",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "**A: US-citizen digital nomad.** Test owner/entity classification, work source, foreign tax home and either FEIE residence/presence test, eligible FTC and social-insurance duties. Wyoming/Delaware LLC is a possible legal form, not a guaranteed solution. Mercury/Wise are original commercial examples, not verified bank recommendations. Sources: [Opening complete LLC classification paragraph](https://www.irs.gov/businesses/small-businesses-self-employed/single-member-limited-liability-companies); [Opening service source and treaty-exception paragraphs](https://www.irs.gov/individuals/international-taxpayers/source-of-income-personal-service-income); [Who Qualifies and whole taxhome/abode discussion](https://www.irs.gov/instructions/i2555).",
    "line": 151
  },
  "short_exact_native_quotes": [
    "You must pay self-employment tax and file Schedule SE (Form 1040) if either of the following applies. Your net earnings from self-employment (excluding church employee"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/us-se-current.txt",
  "source_sha256": "2b87a4b5cf9d5c76c7ca2ead8a837ddfa121fb5902e5b1348528fd74558d01fd",
  "source_version_basis": "Ownwholecompactsourcebodyread;freshownHTTP200bodyexactmatchedpersonallyreadtext;actualIRSupdated30October2026;notallinternationalsocialtreatiesorworkerexceptionsread."
}
```

### HR-NOMAD-HISTORICAL-TAX

Historicalamendmentintroducedspecificnomadstatusreceiptsforforeignemployer/business;notfirstyear0%onallreceipts. Current2026taxoverlayexplicitlyreserved.

```json
{
  "act_article_or_scope": "ActNN138/2020Art2insertingIncomeTaxArt9(1)26",
  "actual_read_on": "2026-11-16",
  "id": "HR-NOMAD-HISTORICAL-TAX",
  "official_url": "https://narodne-novine.nn.hr/clanci/sluzbeni/full/2020_12_138_2625.html",
  "quote_mode": "Contiguous literal native source fragments, <=25 whitespace words each; entire assigned clause retained losslessly under whitespace normalization; no generic per-source inheritance.",
  "section": {
    "actual_text": "Croatia's current permission can extend to 18 months, with shorter-stay extension and later-application conditions. The current published funds amount is EUR 3622.50 per month for the principal. The regulation uses 2.5 times the prior-year average monthly net salary, plus 10% of that average for each additional qualifying family member or partner; alternative period-total evidence is also published. The 2020 tax amendment introduced an exemption for specified digital-nomad receipts from work for a foreign employer/business. It did not create an arbitrary first-tax-year exemption for every receipt. The complete current tax-law overlay remains specifically reserved below; the immigration conditions above are separately recovered current authority rules. Sources: [ActNN40/2025Art12substitutingArt61(1)](https://narodne-novine.nn.hr/clanci/sluzbeni/2025_03_40_545.html); [RegNN14/2021 Art2(3)complete](https://narodne-novine.nn.hr/clanci/sluzbeni/2021_02_14_273.html); [RegNN3/2026 all3articles](https://narodne-novine.nn.hr/clanci/sluzbeni/full/2026_01_3_10.html); [MUPdigitalnomadproof-of-funds currentprincipalamountparagraph](https://mup.gov.hr/aliens-281621/286833).",
    "line": 98
  },
  "short_exact_native_quotes": [
    "Članak 2. U članku 9. stavku 1. točki 6. riječ: »redovitom« briše se. U točki 23. riječi: »i/ili« brišu se. U točki 24. na kraju"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/hr-tax2020.txt",
  "source_sha256": "e7ef9f95dfd8d5aa571dd950064b1e23e07cfbe2a8e739543c56e79287fc421d",
  "source_version_basis": "Actual2020amendmentpersonallyreadwithneighbours16November2026;2024amendingActall19articlesalsoownread,notfullintervening2022/23/currentconsolidation."
}
```

### CR-SOURCE-ACTIVITY-DATED

Dated2025authoritypresentation explains domestic profitable-activity scope irrespective of nationality,residence,capital origin and contract-negotiation connections; not current full Code clearance.

```json
{
  "act_article_or_scope": "Presentation27February2025for2024closure, actualPDFpp2–4 full own read; each scope/connection bullet, Art1/2 attributions",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": [
    "The2025presentation for the2024closure describes profit from CostaRican-source lucrative activity: goods,services and rights,plus other income not excepted by law.",
    "Its scope includes natural/legal persons and collective entities performing domestic economic activity,foreign or national. Income inclusion does not depend on nationality,participants’ domicile/residence,origin of goods/capital,or negotiation location/economic-structure connection.",
    "These are dated authority explanations attributed to LISR1/2. The complete current statutory consolidation has not been recovered; this is not a guarantee that foreign-client work is exempt."
  ],
  "id": "CR-SOURCE-ACTIVITY-DATED",
  "official_url": "https://www.hacienda.go.cr/docs/CHARLAISU-2024-27-02-2025.pdf",
  "quote_mode": "Permitted short exact extracts plus complete condition paraphrase/precise own-read scope; no full native-clause reproduction claimed.",
  "section": {
    "actual_text": "| Costa Rica | The authority’s 2025 presentation for the 2024 closure describes domestic profitable-activity scope irrespective of nationality and the listed contractual connections; it is dated guidance, not the recovered full current Code. [Actual scope presentation pp2–4](https://www.hacienda.go.cr/docs/CHARLAISU-2024-27-02-2025.pdf). The official 2026 self-employed annual bands are zero through CRC 6244000,10% on the excess through 8329000,15% through 10414000,20% through 20872000 and 25% above. Employment has different monthly bands. Rentista permission does not itself classify work income. Sources: [2026ratechart](https://www.hacienda.go.cr/docs/TramosRenta2026.pdf). |",
    "line": 86
  },
  "short_exact_native_quotes": [
    "actividades lucrativas"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/cr-source-seminar.txt",
  "source_sha256": "f19d9d74f9f3c9192bb597777ef2d50c5807c71200b82f3ba7b1840a098be594",
  "source_version_basis": "Actual official25page presentation personally read earlier16November; pp2–4 reread textually now and sourcePDF retained; dated2025/2024 scope made explicit."
}
```

### US-DUAL-STATUS-BOUNDED

Alien dual-status may follow residence changes within a year; first-year and spousal choices and treaty residence can change the result,without citizenship change.

```json
{
  "act_article_or_scope": "ActualIRS introductory dual-status definition,first-year choice,treaty and spousal-election paragraphs, web97–108, retained1411–1432; neighbours through155 also own read",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": [
    "BothUSresident and nonresident status can occur within the same taxyear; this concerns tax residence rather than citizenship.",
    "A next-yearSPTresident may make the prior-year first-year choice only if its separate tests are met. Treaty residence may differ from Code residence.",
    "A dual-status individual married to a UScitizen/resident may elect joint resident treatment; this source establishes the existence of the choice,not full filing eligibility/instructions."
  ],
  "id": "US-DUAL-STATUS-BOUNDED",
  "official_url": "https://www.irs.gov/individuals/international-taxpayers/taxation-of-dual-status-individuals",
  "quote_mode": "Complete assigned actualUSGovernment paragraph, losslessly split into short contiguous literal extracts; public-domain source.",
  "section": {
    "actual_text": "US citizenship does not turn off on moving. Alien dual-status treatment can arise from residence changes under its own rules, beyond just green-card holders; elections and treaty treatment can alter the outcome. [Actual IRS dual-status scope and choices](https://www.irs.gov/individuals/international-taxpayers/taxation-of-dual-status-individuals). Singapore's annual residence and concessions are separate from fractional tax-year treatment. UAE business corporate-tax and certificate periods remain relevant despite no general PIT. Panama, Georgia and Paraguay still require local source/category and residence-period analysis.",
    "line": 143
  },
  "short_exact_native_quotes": [
    "You are a dual-status individual when you have been both a U.S. resident and a nonresident in the same tax year. Dual status does not"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/us-dualstatus.txt",
  "source_sha256": "31af506afc306ba1424b8701dd1c24d348a1f97f79c06e5aad913660919a0bb2",
  "source_version_basis": "Actual currentIRS public body personally read through155 on16November; ordinary actual retained source own read plus freshweb body; no blanket election entitlement."
}
```

### EE-NOMAD-DURATION-BOUNDED

Original1year digital-nomad duration corrected to conditional D-visa maximum365days within12consecutive months,with consecutive-visa limit.

```json
{
  "act_article_or_scope": "ActualMFA currentweb225–236:231duration,232consecutivevisas;249–280documentation/funds neighbours read",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": [
    "The general D-visa maximum is365days within12consecutive months; it is conditional permission,not an automatic1year award.",
    "Two consecutive long-stay visas must together remain within548days in730consecutive days. The official DNVFAQ separately identifies DNV as D or Cvisa; apply the actual granted category.",
    "Current documentation/financial-eligibility questions remain separate,including the existing conflict reservation; duration alone grants no tax exemption."
  ],
  "id": "EE-NOMAD-DURATION-BOUNDED",
  "official_url": "https://www.vm.ee/en/consular-visa-and-travel-information/visa-information/application-long-stay-d-visa",
  "quote_mode": "Permitted short exact extracts plus complete condition paraphrase/precise own-read scope; no full native-clause reproduction claimed.",
  "section": {
    "actual_text": "Estonia’s digital-nomad D-visa is conditional permission for up to 365 days within 12 consecutive months; 2 consecutive long-stay visas are limited to 548 days in 730 consecutive days. This corrects the old unconditional-looking ‘1 year’ duration without granting a tax exemption. [Current MFA duration and consecutive-visa limits](https://www.vm.ee/en/consular-visa-and-travel-information/visa-information/application-long-stay-d-visa). Estonia's domestic residence can arise from a place of residence or at least 183 days over 12 consecutive calendar months. An immigration stay shorter than 183 days does not rule out the home limb. The currently recovered official visa-income pages disagree about gross/net measures and the general D-visa subsistence figure; the original EUR 4500 rule must remain specifically reserved until reconciled with the current operative visa instrument. Sources: [EMTA native Residentsusemääramine:Residendi mõiste and actual home/daycount neighbors](https://www.emta.ee/eraklient/valismaalasele-mitteresidendile/maksuresidentsus/residentsuse-maaramine).",
    "line": 100
  },
  "short_exact_native_quotes": [
    "up to 365 days within twelve consecutive months"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/ee-mfa-dvisa-current-own-web.txt",
  "source_sha256": "ee4db6e0c6f725565d2521bc3ae12c7fc9963b6728cfc80c84e7b124baeffb12",
  "source_version_basis": "Fresh actualMFAweb body personally read16November; ordinaryCLI403 honestly retained. OfficialDNVFAQ124–146 own read confirms D/Ccategory link,not vendor/snippet evidence."
}
```

### AE-CORPORATE-TAX-375000-BOUNDARY

Original>AED375000 corporate-rate threshold preserved separately from natural-personAED1mturnover; publishedCD116 standard bands and anti-fragmentation conditions,with unofficial-English/native-source boundary.

```json
{
  "act_article_or_scope": "CD116/2022Arts2–3 whole plus1/4/5 neighbours, all3actualPDFpages personally read16November",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": [
    "The published decision’s ordinaryCTbands are0% on the portion of taxable income not aboveAED375000 and9% on the excess in the taxperiod. This threshold applies to a taxable person’s combined businesses,not once per activity.",
    "Artificial separation to duplicate the0% threshold is treated under the general anti-abuse provision; authority assesses commercial purpose and financial,economic,regulatory ties and all facts.",
    "This taxable-income threshold is different from the natural-person business turnover threshold ofAED1m and from free-zone qualifying-income rules.",
    "ActualFTA-hosted text is expressly an unofficial English translation; nativeArabic116 not yet personally recovered after ordinary public recovery attempts. This does not establish full original-language compliance or complete current company-tax execution."
  ],
  "id": "AE-CORPORATE-TAX-375000-BOUNDARY",
  "official_url": "https://tax.gov.ae/Datafolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%20No.%20116%20of%202022%20-%20for%20publishing.pdf",
  "quote_mode": "Permitted short exact extracts plus complete condition paraphrase/precise own-read scope; no full native-clause reproduction claimed.",
  "section": {
    "actual_text": "The UAE does not levy the original purported 5% personal income tax from January 2026. Natural-person business activity has a separate corporate-tax scope where calendar-year business turnover exceeds AED 1 million; wages, Personal Investment Income and Real Estate Investment Income are excluded under the published conditions. This is not a tax on every individual's receipts. Free-zone incorporation and its separate qualifying-person/income rules cannot be replaced by a universal 9% + 5% calculation. The old >AED375000 condition concerns a separate taxable-income threshold: the FTA-hosted CD116/2022 text sets ordinary 0% treatment on the portion up to AED375000 and 9% on the excess, once per taxable person’s combined businesses, with anti-fragmentation conditions. It is expressly an unofficial English translation; native Arabic116 and complete current company-tax execution are not cleared here. [Actual decision Arts2–3](https://tax.gov.ae/Datafolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%20No.%20116%20of%202022%20-%20for%20publishing.pdf). [Government FAQ](https://u.ae/en/Help/FAQs/finance-and-investment); [FTA natural persons](https://www.tax.gov.ae/en/taxes/corporate.tax/corporate.tax.topics/basis.of.taxation.natural.person.aspx).",
    "line": 71
  },
  "short_exact_native_quotes": [
    "not exceeding (375,000)"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/ae-cd116-en-current.txt",
  "source_sha256": "5146761bcda9a4c2197c12cebcd0740c640cbf7ce9a5be58004b5198133b18a9",
  "source_version_basis": "Actual officialPDF all3pages/Arts1–5 personally read16November, including its explicit unofficial-translation label; source legal version/CD116date stated, no Arabic-read or professional-approval claim."
}
```

## Original-topic destinations

The complete original-topic destination table is in `../tax-residency-planning/old-topic-map.json`.
