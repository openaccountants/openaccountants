# non-eu-export-services figure and rule ledger

Public projection; canonical private SHA256: `a4997f46183f56579e342662e78b57ac35955a01671c665c26314b74ac5bb959`. Complete captured/native source passages remain local. The JSON companion preserves every retained evidence field.

## Whole rule groups

### 1

Determine the seller-side indirect-tax treatment of services supplied across borders by an EU, UK, Australian, Indian or Singaporean business.

```json
{
  "act_articles": {},
  "conditions_context": "Determine the seller-side indirect-tax treatment of services supplied across borders by an EU, UK, Australian, Indian or Singaporean business. A foreign customer or foreign consumption alone does not establish export relief. Establish the place of supply, any specific relief, who owes the tax, input-credit entitlement and the applicable reporting obligation separately. Goods exports, destination-country registration computations and permanent-establishment income tax are separate jobs.",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 1,
  "line": 19,
  "original_review_exact_claim": "Determine the seller-side indirect-tax treatment of services supplied across borders by an EU, UK, Australian, Indian or Singaporean business.",
  "original_review_row_id": 1,
  "quotation_gaps": [],
  "result_boundary": "Internal workflow/provenance/example-intake policy; not external law",
  "section": "",
  "source_keys": [
    "POLICY"
  ]
}
```

### 2

A foreign customer or foreign consumption alone does not establish export relief.

```json
{
  "act_articles": {
    "AU2A": "s38-190(1), item2(a)",
    "AU2ABS": "s38-190(1), item2 chapeau",
    "AU2ALAND": "s38-190(1), item2(a), land condition",
    "AU2AWHENDONE": "s38-190(1) item2(a), timing of local work",
    "AULOCAL": "s38-190(3)(b), local provision",
    "AULOCALA": "s38-190(3)(a), nonresident agreement",
    "AULOCALC": "s38-190(3)(c), input-taxed limitation on exceptions",
    "AULOCALX": "s38-190(3)(c)(i), business-recipient exception",
    "AULOCALX2": "s38-190(3)(c)(ii), employee/officer alternative",
    "AULOCALX3": "s38-190(3)(c)(iii), recipient creditable-purpose alternative",
    "AUPROP": "s38-190(2A), input-taxed property exclusion",
    "AUPROPALL": "s38-190(2A), item/application extent",
    "AUPROPITEMS": "s38-190(2A), items2-4",
    "AURIGHT": "s38-190(2), rights/options exclusion",
    "AUSCOPE": "s38-190(1), chapeau",
    "AUSCOPEEX": "s38-190(1), chapeau, exclusions",
    "EU44ACT": "Article44, first sentence, taxable business-capacity condition",
    "EU44B": "Article 44, first sentence",
    "EU44F": "Article 44, second sentence",
    "EU44R": "Article 44, third sentence",
    "IN2FE": "IGST2(14)(c), relevant establishment",
    "IN2I": "IGST2(6)(i)",
    "IN2II": "IGST2(6)(ii)",
    "IN2III": "IGST2(6)(iii)",
    "IN2IV": "IGST2(6)(iv), as amended2018",
    "IN2V": "IGST2(6)(v)",
    "IN8EX": "IGST8Explanation1(i)",
    "REG21": "Article 21, first/second paragraphs, relevant establishment",
    "REG22": "Article 22(1), identification of receiving establishment",
    "REG22C": "Article 22(1), secondary evidence",
    "SGABS": "IRAS table row13/(j), overseas customer absence and overseas direct beneficiary absence",
    "SGCONTRACT": "IRAS international-services table row13/(j) and row14/(k), identical overseas-contract limb",
    "SGGOODS": "IRAS table rows9/10/12:21(3)(g)/(h)/(f), goods/export evidence",
    "SGLAND": "Same table row13/(j), Singapore goods/land restriction",
    "SGLOCAL": "Same table rows13/(j) and14/(k), identical local-beneficiary alternative"
  },
  "conditions_context": "Determine the seller-side indirect-tax treatment of services supplied across borders by an EU, UK, Australian, Indian or Singaporean business. A foreign customer or foreign consumption alone does not establish export relief. Establish the place of supply, any specific relief, who owes the tax, input-credit entitlement and the applicable reporting obligation separately. Goods exports, destination-country registration computations and permanent-establishment income tax are separate jobs.",
  "evidence_entry_ids": [
    "EU44ACT",
    "EU44B",
    "EU44F",
    "EU44R",
    "REG21",
    "REG22",
    "REG22C",
    "AUSCOPE",
    "AUSCOPEEX",
    "AU2ABS",
    "AU2A",
    "AU2AWHENDONE",
    "AU2ALAND",
    "AURIGHT",
    "AUPROPALL",
    "AUPROPITEMS",
    "AUPROP",
    "AULOCALA",
    "AULOCAL",
    "AULOCALC",
    "AULOCALX",
    "AULOCALX2",
    "AULOCALX3",
    "IN2I",
    "IN2II",
    "IN2III",
    "IN2IV",
    "IN2V",
    "IN8EX",
    "IN2FE",
    "SGCONTRACT",
    "SGABS",
    "SGLOCAL",
    "SGLAND",
    "SGGOODS"
  ],
  "evidence_format_status": "CURRENT_SHORT_EXTRACT_STANDARD_APPLICABLE",
  "evidence_recommendation_note": "Country-specific conditional synthesis; no invented universal export relief.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "historical_format_status": "HOLD_EXPLICIT_EXTRACT_GAP",
  "historical_quotation_gaps": [
    "SGABS",
    "SGGOODS"
  ],
  "id": 2,
  "line": 19,
  "original_review_exact_claim": "A foreign customer or foreign consumption alone does not establish export relief.",
  "original_review_row_id": 2,
  "quotation_gaps": [],
  "result_boundary": "Internal workflow/provenance/example-intake policy; not external law",
  "section": "",
  "source_keys": [
    "EU",
    "REG",
    "AU",
    "IN",
    "SG"
  ]
}
```

### 3

Establish the place of supply, any specific relief, who owes the tax, input-credit entitlement and the applicable reporting obligation separately.

```json
{
  "act_articles": {},
  "conditions_context": "Determine the seller-side indirect-tax treatment of services supplied across borders by an EU, UK, Australian, Indian or Singaporean business. A foreign customer or foreign consumption alone does not establish export relief. Establish the place of supply, any specific relief, who owes the tax, input-credit entitlement and the applicable reporting obligation separately. Goods exports, destination-country registration computations and permanent-establishment income tax are separate jobs.",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 3,
  "line": 19,
  "original_review_exact_claim": "Establish the place of supply, any specific relief, who owes the tax, input-credit entitlement and the applicable reporting obligation separately.",
  "original_review_row_id": 3,
  "quotation_gaps": [],
  "result_boundary": "Internal workflow/provenance/example-intake policy; not external law",
  "section": "",
  "source_keys": [
    "POLICY"
  ]
}
```

### 4

Goods exports, destination-country registration computations and permanent-establishment income tax are separate jobs.

```json
{
  "act_articles": {},
  "conditions_context": "Determine the seller-side indirect-tax treatment of services supplied across borders by an EU, UK, Australian, Indian or Singaporean business. A foreign customer or foreign consumption alone does not establish export relief. Establish the place of supply, any specific relief, who owes the tax, input-credit entitlement and the applicable reporting obligation separately. Goods exports, destination-country registration computations and permanent-establishment income tax are separate jobs.",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 4,
  "line": 19,
  "original_review_exact_claim": "Goods exports, destination-country registration computations and permanent-establishment income tax are separate jobs.",
  "original_review_row_id": 4,
  "quotation_gaps": [],
  "result_boundary": "Internal workflow/provenance/example-intake policy; not external law",
  "section": "",
  "source_keys": [
    "POLICY"
  ]
}
```

### 5

| Jurisdiction | EU, UK, Australia, India, Singapore; other countries need their own law |

```json
{
  "act_articles": {},
  "conditions_context": "| Jurisdiction | EU, UK, Australia, India, Singapore; other countries need their own law |",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 5,
  "line": 23,
  "original_review_exact_claim": "| Jurisdiction | EU, UK, Australia, India, Singapore; other countries need their own law |",
  "original_review_row_id": 5,
  "quotation_gaps": [],
  "result_boundary": "Internal workflow/provenance/example-intake policy; not external law",
  "section": "",
  "source_keys": [
    "POLICY"
  ]
}
```

### 6

| Contributor | OpenAccountants |

```json
{
  "act_articles": {},
  "conditions_context": "| Contributor | OpenAccountants |",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 6,
  "line": 24,
  "original_review_exact_claim": "| Contributor | OpenAccountants |",
  "original_review_row_id": 6,
  "quotation_gaps": [],
  "result_boundary": "Internal workflow/provenance/example-intake policy; not external law",
  "section": "",
  "source_keys": [
    "POLICY"
  ]
}
```

### 7

| Currency | 2026 rules checked on 15 November 2026; older retrieved official copies and filing-cycle limits identified in Sources |

```json
{
  "act_articles": {},
  "conditions_context": "| Currency | 2026 rules checked on 15 November 2026; older retrieved official copies and filing-cycle limits identified in Sources |",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "2026",
    "15",
    "2026"
  ],
  "id": 7,
  "line": 25,
  "original_review_exact_claim": "| Currency | 2026 rules checked on 15 November 2026; older retrieved official copies and filing-cycle limits identified in Sources |",
  "original_review_row_id": 7,
  "quotation_gaps": [],
  "result_boundary": "Internal workflow/provenance/example-intake policy; not external law",
  "section": "",
  "source_keys": [
    "POLICY"
  ]
}
```

### 8

| Skill version | 1.1 |

```json
{
  "act_articles": {},
  "conditions_context": "| Skill version | 1.1 |",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "1.1"
  ],
  "id": 8,
  "line": 26,
  "original_review_exact_claim": "| Skill version | 1.1 |",
  "original_review_row_id": 8,
  "quotation_gaps": [],
  "result_boundary": "Internal workflow/provenance/example-intake policy; not external law",
  "section": "",
  "source_keys": [
    "POLICY"
  ]
}
```

### 9

| Primary legislation | EU Directive Articles 43-59a and 169; UK VATA section 7A and Schedule 4A; Australian GST Act section 38-190; Indian IGST sections 2(6), 13 and 16 with the enacted 2026 amendment; Singapore GST Act section 21(3), as explained by IRAS |

```json
{
  "act_articles": {
    "AUSCOPE": "s38-190(1), chapeau",
    "EU169A": "Article 169(a), domestic-deductibility condition",
    "EU44B": "Article 44, first sentence",
    "IN13BASE": "IGST13(2), general rule",
    "IN16EXPORT": "IGST16(1)(a)",
    "IN2I": "IGST2(6)(i)",
    "INOMIT": "FinanceAct2026 section157",
    "SGROUTE": "IRAS opening international-services explanation, Section21(3)",
    "UKL2A": "VATA1994 section 7A(2)(a)",
    "UKL5": "VATA1994 section 7A(5)",
    "UKSLAND": "Schedule4A paragraph1(1)"
  },
  "conditions_context": "| Primary legislation | EU Directive Articles 43-59a and 169; UK VATA section 7A and Schedule 4A; Australian GST Act section 38-190; Indian IGST sections 2(6), 13 and 16 with the enacted 2026 amendment; Singapore GST Act section 21(3), as explained by IRAS |",
  "evidence_entry_ids": [
    "EU44B",
    "EU169A",
    "UKL2A",
    "UKL5",
    "UKSLAND",
    "AUSCOPE",
    "IN2I",
    "IN13BASE",
    "IN16EXPORT",
    "INOMIT",
    "SGROUTE"
  ],
  "evidence_format_status": "CURRENT_SHORT_EXTRACT_STANDARD_APPLICABLE",
  "evidence_recommendation_note": "Primary-legislation catalogue; exact operative provisions are identified here. SG quotation gap remains, and the IRAS explanation is not falsely labelled a direct Act read.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "43",
    "59",
    "169",
    "7",
    "4",
    "38",
    "190",
    "2(6)",
    "13",
    "16",
    "2026",
    "21(3)"
  ],
  "historical_format_status": "HOLD_EXPLICIT_EXTRACT_GAP",
  "historical_quotation_gaps": [
    "SGROUTE"
  ],
  "id": 9,
  "line": 27,
  "original_review_exact_claim": "| Primary legislation | EU Directive Articles 43-59a and 169; UK VATA section 7A and Schedule 4A; Australian GST Act section 38-190; Indian IGST sections 2(6), 13 and 16 with the enacted 2026 amendment; Singapore GST Act section 21(3), as explained by IRAS |",
  "original_review_row_id": 9,
  "quotation_gaps": [],
  "result_boundary": "Internal workflow/provenance/example-intake policy; not external law",
  "section": "",
  "source_keys": [
    "EU",
    "UKLAW",
    "UKSCH",
    "AU",
    "IN",
    "IN2026",
    "SG"
  ]
}
```

### 10

| Related guidance | `eu-reverse-charge.md`, `eu-oss-digital.md`, `vat-place-of-supply-master.md`, `permanent-establishment-risk.md` and the actual seller/destination country VAT/GST return Guide |

```json
{
  "act_articles": {},
  "conditions_context": "| Related guidance | `eu-reverse-charge.md`, `eu-oss-digital.md`, `vat-place-of-supply-master.md`, `permanent-establishment-risk.md` and the actual seller/destination country VAT/GST return Guide |",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 10,
  "line": 28,
  "original_review_exact_claim": "| Related guidance | `eu-reverse-charge.md`, `eu-oss-digital.md`, `vat-place-of-supply-master.md`, `permanent-establishment-risk.md` and the actual seller/destination country VAT/GST return Guide |",
  "original_review_row_id": 10,
  "quotation_gaps": [],
  "result_boundary": "Internal workflow/provenance/example-intake policy; not external law",
  "section": "",
  "source_keys": [
    "POLICY"
  ]
}
```

### 11

**Confidence labels:** the original [T1] standard B2B scenarios are straightforward only after their legal conditions and evidence are established; [T2] land, events, transport and mixed supplies require classification and review; [T3] unclear consumption, establishments or complex multi-party arrangements require referral.

```json
{
  "act_articles": {},
  "conditions_context": "**Confidence labels:** the original [T1] standard B2B scenarios are straightforward only after their legal conditions and evidence are established; [T2] land, events, transport and mixed supplies require classification and review; [T3] unclear consumption, establishments or complex multi-party arrangements require referral. These are internal task labels, not approval tiers or permission to skip professional review. This revision remains tier 2, without accountant attestation.",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 11,
  "line": 30,
  "original_review_exact_claim": "**Confidence labels:** the original [T1] standard B2B scenarios are straightforward only after their legal conditions and evidence are established; [T2] land, events, transport and mixed supplies require classification and review; [T3] unclear consumption, establishments or complex multi-party arrangements require referral.",
  "original_review_row_id": 11,
  "quotation_gaps": [],
  "result_boundary": "Internal workflow/provenance/example-intake policy; not external law",
  "section": "",
  "source_keys": [
    "POLICY"
  ]
}
```

### 12

These are internal task labels, not approval tiers or permission to skip professional review.

```json
{
  "act_articles": {},
  "conditions_context": "**Confidence labels:** the original [T1] standard B2B scenarios are straightforward only after their legal conditions and evidence are established; [T2] land, events, transport and mixed supplies require classification and review; [T3] unclear consumption, establishments or complex multi-party arrangements require referral. These are internal task labels, not approval tiers or permission to skip professional review. This revision remains tier 2, without accountant attestation.",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 12,
  "line": 30,
  "original_review_exact_claim": "These are internal task labels, not approval tiers or permission to skip professional review.",
  "original_review_row_id": 12,
  "quotation_gaps": [],
  "result_boundary": "Internal workflow/provenance/example-intake policy; not external law",
  "section": "",
  "source_keys": [
    "POLICY"
  ]
}
```

### 13

This revision remains tier 2, without accountant attestation.

```json
{
  "act_articles": {},
  "conditions_context": "**Confidence labels:** the original [T1] standard B2B scenarios are straightforward only after their legal conditions and evidence are established; [T2] land, events, transport and mixed supplies require classification and review; [T3] unclear consumption, establishments or complex multi-party arrangements require referral. These are internal task labels, not approval tiers or permission to skip professional review. This revision remains tier 2, without accountant attestation.",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "2,"
  ],
  "id": 13,
  "line": 30,
  "original_review_exact_claim": "This revision remains tier 2, without accountant attestation.",
  "original_review_row_id": 13,
  "quotation_gaps": [],
  "result_boundary": "Internal workflow/provenance/example-intake policy; not external law",
  "section": "",
  "source_keys": [
    "POLICY"
  ]
}
```

### 14

| EU ordinary business-use service to a non-EU business | Article 44 customer-establishment rule; outside seller VAT only if the relevant customer establishment is outside the EU | https://publications.europa.eu/resource/cellar/03c42d77-512a-11f0-a9d0-01aa75ed71a1.0007.02/DOC_1 |

```json
{
  "act_articles": {
    "EU44ACT": "Article44, first sentence, taxable business-capacity condition",
    "EU44B": "Article 44, first sentence",
    "EU44F": "Article 44, second sentence",
    "EU44R": "Article 44, third sentence",
    "REG21": "Article 21, first/second paragraphs, relevant establishment",
    "REG22": "Article 22(1), identification of receiving establishment",
    "REG22C": "Article 22(1), secondary evidence"
  },
  "conditions_context": "| EU ordinary business-use service to a non-EU business | Article 44 customer-establishment rule; outside seller VAT only if the relevant customer establishment is outside the EU | [official source] |",
  "evidence_entry_ids": [
    "EU44ACT",
    "EU44B",
    "EU44F",
    "EU44R",
    "REG21",
    "REG22",
    "REG22C"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "44",
    "03",
    "2",
    "7",
    "512",
    "11",
    "01",
    "5",
    "1",
    "0007.02",
    "1"
  ],
  "id": 14,
  "line": 36,
  "original_review_exact_claim": "| EU ordinary business-use service to a non-EU business | Article 44 customer-establishment rule; outside seller VAT only if the relevant customer establishment is outside the EU | https://publications.europa.eu/resource/cellar/03c42d77-512a-11f0-a9d0-01aa75ed71a1.0007.02/DOC_1 |",
  "original_review_row_id": 14,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference",
  "source_keys": [
    "EU",
    "REG"
  ]
}
```

### 15

| EU service to non-EU consumer | Article 45 supplier rule unless a specific rule, including Articles 47, 54, 58 or 59, changes it | https://publications.europa.eu/resource/cellar/03c42d77-512a-11f0-a9d0-01aa75ed71a1.0007.02/DOC_1 |

```json
{
  "act_articles": {
    "EU45": "Article 45, first sentence",
    "EU45F": "Article 45, second/third sentences",
    "EU47": "Article 47, final operative clause",
    "EU54": "Article 54(1), first subparagraph",
    "EU54V": "Article 54(1), second subparagraph",
    "EU54VC": "Article 54(1), second subparagraph, result",
    "EU58": "Article 58(1), chapeau",
    "EU59": "Article 59, chapeau, non-EU customer qualification",
    "EU59B_AD": "Article59(b)",
    "EU59C": "Article 59(c)"
  },
  "conditions_context": "| EU service to non-EU consumer | Article 45 supplier rule unless a specific rule, including Articles 47, 54, 58 or 59, changes it | [official source] |",
  "evidence_entry_ids": [
    "EU45",
    "EU45F",
    "EU47",
    "EU54",
    "EU54V",
    "EU54VC",
    "EU58",
    "EU59",
    "EU59C",
    "EU59B_AD"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "45",
    "47,",
    "54,",
    "58",
    "59,",
    "03",
    "2",
    "7",
    "512",
    "11",
    "01",
    "5",
    "1",
    "0007.02",
    "1"
  ],
  "id": 15,
  "line": 37,
  "original_review_exact_claim": "| EU service to non-EU consumer | Article 45 supplier rule unless a specific rule, including Articles 47, 54, 58 or 59, changes it | https://publications.europa.eu/resource/cellar/03c42d77-512a-11f0-a9d0-01aa75ed71a1.0007.02/DOC_1 |",
  "original_review_row_id": 15,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference",
  "source_keys": [
    "EU"
  ]
}
```

### 16

| UK ordinary B2B service to non-UK business | Section 7A recipient-belonging rule, subject to Schedule 4A | https://www.legislation.gov.uk/ukpga/1994/23/section/7A/data.xml |

```json
{
  "act_articles": {
    "UKL2A": "VATA1994 section 7A(2)(a)",
    "UKL4": "VATA1994 section 7A(4)(a)/(b)",
    "UKL5": "VATA1994 section 7A(5)"
  },
  "conditions_context": "| UK ordinary B2B service to non-UK business | Section 7A recipient-belonging rule, subject to Schedule 4A | [official source] |",
  "evidence_entry_ids": [
    "UKL2A",
    "UKL4",
    "UKL5"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "7",
    "4",
    "1994",
    "23",
    "7"
  ],
  "id": 16,
  "line": 38,
  "original_review_exact_claim": "| UK ordinary B2B service to non-UK business | Section 7A recipient-belonging rule, subject to Schedule 4A | https://www.legislation.gov.uk/ukpga/1994/23/section/7A/data.xml |",
  "original_review_row_id": 16,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference",
  "source_keys": [
    "UKLAW"
  ]
}
```

### 17

| Australian service to overseas customer | Prove a particular section 38-190 item and all applicable exclusions; item 2 and item 3 are distinct routes | https://www.legislation.gov.au/C2004A00446/2026-01-01/2026-01-01/text/original/epub/OEBPS/document_1/document_1.html |

```json
{
  "act_articles": {
    "AU2A": "s38-190(1), item2(a)",
    "AU2ABS": "s38-190(1), item2 chapeau",
    "AU2ALAND": "s38-190(1), item2(a), land condition",
    "AU2AWHENDONE": "s38-190(1) item2(a), timing of local work",
    "AU2BENT": "s38-190(1), item2(b), enterprise condition",
    "AU2BREG": "s38-190(1) item2(b), actual registration wording",
    "AU3": "s38-190(1), item3(b)",
    "AU3ABS": "s38-190(1), item3(a)",
    "AU3AUSTAGREE": "s38-190(4)(a), agreement limb",
    "AU3EX": "s38-190(1), item3 final exclusion",
    "AU3LAND": "s38-190(1) item3, final exclusion",
    "AUEXT": "s38-190(4)(b), item3 extension",
    "AUEXTTRANS": "s38-190(5)(a)-(e), goods transport/handling/facilitation/insurance/arrangement; extract(a)",
    "AUEXTX": "s38-190(5), transport-service exclusion to extension",
    "AULOCAL": "s38-190(3)(b), local provision",
    "AULOCALA": "s38-190(3)(a), nonresident agreement",
    "AULOCALC": "s38-190(3)(c), input-taxed limitation on exceptions",
    "AULOCALX": "s38-190(3)(c)(i), business-recipient exception",
    "AULOCALX2": "s38-190(3)(c)(ii), employee/officer alternative",
    "AULOCALX3": "s38-190(3)(c)(iii), recipient creditable-purpose alternative",
    "AUPROP": "s38-190(2A), input-taxed property exclusion",
    "AUPROPALL": "s38-190(2A), item/application extent",
    "AUPROPITEMS": "s38-190(2A), items2-4",
    "AURIGHT": "s38-190(2), rights/options exclusion",
    "AUSCOPE": "s38-190(1), chapeau",
    "AUSCOPEEX": "s38-190(1), chapeau, exclusions"
  },
  "conditions_context": "| Australian service to overseas customer | Prove a particular section 38-190 item and all applicable exclusions; item 2 and item 3 are distinct routes | [official source] |",
  "evidence_entry_ids": [
    "AUSCOPE",
    "AUSCOPEEX",
    "AU2ABS",
    "AU2A",
    "AU2AWHENDONE",
    "AU2ALAND",
    "AURIGHT",
    "AUPROPALL",
    "AUPROPITEMS",
    "AUPROP",
    "AULOCALA",
    "AULOCAL",
    "AULOCALC",
    "AULOCALX",
    "AULOCALX2",
    "AULOCALX3",
    "AU2BENT",
    "AU2BREG",
    "AU3ABS",
    "AU3",
    "AU3EX",
    "AU3LAND",
    "AU3AUSTAGREE",
    "AUEXT",
    "AUEXTX",
    "AUEXTTRANS"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "38",
    "190",
    "2",
    "3",
    "004",
    "0446",
    "2026",
    "01",
    "01",
    "2026",
    "01",
    "01",
    "1",
    "1."
  ],
  "id": 17,
  "line": 39,
  "original_review_exact_claim": "| Australian service to overseas customer | Prove a particular section 38-190 item and all applicable exclusions; item 2 and item 3 are distinct routes | https://www.legislation.gov.au/C2004A00446/2026-01-01/2026-01-01/text/original/epub/OEBPS/document_1/document_1.html |",
  "original_review_row_id": 17,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference",
  "source_keys": [
    "AU"
  ]
}
```

### 18

| Indian service export | All 5 section 2(6) conditions (derived count), current place rule and compliant bond/LUT or eligible notified tax-paid route | https://thc.nic.in/Central%20Governmental%20Acts/Integrated%20Goods%20and%20Services%20Tax%20Act%2C%202017..pdf |

```json
{
  "act_articles": {
    "GCAPRES": "GeneralClausesAct1897 section5(1)(b), same page",
    "GCASSENT": "GeneralClausesAct1897 section5(1), Mumbai Port copy PDFp9",
    "IN13BASE": "IGST13(2), general rule",
    "IN13EVENT": "IGST13(5), scan PDFpage17",
    "IN13FALL": "IGST13(2), proviso",
    "IN13LAND": "IGST13(4)",
    "IN13PHYS": "IGST13(3)(b), physical presence",
    "IN16EXPORT": "IGST16(1)(a)",
    "IN16LUT": "IGST16(3), bond/LUT route",
    "IN16PAID": "IGST16(4), scan PDFpage22, notified class/conditions",
    "IN250": "Same condition(i), strict threshold",
    "IN2FE": "IGST2(14)(c), relevant establishment",
    "IN2I": "IGST2(6)(i)",
    "IN2II": "IGST2(6)(ii)",
    "IN2III": "IGST2(6)(iii)",
    "IN2IV": "IGST2(6)(iv), as amended2018",
    "IN2V": "IGST2(6)(v)",
    "IN8EX": "IGST8Explanation1(i)",
    "INARN": "Same substituted2(c)/(e), deemed acceptance",
    "INARNREJECT": "Same substituted2(e), ineligible LUT rejection",
    "INASSENT": "FinanceAct2026 Gazette title/assent",
    "INCOMMENCEA": "FinanceAct2026 section1(2)(a)",
    "INCOMMENCEB": "FinanceAct2026 section1(2)(b)",
    "INLUTPRIOR": "Circular8/8/2017 paragraph2(e), prior requirement",
    "INLUTYEAR": "Circular8/8/2017 paragraph2(b)",
    "INOMIT": "FinanceAct2026 section157",
    "INPROSEC": "Notification37/2017 condition(i), prosecution exclusion",
    "INRFD": "Circular40/14/2018 paragraph2 substituted2(c)"
  },
  "conditions_context": "| Indian service export | All 5 section 2(6) conditions (derived count), current place rule and compliant bond/LUT or eligible notified tax-paid route | [official source] |",
  "evidence_entry_ids": [
    "IN2I",
    "IN2II",
    "IN2III",
    "IN2IV",
    "IN2V",
    "IN8EX",
    "IN2FE",
    "IN13BASE",
    "IN13FALL",
    "IN13PHYS",
    "IN13LAND",
    "IN13EVENT",
    "INOMIT",
    "INASSENT",
    "INCOMMENCEA",
    "INCOMMENCEB",
    "GCASSENT",
    "GCAPRES",
    "IN16EXPORT",
    "IN16LUT",
    "INLUTYEAR",
    "INLUTPRIOR",
    "INPROSEC",
    "IN250",
    "INRFD",
    "INARN",
    "INARNREJECT",
    "IN16PAID"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "5",
    "2(6)",
    "20",
    "20",
    "20",
    "20",
    "20",
    "20",
    "20",
    "2",
    "202017.."
  ],
  "id": 18,
  "line": 40,
  "original_review_exact_claim": "| Indian service export | All 5 section 2(6) conditions (derived count), current place rule and compliant bond/LUT or eligible notified tax-paid route | https://thc.nic.in/Central%20Governmental%20Acts/Integrated%20Goods%20and%20Services%20Tax%20Act%2C%202017..pdf |",
  "original_review_row_id": 18,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference",
  "source_keys": [
    "IN",
    "IN2026",
    "INGCA",
    "INLUT",
    "IN37",
    "INONLINE"
  ]
}
```

### 19

| Singapore international service | Qualifying section 21(3) provision; overseas contract alone is insufficient | https://www.iras.gov.sg/taxes/goods-services-tax-%28gst%29/charging-gst-%28output-tax%29/when-to-charge-0-gst-%28zero-rate%29/providing-international-services |

```json
{
  "act_articles": {
    "SGABS": "IRAS table row13/(j), overseas customer absence and overseas direct beneficiary absence",
    "SGBUSINESS": "Same table row14/(k), contractual business-capacity limb",
    "SGCONTRACT": "IRAS international-services table row13/(j) and row14/(k), identical overseas-contract limb",
    "SGGOODS": "IRAS table rows9/10/12:21(3)(g)/(h)/(f), goods/export evidence",
    "SGKLAND": "IRAS table row14/(k), professional/data goods-for-export exception and definite/immediate intention condition",
    "SGLAND": "Same table row13/(j), Singapore goods/land restriction",
    "SGLOCAL": "Same table rows13/(j) and14/(k), identical local-beneficiary alternative",
    "SGROUTE": "IRAS opening international-services explanation, Section21(3)"
  },
  "conditions_context": "| Singapore international service | Qualifying section 21(3) provision; overseas contract alone is insufficient | [official source] |",
  "current_goods_ships_boundary": "Singapore professional-versus-data Singapore-goods/ships conditions under the current Second Schedule: the retained 2020 official reproduction distinguishes professional services (export goods and ships) from data services (export goods only), while the current IRAS table combines the categories. The former combined proposition \"professional/data services must not directly relate to Singapore land/goods other than goods for export\" is individually unusable for this branch until the current regulatory text/version is reconciled; no ships relief or blanket ships exclusion is cleared here. ",
  "evidence_entry_ids": [
    "SGROUTE",
    "SGCONTRACT",
    "SGABS",
    "SGLOCAL",
    "SGLAND",
    "SGGOODS",
    "SGBUSINESS",
    "SGKLAND"
  ],
  "evidence_format_status": "CURRENT_SHORT_EXTRACT_STANDARD_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "21(3)",
    "28",
    "29",
    "28",
    "29",
    "0",
    "28",
    "29"
  ],
  "historical_format_status": "HOLD_EXPLICIT_EXTRACT_GAP",
  "historical_quotation_gaps": [
    "SGROUTE",
    "SGABS",
    "SGGOODS",
    "SGKLAND"
  ],
  "id": 19,
  "line": 41,
  "original_review_exact_claim": "| Singapore international service | Qualifying section 21(3) provision; overseas contract alone is insufficient | https://www.iras.gov.sg/taxes/goods-services-tax-%28gst%29/charging-gst-%28output-tax%29/when-to-charge-0-gst-%28zero-rate%29/providing-international-services |",
  "original_review_row_id": 19,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference",
  "source_keys": [
    "SG"
  ]
}
```

### 20

Read contracts, invoices, prior returns and existing case material first.

```json
{
  "act_articles": {},
  "conditions_context": "Read contracts, invoices, prior returns and existing case material first. Ask only unresolved facts, together:",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 20,
  "line": 45,
  "original_review_exact_claim": "Read contracts, invoices, prior returns and existing case material first.",
  "original_review_row_id": 20,
  "quotation_gaps": [],
  "result_boundary": "Internal workflow/provenance/example-intake policy; not external law",
  "section": "Quick reference / Ask the client first",
  "source_keys": [
    "POLICY"
  ]
}
```

### 21

Ask only unresolved facts, together:

```json
{
  "act_articles": {},
  "conditions_context": "Read contracts, invoices, prior returns and existing case material first. Ask only unresolved facts, together:",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 21,
  "line": 45,
  "original_review_exact_claim": "Ask only unresolved facts, together:",
  "original_review_row_id": 21,
  "quotation_gaps": [],
  "result_boundary": "Internal workflow/provenance/example-intake policy; not external law",
  "section": "Quick reference / Ask the client first",
  "source_keys": [
    "POLICY"
  ]
}
```

### 22

1.

```json
{
  "act_articles": {},
  "conditions_context": "1. Where is the seller established and registered, under which VAT/GST scheme, and for what supply/return period?",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "1."
  ],
  "id": 22,
  "line": 47,
  "original_review_exact_claim": "1.",
  "original_review_row_id": 22,
  "quotation_gaps": [],
  "result_boundary": "Internal workflow/provenance/example-intake policy; not external law",
  "section": "Quick reference / Ask the client first",
  "source_keys": [
    "POLICY"
  ]
}
```

### 23

Where is the seller established and registered, under which VAT/GST scheme, and for what supply/return period?

```json
{
  "act_articles": {},
  "conditions_context": "1. Where is the seller established and registered, under which VAT/GST scheme, and for what supply/return period?",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 23,
  "line": 47,
  "original_review_exact_claim": "Where is the seller established and registered, under which VAT/GST scheme, and for what supply/return period?",
  "original_review_row_id": 23,
  "quotation_gaps": [],
  "result_boundary": "Internal workflow/provenance/example-intake policy; not external law",
  "section": "Quick reference / Ask the client first",
  "source_keys": [
    "POLICY"
  ]
}
```

### 24

2.

```json
{
  "act_articles": {},
  "conditions_context": "2. Who contracts and pays, where do the customer and relevant establishments belong, and is the service for business or private use?",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "2."
  ],
  "id": 24,
  "line": 48,
  "original_review_exact_claim": "2.",
  "original_review_row_id": 24,
  "quotation_gaps": [],
  "result_boundary": "Internal workflow/provenance/example-intake policy; not external law",
  "section": "Quick reference / Ask the client first",
  "source_keys": [
    "POLICY"
  ]
}
```

### 25

Who contracts and pays, where do the customer and relevant establishments belong, and is the service for business or private use?

```json
{
  "act_articles": {},
  "conditions_context": "2. Who contracts and pays, where do the customer and relevant establishments belong, and is the service for business or private use?",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 25,
  "line": 48,
  "original_review_exact_claim": "Who contracts and pays, where do the customer and relevant establishments belong, and is the service for business or private use?",
  "original_review_row_id": 25,
  "quotation_gaps": [],
  "result_boundary": "Internal workflow/provenance/example-intake policy; not external law",
  "section": "Quick reference / Ask the client first",
  "source_keys": [
    "POLICY"
  ]
}
```

### 26

3.

```json
{
  "act_articles": {},
  "conditions_context": "3. What exactly is supplied, including bundled goods, rights, land, event admission, training, transport or intermediary elements?",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "3."
  ],
  "id": 26,
  "line": 49,
  "original_review_exact_claim": "3.",
  "original_review_row_id": 26,
  "quotation_gaps": [],
  "result_boundary": "Internal workflow/provenance/example-intake policy; not external law",
  "section": "Quick reference / Ask the client first",
  "source_keys": [
    "POLICY"
  ]
}
```

### 27

What exactly is supplied, including bundled goods, rights, land, event admission, training, transport or intermediary elements?

```json
{
  "act_articles": {},
  "conditions_context": "3. What exactly is supplied, including bundled goods, rights, land, event admission, training, transport or intermediary elements?",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 27,
  "line": 49,
  "original_review_exact_claim": "What exactly is supplied, including bundled goods, rights, land, event admission, training, transport or intermediary elements?",
  "original_review_row_id": 27,
  "quotation_gaps": [],
  "result_boundary": "Internal workflow/provenance/example-intake policy; not external law",
  "section": "Quick reference / Ask the client first",
  "source_keys": [
    "POLICY"
  ]
}
```

### 28

4.

```json
{
  "act_articles": {},
  "conditions_context": "4. Where is the service performed, where are relevant land/goods, and who actually receives or directly benefits from it? Identify any Australian or Singapore beneficiary.",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "4."
  ],
  "id": 28,
  "line": 50,
  "original_review_exact_claim": "4.",
  "original_review_row_id": 28,
  "quotation_gaps": [],
  "result_boundary": "Internal workflow/provenance/example-intake policy; not external law",
  "section": "Quick reference / Ask the client first",
  "source_keys": [
    "POLICY"
  ]
}
```

### 29

Where is the service performed, where are relevant land/goods, and who actually receives or directly benefits from it?

```json
{
  "act_articles": {},
  "conditions_context": "4. Where is the service performed, where are relevant land/goods, and who actually receives or directly benefits from it? Identify any Australian or Singapore beneficiary.",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 29,
  "line": 50,
  "original_review_exact_claim": "Where is the service performed, where are relevant land/goods, and who actually receives or directly benefits from it?",
  "original_review_row_id": 29,
  "quotation_gaps": [],
  "result_boundary": "Internal workflow/provenance/example-intake policy; not external law",
  "section": "Quick reference / Ask the client first",
  "source_keys": [
    "POLICY"
  ]
}
```

### 30

Identify any Australian or Singapore beneficiary.

```json
{
  "act_articles": {},
  "conditions_context": "4. Where is the service performed, where are relevant land/goods, and who actually receives or directly benefits from it? Identify any Australian or Singapore beneficiary.",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 30,
  "line": 50,
  "original_review_exact_claim": "Identify any Australian or Singapore beneficiary.",
  "original_review_row_id": 30,
  "quotation_gaps": [],
  "result_boundary": "Internal workflow/provenance/example-intake policy; not external law",
  "section": "Quick reference / Ask the client first",
  "source_keys": [
    "POLICY"
  ]
}
```

### 31

5.

```json
{
  "act_articles": {},
  "conditions_context": "5. What supports the customer's status/location and the intended use, including tax identifiers, commercial checks and establishment facts?",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "5."
  ],
  "id": 31,
  "line": 51,
  "original_review_exact_claim": "5.",
  "original_review_row_id": 31,
  "quotation_gaps": [],
  "result_boundary": "Internal workflow/provenance/example-intake policy; not external law",
  "section": "Quick reference / Ask the client first",
  "source_keys": [
    "POLICY"
  ]
}
```

### 32

What supports the customer's status/location and the intended use, including tax identifiers, commercial checks and establishment facts?

```json
{
  "act_articles": {},
  "conditions_context": "5. What supports the customer's status/location and the intended use, including tax identifiers, commercial checks and establishment facts?",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 32,
  "line": 51,
  "original_review_exact_claim": "What supports the customer's status/location and the intended use, including tax identifiers, commercial checks and establishment facts?",
  "original_review_row_id": 32,
  "quotation_gaps": [],
  "result_boundary": "Internal workflow/provenance/example-intake policy; not external law",
  "section": "Quick reference / Ask the client first",
  "source_keys": [
    "POLICY"
  ]
}
```

### 33

6.

```json
{
  "act_articles": {},
  "conditions_context": "6. For India, what are the permitted currency, actual receipt date, RBI/FEMA evidence, separate-person facts and current-year LUT/bond or notified paid-route eligibility? For all sellers, what supports input deduction and the actual return field?",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "6."
  ],
  "id": 33,
  "line": 52,
  "original_review_exact_claim": "6.",
  "original_review_row_id": 33,
  "quotation_gaps": [],
  "result_boundary": "Internal workflow/provenance/example-intake policy; not external law",
  "section": "Quick reference / Ask the client first",
  "source_keys": [
    "POLICY"
  ]
}
```

### 34

For India, what are the permitted currency, actual receipt date, RBI/FEMA evidence, separate-person facts and current-year LUT/bond or notified paid-route eligibility?

```json
{
  "act_articles": {},
  "conditions_context": "6. For India, what are the permitted currency, actual receipt date, RBI/FEMA evidence, separate-person facts and current-year LUT/bond or notified paid-route eligibility? For all sellers, what supports input deduction and the actual return field?",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 34,
  "line": 52,
  "original_review_exact_claim": "For India, what are the permitted currency, actual receipt date, RBI/FEMA evidence, separate-person facts and current-year LUT/bond or notified paid-route eligibility?",
  "original_review_row_id": 34,
  "quotation_gaps": [],
  "result_boundary": "Internal workflow/provenance/example-intake policy; not external law",
  "section": "Quick reference / Ask the client first",
  "source_keys": [
    "POLICY"
  ]
}
```

### 35

For all sellers, what supports input deduction and the actual return field?

```json
{
  "act_articles": {},
  "conditions_context": "6. For India, what are the permitted currency, actual receipt date, RBI/FEMA evidence, separate-person facts and current-year LUT/bond or notified paid-route eligibility? For all sellers, what supports input deduction and the actual return field?",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 35,
  "line": 52,
  "original_review_exact_claim": "For all sellers, what supports input deduction and the actual return field?",
  "original_review_row_id": 35,
  "quotation_gaps": [],
  "result_boundary": "Internal workflow/provenance/example-intake policy; not external law",
  "section": "Quick reference / Ask the client first",
  "source_keys": [
    "POLICY"
  ]
}
```

### 36

Stop an unsupported classification or final invoice if the seller, recipient/status or relevant establishment is unknown; also stop when service type or another decisive fact is missing.

```json
{
  "act_articles": {
    "EU43": "Article 43(2)",
    "REG18A": "Article 18(3)(a), non-EU customer certificate",
    "REG18B": "Article 18(3)(b), alternative proof and verification",
    "REG18CONTRARY": "Article18(3), opening safeguard",
    "REG18ID": "Article18(3)(b), identifiers alternative",
    "REG18V": "Article 18(3)(b), verification condition",
    "REG19": "Article 19, first paragraph, private use",
    "UKBELONG": "Notice741A sections3-4 and6, customer business/status/belonging evidence and relevant establishment"
  },
  "conditions_context": "Stop an unsupported classification or final invoice if the seller, recipient/status or relevant establishment is unknown; also stop when service type or another decisive fact is missing. A foreign postal address is not enough. EU customer-status/private-use/establishment tests: Regulation 282/2011 Articles 18-22, [official source]; UK evidence and belonging: Notice 741A sections 2-4 and 6, [official source].",
  "evidence_entry_ids": [
    "REG18CONTRARY",
    "REG18A",
    "REG18ID",
    "REG18B",
    "REG18V",
    "REG19",
    "EU43",
    "UKBELONG"
  ],
  "evidence_format_status": "CURRENT_SHORT_EXTRACT_STANDARD_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "historical_format_status": "HOLD_EXPLICIT_EXTRACT_GAP",
  "historical_quotation_gaps": [
    "UKBELONG"
  ],
  "id": 36,
  "line": 54,
  "original_review_exact_claim": "Stop an unsupported classification or final invoice if the seller, recipient/status or relevant establishment is unknown; also stop when service type or another decisive fact is missing.",
  "original_review_row_id": 36,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Ask the client first",
  "source_keys": [
    "REG",
    "EU",
    "UK"
  ]
}
```

### 37

A foreign postal address is not enough.

```json
{
  "act_articles": {
    "EU43": "Article 43(2)",
    "REG18A": "Article 18(3)(a), non-EU customer certificate",
    "REG18B": "Article 18(3)(b), alternative proof and verification",
    "REG18CONTRARY": "Article18(3), opening safeguard",
    "REG18ID": "Article18(3)(b), identifiers alternative",
    "REG18V": "Article 18(3)(b), verification condition",
    "REG19": "Article 19, first paragraph, private use",
    "UKBELONG": "Notice741A sections3-4 and6, customer business/status/belonging evidence and relevant establishment"
  },
  "conditions_context": "Stop an unsupported classification or final invoice if the seller, recipient/status or relevant establishment is unknown; also stop when service type or another decisive fact is missing. A foreign postal address is not enough. EU customer-status/private-use/establishment tests: Regulation 282/2011 Articles 18-22, [official source]; UK evidence and belonging: Notice 741A sections 2-4 and 6, [official source].",
  "evidence_entry_ids": [
    "REG18CONTRARY",
    "REG18A",
    "REG18ID",
    "REG18B",
    "REG18V",
    "REG19",
    "EU43",
    "UKBELONG"
  ],
  "evidence_format_status": "CURRENT_SHORT_EXTRACT_STANDARD_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "historical_format_status": "HOLD_EXPLICIT_EXTRACT_GAP",
  "historical_quotation_gaps": [
    "UKBELONG"
  ],
  "id": 37,
  "line": 54,
  "original_review_exact_claim": "A foreign postal address is not enough.",
  "original_review_row_id": 37,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Ask the client first",
  "source_keys": [
    "REG",
    "EU",
    "UK"
  ]
}
```

### 38

EU customer-status/private-use/establishment tests: Regulation 282/2011 Articles 18-22, [official source]; UK evidence and belonging: Notice 741A sections 2-4 and 6, [official source].

```json
{
  "act_articles": {
    "EU43": "Article 43(2)",
    "REG18A": "Article 18(3)(a), non-EU customer certificate",
    "REG18B": "Article 18(3)(b), alternative proof and verification",
    "REG18CONTRARY": "Article18(3), opening safeguard",
    "REG18ID": "Article18(3)(b), identifiers alternative",
    "REG18V": "Article 18(3)(b), verification condition",
    "REG19": "Article 19, first paragraph, private use",
    "REG20": "Article 20, one-country establishment",
    "REG21": "Article 21, first/second paragraphs, relevant establishment",
    "REG22": "Article 22(1), identification of receiving establishment",
    "REG22C": "Article 22(1), secondary evidence",
    "UKBELONG": "Notice741A sections3-4 and6, customer business/status/belonging evidence and relevant establishment"
  },
  "conditions_context": "Stop an unsupported classification or final invoice if the seller, recipient/status or relevant establishment is unknown; also stop when service type or another decisive fact is missing. A foreign postal address is not enough. EU customer-status/private-use/establishment tests: Regulation 282/2011 Articles 18-22, [official source]; UK evidence and belonging: Notice 741A sections 2-4 and 6, [official source].",
  "evidence_entry_ids": [
    "REG18CONTRARY",
    "REG18A",
    "REG18ID",
    "REG18B",
    "REG18V",
    "REG19",
    "EU43",
    "REG20",
    "REG21",
    "REG22",
    "REG22C",
    "UKBELONG"
  ],
  "evidence_format_status": "CURRENT_SHORT_EXTRACT_STANDARD_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "282",
    "2011",
    "18",
    "22,",
    "741",
    "2",
    "4",
    "6,"
  ],
  "historical_format_status": "HOLD_EXPLICIT_EXTRACT_GAP",
  "historical_quotation_gaps": [
    "UKBELONG"
  ],
  "id": 38,
  "line": 54,
  "original_review_exact_claim": "EU customer-status/private-use/establishment tests: Regulation 282/2011 Articles 18-22, [official source]; UK evidence and belonging: Notice 741A sections 2-4 and 6, [official source].",
  "original_review_row_id": 38,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Ask the client first",
  "source_keys": [
    "REG",
    "EU",
    "UK"
  ]
}
```

### 39

An outside-scope service is located outside the seller's taxing jurisdiction.

```json
{
  "act_articles": {
    "EU44B": "Article 44, first sentence",
    "UKL2A": "VATA1994 section 7A(2)(a)"
  },
  "conditions_context": "An outside-scope service is located outside the seller's taxing jurisdiction. A zero-rated/GST-free service qualifies for a specific domestic relief. An exempt/input-taxed supply is a different category and can restrict credits. Even if the customer pays no seller tax in both cases, the legal basis, invoice wording, deduction and reporting can differ. There is no worldwide rule that all B2B services are taxed only in the customer's country: use the relevant country rule and exceptions. UK Notice 741A sections 1-2 and 6: [official source]; EU Articles 44-59a and 168-178: [official source].",
  "evidence_entry_ids": [
    "EU44B",
    "UKL2A"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "Description of territorial result; there is no single worldwide statutory definition.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 39,
  "line": 60,
  "original_review_exact_claim": "An outside-scope service is located outside the seller's taxing jurisdiction.",
  "original_review_row_id": 39,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 1: Separate outside scope, zero-rated and exempt",
  "source_keys": [
    "EU",
    "UKLAW"
  ]
}
```

### 40

A zero-rated/GST-free service qualifies for a specific domestic relief.

```json
{
  "act_articles": {
    "AUSCOPE": "s38-190(1), chapeau",
    "IN16EXPORT": "IGST16(1)(a)",
    "SGROUTE": "IRAS opening international-services explanation, Section21(3)"
  },
  "conditions_context": "An outside-scope service is located outside the seller's taxing jurisdiction. A zero-rated/GST-free service qualifies for a specific domestic relief. An exempt/input-taxed supply is a different category and can restrict credits. Even if the customer pays no seller tax in both cases, the legal basis, invoice wording, deduction and reporting can differ. There is no worldwide rule that all B2B services are taxed only in the customer's country: use the relevant country rule and exceptions. UK Notice 741A sections 1-2 and 6: [official source]; EU Articles 44-59a and 168-178: [official source].",
  "evidence_entry_ids": [
    "AUSCOPE",
    "IN16EXPORT",
    "SGROUTE"
  ],
  "evidence_format_status": "CURRENT_SHORT_EXTRACT_STANDARD_APPLICABLE",
  "evidence_recommendation_note": "Country terminology comparison, not a new universal category or rate.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "historical_format_status": "HOLD_EXPLICIT_EXTRACT_GAP",
  "historical_quotation_gaps": [
    "SGROUTE"
  ],
  "id": 40,
  "line": 60,
  "original_review_exact_claim": "A zero-rated/GST-free service qualifies for a specific domestic relief.",
  "original_review_row_id": 40,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 1: Separate outside scope, zero-rated and exempt",
  "source_keys": [
    "AU",
    "IN",
    "SG"
  ]
}
```

### 41

An exempt/input-taxed supply is a different category and can restrict credits.

```json
{
  "act_articles": {
    "AU11INPUT": "s11-15(2)(a), subject3-5exceptions",
    "AU11PRIVATE": "s11-15(2)(b)",
    "EU169A": "Article 169(a), domestic-deductibility condition",
    "EU173": "Article 173(1), mixed use"
  },
  "conditions_context": "An outside-scope service is located outside the seller's taxing jurisdiction. A zero-rated/GST-free service qualifies for a specific domestic relief. An exempt/input-taxed supply is a different category and can restrict credits. Even if the customer pays no seller tax in both cases, the legal basis, invoice wording, deduction and reporting can differ. There is no worldwide rule that all B2B services are taxed only in the customer's country: use the relevant country rule and exceptions. UK Notice 741A sections 1-2 and 6: [official source]; EU Articles 44-59a and 168-178: [official source].",
  "evidence_entry_ids": [
    "EU169A",
    "EU173",
    "AU11INPUT",
    "AU11PRIVATE"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 41,
  "line": 60,
  "original_review_exact_claim": "An exempt/input-taxed supply is a different category and can restrict credits.",
  "original_review_row_id": 41,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 1: Separate outside scope, zero-rated and exempt",
  "source_keys": [
    "EU",
    "AU"
  ]
}
```

### 42

Even if the customer pays no seller tax in both cases, the legal basis, invoice wording, deduction and reporting can differ.

```json
{
  "act_articles": {
    "ABG3": "G3 Other GST-free sales, What to report at G3",
    "EU169A": "Article 169(a), domestic-deductibility condition",
    "EU219A": "Article 219a(1), invoicing framework",
    "EU226": "Article 226(11a), mandatory wording",
    "UKBOX6": "Notice700/12 section3.7, Box6 list"
  },
  "conditions_context": "An outside-scope service is located outside the seller's taxing jurisdiction. A zero-rated/GST-free service qualifies for a specific domestic relief. An exempt/input-taxed supply is a different category and can restrict credits. Even if the customer pays no seller tax in both cases, the legal basis, invoice wording, deduction and reporting can differ. There is no worldwide rule that all B2B services are taxed only in the customer's country: use the relevant country rule and exceptions. UK Notice 741A sections 1-2 and 6: [official source]; EU Articles 44-59a and 168-178: [official source].",
  "evidence_entry_ids": [
    "EU169A",
    "EU219A",
    "EU226",
    "UKBOX6",
    "ABG3"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "Conditional synthesis of separate deduction, invoicing and reporting provisions, not a single external rule.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 42,
  "line": 60,
  "original_review_exact_claim": "Even if the customer pays no seller tax in both cases, the legal basis, invoice wording, deduction and reporting can differ.",
  "original_review_row_id": 42,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 1: Separate outside scope, zero-rated and exempt",
  "source_keys": [
    "EU",
    "UKRETURN",
    "AUBAS"
  ]
}
```

### 43

There is no worldwide rule that all B2B services are taxed only in the customer's country: use the relevant country rule and exceptions.

```json
{
  "act_articles": {
    "AU2A": "s38-190(1), item2(a)",
    "AU2ABS": "s38-190(1), item2 chapeau",
    "AU2ALAND": "s38-190(1), item2(a), land condition",
    "AU2AWHENDONE": "s38-190(1) item2(a), timing of local work",
    "AULOCAL": "s38-190(3)(b), local provision",
    "AULOCALA": "s38-190(3)(a), nonresident agreement",
    "AULOCALC": "s38-190(3)(c), input-taxed limitation on exceptions",
    "AULOCALX": "s38-190(3)(c)(i), business-recipient exception",
    "AULOCALX2": "s38-190(3)(c)(ii), employee/officer alternative",
    "AULOCALX3": "s38-190(3)(c)(iii), recipient creditable-purpose alternative",
    "AUPROP": "s38-190(2A), input-taxed property exclusion",
    "AUPROPALL": "s38-190(2A), item/application extent",
    "AUPROPITEMS": "s38-190(2A), items2-4",
    "AURIGHT": "s38-190(2), rights/options exclusion",
    "AUSCOPE": "s38-190(1), chapeau",
    "AUSCOPEEX": "s38-190(1), chapeau, exclusions",
    "EU44ACT": "Article44, first sentence, taxable business-capacity condition",
    "EU44B": "Article 44, first sentence",
    "EU44F": "Article 44, second sentence",
    "EU44R": "Article 44, third sentence",
    "EU45": "Article 45, first sentence",
    "IN2FE": "IGST2(14)(c), relevant establishment",
    "IN2I": "IGST2(6)(i)",
    "IN2II": "IGST2(6)(ii)",
    "IN2III": "IGST2(6)(iii)",
    "IN2IV": "IGST2(6)(iv), as amended2018",
    "IN2V": "IGST2(6)(v)",
    "IN8EX": "IGST8Explanation1(i)",
    "REG21": "Article 21, first/second paragraphs, relevant establishment",
    "REG22": "Article 22(1), identification of receiving establishment",
    "REG22C": "Article 22(1), secondary evidence",
    "SGABS": "IRAS table row13/(j), overseas customer absence and overseas direct beneficiary absence",
    "SGCONTRACT": "IRAS international-services table row13/(j) and row14/(k), identical overseas-contract limb",
    "SGGOODS": "IRAS table rows9/10/12:21(3)(g)/(h)/(f), goods/export evidence",
    "SGLAND": "Same table row13/(j), Singapore goods/land restriction",
    "SGLOCAL": "Same table rows13/(j) and14/(k), identical local-beneficiary alternative",
    "UKL5": "VATA1994 section 7A(5)"
  },
  "conditions_context": "An outside-scope service is located outside the seller's taxing jurisdiction. A zero-rated/GST-free service qualifies for a specific domestic relief. An exempt/input-taxed supply is a different category and can restrict credits. Even if the customer pays no seller tax in both cases, the legal basis, invoice wording, deduction and reporting can differ. There is no worldwide rule that all B2B services are taxed only in the customer's country: use the relevant country rule and exceptions. UK Notice 741A sections 1-2 and 6: [official source]; EU Articles 44-59a and 168-178: [official source].",
  "evidence_entry_ids": [
    "EU44ACT",
    "EU44B",
    "EU44F",
    "EU44R",
    "REG21",
    "REG22",
    "REG22C",
    "EU45",
    "UKL5",
    "AUSCOPE",
    "AUSCOPEEX",
    "AU2ABS",
    "AU2A",
    "AU2AWHENDONE",
    "AU2ALAND",
    "AURIGHT",
    "AUPROPALL",
    "AUPROPITEMS",
    "AUPROP",
    "AULOCALA",
    "AULOCAL",
    "AULOCALC",
    "AULOCALX",
    "AULOCALX2",
    "AULOCALX3",
    "IN2I",
    "IN2II",
    "IN2III",
    "IN2IV",
    "IN2V",
    "IN8EX",
    "IN2FE",
    "SGCONTRACT",
    "SGABS",
    "SGLOCAL",
    "SGLAND",
    "SGGOODS"
  ],
  "evidence_format_status": "CURRENT_SHORT_EXTRACT_STANDARD_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "historical_format_status": "HOLD_EXPLICIT_EXTRACT_GAP",
  "historical_quotation_gaps": [
    "SGABS",
    "SGGOODS"
  ],
  "id": 43,
  "line": 60,
  "original_review_exact_claim": "There is no worldwide rule that all B2B services are taxed only in the customer's country: use the relevant country rule and exceptions.",
  "original_review_row_id": 43,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 1: Separate outside scope, zero-rated and exempt",
  "source_keys": [
    "EU",
    "REG",
    "UKLAW",
    "AU",
    "IN",
    "SG"
  ]
}
```

### 44

UK Notice 741A sections 1-2 and 6: [official source]; EU Articles 44-59a and 168-178: [official source].

```json
{
  "act_articles": {
    "EU168": "Article 168, chapeau",
    "EU169A": "Article 169(a), domestic-deductibility condition",
    "EU169AX": "Article 169(a), Article 284 exclusion",
    "EU169C": "Article 169(c), financial/insurance route",
    "EU173": "Article 173(1), mixed use",
    "EU176": "Article 176, second paragraph",
    "EU178": "Article 178(a), invoice condition",
    "EU44ACT": "Article44, first sentence, taxable business-capacity condition",
    "EU44B": "Article 44, first sentence",
    "EU44F": "Article 44, second sentence",
    "EU44R": "Article 44, third sentence",
    "EU45": "Article 45, first sentence",
    "EU47": "Article 47, final operative clause",
    "EU53": "Article 53, first paragraph",
    "EU54": "Article 54(1), first subparagraph",
    "EU58": "Article 58(1), chapeau",
    "EU59": "Article 59, chapeau, non-EU customer qualification",
    "REG21": "Article 21, first/second paragraphs, relevant establishment",
    "REG22": "Article 22(1), identification of receiving establishment",
    "REG22C": "Article 22(1), secondary evidence",
    "UKL2A": "VATA1994 section 7A(2)(a)",
    "UKL2B": "VATA1994 section 7A(2)(b)",
    "UKL5": "VATA1994 section 7A(5)"
  },
  "conditions_context": "An outside-scope service is located outside the seller's taxing jurisdiction. A zero-rated/GST-free service qualifies for a specific domestic relief. An exempt/input-taxed supply is a different category and can restrict credits. Even if the customer pays no seller tax in both cases, the legal basis, invoice wording, deduction and reporting can differ. There is no worldwide rule that all B2B services are taxed only in the customer's country: use the relevant country rule and exceptions. UK Notice 741A sections 1-2 and 6: [official source]; EU Articles 44-59a and 168-178: [official source].",
  "evidence_entry_ids": [
    "EU44ACT",
    "EU44B",
    "EU44F",
    "EU44R",
    "REG21",
    "REG22",
    "REG22C",
    "EU45",
    "EU47",
    "EU53",
    "EU54",
    "EU58",
    "EU59",
    "EU168",
    "EU169A",
    "EU169AX",
    "EU169C",
    "EU173",
    "EU176",
    "EU178",
    "UKL2A",
    "UKL2B",
    "UKL5"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "741",
    "1",
    "2",
    "6",
    "44",
    "59",
    "168",
    "178"
  ],
  "id": 44,
  "line": 60,
  "original_review_exact_claim": "UK Notice 741A sections 1-2 and 6: [official source]; EU Articles 44-59a and 168-178: [official source].",
  "original_review_row_id": 44,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 1: Separate outside scope, zero-rated and exempt",
  "source_keys": [
    "EU",
    "REG",
    "UKLAW"
  ]
}
```

### 45

Do not promise FULL input recovery merely because a service is exported.

```json
{
  "act_articles": {
    "AU11A": "s11-5(a)-(d), creditable acquisition",
    "AU11B": "s11-5(b)",
    "AU11C": "s11-5(c)",
    "AU11D": "s11-5(d)",
    "AU11ENTERPRISE": "s11-15(1)",
    "AU11ENTITLE": "s11-20",
    "AU11EX3": "s11-15(3), overseas-enterprise exception to11-15(2)(a)",
    "AU11EX4": "s11-15(4)(b), financial-acquisitions exception",
    "AU11EX5": "s11-15(5)(b), borrowing exception",
    "AU11INPUT": "s11-15(2)(a), subject3-5exceptions",
    "AU11PART": "s11-25 second sentence and11-30(1)/(3)",
    "AU11PRIVATE": "s11-15(2)(b)",
    "AU29INV": "s29-10(3), tax invoice attribution condition, exceptions in final paragraph",
    "AU29INVEX": "s29-10(3), Commissioner exception",
    "EU168": "Article 168, chapeau",
    "EU169A": "Article 169(a), domestic-deductibility condition",
    "EU169AX": "Article 169(a), Article 284 exclusion",
    "EU169C": "Article 169(c), financial/insurance route",
    "EU173": "Article 173(1), mixed use",
    "EU176": "Article 176, second paragraph",
    "EU178": "Article 178(a), invoice condition",
    "SGALL8": "IRAS Conditions you must meet, opening and complete enumerated conditions1-8",
    "SGATTRIB": "Same page, business/nonbusiness use paragraph following condition3"
  },
  "conditions_context": "Do not promise FULL input recovery merely because a service is exported. For EU outside-territory transactions, Article 169(a) requires that deduction would be available if the transaction occurred domestically, and excludes Article 284-exempt transactions; Article 169(c) separately addresses specified exempt financial/insurance transactions with non-EU customers. Mixed use, non-business expenditure, national exclusions and invoice evidence still matter under Articles 173, 176 and 178. Source: [official source]. The country rules below impose their own conditions.",
  "evidence_entry_ids": [
    "EU168",
    "EU169A",
    "EU169AX",
    "EU169C",
    "EU173",
    "EU176",
    "EU178",
    "AU11A",
    "AU11B",
    "AU11C",
    "AU11D",
    "AU11ENTERPRISE",
    "AU11ENTITLE",
    "AU11PRIVATE",
    "AU11INPUT",
    "AU11EX3",
    "AU11EX4",
    "AU11EX5",
    "AU11PART",
    "AU29INV",
    "AU29INVEX",
    "SGALL8",
    "SGATTRIB"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 45,
  "line": 62,
  "original_review_exact_claim": "Do not promise FULL input recovery merely because a service is exported.",
  "original_review_row_id": 45,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 1: Separate outside scope, zero-rated and exempt",
  "source_keys": [
    "EU",
    "AU",
    "SGINPUT"
  ]
}
```

### 46

For EU outside-territory transactions, Article 169(a) requires that deduction would be available if the transaction occurred domestically, and excludes Article 284-exempt transactions; Article 169(c) separately addresses specified exempt financial/insurance transactions with non-EU customers.

```json
{
  "act_articles": {
    "EU169A": "Article 169(a), domestic-deductibility condition",
    "EU169AX": "Article 169(a), Article 284 exclusion",
    "EU169C": "Article 169(c), financial/insurance route"
  },
  "conditions_context": "Do not promise FULL input recovery merely because a service is exported. For EU outside-territory transactions, Article 169(a) requires that deduction would be available if the transaction occurred domestically, and excludes Article 284-exempt transactions; Article 169(c) separately addresses specified exempt financial/insurance transactions with non-EU customers. Mixed use, non-business expenditure, national exclusions and invoice evidence still matter under Articles 173, 176 and 178. Source: [official source]. The country rules below impose their own conditions.",
  "evidence_entry_ids": [
    "EU169A",
    "EU169AX",
    "EU169C"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "169(a)",
    "284",
    "169(c)"
  ],
  "id": 46,
  "line": 62,
  "original_review_exact_claim": "For EU outside-territory transactions, Article 169(a) requires that deduction would be available if the transaction occurred domestically, and excludes Article 284-exempt transactions; Article 169(c) separately addresses specified exempt financial/insurance transactions with non-EU customers.",
  "original_review_row_id": 46,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 1: Separate outside scope, zero-rated and exempt",
  "source_keys": [
    "EU"
  ]
}
```

### 47

Mixed use, non-business expenditure, national exclusions and invoice evidence still matter under Articles 173, 176 and 178.

```json
{
  "act_articles": {
    "EU168": "Article 168, chapeau",
    "EU173": "Article 173(1), mixed use",
    "EU176": "Article 176, second paragraph",
    "EU178": "Article 178(a), invoice condition"
  },
  "conditions_context": "Do not promise FULL input recovery merely because a service is exported. For EU outside-territory transactions, Article 169(a) requires that deduction would be available if the transaction occurred domestically, and excludes Article 284-exempt transactions; Article 169(c) separately addresses specified exempt financial/insurance transactions with non-EU customers. Mixed use, non-business expenditure, national exclusions and invoice evidence still matter under Articles 173, 176 and 178. Source: [official source]. The country rules below impose their own conditions.",
  "evidence_entry_ids": [
    "EU168",
    "EU173",
    "EU176",
    "EU178"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "173,",
    "176",
    "178."
  ],
  "id": 47,
  "line": 62,
  "original_review_exact_claim": "Mixed use, non-business expenditure, national exclusions and invoice evidence still matter under Articles 173, 176 and 178.",
  "original_review_row_id": 47,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 1: Separate outside scope, zero-rated and exempt",
  "source_keys": [
    "EU"
  ]
}
```

### 48

Source: [official source].

```json
{
  "act_articles": {
    "EU168": "Article 168, chapeau",
    "EU169A": "Article 169(a), domestic-deductibility condition",
    "EU169AX": "Article 169(a), Article 284 exclusion",
    "EU169C": "Article 169(c), financial/insurance route",
    "EU173": "Article 173(1), mixed use",
    "EU176": "Article 176, second paragraph",
    "EU178": "Article 178(a), invoice condition"
  },
  "conditions_context": "Do not promise FULL input recovery merely because a service is exported. For EU outside-territory transactions, Article 169(a) requires that deduction would be available if the transaction occurred domestically, and excludes Article 284-exempt transactions; Article 169(c) separately addresses specified exempt financial/insurance transactions with non-EU customers. Mixed use, non-business expenditure, national exclusions and invoice evidence still matter under Articles 173, 176 and 178. Source: [official source]. The country rules below impose their own conditions.",
  "evidence_entry_ids": [
    "EU168",
    "EU169A",
    "EU169AX",
    "EU169C",
    "EU173",
    "EU176",
    "EU178"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 48,
  "line": 62,
  "original_review_exact_claim": "Source: [official source].",
  "original_review_row_id": 48,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 1: Separate outside scope, zero-rated and exempt",
  "source_keys": [
    "EU"
  ]
}
```

### 49

The country rules below impose their own conditions.

```json
{
  "act_articles": {
    "AU11A": "s11-5(a)-(d), creditable acquisition",
    "AU11B": "s11-5(b)",
    "AU11C": "s11-5(c)",
    "AU11D": "s11-5(d)",
    "AU11ENTERPRISE": "s11-15(1)",
    "AU11ENTITLE": "s11-20",
    "AU11EX3": "s11-15(3), overseas-enterprise exception to11-15(2)(a)",
    "AU11EX4": "s11-15(4)(b), financial-acquisitions exception",
    "AU11EX5": "s11-15(5)(b), borrowing exception",
    "AU11INPUT": "s11-15(2)(a), subject3-5exceptions",
    "AU11PART": "s11-25 second sentence and11-30(1)/(3)",
    "AU11PRIVATE": "s11-15(2)(b)",
    "AU29INV": "s29-10(3), tax invoice attribution condition, exceptions in final paragraph",
    "AU29INVEX": "s29-10(3), Commissioner exception",
    "IN16INPUT": "IGST16(2), blocked-credit qualification",
    "SGALL8": "IRAS Conditions you must meet, opening and complete enumerated conditions1-8",
    "SGATTRIB": "Same page, business/nonbusiness use paragraph following condition3"
  },
  "conditions_context": "Do not promise FULL input recovery merely because a service is exported. For EU outside-territory transactions, Article 169(a) requires that deduction would be available if the transaction occurred domestically, and excludes Article 284-exempt transactions; Article 169(c) separately addresses specified exempt financial/insurance transactions with non-EU customers. Mixed use, non-business expenditure, national exclusions and invoice evidence still matter under Articles 173, 176 and 178. Source: [official source]. The country rules below impose their own conditions.",
  "evidence_entry_ids": [
    "AU11A",
    "AU11B",
    "AU11C",
    "AU11D",
    "AU11ENTERPRISE",
    "AU11ENTITLE",
    "AU11PRIVATE",
    "AU11INPUT",
    "AU11EX3",
    "AU11EX4",
    "AU11EX5",
    "AU11PART",
    "AU29INV",
    "AU29INVEX",
    "SGALL8",
    "SGATTRIB",
    "IN16INPUT"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "Comparative referral to the separately stated national credit conditions.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 49,
  "line": 62,
  "original_review_exact_claim": "The country rules below impose their own conditions.",
  "original_review_row_id": 49,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 1: Separate outside scope, zero-rated and exempt",
  "source_keys": [
    "AU",
    "SGINPUT",
    "IN"
  ]
}
```

### 50

| Malta ordinary taxable event/training | 18% standard rate (in words on the page); only after excluding an exemption or Eighth Schedule reduced treatment | https://legislation.mt/getpdf/6ac352947b5e681a8405fbf4 |

```json
{
  "act_articles": {
    "MT18": "Cap406 Article19(1)",
    "MT8": "Cap406 Article19(2), Eighth Schedule qualification"
  },
  "conditions_context": "| Malta ordinary taxable event/training | 18% standard rate (in words on the page); only after excluding an exemption or Eighth Schedule reduced treatment | [official source] |",
  "evidence_entry_ids": [
    "MT18",
    "MT8"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "Ordinary taxable standard-rate hypothetical classification; exemptions and Eighth Schedule treatment are excluded by the case assumptions, not universally denied.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "18%",
    "6",
    "52947",
    "81",
    "405"
  ],
  "id": 50,
  "line": 68,
  "original_review_exact_claim": "| Malta ordinary taxable event/training | 18% standard rate (in words on the page); only after excluding an exemption or Eighth Schedule reduced treatment | https://legislation.mt/getpdf/6ac352947b5e681a8405fbf4 |",
  "original_review_row_id": 50,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Rates used in the conditional cases",
  "source_keys": [
    "MT"
  ]
}
```

### 51

| UK ordinary taxable land survey | 20% standard rate; not an exempt/reduced/zero-rated supply | https://www.gov.uk/vat-rates |

```json
{
  "act_articles": {
    "UKRATE20": "HMRC VAT rates, standard-rate statement",
    "UKSLAND": "Schedule4A paragraph1(1)",
    "UKSSURVEY": "Schedule4A paragraph1(2)(f), professional land services"
  },
  "conditions_context": "| UK ordinary taxable land survey | 20% standard rate; not an exempt/reduced/zero-rated supply | [official source] |",
  "evidence_entry_ids": [
    "UKRATE20",
    "UKSLAND",
    "UKSSURVEY"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "Standard-rate hypothetical assumes no applicable exemption/reduction/zero rating.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "20%"
  ],
  "id": 51,
  "line": 69,
  "original_review_exact_claim": "| UK ordinary taxable land survey | 20% standard rate; not an exempt/reduced/zero-rated supply | https://www.gov.uk/vat-rates |",
  "original_review_row_id": 51,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Rates used in the conditional cases",
  "source_keys": [
    "UKRATE",
    "UKSCH"
  ]
}
```

### 52

| Metropolitan France ordinary taxable service | 20% standard rate; the yoga example still requires its actual exemption/franchise and classification checks | https://www.douane.gouv.fr/fiche/les-taux-de-tva |

```json
{
  "act_articles": {
    "FR20": "DGDDI Les taux de TVA / metropolitan rates / standard-rate explanation",
    "FRRESID": "Same standard-rate explanation, residual taxable scope"
  },
  "conditions_context": "| Metropolitan France ordinary taxable service | 20% standard rate; the yoga example still requires its actual exemption/franchise and classification checks | [official source] |",
  "evidence_entry_ids": [
    "FR20",
    "FRRESID"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "Conditional metropolitan standard-rate pointer, not a clearance of the yoga classification or exemption.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "20%"
  ],
  "id": 52,
  "line": 70,
  "original_review_exact_claim": "| Metropolitan France ordinary taxable service | 20% standard rate; the yoga example still requires its actual exemption/franchise and classification checks | https://www.douane.gouv.fr/fiche/les-taux-de-tva |",
  "original_review_row_id": 52,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Rates used in the conditional cases",
  "source_keys": [
    "FRRATE"
  ]
}
```

### 53

For a taxable customer acting as such, Article 44 locates an ordinary service at the customer's business establishment, or the fixed establishment receiving it, or the fallback permanent address/usual residence.

```json
{
  "act_articles": {
    "EU44ACT": "Article44, first sentence, taxable business-capacity condition",
    "EU44B": "Article 44, first sentence",
    "EU44F": "Article 44, second sentence",
    "EU44R": "Article 44, third sentence",
    "REG21": "Article 21, first/second paragraphs, relevant establishment",
    "REG22": "Article 22(1), identification of receiving establishment",
    "REG22C": "Article 22(1), secondary evidence"
  },
  "conditions_context": "For a taxable customer acting as such, Article 44 locates an ordinary service at the customer's business establishment, or the fixed establishment receiving it, or the fallback permanent address/usual residence. Thus remote business consulting, software development or design supplied to the evidenced US/Japanese establishment is normally outside the seller's EU VAT, subject to the particular rules below and any implemented Article 59a use/enjoyment override. Do not treat a non-EU head-office address as decisive if an EU establishment actually receives the service. Sources: Articles 43-45 and 59a, [official source]; Regulation Articles 18(3), 19 and 20-22, [official source].",
  "evidence_entry_ids": [
    "EU44ACT",
    "EU44B",
    "EU44F",
    "EU44R",
    "REG21",
    "REG22",
    "REG22C"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "44"
  ],
  "id": 53,
  "line": 76,
  "original_review_exact_claim": "For a taxable customer acting as such, Article 44 locates an ordinary service at the customer's business establishment, or the fixed establishment receiving it, or the fallback permanent address/usual residence.",
  "original_review_row_id": 53,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 2: EU seller to a non-EU customer / B2B general rule and evidence",
  "source_keys": [
    "EU",
    "REG"
  ]
}
```

### 54

Thus remote business consulting, software development or design supplied to the evidenced US/Japanese establishment is normally outside the seller's EU VAT, subject to the particular rules below and any implemented Article 59a use/enjoyment override.

```json
{
  "act_articles": {
    "EU44ACT": "Article44, first sentence, taxable business-capacity condition",
    "EU44B": "Article 44, first sentence",
    "EU44F": "Article 44, second sentence",
    "EU44R": "Article 44, third sentence",
    "EU59A": "Article 59a, chapeau and points (a)/(b)",
    "EU59ARANGE": "Article59a, chapeau, listed applicable categories",
    "EU59AU": "Article 59a(a)/(b), effective-use condition",
    "REG21": "Article 21, first/second paragraphs, relevant establishment",
    "REG22": "Article 22(1), identification of receiving establishment",
    "REG22C": "Article 22(1), secondary evidence"
  },
  "conditions_context": "For a taxable customer acting as such, Article 44 locates an ordinary service at the customer's business establishment, or the fixed establishment receiving it, or the fallback permanent address/usual residence. Thus remote business consulting, software development or design supplied to the evidenced US/Japanese establishment is normally outside the seller's EU VAT, subject to the particular rules below and any implemented Article 59a use/enjoyment override. Do not treat a non-EU head-office address as decisive if an EU establishment actually receives the service. Sources: Articles 43-45 and 59a, [official source]; Regulation Articles 18(3), 19 and 20-22, [official source].",
  "evidence_entry_ids": [
    "EU44ACT",
    "EU44B",
    "EU44F",
    "EU44R",
    "REG21",
    "REG22",
    "REG22C",
    "EU59A",
    "EU59ARANGE",
    "EU59AU"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "59"
  ],
  "id": 54,
  "line": 76,
  "original_review_exact_claim": "Thus remote business consulting, software development or design supplied to the evidenced US/Japanese establishment is normally outside the seller's EU VAT, subject to the particular rules below and any implemented Article 59a use/enjoyment override.",
  "original_review_row_id": 54,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 2: EU seller to a non-EU customer / B2B general rule and evidence",
  "source_keys": [
    "EU",
    "REG"
  ]
}
```

### 55

Do not treat a non-EU head-office address as decisive if an EU establishment actually receives the service.

```json
{
  "act_articles": {
    "EU44F": "Article 44, second sentence",
    "REG21": "Article 21, first/second paragraphs, relevant establishment",
    "REG22": "Article 22(1), identification of receiving establishment",
    "REG22C": "Article 22(1), secondary evidence"
  },
  "conditions_context": "For a taxable customer acting as such, Article 44 locates an ordinary service at the customer's business establishment, or the fixed establishment receiving it, or the fallback permanent address/usual residence. Thus remote business consulting, software development or design supplied to the evidenced US/Japanese establishment is normally outside the seller's EU VAT, subject to the particular rules below and any implemented Article 59a use/enjoyment override. Do not treat a non-EU head-office address as decisive if an EU establishment actually receives the service. Sources: Articles 43-45 and 59a, [official source]; Regulation Articles 18(3), 19 and 20-22, [official source].",
  "evidence_entry_ids": [
    "EU44F",
    "REG21",
    "REG22",
    "REG22C"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 55,
  "line": 76,
  "original_review_exact_claim": "Do not treat a non-EU head-office address as decisive if an EU establishment actually receives the service.",
  "original_review_row_id": 55,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 2: EU seller to a non-EU customer / B2B general rule and evidence",
  "source_keys": [
    "EU",
    "REG"
  ]
}
```

### 56

Sources: Articles 43-45 and 59a, [official source]; Regulation Articles 18(3), 19 and 20-22, [official source].

```json
{
  "act_articles": {
    "EU43": "Article 43(2)",
    "EU44ACT": "Article44, first sentence, taxable business-capacity condition",
    "EU44B": "Article 44, first sentence",
    "EU44F": "Article 44, second sentence",
    "EU44R": "Article 44, third sentence",
    "EU45": "Article 45, first sentence",
    "EU59A": "Article 59a, chapeau and points (a)/(b)",
    "EU59AU": "Article 59a(a)/(b), effective-use condition",
    "REG18A": "Article 18(3)(a), non-EU customer certificate",
    "REG18B": "Article 18(3)(b), alternative proof and verification",
    "REG18CONTRARY": "Article18(3), opening safeguard",
    "REG18ID": "Article18(3)(b), identifiers alternative",
    "REG18V": "Article 18(3)(b), verification condition",
    "REG19": "Article 19, first paragraph, private use",
    "REG20": "Article 20, one-country establishment",
    "REG21": "Article 21, first/second paragraphs, relevant establishment",
    "REG22": "Article 22(1), identification of receiving establishment",
    "REG22C": "Article 22(1), secondary evidence"
  },
  "conditions_context": "For a taxable customer acting as such, Article 44 locates an ordinary service at the customer's business establishment, or the fixed establishment receiving it, or the fallback permanent address/usual residence. Thus remote business consulting, software development or design supplied to the evidenced US/Japanese establishment is normally outside the seller's EU VAT, subject to the particular rules below and any implemented Article 59a use/enjoyment override. Do not treat a non-EU head-office address as decisive if an EU establishment actually receives the service. Sources: Articles 43-45 and 59a, [official source]; Regulation Articles 18(3), 19 and 20-22, [official source].",
  "evidence_entry_ids": [
    "EU44ACT",
    "EU44B",
    "EU44F",
    "EU44R",
    "REG21",
    "REG22",
    "REG22C",
    "REG18CONTRARY",
    "REG18A",
    "REG18ID",
    "REG18B",
    "REG18V",
    "REG19",
    "EU43",
    "REG20",
    "EU45",
    "EU59A",
    "EU59AU"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "43",
    "45",
    "59",
    "18(3)",
    "19",
    "20",
    "22,"
  ],
  "id": 56,
  "line": 76,
  "original_review_exact_claim": "Sources: Articles 43-45 and 59a, [official source]; Regulation Articles 18(3), 19 and 20-22, [official source].",
  "original_review_row_id": 56,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 2: EU seller to a non-EU customer / B2B general rule and evidence",
  "source_keys": [
    "EU",
    "REG"
  ]
}
```

### 57

For a non-EU customer, obtain the relevant tax-authority business certificate, or the business tax/similar identifier or other proof plus reasonable commercial verification, unless contrary information exists.

```json
{
  "act_articles": {
    "REG18A": "Article 18(3)(a), non-EU customer certificate",
    "REG18B": "Article 18(3)(b), alternative proof and verification",
    "REG18CONTRARY": "Article18(3), opening safeguard",
    "REG18ID": "Article18(3)(b), identifiers alternative",
    "REG18V": "Article 18(3)(b), verification condition"
  },
  "conditions_context": "For a non-EU customer, obtain the relevant tax-authority business certificate, or the business tax/similar identifier or other proof plus reasonable commercial verification, unless contrary information exists. Exclusively private-use services follow B2C rules even if bought by a business. The EU rules also deem specified non-taxable legal persons identified for VAT to be taxable for place-of-supply purposes; do not equate business status solely with possession of an EU VAT number. Sources: Article 43, [official source]; Regulation Articles 18-19, [official source].",
  "evidence_entry_ids": [
    "REG18CONTRARY",
    "REG18A",
    "REG18ID",
    "REG18B",
    "REG18V"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 57,
  "line": 78,
  "original_review_exact_claim": "For a non-EU customer, obtain the relevant tax-authority business certificate, or the business tax/similar identifier or other proof plus reasonable commercial verification, unless contrary information exists.",
  "original_review_row_id": 57,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 2: EU seller to a non-EU customer / B2B general rule and evidence",
  "source_keys": [
    "REG"
  ]
}
```

### 58

Exclusively private-use services follow B2C rules even if bought by a business.

```json
{
  "act_articles": {
    "REG19": "Article 19, first paragraph, private use"
  },
  "conditions_context": "For a non-EU customer, obtain the relevant tax-authority business certificate, or the business tax/similar identifier or other proof plus reasonable commercial verification, unless contrary information exists. Exclusively private-use services follow B2C rules even if bought by a business. The EU rules also deem specified non-taxable legal persons identified for VAT to be taxable for place-of-supply purposes; do not equate business status solely with possession of an EU VAT number. Sources: Article 43, [official source]; Regulation Articles 18-19, [official source].",
  "evidence_entry_ids": [
    "REG19"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 58,
  "line": 78,
  "original_review_exact_claim": "Exclusively private-use services follow B2C rules even if bought by a business.",
  "original_review_row_id": 58,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 2: EU seller to a non-EU customer / B2B general rule and evidence",
  "source_keys": [
    "REG"
  ]
}
```

### 59

The EU rules also deem specified non-taxable legal persons identified for VAT to be taxable for place-of-supply purposes; do not equate business status solely with possession of an EU VAT number.

```json
{
  "act_articles": {
    "EU43": "Article 43(2)",
    "REG18B": "Article 18(3)(b), alternative proof and verification",
    "REG18ID": "Article18(3)(b), identifiers alternative"
  },
  "conditions_context": "For a non-EU customer, obtain the relevant tax-authority business certificate, or the business tax/similar identifier or other proof plus reasonable commercial verification, unless contrary information exists. Exclusively private-use services follow B2C rules even if bought by a business. The EU rules also deem specified non-taxable legal persons identified for VAT to be taxable for place-of-supply purposes; do not equate business status solely with possession of an EU VAT number. Sources: Article 43, [official source]; Regulation Articles 18-19, [official source].",
  "evidence_entry_ids": [
    "EU43",
    "REG18ID",
    "REG18B"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 59,
  "line": 78,
  "original_review_exact_claim": "The EU rules also deem specified non-taxable legal persons identified for VAT to be taxable for place-of-supply purposes; do not equate business status solely with possession of an EU VAT number.",
  "original_review_row_id": 59,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 2: EU seller to a non-EU customer / B2B general rule and evidence",
  "source_keys": [
    "EU",
    "REG"
  ]
}
```

### 60

Sources: Article 43, [official source]; Regulation Articles 18-19, [official source].

```json
{
  "act_articles": {
    "EU43": "Article 43(2)",
    "REG18A": "Article 18(3)(a), non-EU customer certificate",
    "REG18B": "Article 18(3)(b), alternative proof and verification",
    "REG18CONTRARY": "Article18(3), opening safeguard",
    "REG18ID": "Article18(3)(b), identifiers alternative",
    "REG18V": "Article 18(3)(b), verification condition",
    "REG19": "Article 19, first paragraph, private use"
  },
  "conditions_context": "For a non-EU customer, obtain the relevant tax-authority business certificate, or the business tax/similar identifier or other proof plus reasonable commercial verification, unless contrary information exists. Exclusively private-use services follow B2C rules even if bought by a business. The EU rules also deem specified non-taxable legal persons identified for VAT to be taxable for place-of-supply purposes; do not equate business status solely with possession of an EU VAT number. Sources: Article 43, [official source]; Regulation Articles 18-19, [official source].",
  "evidence_entry_ids": [
    "REG18CONTRARY",
    "REG18A",
    "REG18ID",
    "REG18B",
    "REG18V",
    "REG19",
    "EU43"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "43,",
    "18",
    "19,"
  ],
  "id": 60,
  "line": 78,
  "original_review_exact_claim": "Sources: Article 43, [official source]; Regulation Articles 18-19, [official source].",
  "original_review_row_id": 60,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 2: EU seller to a non-EU customer / B2B general rule and evidence",
  "source_keys": [
    "REG",
    "EU"
  ]
}
```

### 61

Do not describe an Article 44 supply outside the EU as an EU statutory 0% rate.

```json
{
  "act_articles": {
    "EU44B": "Article 44, first sentence"
  },
  "conditions_context": "Do not describe an Article 44 supply outside the EU as an EU statutory 0% rate. A descriptive invoice note such as \"Outside the scope of VAT - place of supply outside the EU\" records the conclusion; it is not a universally prescribed wording. Check the seller's invoice rules, and any destination-country reverse charge. Article 219a determines the applicable invoicing framework and Article 226 includes the required \"Reverse charge\" wording where the customer is liable. Sources: [official source].",
  "evidence_entry_ids": [
    "EU44B"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "Article44 is a location rule, not a statutory0% rate; this is a direct legal distinction.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "44",
    "0%"
  ],
  "id": 61,
  "line": 80,
  "original_review_exact_claim": "Do not describe an Article 44 supply outside the EU as an EU statutory 0% rate.",
  "original_review_row_id": 61,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 2: EU seller to a non-EU customer / B2B general rule and evidence",
  "source_keys": [
    "EU"
  ]
}
```

### 62

A descriptive invoice note such as "Outside the scope of VAT - place of supply outside the EU" records the conclusion; it is not a universally prescribed wording.

```json
{
  "act_articles": {
    "EU219A": "Article 219a(1), invoicing framework",
    "EU219AB": "Article 219a(2)(a)(ii), outside-Community invoice exception",
    "EU226": "Article 226(11a), mandatory wording"
  },
  "conditions_context": "Do not describe an Article 44 supply outside the EU as an EU statutory 0% rate. A descriptive invoice note such as \"Outside the scope of VAT - place of supply outside the EU\" records the conclusion; it is not a universally prescribed wording. Check the seller's invoice rules, and any destination-country reverse charge. Article 219a determines the applicable invoicing framework and Article 226 includes the required \"Reverse charge\" wording where the customer is liable. Sources: [official source].",
  "evidence_entry_ids": [
    "EU219A",
    "EU219AB",
    "EU226"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "The quoted invoice note is expressly author-supplied descriptive text, not purported statutory wording; do not manufacture a native legal extract for that suggested note.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 62,
  "line": 80,
  "original_review_exact_claim": "A descriptive invoice note such as \"Outside the scope of VAT - place of supply outside the EU\" records the conclusion; it is not a universally prescribed wording.",
  "original_review_row_id": 62,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 2: EU seller to a non-EU customer / B2B general rule and evidence",
  "source_keys": [
    "EU"
  ]
}
```

### 63

Check the seller's invoice rules, and any destination-country reverse charge.

```json
{
  "act_articles": {
    "EU219A": "Article 219a(1), invoicing framework",
    "EU219AB": "Article 219a(2)(a)(ii), outside-Community invoice exception",
    "EU226": "Article 226(11a), mandatory wording"
  },
  "conditions_context": "Do not describe an Article 44 supply outside the EU as an EU statutory 0% rate. A descriptive invoice note such as \"Outside the scope of VAT - place of supply outside the EU\" records the conclusion; it is not a universally prescribed wording. Check the seller's invoice rules, and any destination-country reverse charge. Article 219a determines the applicable invoicing framework and Article 226 includes the required \"Reverse charge\" wording where the customer is liable. Sources: [official source].",
  "evidence_entry_ids": [
    "EU219A",
    "EU219AB",
    "EU226"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "Invoice/destination-liability gate, not an assertion that every destination imposes reverse charge.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 63,
  "line": 80,
  "original_review_exact_claim": "Check the seller's invoice rules, and any destination-country reverse charge.",
  "original_review_row_id": 63,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 2: EU seller to a non-EU customer / B2B general rule and evidence",
  "source_keys": [
    "EU"
  ]
}
```

### 64

Article 219a determines the applicable invoicing framework and Article 226 includes the required "Reverse charge" wording where the customer is liable.

```json
{
  "act_articles": {
    "EU219A": "Article 219a(1), invoicing framework",
    "EU219AB": "Article 219a(2)(a)(ii), outside-Community invoice exception",
    "EU226": "Article 226(11a), mandatory wording"
  },
  "conditions_context": "Do not describe an Article 44 supply outside the EU as an EU statutory 0% rate. A descriptive invoice note such as \"Outside the scope of VAT - place of supply outside the EU\" records the conclusion; it is not a universally prescribed wording. Check the seller's invoice rules, and any destination-country reverse charge. Article 219a determines the applicable invoicing framework and Article 226 includes the required \"Reverse charge\" wording where the customer is liable. Sources: [official source].",
  "evidence_entry_ids": [
    "EU219A",
    "EU219AB",
    "EU226"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "219",
    "226"
  ],
  "id": 64,
  "line": 80,
  "original_review_exact_claim": "Article 219a determines the applicable invoicing framework and Article 226 includes the required \"Reverse charge\" wording where the customer is liable.",
  "original_review_row_id": 64,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 2: EU seller to a non-EU customer / B2B general rule and evidence",
  "source_keys": [
    "EU"
  ]
}
```

### 65

Sources: [official source].

```json
{
  "act_articles": {
    "EU219A": "Article 219a(1), invoicing framework",
    "EU219AB": "Article 219a(2)(a)(ii), outside-Community invoice exception",
    "EU226": "Article 226(11a), mandatory wording"
  },
  "conditions_context": "Do not describe an Article 44 supply outside the EU as an EU statutory 0% rate. A descriptive invoice note such as \"Outside the scope of VAT - place of supply outside the EU\" records the conclusion; it is not a universally prescribed wording. Check the seller's invoice rules, and any destination-country reverse charge. Article 219a determines the applicable invoicing framework and Article 226 includes the required \"Reverse charge\" wording where the customer is liable. Sources: [official source].",
  "evidence_entry_ids": [
    "EU219A",
    "EU219AB",
    "EU226"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 65,
  "line": 80,
  "original_review_exact_claim": "Sources: [official source].",
  "original_review_row_id": 65,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 2: EU seller to a non-EU customer / B2B general rule and evidence",
  "source_keys": [
    "EU"
  ]
}
```

### 66

There is no EU recapitulative-statement entry for an ordinary service actually located outside the EU merely because the seller is EU-established.

```json
{
  "act_articles": {
    "EU262": "Article 262(1)(c), recapitulative services",
    "EU262CUST": "Article262(1)(c), persons included",
    "EU262LIAB": "Article262(1)(c), recipient liability"
  },
  "conditions_context": "There is no EU recapitulative-statement entry for an ordinary service actually located outside the EU merely because the seller is EU-established. Article 262 concerns the specified intra-EU transactions, including qualifying Article 196 services. Intrastat concerns goods movements, not these pure service supplies; separate national services-statistics duties may exist. Sources: Article 262, [official source]; the goods-movement distinction in the official 2026 ELSTER instructions, [official source].",
  "evidence_entry_ids": [
    "EU262CUST",
    "EU262",
    "EU262LIAB"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "Negative inference is limited to a service whose actual place is outside the EU; not a blanket exception for every foreign invoice.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 66,
  "line": 82,
  "original_review_exact_claim": "There is no EU recapitulative-statement entry for an ordinary service actually located outside the EU merely because the seller is EU-established.",
  "original_review_row_id": 66,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 2: EU seller to a non-EU customer / B2B general rule and evidence",
  "source_keys": [
    "EU"
  ]
}
```

### 67

Article 262 concerns the specified intra-EU transactions, including qualifying Article 196 services.

```json
{
  "act_articles": {
    "EU196": "Article 196",
    "EU262": "Article 262(1)(c), recapitulative services",
    "EU262CUST": "Article262(1)(c), persons included",
    "EU262LIAB": "Article262(1)(c), recipient liability"
  },
  "conditions_context": "There is no EU recapitulative-statement entry for an ordinary service actually located outside the EU merely because the seller is EU-established. Article 262 concerns the specified intra-EU transactions, including qualifying Article 196 services. Intrastat concerns goods movements, not these pure service supplies; separate national services-statistics duties may exist. Sources: Article 262, [official source]; the goods-movement distinction in the official 2026 ELSTER instructions, [official source].",
  "evidence_entry_ids": [
    "EU262CUST",
    "EU262",
    "EU262LIAB",
    "EU196"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "262",
    "196"
  ],
  "id": 67,
  "line": 82,
  "original_review_exact_claim": "Article 262 concerns the specified intra-EU transactions, including qualifying Article 196 services.",
  "original_review_row_id": 67,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 2: EU seller to a non-EU customer / B2B general rule and evidence",
  "source_keys": [
    "EU"
  ]
}
```

### 68

Intrastat concerns goods movements, not these pure service supplies; separate national services-statistics duties may exist.

```json
{
  "act_articles": {
    "DEGOODS": "ELSTER2026 / Allgemein, Intrahandelsstatistik paragraph"
  },
  "conditions_context": "There is no EU recapitulative-statement entry for an ordinary service actually located outside the EU merely because the seller is EU-established. Article 262 concerns the specified intra-EU transactions, including qualifying Article 196 services. Intrastat concerns goods movements, not these pure service supplies; separate national services-statistics duties may exist. Sources: Article 262, [official source]; the goods-movement distinction in the official 2026 ELSTER instructions, [official source].",
  "evidence_entry_ids": [
    "DEGOODS"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "The first sentence is supported by the official goods-movement distinction. Possible separate services-statistics duties are referred, not asserted as a computed obligation.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 68,
  "line": 82,
  "original_review_exact_claim": "Intrastat concerns goods movements, not these pure service supplies; separate national services-statistics duties may exist.",
  "original_review_row_id": 68,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 2: EU seller to a non-EU customer / B2B general rule and evidence",
  "source_keys": [
    "DEHELP"
  ]
}
```

### 69

Sources: Article 262, [official source]; the goods-movement distinction in the official 2026 ELSTER instructions, [official source].

```json
{
  "act_articles": {
    "DEGOODS": "ELSTER2026 / Allgemein, Intrahandelsstatistik paragraph",
    "EU262": "Article 262(1)(c), recapitulative services",
    "EU262CUST": "Article262(1)(c), persons included",
    "EU262LIAB": "Article262(1)(c), recipient liability"
  },
  "conditions_context": "There is no EU recapitulative-statement entry for an ordinary service actually located outside the EU merely because the seller is EU-established. Article 262 concerns the specified intra-EU transactions, including qualifying Article 196 services. Intrastat concerns goods movements, not these pure service supplies; separate national services-statistics duties may exist. Sources: Article 262, [official source]; the goods-movement distinction in the official 2026 ELSTER instructions, [official source].",
  "evidence_entry_ids": [
    "EU262CUST",
    "EU262",
    "EU262LIAB",
    "DEGOODS"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "262,",
    "2026"
  ],
  "id": 69,
  "line": 82,
  "original_review_exact_claim": "Sources: Article 262, [official source]; the goods-movement distinction in the official 2026 ELSTER instructions, [official source].",
  "original_review_row_id": 69,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 2: EU seller to a non-EU customer / B2B general rule and evidence",
  "source_keys": [
    "EU",
    "DEHELP"
  ]
}
```

### 70

| Consulting, legal, accounting, engineering, advertising, data processing/information; IT only if its actual nature fits a listed category | Article 59 shifts the listed service to the customer's established/permanent/usual location outside the EU; an IT label alone is not enough | https://publications.europa.eu/resource/cellar/03c42d77-512a-11f0-a9d0-01aa75ed71a1.0007.02/DOC_1 |

```json
{
  "act_articles": {
    "EU59": "Article 59, chapeau, non-EU customer qualification",
    "EU59B_AD": "Article59(b)",
    "EU59C": "Article 59(c)"
  },
  "conditions_context": "| Consulting, legal, accounting, engineering, advertising, data processing/information; IT only if its actual nature fits a listed category | Article 59 shifts the listed service to the customer's established/permanent/usual location outside the EU; an IT label alone is not enough | [official source] |",
  "evidence_entry_ids": [
    "EU59",
    "EU59C",
    "EU59B_AD"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "59",
    "03",
    "2",
    "7",
    "512",
    "11",
    "01",
    "5",
    "1",
    "0007.02",
    "1"
  ],
  "id": 70,
  "line": 88,
  "original_review_exact_claim": "| Consulting, legal, accounting, engineering, advertising, data processing/information; IT only if its actual nature fits a listed category | Article 59 shifts the listed service to the customer's established/permanent/usual location outside the EU; an IT label alone is not enough | https://publications.europa.eu/resource/cellar/03c42d77-512a-11f0-a9d0-01aa75ed71a1.0007.02/DOC_1 |",
  "original_review_row_id": 70,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 2: EU seller to a non-EU customer / B2C general rule, listed services and special places",
  "source_keys": [
    "EU"
  ]
}
```

### 71

| Telecommunications, broadcasting or electronically supplied service | Article 58 customer location; email communication alone does not make a human-delivered service electronic; destination-country tax may arise | https://publications.europa.eu/resource/cellar/03c42d77-512a-11f0-a9d0-01aa75ed71a1.0007.02/DOC_1 |

```json
{
  "act_articles": {
    "EU58": "Article 58(1), chapeau",
    "EU58E": "Article 58(1), final subparagraph"
  },
  "conditions_context": "| Telecommunications, broadcasting or electronically supplied service | Article 58 customer location; email communication alone does not make a human-delivered service electronic; destination-country tax may arise | [official source] |",
  "evidence_entry_ids": [
    "EU58",
    "EU58E"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "58",
    "03",
    "2",
    "7",
    "512",
    "11",
    "01",
    "5",
    "1",
    "0007.02",
    "1"
  ],
  "id": 71,
  "line": 89,
  "original_review_exact_claim": "| Telecommunications, broadcasting or electronically supplied service | Article 58 customer location; email communication alone does not make a human-delivered service electronic; destination-country tax may arise | https://publications.europa.eu/resource/cellar/03c42d77-512a-11f0-a9d0-01aa75ed71a1.0007.02/DOC_1 |",
  "original_review_row_id": 71,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 2: EU seller to a non-EU customer / B2C general rule, listed services and special places",
  "source_keys": [
    "EU"
  ]
}
```

### 72

| Property/land-related service | Article 47 property location; establish a sufficiently direct connection, not merely a customer's property interest | https://publications.europa.eu/resource/cellar/03c42d77-512a-11f0-a9d0-01aa75ed71a1.0007.02/DOC_1 ; https://publications.europa.eu/resource/cellar/5bc93f0b-2a93-11f0-8a44-01aa75ed71a1.0006.02/DOC_1 |

```json
{
  "act_articles": {
    "EU47": "Article 47, final operative clause",
    "REG31A": "Article 31a(1), sufficiently direct land connection"
  },
  "conditions_context": "| Property/land-related service | Article 47 property location; establish a sufficiently direct connection, not merely a customer's property interest | [official source] ; [official source] |",
  "evidence_entry_ids": [
    "EU47",
    "REG31A"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "47",
    "03",
    "2",
    "7",
    "512",
    "11",
    "01",
    "5",
    "1",
    "0007.02",
    "1",
    "5",
    "3",
    "2",
    "3",
    "11",
    "8",
    "4",
    "01",
    "5",
    "1",
    "0006.02",
    "1"
  ],
  "id": 72,
  "line": 90,
  "original_review_exact_claim": "| Property/land-related service | Article 47 property location; establish a sufficiently direct connection, not merely a customer's property interest | https://publications.europa.eu/resource/cellar/03c42d77-512a-11f0-a9d0-01aa75ed71a1.0007.02/DOC_1 ; https://publications.europa.eu/resource/cellar/5bc93f0b-2a93-11f0-8a44-01aa75ed71a1.0006.02/DOC_1 |",
  "original_review_row_id": 72,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 2: EU seller to a non-EU customer / B2C general rule, listed services and special places",
  "source_keys": [
    "EU",
    "REG"
  ]
}
```

### 73

| In-person cultural, sporting, educational or similar activity/admission | Article 54 for B2C, where the activity takes place; Article 53 is the B2B admission provision | https://publications.europa.eu/resource/cellar/03c42d77-512a-11f0-a9d0-01aa75ed71a1.0007.02/DOC_1 |

```json
{
  "act_articles": {
    "EU53": "Article 53, first paragraph",
    "EU54": "Article 54(1), first subparagraph"
  },
  "conditions_context": "| In-person cultural, sporting, educational or similar activity/admission | Article 54 for B2C, where the activity takes place; Article 53 is the B2B admission provision | [official source] |",
  "evidence_entry_ids": [
    "EU54",
    "EU53"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "54",
    "53",
    "03",
    "2",
    "7",
    "512",
    "11",
    "01",
    "5",
    "1",
    "0007.02",
    "1"
  ],
  "id": 73,
  "line": 91,
  "original_review_exact_claim": "| In-person cultural, sporting, educational or similar activity/admission | Article 54 for B2C, where the activity takes place; Article 53 is the B2B admission provision | https://publications.europa.eu/resource/cellar/03c42d77-512a-11f0-a9d0-01aa75ed71a1.0007.02/DOC_1 |",
  "original_review_row_id": 73,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 2: EU seller to a non-EU customer / B2C general rule, listed services and special places",
  "source_keys": [
    "EU"
  ]
}
```

### 74

| Streamed or otherwise virtually available B2C activity | Article 54 customer location; virtual B2B admission is excluded from Article 53 and requires the applicable rule, normally Article 44 | https://publications.europa.eu/resource/cellar/03c42d77-512a-11f0-a9d0-01aa75ed71a1.0007.02/DOC_1 |

```json
{
  "act_articles": {
    "EU44ACT": "Article44, first sentence, taxable business-capacity condition",
    "EU44B": "Article 44, first sentence",
    "EU44F": "Article 44, second sentence",
    "EU44R": "Article 44, third sentence",
    "EU53V": "Article 53, second paragraph",
    "EU54V": "Article 54(1), second subparagraph",
    "EU54VC": "Article 54(1), second subparagraph, result",
    "REG21": "Article 21, first/second paragraphs, relevant establishment",
    "REG22": "Article 22(1), identification of receiving establishment",
    "REG22C": "Article 22(1), secondary evidence"
  },
  "conditions_context": "| Streamed or otherwise virtually available B2C activity | Article 54 customer location; virtual B2B admission is excluded from Article 53 and requires the applicable rule, normally Article 44 | [official source] |",
  "evidence_entry_ids": [
    "EU54V",
    "EU54VC",
    "EU53V",
    "EU44ACT",
    "EU44B",
    "EU44F",
    "EU44R",
    "REG21",
    "REG22",
    "REG22C"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "54",
    "53",
    "44",
    "03",
    "2",
    "7",
    "512",
    "11",
    "01",
    "5",
    "1",
    "0007.02",
    "1"
  ],
  "id": 74,
  "line": 92,
  "original_review_exact_claim": "| Streamed or otherwise virtually available B2C activity | Article 54 customer location; virtual B2B admission is excluded from Article 53 and requires the applicable rule, normally Article 44 | https://publications.europa.eu/resource/cellar/03c42d77-512a-11f0-a9d0-01aa75ed71a1.0007.02/DOC_1 |",
  "original_review_row_id": 74,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 2: EU seller to a non-EU customer / B2C general rule, listed services and special places",
  "source_keys": [
    "EU",
    "REG"
  ]
}
```

### 75

| Restaurant/catering | Article 55 physical performance, subject to the specific Article 57 rule for qualifying onboard EU passenger-transport services | https://publications.europa.eu/resource/cellar/03c42d77-512a-11f0-a9d0-01aa75ed71a1.0007.02/DOC_1 |

```json
{
  "act_articles": {
    "EU55": "Article 55, final operative clause",
    "EU57": "Article 57(1), qualifying onboard catering"
  },
  "conditions_context": "| Restaurant/catering | Article 55 physical performance, subject to the specific Article 57 rule for qualifying onboard EU passenger-transport services | [official source] |",
  "evidence_entry_ids": [
    "EU55",
    "EU57"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "55",
    "57",
    "03",
    "2",
    "7",
    "512",
    "11",
    "01",
    "5",
    "1",
    "0007.02",
    "1"
  ],
  "id": 75,
  "line": 93,
  "original_review_exact_claim": "| Restaurant/catering | Article 55 physical performance, subject to the specific Article 57 rule for qualifying onboard EU passenger-transport services | https://publications.europa.eu/resource/cellar/03c42d77-512a-11f0-a9d0-01aa75ed71a1.0007.02/DOC_1 |",
  "original_review_row_id": 75,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 2: EU seller to a non-EU customer / B2C general rule, listed services and special places",
  "source_keys": [
    "EU"
  ]
}
```

### 76

| Passenger transport | Article 48 transport location, proportionate to distances; national exemptions/rates still require checking | https://publications.europa.eu/resource/cellar/03c42d77-512a-11f0-a9d0-01aa75ed71a1.0007.02/DOC_1 |

```json
{
  "act_articles": {
    "EU48": "Article 48"
  },
  "conditions_context": "| Passenger transport | Article 48 transport location, proportionate to distances; national exemptions/rates still require checking | [official source] |",
  "evidence_entry_ids": [
    "EU48"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "National rates/exemptions expressly referred; none is inferred from the distance rule.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "48",
    "03",
    "2",
    "7",
    "512",
    "11",
    "01",
    "5",
    "1",
    "0007.02",
    "1"
  ],
  "id": 76,
  "line": 94,
  "original_review_exact_claim": "| Passenger transport | Article 48 transport location, proportionate to distances; national exemptions/rates still require checking | https://publications.europa.eu/resource/cellar/03c42d77-512a-11f0-a9d0-01aa75ed71a1.0007.02/DOC_1 |",
  "original_review_row_id": 76,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 2: EU seller to a non-EU customer / B2C general rule, listed services and special places",
  "source_keys": [
    "EU"
  ]
}
```

### 77

| Other service with no applicable special rule | Article 45 supplier establishment/fixed-establishment rule; a foreign consumer does not by itself remove domestic VAT | https://publications.europa.eu/resource/cellar/03c42d77-512a-11f0-a9d0-01aa75ed71a1.0007.02/DOC_1 |

```json
{
  "act_articles": {
    "EU45": "Article 45, first sentence",
    "EU45F": "Article 45, second/third sentences"
  },
  "conditions_context": "| Other service with no applicable special rule | Article 45 supplier establishment/fixed-establishment rule; a foreign consumer does not by itself remove domestic VAT | [official source] |",
  "evidence_entry_ids": [
    "EU45",
    "EU45F"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "45",
    "03",
    "2",
    "7",
    "512",
    "11",
    "01",
    "5",
    "1",
    "0007.02",
    "1"
  ],
  "id": 77,
  "line": 95,
  "original_review_exact_claim": "| Other service with no applicable special rule | Article 45 supplier establishment/fixed-establishment rule; a foreign consumer does not by itself remove domestic VAT | https://publications.europa.eu/resource/cellar/03c42d77-512a-11f0-a9d0-01aa75ed71a1.0007.02/DOC_1 |",
  "original_review_row_id": 77,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 2: EU seller to a non-EU customer / B2C general rule, listed services and special places",
  "source_keys": [
    "EU"
  ]
}
```

### 78

Article 59 also includes specified rights/licences, obligations to refrain, financial/insurance services, staff, movable-property hire except transport, and energy-network services.

```json
{
  "act_articles": {
    "EU59A_RIGHT": "Article59(a)",
    "EU59D_REFRAIN": "Article59(d)",
    "EU59E_FIN": "Article59(e)",
    "EU59F_STAFF": "Article59(f)",
    "EU59H_ENERGY": "Article59(h)",
    "EU59OTH": "Article 59(a)-(h), other categories; extract from (g)"
  },
  "conditions_context": "Article 59 also includes specified rights/licences, obligations to refrain, financial/insurance services, staff, movable-property hire except transport, and energy-network services. Identify the actual category and relevant exclusion; do not limit the article to the professional examples above or treat every service as listed. Member-State Article 59a implementation can change the result where effective use/enjoyment differs. Source: [official source].",
  "evidence_entry_ids": [
    "EU59A_RIGHT",
    "EU59D_REFRAIN",
    "EU59E_FIN",
    "EU59F_STAFF",
    "EU59OTH",
    "EU59H_ENERGY"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "59"
  ],
  "id": 78,
  "line": 97,
  "original_review_exact_claim": "Article 59 also includes specified rights/licences, obligations to refrain, financial/insurance services, staff, movable-property hire except transport, and energy-network services.",
  "original_review_row_id": 78,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 2: EU seller to a non-EU customer / B2C general rule, listed services and special places",
  "source_keys": [
    "EU"
  ]
}
```

### 79

Identify the actual category and relevant exclusion; do not limit the article to the professional examples above or treat every service as listed.

```json
{
  "act_articles": {
    "EU59": "Article 59, chapeau, non-EU customer qualification",
    "EU59A_RIGHT": "Article59(a)",
    "EU59B_AD": "Article59(b)",
    "EU59C": "Article 59(c)",
    "EU59D_REFRAIN": "Article59(d)",
    "EU59E_FIN": "Article59(e)",
    "EU59F_STAFF": "Article59(f)",
    "EU59H_ENERGY": "Article59(h)",
    "EU59OTH": "Article 59(a)-(h), other categories; extract from (g)"
  },
  "conditions_context": "Article 59 also includes specified rights/licences, obligations to refrain, financial/insurance services, staff, movable-property hire except transport, and energy-network services. Identify the actual category and relevant exclusion; do not limit the article to the professional examples above or treat every service as listed. Member-State Article 59a implementation can change the result where effective use/enjoyment differs. Source: [official source].",
  "evidence_entry_ids": [
    "EU59",
    "EU59A_RIGHT",
    "EU59D_REFRAIN",
    "EU59E_FIN",
    "EU59F_STAFF",
    "EU59OTH",
    "EU59H_ENERGY",
    "EU59C",
    "EU59B_AD"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 79,
  "line": 97,
  "original_review_exact_claim": "Identify the actual category and relevant exclusion; do not limit the article to the professional examples above or treat every service as listed.",
  "original_review_row_id": 79,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 2: EU seller to a non-EU customer / B2C general rule, listed services and special places",
  "source_keys": [
    "EU"
  ]
}
```

### 80

Member-State Article 59a implementation can change the result where effective use/enjoyment differs.

```json
{
  "act_articles": {
    "EU59A": "Article 59a, chapeau and points (a)/(b)",
    "EU59ARANGE": "Article59a, chapeau, listed applicable categories",
    "EU59AU": "Article 59a(a)/(b), effective-use condition"
  },
  "conditions_context": "Article 59 also includes specified rights/licences, obligations to refrain, financial/insurance services, staff, movable-property hire except transport, and energy-network services. Identify the actual category and relevant exclusion; do not limit the article to the professional examples above or treat every service as listed. Member-State Article 59a implementation can change the result where effective use/enjoyment differs. Source: [official source].",
  "evidence_entry_ids": [
    "EU59A",
    "EU59ARANGE",
    "EU59AU"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "59"
  ],
  "id": 80,
  "line": 97,
  "original_review_exact_claim": "Member-State Article 59a implementation can change the result where effective use/enjoyment differs.",
  "original_review_row_id": 80,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 2: EU seller to a non-EU customer / B2C general rule, listed services and special places",
  "source_keys": [
    "EU"
  ]
}
```

### 81

Source: [official source].

```json
{
  "act_articles": {
    "EU59": "Article 59, chapeau, non-EU customer qualification",
    "EU59A": "Article 59a, chapeau and points (a)/(b)",
    "EU59ARANGE": "Article59a, chapeau, listed applicable categories",
    "EU59AU": "Article 59a(a)/(b), effective-use condition",
    "EU59A_RIGHT": "Article59(a)",
    "EU59D_REFRAIN": "Article59(d)",
    "EU59E_FIN": "Article59(e)",
    "EU59F_STAFF": "Article59(f)",
    "EU59H_ENERGY": "Article59(h)",
    "EU59OTH": "Article 59(a)-(h), other categories; extract from (g)"
  },
  "conditions_context": "Article 59 also includes specified rights/licences, obligations to refrain, financial/insurance services, staff, movable-property hire except transport, and energy-network services. Identify the actual category and relevant exclusion; do not limit the article to the professional examples above or treat every service as listed. Member-State Article 59a implementation can change the result where effective use/enjoyment differs. Source: [official source].",
  "evidence_entry_ids": [
    "EU59",
    "EU59A_RIGHT",
    "EU59D_REFRAIN",
    "EU59E_FIN",
    "EU59F_STAFF",
    "EU59OTH",
    "EU59H_ENERGY",
    "EU59A",
    "EU59ARANGE",
    "EU59AU"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 81,
  "line": 97,
  "original_review_exact_claim": "Source: [official source].",
  "original_review_row_id": 81,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 2: EU seller to a non-EU customer / B2C general rule, listed services and special places",
  "source_keys": [
    "EU"
  ]
}
```

### 82

| Malta | Former "Box 2 = non-EU supplies" is not confirmed for the current return and registration regime. Do not populate it from this Guide | Not yet confirmed: actual applicable MTCA form/portal field |

```json
{
  "act_articles": {},
  "conditions_context": "| Malta | Former \"Box 2 = non-EU supplies\" is not confirmed for the current return and registration regime. Do not populate it from this Guide | Not yet confirmed: actual applicable MTCA form/portal field |",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": "Unconfirmed current MTCA box: no positive legal/return claim to support. Preserve reservation; do not quote Article19 as proof of a return field.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "2"
  ],
  "id": 82,
  "line": 103,
  "original_review_exact_claim": "| Malta | Former \"Box 2 = non-EU supplies\" is not confirmed for the current return and registration regime. Do not populate it from this Guide | Not yet confirmed: actual applicable MTCA form/portal field |",
  "original_review_row_id": 82,
  "quotation_gaps": [],
  "result_boundary": "Reserved assertion or correction; not a usable old filing figure",
  "section": "Quick reference / The method, step by step / Step 2: EU seller to a non-EU customer / EU return mappings: original claims checked separately",
  "source_keys": [
    "POLICY"
  ]
}
```

### 83

| Germany | Ordinary foreign-place services taxable if supplied domestically: 2026 UStVA row 36, KZ 45, excluding items belonging in rows 33-35 and stated domestic exceptions. Do not confuse it with qualifying intra-EU services in row 35/KZ 21 | 2026 official form/instructions https://www.bundesfinanzministerium.de/Content/DE/Downloads/BMF_Schreiben/Steuerarten/Umsatzsteuer/2025-12-29-vordruckmuster-USt-voranmeldung-2026.pdf?__blob=publicationFile&v=7 ; https://www.elster.de/eportal/helpGlobal?themaGlobal=help_ustva_2026 |

```json
{
  "act_articles": {
    "DE21": "Same form, row35/KZ21",
    "DE45": "2026UStVA form PDFpage5, row36/KZ45",
    "DEEXROWS": "Same section, rows33-35 exclusion",
    "DEFOREIGN": "ELSTER2026 / Übrige nicht steuerbare Umsätze, first paragraph",
    "DETAXABLE": "Same paragraph, domestic-taxability condition"
  },
  "conditions_context": "| Germany | Ordinary foreign-place services taxable if supplied domestically: 2026 UStVA row 36, KZ 45, excluding items belonging in rows 33-35 and stated domestic exceptions. Do not confuse it with qualifying intra-EU services in row 35/KZ 21 | 2026 official form/instructions [official source] ; [official source] |",
  "evidence_entry_ids": [
    "DE45",
    "DE21",
    "DEFOREIGN",
    "DETAXABLE",
    "DEEXROWS"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "2026",
    "36,",
    "45,",
    "33",
    "35",
    "35",
    "21",
    "2026",
    "2025",
    "12",
    "29",
    "2026.",
    "7",
    "2026"
  ],
  "id": 83,
  "line": 104,
  "original_review_exact_claim": "| Germany | Ordinary foreign-place services taxable if supplied domestically: 2026 UStVA row 36, KZ 45, excluding items belonging in rows 33-35 and stated domestic exceptions. Do not confuse it with qualifying intra-EU services in row 35/KZ 21 | 2026 official form/instructions https://www.bundesfinanzministerium.de/Content/DE/Downloads/BMF_Schreiben/Steuerarten/Umsatzsteuer/2025-12-29-vordruckmuster-USt-voranmeldung-2026.pdf?__blob=publicationFile&v=7 ; https://www.elster.de/eportal/helpGlobal?themaGlobal=help_ustva_2026 |",
  "original_review_row_id": 83,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 2: EU seller to a non-EU customer / EU return mappings: original claims checked separately",
  "source_keys": [
    "DE",
    "DEHELP"
  ]
}
```

### 84

| France | Ordinary non-taxable foreign-place services belong in CA3 E2, not the old E1 export-goods shortcut; the notice includes services to a foreign-established customer even if taxed there | 2026 CA3 notice E1/E2, https://www.impots.gouv.fr/sites/default/files/formulaires/3310-ca3-sd/2026/3310-ca3-sd_5426.pdf |

```json
{
  "act_articles": {
    "FRE2": "CA3notice2026 PDFpage6, LigneE2, final bullet"
  },
  "conditions_context": "| France | Ordinary non-taxable foreign-place services belong in CA3 E2, not the old E1 export-goods shortcut; the notice includes services to a foreign-established customer even if taxed there | 2026 CA3 notice E1/E2, [official source] |",
  "evidence_entry_ids": [
    "FRE2"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "2026",
    "3310",
    "2026",
    "3310",
    "5426."
  ],
  "id": 84,
  "line": 105,
  "original_review_exact_claim": "| France | Ordinary non-taxable foreign-place services belong in CA3 E2, not the old E1 export-goods shortcut; the notice includes services to a foreign-established customer even if taxed there | 2026 CA3 notice E1/E2, https://www.impots.gouv.fr/sites/default/files/formulaires/3310-ca3-sd/2026/3310-ca3-sd_5426.pdf |",
  "original_review_row_id": 84,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 2: EU seller to a non-EU customer / EU return mappings: original claims checked separately",
  "source_keys": [
    "FR"
  ]
}
```

### 85

| Italy | Former "VE30 field 4 / Esterometro" is not a usable current service-export mapping. Annual IVA 2026 is for tax period 2025: its VE34 covers qualifying outside-territory invoiced transactions. That is 2025-2026 filing-cycle evidence, not the annual form for 2026 transactions | IVA 2026 cover/VE34 instructions, https://www.agenziaentrate.gov.it/portale/documents/20143/9602686/IVA_ANNUALE_2026_istr.pdf/2a42fb92-1b76-229a-d0f5-06069d79b514?t=1768504755711 ; current 2026-transaction annual/e-invoicing fields not yet confirmed |

```json
{
  "act_articles": {
    "ITCYCLE": "IVA2026 cover",
    "ITINVOICE": "Same VE34 first sentence, invoice condition",
    "ITVE34": "IVA2026 instructions RigoVE34, first sentence"
  },
  "conditions_context": "| Italy | Former \"VE30 field 4 / Esterometro\" is not a usable current service-export mapping. Annual IVA 2026 is for tax period 2025: its VE34 covers qualifying outside-territory invoiced transactions. That is 2025-2026 filing-cycle evidence, not the annual form for 2026 transactions | IVA 2026 cover/VE34 instructions, [official source] ; current 2026-transaction annual/e-invoicing fields not yet confirmed |",
  "evidence_entry_ids": [
    "ITCYCLE",
    "ITVE34",
    "ITINVOICE"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "Former VE30/Esterometro mapping and 2026-transaction annual/e-invoicing fields remain reserved. Do not turn 2025-period IVA2026 into a current2026 transaction-form claim.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "0",
    "4",
    "2026",
    "2025",
    "4",
    "2025",
    "2026",
    "2026",
    "2026",
    "4",
    "20143",
    "9602686",
    "2026",
    "2",
    "2",
    "2",
    "1",
    "6",
    "229",
    "06069",
    "9",
    "14",
    "1768504755711",
    "2026"
  ],
  "id": 85,
  "line": 106,
  "original_review_exact_claim": "| Italy | Former \"VE30 field 4 / Esterometro\" is not a usable current service-export mapping. Annual IVA 2026 is for tax period 2025: its VE34 covers qualifying outside-territory invoiced transactions. That is 2025-2026 filing-cycle evidence, not the annual form for 2026 transactions | IVA 2026 cover/VE34 instructions, https://www.agenziaentrate.gov.it/portale/documents/20143/9602686/IVA_ANNUALE_2026_istr.pdf/2a42fb92-1b76-229a-d0f5-06069d79b514?t=1768504755711 ; current 2026-transaction annual/e-invoicing fields not yet confirmed |",
  "original_review_row_id": 85,
  "quotation_gaps": [],
  "result_boundary": "Reserved assertion or correction; not a usable old filing figure",
  "section": "Quick reference / The method, step by step / Step 2: EU seller to a non-EU customer / EU return mappings: original claims checked separately",
  "source_keys": [
    "IT"
  ]
}
```

### 86

| Slovakia | Do not use old row 15 for an ordinary service whose place is outside Slovakia: the authority says foreign-place transactions are omitted from the domestic VAT return. Other records/reporting must be assessed separately | Current PFS return instructions, https://www.financnasprava.sk/sk/podnikatelia/dane/dan-z-pridanej-hodnoty/danove-priznanie |

```json
{
  "act_articles": {
    "SKOMIT": "PFS Danove priznanie / Daňové priznanie, foreign-place sentence"
  },
  "conditions_context": "| Slovakia | Do not use old row 15 for an ordinary service whose place is outside Slovakia: the authority says foreign-place transactions are omitted from the domestic VAT return. Other records/reporting must be assessed separately | Current PFS return instructions, [official source] |",
  "evidence_entry_ids": [
    "SKOMIT"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "15"
  ],
  "id": 86,
  "line": 107,
  "original_review_exact_claim": "| Slovakia | Do not use old row 15 for an ordinary service whose place is outside Slovakia: the authority says foreign-place transactions are omitted from the domestic VAT return. Other records/reporting must be assessed separately | Current PFS return instructions, https://www.financnasprava.sk/sk/podnikatelia/dane/dan-z-pridanej-hodnoty/danove-priznanie |",
  "original_review_row_id": 86,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 2: EU seller to a non-EU customer / EU return mappings: original claims checked separately",
  "source_keys": [
    "SK"
  ]
}
```

### 87

For services, Northern Ireland uses UK place rules and the Isle of Man is treated as part of the UK VAT territory; establish the actual VAT jurisdiction rather than postal geography.

```json
{
  "act_articles": {
    "UKIOM": "Notice741A2.5, first paragraph, Isle of Man sentence",
    "UKNI": "Notice741A2.5, Northern Ireland Protocol paragraph"
  },
  "conditions_context": "For services, Northern Ireland uses UK place rules and the Isle of Man is treated as part of the UK VAT territory; establish the actual VAT jurisdiction rather than postal geography. Source: Notice 741A section 2.5, [official source].",
  "evidence_entry_ids": [
    "UKNI",
    "UKIOM"
  ],
  "evidence_format_status": "CURRENT_SHORT_EXTRACT_STANDARD_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "historical_format_status": "HOLD_EXPLICIT_EXTRACT_GAP",
  "historical_quotation_gaps": [
    "UKIOM"
  ],
  "id": 87,
  "line": 111,
  "original_review_exact_claim": "For services, Northern Ireland uses UK place rules and the Isle of Man is treated as part of the UK VAT territory; establish the actual VAT jurisdiction rather than postal geography.",
  "original_review_row_id": 87,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 3: UK seller to a non-UK customer",
  "source_keys": [
    "UK"
  ]
}
```

### 88

Source: Notice 741A section 2.5, [official source].

```json
{
  "act_articles": {
    "UKIOM": "Notice741A2.5, first paragraph, Isle of Man sentence",
    "UKNI": "Notice741A2.5, Northern Ireland Protocol paragraph"
  },
  "conditions_context": "For services, Northern Ireland uses UK place rules and the Isle of Man is treated as part of the UK VAT territory; establish the actual VAT jurisdiction rather than postal geography. Source: Notice 741A section 2.5, [official source].",
  "evidence_entry_ids": [
    "UKNI",
    "UKIOM"
  ],
  "evidence_format_status": "CURRENT_SHORT_EXTRACT_STANDARD_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "741",
    "2.5,"
  ],
  "historical_format_status": "HOLD_EXPLICIT_EXTRACT_GAP",
  "historical_quotation_gaps": [
    "UKIOM"
  ],
  "id": 88,
  "line": 111,
  "original_review_exact_claim": "Source: Notice 741A section 2.5, [official source].",
  "original_review_row_id": 88,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 3: UK seller to a non-UK customer",
  "source_keys": [
    "UK"
  ]
}
```

### 89

The B2B general rule is VATA section 7A(2)(a), **not the former section 7(10) citation**.

```json
{
  "act_articles": {
    "UKL2A": "VATA1994 section 7A(2)(a)"
  },
  "conditions_context": "The B2B general rule is VATA section 7A(2)(a), **not the former section 7(10) citation**. It places the service where the relevant business recipient belongs, subject to Schedule 4A exceptions. For an ordinary business-use service received by the Australian establishment, do not charge UK VAT; preserve business/location evidence and explain \"Outside the scope of UK VAT\" as descriptive wording. Sources: [official source]; Notice 741A sections 2-4 and 6, [official source].",
  "evidence_entry_ids": [
    "UKL2A"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "7",
    "2",
    "7(10)"
  ],
  "id": 89,
  "line": 113,
  "original_review_exact_claim": "The B2B general rule is VATA section 7A(2)(a), **not the former section 7(10) citation**.",
  "original_review_row_id": 89,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 3: UK seller to a non-UK customer",
  "source_keys": [
    "UKLAW"
  ]
}
```

### 90

It places the service where the relevant business recipient belongs, subject to Schedule 4A exceptions.

```json
{
  "act_articles": {
    "UKL2A": "VATA1994 section 7A(2)(a)",
    "UKL4": "VATA1994 section 7A(4)(a)/(b)",
    "UKL5": "VATA1994 section 7A(5)"
  },
  "conditions_context": "The B2B general rule is VATA section 7A(2)(a), **not the former section 7(10) citation**. It places the service where the relevant business recipient belongs, subject to Schedule 4A exceptions. For an ordinary business-use service received by the Australian establishment, do not charge UK VAT; preserve business/location evidence and explain \"Outside the scope of UK VAT\" as descriptive wording. Sources: [official source]; Notice 741A sections 2-4 and 6, [official source].",
  "evidence_entry_ids": [
    "UKL2A",
    "UKL4",
    "UKL5"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "4"
  ],
  "id": 90,
  "line": 113,
  "original_review_exact_claim": "It places the service where the relevant business recipient belongs, subject to Schedule 4A exceptions.",
  "original_review_row_id": 90,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 3: UK seller to a non-UK customer",
  "source_keys": [
    "UKLAW"
  ]
}
```

### 91

For an ordinary business-use service received by the Australian establishment, do not charge UK VAT; preserve business/location evidence and explain "Outside the scope of UK VAT" as descriptive wording.

```json
{
  "act_articles": {
    "UKBELONG": "Notice741A sections3-4 and6, customer business/status/belonging evidence and relevant establishment",
    "UKL2A": "VATA1994 section 7A(2)(a)",
    "UKL4": "VATA1994 section 7A(4)(a)/(b)",
    "UKL5": "VATA1994 section 7A(5)"
  },
  "conditions_context": "The B2B general rule is VATA section 7A(2)(a), **not the former section 7(10) citation**. It places the service where the relevant business recipient belongs, subject to Schedule 4A exceptions. For an ordinary business-use service received by the Australian establishment, do not charge UK VAT; preserve business/location evidence and explain \"Outside the scope of UK VAT\" as descriptive wording. Sources: [official source]; Notice 741A sections 2-4 and 6, [official source].",
  "evidence_entry_ids": [
    "UKL2A",
    "UKL4",
    "UKL5",
    "UKBELONG"
  ],
  "evidence_format_status": "CURRENT_SHORT_EXTRACT_STANDARD_APPLICABLE",
  "evidence_recommendation_note": "Australian receiving establishment and no special rule are assumed/proved case facts; invoice phrase is descriptive, not statutory.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "historical_format_status": "HOLD_EXPLICIT_EXTRACT_GAP",
  "historical_quotation_gaps": [
    "UKBELONG"
  ],
  "id": 91,
  "line": 113,
  "original_review_exact_claim": "For an ordinary business-use service received by the Australian establishment, do not charge UK VAT; preserve business/location evidence and explain \"Outside the scope of UK VAT\" as descriptive wording.",
  "original_review_row_id": 91,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 3: UK seller to a non-UK customer",
  "source_keys": [
    "UKLAW",
    "UK"
  ]
}
```

### 92

Sources: [official source]; Notice 741A sections 2-4 and 6, [official source].

```json
{
  "act_articles": {
    "UKBELONG": "Notice741A sections3-4 and6, customer business/status/belonging evidence and relevant establishment",
    "UKL2A": "VATA1994 section 7A(2)(a)",
    "UKL4": "VATA1994 section 7A(4)(a)/(b)",
    "UKL5": "VATA1994 section 7A(5)"
  },
  "conditions_context": "The B2B general rule is VATA section 7A(2)(a), **not the former section 7(10) citation**. It places the service where the relevant business recipient belongs, subject to Schedule 4A exceptions. For an ordinary business-use service received by the Australian establishment, do not charge UK VAT; preserve business/location evidence and explain \"Outside the scope of UK VAT\" as descriptive wording. Sources: [official source]; Notice 741A sections 2-4 and 6, [official source].",
  "evidence_entry_ids": [
    "UKL2A",
    "UKL4",
    "UKL5",
    "UKBELONG"
  ],
  "evidence_format_status": "CURRENT_SHORT_EXTRACT_STANDARD_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "741",
    "2",
    "4",
    "6,"
  ],
  "historical_format_status": "HOLD_EXPLICIT_EXTRACT_GAP",
  "historical_quotation_gaps": [
    "UKBELONG"
  ],
  "id": 92,
  "line": 113,
  "original_review_exact_claim": "Sources: [official source]; Notice 741A sections 2-4 and 6, [official source].",
  "original_review_row_id": 92,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 3: UK seller to a non-UK customer",
  "source_keys": [
    "UKLAW",
    "UK"
  ]
}
```

### 93

UK input tax on supplies outside the UK is recoverable subject to the normal rules where the service would be taxable if made in the UK; certain specified exempt supplies have separate relief.

```json
{
  "act_articles": {
    "UKINPUT1": "Notice741A2.7, outside-UK taxable-if-domestic bullet",
    "UKINPUT2": "Notice741A2.7, opening qualification",
    "UKSPEC": "Notice741A2.7, specified exempt-supplies relief bullet"
  },
  "conditions_context": "UK input tax on supplies outside the UK is recoverable subject to the normal rules where the service would be taxable if made in the UK; certain specified exempt supplies have separate relief. Do not promise full recovery of all costs. Source: Notice 741A section 2.7, [official source].",
  "evidence_entry_ids": [
    "UKINPUT1",
    "UKINPUT2",
    "UKSPEC"
  ],
  "evidence_format_status": "CURRENT_SHORT_EXTRACT_STANDARD_APPLICABLE",
  "evidence_recommendation_note": "Exact quoted limb supports outside-UK taxable-if-domestic recovery, with normal-rule qualification. Specified exempt-supplies relief is expressly a separate route and not computed; its fuller extract is quotation-restricted (see UKSPEC gap).",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "historical_format_status": "HOLD_EXPLICIT_EXTRACT_GAP",
  "historical_quotation_gaps": [
    "UKSPEC"
  ],
  "id": 93,
  "line": 115,
  "original_review_exact_claim": "UK input tax on supplies outside the UK is recoverable subject to the normal rules where the service would be taxable if made in the UK; certain specified exempt supplies have separate relief.",
  "original_review_row_id": 93,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 3: UK seller to a non-UK customer",
  "source_keys": [
    "UK"
  ]
}
```

### 94

Do not promise full recovery of all costs.

```json
{
  "act_articles": {
    "UKINPUT1": "Notice741A2.7, outside-UK taxable-if-domestic bullet",
    "UKINPUT2": "Notice741A2.7, opening qualification"
  },
  "conditions_context": "UK input tax on supplies outside the UK is recoverable subject to the normal rules where the service would be taxable if made in the UK; certain specified exempt supplies have separate relief. Do not promise full recovery of all costs. Source: Notice 741A section 2.7, [official source].",
  "evidence_entry_ids": [
    "UKINPUT1",
    "UKINPUT2"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 94,
  "line": 115,
  "original_review_exact_claim": "Do not promise full recovery of all costs.",
  "original_review_row_id": 94,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 3: UK seller to a non-UK customer",
  "source_keys": [
    "UK"
  ]
}
```

### 95

Source: Notice 741A section 2.7, [official source].

```json
{
  "act_articles": {
    "UKINPUT1": "Notice741A2.7, outside-UK taxable-if-domestic bullet",
    "UKINPUT2": "Notice741A2.7, opening qualification",
    "UKSPEC": "Notice741A2.7, specified exempt-supplies relief bullet"
  },
  "conditions_context": "UK input tax on supplies outside the UK is recoverable subject to the normal rules where the service would be taxable if made in the UK; certain specified exempt supplies have separate relief. Do not promise full recovery of all costs. Source: Notice 741A section 2.7, [official source].",
  "evidence_entry_ids": [
    "UKINPUT1",
    "UKINPUT2",
    "UKSPEC"
  ],
  "evidence_format_status": "CURRENT_SHORT_EXTRACT_STANDARD_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "741",
    "2.7,"
  ],
  "historical_format_status": "HOLD_EXPLICIT_EXTRACT_GAP",
  "historical_quotation_gaps": [
    "UKSPEC"
  ],
  "id": 95,
  "line": 115,
  "original_review_exact_claim": "Source: Notice 741A section 2.7, [official source].",
  "original_review_row_id": 95,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 3: UK seller to a non-UK customer",
  "source_keys": [
    "UK"
  ]
}
```

### 96

For B2C, apply section 7A(2)(b) unless Schedule 4A changes it.

```json
{
  "act_articles": {
    "UKL2B": "VATA1994 section 7A(2)(b)",
    "UKL5": "VATA1994 section 7A(5)"
  },
  "conditions_context": "For B2C, apply section 7A(2)(b) unless Schedule 4A changes it. Listed professional/intangible services to a customer belonging outside the UK shift to that customer under Schedule 4A paragraph 16; ordinary unlisted services remain under the supplier rule, subject to the particular performance/property rules. Classify actual IT/consulting rather than the supplier's qualification. Digital/telecoms/broadcasting customer-location rules and the specified use/enjoyment categories need separate checks. The UK use/enjoyment rule is not a universal anti-avoidance test for every service. Sources: [official source]; Notice 741A sections 6-14, [official source].",
  "evidence_entry_ids": [
    "UKL2B",
    "UKL5"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "7",
    "2",
    "4"
  ],
  "id": 96,
  "line": 117,
  "original_review_exact_claim": "For B2C, apply section 7A(2)(b) unless Schedule 4A changes it.",
  "original_review_row_id": 96,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 3: UK seller to a non-UK customer",
  "source_keys": [
    "UKLAW"
  ]
}
```

### 97

Listed professional/intangible services to a customer belonging outside the UK shift to that customer under Schedule 4A paragraph 16; ordinary unlisted services remain under the supplier rule, subject to the particular performance/property rules.

```json
{
  "act_articles": {
    "UKL2B": "VATA1994 section 7A(2)(b)",
    "UKL5": "VATA1994 section 7A(5)",
    "UKSACT": "Schedule4A paragraph14A(1)-(2), nonbusiness-person activity",
    "UKSB2C": "Schedule4A paragraph16(1), qualifying non-UK consumer",
    "UKSLAND": "Schedule4A paragraph1(1)",
    "UKSOUTCUST": "Schedule4A paragraph16(1)(a)-(b), location qualification",
    "UKSPROF": "Schedule4A paragraph16(2)(d), listed professional/data services",
    "UKSPROFEX": "Schedule4A paragraph16(2)(d), land exclusion"
  },
  "conditions_context": "For B2C, apply section 7A(2)(b) unless Schedule 4A changes it. Listed professional/intangible services to a customer belonging outside the UK shift to that customer under Schedule 4A paragraph 16; ordinary unlisted services remain under the supplier rule, subject to the particular performance/property rules. Classify actual IT/consulting rather than the supplier's qualification. Digital/telecoms/broadcasting customer-location rules and the specified use/enjoyment categories need separate checks. The UK use/enjoyment rule is not a universal anti-avoidance test for every service. Sources: [official source]; Notice 741A sections 6-14, [official source].",
  "evidence_entry_ids": [
    "UKSOUTCUST",
    "UKSB2C",
    "UKSPROF",
    "UKSPROFEX",
    "UKL2B",
    "UKL5",
    "UKSACT",
    "UKSLAND"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "4",
    "16"
  ],
  "id": 97,
  "line": 117,
  "original_review_exact_claim": "Listed professional/intangible services to a customer belonging outside the UK shift to that customer under Schedule 4A paragraph 16; ordinary unlisted services remain under the supplier rule, subject to the particular performance/property rules.",
  "original_review_row_id": 97,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 3: UK seller to a non-UK customer",
  "source_keys": [
    "UKSCH",
    "UKLAW"
  ]
}
```

### 98

Classify actual IT/consulting rather than the supplier's qualification.

```json
{
  "act_articles": {
    "UKSPROF": "Schedule4A paragraph16(2)(d), listed professional/data services",
    "UKSPROFEX": "Schedule4A paragraph16(2)(d), land exclusion"
  },
  "conditions_context": "For B2C, apply section 7A(2)(b) unless Schedule 4A changes it. Listed professional/intangible services to a customer belonging outside the UK shift to that customer under Schedule 4A paragraph 16; ordinary unlisted services remain under the supplier rule, subject to the particular performance/property rules. Classify actual IT/consulting rather than the supplier's qualification. Digital/telecoms/broadcasting customer-location rules and the specified use/enjoyment categories need separate checks. The UK use/enjoyment rule is not a universal anti-avoidance test for every service. Sources: [official source]; Notice 741A sections 6-14, [official source].",
  "evidence_entry_ids": [
    "UKSPROF",
    "UKSPROFEX"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "Classification workflow follows actual listed service nature, not a claim about professional licensing.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 98,
  "line": 117,
  "original_review_exact_claim": "Classify actual IT/consulting rather than the supplier's qualification.",
  "original_review_row_id": 98,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 3: UK seller to a non-UK customer",
  "source_keys": [
    "UKSCH"
  ]
}
```

### 99

Digital/telecoms/broadcasting customer-location rules and the specified use/enjoyment categories need separate checks.

```json
{
  "act_articles": {
    "UKSDIGITAL": "Schedule4A paragraph15(1), B2C digital/telecom/broadcast",
    "UKSUE": "Schedule4A paragraphs3(3)-(4),7(1)-(2),8(3)-(4),9(1)-(2),9D(2)-(3),9E(3)-(4), specified categories"
  },
  "conditions_context": "For B2C, apply section 7A(2)(b) unless Schedule 4A changes it. Listed professional/intangible services to a customer belonging outside the UK shift to that customer under Schedule 4A paragraph 16; ordinary unlisted services remain under the supplier rule, subject to the particular performance/property rules. Classify actual IT/consulting rather than the supplier's qualification. Digital/telecoms/broadcasting customer-location rules and the specified use/enjoyment categories need separate checks. The UK use/enjoyment rule is not a universal anti-avoidance test for every service. Sources: [official source]; Notice 741A sections 6-14, [official source].",
  "evidence_entry_ids": [
    "UKSDIGITAL",
    "UKSUE"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 99,
  "line": 117,
  "original_review_exact_claim": "Digital/telecoms/broadcasting customer-location rules and the specified use/enjoyment categories need separate checks.",
  "original_review_row_id": 99,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 3: UK seller to a non-UK customer",
  "source_keys": [
    "UKSCH"
  ]
}
```

### 100

The UK use/enjoyment rule is not a universal anti-avoidance test for every service.

```json
{
  "act_articles": {
    "UKSUE": "Schedule4A paragraphs3(3)-(4),7(1)-(2),8(3)-(4),9(1)-(2),9D(2)-(3),9E(3)-(4), specified categories"
  },
  "conditions_context": "For B2C, apply section 7A(2)(b) unless Schedule 4A changes it. Listed professional/intangible services to a customer belonging outside the UK shift to that customer under Schedule 4A paragraph 16; ordinary unlisted services remain under the supplier rule, subject to the particular performance/property rules. Classify actual IT/consulting rather than the supplier's qualification. Digital/telecoms/broadcasting customer-location rules and the specified use/enjoyment categories need separate checks. The UK use/enjoyment rule is not a universal anti-avoidance test for every service. Sources: [official source]; Notice 741A sections 6-14, [official source].",
  "evidence_entry_ids": [
    "UKSUE"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "The exact Schedule4A categories/paragraphs are identified; no worldwide use/enjoyment test is inferred.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 100,
  "line": 117,
  "original_review_exact_claim": "The UK use/enjoyment rule is not a universal anti-avoidance test for every service.",
  "original_review_row_id": 100,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 3: UK seller to a non-UK customer",
  "source_keys": [
    "UKSCH"
  ]
}
```

### 101

Sources: [official source]; Notice 741A sections 6-14, [official source].

```json
{
  "act_articles": {
    "UKL2B": "VATA1994 section 7A(2)(b)",
    "UKL5": "VATA1994 section 7A(5)",
    "UKSB2C": "Schedule4A paragraph16(1), qualifying non-UK consumer",
    "UKSDIGITAL": "Schedule4A paragraph15(1), B2C digital/telecom/broadcast",
    "UKSOUTCUST": "Schedule4A paragraph16(1)(a)-(b), location qualification",
    "UKSPROF": "Schedule4A paragraph16(2)(d), listed professional/data services",
    "UKSPROFEX": "Schedule4A paragraph16(2)(d), land exclusion",
    "UKSUE": "Schedule4A paragraphs3(3)-(4),7(1)-(2),8(3)-(4),9(1)-(2),9D(2)-(3),9E(3)-(4), specified categories"
  },
  "conditions_context": "For B2C, apply section 7A(2)(b) unless Schedule 4A changes it. Listed professional/intangible services to a customer belonging outside the UK shift to that customer under Schedule 4A paragraph 16; ordinary unlisted services remain under the supplier rule, subject to the particular performance/property rules. Classify actual IT/consulting rather than the supplier's qualification. Digital/telecoms/broadcasting customer-location rules and the specified use/enjoyment categories need separate checks. The UK use/enjoyment rule is not a universal anti-avoidance test for every service. Sources: [official source]; Notice 741A sections 6-14, [official source].",
  "evidence_entry_ids": [
    "UKL2B",
    "UKL5",
    "UKSOUTCUST",
    "UKSB2C",
    "UKSPROF",
    "UKSPROFEX",
    "UKSDIGITAL",
    "UKSUE"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "741",
    "6",
    "14,"
  ],
  "id": 101,
  "line": 117,
  "original_review_exact_claim": "Sources: [official source]; Notice 741A sections 6-14, [official source].",
  "original_review_row_id": 101,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 3: UK seller to a non-UK customer",
  "source_keys": [
    "UKLAW",
    "UKSCH"
  ]
}
```

### 102

For an ordinary outside-UK service by a UK VAT-registered business under standard accounting, include its net value in Box 6 and no output VAT from that supply in Box 1.

```json
{
  "act_articles": {
    "UKBOX1": "Notice700/12 section3.2, opening Box1 instruction",
    "UKBOX6": "Notice700/12 section3.7, Box6 list"
  },
  "conditions_context": "For an ordinary outside-UK service by a UK VAT-registered business under standard accounting, include its net value in Box 6 and no output VAT from that supply in Box 1. Confirm any special scheme separately. Source: Notice 700/12 sections 3.2 and 3.7, [official source].",
  "evidence_entry_ids": [
    "UKBOX6",
    "UKBOX1"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "Standard ordinary UK VAT accounting and outside-UK service only; special schemes separately gated.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "6",
    "1."
  ],
  "id": 102,
  "line": 119,
  "original_review_exact_claim": "For an ordinary outside-UK service by a UK VAT-registered business under standard accounting, include its net value in Box 6 and no output VAT from that supply in Box 1.",
  "original_review_row_id": 102,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 3: UK seller to a non-UK customer",
  "source_keys": [
    "UKRETURN"
  ]
}
```

### 103

Confirm any special scheme separately.

```json
{
  "act_articles": {
    "UKBOX1": "Notice700/12 section3.2, opening Box1 instruction",
    "UKBOX6": "Notice700/12 section3.7, Box6 list"
  },
  "conditions_context": "For an ordinary outside-UK service by a UK VAT-registered business under standard accounting, include its net value in Box 6 and no output VAT from that supply in Box 1. Confirm any special scheme separately. Source: Notice 700/12 sections 3.2 and 3.7, [official source].",
  "evidence_entry_ids": [
    "UKBOX6",
    "UKBOX1"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "Workflow gate rather than clearance of any special scheme.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 103,
  "line": 119,
  "original_review_exact_claim": "Confirm any special scheme separately.",
  "original_review_row_id": 103,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 3: UK seller to a non-UK customer",
  "source_keys": [
    "UKRETURN"
  ]
}
```

### 104

Source: Notice 700/12 sections 3.2 and 3.7, [official source].

```json
{
  "act_articles": {
    "UKBOX1": "Notice700/12 section3.2, opening Box1 instruction",
    "UKBOX6": "Notice700/12 section3.7, Box6 list"
  },
  "conditions_context": "For an ordinary outside-UK service by a UK VAT-registered business under standard accounting, include its net value in Box 6 and no output VAT from that supply in Box 1. Confirm any special scheme separately. Source: Notice 700/12 sections 3.2 and 3.7, [official source].",
  "evidence_entry_ids": [
    "UKBOX6",
    "UKBOX1"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "700",
    "12",
    "3.2",
    "3.7,"
  ],
  "id": 104,
  "line": 119,
  "original_review_exact_claim": "Source: Notice 700/12 sections 3.2 and 3.7, [official source].",
  "original_review_row_id": 104,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 3: UK seller to a non-UK customer",
  "source_keys": [
    "UKRETURN"
  ]
}
```

### 105

**Post-Brexit correction:** services are outside the Northern Ireland goods arrangement.

```json
{
  "act_articles": {
    "UKNI": "Notice741A2.5, Northern Ireland Protocol paragraph"
  },
  "conditions_context": "**Post-Brexit correction:** services are outside the Northern Ireland goods arrangement. A UK supplier can still supply Article 44 services for which an EU customer owes VAT under **Article 196**: it applies to a supplier not established in the customer's Member State, including a UK supplier, subject to the establishment/liability conditions. French implementation does not replace or disapply that EU mechanism merely because the supplier is non-EU. The UK seller charges no UK VAT on an ordinary qualifying France-place service; check French recipient liability and invoicing. Sources: Articles 44, 192a and 196, [official source]; UK Notice 741A section 2.5, [official source].",
  "evidence_entry_ids": [
    "UKNI"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 105,
  "line": 121,
  "original_review_exact_claim": "**Post-Brexit correction:** services are outside the Northern Ireland goods arrangement.",
  "original_review_row_id": 105,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 3: UK seller to a non-UK customer",
  "source_keys": [
    "UK"
  ]
}
```

### 106

A UK supplier can still supply Article 44 services for which an EU customer owes VAT under **Article 196**: it applies to a supplier not established in the customer's Member State, including a UK supplier, subject to the establishment/liability conditions.

```json
{
  "act_articles": {
    "EU192A": "Article 192a(b), establishment intervention",
    "EU196": "Article 196",
    "EU44ACT": "Article44, first sentence, taxable business-capacity condition",
    "EU44B": "Article 44, first sentence"
  },
  "conditions_context": "**Post-Brexit correction:** services are outside the Northern Ireland goods arrangement. A UK supplier can still supply Article 44 services for which an EU customer owes VAT under **Article 196**: it applies to a supplier not established in the customer's Member State, including a UK supplier, subject to the establishment/liability conditions. French implementation does not replace or disapply that EU mechanism merely because the supplier is non-EU. The UK seller charges no UK VAT on an ordinary qualifying France-place service; check French recipient liability and invoicing. Sources: Articles 44, 192a and 196, [official source]; UK Notice 741A section 2.5, [official source].",
  "evidence_entry_ids": [
    "EU44ACT",
    "EU44B",
    "EU192A",
    "EU196"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "44",
    "196"
  ],
  "id": 106,
  "line": 121,
  "original_review_exact_claim": "A UK supplier can still supply Article 44 services for which an EU customer owes VAT under **Article 196**: it applies to a supplier not established in the customer's Member State, including a UK supplier, subject to the establishment/liability conditions.",
  "original_review_row_id": 106,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 3: UK seller to a non-UK customer",
  "source_keys": [
    "EU"
  ]
}
```

### 107

French implementation does not replace or disapply that EU mechanism merely because the supplier is non-EU.

```json
{
  "act_articles": {
    "EU196": "Article 196"
  },
  "conditions_context": "**Post-Brexit correction:** services are outside the Northern Ireland goods arrangement. A UK supplier can still supply Article 44 services for which an EU customer owes VAT under **Article 196**: it applies to a supplier not established in the customer's Member State, including a UK supplier, subject to the establishment/liability conditions. French implementation does not replace or disapply that EU mechanism merely because the supplier is non-EU. The UK seller charges no UK VAT on an ordinary qualifying France-place service; check French recipient liability and invoicing. Sources: Articles 44, 192a and 196, [official source]; UK Notice 741A section 2.5, [official source].",
  "evidence_entry_ids": [
    "EU196"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "Article196 is not limited to EU-established suppliers; no French return/registration rule is computed here.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 107,
  "line": 121,
  "original_review_exact_claim": "French implementation does not replace or disapply that EU mechanism merely because the supplier is non-EU.",
  "original_review_row_id": 107,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 3: UK seller to a non-UK customer",
  "source_keys": [
    "EU"
  ]
}
```

### 108

The UK seller charges no UK VAT on an ordinary qualifying France-place service; check French recipient liability and invoicing.

```json
{
  "act_articles": {
    "EU192A": "Article 192a(b), establishment intervention",
    "EU196": "Article 196",
    "EU219A": "Article 219a(1), invoicing framework",
    "EU226": "Article 226(11a), mandatory wording",
    "EU44B": "Article 44, first sentence",
    "UKL2A": "VATA1994 section 7A(2)(a)",
    "UKL5": "VATA1994 section 7A(5)"
  },
  "conditions_context": "**Post-Brexit correction:** services are outside the Northern Ireland goods arrangement. A UK supplier can still supply Article 44 services for which an EU customer owes VAT under **Article 196**: it applies to a supplier not established in the customer's Member State, including a UK supplier, subject to the establishment/liability conditions. French implementation does not replace or disapply that EU mechanism merely because the supplier is non-EU. The UK seller charges no UK VAT on an ordinary qualifying France-place service; check French recipient liability and invoicing. Sources: Articles 44, 192a and 196, [official source]; UK Notice 741A section 2.5, [official source].",
  "evidence_entry_ids": [
    "UKL2A",
    "UKL5",
    "EU44B",
    "EU192A",
    "EU196",
    "EU219A",
    "EU226"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 108,
  "line": 121,
  "original_review_exact_claim": "The UK seller charges no UK VAT on an ordinary qualifying France-place service; check French recipient liability and invoicing.",
  "original_review_row_id": 108,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 3: UK seller to a non-UK customer",
  "source_keys": [
    "UKLAW",
    "EU"
  ]
}
```

### 109

Sources: Articles 44, 192a and 196, [official source]; UK Notice 741A section 2.5, [official source].

```json
{
  "act_articles": {
    "EU192A": "Article 192a(b), establishment intervention",
    "EU196": "Article 196",
    "EU44B": "Article 44, first sentence",
    "UKNI": "Notice741A2.5, Northern Ireland Protocol paragraph"
  },
  "conditions_context": "**Post-Brexit correction:** services are outside the Northern Ireland goods arrangement. A UK supplier can still supply Article 44 services for which an EU customer owes VAT under **Article 196**: it applies to a supplier not established in the customer's Member State, including a UK supplier, subject to the establishment/liability conditions. French implementation does not replace or disapply that EU mechanism merely because the supplier is non-EU. The UK seller charges no UK VAT on an ordinary qualifying France-place service; check French recipient liability and invoicing. Sources: Articles 44, 192a and 196, [official source]; UK Notice 741A section 2.5, [official source].",
  "evidence_entry_ids": [
    "EU44B",
    "EU192A",
    "EU196",
    "UKNI"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "44,",
    "192",
    "196,",
    "741",
    "2.5,"
  ],
  "id": 109,
  "line": 121,
  "original_review_exact_claim": "Sources: Articles 44, 192a and 196, [official source]; UK Notice 741A section 2.5, [official source].",
  "original_review_row_id": 109,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 3: UK seller to a non-UK customer",
  "source_keys": [
    "EU",
    "UK"
  ]
}
```

### 110

Use GST Act section 38-190 for things other than goods or real property; a service performed by the supplier in Australia can qualify.

```json
{
  "act_articles": {
    "AU2A": "s38-190(1), item2(a)",
    "AU2ABS": "s38-190(1), item2 chapeau",
    "AU2ALAND": "s38-190(1), item2(a), land condition",
    "AUSCOPE": "s38-190(1), chapeau",
    "AUSCOPEEX": "s38-190(1), chapeau, exclusions"
  },
  "conditions_context": "Use GST Act section 38-190 for things other than goods or real property; a service performed by the supplier in Australia can qualify. Identify the precise item, the non-resident/recipient, its relevant presence and the actual recipient/beneficiary. An overseas registered address alone does not establish all conditions. Source: [official source].",
  "evidence_entry_ids": [
    "AUSCOPE",
    "AUSCOPEEX",
    "AU2ABS",
    "AU2A",
    "AU2ALAND"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "Item2(a) does not require supplier performance outside Australia; all local goods/property/beneficiary exclusions remain applicable.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "38",
    "190"
  ],
  "id": 110,
  "line": 125,
  "original_review_exact_claim": "Use GST Act section 38-190 for things other than goods or real property; a service performed by the supplier in Australia can qualify.",
  "original_review_row_id": 110,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 4: Australian seller to an overseas customer",
  "source_keys": [
    "AU"
  ]
}
```

### 111

Identify the precise item, the non-resident/recipient, its relevant presence and the actual recipient/beneficiary.

```json
{
  "act_articles": {
    "AU2A": "s38-190(1), item2(a)",
    "AU2ABS": "s38-190(1), item2 chapeau",
    "AU2ALAND": "s38-190(1), item2(a), land condition",
    "AU2AWHENDONE": "s38-190(1) item2(a), timing of local work",
    "AU2BENT": "s38-190(1), item2(b), enterprise condition",
    "AU2BREG": "s38-190(1) item2(b), actual registration wording",
    "AU3": "s38-190(1), item3(b)",
    "AU3ABS": "s38-190(1), item3(a)",
    "AU3EX": "s38-190(1), item3 final exclusion",
    "AU3LAND": "s38-190(1) item3, final exclusion",
    "AULOCAL": "s38-190(3)(b), local provision",
    "AULOCALA": "s38-190(3)(a), nonresident agreement",
    "AULOCALC": "s38-190(3)(c), input-taxed limitation on exceptions",
    "AULOCALX": "s38-190(3)(c)(i), business-recipient exception",
    "AULOCALX2": "s38-190(3)(c)(ii), employee/officer alternative",
    "AULOCALX3": "s38-190(3)(c)(iii), recipient creditable-purpose alternative",
    "AUPROP": "s38-190(2A), input-taxed property exclusion",
    "AUPROPALL": "s38-190(2A), item/application extent",
    "AUPROPITEMS": "s38-190(2A), items2-4",
    "AURIGHT": "s38-190(2), rights/options exclusion",
    "AUSCOPE": "s38-190(1), chapeau",
    "AUSCOPEEX": "s38-190(1), chapeau, exclusions"
  },
  "conditions_context": "Use GST Act section 38-190 for things other than goods or real property; a service performed by the supplier in Australia can qualify. Identify the precise item, the non-resident/recipient, its relevant presence and the actual recipient/beneficiary. An overseas registered address alone does not establish all conditions. Source: [official source].",
  "evidence_entry_ids": [
    "AUSCOPE",
    "AUSCOPEEX",
    "AU2ABS",
    "AU2A",
    "AU2AWHENDONE",
    "AU2ALAND",
    "AURIGHT",
    "AUPROPALL",
    "AUPROPITEMS",
    "AUPROP",
    "AULOCALA",
    "AULOCAL",
    "AULOCALC",
    "AULOCALX",
    "AULOCALX2",
    "AULOCALX3",
    "AU2BENT",
    "AU2BREG",
    "AU3ABS",
    "AU3",
    "AU3EX",
    "AU3LAND"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 111,
  "line": 125,
  "original_review_exact_claim": "Identify the precise item, the non-resident/recipient, its relevant presence and the actual recipient/beneficiary.",
  "original_review_row_id": 111,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 4: Australian seller to an overseas customer",
  "source_keys": [
    "AU"
  ]
}
```

### 112

An overseas registered address alone does not establish all conditions.

```json
{
  "act_articles": {
    "AU2A": "s38-190(1), item2(a)",
    "AU2ABS": "s38-190(1), item2 chapeau",
    "AU2ALAND": "s38-190(1), item2(a), land condition",
    "AU2AWHENDONE": "s38-190(1) item2(a), timing of local work",
    "AULOCAL": "s38-190(3)(b), local provision",
    "AULOCALA": "s38-190(3)(a), nonresident agreement",
    "AULOCALC": "s38-190(3)(c), input-taxed limitation on exceptions",
    "AULOCALX": "s38-190(3)(c)(i), business-recipient exception",
    "AULOCALX2": "s38-190(3)(c)(ii), employee/officer alternative",
    "AULOCALX3": "s38-190(3)(c)(iii), recipient creditable-purpose alternative",
    "AUPROP": "s38-190(2A), input-taxed property exclusion",
    "AUPROPALL": "s38-190(2A), item/application extent",
    "AUPROPITEMS": "s38-190(2A), items2-4",
    "AURIGHT": "s38-190(2), rights/options exclusion",
    "AUSCOPE": "s38-190(1), chapeau",
    "AUSCOPEEX": "s38-190(1), chapeau, exclusions"
  },
  "conditions_context": "Use GST Act section 38-190 for things other than goods or real property; a service performed by the supplier in Australia can qualify. Identify the precise item, the non-resident/recipient, its relevant presence and the actual recipient/beneficiary. An overseas registered address alone does not establish all conditions. Source: [official source].",
  "evidence_entry_ids": [
    "AUSCOPE",
    "AUSCOPEEX",
    "AU2ABS",
    "AU2A",
    "AU2AWHENDONE",
    "AU2ALAND",
    "AURIGHT",
    "AUPROPALL",
    "AUPROPITEMS",
    "AUPROP",
    "AULOCALA",
    "AULOCAL",
    "AULOCALC",
    "AULOCALX",
    "AULOCALX2",
    "AULOCALX3"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 112,
  "line": 125,
  "original_review_exact_claim": "An overseas registered address alone does not establish all conditions.",
  "original_review_row_id": 112,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 4: Australian seller to an overseas customer",
  "source_keys": [
    "AU"
  ]
}
```

### 113

Source: [official source].

```json
{
  "act_articles": {
    "AU2A": "s38-190(1), item2(a)",
    "AU2ABS": "s38-190(1), item2 chapeau",
    "AU2ALAND": "s38-190(1), item2(a), land condition",
    "AU2AWHENDONE": "s38-190(1) item2(a), timing of local work",
    "AU2BENT": "s38-190(1), item2(b), enterprise condition",
    "AU2BREG": "s38-190(1) item2(b), actual registration wording",
    "AU3": "s38-190(1), item3(b)",
    "AU3ABS": "s38-190(1), item3(a)",
    "AU3EX": "s38-190(1), item3 final exclusion",
    "AU3LAND": "s38-190(1) item3, final exclusion",
    "AULOCAL": "s38-190(3)(b), local provision",
    "AULOCALA": "s38-190(3)(a), nonresident agreement",
    "AULOCALC": "s38-190(3)(c), input-taxed limitation on exceptions",
    "AULOCALX": "s38-190(3)(c)(i), business-recipient exception",
    "AULOCALX2": "s38-190(3)(c)(ii), employee/officer alternative",
    "AULOCALX3": "s38-190(3)(c)(iii), recipient creditable-purpose alternative",
    "AUPROP": "s38-190(2A), input-taxed property exclusion",
    "AUPROPALL": "s38-190(2A), item/application extent",
    "AUPROPITEMS": "s38-190(2A), items2-4",
    "AURIGHT": "s38-190(2), rights/options exclusion",
    "AUSCOPE": "s38-190(1), chapeau",
    "AUSCOPEEX": "s38-190(1), chapeau, exclusions"
  },
  "conditions_context": "Use GST Act section 38-190 for things other than goods or real property; a service performed by the supplier in Australia can qualify. Identify the precise item, the non-resident/recipient, its relevant presence and the actual recipient/beneficiary. An overseas registered address alone does not establish all conditions. Source: [official source].",
  "evidence_entry_ids": [
    "AUSCOPE",
    "AUSCOPEEX",
    "AU2ABS",
    "AU2A",
    "AU2AWHENDONE",
    "AU2ALAND",
    "AURIGHT",
    "AUPROPALL",
    "AUPROPITEMS",
    "AUPROP",
    "AULOCALA",
    "AULOCAL",
    "AULOCALC",
    "AULOCALX",
    "AULOCALX2",
    "AULOCALX3",
    "AU2BENT",
    "AU2BREG",
    "AU3ABS",
    "AU3",
    "AU3EX",
    "AU3LAND"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 113,
  "line": 125,
  "original_review_exact_claim": "Source: [official source].",
  "original_review_row_id": 113,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 4: Australian seller to an overseas customer",
  "source_keys": [
    "AU"
  ]
}
```

### 114

| Item 1 | Supply directly connected with goods or real property situated outside the indirect tax zone | https://www.legislation.gov.au/C2004A00446/2026-01-01/2026-01-01/text/original/epub/OEBPS/document_1/document_1.html |

```json
{
  "act_articles": {
    "AU1": "s38-190(1), item1"
  },
  "conditions_context": "| Item 1 | Supply directly connected with goods or real property situated outside the indirect tax zone | [official source] |",
  "evidence_entry_ids": [
    "AU1"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "1",
    "004",
    "0446",
    "2026",
    "01",
    "01",
    "2026",
    "01",
    "01",
    "1",
    "1."
  ],
  "id": 114,
  "line": 129,
  "original_review_exact_claim": "| Item 1 | Supply directly connected with goods or real property situated outside the indirect tax zone | https://www.legislation.gov.au/C2004A00446/2026-01-01/2026-01-01/text/original/epub/OEBPS/document_1/document_1.html |",
  "original_review_row_id": 114,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 4: Australian seller to an overseas customer",
  "source_keys": [
    "AU"
  ]
}
```

### 115

| Item 2(a) | Non-resident not in the indirect tax zone when the thing is done; supply is neither work physically performed on goods there nor directly connected with real property there | https://www.legislation.gov.au/C2004A00446/2026-01-01/2026-01-01/text/original/epub/OEBPS/document_1/document_1.html |

```json
{
  "act_articles": {
    "AU2A": "s38-190(1), item2(a)",
    "AU2ABS": "s38-190(1), item2 chapeau",
    "AU2ALAND": "s38-190(1), item2(a), land condition",
    "AU2AWHENDONE": "s38-190(1) item2(a), timing of local work"
  },
  "conditions_context": "| Item 2(a) | Non-resident not in the indirect tax zone when the thing is done; supply is neither work physically performed on goods there nor directly connected with real property there | [official source] |",
  "evidence_entry_ids": [
    "AU2ABS",
    "AU2A",
    "AU2AWHENDONE",
    "AU2ALAND"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "2(a)",
    "004",
    "0446",
    "2026",
    "01",
    "01",
    "2026",
    "01",
    "01",
    "1",
    "1."
  ],
  "id": 115,
  "line": 130,
  "original_review_exact_claim": "| Item 2(a) | Non-resident not in the indirect tax zone when the thing is done; supply is neither work physically performed on goods there nor directly connected with real property there | https://www.legislation.gov.au/C2004A00446/2026-01-01/2026-01-01/text/original/epub/OEBPS/document_1/document_1.html |",
  "original_review_row_id": 115,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 4: Australian seller to an overseas customer",
  "source_keys": [
    "AU"
  ]
}
```

### 116

| Item 2(b), an alternative to item 2(a) | Same non-resident/absence condition; recipient acquires in carrying on its enterprise and is neither GST-registered nor required to be registered | https://www.legislation.gov.au/C2004A00446/2026-01-01/2026-01-01/text/original/epub/OEBPS/document_1/document_1.html |

```json
{
  "act_articles": {
    "AU2ABS": "s38-190(1), item2 chapeau",
    "AU2BENT": "s38-190(1), item2(b), enterprise condition",
    "AU2BREG": "s38-190(1) item2(b), actual registration wording"
  },
  "conditions_context": "| Item 2(b), an alternative to item 2(a) | Same non-resident/absence condition; recipient acquires in carrying on its enterprise and is neither GST-registered nor required to be registered | [official source] |",
  "evidence_entry_ids": [
    "AU2ABS",
    "AU2BENT",
    "AU2BREG"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "2(b)",
    "2(a)",
    "004",
    "0446",
    "2026",
    "01",
    "01",
    "2026",
    "01",
    "01",
    "1",
    "1."
  ],
  "id": 116,
  "line": 131,
  "original_review_exact_claim": "| Item 2(b), an alternative to item 2(a) | Same non-resident/absence condition; recipient acquires in carrying on its enterprise and is neither GST-registered nor required to be registered | https://www.legislation.gov.au/C2004A00446/2026-01-01/2026-01-01/text/original/epub/OEBPS/document_1/document_1.html |",
  "original_review_row_id": 116,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 4: Australian seller to an overseas customer",
  "source_keys": [
    "AU"
  ]
}
```

### 117

| Item 3 | Recipient not in the indirect tax zone when the thing is done; effective use/enjoyment outside; excludes local goods-work and local real-property connection | https://www.legislation.gov.au/C2004A00446/2026-01-01/2026-01-01/text/original/epub/OEBPS/document_1/document_1.html |

```json
{
  "act_articles": {
    "AU3": "s38-190(1), item3(b)",
    "AU3ABS": "s38-190(1), item3(a)",
    "AU3EX": "s38-190(1), item3 final exclusion",
    "AU3LAND": "s38-190(1) item3, final exclusion"
  },
  "conditions_context": "| Item 3 | Recipient not in the indirect tax zone when the thing is done; effective use/enjoyment outside; excludes local goods-work and local real-property connection | [official source] |",
  "evidence_entry_ids": [
    "AU3ABS",
    "AU3",
    "AU3EX",
    "AU3LAND"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "3",
    "004",
    "0446",
    "2026",
    "01",
    "01",
    "2026",
    "01",
    "01",
    "1",
    "1."
  ],
  "id": 117,
  "line": 132,
  "original_review_exact_claim": "| Item 3 | Recipient not in the indirect tax zone when the thing is done; effective use/enjoyment outside; excludes local goods-work and local real-property connection | https://www.legislation.gov.au/C2004A00446/2026-01-01/2026-01-01/text/original/epub/OEBPS/document_1/document_1.html |",
  "original_review_row_id": 117,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 4: Australian seller to an overseas customer",
  "source_keys": [
    "AU"
  ]
}
```

### 118

| Rights/options, subsection (2) | Relief is excluded for a right/option to acquire something whose supply would be connected with the indirect tax zone and would not be GST-free | https://www.legislation.gov.au/C2004A00446/2026-01-01/2026-01-01/text/original/epub/OEBPS/document_1/document_1.html |

```json
{
  "act_articles": {
    "AURIGHT": "s38-190(2), rights/options exclusion"
  },
  "conditions_context": "| Rights/options, subsection (2) | Relief is excluded for a right/option to acquire something whose supply would be connected with the indirect tax zone and would not be GST-free | [official source] |",
  "evidence_entry_ids": [
    "AURIGHT"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "2",
    "004",
    "0446",
    "2026",
    "01",
    "01",
    "2026",
    "01",
    "01",
    "1",
    "1."
  ],
  "id": 118,
  "line": 133,
  "original_review_exact_claim": "| Rights/options, subsection (2) | Relief is excluded for a right/option to acquire something whose supply would be connected with the indirect tax zone and would not be GST-free | https://www.legislation.gov.au/C2004A00446/2026-01-01/2026-01-01/text/original/epub/OEBPS/document_1/document_1.html |",
  "original_review_row_id": 118,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 4: Australian seller to an overseas customer",
  "source_keys": [
    "AU"
  ]
}
```

### 119

| Input-taxed real-property connection, subsection (2A) | Items 2-4 do not relieve an acquisition relating directly/indirectly, wholly/partly, to a supply of local real property input-taxed under the specified residential-property subdivisions | https://www.legislation.gov.au/C2004A00446/2026-01-01/2026-01-01/text/original/epub/OEBPS/document_1/document_1.html |

```json
{
  "act_articles": {
    "AUPROP": "s38-190(2A), input-taxed property exclusion",
    "AUPROPALL": "s38-190(2A), item/application extent",
    "AUPROPITEMS": "s38-190(2A), items2-4"
  },
  "conditions_context": "| Input-taxed real-property connection, subsection (2A) | Items 2-4 do not relieve an acquisition relating directly/indirectly, wholly/partly, to a supply of local real property input-taxed under the specified residential-property subdivisions | [official source] |",
  "evidence_entry_ids": [
    "AUPROPITEMS",
    "AUPROPALL",
    "AUPROP"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "2",
    "2",
    "4",
    "004",
    "0446",
    "2026",
    "01",
    "01",
    "2026",
    "01",
    "01",
    "1",
    "1."
  ],
  "id": 119,
  "line": 134,
  "original_review_exact_claim": "| Input-taxed real-property connection, subsection (2A) | Items 2-4 do not relieve an acquisition relating directly/indirectly, wholly/partly, to a supply of local real property input-taxed under the specified residential-property subdivisions | https://www.legislation.gov.au/C2004A00446/2026-01-01/2026-01-01/text/original/epub/OEBPS/document_1/document_1.html |",
  "original_review_row_id": 119,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 4: Australian seller to an overseas customer",
  "source_keys": [
    "AU"
  ]
}
```

### 120

| Local third-party provision, subsection (3) | Item 2 can be denied where the non-resident agreement provides the service to another entity in Australia; apply all statutory exceptions, including the Australian-based business-recipient and specified employee/officer cases | https://www.legislation.gov.au/C2004A00446/2026-01-01/2026-01-01/text/original/epub/OEBPS/document_1/document_1.html |

```json
{
  "act_articles": {
    "AULOCAL": "s38-190(3)(b), local provision",
    "AULOCALA": "s38-190(3)(a), nonresident agreement",
    "AULOCALC": "s38-190(3)(c), input-taxed limitation on exceptions",
    "AULOCALX": "s38-190(3)(c)(i), business-recipient exception",
    "AULOCALX2": "s38-190(3)(c)(ii), employee/officer alternative",
    "AULOCALX3": "s38-190(3)(c)(iii), recipient creditable-purpose alternative"
  },
  "conditions_context": "| Local third-party provision, subsection (3) | Item 2 can be denied where the non-resident agreement provides the service to another entity in Australia; apply all statutory exceptions, including the Australian-based business-recipient and specified employee/officer cases | [official source] |",
  "evidence_entry_ids": [
    "AULOCALA",
    "AULOCAL",
    "AULOCALC",
    "AULOCALX",
    "AULOCALX2",
    "AULOCALX3"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "3",
    "2",
    "004",
    "0446",
    "2026",
    "01",
    "01",
    "2026",
    "01",
    "01",
    "1",
    "1."
  ],
  "id": 120,
  "line": 135,
  "original_review_exact_claim": "| Local third-party provision, subsection (3) | Item 2 can be denied where the non-resident agreement provides the service to another entity in Australia; apply all statutory exceptions, including the Australian-based business-recipient and specified employee/officer cases | https://www.legislation.gov.au/C2004A00446/2026-01-01/2026-01-01/text/original/epub/OEBPS/document_1/document_1.html |",
  "original_review_row_id": 120,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 4: Australian seller to an overseas customer",
  "source_keys": [
    "AU"
  ]
}
```

### 121

| Item 3 extension, subsections (4)-(5) | Certain agreements with an Australian resident for provision to another entity outside Australia can satisfy the absence limb; listed local international-transport-related services are excluded from this extension | https://www.legislation.gov.au/C2004A00446/2026-01-01/2026-01-01/text/original/epub/OEBPS/document_1/document_1.html |

```json
{
  "act_articles": {
    "AU3AUSTAGREE": "s38-190(4)(a), agreement limb",
    "AUEXT": "s38-190(4)(b), item3 extension",
    "AUEXTTRANS": "s38-190(5)(a)-(e), goods transport/handling/facilitation/insurance/arrangement; extract(a)",
    "AUEXTX": "s38-190(5), transport-service exclusion to extension"
  },
  "conditions_context": "| Item 3 extension, subsections (4)-(5) | Certain agreements with an Australian resident for provision to another entity outside Australia can satisfy the absence limb; listed local international-transport-related services are excluded from this extension | [official source] |",
  "evidence_entry_ids": [
    "AU3AUSTAGREE",
    "AUEXT",
    "AUEXTX",
    "AUEXTTRANS"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "3",
    "4",
    "5",
    "004",
    "0446",
    "2026",
    "01",
    "01",
    "2026",
    "01",
    "01",
    "1",
    "1."
  ],
  "id": 121,
  "line": 136,
  "original_review_exact_claim": "| Item 3 extension, subsections (4)-(5) | Certain agreements with an Australian resident for provision to another entity outside Australia can satisfy the absence limb; listed local international-transport-related services are excluded from this extension | https://www.legislation.gov.au/C2004A00446/2026-01-01/2026-01-01/text/original/epub/OEBPS/document_1/document_1.html |",
  "original_review_row_id": 121,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 4: Australian seller to an overseas customer",
  "source_keys": [
    "AU"
  ]
}
```

### 122

Do not combine items 2 and 3 into one cumulative test.

```json
{
  "act_articles": {
    "AU2A": "s38-190(1), item2(a)",
    "AU2ABS": "s38-190(1), item2 chapeau",
    "AU2ALAND": "s38-190(1), item2(a), land condition",
    "AU2BENT": "s38-190(1), item2(b), enterprise condition",
    "AU2BREG": "s38-190(1) item2(b), actual registration wording",
    "AU3": "s38-190(1), item3(b)",
    "AU3ABS": "s38-190(1), item3(a)",
    "AU3EX": "s38-190(1), item3 final exclusion",
    "AU3LAND": "s38-190(1) item3, final exclusion"
  },
  "conditions_context": "Do not combine items 2 and 3 into one cumulative test. Effective use/enjoyment outside Australia is an item 3 condition, not a universal added condition to every item 2 supply. Conversely, do not disregard subsections (2), (2A) and (3) just because the contract is with a non-resident. Complex presence, third-party provision, rights and mixed supplies require the applicable detailed ruling/country guidance before a final result. Source: [official source].",
  "evidence_entry_ids": [
    "AU2ABS",
    "AU2A",
    "AU2ALAND",
    "AU2BENT",
    "AU2BREG",
    "AU3ABS",
    "AU3",
    "AU3EX",
    "AU3LAND"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "2",
    "3"
  ],
  "id": 122,
  "line": 138,
  "original_review_exact_claim": "Do not combine items 2 and 3 into one cumulative test.",
  "original_review_row_id": 122,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 4: Australian seller to an overseas customer",
  "source_keys": [
    "AU"
  ]
}
```

### 123

Effective use/enjoyment outside Australia is an item 3 condition, not a universal added condition to every item 2 supply.

```json
{
  "act_articles": {
    "AU2A": "s38-190(1), item2(a)",
    "AU2ABS": "s38-190(1), item2 chapeau",
    "AU2ALAND": "s38-190(1), item2(a), land condition",
    "AU2BENT": "s38-190(1), item2(b), enterprise condition",
    "AU2BREG": "s38-190(1) item2(b), actual registration wording",
    "AU3": "s38-190(1), item3(b)",
    "AU3ABS": "s38-190(1), item3(a)",
    "AU3EX": "s38-190(1), item3 final exclusion",
    "AU3LAND": "s38-190(1) item3, final exclusion"
  },
  "conditions_context": "Do not combine items 2 and 3 into one cumulative test. Effective use/enjoyment outside Australia is an item 3 condition, not a universal added condition to every item 2 supply. Conversely, do not disregard subsections (2), (2A) and (3) just because the contract is with a non-resident. Complex presence, third-party provision, rights and mixed supplies require the applicable detailed ruling/country guidance before a final result. Source: [official source].",
  "evidence_entry_ids": [
    "AU2ABS",
    "AU2A",
    "AU2ALAND",
    "AU2BENT",
    "AU2BREG",
    "AU3ABS",
    "AU3",
    "AU3EX",
    "AU3LAND"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "3",
    "2"
  ],
  "id": 123,
  "line": 138,
  "original_review_exact_claim": "Effective use/enjoyment outside Australia is an item 3 condition, not a universal added condition to every item 2 supply.",
  "original_review_row_id": 123,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 4: Australian seller to an overseas customer",
  "source_keys": [
    "AU"
  ]
}
```

### 124

Conversely, do not disregard subsections (2), (2A) and (3) just because the contract is with a non-resident.

```json
{
  "act_articles": {
    "AULOCAL": "s38-190(3)(b), local provision",
    "AULOCALA": "s38-190(3)(a), nonresident agreement",
    "AULOCALC": "s38-190(3)(c), input-taxed limitation on exceptions",
    "AULOCALX": "s38-190(3)(c)(i), business-recipient exception",
    "AULOCALX2": "s38-190(3)(c)(ii), employee/officer alternative",
    "AULOCALX3": "s38-190(3)(c)(iii), recipient creditable-purpose alternative",
    "AUPROP": "s38-190(2A), input-taxed property exclusion",
    "AUPROPALL": "s38-190(2A), item/application extent",
    "AUPROPITEMS": "s38-190(2A), items2-4",
    "AURIGHT": "s38-190(2), rights/options exclusion"
  },
  "conditions_context": "Do not combine items 2 and 3 into one cumulative test. Effective use/enjoyment outside Australia is an item 3 condition, not a universal added condition to every item 2 supply. Conversely, do not disregard subsections (2), (2A) and (3) just because the contract is with a non-resident. Complex presence, third-party provision, rights and mixed supplies require the applicable detailed ruling/country guidance before a final result. Source: [official source].",
  "evidence_entry_ids": [
    "AURIGHT",
    "AUPROPITEMS",
    "AUPROPALL",
    "AUPROP",
    "AULOCALA",
    "AULOCAL",
    "AULOCALC",
    "AULOCALX",
    "AULOCALX2",
    "AULOCALX3"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "2",
    "2",
    "3"
  ],
  "id": 124,
  "line": 138,
  "original_review_exact_claim": "Conversely, do not disregard subsections (2), (2A) and (3) just because the contract is with a non-resident.",
  "original_review_row_id": 124,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 4: Australian seller to an overseas customer",
  "source_keys": [
    "AU"
  ]
}
```

### 125

Complex presence, third-party provision, rights and mixed supplies require the applicable detailed ruling/country guidance before a final result.

```json
{
  "act_articles": {
    "AU2A": "s38-190(1), item2(a)",
    "AU2ABS": "s38-190(1), item2 chapeau",
    "AU2ALAND": "s38-190(1), item2(a), land condition",
    "AU2AWHENDONE": "s38-190(1) item2(a), timing of local work",
    "AU2BENT": "s38-190(1), item2(b), enterprise condition",
    "AU2BREG": "s38-190(1) item2(b), actual registration wording",
    "AU3": "s38-190(1), item3(b)",
    "AU3ABS": "s38-190(1), item3(a)",
    "AU3EX": "s38-190(1), item3 final exclusion",
    "AU3LAND": "s38-190(1) item3, final exclusion",
    "AULOCAL": "s38-190(3)(b), local provision",
    "AULOCALA": "s38-190(3)(a), nonresident agreement",
    "AULOCALC": "s38-190(3)(c), input-taxed limitation on exceptions",
    "AULOCALX": "s38-190(3)(c)(i), business-recipient exception",
    "AULOCALX2": "s38-190(3)(c)(ii), employee/officer alternative",
    "AULOCALX3": "s38-190(3)(c)(iii), recipient creditable-purpose alternative",
    "AUPROP": "s38-190(2A), input-taxed property exclusion",
    "AUPROPALL": "s38-190(2A), item/application extent",
    "AUPROPITEMS": "s38-190(2A), items2-4",
    "AURIGHT": "s38-190(2), rights/options exclusion",
    "AUSCOPE": "s38-190(1), chapeau",
    "AUSCOPEEX": "s38-190(1), chapeau, exclusions"
  },
  "conditions_context": "Do not combine items 2 and 3 into one cumulative test. Effective use/enjoyment outside Australia is an item 3 condition, not a universal added condition to every item 2 supply. Conversely, do not disregard subsections (2), (2A) and (3) just because the contract is with a non-resident. Complex presence, third-party provision, rights and mixed supplies require the applicable detailed ruling/country guidance before a final result. Source: [official source].",
  "evidence_entry_ids": [
    "AUSCOPE",
    "AUSCOPEEX",
    "AU2ABS",
    "AU2A",
    "AU2AWHENDONE",
    "AU2ALAND",
    "AURIGHT",
    "AUPROPALL",
    "AUPROPITEMS",
    "AUPROP",
    "AULOCALA",
    "AULOCAL",
    "AULOCALC",
    "AULOCALX",
    "AULOCALX2",
    "AULOCALX3",
    "AU2BENT",
    "AU2BREG",
    "AU3ABS",
    "AU3",
    "AU3EX",
    "AU3LAND"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "Referral of complexity; no unverified detailed-ruling result is asserted.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 125,
  "line": 138,
  "original_review_exact_claim": "Complex presence, third-party provision, rights and mixed supplies require the applicable detailed ruling/country guidance before a final result.",
  "original_review_row_id": 125,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 4: Australian seller to an overseas customer",
  "source_keys": [
    "AU"
  ]
}
```

### 126

Source: [official source].

```json
{
  "act_articles": {
    "AU2A": "s38-190(1), item2(a)",
    "AU2ABS": "s38-190(1), item2 chapeau",
    "AU2ALAND": "s38-190(1), item2(a), land condition",
    "AU2AWHENDONE": "s38-190(1) item2(a), timing of local work",
    "AU2BENT": "s38-190(1), item2(b), enterprise condition",
    "AU2BREG": "s38-190(1) item2(b), actual registration wording",
    "AU3": "s38-190(1), item3(b)",
    "AU3ABS": "s38-190(1), item3(a)",
    "AU3AUSTAGREE": "s38-190(4)(a), agreement limb",
    "AU3EX": "s38-190(1), item3 final exclusion",
    "AU3LAND": "s38-190(1) item3, final exclusion",
    "AUEXT": "s38-190(4)(b), item3 extension",
    "AUEXTTRANS": "s38-190(5)(a)-(e), goods transport/handling/facilitation/insurance/arrangement; extract(a)",
    "AUEXTX": "s38-190(5), transport-service exclusion to extension",
    "AULOCAL": "s38-190(3)(b), local provision",
    "AULOCALA": "s38-190(3)(a), nonresident agreement",
    "AULOCALC": "s38-190(3)(c), input-taxed limitation on exceptions",
    "AULOCALX": "s38-190(3)(c)(i), business-recipient exception",
    "AULOCALX2": "s38-190(3)(c)(ii), employee/officer alternative",
    "AULOCALX3": "s38-190(3)(c)(iii), recipient creditable-purpose alternative",
    "AUPROP": "s38-190(2A), input-taxed property exclusion",
    "AUPROPALL": "s38-190(2A), item/application extent",
    "AUPROPITEMS": "s38-190(2A), items2-4",
    "AURIGHT": "s38-190(2), rights/options exclusion",
    "AUSCOPE": "s38-190(1), chapeau",
    "AUSCOPEEX": "s38-190(1), chapeau, exclusions"
  },
  "conditions_context": "Do not combine items 2 and 3 into one cumulative test. Effective use/enjoyment outside Australia is an item 3 condition, not a universal added condition to every item 2 supply. Conversely, do not disregard subsections (2), (2A) and (3) just because the contract is with a non-resident. Complex presence, third-party provision, rights and mixed supplies require the applicable detailed ruling/country guidance before a final result. Source: [official source].",
  "evidence_entry_ids": [
    "AUSCOPE",
    "AUSCOPEEX",
    "AU2ABS",
    "AU2A",
    "AU2AWHENDONE",
    "AU2ALAND",
    "AURIGHT",
    "AUPROPALL",
    "AUPROPITEMS",
    "AUPROP",
    "AULOCALA",
    "AULOCAL",
    "AULOCALC",
    "AULOCALX",
    "AULOCALX2",
    "AULOCALX3",
    "AU2BENT",
    "AU2BREG",
    "AU3ABS",
    "AU3",
    "AU3EX",
    "AU3LAND",
    "AU3AUSTAGREE",
    "AUEXT",
    "AUEXTX",
    "AUEXTTRANS"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 126,
  "line": 138,
  "original_review_exact_claim": "Source: [official source].",
  "original_review_row_id": 126,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 4: Australian seller to an overseas customer",
  "source_keys": [
    "AU"
  ]
}
```

### 127

Input tax credits require a creditable acquisition: business/creditable purpose, a taxable acquisition for consideration, registration/required registration and applicable evidence/limitations.

```json
{
  "act_articles": {
    "AU11A": "s11-5(a)-(d), creditable acquisition",
    "AU11B": "s11-5(b)",
    "AU11C": "s11-5(c)",
    "AU11D": "s11-5(d)",
    "AU11ENTERPRISE": "s11-15(1)",
    "AU11ENTITLE": "s11-20",
    "AU11EX3": "s11-15(3), overseas-enterprise exception to11-15(2)(a)",
    "AU11EX4": "s11-15(4)(b), financial-acquisitions exception",
    "AU11EX5": "s11-15(5)(b), borrowing exception",
    "AU11INPUT": "s11-15(2)(a), subject3-5exceptions",
    "AU11PART": "s11-25 second sentence and11-30(1)/(3)",
    "AU11PRIVATE": "s11-15(2)(b)",
    "AU29INV": "s29-10(3), tax invoice attribution condition, exceptions in final paragraph",
    "AU29INVEX": "s29-10(3), Commissioner exception"
  },
  "conditions_context": "Input tax credits require a creditable acquisition: business/creditable purpose, a taxable acquisition for consideration, registration/required registration and applicable evidence/limitations. Private/input-taxed use and partly creditable acquisitions can reduce entitlement. GST-free output does not establish full credit for every purchase. Sources: GST Act sections 11-5, 11-15 and 11-20 to 11-30, [official source].",
  "evidence_entry_ids": [
    "AU11A",
    "AU11B",
    "AU11C",
    "AU11D",
    "AU11ENTERPRISE",
    "AU11ENTITLE",
    "AU11PRIVATE",
    "AU11INPUT",
    "AU11EX3",
    "AU11EX4",
    "AU11EX5",
    "AU11PART",
    "AU29INV",
    "AU29INVEX"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 127,
  "line": 140,
  "original_review_exact_claim": "Input tax credits require a creditable acquisition: business/creditable purpose, a taxable acquisition for consideration, registration/required registration and applicable evidence/limitations.",
  "original_review_row_id": 127,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 4: Australian seller to an overseas customer",
  "source_keys": [
    "AU"
  ]
}
```

### 128

Private/input-taxed use and partly creditable acquisitions can reduce entitlement.

```json
{
  "act_articles": {
    "AU11EX3": "s11-15(3), overseas-enterprise exception to11-15(2)(a)",
    "AU11EX4": "s11-15(4)(b), financial-acquisitions exception",
    "AU11EX5": "s11-15(5)(b), borrowing exception",
    "AU11INPUT": "s11-15(2)(a), subject3-5exceptions",
    "AU11PART": "s11-25 second sentence and11-30(1)/(3)",
    "AU11PRIVATE": "s11-15(2)(b)"
  },
  "conditions_context": "Input tax credits require a creditable acquisition: business/creditable purpose, a taxable acquisition for consideration, registration/required registration and applicable evidence/limitations. Private/input-taxed use and partly creditable acquisitions can reduce entitlement. GST-free output does not establish full credit for every purchase. Sources: GST Act sections 11-5, 11-15 and 11-20 to 11-30, [official source].",
  "evidence_entry_ids": [
    "AU11PRIVATE",
    "AU11INPUT",
    "AU11EX3",
    "AU11EX4",
    "AU11EX5",
    "AU11PART"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 128,
  "line": 140,
  "original_review_exact_claim": "Private/input-taxed use and partly creditable acquisitions can reduce entitlement.",
  "original_review_row_id": 128,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 4: Australian seller to an overseas customer",
  "source_keys": [
    "AU"
  ]
}
```

### 129

GST-free output does not establish full credit for every purchase.

```json
{
  "act_articles": {
    "AU11A": "s11-5(a)-(d), creditable acquisition",
    "AU11B": "s11-5(b)",
    "AU11C": "s11-5(c)",
    "AU11D": "s11-5(d)",
    "AU11ENTERPRISE": "s11-15(1)",
    "AU11ENTITLE": "s11-20",
    "AU11EX3": "s11-15(3), overseas-enterprise exception to11-15(2)(a)",
    "AU11EX4": "s11-15(4)(b), financial-acquisitions exception",
    "AU11EX5": "s11-15(5)(b), borrowing exception",
    "AU11INPUT": "s11-15(2)(a), subject3-5exceptions",
    "AU11PART": "s11-25 second sentence and11-30(1)/(3)",
    "AU11PRIVATE": "s11-15(2)(b)",
    "AU29INV": "s29-10(3), tax invoice attribution condition, exceptions in final paragraph",
    "AU29INVEX": "s29-10(3), Commissioner exception"
  },
  "conditions_context": "Input tax credits require a creditable acquisition: business/creditable purpose, a taxable acquisition for consideration, registration/required registration and applicable evidence/limitations. Private/input-taxed use and partly creditable acquisitions can reduce entitlement. GST-free output does not establish full credit for every purchase. Sources: GST Act sections 11-5, 11-15 and 11-20 to 11-30, [official source].",
  "evidence_entry_ids": [
    "AU11A",
    "AU11B",
    "AU11C",
    "AU11D",
    "AU11ENTERPRISE",
    "AU11ENTITLE",
    "AU11PRIVATE",
    "AU11INPUT",
    "AU11EX3",
    "AU11EX4",
    "AU11EX5",
    "AU11PART",
    "AU29INV",
    "AU29INVEX"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 129,
  "line": 140,
  "original_review_exact_claim": "GST-free output does not establish full credit for every purchase.",
  "original_review_row_id": 129,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 4: Australian seller to an overseas customer",
  "source_keys": [
    "AU"
  ]
}
```

### 130

Sources: GST Act sections 11-5, 11-15 and 11-20 to 11-30, [official source].

```json
{
  "act_articles": {
    "AU11A": "s11-5(a)-(d), creditable acquisition",
    "AU11B": "s11-5(b)",
    "AU11C": "s11-5(c)",
    "AU11D": "s11-5(d)",
    "AU11ENTERPRISE": "s11-15(1)",
    "AU11ENTITLE": "s11-20",
    "AU11EX3": "s11-15(3), overseas-enterprise exception to11-15(2)(a)",
    "AU11EX4": "s11-15(4)(b), financial-acquisitions exception",
    "AU11EX5": "s11-15(5)(b), borrowing exception",
    "AU11INPUT": "s11-15(2)(a), subject3-5exceptions",
    "AU11PART": "s11-25 second sentence and11-30(1)/(3)",
    "AU11PRIVATE": "s11-15(2)(b)",
    "AU29INV": "s29-10(3), tax invoice attribution condition, exceptions in final paragraph",
    "AU29INVEX": "s29-10(3), Commissioner exception"
  },
  "conditions_context": "Input tax credits require a creditable acquisition: business/creditable purpose, a taxable acquisition for consideration, registration/required registration and applicable evidence/limitations. Private/input-taxed use and partly creditable acquisitions can reduce entitlement. GST-free output does not establish full credit for every purchase. Sources: GST Act sections 11-5, 11-15 and 11-20 to 11-30, [official source].",
  "evidence_entry_ids": [
    "AU11A",
    "AU11B",
    "AU11C",
    "AU11D",
    "AU11ENTERPRISE",
    "AU11ENTITLE",
    "AU11PRIVATE",
    "AU11INPUT",
    "AU11EX3",
    "AU11EX4",
    "AU11EX5",
    "AU11PART",
    "AU29INV",
    "AU29INVEX"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "11",
    "5,",
    "11",
    "15",
    "11",
    "20",
    "11",
    "30,"
  ],
  "id": 130,
  "line": 140,
  "original_review_exact_claim": "Sources: GST Act sections 11-5, 11-15 and 11-20 to 11-30, [official source].",
  "original_review_row_id": 130,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 4: Australian seller to an overseas customer",
  "source_keys": [
    "AU"
  ]
}
```

### 131

**Reporting correction:** ordinary GST-free remote development/design/consulting is included in G1; under full reporting, it is normally other GST-free sales in G3.

```json
{
  "act_articles": {
    "ABG1": "G1 total sales, accounts/calculation-method GST-free-sales bullets",
    "ABG3": "G3 Other GST-free sales, What to report at G3",
    "ASIMPLE": "GST reporting methods / Simpler BAS / What to report, complete three-label list"
  },
  "conditions_context": "**Reporting correction:** ordinary GST-free remote development/design/consulting is included in G1; under full reporting, it is normally other GST-free sales in G3. G2 excludes GST-free services except the specified repair/renovation/modification/treatment of overseas goods destined outside Australia. Do not put every exported service in G2. Simpler BAS uses the applicable simplified labels rather than requiring G2/G3. Sources: ATO BAS G1-G3 instructions, [official source]; reporting-method guidance, [official source].",
  "evidence_entry_ids": [
    "ABG1",
    "ABG3",
    "ASIMPLE"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 131,
  "line": 142,
  "original_review_exact_claim": "**Reporting correction:** ordinary GST-free remote development/design/consulting is included in G1; under full reporting, it is normally other GST-free sales in G3.",
  "original_review_row_id": 131,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 4: Australian seller to an overseas customer",
  "source_keys": [
    "AUBAS",
    "AUSIMPLE"
  ]
}
```

### 132

G2 excludes GST-free services except the specified repair/renovation/modification/treatment of overseas goods destined outside Australia.

```json
{
  "act_articles": {
    "ABG2": "G2 Export sales, What not to report at G2, first bullet",
    "ABG2X": "Same G2 first bullet, exception"
  },
  "conditions_context": "**Reporting correction:** ordinary GST-free remote development/design/consulting is included in G1; under full reporting, it is normally other GST-free sales in G3. G2 excludes GST-free services except the specified repair/renovation/modification/treatment of overseas goods destined outside Australia. Do not put every exported service in G2. Simpler BAS uses the applicable simplified labels rather than requiring G2/G3. Sources: ATO BAS G1-G3 instructions, [official source]; reporting-method guidance, [official source].",
  "evidence_entry_ids": [
    "ABG2",
    "ABG2X"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 132,
  "line": 142,
  "original_review_exact_claim": "G2 excludes GST-free services except the specified repair/renovation/modification/treatment of overseas goods destined outside Australia.",
  "original_review_row_id": 132,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 4: Australian seller to an overseas customer",
  "source_keys": [
    "AUBAS"
  ]
}
```

### 133

Do not put every exported service in G2.

```json
{
  "act_articles": {
    "ABG2": "G2 Export sales, What not to report at G2, first bullet",
    "ABG2X": "Same G2 first bullet, exception"
  },
  "conditions_context": "**Reporting correction:** ordinary GST-free remote development/design/consulting is included in G1; under full reporting, it is normally other GST-free sales in G3. G2 excludes GST-free services except the specified repair/renovation/modification/treatment of overseas goods destined outside Australia. Do not put every exported service in G2. Simpler BAS uses the applicable simplified labels rather than requiring G2/G3. Sources: ATO BAS G1-G3 instructions, [official source]; reporting-method guidance, [official source].",
  "evidence_entry_ids": [
    "ABG2",
    "ABG2X"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 133,
  "line": 142,
  "original_review_exact_claim": "Do not put every exported service in G2.",
  "original_review_row_id": 133,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 4: Australian seller to an overseas customer",
  "source_keys": [
    "AUBAS"
  ]
}
```

### 134

Simpler BAS uses the applicable simplified labels rather than requiring G2/G3.

```json
{
  "act_articles": {
    "ASIMPLE": "GST reporting methods / Simpler BAS / What to report, complete three-label list"
  },
  "conditions_context": "**Reporting correction:** ordinary GST-free remote development/design/consulting is included in G1; under full reporting, it is normally other GST-free sales in G3. G2 excludes GST-free services except the specified repair/renovation/modification/treatment of overseas goods destined outside Australia. Do not put every exported service in G2. Simpler BAS uses the applicable simplified labels rather than requiring G2/G3. Sources: ATO BAS G1-G3 instructions, [official source]; reporting-method guidance, [official source].",
  "evidence_entry_ids": [
    "ASIMPLE"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "Complete three-label list supports the simplified reporting-method distinction; this is not a newly invented numerical eligibility threshold.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 134,
  "line": 142,
  "original_review_exact_claim": "Simpler BAS uses the applicable simplified labels rather than requiring G2/G3.",
  "original_review_row_id": 134,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 4: Australian seller to an overseas customer",
  "source_keys": [
    "AUSIMPLE"
  ]
}
```

### 135

Sources: ATO BAS G1-G3 instructions, [official source]; reporting-method guidance, [official source].

```json
{
  "act_articles": {
    "ABG1": "G1 total sales, accounts/calculation-method GST-free-sales bullets",
    "ABG2": "G2 Export sales, What not to report at G2, first bullet",
    "ABG2X": "Same G2 first bullet, exception",
    "ABG3": "G3 Other GST-free sales, What to report at G3",
    "ASIMPLE": "GST reporting methods / Simpler BAS / What to report, complete three-label list"
  },
  "conditions_context": "**Reporting correction:** ordinary GST-free remote development/design/consulting is included in G1; under full reporting, it is normally other GST-free sales in G3. G2 excludes GST-free services except the specified repair/renovation/modification/treatment of overseas goods destined outside Australia. Do not put every exported service in G2. Simpler BAS uses the applicable simplified labels rather than requiring G2/G3. Sources: ATO BAS G1-G3 instructions, [official source]; reporting-method guidance, [official source].",
  "evidence_entry_ids": [
    "ABG1",
    "ABG3",
    "ABG2",
    "ABG2X",
    "ASIMPLE"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 135,
  "line": 142,
  "original_review_exact_claim": "Sources: ATO BAS G1-G3 instructions, [official source]; reporting-method guidance, [official source].",
  "original_review_row_id": 135,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 4: Australian seller to an overseas customer",
  "source_keys": [
    "AUBAS",
    "AUSIMPLE"
  ]
}
```

### 136

**Original common scenario:** an Australian developer works from Australia for a US company, with the software used in the US.

```json
{
  "act_articles": {},
  "conditions_context": "**Original common scenario:** an Australian developer works from Australia for a US company, with the software used in the US. Subject to proving the non-resident/absence facts, no excluded local goods/property connection, and the third-party/exclusion checks above, item 2(a) can give GST-free treatment. Invoice the agreed AUD amount without GST. The supplier's Australian workplace is not itself a failure of the item. Source: [official source].",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 136,
  "line": 144,
  "original_review_exact_claim": "**Original common scenario:** an Australian developer works from Australia for a US company, with the software used in the US.",
  "original_review_row_id": 136,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 4: Australian seller to an overseas customer",
  "source_keys": [
    "POLICY"
  ]
}
```

### 137

Subject to proving the non-resident/absence facts, no excluded local goods/property connection, and the third-party/exclusion checks above, item 2(a) can give GST-free treatment.

```json
{
  "act_articles": {
    "AU2A": "s38-190(1), item2(a)",
    "AU2ABS": "s38-190(1), item2 chapeau",
    "AU2ALAND": "s38-190(1), item2(a), land condition",
    "AU2AWHENDONE": "s38-190(1) item2(a), timing of local work",
    "AULOCAL": "s38-190(3)(b), local provision",
    "AULOCALA": "s38-190(3)(a), nonresident agreement",
    "AULOCALC": "s38-190(3)(c), input-taxed limitation on exceptions",
    "AULOCALX": "s38-190(3)(c)(i), business-recipient exception",
    "AULOCALX2": "s38-190(3)(c)(ii), employee/officer alternative",
    "AULOCALX3": "s38-190(3)(c)(iii), recipient creditable-purpose alternative",
    "AUPROP": "s38-190(2A), input-taxed property exclusion",
    "AUPROPALL": "s38-190(2A), item/application extent",
    "AUPROPITEMS": "s38-190(2A), items2-4",
    "AURIGHT": "s38-190(2), rights/options exclusion",
    "AUSCOPE": "s38-190(1), chapeau",
    "AUSCOPEEX": "s38-190(1), chapeau, exclusions"
  },
  "conditions_context": "**Original common scenario:** an Australian developer works from Australia for a US company, with the software used in the US. Subject to proving the non-resident/absence facts, no excluded local goods/property connection, and the third-party/exclusion checks above, item 2(a) can give GST-free treatment. Invoice the agreed AUD amount without GST. The supplier's Australian workplace is not itself a failure of the item. Source: [official source].",
  "evidence_entry_ids": [
    "AUSCOPE",
    "AUSCOPEEX",
    "AU2ABS",
    "AU2A",
    "AU2AWHENDONE",
    "AU2ALAND",
    "AURIGHT",
    "AUPROPALL",
    "AUPROPITEMS",
    "AUPROP",
    "AULOCALA",
    "AULOCAL",
    "AULOCALC",
    "AULOCALX",
    "AULOCALX2",
    "AULOCALX3"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "Identical item2(a) application under the expressly proved facts; agreed AUD amount is a hypothetical contractual input, not an official figure.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "2(a)"
  ],
  "id": 137,
  "line": 144,
  "original_review_exact_claim": "Subject to proving the non-resident/absence facts, no excluded local goods/property connection, and the third-party/exclusion checks above, item 2(a) can give GST-free treatment.",
  "original_review_row_id": 137,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 4: Australian seller to an overseas customer",
  "source_keys": [
    "AU"
  ]
}
```

### 138

Invoice the agreed AUD amount without GST.

```json
{
  "act_articles": {
    "AU2A": "s38-190(1), item2(a)",
    "AU2ABS": "s38-190(1), item2 chapeau",
    "AU2ALAND": "s38-190(1), item2(a), land condition",
    "AU2AWHENDONE": "s38-190(1) item2(a), timing of local work",
    "AULOCAL": "s38-190(3)(b), local provision",
    "AULOCALA": "s38-190(3)(a), nonresident agreement",
    "AULOCALC": "s38-190(3)(c), input-taxed limitation on exceptions",
    "AULOCALX": "s38-190(3)(c)(i), business-recipient exception",
    "AULOCALX2": "s38-190(3)(c)(ii), employee/officer alternative",
    "AULOCALX3": "s38-190(3)(c)(iii), recipient creditable-purpose alternative",
    "AUPROP": "s38-190(2A), input-taxed property exclusion",
    "AUPROPALL": "s38-190(2A), item/application extent",
    "AUPROPITEMS": "s38-190(2A), items2-4",
    "AURIGHT": "s38-190(2), rights/options exclusion",
    "AUSCOPE": "s38-190(1), chapeau",
    "AUSCOPEEX": "s38-190(1), chapeau, exclusions"
  },
  "conditions_context": "**Original common scenario:** an Australian developer works from Australia for a US company, with the software used in the US. Subject to proving the non-resident/absence facts, no excluded local goods/property connection, and the third-party/exclusion checks above, item 2(a) can give GST-free treatment. Invoice the agreed AUD amount without GST. The supplier's Australian workplace is not itself a failure of the item. Source: [official source].",
  "evidence_entry_ids": [
    "AUSCOPE",
    "AUSCOPEEX",
    "AU2ABS",
    "AU2A",
    "AU2AWHENDONE",
    "AU2ALAND",
    "AURIGHT",
    "AUPROPALL",
    "AUPROPITEMS",
    "AUPROP",
    "AULOCALA",
    "AULOCAL",
    "AULOCALC",
    "AULOCALX",
    "AULOCALX2",
    "AULOCALX3"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "Identical item2(a) application under the expressly proved facts; agreed AUD amount is a hypothetical contractual input, not an official figure.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 138,
  "line": 144,
  "original_review_exact_claim": "Invoice the agreed AUD amount without GST.",
  "original_review_row_id": 138,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 4: Australian seller to an overseas customer",
  "source_keys": [
    "AU"
  ]
}
```

### 139

The supplier's Australian workplace is not itself a failure of the item.

```json
{
  "act_articles": {
    "AU2A": "s38-190(1), item2(a)",
    "AU2ABS": "s38-190(1), item2 chapeau",
    "AU2ALAND": "s38-190(1), item2(a), land condition",
    "AU2AWHENDONE": "s38-190(1) item2(a), timing of local work",
    "AULOCAL": "s38-190(3)(b), local provision",
    "AULOCALA": "s38-190(3)(a), nonresident agreement",
    "AULOCALC": "s38-190(3)(c), input-taxed limitation on exceptions",
    "AULOCALX": "s38-190(3)(c)(i), business-recipient exception",
    "AULOCALX2": "s38-190(3)(c)(ii), employee/officer alternative",
    "AULOCALX3": "s38-190(3)(c)(iii), recipient creditable-purpose alternative",
    "AUPROP": "s38-190(2A), input-taxed property exclusion",
    "AUPROPALL": "s38-190(2A), item/application extent",
    "AUPROPITEMS": "s38-190(2A), items2-4",
    "AURIGHT": "s38-190(2), rights/options exclusion",
    "AUSCOPE": "s38-190(1), chapeau",
    "AUSCOPEEX": "s38-190(1), chapeau, exclusions"
  },
  "conditions_context": "**Original common scenario:** an Australian developer works from Australia for a US company, with the software used in the US. Subject to proving the non-resident/absence facts, no excluded local goods/property connection, and the third-party/exclusion checks above, item 2(a) can give GST-free treatment. Invoice the agreed AUD amount without GST. The supplier's Australian workplace is not itself a failure of the item. Source: [official source].",
  "evidence_entry_ids": [
    "AUSCOPE",
    "AUSCOPEEX",
    "AU2ABS",
    "AU2A",
    "AU2AWHENDONE",
    "AU2ALAND",
    "AURIGHT",
    "AUPROPALL",
    "AUPROPITEMS",
    "AUPROP",
    "AULOCALA",
    "AULOCAL",
    "AULOCALC",
    "AULOCALX",
    "AULOCALX2",
    "AULOCALX3"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "Identical item2(a) application under the expressly proved facts; agreed AUD amount is a hypothetical contractual input, not an official figure.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 139,
  "line": 144,
  "original_review_exact_claim": "The supplier's Australian workplace is not itself a failure of the item.",
  "original_review_row_id": 139,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 4: Australian seller to an overseas customer",
  "source_keys": [
    "AU"
  ]
}
```

### 140

Source: [official source].

```json
{
  "act_articles": {
    "AU2A": "s38-190(1), item2(a)",
    "AU2ABS": "s38-190(1), item2 chapeau",
    "AU2ALAND": "s38-190(1), item2(a), land condition",
    "AU2AWHENDONE": "s38-190(1) item2(a), timing of local work",
    "AULOCAL": "s38-190(3)(b), local provision",
    "AULOCALA": "s38-190(3)(a), nonresident agreement",
    "AULOCALC": "s38-190(3)(c), input-taxed limitation on exceptions",
    "AULOCALX": "s38-190(3)(c)(i), business-recipient exception",
    "AULOCALX2": "s38-190(3)(c)(ii), employee/officer alternative",
    "AULOCALX3": "s38-190(3)(c)(iii), recipient creditable-purpose alternative",
    "AUPROP": "s38-190(2A), input-taxed property exclusion",
    "AUPROPALL": "s38-190(2A), item/application extent",
    "AUPROPITEMS": "s38-190(2A), items2-4",
    "AURIGHT": "s38-190(2), rights/options exclusion",
    "AUSCOPE": "s38-190(1), chapeau",
    "AUSCOPEEX": "s38-190(1), chapeau, exclusions"
  },
  "conditions_context": "**Original common scenario:** an Australian developer works from Australia for a US company, with the software used in the US. Subject to proving the non-resident/absence facts, no excluded local goods/property connection, and the third-party/exclusion checks above, item 2(a) can give GST-free treatment. Invoice the agreed AUD amount without GST. The supplier's Australian workplace is not itself a failure of the item. Source: [official source].",
  "evidence_entry_ids": [
    "AUSCOPE",
    "AUSCOPEEX",
    "AU2ABS",
    "AU2A",
    "AU2AWHENDONE",
    "AU2ALAND",
    "AURIGHT",
    "AUPROPALL",
    "AUPROPITEMS",
    "AUPROP",
    "AULOCALA",
    "AULOCAL",
    "AULOCALC",
    "AULOCALX",
    "AULOCALX2",
    "AULOCALX3"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 140,
  "line": 144,
  "original_review_exact_claim": "Source: [official source].",
  "original_review_row_id": 140,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 4: Australian seller to an overseas customer",
  "source_keys": [
    "AU"
  ]
}
```

### 141

All 5 IGST section 2(6) conditions (derived count of its enumerated requirements) must hold, not just a foreign customer and an LUT:

```json
{
  "act_articles": {
    "IN2FE": "IGST2(14)(c), relevant establishment",
    "IN2I": "IGST2(6)(i)",
    "IN2II": "IGST2(6)(ii)",
    "IN2III": "IGST2(6)(iii)",
    "IN2IV": "IGST2(6)(iv), as amended2018",
    "IN2V": "IGST2(6)(v)",
    "IN8EX": "IGST8Explanation1(i)"
  },
  "conditions_context": "All 5 IGST section 2(6) conditions (derived count of its enumerated requirements) must hold, not just a foreign customer and an LUT:",
  "evidence_entry_ids": [
    "IN2I",
    "IN2II",
    "IN2III",
    "IN2IV",
    "IN2V",
    "IN8EX",
    "IN2FE"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "Five is a recomputed count of IGST2(6)(i)-(v), not an invented threshold. Other old source keys on this row do not prove the count and should be removed from this specific count assertion.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "5",
    "2(6)"
  ],
  "id": 141,
  "line": 148,
  "original_review_exact_claim": "All 5 IGST section 2(6) conditions (derived count of its enumerated requirements) must hold, not just a foreign customer and an LUT:",
  "original_review_row_id": 141,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 5: Indian seller to a non-Indian customer",
  "source_keys": [
    "IN"
  ]
}
```

### 142

| Supplier | Located in India | https://thc.nic.in/Central%20Governmental%20Acts/Integrated%20Goods%20and%20Services%20Tax%20Act%2C%202017..pdf |

```json
{
  "act_articles": {
    "IN2I": "IGST2(6)(i)"
  },
  "conditions_context": "| Supplier | Located in India | [official source] |",
  "evidence_entry_ids": [
    "IN2I"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "20",
    "20",
    "20",
    "20",
    "20",
    "20",
    "20",
    "2",
    "202017.."
  ],
  "id": 142,
  "line": 152,
  "original_review_exact_claim": "| Supplier | Located in India | https://thc.nic.in/Central%20Governmental%20Acts/Integrated%20Goods%20and%20Services%20Tax%20Act%2C%202017..pdf |",
  "original_review_row_id": 142,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 5: Indian seller to a non-Indian customer",
  "source_keys": [
    "IN"
  ]
}
```

### 143

| Recipient | Located outside India, based on the relevant establishment | https://thc.nic.in/Central%20Governmental%20Acts/Integrated%20Goods%20and%20Services%20Tax%20Act%2C%202017..pdf |

```json
{
  "act_articles": {
    "IN2FE": "IGST2(14)(c), relevant establishment",
    "IN2II": "IGST2(6)(ii)"
  },
  "conditions_context": "| Recipient | Located outside India, based on the relevant establishment | [official source] |",
  "evidence_entry_ids": [
    "IN2II",
    "IN2FE"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "20",
    "20",
    "20",
    "20",
    "20",
    "20",
    "20",
    "2",
    "202017.."
  ],
  "id": 143,
  "line": 153,
  "original_review_exact_claim": "| Recipient | Located outside India, based on the relevant establishment | https://thc.nic.in/Central%20Governmental%20Acts/Integrated%20Goods%20and%20Services%20Tax%20Act%2C%202017..pdf |",
  "original_review_row_id": 143,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 5: Indian seller to a non-Indian customer",
  "source_keys": [
    "IN"
  ]
}
```

### 144

| Place of supply | Outside India under section 13 and the applicable current exception | https://thc.nic.in/Central%20Governmental%20Acts/Integrated%20Goods%20and%20Services%20Tax%20Act%2C%202017..pdf ; https://egazette.gov.in/WriteReadData/2026/271439.pdf |

```json
{
  "act_articles": {
    "GCAPRES": "GeneralClausesAct1897 section5(1)(b), same page",
    "GCASSENT": "GeneralClausesAct1897 section5(1), Mumbai Port copy PDFp9",
    "IN13BASE": "IGST13(2), general rule",
    "IN13EVENT": "IGST13(5), scan PDFpage17",
    "IN13FALL": "IGST13(2), proviso",
    "IN13LAND": "IGST13(4)",
    "IN13PHYS": "IGST13(3)(b), physical presence",
    "IN2III": "IGST2(6)(iii)",
    "INASSENT": "FinanceAct2026 Gazette title/assent",
    "INCOMMENCEA": "FinanceAct2026 section1(2)(a)",
    "INCOMMENCEB": "FinanceAct2026 section1(2)(b)",
    "INOMIT": "FinanceAct2026 section157"
  },
  "conditions_context": "| Place of supply | Outside India under section 13 and the applicable current exception | [official source] ; [official source] |",
  "evidence_entry_ids": [
    "IN2III",
    "IN13BASE",
    "IN13FALL",
    "IN13PHYS",
    "IN13LAND",
    "IN13EVENT",
    "INOMIT",
    "INASSENT",
    "INCOMMENCEA",
    "INCOMMENCEB",
    "GCASSENT",
    "GCAPRES"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "13",
    "20",
    "20",
    "20",
    "20",
    "20",
    "20",
    "20",
    "2",
    "202017..",
    "2026",
    "271439."
  ],
  "id": 144,
  "line": 154,
  "original_review_exact_claim": "| Place of supply | Outside India under section 13 and the applicable current exception | https://thc.nic.in/Central%20Governmental%20Acts/Integrated%20Goods%20and%20Services%20Tax%20Act%2C%202017..pdf ; https://egazette.gov.in/WriteReadData/2026/271439.pdf |",
  "original_review_row_id": 144,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 5: Indian seller to a non-Indian customer",
  "source_keys": [
    "IN",
    "IN2026",
    "INGCA"
  ]
}
```

### 145

| Payment | Received in convertible foreign exchange or INR wherever permitted by RBI; monitor the applicable receipt period | https://thc.nic.in/Central%20Governmental%20Acts/Integrated%20Goods%20and%20Services%20Tax%20Act%2C%202017..pdf ; https://gstcouncil.gov.in/sites/default/files/2024-09/central-tax-12-2024-11072024.pdf |

```json
{
  "act_articles": {
    "IN2IV": "IGST2(6)(iv), as amended2018",
    "IN96COMM": "Same substituted96A(1)(b), Commissioner extension",
    "IN96FEMA": "Same substituted96A(1)(b), FEMA/RBI later-period limb",
    "IN96INVOICE": "Notification12/2024 rule20(i), invoice starting date",
    "IN96PAY": "Same substituted96A(1)(b), payment qualification",
    "IN96TIME": "Notification12/2024-CentralTax rule20(i), substituted96A(1)(b)"
  },
  "conditions_context": "| Payment | Received in convertible foreign exchange or INR wherever permitted by RBI; monitor the applicable receipt period | [official source] ; [official source] |",
  "evidence_entry_ids": [
    "IN2IV",
    "IN96TIME",
    "IN96FEMA",
    "IN96INVOICE",
    "IN96COMM",
    "IN96PAY"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "20",
    "20",
    "20",
    "20",
    "20",
    "20",
    "20",
    "2",
    "202017..",
    "2024",
    "09",
    "12",
    "2024",
    "11072024."
  ],
  "id": 145,
  "line": 155,
  "original_review_exact_claim": "| Payment | Received in convertible foreign exchange or INR wherever permitted by RBI; monitor the applicable receipt period | https://thc.nic.in/Central%20Governmental%20Acts/Integrated%20Goods%20and%20Services%20Tax%20Act%2C%202017..pdf ; https://gstcouncil.gov.in/sites/default/files/2024-09/central-tax-12-2024-11072024.pdf |",
  "original_review_row_id": 145,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 5: Indian seller to a non-Indian customer",
  "source_keys": [
    "IN",
    "IN96"
  ]
}
```

### 146

| Distinct establishments | Supplier and recipient are not merely establishments of a distinct person under section 8 Explanation 1; a separately incorporated foreign customer is not automatically the same person's establishment | https://thc.nic.in/Central%20Governmental%20Acts/Integrated%20Goods%20and%20Services%20Tax%20Act%2C%202017..pdf ; https://cbic-gst.gov.in/pdf/Circular-No-161-14-2021-GST.pdf |

```json
{
  "act_articles": {
    "IN2V": "IGST2(6)(v)",
    "IN8EX": "IGST8Explanation1(i)",
    "INBRANCH": "Circular161/17/2021 paragraph4.3, same-company establishments",
    "INSEPARATE": "Circular161/17/2021 paragraph5.1, incorporated companies"
  },
  "conditions_context": "| Distinct establishments | Supplier and recipient are not merely establishments of a distinct person under section 8 Explanation 1; a separately incorporated foreign customer is not automatically the same person's establishment | [official source] ; [official source] |",
  "evidence_entry_ids": [
    "IN2V",
    "IN8EX",
    "INSEPARATE",
    "INBRANCH"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "8",
    "1",
    "20",
    "20",
    "20",
    "20",
    "20",
    "20",
    "20",
    "2",
    "202017..",
    "161",
    "14",
    "2021"
  ],
  "id": 146,
  "line": 156,
  "original_review_exact_claim": "| Distinct establishments | Supplier and recipient are not merely establishments of a distinct person under section 8 Explanation 1; a separately incorporated foreign customer is not automatically the same person's establishment | https://thc.nic.in/Central%20Governmental%20Acts/Integrated%20Goods%20and%20Services%20Tax%20Act%2C%202017..pdf ; https://cbic-gst.gov.in/pdf/Circular-No-161-14-2021-GST.pdf |",
  "original_review_row_id": 146,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 5: Indian seller to a non-Indian customer",
  "source_keys": [
    "IN",
    "INPERSON"
  ]
}
```

### 147

Section 13(2) normally uses recipient location, with a supplier-location fallback if recipient location is unavailable in the ordinary course.

```json
{
  "act_articles": {
    "IN13BASE": "IGST13(2), general rule",
    "IN13FALL": "IGST13(2), proviso"
  },
  "conditions_context": "Section 13(2) normally uses recipient location, with a supplier-location fallback if recipient location is unavailable in the ordinary course. Goods-work/physical-presence services, immovable property, events and the remaining special rules can change the place. The former intermediary-services clause in section 13(8)(b) was **omitted by Finance Act 2026 section 157, from 30 March 2026**; do not apply an older consolidated scan's intermediary supplier-location rule to a current transaction without that overlay. The date follows presidential assent: section 157 has no separate delayed commencement under Finance Act section 1, so General Clauses Act section 5 supplies the assent-date default. Other section 13 conditions still apply; omission alone does not prove every export condition. Sources: [official source]; Finance Act commencement/section 157, [official source]; General Clauses Act section 5, [official source].",
  "evidence_entry_ids": [
    "IN13BASE",
    "IN13FALL"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "13(2)"
  ],
  "id": 147,
  "line": 158,
  "original_review_exact_claim": "Section 13(2) normally uses recipient location, with a supplier-location fallback if recipient location is unavailable in the ordinary course.",
  "original_review_row_id": 147,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 5: Indian seller to a non-Indian customer",
  "source_keys": [
    "IN"
  ]
}
```

### 148

Goods-work/physical-presence services, immovable property, events and the remaining special rules can change the place.

```json
{
  "act_articles": {
    "IN13EVENT": "IGST13(5), scan PDFpage17",
    "IN13GOODS": "IGST13(3)(a), scanPDFpage16, goods availability and both provisos",
    "IN13LAND": "IGST13(4)",
    "IN13PHYS": "IGST13(3)(b), physical presence"
  },
  "conditions_context": "Section 13(2) normally uses recipient location, with a supplier-location fallback if recipient location is unavailable in the ordinary course. Goods-work/physical-presence services, immovable property, events and the remaining special rules can change the place. The former intermediary-services clause in section 13(8)(b) was **omitted by Finance Act 2026 section 157, from 30 March 2026**; do not apply an older consolidated scan's intermediary supplier-location rule to a current transaction without that overlay. The date follows presidential assent: section 157 has no separate delayed commencement under Finance Act section 1, so General Clauses Act section 5 supplies the assent-date default. Other section 13 conditions still apply; omission alone does not prove every export condition. Sources: [official source]; Finance Act commencement/section 157, [official source]; General Clauses Act section 5, [official source].",
  "evidence_entry_ids": [
    "IN13PHYS",
    "IN13LAND",
    "IN13EVENT",
    "IN13GOODS"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "Other special rules are a referral, not a claim that the three listed exceptions are exhaustive. See IN13GOODS extra extract for goods-work condition.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 148,
  "line": 158,
  "original_review_exact_claim": "Goods-work/physical-presence services, immovable property, events and the remaining special rules can change the place.",
  "original_review_row_id": 148,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 5: Indian seller to a non-Indian customer",
  "source_keys": [
    "IN"
  ]
}
```

### 149

The former intermediary-services clause in section 13(8)(b) was **omitted by Finance Act 2026 section 157, from 30 March 2026**; do not apply an older consolidated scan's intermediary supplier-location rule to a current transaction without that overlay.

```json
{
  "act_articles": {
    "GCAPRES": "GeneralClausesAct1897 section5(1)(b), same page",
    "GCASSENT": "GeneralClausesAct1897 section5(1), Mumbai Port copy PDFp9",
    "INASSENT": "FinanceAct2026 Gazette title/assent",
    "INCOMMENCEA": "FinanceAct2026 section1(2)(a)",
    "INCOMMENCEB": "FinanceAct2026 section1(2)(b)",
    "INOMIT": "FinanceAct2026 section157"
  },
  "conditions_context": "Section 13(2) normally uses recipient location, with a supplier-location fallback if recipient location is unavailable in the ordinary course. Goods-work/physical-presence services, immovable property, events and the remaining special rules can change the place. The former intermediary-services clause in section 13(8)(b) was **omitted by Finance Act 2026 section 157, from 30 March 2026**; do not apply an older consolidated scan's intermediary supplier-location rule to a current transaction without that overlay. The date follows presidential assent: section 157 has no separate delayed commencement under Finance Act section 1, so General Clauses Act section 5 supplies the assent-date default. Other section 13 conditions still apply; omission alone does not prove every export condition. Sources: [official source]; Finance Act commencement/section 157, [official source]; General Clauses Act section 5, [official source].",
  "evidence_entry_ids": [
    "INOMIT",
    "INASSENT",
    "INCOMMENCEA",
    "INCOMMENCEB",
    "GCASSENT",
    "GCAPRES"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "Assent-date commencement is derived by reading FinanceAct1(2) delayed lists and157 together with GeneralClausesAct5; no single generic assent quote is sufficient by itself. Older IGSTscan is overlaid, not claimed current on this clause.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "13(8)",
    "2026",
    "157,",
    "30",
    "2026"
  ],
  "id": 149,
  "line": 158,
  "original_review_exact_claim": "The former intermediary-services clause in section 13(8)(b) was **omitted by Finance Act 2026 section 157, from 30 March 2026**; do not apply an older consolidated scan's intermediary supplier-location rule to a current transaction without that overlay.",
  "original_review_row_id": 149,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 5: Indian seller to a non-Indian customer",
  "source_keys": [
    "IN2026",
    "INGCA"
  ]
}
```

### 150

The date follows presidential assent: section 157 has no separate delayed commencement under Finance Act section 1, so General Clauses Act section 5 supplies the assent-date default.

```json
{
  "act_articles": {
    "GCAPRES": "GeneralClausesAct1897 section5(1)(b), same page",
    "GCASSENT": "GeneralClausesAct1897 section5(1), Mumbai Port copy PDFp9",
    "INASSENT": "FinanceAct2026 Gazette title/assent",
    "INCOMMENCEA": "FinanceAct2026 section1(2)(a)",
    "INCOMMENCEB": "FinanceAct2026 section1(2)(b)",
    "INOMIT": "FinanceAct2026 section157"
  },
  "conditions_context": "Section 13(2) normally uses recipient location, with a supplier-location fallback if recipient location is unavailable in the ordinary course. Goods-work/physical-presence services, immovable property, events and the remaining special rules can change the place. The former intermediary-services clause in section 13(8)(b) was **omitted by Finance Act 2026 section 157, from 30 March 2026**; do not apply an older consolidated scan's intermediary supplier-location rule to a current transaction without that overlay. The date follows presidential assent: section 157 has no separate delayed commencement under Finance Act section 1, so General Clauses Act section 5 supplies the assent-date default. Other section 13 conditions still apply; omission alone does not prove every export condition. Sources: [official source]; Finance Act commencement/section 157, [official source]; General Clauses Act section 5, [official source].",
  "evidence_entry_ids": [
    "INOMIT",
    "INASSENT",
    "INCOMMENCEA",
    "INCOMMENCEB",
    "GCASSENT",
    "GCAPRES"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "157",
    "1,",
    "5"
  ],
  "id": 150,
  "line": 158,
  "original_review_exact_claim": "The date follows presidential assent: section 157 has no separate delayed commencement under Finance Act section 1, so General Clauses Act section 5 supplies the assent-date default.",
  "original_review_row_id": 150,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 5: Indian seller to a non-Indian customer",
  "source_keys": [
    "IN2026",
    "INGCA"
  ]
}
```

### 151

Other section 13 conditions still apply; omission alone does not prove every export condition.

```json
{
  "act_articles": {
    "GCAPRES": "GeneralClausesAct1897 section5(1)(b), same page",
    "GCASSENT": "GeneralClausesAct1897 section5(1), Mumbai Port copy PDFp9",
    "IN13BASE": "IGST13(2), general rule",
    "IN13EVENT": "IGST13(5), scan PDFpage17",
    "IN13FALL": "IGST13(2), proviso",
    "IN13LAND": "IGST13(4)",
    "IN13PHYS": "IGST13(3)(b), physical presence",
    "IN2FE": "IGST2(14)(c), relevant establishment",
    "IN2I": "IGST2(6)(i)",
    "IN2II": "IGST2(6)(ii)",
    "IN2III": "IGST2(6)(iii)",
    "IN2IV": "IGST2(6)(iv), as amended2018",
    "IN2V": "IGST2(6)(v)",
    "IN8EX": "IGST8Explanation1(i)",
    "INASSENT": "FinanceAct2026 Gazette title/assent",
    "INCOMMENCEA": "FinanceAct2026 section1(2)(a)",
    "INCOMMENCEB": "FinanceAct2026 section1(2)(b)",
    "INOMIT": "FinanceAct2026 section157"
  },
  "conditions_context": "Section 13(2) normally uses recipient location, with a supplier-location fallback if recipient location is unavailable in the ordinary course. Goods-work/physical-presence services, immovable property, events and the remaining special rules can change the place. The former intermediary-services clause in section 13(8)(b) was **omitted by Finance Act 2026 section 157, from 30 March 2026**; do not apply an older consolidated scan's intermediary supplier-location rule to a current transaction without that overlay. The date follows presidential assent: section 157 has no separate delayed commencement under Finance Act section 1, so General Clauses Act section 5 supplies the assent-date default. Other section 13 conditions still apply; omission alone does not prove every export condition. Sources: [official source]; Finance Act commencement/section 157, [official source]; General Clauses Act section 5, [official source].",
  "evidence_entry_ids": [
    "IN2I",
    "IN2II",
    "IN2III",
    "IN2IV",
    "IN2V",
    "IN8EX",
    "IN2FE",
    "IN13BASE",
    "IN13FALL",
    "IN13PHYS",
    "IN13LAND",
    "IN13EVENT",
    "INOMIT",
    "INASSENT",
    "INCOMMENCEA",
    "INCOMMENCEB",
    "GCASSENT",
    "GCAPRES"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "13"
  ],
  "id": 151,
  "line": 158,
  "original_review_exact_claim": "Other section 13 conditions still apply; omission alone does not prove every export condition.",
  "original_review_row_id": 151,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 5: Indian seller to a non-Indian customer",
  "source_keys": [
    "IN",
    "IN2026",
    "INGCA"
  ]
}
```

### 152

Sources: [official source]; Finance Act commencement/section 157, [official source]; General Clauses Act section 5, [official source].

```json
{
  "act_articles": {
    "GCAPRES": "GeneralClausesAct1897 section5(1)(b), same page",
    "GCASSENT": "GeneralClausesAct1897 section5(1), Mumbai Port copy PDFp9",
    "IN13BASE": "IGST13(2), general rule",
    "IN13EVENT": "IGST13(5), scan PDFpage17",
    "IN13FALL": "IGST13(2), proviso",
    "IN13LAND": "IGST13(4)",
    "IN13PHYS": "IGST13(3)(b), physical presence",
    "IN2FE": "IGST2(14)(c), relevant establishment",
    "IN2I": "IGST2(6)(i)",
    "IN2II": "IGST2(6)(ii)",
    "IN2III": "IGST2(6)(iii)",
    "IN2IV": "IGST2(6)(iv), as amended2018",
    "IN2V": "IGST2(6)(v)",
    "IN8EX": "IGST8Explanation1(i)",
    "INASSENT": "FinanceAct2026 Gazette title/assent",
    "INCOMMENCEA": "FinanceAct2026 section1(2)(a)",
    "INCOMMENCEB": "FinanceAct2026 section1(2)(b)",
    "INOMIT": "FinanceAct2026 section157"
  },
  "conditions_context": "Section 13(2) normally uses recipient location, with a supplier-location fallback if recipient location is unavailable in the ordinary course. Goods-work/physical-presence services, immovable property, events and the remaining special rules can change the place. The former intermediary-services clause in section 13(8)(b) was **omitted by Finance Act 2026 section 157, from 30 March 2026**; do not apply an older consolidated scan's intermediary supplier-location rule to a current transaction without that overlay. The date follows presidential assent: section 157 has no separate delayed commencement under Finance Act section 1, so General Clauses Act section 5 supplies the assent-date default. Other section 13 conditions still apply; omission alone does not prove every export condition. Sources: [official source]; Finance Act commencement/section 157, [official source]; General Clauses Act section 5, [official source].",
  "evidence_entry_ids": [
    "IN2I",
    "IN2II",
    "IN2III",
    "IN2IV",
    "IN2V",
    "IN8EX",
    "IN2FE",
    "IN13BASE",
    "IN13FALL",
    "IN13PHYS",
    "IN13LAND",
    "IN13EVENT",
    "INOMIT",
    "INASSENT",
    "INCOMMENCEA",
    "INCOMMENCEB",
    "GCASSENT",
    "GCAPRES"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "157,",
    "5,"
  ],
  "id": 152,
  "line": 158,
  "original_review_exact_claim": "Sources: [official source]; Finance Act commencement/section 157, [official source]; General Clauses Act section 5, [official source].",
  "original_review_row_id": 152,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 5: Indian seller to a non-Indian customer",
  "source_keys": [
    "IN",
    "IN2026",
    "INGCA"
  ]
}
```

### 153

| Without payment under bond/LUT | Section 16(3) and rule 96A require the compliant route; use FORM GST RFD-11 before export, subject to permitted condonation. LUT is for its financial year; otherwise an eligible bond route may be required | https://thc.nic.in/Central%20Governmental%20Acts/Integrated%20Goods%20and%20Services%20Tax%20Act%2C%202017..pdf ; https://cbic-gst.gov.in/pdf/Final_Master_circular_LUT_Bond_04102017.pdf ; https://cbic-gst.gov.in/pdf/circularno-40-cgst.pdf |

```json
{
  "act_articles": {
    "IN16EXPORT": "IGST16(1)(a)",
    "IN16LUT": "IGST16(3), bond/LUT route",
    "IN250": "Same condition(i), strict threshold",
    "INARN": "Same substituted2(c)/(e), deemed acceptance",
    "INARNREJECT": "Same substituted2(e), ineligible LUT rejection",
    "INCONDONE": "Circular37/11/2018 paragraph4.1",
    "INCONDONEFACTS": "Same paragraph4.1, individual-facts qualification",
    "INLUTPRIOR": "Circular8/8/2017 paragraph2(e), prior requirement",
    "INLUTYEAR": "Circular8/8/2017 paragraph2(b)",
    "INPROSEC": "Notification37/2017 condition(i), prosecution exclusion",
    "INRFD": "Circular40/14/2018 paragraph2 substituted2(c)"
  },
  "conditions_context": "| Without payment under bond/LUT | Section 16(3) and rule 96A require the compliant route; use FORM GST RFD-11 before export, subject to permitted condonation. LUT is for its financial year; otherwise an eligible bond route may be required | [official source] ; [official source] ; [official source] |",
  "evidence_entry_ids": [
    "IN16EXPORT",
    "IN16LUT",
    "INLUTYEAR",
    "INLUTPRIOR",
    "INPROSEC",
    "IN250",
    "INRFD",
    "INARN",
    "INARNREJECT",
    "INCONDONE",
    "INCONDONEFACTS"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "Before-export requirement and financial-year rule are supported separately; condonation is facts-dependent, not automatic.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "16(3)",
    "96",
    "11",
    "20",
    "20",
    "20",
    "20",
    "20",
    "20",
    "20",
    "2",
    "202017..",
    "04102017.",
    "40"
  ],
  "id": 153,
  "line": 162,
  "original_review_exact_claim": "| Without payment under bond/LUT | Section 16(3) and rule 96A require the compliant route; use FORM GST RFD-11 before export, subject to permitted condonation. LUT is for its financial year; otherwise an eligible bond route may be required | https://thc.nic.in/Central%20Governmental%20Acts/Integrated%20Goods%20and%20Services%20Tax%20Act%2C%202017..pdf ; https://cbic-gst.gov.in/pdf/Final_Master_circular_LUT_Bond_04102017.pdf ; https://cbic-gst.gov.in/pdf/circularno-40-cgst.pdf |",
  "original_review_row_id": 153,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 5: Indian seller to a non-Indian customer",
  "source_keys": [
    "IN",
    "INLUT",
    "IN37",
    "INONLINE",
    "INLATE"
  ]
}
```

### 154

| With payment and refund | Not a universal alternative available to everyone: section 16(4) requires the currently notified class/conditions and refund procedure. Establish eligibility before paying tax expecting a refund; current notification applicability is not cleared here | https://thc.nic.in/Central%20Governmental%20Acts/Integrated%20Goods%20and%20Services%20Tax%20Act%2C%202017..pdf |

```json
{
  "act_articles": {
    "IN16PAID": "IGST16(4), scan PDFpage22, notified class/conditions"
  },
  "conditions_context": "| With payment and refund | Not a universal alternative available to everyone: section 16(4) requires the currently notified class/conditions and refund procedure. Establish eligibility before paying tax expecting a refund; current notification applicability is not cleared here | [official source] |",
  "evidence_entry_ids": [
    "IN16PAID"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "Notification-class eligibility expressly not cleared. Native extract is visually read law, not corrupted OCR; no refund guarantee.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "16(4)",
    "20",
    "20",
    "20",
    "20",
    "20",
    "20",
    "20",
    "2",
    "202017.."
  ],
  "id": 154,
  "line": 163,
  "original_review_exact_claim": "| With payment and refund | Not a universal alternative available to everyone: section 16(4) requires the currently notified class/conditions and refund procedure. Establish eligibility before paying tax expecting a refund; current notification applicability is not cleared here | https://thc.nic.in/Central%20Governmental%20Acts/Integrated%20Goods%20and%20Services%20Tax%20Act%2C%202017..pdf |",
  "original_review_row_id": 154,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 5: Indian seller to a non-Indian customer",
  "source_keys": [
    "IN"
  ]
}
```

### 155

| Input credit / refund | Section 16(2) preserves eligible credit subject to CGST section 17(5); unutilised credit/refunds remain subject to section 54 and applicable rules/evidence. Do not promise FULL refund or adjustment of every domestic cost | https://thc.nic.in/Central%20Governmental%20Acts/Integrated%20Goods%20and%20Services%20Tax%20Act%2C%202017..pdf |

```json
{
  "act_articles": {
    "IN16INPUT": "IGST16(2), blocked-credit qualification",
    "IN16REFUND": "IGST16(3), scanPDFpage21, section54/rules qualification"
  },
  "conditions_context": "| Input credit / refund | Section 16(2) preserves eligible credit subject to CGST section 17(5); unutilised credit/refunds remain subject to section 54 and applicable rules/evidence. Do not promise FULL refund or adjustment of every domestic cost | [official source] |",
  "evidence_entry_ids": [
    "IN16INPUT",
    "IN16REFUND"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "IGST16(2)-(3) refers to CGST17(5)/54 and rules; those detailed entitlements are gated, not supplied by this Guide. See IN16REFUND extra extract for54 limitation.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "16(2)",
    "17(5)",
    "54",
    "20",
    "20",
    "20",
    "20",
    "20",
    "20",
    "20",
    "2",
    "202017.."
  ],
  "id": 155,
  "line": 164,
  "original_review_exact_claim": "| Input credit / refund | Section 16(2) preserves eligible credit subject to CGST section 17(5); unutilised credit/refunds remain subject to section 54 and applicable rules/evidence. Do not promise FULL refund or adjustment of every domestic cost | https://thc.nic.in/Central%20Governmental%20Acts/Integrated%20Goods%20and%20Services%20Tax%20Act%2C%202017..pdf |",
  "original_review_row_id": 155,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 5: Indian seller to a non-Indian customer",
  "source_keys": [
    "IN"
  ]
}
```

### 156

For an eligible exporter with qualifying zero-rated services, the original financial-year LUT recommendation is retained: use a valid LUT for the relevant financial year where its conditions are met, rather than advancing IGST under an eligible tax-paid route and awaiting its refund.

```json
{
  "act_articles": {
    "IN16LUT": "IGST16(3), bond/LUT route",
    "IN16PAID": "IGST16(4), scan PDFpage22, notified class/conditions",
    "INLUTYEAR": "Circular8/8/2017 paragraph2(b)",
    "INRFD": "Circular40/14/2018 paragraph2 substituted2(c)"
  },
  "conditions_context": "For an eligible exporter with qualifying zero-rated services, the original financial-year LUT recommendation is retained: use a valid LUT for the relevant financial year where its conditions are met, rather than advancing IGST under an eligible tax-paid route and awaiting its refund. This avoids that upfront tax/refund cash-flow cycle; it does not guarantee or accelerate a separate unutilised-input-credit refund. Eligibility, receipt and refund conditions still control. Sources: [official source]; [official source]; [official source].",
  "evidence_entry_ids": [
    "IN16LUT",
    "IN16PAID",
    "INLUTYEAR",
    "INRFD"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACTS_SUPPLIED_AUTHOR_DELTA_RECHECK_PENDING",
  "evidence_recommendation_note": "Restored F3 annual LUT recommendation. Cash-flow comparison is logical consequence of the two qualified routes; no guaranteed or accelerated input-credit refund is asserted.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 156,
  "line": 166,
  "original_review_row_id": null,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 5: Indian seller to a non-Indian customer",
  "source_keys": [
    "IN",
    "INLUT",
    "INONLINE"
  ]
}
```

### 157

This avoids that upfront tax/refund cash-flow cycle; it does not guarantee or accelerate a separate unutilised-input-credit refund.

```json
{
  "act_articles": {
    "IN16LUT": "IGST16(3), bond/LUT route",
    "IN16PAID": "IGST16(4), scan PDFpage22, notified class/conditions",
    "IN16REFUND": "IGST16(3), scanPDFpage21, section54/rules qualification"
  },
  "conditions_context": "For an eligible exporter with qualifying zero-rated services, the original financial-year LUT recommendation is retained: use a valid LUT for the relevant financial year where its conditions are met, rather than advancing IGST under an eligible tax-paid route and awaiting its refund. This avoids that upfront tax/refund cash-flow cycle; it does not guarantee or accelerate a separate unutilised-input-credit refund. Eligibility, receipt and refund conditions still control. Sources: [official source]; [official source]; [official source].",
  "evidence_entry_ids": [
    "IN16LUT",
    "IN16PAID",
    "IN16REFUND"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACTS_SUPPLIED_AUTHOR_DELTA_RECHECK_PENDING",
  "evidence_recommendation_note": "Restored F3 annual LUT recommendation. Cash-flow comparison is logical consequence of the two qualified routes; no guaranteed or accelerated input-credit refund is asserted.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 157,
  "line": 166,
  "original_review_row_id": null,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 5: Indian seller to a non-Indian customer",
  "source_keys": [
    "IN"
  ]
}
```

### 158

Eligibility, receipt and refund conditions still control.

```json
{
  "act_articles": {
    "IN16REFUND": "IGST16(3), scanPDFpage21, section54/rules qualification",
    "IN2I": "IGST2(6)(i)",
    "IN2II": "IGST2(6)(ii)",
    "IN2III": "IGST2(6)(iii)",
    "IN2IV": "IGST2(6)(iv), as amended2018",
    "IN2V": "IGST2(6)(v)"
  },
  "conditions_context": "For an eligible exporter with qualifying zero-rated services, the original financial-year LUT recommendation is retained: use a valid LUT for the relevant financial year where its conditions are met, rather than advancing IGST under an eligible tax-paid route and awaiting its refund. This avoids that upfront tax/refund cash-flow cycle; it does not guarantee or accelerate a separate unutilised-input-credit refund. Eligibility, receipt and refund conditions still control. Sources: [official source]; [official source]; [official source].",
  "evidence_entry_ids": [
    "IN2I",
    "IN2II",
    "IN2III",
    "IN2IV",
    "IN2V",
    "IN16REFUND"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACTS_SUPPLIED_AUTHOR_DELTA_RECHECK_PENDING",
  "evidence_recommendation_note": "Restored F3 annual LUT recommendation. Cash-flow comparison is logical consequence of the two qualified routes; no guaranteed or accelerated input-credit refund is asserted.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 158,
  "line": 166,
  "original_review_row_id": null,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 5: Indian seller to a non-Indian customer",
  "source_keys": [
    "IN"
  ]
}
```

### 159

Sources: [official source]; [official source]; [official source].

```json
{
  "act_articles": {
    "IN16LUT": "IGST16(3), bond/LUT route",
    "IN16PAID": "IGST16(4), scan PDFpage22, notified class/conditions",
    "INLUTYEAR": "Circular8/8/2017 paragraph2(b)",
    "INRFD": "Circular40/14/2018 paragraph2 substituted2(c)"
  },
  "conditions_context": "For an eligible exporter with qualifying zero-rated services, the original financial-year LUT recommendation is retained: use a valid LUT for the relevant financial year where its conditions are met, rather than advancing IGST under an eligible tax-paid route and awaiting its refund. This avoids that upfront tax/refund cash-flow cycle; it does not guarantee or accelerate a separate unutilised-input-credit refund. Eligibility, receipt and refund conditions still control. Sources: [official source]; [official source]; [official source].",
  "evidence_entry_ids": [
    "IN16LUT",
    "IN16PAID",
    "INLUTYEAR",
    "INRFD"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACTS_SUPPLIED_AUTHOR_DELTA_RECHECK_PENDING",
  "evidence_recommendation_note": "Restored F3 annual LUT recommendation. Cash-flow comparison is logical consequence of the two qualified routes; no guaranteed or accelerated input-credit refund is asserted.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 159,
  "line": 166,
  "original_review_row_id": null,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 5: Indian seller to a non-Indian customer",
  "source_keys": [
    "IN",
    "INLUT",
    "INONLINE"
  ]
}
```

### 160

LUT eligibility is subject to Notification 37/2017: the prosecution exclusion involves tax evaded exceeding INR 250 lakh (in words on the page); use the actual facts rather than assume every freelancer qualifies.

```json
{
  "act_articles": {
    "IN250": "Same condition(i), strict threshold",
    "INPROSEC": "Notification37/2017 condition(i), prosecution exclusion"
  },
  "conditions_context": "LUT eligibility is subject to Notification 37/2017: the prosecution exclusion involves tax evaded exceeding INR 250 lakh (in words on the page); use the actual facts rather than assume every freelancer qualifies. Circular 8/8/2017 paragraph 2(b) states validity for the financial year; Circular 40/14/2018 updates online RFD-11/ARN acceptance. Current portal guidance selects that financial year. Sources: [official source]; [official source]; [official source]; [official source].",
  "evidence_entry_ids": [
    "INPROSEC",
    "IN250"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "37",
    "2017",
    "250"
  ],
  "id": 160,
  "line": 168,
  "original_review_exact_claim": "LUT eligibility is subject to Notification 37/2017: the prosecution exclusion involves tax evaded exceeding INR 250 lakh (in words on the page); use the actual facts rather than assume every freelancer qualifies.",
  "original_review_row_id": 156,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 5: Indian seller to a non-Indian customer",
  "source_keys": [
    "IN37"
  ]
}
```

### 161

Circular 8/8/2017 paragraph 2(b) states validity for the financial year; Circular 40/14/2018 updates online RFD-11/ARN acceptance.

```json
{
  "act_articles": {
    "INARN": "Same substituted2(c)/(e), deemed acceptance",
    "INARNREJECT": "Same substituted2(e), ineligible LUT rejection",
    "INLUTYEAR": "Circular8/8/2017 paragraph2(b)",
    "INRFD": "Circular40/14/2018 paragraph2 substituted2(c)"
  },
  "conditions_context": "LUT eligibility is subject to Notification 37/2017: the prosecution exclusion involves tax evaded exceeding INR 250 lakh (in words on the page); use the actual facts rather than assume every freelancer qualifies. Circular 8/8/2017 paragraph 2(b) states validity for the financial year; Circular 40/14/2018 updates online RFD-11/ARN acceptance. Current portal guidance selects that financial year. Sources: [official source]; [official source]; [official source]; [official source].",
  "evidence_entry_ids": [
    "INLUTYEAR",
    "INRFD",
    "INARN",
    "INARNREJECT"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "8",
    "8",
    "2017",
    "2(b)",
    "40",
    "14",
    "2018",
    "11"
  ],
  "id": 161,
  "line": 168,
  "original_review_exact_claim": "Circular 8/8/2017 paragraph 2(b) states validity for the financial year; Circular 40/14/2018 updates online RFD-11/ARN acceptance.",
  "original_review_row_id": 157,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 5: Indian seller to a non-Indian customer",
  "source_keys": [
    "INLUT",
    "INONLINE"
  ]
}
```

### 162

Current portal guidance selects that financial year.

```json
{
  "act_articles": {
    "INPORTALYEAR": "Furnishing LUT manual, financial-year selection step"
  },
  "conditions_context": "LUT eligibility is subject to Notification 37/2017: the prosecution exclusion involves tax evaded exceeding INR 250 lakh (in words on the page); use the actual facts rather than assume every freelancer qualifies. Circular 8/8/2017 paragraph 2(b) states validity for the financial year; Circular 40/14/2018 updates online RFD-11/ARN acceptance. Current portal guidance selects that financial year. Sources: [official source]; [official source]; [official source]; [official source].",
  "evidence_entry_ids": [
    "INPORTALYEAR"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 162,
  "line": 168,
  "original_review_exact_claim": "Current portal guidance selects that financial year.",
  "original_review_row_id": 158,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 5: Indian seller to a non-Indian customer",
  "source_keys": [
    "INPORTAL"
  ]
}
```

### 163

Sources: [official source]; [official source]; [official source]; [official source].

```json
{
  "act_articles": {
    "IN250": "Same condition(i), strict threshold",
    "INARN": "Same substituted2(c)/(e), deemed acceptance",
    "INARNREJECT": "Same substituted2(e), ineligible LUT rejection",
    "INLUTYEAR": "Circular8/8/2017 paragraph2(b)",
    "INPORTALYEAR": "Furnishing LUT manual, financial-year selection step",
    "INPROSEC": "Notification37/2017 condition(i), prosecution exclusion",
    "INRFD": "Circular40/14/2018 paragraph2 substituted2(c)"
  },
  "conditions_context": "LUT eligibility is subject to Notification 37/2017: the prosecution exclusion involves tax evaded exceeding INR 250 lakh (in words on the page); use the actual facts rather than assume every freelancer qualifies. Circular 8/8/2017 paragraph 2(b) states validity for the financial year; Circular 40/14/2018 updates online RFD-11/ARN acceptance. Current portal guidance selects that financial year. Sources: [official source]; [official source]; [official source]; [official source].",
  "evidence_entry_ids": [
    "INPROSEC",
    "IN250",
    "INLUTYEAR",
    "INRFD",
    "INARN",
    "INARNREJECT",
    "INPORTALYEAR"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 163,
  "line": 168,
  "original_review_exact_claim": "Sources: [official source]; [official source]; [official source]; [official source].",
  "original_review_row_id": 159,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 5: Indian seller to a non-Indian customer",
  "source_keys": [
    "IN37",
    "INLUT",
    "INONLINE",
    "INPORTAL"
  ]
}
```

### 164

For services under rule 96A(1)(b), the payment/interest consequence is **15 days after expiry of the later of 1 year from invoice or the FEMA-permitted period including RBI extension**, subject to any further period the Commissioner allows, if permitted-currency payment is not received.

```json
{
  "act_articles": {
    "IN96COMM": "Same substituted96A(1)(b), Commissioner extension",
    "IN96FEMA": "Same substituted96A(1)(b), FEMA/RBI later-period limb",
    "IN96INVOICE": "Notification12/2024 rule20(i), invoice starting date",
    "IN96PAY": "Same substituted96A(1)(b), payment qualification",
    "IN96TIME": "Notification12/2024-CentralTax rule20(i), substituted96A(1)(b)"
  },
  "conditions_context": "For services under rule 96A(1)(b), the payment/interest consequence is **15 days after expiry of the later of 1 year from invoice or the FEMA-permitted period including RBI extension**, subject to any further period the Commissioner allows, if permitted-currency payment is not received. These periods are stated in words in the operative amendment (in words on the page). Do not use an unqualified fixed 1-year deadline. Missing/late LUT is not an instruction to assume automatic tax-paid refund: Circular 37/11/2018 paragraph 4 permits case-specific ex post facto condonation. Sources: 12/2024-Central Tax rule 20, [official source]; [official source].",
  "evidence_entry_ids": [
    "IN96TIME",
    "IN96FEMA",
    "IN96INVOICE",
    "IN96COMM",
    "IN96PAY"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "96",
    "1",
    "15",
    "1"
  ],
  "id": 164,
  "line": 170,
  "original_review_exact_claim": "For services under rule 96A(1)(b), the payment/interest consequence is **15 days after expiry of the later of 1 year from invoice or the FEMA-permitted period including RBI extension**, subject to any further period the Commissioner allows, if permitted-currency payment is not received.",
  "original_review_row_id": 160,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 5: Indian seller to a non-Indian customer",
  "source_keys": [
    "IN96"
  ]
}
```

### 165

These periods are stated in words in the operative amendment (in words on the page).

```json
{
  "act_articles": {
    "IN96COMM": "Same substituted96A(1)(b), Commissioner extension",
    "IN96FEMA": "Same substituted96A(1)(b), FEMA/RBI later-period limb",
    "IN96INVOICE": "Notification12/2024 rule20(i), invoice starting date",
    "IN96PAY": "Same substituted96A(1)(b), payment qualification",
    "IN96TIME": "Notification12/2024-CentralTax rule20(i), substituted96A(1)(b)"
  },
  "conditions_context": "For services under rule 96A(1)(b), the payment/interest consequence is **15 days after expiry of the later of 1 year from invoice or the FEMA-permitted period including RBI extension**, subject to any further period the Commissioner allows, if permitted-currency payment is not received. These periods are stated in words in the operative amendment (in words on the page). Do not use an unqualified fixed 1-year deadline. Missing/late LUT is not an instruction to assume automatic tax-paid refund: Circular 37/11/2018 paragraph 4 permits case-specific ex post facto condonation. Sources: 12/2024-Central Tax rule 20, [official source]; [official source].",
  "evidence_entry_ids": [
    "IN96TIME",
    "IN96FEMA",
    "IN96INVOICE",
    "IN96COMM",
    "IN96PAY"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 165,
  "line": 170,
  "original_review_exact_claim": "These periods are stated in words in the operative amendment (in words on the page).",
  "original_review_row_id": 161,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 5: Indian seller to a non-Indian customer",
  "source_keys": [
    "IN96"
  ]
}
```

### 166

Do not use an unqualified fixed 1-year deadline.

```json
{
  "act_articles": {
    "IN96COMM": "Same substituted96A(1)(b), Commissioner extension",
    "IN96FEMA": "Same substituted96A(1)(b), FEMA/RBI later-period limb",
    "IN96INVOICE": "Notification12/2024 rule20(i), invoice starting date",
    "IN96PAY": "Same substituted96A(1)(b), payment qualification",
    "IN96TIME": "Notification12/2024-CentralTax rule20(i), substituted96A(1)(b)"
  },
  "conditions_context": "For services under rule 96A(1)(b), the payment/interest consequence is **15 days after expiry of the later of 1 year from invoice or the FEMA-permitted period including RBI extension**, subject to any further period the Commissioner allows, if permitted-currency payment is not received. These periods are stated in words in the operative amendment (in words on the page). Do not use an unqualified fixed 1-year deadline. Missing/late LUT is not an instruction to assume automatic tax-paid refund: Circular 37/11/2018 paragraph 4 permits case-specific ex post facto condonation. Sources: 12/2024-Central Tax rule 20, [official source]; [official source].",
  "evidence_entry_ids": [
    "IN96TIME",
    "IN96FEMA",
    "IN96INVOICE",
    "IN96COMM",
    "IN96PAY"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "1"
  ],
  "id": 166,
  "line": 170,
  "original_review_exact_claim": "Do not use an unqualified fixed 1-year deadline.",
  "original_review_row_id": 162,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 5: Indian seller to a non-Indian customer",
  "source_keys": [
    "IN96"
  ]
}
```

### 167

Missing/late LUT is not an instruction to assume automatic tax-paid refund: Circular 37/11/2018 paragraph 4 permits case-specific ex post facto condonation.

```json
{
  "act_articles": {
    "INCONDONE": "Circular37/11/2018 paragraph4.1",
    "INCONDONEFACTS": "Same paragraph4.1, individual-facts qualification"
  },
  "conditions_context": "For services under rule 96A(1)(b), the payment/interest consequence is **15 days after expiry of the later of 1 year from invoice or the FEMA-permitted period including RBI extension**, subject to any further period the Commissioner allows, if permitted-currency payment is not received. These periods are stated in words in the operative amendment (in words on the page). Do not use an unqualified fixed 1-year deadline. Missing/late LUT is not an instruction to assume automatic tax-paid refund: Circular 37/11/2018 paragraph 4 permits case-specific ex post facto condonation. Sources: 12/2024-Central Tax rule 20, [official source]; [official source].",
  "evidence_entry_ids": [
    "INCONDONE",
    "INCONDONEFACTS"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "37",
    "11",
    "2018",
    "4"
  ],
  "id": 167,
  "line": 170,
  "original_review_exact_claim": "Missing/late LUT is not an instruction to assume automatic tax-paid refund: Circular 37/11/2018 paragraph 4 permits case-specific ex post facto condonation.",
  "original_review_row_id": 163,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 5: Indian seller to a non-Indian customer",
  "source_keys": [
    "INLATE"
  ]
}
```

### 168

Sources: 12/2024-Central Tax rule 20, [official source]; [official source].

```json
{
  "act_articles": {
    "IN96COMM": "Same substituted96A(1)(b), Commissioner extension",
    "IN96FEMA": "Same substituted96A(1)(b), FEMA/RBI later-period limb",
    "IN96INVOICE": "Notification12/2024 rule20(i), invoice starting date",
    "IN96PAY": "Same substituted96A(1)(b), payment qualification",
    "IN96TIME": "Notification12/2024-CentralTax rule20(i), substituted96A(1)(b)",
    "INCONDONE": "Circular37/11/2018 paragraph4.1",
    "INCONDONEFACTS": "Same paragraph4.1, individual-facts qualification"
  },
  "conditions_context": "For services under rule 96A(1)(b), the payment/interest consequence is **15 days after expiry of the later of 1 year from invoice or the FEMA-permitted period including RBI extension**, subject to any further period the Commissioner allows, if permitted-currency payment is not received. These periods are stated in words in the operative amendment (in words on the page). Do not use an unqualified fixed 1-year deadline. Missing/late LUT is not an instruction to assume automatic tax-paid refund: Circular 37/11/2018 paragraph 4 permits case-specific ex post facto condonation. Sources: 12/2024-Central Tax rule 20, [official source]; [official source].",
  "evidence_entry_ids": [
    "IN96TIME",
    "IN96FEMA",
    "IN96INVOICE",
    "IN96COMM",
    "IN96PAY",
    "INCONDONE",
    "INCONDONEFACTS"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "12",
    "2024",
    "20,"
  ],
  "id": 168,
  "line": 170,
  "original_review_exact_claim": "Sources: 12/2024-Central Tax rule 20, [official source]; [official source].",
  "original_review_row_id": 164,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 5: Indian seller to a non-Indian customer",
  "source_keys": [
    "IN96",
    "INLATE"
  ]
}
```

### 169

For a registered exporter, reconcile GSTR-1 Table 6A export invoices with GSTR-3B Table 3.1(b) zero-rated outward supplies, including applicable amendments; preserve payment, LUT and refund evidence.

```json
{
  "act_articles": {
    "INRETURNMAP": "GSTR3B FAQ / system generated GSTR3B table, GSTR1 export6A/6B/9 amendments row to3.1(b)"
  },
  "conditions_context": "For a registered exporter, reconcile GSTR-1 Table 6A export invoices with GSTR-3B Table 3.1(b) zero-rated outward supplies, including applicable amendments; preserve payment, LUT and refund evidence. Use the period's required INR valuation rather than insert the USD invoice as though it were INR. Current official return FAQ maps these tables: [official source]; the service-valuation rule is CGST Rule 34(2), applied through IGST section 20: [official source]; [official source] (CGST section 13 concerns time of supply; the IGST section 13 place-of-supply test is separate). No return/payment or refund filing deadline beyond the sourced receipt rule is determined by this Guide.",
  "evidence_entry_ids": [
    "INRETURNMAP"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "Actual full table read shows GSTR1 export6A/6B/amendment9A/B/C to GSTR3B3.1(b). Preserving payment/LUT/refund evidence is workflow, not a separate return-table rule.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "1",
    "6",
    "3",
    "3.1(b)"
  ],
  "id": 169,
  "line": 172,
  "original_review_exact_claim": "For a registered exporter, reconcile GSTR-1 Table 6A export invoices with GSTR-3B Table 3.1(b) zero-rated outward supplies, including applicable amendments; preserve payment, LUT and refund evidence.",
  "original_review_row_id": 165,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 5: Indian seller to a non-Indian customer",
  "source_keys": [
    "INRETURN"
  ]
}
```

### 170

Use the period's required INR valuation rather than insert the USD invoice as though it were INR.

```json
{
  "INR_boundary": "Entire actual live Rule34 heading, both operative subsections and historic substitution note personally read, with complete live Rules33 and35 neighbours. Current official index marks entry active and amendment27July2017. Service valuation uses GAAP rate at CGSTsection13 time of supply. This is different from IGSTsection13 place of supply and IGST2(6)(iv) receipt-currency permission. No actual FXrate, invoice/time-of-supply facts, accounting policy, INR amount, return-period cutoff or refund amount is supplied or cleared. Complete 2026Notification05 amendment targets independently checked; noRule34 amendment there. This is current official live-entry proof, not an assertion that the old full CBIC/Court compilation incorporates every2026amendment.",
  "act_articles": {
    "IN20APPLY": "IGSTAct20, operative line after(xxv), scanPDFpage26/printed219, subject to chapeau",
    "IN20TIME": "IGSTAct20(iii), scanPDFpage25/printed218",
    "ININR": "Central Goods and Services Tax Rules2017, Rule34(2), live active CBIC entry; heading specifies currency other than Indianrupees; read with34(1) and substitution footnote"
  },
  "conditions_context": "For a registered exporter, reconcile GSTR-1 Table 6A export invoices with GSTR-3B Table 3.1(b) zero-rated outward supplies, including applicable amendments; preserve payment, LUT and refund evidence. Use the period's required INR valuation rather than insert the USD invoice as though it were INR. Current official return FAQ maps these tables: [official source]; the service-valuation rule is CGST Rule 34(2), applied through IGST section 20: [official source]; [official source] (CGST section 13 concerns time of supply; the IGST section 13 place-of-supply test is separate). No return/payment or refund filing deadline beyond the sourced receipt rule is determined by this Guide.",
  "evidence_entry_ids": [
    "ININR",
    "IN20TIME",
    "IN20APPLY"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACTS_SUPPLIED_AUTHOR_DELTA_RECHECK_PENDING",
  "evidence_recommendation_note": "INR valuation-basis extract gap resolved by the bounded live Rule34(2)/IGST20 addendum; FAQ retained only where a separate return mapping is asserted. No actual exchange rate or converted amount is cleared.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 170,
  "line": 172,
  "original_review_exact_claim": "Use the period's required INR valuation rather than insert the USD invoice as though it were INR.",
  "original_review_row_id": 166,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 5: Indian seller to a non-Indian customer",
  "source_keys": [
    "INRULE34",
    "IN"
  ]
}
```

### 171

Current official return FAQ maps these tables: [official source]; the service-valuation rule is CGST Rule 34(2), applied through IGST section 20: [official source]; [official source] (CGST section 13 concerns time of supply; the IGST section 13 place-of-supply test is separate).

```json
{
  "INR_boundary": "Entire actual live Rule34 heading, both operative subsections and historic substitution note personally read, with complete live Rules33 and35 neighbours. Current official index marks entry active and amendment27July2017. Service valuation uses GAAP rate at CGSTsection13 time of supply. This is different from IGSTsection13 place of supply and IGST2(6)(iv) receipt-currency permission. No actual FXrate, invoice/time-of-supply facts, accounting policy, INR amount, return-period cutoff or refund amount is supplied or cleared. Complete 2026Notification05 amendment targets independently checked; noRule34 amendment there. This is current official live-entry proof, not an assertion that the old full CBIC/Court compilation incorporates every2026amendment.",
  "act_articles": {
    "IN20APPLY": "IGSTAct20, operative line after(xxv), scanPDFpage26/printed219, subject to chapeau",
    "IN20TIME": "IGSTAct20(iii), scanPDFpage25/printed218",
    "ININR": "Central Goods and Services Tax Rules2017, Rule34(2), live active CBIC entry; heading specifies currency other than Indianrupees; read with34(1) and substitution footnote",
    "INRETURNMAP": "GSTR3B FAQ / system generated GSTR3B table, GSTR1 export6A/6B/9 amendments row to3.1(b)"
  },
  "conditions_context": "For a registered exporter, reconcile GSTR-1 Table 6A export invoices with GSTR-3B Table 3.1(b) zero-rated outward supplies, including applicable amendments; preserve payment, LUT and refund evidence. Use the period's required INR valuation rather than insert the USD invoice as though it were INR. Current official return FAQ maps these tables: [official source]; the service-valuation rule is CGST Rule 34(2), applied through IGST section 20: [official source]; [official source] (CGST section 13 concerns time of supply; the IGST section 13 place-of-supply test is separate). No return/payment or refund filing deadline beyond the sourced receipt rule is determined by this Guide.",
  "evidence_entry_ids": [
    "INRETURNMAP",
    "ININR",
    "IN20TIME",
    "IN20APPLY"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACTS_SUPPLIED_AUTHOR_DELTA_RECHECK_PENDING",
  "evidence_recommendation_note": "INR valuation-basis extract gap resolved by the bounded live Rule34(2)/IGST20 addendum; FAQ retained only where a separate return mapping is asserted. No actual exchange rate or converted amount is cleared.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "34(2)",
    "20",
    "13",
    "13"
  ],
  "id": 171,
  "line": 172,
  "original_review_exact_claim": "Current official return FAQ maps these tables: [official source].",
  "original_review_row_id": 167,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 5: Indian seller to a non-Indian customer",
  "source_keys": [
    "INRETURN",
    "INRULE34",
    "IN"
  ]
}
```

### 172

No return/payment or refund filing deadline beyond the sourced receipt rule is determined by this Guide.

```json
{
  "act_articles": {},
  "conditions_context": "For a registered exporter, reconcile GSTR-1 Table 6A export invoices with GSTR-3B Table 3.1(b) zero-rated outward supplies, including applicable amendments; preserve payment, LUT and refund evidence. Use the period's required INR valuation rather than insert the USD invoice as though it were INR. Current official return FAQ maps these tables: [official source]; the service-valuation rule is CGST Rule 34(2), applied through IGST section 20: [official source]; [official source] (CGST section 13 concerns time of supply; the IGST section 13 place-of-supply test is separate). No return/payment or refund filing deadline beyond the sourced receipt rule is determined by this Guide.",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 172,
  "line": 172,
  "original_review_exact_claim": "No return/payment or refund filing deadline beyond the sourced receipt rule is determined by this Guide.",
  "original_review_row_id": 168,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 5: Indian seller to a non-Indian customer",
  "source_keys": [
    "POLICY"
  ]
}
```

### 173

**Original common scenario:** an Indian developer supplies software development to a US company, paid in USD with LUT filed.

```json
{
  "act_articles": {},
  "conditions_context": "**Original common scenario:** an Indian developer supplies software development to a US company, paid in USD with LUT filed. It can be a zero-rated export without IGST only after the location/place, separate-establishment and timely permitted-payment conditions are proved and the LUT is valid. Eligible ITC follows its own conditions; payment in USD and LUT alone do not prove all 5 conditions. Sources: [official source]; [official source].",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 173,
  "line": 174,
  "original_review_exact_claim": "**Original common scenario:** an Indian developer supplies software development to a US company, paid in USD with LUT filed.",
  "original_review_row_id": 169,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 5: Indian seller to a non-Indian customer",
  "source_keys": [
    "POLICY"
  ]
}
```

### 174

It can be a zero-rated export without IGST only after the location/place, separate-establishment and timely permitted-payment conditions are proved and the LUT is valid.

```json
{
  "act_articles": {
    "IN13BASE": "IGST13(2), general rule",
    "IN13EVENT": "IGST13(5), scan PDFpage17",
    "IN13FALL": "IGST13(2), proviso",
    "IN13LAND": "IGST13(4)",
    "IN13PHYS": "IGST13(3)(b), physical presence",
    "IN16EXPORT": "IGST16(1)(a)",
    "IN16LUT": "IGST16(3), bond/LUT route",
    "IN250": "Same condition(i), strict threshold",
    "IN2FE": "IGST2(14)(c), relevant establishment",
    "IN2I": "IGST2(6)(i)",
    "IN2II": "IGST2(6)(ii)",
    "IN2III": "IGST2(6)(iii)",
    "IN2IV": "IGST2(6)(iv), as amended2018",
    "IN2V": "IGST2(6)(v)",
    "IN8EX": "IGST8Explanation1(i)",
    "IN96COMM": "Same substituted96A(1)(b), Commissioner extension",
    "IN96FEMA": "Same substituted96A(1)(b), FEMA/RBI later-period limb",
    "IN96INVOICE": "Notification12/2024 rule20(i), invoice starting date",
    "IN96PAY": "Same substituted96A(1)(b), payment qualification",
    "IN96TIME": "Notification12/2024-CentralTax rule20(i), substituted96A(1)(b)",
    "INARN": "Same substituted2(c)/(e), deemed acceptance",
    "INARNREJECT": "Same substituted2(e), ineligible LUT rejection",
    "INLUTPRIOR": "Circular8/8/2017 paragraph2(e), prior requirement",
    "INLUTYEAR": "Circular8/8/2017 paragraph2(b)",
    "INPROSEC": "Notification37/2017 condition(i), prosecution exclusion",
    "INRFD": "Circular40/14/2018 paragraph2 substituted2(c)"
  },
  "conditions_context": "**Original common scenario:** an Indian developer supplies software development to a US company, paid in USD with LUT filed. It can be a zero-rated export without IGST only after the location/place, separate-establishment and timely permitted-payment conditions are proved and the LUT is valid. Eligible ITC follows its own conditions; payment in USD and LUT alone do not prove all 5 conditions. Sources: [official source]; [official source].",
  "evidence_entry_ids": [
    "IN2I",
    "IN2II",
    "IN2III",
    "IN2IV",
    "IN2V",
    "IN8EX",
    "IN2FE",
    "IN13BASE",
    "IN13FALL",
    "IN13PHYS",
    "IN13LAND",
    "IN13EVENT",
    "IN16EXPORT",
    "IN16LUT",
    "INLUTYEAR",
    "INLUTPRIOR",
    "INPROSEC",
    "IN250",
    "INRFD",
    "INARN",
    "INARNREJECT",
    "IN96TIME",
    "IN96FEMA",
    "IN96INVOICE",
    "IN96COMM",
    "IN96PAY"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 174,
  "line": 174,
  "original_review_exact_claim": "It can be a zero-rated export without IGST only after the location/place, separate-establishment and timely permitted-payment conditions are proved and the LUT is valid.",
  "original_review_row_id": 170,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 5: Indian seller to a non-Indian customer",
  "source_keys": [
    "IN",
    "INLUT",
    "IN37",
    "INONLINE",
    "IN96"
  ]
}
```

### 175

Eligible ITC follows its own conditions; payment in USD and LUT alone do not prove all 5 conditions.

```json
{
  "act_articles": {
    "IN16INPUT": "IGST16(2), blocked-credit qualification",
    "IN2FE": "IGST2(14)(c), relevant establishment",
    "IN2I": "IGST2(6)(i)",
    "IN2II": "IGST2(6)(ii)",
    "IN2III": "IGST2(6)(iii)",
    "IN2IV": "IGST2(6)(iv), as amended2018",
    "IN2V": "IGST2(6)(v)",
    "IN8EX": "IGST8Explanation1(i)"
  },
  "conditions_context": "**Original common scenario:** an Indian developer supplies software development to a US company, paid in USD with LUT filed. It can be a zero-rated export without IGST only after the location/place, separate-establishment and timely permitted-payment conditions are proved and the LUT is valid. Eligible ITC follows its own conditions; payment in USD and LUT alone do not prove all 5 conditions. Sources: [official source]; [official source].",
  "evidence_entry_ids": [
    "IN16INPUT",
    "IN2I",
    "IN2II",
    "IN2III",
    "IN2IV",
    "IN2V",
    "IN8EX",
    "IN2FE"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "5"
  ],
  "id": 175,
  "line": 174,
  "original_review_exact_claim": "Eligible ITC follows its own conditions; payment in USD and LUT alone do not prove all 5 conditions.",
  "original_review_row_id": 171,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 5: Indian seller to a non-Indian customer",
  "source_keys": [
    "IN"
  ]
}
```

### 176

Sources: [official source]; [official source].

```json
{
  "act_articles": {
    "IN13BASE": "IGST13(2), general rule",
    "IN13EVENT": "IGST13(5), scan PDFpage17",
    "IN13FALL": "IGST13(2), proviso",
    "IN13LAND": "IGST13(4)",
    "IN13PHYS": "IGST13(3)(b), physical presence",
    "IN16EXPORT": "IGST16(1)(a)",
    "IN16INPUT": "IGST16(2), blocked-credit qualification",
    "IN16LUT": "IGST16(3), bond/LUT route",
    "IN250": "Same condition(i), strict threshold",
    "IN2FE": "IGST2(14)(c), relevant establishment",
    "IN2I": "IGST2(6)(i)",
    "IN2II": "IGST2(6)(ii)",
    "IN2III": "IGST2(6)(iii)",
    "IN2IV": "IGST2(6)(iv), as amended2018",
    "IN2V": "IGST2(6)(v)",
    "IN8EX": "IGST8Explanation1(i)",
    "IN96COMM": "Same substituted96A(1)(b), Commissioner extension",
    "IN96FEMA": "Same substituted96A(1)(b), FEMA/RBI later-period limb",
    "IN96INVOICE": "Notification12/2024 rule20(i), invoice starting date",
    "IN96PAY": "Same substituted96A(1)(b), payment qualification",
    "IN96TIME": "Notification12/2024-CentralTax rule20(i), substituted96A(1)(b)",
    "INARN": "Same substituted2(c)/(e), deemed acceptance",
    "INARNREJECT": "Same substituted2(e), ineligible LUT rejection",
    "INLUTPRIOR": "Circular8/8/2017 paragraph2(e), prior requirement",
    "INLUTYEAR": "Circular8/8/2017 paragraph2(b)",
    "INPROSEC": "Notification37/2017 condition(i), prosecution exclusion",
    "INRFD": "Circular40/14/2018 paragraph2 substituted2(c)"
  },
  "conditions_context": "**Original common scenario:** an Indian developer supplies software development to a US company, paid in USD with LUT filed. It can be a zero-rated export without IGST only after the location/place, separate-establishment and timely permitted-payment conditions are proved and the LUT is valid. Eligible ITC follows its own conditions; payment in USD and LUT alone do not prove all 5 conditions. Sources: [official source]; [official source].",
  "evidence_entry_ids": [
    "IN2I",
    "IN2II",
    "IN2III",
    "IN2IV",
    "IN2V",
    "IN8EX",
    "IN2FE",
    "IN13BASE",
    "IN13FALL",
    "IN13PHYS",
    "IN13LAND",
    "IN13EVENT",
    "IN16EXPORT",
    "IN16LUT",
    "INLUTYEAR",
    "INLUTPRIOR",
    "INPROSEC",
    "IN250",
    "INRFD",
    "INARN",
    "INARNREJECT",
    "IN96TIME",
    "IN96FEMA",
    "IN96INVOICE",
    "IN96COMM",
    "IN96PAY",
    "IN16INPUT"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 176,
  "line": 174,
  "original_review_exact_claim": "Sources: [official source]; [official source].",
  "original_review_row_id": 172,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 5: Indian seller to a non-Indian customer",
  "source_keys": [
    "IN",
    "INLUT",
    "IN37",
    "INONLINE",
    "IN96"
  ]
}
```

### 177

The governing route is GST Act **section 21(3) international services**, not a general "Fifth Schedule" catch-all.

```json
{
  "act_articles": {
    "SGFIFTH": "IRAS telecommunications table row25, section21(3)(q), Fifth Schedule",
    "SGROUTE": "IRAS opening international-services explanation, Section21(3)"
  },
  "conditions_context": "The governing route is GST Act **section 21(3) international services**, not a general \"Fifth Schedule\" catch-all. IRAS explicitly says not every overseas-customer service is zero-rated. The Fifth Schedule of the International Services Order concerns specified telecommunications under section 21(3)(q); it is not the old professional-service Para 1/2/3/10 table. Source: current IRAS international-services table and belonging guidance, [official source].",
  "evidence_entry_ids": [
    "SGROUTE",
    "SGFIFTH"
  ],
  "evidence_format_status": "CURRENT_SHORT_EXTRACT_STANDARD_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "21(3)"
  ],
  "historical_format_status": "HOLD_EXPLICIT_EXTRACT_GAP",
  "historical_quotation_gaps": [
    "SGROUTE",
    "SGFIFTH"
  ],
  "id": 177,
  "line": 178,
  "original_review_exact_claim": "The governing route is GST Act **section 21(3) international services**, not a general \"Fifth Schedule\" catch-all.",
  "original_review_row_id": 173,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 6: Singaporean seller to an overseas customer",
  "source_keys": [
    "SG"
  ]
}
```

### 178

IRAS explicitly says not every overseas-customer service is zero-rated.

```json
{
  "act_articles": {
    "SGROUTE": "IRAS opening international-services explanation, Section21(3)"
  },
  "conditions_context": "The governing route is GST Act **section 21(3) international services**, not a general \"Fifth Schedule\" catch-all. IRAS explicitly says not every overseas-customer service is zero-rated. The Fifth Schedule of the International Services Order concerns specified telecommunications under section 21(3)(q); it is not the old professional-service Para 1/2/3/10 table. Source: current IRAS international-services table and belonging guidance, [official source].",
  "evidence_entry_ids": [
    "SGROUTE"
  ],
  "evidence_format_status": "CURRENT_SHORT_EXTRACT_STANDARD_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "historical_format_status": "HOLD_EXPLICIT_EXTRACT_GAP",
  "historical_quotation_gaps": [
    "SGROUTE"
  ],
  "id": 178,
  "line": 178,
  "original_review_exact_claim": "IRAS explicitly says not every overseas-customer service is zero-rated.",
  "original_review_row_id": 174,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 6: Singaporean seller to an overseas customer",
  "source_keys": [
    "SG"
  ]
}
```

### 179

The Fifth Schedule of the International Services Order concerns specified telecommunications under section 21(3)(q); it is not the old professional-service Para 1/2/3/10 table.

```json
{
  "act_articles": {
    "SGFIFTH": "IRAS telecommunications table row25, section21(3)(q), Fifth Schedule"
  },
  "conditions_context": "The governing route is GST Act **section 21(3) international services**, not a general \"Fifth Schedule\" catch-all. IRAS explicitly says not every overseas-customer service is zero-rated. The Fifth Schedule of the International Services Order concerns specified telecommunications under section 21(3)(q); it is not the old professional-service Para 1/2/3/10 table. Source: current IRAS international-services table and belonging guidance, [official source].",
  "evidence_entry_ids": [
    "SGFIFTH"
  ],
  "evidence_format_status": "CURRENT_SHORT_EXTRACT_STANDARD_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "21(3)",
    "1",
    "2",
    "3",
    "10"
  ],
  "historical_format_status": "HOLD_EXPLICIT_EXTRACT_GAP",
  "historical_quotation_gaps": [
    "SGFIFTH"
  ],
  "id": 179,
  "line": 178,
  "original_review_exact_claim": "The Fifth Schedule of the International Services Order concerns specified telecommunications under section 21(3)(q); it is not the old professional-service Para 1/2/3/10 table.",
  "original_review_row_id": 175,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 6: Singaporean seller to an overseas customer",
  "source_keys": [
    "SG"
  ]
}
```

### 180

Source: current IRAS international-services table and belonging guidance, [official source].

```json
{
  "act_articles": {
    "SGBELONG": "IRAS Belonging status / Customer is a business / numbered1-3 plus business/fixed establishment definitions",
    "SGFIFTH": "IRAS telecommunications table row25, section21(3)(q), Fifth Schedule",
    "SGROUTE": "IRAS opening international-services explanation, Section21(3)"
  },
  "conditions_context": "The governing route is GST Act **section 21(3) international services**, not a general \"Fifth Schedule\" catch-all. IRAS explicitly says not every overseas-customer service is zero-rated. The Fifth Schedule of the International Services Order concerns specified telecommunications under section 21(3)(q); it is not the old professional-service Para 1/2/3/10 table. Source: current IRAS international-services table and belonging guidance, [official source].",
  "evidence_entry_ids": [
    "SGROUTE",
    "SGFIFTH",
    "SGBELONG"
  ],
  "evidence_format_status": "CURRENT_SHORT_EXTRACT_STANDARD_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "historical_format_status": "HOLD_EXPLICIT_EXTRACT_GAP",
  "historical_quotation_gaps": [
    "SGROUTE",
    "SGFIFTH",
    "SGBELONG"
  ],
  "id": 180,
  "line": 178,
  "original_review_exact_claim": "Source: current IRAS international-services table and belonging guidance, [official source].",
  "original_review_row_id": 176,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 6: Singaporean seller to an overseas customer",
  "source_keys": [
    "SG"
  ]
}
```

### 181

| General overseas contract, formerly "Para 1" | Section 21(3)(j): contractually supplied to an overseas person outside Singapore when performed; directly benefits an overseas person outside Singapore or a GST-registered person belonging in Singapore; no prohibited Singapore land/goods connection, subject to the section 21(3)(g) goods exception and relevant media-sales provisions | https://www.iras.gov.sg/taxes/goods-services-tax-%28gst%29/charging-gst-%28output-tax%29/when-to-charge-0-gst-%28zero-rate%29/providing-international-services |

```json
{
  "act_articles": {
    "SGABS": "IRAS table row13/(j), overseas customer absence and overseas direct beneficiary absence",
    "SGCONTRACT": "IRAS international-services table row13/(j) and row14/(k), identical overseas-contract limb",
    "SGGOODS": "IRAS table rows9/10/12:21(3)(g)/(h)/(f), goods/export evidence",
    "SGLAND": "Same table row13/(j), Singapore goods/land restriction",
    "SGLOCAL": "Same table rows13/(j) and14/(k), identical local-beneficiary alternative"
  },
  "conditions_context": "| General overseas contract, formerly \"Para 1\" | Section 21(3)(j): contractually supplied to an overseas person outside Singapore when performed; directly benefits an overseas person outside Singapore or a GST-registered person belonging in Singapore; no prohibited Singapore land/goods connection, subject to the section 21(3)(g) goods exception and relevant media-sales provisions | [official source] |",
  "evidence_entry_ids": [
    "SGCONTRACT",
    "SGABS",
    "SGLOCAL",
    "SGLAND",
    "SGGOODS"
  ],
  "evidence_format_status": "CURRENT_SHORT_EXTRACT_STANDARD_APPLICABLE",
  "evidence_recommendation_note": "Each separate j condition is mapped: overseas contractual person/absence, direct benefit/local GSTregistration, land/goods limit and goods exception. Quoted j fragments are not inherited for the unquoted remaining clauses.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "1",
    "21(3)",
    "21(3)",
    "28",
    "29",
    "28",
    "29",
    "0",
    "28",
    "29"
  ],
  "historical_format_status": "HOLD_EXPLICIT_EXTRACT_GAP",
  "historical_quotation_gaps": [
    "SGABS",
    "SGGOODS"
  ],
  "id": 181,
  "line": 182,
  "original_review_exact_claim": "| General overseas contract, formerly \"Para 1\" | Section 21(3)(j): contractually supplied to an overseas person outside Singapore when performed; directly benefits an overseas person outside Singapore or a GST-registered person belonging in Singapore; no prohibited Singapore land/goods connection, subject to the section 21(3)(g) goods exception and relevant media-sales provisions | https://www.iras.gov.sg/taxes/goods-services-tax-%28gst%29/charging-gst-%28output-tax%29/when-to-charge-0-gst-%28zero-rate%29/providing-international-services |",
  "original_review_row_id": 177,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 6: Singaporean seller to an overseas customer",
  "source_keys": [
    "SG"
  ]
}
```

### 182

| Prescribed professional/data services | Section 21(3)(k) and Second Schedule of the International Services Order: overseas contractual person wholly in business capacity; direct beneficiary overseas in business capacity or GST-registered in Singapore; Singapore land-related services are excluded. The exact Singapore-goods/ships limb for professional services versus data services is not cleared by this Guide: see the specific reservation in Sources; do not decide relief for that branch from the combined summary. Unlike (j), the overseas customer can be in Singapore for these qualifying services | https://www.iras.gov.sg/taxes/goods-services-tax-%28gst%29/charging-gst-%28output-tax%29/when-to-charge-0-gst-%28zero-rate%29/providing-international-services |

```json
{
  "act_articles": {
    "SGBUSINESS": "Same table row14/(k), contractual business-capacity limb",
    "SGCONTRACT": "IRAS international-services table row13/(j) and row14/(k), identical overseas-contract limb",
    "SGKLAND": "Historical Second Schedule 1(a)-(b),2(a)-(b); current professional/data goods/ships branch reserved, not cleared",
    "SGLOCAL": "Same table rows13/(j) and14/(k), identical local-beneficiary alternative"
  },
  "conditions_context": "| Prescribed professional/data services | Section 21(3)(k) and Second Schedule of the International Services Order: overseas contractual person wholly in business capacity; direct beneficiary overseas in business capacity or GST-registered in Singapore; Singapore land-related services are excluded. The exact Singapore-goods/ships limb for professional services versus data services is not cleared by this Guide: see the specific reservation in Sources; do not decide relief for that branch from the combined summary. Unlike (j), the overseas customer can be in Singapore for these qualifying services | https://www.iras.gov.sg/taxes/goods-services-tax-%28gst%29/charging-gst-%28output-tax%29/when-to-charge-0-gst-%28zero-rate%29/providing-international-services |",
  "current_goods_ships_boundary": "Singapore professional-versus-data Singapore-goods/ships conditions under the current Second Schedule: the retained 2020 official reproduction distinguishes professional services (export goods and ships) from data services (export goods only), while the current IRAS table combines the categories. The former combined proposition \"professional/data services must not directly relate to Singapore land/goods other than goods for export\" is individually unusable for this branch until the current regulatory text/version is reconciled; no ships relief or blanket ships exclusion is cleared here. ",
  "evidence_entry_ids": [
    "SGCONTRACT",
    "SGBUSINESS",
    "SGLOCAL",
    "SGKLAND"
  ],
  "evidence_format_status": "CURRENT_SHORT_EXTRACT_STANDARD_APPLICABLE",
  "evidence_recommendation_note": "k is a distinct prescribed professional/data route. Presence contrast with j and export-goods exception are explicitly quotation gaps rather than fabricated j quotes.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "21(3)",
    "28",
    "29",
    "28",
    "29",
    "0",
    "28",
    "29"
  ],
  "historical_format_status": "HOLD_EXPLICIT_EXTRACT_GAP",
  "historical_quotation_gaps": [
    "SGKLAND"
  ],
  "id": 182,
  "line": 183,
  "original_review_exact_claim": "| Prescribed professional/data services | Section 21(3)(k) and Second Schedule of the International Services Order: overseas contractual person wholly in business capacity; direct beneficiary overseas in business capacity or GST-registered in Singapore; professional/data services must not directly relate to Singapore land/goods other than goods for export. Unlike (j), the overseas customer can be in Singapore for these qualifying services | https://www.iras.gov.sg/taxes/goods-services-tax-%28gst%29/charging-gst-%28output-tax%29/when-to-charge-0-gst-%28zero-rate%29/providing-international-services |",
  "original_review_row_id": 178,
  "prior_unchanged_review_claim": "| Prescribed professional/data services | Section 21(3)(k) and Second Schedule of the International Services Order: overseas contractual person wholly in business capacity; direct beneficiary overseas in business capacity or GST-registered in Singapore; professional/data services must not directly relate to Singapore land/goods other than goods for export. Unlike (j), the overseas customer can be in Singapore for these qualifying services | https://www.iras.gov.sg/taxes/goods-services-tax-%28gst%29/charging-gst-%28output-tax%29/when-to-charge-0-gst-%28zero-rate%29/providing-international-services |",
  "quotation_gaps": [],
  "result_boundary": "Contractual/business/beneficiary/land conditions retained; exact Singapore-goods/ships branch individually unusable pending current regulatory reconciliation",
  "section": "Quick reference / The method, step by step / Step 6: Singaporean seller to an overseas customer",
  "source_keys": [
    "SG"
  ]
}
```

### 183

| Goods for export, formerly "Para 2" | The specific section 21(3)(g)/(h) and prescribed conditions/evidence, not every service touching goods. Services directly connected with overseas goods have the separate (f) route | https://www.iras.gov.sg/taxes/goods-services-tax-%28gst%29/charging-gst-%28output-tax%29/when-to-charge-0-gst-%28zero-rate%29/providing-international-services |

```json
{
  "act_articles": {
    "SGGOODS": "IRAS table rows9/10/12:21(3)(g)/(h)/(f), goods/export evidence"
  },
  "conditions_context": "| Goods for export, formerly \"Para 2\" | The specific section 21(3)(g)/(h) and prescribed conditions/evidence, not every service touching goods. Services directly connected with overseas goods have the separate (f) route | [official source] |",
  "evidence_entry_ids": [
    "SGGOODS"
  ],
  "evidence_format_status": "CURRENT_SHORT_EXTRACT_STANDARD_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "2",
    "21(3)",
    "28",
    "29",
    "28",
    "29",
    "0",
    "28",
    "29"
  ],
  "historical_format_status": "HOLD_EXPLICIT_EXTRACT_GAP",
  "historical_quotation_gaps": [
    "SGGOODS"
  ],
  "id": 183,
  "line": 184,
  "original_review_exact_claim": "| Goods for export, formerly \"Para 2\" | The specific section 21(3)(g)/(h) and prescribed conditions/evidence, not every service touching goods. Services directly connected with overseas goods have the separate (f) route | https://www.iras.gov.sg/taxes/goods-services-tax-%28gst%29/charging-gst-%28output-tax%29/when-to-charge-0-gst-%28zero-rate%29/providing-international-services |",
  "original_review_row_id": 179,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 6: Singaporean seller to an overseas customer",
  "source_keys": [
    "SG"
  ]
}
```

### 184

| International transport, formerly "Para 3" | Apply the relevant section 21(3)(a) transport category/conditions; no generic relief for every transport service | https://www.iras.gov.sg/taxes/goods-services-tax-%28gst%29/charging-gst-%28output-tax%29/when-to-charge-0-gst-%28zero-rate%29/providing-international-services |

```json
{
  "act_articles": {
    "SGTRANS": "IRAS table rows3/4:21(3)(a), international transport"
  },
  "conditions_context": "| International transport, formerly \"Para 3\" | Apply the relevant section 21(3)(a) transport category/conditions; no generic relief for every transport service | [official source] |",
  "evidence_entry_ids": [
    "SGTRANS"
  ],
  "evidence_format_status": "CURRENT_SHORT_EXTRACT_STANDARD_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "3",
    "21(3)",
    "28",
    "29",
    "28",
    "29",
    "0",
    "28",
    "29"
  ],
  "historical_format_status": "HOLD_EXPLICIT_EXTRACT_GAP",
  "historical_quotation_gaps": [
    "SGTRANS"
  ],
  "id": 184,
  "line": 185,
  "original_review_exact_claim": "| International transport, formerly \"Para 3\" | Apply the relevant section 21(3)(a) transport category/conditions; no generic relief for every transport service | https://www.iras.gov.sg/taxes/goods-services-tax-%28gst%29/charging-gst-%28output-tax%29/when-to-charge-0-gst-%28zero-rate%29/providing-international-services |",
  "original_review_row_id": 180,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 6: Singaporean seller to an overseas customer",
  "source_keys": [
    "SG"
  ]
}
```

### 185

| Intellectual-property rights, formerly "Para 10" | Preserve the licensing/IP topic, but do not use that unsupported paragraph mapping. Identify the actual supply/right and applicable current international-services provision before zero-rating; the old category attribution is unconfirmed | Not yet confirmed: exact former Para 10 mapping; no relief cleared merely by this label |

```json
{
  "act_articles": {},
  "conditions_context": "| Intellectual-property rights, formerly \"Para 10\" | Preserve the licensing/IP topic, but do not use that unsupported paragraph mapping. Identify the actual supply/right and applicable current international-services provision before zero-rating; the old category attribution is unconfirmed | Not yet confirmed: exact former Para 10 mapping; no relief cleared merely by this label |",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": "Former Para10/IP mapping expressly reserved; no generic SG quote can clear an unidentified licensing service.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "10",
    "10"
  ],
  "id": 185,
  "line": 186,
  "original_review_exact_claim": "| Intellectual-property rights, formerly \"Para 10\" | Preserve the licensing/IP topic, but do not use that unsupported paragraph mapping. Identify the actual supply/right and applicable current international-services provision before zero-rating; the old category attribution is unconfirmed | Not yet confirmed: exact former Para 10 mapping; no relief cleared merely by this label |",
  "original_review_row_id": 181,
  "quotation_gaps": [],
  "result_boundary": "Reserved assertion or correction; not a usable old filing figure",
  "section": "Quick reference / The method, step by step / Step 6: Singaporean seller to an overseas customer",
  "source_keys": [
    "POLICY"
  ]
}
```

### 186

Determine the contractual customer's belonging status, not just its incorporation address.

```json
{
  "act_articles": {
    "SGBELONG": "IRAS Belonging status / Customer is a business / numbered1-3 plus business/fixed establishment definitions"
  },
  "conditions_context": "Determine the contractual customer's belonging status, not just its incorporation address. A Singapore business/fixed establishment most directly using the contracted service can change that status. Separately identify direct beneficiaries and their GST registration. A Singapore branch or beneficiary does **not** automatically deny relief: the local GST-registered beneficiary limb can apply if the overseas-contract and other conditions are met. Unregistered local benefit, or a contractual customer actually belonging in Singapore, can produce a different outcome. Source: [official source].",
  "evidence_entry_ids": [
    "SGBELONG"
  ],
  "evidence_format_status": "CURRENT_SHORT_EXTRACT_STANDARD_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "historical_format_status": "HOLD_EXPLICIT_EXTRACT_GAP",
  "historical_quotation_gaps": [
    "SGBELONG"
  ],
  "id": 186,
  "line": 188,
  "original_review_exact_claim": "Determine the contractual customer's belonging status, not just its incorporation address.",
  "original_review_row_id": 182,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 6: Singaporean seller to an overseas customer",
  "source_keys": [
    "SG"
  ]
}
```

### 187

A Singapore business/fixed establishment most directly using the contracted service can change that status.

```json
{
  "act_articles": {
    "SGBELONG": "IRAS Belonging status / Customer is a business / numbered1-3 plus business/fixed establishment definitions"
  },
  "conditions_context": "Determine the contractual customer's belonging status, not just its incorporation address. A Singapore business/fixed establishment most directly using the contracted service can change that status. Separately identify direct beneficiaries and their GST registration. A Singapore branch or beneficiary does **not** automatically deny relief: the local GST-registered beneficiary limb can apply if the overseas-contract and other conditions are met. Unregistered local benefit, or a contractual customer actually belonging in Singapore, can produce a different outcome. Source: [official source].",
  "evidence_entry_ids": [
    "SGBELONG"
  ],
  "evidence_format_status": "CURRENT_SHORT_EXTRACT_STANDARD_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "historical_format_status": "HOLD_EXPLICIT_EXTRACT_GAP",
  "historical_quotation_gaps": [
    "SGBELONG"
  ],
  "id": 187,
  "line": 188,
  "original_review_exact_claim": "A Singapore business/fixed establishment most directly using the contracted service can change that status.",
  "original_review_row_id": 183,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 6: Singaporean seller to an overseas customer",
  "source_keys": [
    "SG"
  ]
}
```

### 188

Separately identify direct beneficiaries and their GST registration.

```json
{
  "act_articles": {
    "SGABS": "IRAS table row13/(j), overseas customer absence and overseas direct beneficiary absence",
    "SGBUSINESS": "Same table row14/(k), contractual business-capacity limb",
    "SGCONTRACT": "IRAS international-services table row13/(j) and row14/(k), identical overseas-contract limb",
    "SGGOODS": "IRAS table rows9/10/12:21(3)(g)/(h)/(f), goods/export evidence",
    "SGKLAND": "IRAS table row14/(k), professional/data goods-for-export exception and definite/immediate intention condition",
    "SGLAND": "Same table row13/(j), Singapore goods/land restriction",
    "SGLOCAL": "Same table rows13/(j) and14/(k), identical local-beneficiary alternative"
  },
  "conditions_context": "Determine the contractual customer's belonging status, not just its incorporation address. A Singapore business/fixed establishment most directly using the contracted service can change that status. Separately identify direct beneficiaries and their GST registration. A Singapore branch or beneficiary does **not** automatically deny relief: the local GST-registered beneficiary limb can apply if the overseas-contract and other conditions are met. Unregistered local benefit, or a contractual customer actually belonging in Singapore, can produce a different outcome. Source: [official source].",
  "current_goods_ships_boundary": "Singapore professional-versus-data Singapore-goods/ships conditions under the current Second Schedule: the retained 2020 official reproduction distinguishes professional services (export goods and ships) from data services (export goods only), while the current IRAS table combines the categories. The former combined proposition \"professional/data services must not directly relate to Singapore land/goods other than goods for export\" is individually unusable for this branch until the current regulatory text/version is reconciled; no ships relief or blanket ships exclusion is cleared here. ",
  "evidence_entry_ids": [
    "SGLOCAL",
    "SGCONTRACT",
    "SGABS",
    "SGLAND",
    "SGGOODS",
    "SGBUSINESS",
    "SGKLAND"
  ],
  "evidence_format_status": "CURRENT_SHORT_EXTRACT_STANDARD_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "historical_format_status": "HOLD_EXPLICIT_EXTRACT_GAP",
  "historical_quotation_gaps": [
    "SGABS",
    "SGGOODS",
    "SGKLAND"
  ],
  "id": 188,
  "line": 188,
  "original_review_exact_claim": "Separately identify direct beneficiaries and their GST registration.",
  "original_review_row_id": 184,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 6: Singaporean seller to an overseas customer",
  "source_keys": [
    "SG"
  ]
}
```

### 189

A Singapore branch or beneficiary does **not** automatically deny relief: the local GST-registered beneficiary limb can apply if the overseas-contract and other conditions are met.

```json
{
  "act_articles": {
    "SGABS": "IRAS table row13/(j), overseas customer absence and overseas direct beneficiary absence",
    "SGBELONG": "IRAS Belonging status / Customer is a business / numbered1-3 plus business/fixed establishment definitions",
    "SGBUSINESS": "Same table row14/(k), contractual business-capacity limb",
    "SGCONTRACT": "IRAS international-services table row13/(j) and row14/(k), identical overseas-contract limb",
    "SGKLAND": "IRAS table row14/(k), professional/data goods-for-export exception and definite/immediate intention condition",
    "SGLOCAL": "Same table rows13/(j) and14/(k), identical local-beneficiary alternative"
  },
  "conditions_context": "Determine the contractual customer's belonging status, not just its incorporation address. A Singapore business/fixed establishment most directly using the contracted service can change that status. Separately identify direct beneficiaries and their GST registration. A Singapore branch or beneficiary does **not** automatically deny relief: the local GST-registered beneficiary limb can apply if the overseas-contract and other conditions are met. Unregistered local benefit, or a contractual customer actually belonging in Singapore, can produce a different outcome. Source: [official source].",
  "current_goods_ships_boundary": "Singapore professional-versus-data Singapore-goods/ships conditions under the current Second Schedule: the retained 2020 official reproduction distinguishes professional services (export goods and ships) from data services (export goods only), while the current IRAS table combines the categories. The former combined proposition \"professional/data services must not directly relate to Singapore land/goods other than goods for export\" is individually unusable for this branch until the current regulatory text/version is reconciled; no ships relief or blanket ships exclusion is cleared here. ",
  "evidence_entry_ids": [
    "SGCONTRACT",
    "SGLOCAL",
    "SGBELONG",
    "SGABS",
    "SGBUSINESS",
    "SGKLAND"
  ],
  "evidence_format_status": "CURRENT_SHORT_EXTRACT_STANDARD_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "historical_format_status": "HOLD_EXPLICIT_EXTRACT_GAP",
  "historical_quotation_gaps": [
    "SGBELONG",
    "SGABS",
    "SGKLAND"
  ],
  "id": 189,
  "line": 188,
  "original_review_exact_claim": "A Singapore branch or beneficiary does **not** automatically deny relief: the local GST-registered beneficiary limb can apply if the overseas-contract and other conditions are met.",
  "original_review_row_id": 185,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 6: Singaporean seller to an overseas customer",
  "source_keys": [
    "SG"
  ]
}
```

### 190

Unregistered local benefit, or a contractual customer actually belonging in Singapore, can produce a different outcome.

```json
{
  "act_articles": {
    "SGABS": "IRAS table row13/(j), overseas customer absence and overseas direct beneficiary absence",
    "SGBELONG": "IRAS Belonging status / Customer is a business / numbered1-3 plus business/fixed establishment definitions",
    "SGLOCAL": "Same table rows13/(j) and14/(k), identical local-beneficiary alternative"
  },
  "conditions_context": "Determine the contractual customer's belonging status, not just its incorporation address. A Singapore business/fixed establishment most directly using the contracted service can change that status. Separately identify direct beneficiaries and their GST registration. A Singapore branch or beneficiary does **not** automatically deny relief: the local GST-registered beneficiary limb can apply if the overseas-contract and other conditions are met. Unregistered local benefit, or a contractual customer actually belonging in Singapore, can produce a different outcome. Source: [official source].",
  "evidence_entry_ids": [
    "SGLOCAL",
    "SGBELONG",
    "SGABS"
  ],
  "evidence_format_status": "CURRENT_SHORT_EXTRACT_STANDARD_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "historical_format_status": "HOLD_EXPLICIT_EXTRACT_GAP",
  "historical_quotation_gaps": [
    "SGBELONG",
    "SGABS"
  ],
  "id": 190,
  "line": 188,
  "original_review_exact_claim": "Unregistered local benefit, or a contractual customer actually belonging in Singapore, can produce a different outcome.",
  "original_review_row_id": 186,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 6: Singaporean seller to an overseas customer",
  "source_keys": [
    "SG"
  ]
}
```

### 191

Source: [official source].

```json
{
  "act_articles": {
    "SGABS": "IRAS table row13/(j), overseas customer absence and overseas direct beneficiary absence",
    "SGBELONG": "IRAS Belonging status / Customer is a business / numbered1-3 plus business/fixed establishment definitions",
    "SGBUSINESS": "Same table row14/(k), contractual business-capacity limb",
    "SGCONTRACT": "IRAS international-services table row13/(j) and row14/(k), identical overseas-contract limb",
    "SGGOODS": "IRAS table rows9/10/12:21(3)(g)/(h)/(f), goods/export evidence",
    "SGKLAND": "IRAS table row14/(k), professional/data goods-for-export exception and definite/immediate intention condition",
    "SGLAND": "Same table row13/(j), Singapore goods/land restriction",
    "SGLOCAL": "Same table rows13/(j) and14/(k), identical local-beneficiary alternative"
  },
  "conditions_context": "Determine the contractual customer's belonging status, not just its incorporation address. A Singapore business/fixed establishment most directly using the contracted service can change that status. Separately identify direct beneficiaries and their GST registration. A Singapore branch or beneficiary does **not** automatically deny relief: the local GST-registered beneficiary limb can apply if the overseas-contract and other conditions are met. Unregistered local benefit, or a contractual customer actually belonging in Singapore, can produce a different outcome. Source: [official source].",
  "current_goods_ships_boundary": "Singapore professional-versus-data Singapore-goods/ships conditions under the current Second Schedule: the retained 2020 official reproduction distinguishes professional services (export goods and ships) from data services (export goods only), while the current IRAS table combines the categories. The former combined proposition \"professional/data services must not directly relate to Singapore land/goods other than goods for export\" is individually unusable for this branch until the current regulatory text/version is reconciled; no ships relief or blanket ships exclusion is cleared here. ",
  "evidence_entry_ids": [
    "SGBELONG",
    "SGCONTRACT",
    "SGABS",
    "SGLOCAL",
    "SGLAND",
    "SGGOODS",
    "SGBUSINESS",
    "SGKLAND"
  ],
  "evidence_format_status": "CURRENT_SHORT_EXTRACT_STANDARD_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "historical_format_status": "HOLD_EXPLICIT_EXTRACT_GAP",
  "historical_quotation_gaps": [
    "SGBELONG",
    "SGABS",
    "SGGOODS",
    "SGKLAND"
  ],
  "id": 191,
  "line": 188,
  "original_review_exact_claim": "Source: [official source].",
  "original_review_row_id": 187,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 6: Singaporean seller to an overseas customer",
  "source_keys": [
    "SG"
  ]
}
```

### 192

Report qualifying zero-rated international services in **GST return Box 2**.

```json
{
  "act_articles": {
    "SGBOX2": "IRAS Completing GST returns / Box2 title and qualifying international-services explanation"
  },
  "conditions_context": "Report qualifying zero-rated international services in **GST return Box 2**. Input GST is deductible only if all applicable conditions hold, including GST registration, business/taxable use, proper invoices/import evidence, attribution, disallowance and fraud checks; mixed exempt/non-business use can restrict recovery. Sources: [official source]; [official source].",
  "evidence_entry_ids": [
    "SGBOX2"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "Only SGRETURN proves Box2; SGINPUT is not evidence of the output return field.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "2"
  ],
  "id": 192,
  "line": 190,
  "original_review_exact_claim": "Report qualifying zero-rated international services in **GST return Box 2**.",
  "original_review_row_id": 188,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 6: Singaporean seller to an overseas customer",
  "source_keys": [
    "SGRETURN"
  ]
}
```

### 193

Input GST is deductible only if all applicable conditions hold, including GST registration, business/taxable use, proper invoices/import evidence, attribution, disallowance and fraud checks; mixed exempt/non-business use can restrict recovery.

```json
{
  "act_articles": {
    "SGALL8": "IRAS Conditions you must meet, opening and complete enumerated conditions1-8",
    "SGATTRIB": "Same page, business/nonbusiness use paragraph following condition3",
    "SGINPUTDETAIL": "IRAS Conditions you must meet, enumerated1-8; attribution/private/exempt/nonclaimable/fraud paragraphs"
  },
  "conditions_context": "Report qualifying zero-rated international services in **GST return Box 2**. Input GST is deductible only if all applicable conditions hold, including GST registration, business/taxable use, proper invoices/import evidence, attribution, disallowance and fraud checks; mixed exempt/non-business use can restrict recovery. Sources: [official source]; [official source].",
  "evidence_entry_ids": [
    "SGALL8",
    "SGATTRIB",
    "SGINPUTDETAIL"
  ],
  "evidence_format_status": "CURRENT_SHORT_EXTRACT_STANDARD_APPLICABLE",
  "evidence_recommendation_note": "Opening all-eight requirement read with all8 enumerated items and attribution/mixed-use/blocked/fraud neighbours; limited extract does not purport to reproduce the whole guidance checklist. See SGINPUTDETAIL gap.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "historical_format_status": "HOLD_EXPLICIT_EXTRACT_GAP",
  "historical_quotation_gaps": [
    "SGINPUTDETAIL"
  ],
  "id": 193,
  "line": 190,
  "original_review_exact_claim": "Input GST is deductible only if all applicable conditions hold, including GST registration, business/taxable use, proper invoices/import evidence, attribution, disallowance and fraud checks; mixed exempt/non-business use can restrict recovery.",
  "original_review_row_id": 189,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 6: Singaporean seller to an overseas customer",
  "source_keys": [
    "SGINPUT"
  ]
}
```

### 194

Sources: [official source]; [official source].

```json
{
  "act_articles": {
    "SGALL8": "IRAS Conditions you must meet, opening and complete enumerated conditions1-8",
    "SGATTRIB": "Same page, business/nonbusiness use paragraph following condition3",
    "SGBOX2": "IRAS Completing GST returns / Box2 title and qualifying international-services explanation"
  },
  "conditions_context": "Report qualifying zero-rated international services in **GST return Box 2**. Input GST is deductible only if all applicable conditions hold, including GST registration, business/taxable use, proper invoices/import evidence, attribution, disallowance and fraud checks; mixed exempt/non-business use can restrict recovery. Sources: [official source]; [official source].",
  "evidence_entry_ids": [
    "SGALL8",
    "SGATTRIB",
    "SGBOX2"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 194,
  "line": 190,
  "original_review_exact_claim": "Sources: [official source]; [official source].",
  "original_review_row_id": 190,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 6: Singaporean seller to an overseas customer",
  "source_keys": [
    "SGINPUT",
    "SGRETURN"
  ]
}
```

### 195

**Original common scenario:** a Singapore UI/UX designer supplies a UK company.

```json
{
  "act_articles": {},
  "conditions_context": "**Original common scenario:** a Singapore UI/UX designer supplies a UK company. With evidenced overseas contractual/beneficiary status and the relevant section 21(3) conditions, GST can be zero-rated; a foreign invoice address alone does not establish this. Input credit remains conditional and Box 2 applies only to the qualifying supply. Sources: [official source]; [official source]; [official source].",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 195,
  "line": 192,
  "original_review_exact_claim": "**Original common scenario:** a Singapore UI/UX designer supplies a UK company.",
  "original_review_row_id": 191,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 6: Singaporean seller to an overseas customer",
  "source_keys": [
    "POLICY"
  ]
}
```

### 196

With evidenced overseas contractual/beneficiary status and the relevant section 21(3) conditions, GST can be zero-rated; a foreign invoice address alone does not establish this.

```json
{
  "act_articles": {
    "SGABS": "IRAS table row13/(j), overseas customer absence and overseas direct beneficiary absence",
    "SGBELONG": "IRAS Belonging status / Customer is a business / numbered1-3 plus business/fixed establishment definitions",
    "SGBUSINESS": "Same table row14/(k), contractual business-capacity limb",
    "SGCONTRACT": "IRAS international-services table row13/(j) and row14/(k), identical overseas-contract limb",
    "SGGOODS": "IRAS table rows9/10/12:21(3)(g)/(h)/(f), goods/export evidence",
    "SGKLAND": "IRAS table row14/(k), professional/data goods-for-export exception and definite/immediate intention condition",
    "SGLAND": "Same table row13/(j), Singapore goods/land restriction",
    "SGLOCAL": "Same table rows13/(j) and14/(k), identical local-beneficiary alternative"
  },
  "conditions_context": "**Original common scenario:** a Singapore UI/UX designer supplies a UK company. With evidenced overseas contractual/beneficiary status and the relevant section 21(3) conditions, GST can be zero-rated; a foreign invoice address alone does not establish this. Input credit remains conditional and Box 2 applies only to the qualifying supply. Sources: [official source]; [official source]; [official source].",
  "current_goods_ships_boundary": "Singapore professional-versus-data Singapore-goods/ships conditions under the current Second Schedule: the retained 2020 official reproduction distinguishes professional services (export goods and ships) from data services (export goods only), while the current IRAS table combines the categories. The former combined proposition \"professional/data services must not directly relate to Singapore land/goods other than goods for export\" is individually unusable for this branch until the current regulatory text/version is reconciled; no ships relief or blanket ships exclusion is cleared here. ",
  "evidence_entry_ids": [
    "SGCONTRACT",
    "SGABS",
    "SGLOCAL",
    "SGLAND",
    "SGGOODS",
    "SGBUSINESS",
    "SGKLAND",
    "SGBELONG"
  ],
  "evidence_format_status": "CURRENT_SHORT_EXTRACT_STANDARD_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "21(3)"
  ],
  "historical_format_status": "HOLD_EXPLICIT_EXTRACT_GAP",
  "historical_quotation_gaps": [
    "SGABS",
    "SGGOODS",
    "SGKLAND",
    "SGBELONG"
  ],
  "id": 196,
  "line": 192,
  "original_review_exact_claim": "With evidenced overseas contractual/beneficiary status and the relevant section 21(3) conditions, GST can be zero-rated; a foreign invoice address alone does not establish this.",
  "original_review_row_id": 192,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 6: Singaporean seller to an overseas customer",
  "source_keys": [
    "SG"
  ]
}
```

### 197

Input credit remains conditional and Box 2 applies only to the qualifying supply.

```json
{
  "act_articles": {
    "SGALL8": "IRAS Conditions you must meet, opening and complete enumerated conditions1-8",
    "SGATTRIB": "Same page, business/nonbusiness use paragraph following condition3",
    "SGBOX2": "IRAS Completing GST returns / Box2 title and qualifying international-services explanation",
    "SGINPUTDETAIL": "IRAS Conditions you must meet, enumerated1-8; attribution/private/exempt/nonclaimable/fraud paragraphs"
  },
  "conditions_context": "**Original common scenario:** a Singapore UI/UX designer supplies a UK company. With evidenced overseas contractual/beneficiary status and the relevant section 21(3) conditions, GST can be zero-rated; a foreign invoice address alone does not establish this. Input credit remains conditional and Box 2 applies only to the qualifying supply. Sources: [official source]; [official source]; [official source].",
  "evidence_entry_ids": [
    "SGALL8",
    "SGATTRIB",
    "SGBOX2",
    "SGINPUTDETAIL"
  ],
  "evidence_format_status": "CURRENT_SHORT_EXTRACT_STANDARD_APPLICABLE",
  "evidence_recommendation_note": "F1: add SGRETURN beside this repeated Box2 assertion and to original row193 provenance; SGINPUT only supports credits.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "2"
  ],
  "historical_format_status": "HOLD_EXPLICIT_EXTRACT_GAP",
  "historical_quotation_gaps": [
    "SGINPUTDETAIL"
  ],
  "id": 197,
  "line": 192,
  "original_review_exact_claim": "Input credit remains conditional and Box 2 applies only to the qualifying supply.",
  "original_review_row_id": 193,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 6: Singaporean seller to an overseas customer",
  "source_keys": [
    "SGINPUT",
    "SGRETURN"
  ]
}
```

### 198

Sources: [official source]; [official source]; [official source].

```json
{
  "act_articles": {
    "SGALL8": "IRAS Conditions you must meet, opening and complete enumerated conditions1-8",
    "SGATTRIB": "Same page, business/nonbusiness use paragraph following condition3",
    "SGBOX2": "IRAS Completing GST returns / Box2 title and qualifying international-services explanation"
  },
  "conditions_context": "**Original common scenario:** a Singapore UI/UX designer supplies a UK company. With evidenced overseas contractual/beneficiary status and the relevant section 21(3) conditions, GST can be zero-rated; a foreign invoice address alone does not establish this. Input credit remains conditional and Box 2 applies only to the qualifying supply. Sources: [official source]; [official source]; [official source].",
  "evidence_entry_ids": [
    "SGALL8",
    "SGATTRIB",
    "SGBOX2"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "F1: include the SGRETURN link in this source line alongside actual output-field claim.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 198,
  "line": 192,
  "original_review_exact_claim": "Sources: [official source]; [official source].",
  "original_review_row_id": 194,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / The method, step by step / Step 6: Singaporean seller to an overseas customer",
  "source_keys": [
    "SGINPUT",
    "SGRETURN"
  ]
}
```

### 199

| Land/immovable property in EU or UK | Property location governs the sufficiently connected service; taxable liability/exemption/rate is a separate step | Article 47 https://publications.europa.eu/resource/cellar/03c42d77-512a-11f0-a9d0-01aa75ed71a1.0007.02/DOC_1 ; Schedule 4A paragraph 1 https://www.legislation.gov.uk/ukpga/1994/23/schedule/4A/data.xml |

```json
{
  "act_articles": {
    "EU47": "Article 47, final operative clause",
    "REG31A": "Article 31a(1), sufficiently direct land connection",
    "UKSLAND": "Schedule4A paragraph1(1)",
    "UKSSURVEY": "Schedule4A paragraph1(2)(f), professional land services"
  },
  "conditions_context": "| Land/immovable property in EU or UK | Property location governs the sufficiently connected service; taxable liability/exemption/rate is a separate step | Article 47 [official source] ; Schedule 4A paragraph 1 [official source] |",
  "evidence_entry_ids": [
    "EU47",
    "REG31A",
    "UKSLAND",
    "UKSSURVEY"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "47",
    "03",
    "2",
    "7",
    "512",
    "11",
    "01",
    "5",
    "1",
    "0007.02",
    "1",
    "4",
    "1",
    "1994",
    "23",
    "4"
  ],
  "id": 199,
  "line": 198,
  "original_review_exact_claim": "| Land/immovable property in EU or UK | Property location governs the sufficiently connected service; taxable liability/exemption/rate is a separate step | Article 47 https://publications.europa.eu/resource/cellar/03c42d77-512a-11f0-a9d0-01aa75ed71a1.0007.02/DOC_1 ; Schedule 4A paragraph 1 https://www.legislation.gov.uk/ukpga/1994/23/schedule/4A/data.xml |",
  "original_review_row_id": 195,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Boundary and exception table",
  "source_keys": [
    "EU",
    "REG",
    "UKSCH"
  ]
}
```

### 200

| Land/property in AU, India or Singapore | Use the specific country tests: AU item 2 alternatives/exclusions, India section 13(4), SG relevant section 21(3) land exclusion/overseas-land relief. Do not transplant the EU test or assert every domestic land service has the same rate | https://www.legislation.gov.au/C2004A00446/2026-01-01/2026-01-01/text/original/epub/OEBPS/document_1/document_1.html ; https://thc.nic.in/Central%20Governmental%20Acts/Integrated%20Goods%20and%20Services%20Tax%20Act%2C%202017..pdf ; https://www.iras.gov.sg/taxes/goods-services-tax-%28gst%29/charging-gst-%28output-tax%29/when-to-charge-0-gst-%28zero-rate%29/providing-international-services |

```json
{
  "act_articles": {
    "AU2A": "s38-190(1), item2(a)",
    "AU2ABS": "s38-190(1), item2 chapeau",
    "AU2ALAND": "s38-190(1), item2(a), land condition",
    "AU2BENT": "s38-190(1), item2(b), enterprise condition",
    "AU2BREG": "s38-190(1) item2(b), actual registration wording",
    "AUPROP": "s38-190(2A), input-taxed property exclusion",
    "IN13LAND": "IGST13(4)",
    "SGKLAND": "IRAS table row14/(k), professional/data goods-for-export exception and definite/immediate intention condition",
    "SGLAND": "Same table row13/(j), Singapore goods/land restriction"
  },
  "conditions_context": "| Land/property in AU, India or Singapore | Use the specific country tests: AU item 2 alternatives/exclusions, India section 13(4), SG relevant section 21(3) land exclusion/overseas-land relief. Do not transplant the EU test or assert every domestic land service has the same rate | [official source] ; [official source] ; [official source] |",
  "current_goods_ships_boundary": "Singapore professional-versus-data Singapore-goods/ships conditions under the current Second Schedule: the retained 2020 official reproduction distinguishes professional services (export goods and ships) from data services (export goods only), while the current IRAS table combines the categories. The former combined proposition \"professional/data services must not directly relate to Singapore land/goods other than goods for export\" is individually unusable for this branch until the current regulatory text/version is reconciled; no ships relief or blanket ships exclusion is cleared here. ",
  "evidence_entry_ids": [
    "AU2ABS",
    "AU2A",
    "AU2ALAND",
    "AU2BENT",
    "AU2BREG",
    "AUPROP",
    "IN13LAND",
    "SGLAND",
    "SGKLAND"
  ],
  "evidence_format_status": "CURRENT_SHORT_EXTRACT_STANDARD_APPLICABLE",
  "evidence_recommendation_note": "Specific relief and exclusions are country-specific; no universal domestic-land rate result is asserted.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "2",
    "13(4)",
    "21(3)",
    "004",
    "0446",
    "2026",
    "01",
    "01",
    "2026",
    "01",
    "01",
    "1",
    "1.",
    "20",
    "20",
    "20",
    "20",
    "20",
    "20",
    "20",
    "2",
    "202017..",
    "28",
    "29",
    "28",
    "29",
    "0",
    "28",
    "29"
  ],
  "historical_format_status": "HOLD_EXPLICIT_EXTRACT_GAP",
  "historical_quotation_gaps": [
    "SGKLAND"
  ],
  "id": 200,
  "line": 199,
  "original_review_exact_claim": "| Land/property in AU, India or Singapore | Use the specific country tests: AU item 2 alternatives/exclusions, India section 13(4), SG relevant section 21(3) land exclusion/overseas-land relief. Do not transplant the EU test or assert every domestic land service has the same rate | https://www.legislation.gov.au/C2004A00446/2026-01-01/2026-01-01/text/original/epub/OEBPS/document_1/document_1.html ; https://thc.nic.in/Central%20Governmental%20Acts/Integrated%20Goods%20and%20Services%20Tax%20Act%2C%202017..pdf ; https://www.iras.gov.sg/taxes/goods-services-tax-%28gst%29/charging-gst-%28output-tax%29/when-to-charge-0-gst-%28zero-rate%29/providing-international-services |",
  "original_review_row_id": 196,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Boundary and exception table",
  "source_keys": [
    "AU",
    "IN",
    "SG"
  ]
}
```

### 201

| Event admission/attendance | EU in-person B2B admission Article 53; B2C activities Article 54; distinguish virtual attendance. UK performance/admission rules must be checked separately | https://publications.europa.eu/resource/cellar/03c42d77-512a-11f0-a9d0-01aa75ed71a1.0007.02/DOC_1 ; https://www.gov.uk/guidance/vat-place-of-supply-of-services-notice-741a |

```json
{
  "act_articles": {
    "EU53": "Article 53, first paragraph",
    "EU53V": "Article 53, second paragraph",
    "EU54": "Article 54(1), first subparagraph",
    "EU54V": "Article 54(1), second subparagraph",
    "EU54VC": "Article 54(1), second subparagraph, result",
    "UKSACT": "Schedule4A paragraph14A(1)-(2), nonbusiness-person activity",
    "UKSADMIT": "Schedule4A paragraph9A(1)/(2), B2B admission"
  },
  "conditions_context": "| Event admission/attendance | EU in-person B2B admission Article 53; B2C activities Article 54; distinguish virtual attendance. UK performance/admission rules must be checked separately | [official source] ; [official source] |",
  "evidence_entry_ids": [
    "EU53",
    "EU53V",
    "EU54",
    "EU54V",
    "EU54VC",
    "UKSADMIT",
    "UKSACT"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "53",
    "54",
    "03",
    "2",
    "7",
    "512",
    "11",
    "01",
    "5",
    "1",
    "0007.02",
    "1",
    "741"
  ],
  "id": 201,
  "line": 200,
  "original_review_exact_claim": "| Event admission/attendance | EU in-person B2B admission Article 53; B2C activities Article 54; distinguish virtual attendance. UK performance/admission rules must be checked separately | https://publications.europa.eu/resource/cellar/03c42d77-512a-11f0-a9d0-01aa75ed71a1.0007.02/DOC_1 ; https://www.gov.uk/guidance/vat-place-of-supply-of-services-notice-741a |",
  "original_review_row_id": 197,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Boundary and exception table",
  "source_keys": [
    "EU",
    "UKSCH"
  ]
}
```

### 202

| Restaurant/catering | EU Article 55, subject to onboard Article 57; UK physical-performance rule. Overseas customer does not itself confer relief | https://publications.europa.eu/resource/cellar/03c42d77-512a-11f0-a9d0-01aa75ed71a1.0007.02/DOC_1 ; https://www.gov.uk/guidance/vat-place-of-supply-of-services-notice-741a |

```json
{
  "act_articles": {
    "EU55": "Article 55, final operative clause",
    "EU57": "Article 57(1), qualifying onboard catering",
    "UKSCATER": "Schedule4A paragraph5, restaurant/catering"
  },
  "conditions_context": "| Restaurant/catering | EU Article 55, subject to onboard Article 57; UK physical-performance rule. Overseas customer does not itself confer relief | [official source] ; [official source] |",
  "evidence_entry_ids": [
    "EU55",
    "EU57",
    "UKSCATER"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "55,",
    "57",
    "03",
    "2",
    "7",
    "512",
    "11",
    "01",
    "5",
    "1",
    "0007.02",
    "1",
    "741"
  ],
  "id": 202,
  "line": 201,
  "original_review_exact_claim": "| Restaurant/catering | EU Article 55, subject to onboard Article 57; UK physical-performance rule. Overseas customer does not itself confer relief | https://publications.europa.eu/resource/cellar/03c42d77-512a-11f0-a9d0-01aa75ed71a1.0007.02/DOC_1 ; https://www.gov.uk/guidance/vat-place-of-supply-of-services-notice-741a |",
  "original_review_row_id": 198,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Boundary and exception table",
  "source_keys": [
    "EU",
    "UKSCH"
  ]
}
```

### 203

| Passenger transport | EU distance rule Article 48; UK has specific transport rules; Australian international/domestic transport relief is a separate country-law inquiry, not automatically section 38-190 | https://publications.europa.eu/resource/cellar/03c42d77-512a-11f0-a9d0-01aa75ed71a1.0007.02/DOC_1 ; https://www.gov.uk/guidance/vat-place-of-supply-of-services-notice-741a ; https://www.legislation.gov.au/C2004A00446/2026-01-01/2026-01-01/text/original/epub/OEBPS/document_1/document_1.html |

```json
{
  "act_articles": {
    "AUEXTTRANS": "s38-190(5)(a)-(e), goods transport/handling/facilitation/insurance/arrangement; extract(a)",
    "AUEXTX": "s38-190(5), transport-service exclusion to extension",
    "EU48": "Article 48",
    "UKSPASS": "Schedule4A paragraph2(1), passenger transport"
  },
  "conditions_context": "| Passenger transport | EU distance rule Article 48; UK has specific transport rules; Australian international/domestic transport relief is a separate country-law inquiry, not automatically section 38-190 | [official source] ; [official source] ; [official source] |",
  "evidence_entry_ids": [
    "EU48",
    "UKSPASS",
    "AUEXTTRANS",
    "AUEXTX"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "Australian transport relief expressly referred outside this Guide, not cleared as38-190 relief.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "48",
    "38",
    "190",
    "03",
    "2",
    "7",
    "512",
    "11",
    "01",
    "5",
    "1",
    "0007.02",
    "1",
    "741",
    "004",
    "0446",
    "2026",
    "01",
    "01",
    "2026",
    "01",
    "01",
    "1",
    "1."
  ],
  "id": 203,
  "line": 202,
  "original_review_exact_claim": "| Passenger transport | EU distance rule Article 48; UK has specific transport rules; Australian international/domestic transport relief is a separate country-law inquiry, not automatically section 38-190 | https://publications.europa.eu/resource/cellar/03c42d77-512a-11f0-a9d0-01aa75ed71a1.0007.02/DOC_1 ; https://www.gov.uk/guidance/vat-place-of-supply-of-services-notice-741a ; https://www.legislation.gov.au/C2004A00446/2026-01-01/2026-01-01/text/original/epub/OEBPS/document_1/document_1.html |",
  "original_review_row_id": 199,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Boundary and exception table",
  "source_keys": [
    "EU",
    "UKSCH",
    "AU"
  ]
}
```

### 204

| Goods physically in AU or SG | AU item-specific goods-work exclusions and alternative routes matter; SG local-goods restrictions have specified goods-for-export exceptions. Do not say all local work necessarily fails every relief | https://www.legislation.gov.au/C2004A00446/2026-01-01/2026-01-01/text/original/epub/OEBPS/document_1/document_1.html ; https://www.iras.gov.sg/taxes/goods-services-tax-%28gst%29/charging-gst-%28output-tax%29/when-to-charge-0-gst-%28zero-rate%29/providing-international-services |

```json
{
  "act_articles": {
    "AU2A": "s38-190(1), item2(a)",
    "AU2ALAND": "s38-190(1), item2(a), land condition",
    "AU2BENT": "s38-190(1), item2(b), enterprise condition",
    "AU2BREG": "s38-190(1) item2(b), actual registration wording",
    "AU3EX": "s38-190(1), item3 final exclusion",
    "SGGOODS": "IRAS table rows9/10/12:21(3)(g)/(h)/(f), goods/export evidence",
    "SGKLAND": "IRAS table row14/(k), professional/data goods-for-export exception and definite/immediate intention condition"
  },
  "conditions_context": "| Goods physically in AU or SG | AU item-specific goods-work exclusions and alternative routes matter; SG local-goods restrictions have specified goods-for-export exceptions. Do not say all local work necessarily fails every relief | [official source] ; [official source] |",
  "current_goods_ships_boundary": "Singapore professional-versus-data Singapore-goods/ships conditions under the current Second Schedule: the retained 2020 official reproduction distinguishes professional services (export goods and ships) from data services (export goods only), while the current IRAS table combines the categories. The former combined proposition \"professional/data services must not directly relate to Singapore land/goods other than goods for export\" is individually unusable for this branch until the current regulatory text/version is reconciled; no ships relief or blanket ships exclusion is cleared here. ",
  "evidence_entry_ids": [
    "AU2A",
    "AU2ALAND",
    "AU2BENT",
    "AU2BREG",
    "AU3EX",
    "SGGOODS",
    "SGKLAND"
  ],
  "evidence_format_status": "CURRENT_SHORT_EXTRACT_STANDARD_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "004",
    "0446",
    "2026",
    "01",
    "01",
    "2026",
    "01",
    "01",
    "1",
    "1.",
    "28",
    "29",
    "28",
    "29",
    "0",
    "28",
    "29"
  ],
  "historical_format_status": "HOLD_EXPLICIT_EXTRACT_GAP",
  "historical_quotation_gaps": [
    "SGGOODS",
    "SGKLAND"
  ],
  "id": 204,
  "line": 203,
  "original_review_exact_claim": "| Goods physically in AU or SG | AU item-specific goods-work exclusions and alternative routes matter; SG local-goods restrictions have specified goods-for-export exceptions. Do not say all local work necessarily fails every relief | https://www.legislation.gov.au/C2004A00446/2026-01-01/2026-01-01/text/original/epub/OEBPS/document_1/document_1.html ; https://www.iras.gov.sg/taxes/goods-services-tax-%28gst%29/charging-gst-%28output-tax%29/when-to-charge-0-gst-%28zero-rate%29/providing-international-services |",
  "original_review_row_id": 200,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Boundary and exception table",
  "source_keys": [
    "AU",
    "SG"
  ]
}
```

### 205

| Effective use/enjoyment or local benefit | AU item 3 is not all item 2; UK applies specified categories; EU depends on actual Article 59a implementation; SG uses its particular direct-benefit/belonging tests | https://www.legislation.gov.au/C2004A00446/2026-01-01/2026-01-01/text/original/epub/OEBPS/document_1/document_1.html ; https://www.gov.uk/guidance/vat-place-of-supply-of-services-notice-741a ; https://publications.europa.eu/resource/cellar/03c42d77-512a-11f0-a9d0-01aa75ed71a1.0007.02/DOC_1 ; https://www.iras.gov.sg/taxes/goods-services-tax-%28gst%29/charging-gst-%28output-tax%29/when-to-charge-0-gst-%28zero-rate%29/providing-international-services |

```json
{
  "act_articles": {
    "AU2A": "s38-190(1), item2(a)",
    "AU2BENT": "s38-190(1), item2(b), enterprise condition",
    "AU3": "s38-190(1), item3(b)",
    "EU59A": "Article 59a, chapeau and points (a)/(b)",
    "EU59ARANGE": "Article59a, chapeau, listed applicable categories",
    "EU59AU": "Article 59a(a)/(b), effective-use condition",
    "SGABS": "IRAS table row13/(j), overseas customer absence and overseas direct beneficiary absence",
    "SGBELONG": "IRAS Belonging status / Customer is a business / numbered1-3 plus business/fixed establishment definitions",
    "SGBUSINESS": "Same table row14/(k), contractual business-capacity limb",
    "SGCONTRACT": "IRAS international-services table row13/(j) and row14/(k), identical overseas-contract limb",
    "SGGOODS": "IRAS table rows9/10/12:21(3)(g)/(h)/(f), goods/export evidence",
    "SGKLAND": "IRAS table row14/(k), professional/data goods-for-export exception and definite/immediate intention condition",
    "SGLAND": "Same table row13/(j), Singapore goods/land restriction",
    "SGLOCAL": "Same table rows13/(j) and14/(k), identical local-beneficiary alternative",
    "UKSUE": "Schedule4A paragraphs3(3)-(4),7(1)-(2),8(3)-(4),9(1)-(2),9D(2)-(3),9E(3)-(4), specified categories"
  },
  "conditions_context": "| Effective use/enjoyment or local benefit | AU item 3 is not all item 2; UK applies specified categories; EU depends on actual Article 59a implementation; SG uses its particular direct-benefit/belonging tests | [official source] ; [official source] ; [official source] ; [official source] |",
  "current_goods_ships_boundary": "Singapore professional-versus-data Singapore-goods/ships conditions under the current Second Schedule: the retained 2020 official reproduction distinguishes professional services (export goods and ships) from data services (export goods only), while the current IRAS table combines the categories. The former combined proposition \"professional/data services must not directly relate to Singapore land/goods other than goods for export\" is individually unusable for this branch until the current regulatory text/version is reconciled; no ships relief or blanket ships exclusion is cleared here. ",
  "evidence_entry_ids": [
    "AU3",
    "AU2A",
    "AU2BENT",
    "UKSUE",
    "EU59A",
    "EU59ARANGE",
    "EU59AU",
    "SGBELONG",
    "SGCONTRACT",
    "SGABS",
    "SGLOCAL",
    "SGLAND",
    "SGGOODS",
    "SGBUSINESS",
    "SGKLAND"
  ],
  "evidence_format_status": "CURRENT_SHORT_EXTRACT_STANDARD_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "3",
    "2",
    "59",
    "004",
    "0446",
    "2026",
    "01",
    "01",
    "2026",
    "01",
    "01",
    "1",
    "1.",
    "741",
    "03",
    "2",
    "7",
    "512",
    "11",
    "01",
    "5",
    "1",
    "0007.02",
    "1",
    "28",
    "29",
    "28",
    "29",
    "0",
    "28",
    "29"
  ],
  "historical_format_status": "HOLD_EXPLICIT_EXTRACT_GAP",
  "historical_quotation_gaps": [
    "SGBELONG",
    "SGABS",
    "SGGOODS",
    "SGKLAND"
  ],
  "id": 205,
  "line": 204,
  "original_review_exact_claim": "| Effective use/enjoyment or local benefit | AU item 3 is not all item 2; UK applies specified categories; EU depends on actual Article 59a implementation; SG uses its particular direct-benefit/belonging tests | https://www.legislation.gov.au/C2004A00446/2026-01-01/2026-01-01/text/original/epub/OEBPS/document_1/document_1.html ; https://www.gov.uk/guidance/vat-place-of-supply-of-services-notice-741a ; https://publications.europa.eu/resource/cellar/03c42d77-512a-11f0-a9d0-01aa75ed71a1.0007.02/DOC_1 ; https://www.iras.gov.sg/taxes/goods-services-tax-%28gst%29/charging-gst-%28output-tax%29/when-to-charge-0-gst-%28zero-rate%29/providing-international-services |",
  "original_review_row_id": 201,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Boundary and exception table",
  "source_keys": [
    "AU",
    "UKSCH",
    "EU",
    "SG"
  ]
}
```

### 206

| Other B2C service | EU supplier rule Article 45 applies only after all specific rules are excluded, not solely because the service is absent from Article 59 | https://publications.europa.eu/resource/cellar/03c42d77-512a-11f0-a9d0-01aa75ed71a1.0007.02/DOC_1 |

```json
{
  "act_articles": {
    "EU45": "Article 45, first sentence",
    "EU45F": "Article 45, second/third sentences",
    "EU47": "Article 47, final operative clause",
    "EU53": "Article 53, first paragraph",
    "EU54": "Article 54(1), first subparagraph",
    "EU58": "Article 58(1), chapeau",
    "EU59": "Article 59, chapeau, non-EU customer qualification"
  },
  "conditions_context": "| Other B2C service | EU supplier rule Article 45 applies only after all specific rules are excluded, not solely because the service is absent from Article 59 | [official source] |",
  "evidence_entry_ids": [
    "EU45",
    "EU45F",
    "EU47",
    "EU53",
    "EU54",
    "EU58",
    "EU59"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "45",
    "59",
    "03",
    "2",
    "7",
    "512",
    "11",
    "01",
    "5",
    "1",
    "0007.02",
    "1"
  ],
  "id": 206,
  "line": 205,
  "original_review_exact_claim": "| Other B2C service | EU supplier rule Article 45 applies only after all specific rules are excluded, not solely because the service is absent from Article 59 | https://publications.europa.eu/resource/cellar/03c42d77-512a-11f0-a9d0-01aa75ed71a1.0007.02/DOC_1 |",
  "original_review_row_id": 202,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Boundary and exception table",
  "source_keys": [
    "EU"
  ]
}
```

### 207

The original amounts, countries and scenarios are retained.

```json
{
  "act_articles": {},
  "conditions_context": "The original amounts, countries and scenarios are retained. Each assumes the seller's ordinary registration and no relevant exemption/special scheme unless stated. Establish the additional decisive facts below before using a result; figures are example inputs or derived results, not new thresholds.",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 207,
  "line": 209,
  "original_review_exact_claim": "The original amounts, countries and scenarios are retained.",
  "original_review_row_id": 203,
  "quotation_gaps": [],
  "result_boundary": "Internal workflow/provenance/example-intake policy; not external law",
  "section": "Quick reference / Worked cases",
  "source_keys": [
    "POLICY"
  ]
}
```

### 208

Each assumes the seller's ordinary registration and no relevant exemption/special scheme unless stated.

```json
{
  "act_articles": {},
  "conditions_context": "The original amounts, countries and scenarios are retained. Each assumes the seller's ordinary registration and no relevant exemption/special scheme unless stated. Establish the additional decisive facts below before using a result; figures are example inputs or derived results, not new thresholds.",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 208,
  "line": 209,
  "original_review_exact_claim": "Each assumes the seller's ordinary registration and no relevant exemption/special scheme unless stated.",
  "original_review_row_id": 204,
  "quotation_gaps": [],
  "result_boundary": "Internal workflow/provenance/example-intake policy; not external law",
  "section": "Quick reference / Worked cases",
  "source_keys": [
    "POLICY"
  ]
}
```

### 209

Establish the additional decisive facts below before using a result; figures are example inputs or derived results, not new thresholds.

```json
{
  "act_articles": {},
  "conditions_context": "The original amounts, countries and scenarios are retained. Each assumes the seller's ordinary registration and no relevant exemption/special scheme unless stated. Establish the additional decisive facts below before using a result; figures are example inputs or derived results, not new thresholds.",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 209,
  "line": 209,
  "original_review_exact_claim": "Establish the additional decisive facts below before using a result; figures are example inputs or derived results, not new thresholds.",
  "original_review_row_id": 205,
  "quotation_gaps": [],
  "result_boundary": "Internal workflow/provenance/example-intake policy; not external law",
  "section": "Quick reference / Worked cases",
  "source_keys": [
    "POLICY"
  ]
}
```

### 210

Remote software development, EUR 5,000 monthly.

```json
{
  "act_articles": {},
  "conditions_context": "Remote software development, EUR 5,000 monthly. Assuming the actual US business establishment receives it for business use and no particular-place/use-enjoyment override applies, Article 44 places it in the US. Malta output VAT from this invoice is EUR 0; customer total EUR 5,000. Describe outside scope, not a statutory 0% Malta rate. Deduct qualifying Malta inputs under the conditions above; do not promise full recovery of every cost. The former Malta Box 2 instruction remains unconfirmed and must not be filed from this example. Sources: [official source]; [official source].",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "5,000"
  ],
  "id": 210,
  "line": 213,
  "original_review_exact_claim": "Remote software development, EUR 5,000 monthly.",
  "original_review_row_id": 206,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Example 1: Malta IT freelancer to US client, B2B",
  "source_keys": [
    "POLICY"
  ]
}
```

### 211

Assuming the actual US business establishment receives it for business use and no particular-place/use-enjoyment override applies, Article 44 places it in the US.

```json
{
  "act_articles": {
    "EU44ACT": "Article44, first sentence, taxable business-capacity condition",
    "EU44B": "Article 44, first sentence",
    "EU44F": "Article 44, second sentence",
    "EU44R": "Article 44, third sentence",
    "EU59A": "Article 59a, chapeau and points (a)/(b)",
    "EU59ARANGE": "Article59a, chapeau, listed applicable categories",
    "EU59AU": "Article 59a(a)/(b), effective-use condition",
    "REG21": "Article 21, first/second paragraphs, relevant establishment",
    "REG22": "Article 22(1), identification of receiving establishment",
    "REG22C": "Article 22(1), secondary evidence"
  },
  "conditions_context": "Remote software development, EUR 5,000 monthly. Assuming the actual US business establishment receives it for business use and no particular-place/use-enjoyment override applies, Article 44 places it in the US. Malta output VAT from this invoice is EUR 0; customer total EUR 5,000. Describe outside scope, not a statutory 0% Malta rate. Deduct qualifying Malta inputs under the conditions above; do not promise full recovery of every cost. The former Malta Box 2 instruction remains unconfirmed and must not be filed from this example. Sources: [official source]; [official source].",
  "evidence_entry_ids": [
    "EU44ACT",
    "EU44B",
    "EU44F",
    "EU44R",
    "REG21",
    "REG22",
    "REG22C",
    "EU59A",
    "EU59ARANGE",
    "EU59AU"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "44"
  ],
  "id": 211,
  "line": 213,
  "original_review_exact_claim": "Assuming the actual US business establishment receives it for business use and no particular-place/use-enjoyment override applies, Article 44 places it in the US.",
  "original_review_row_id": 207,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Example 1: Malta IT freelancer to US client, B2B",
  "source_keys": [
    "EU",
    "REG"
  ]
}
```

### 212

Malta output VAT from this invoice is EUR 0; customer total EUR 5,000.

```json
{
  "act_articles": {
    "EU44ACT": "Article44, first sentence, taxable business-capacity condition",
    "EU44B": "Article 44, first sentence",
    "EU44F": "Article 44, second sentence",
    "EU44R": "Article 44, third sentence",
    "REG21": "Article 21, first/second paragraphs, relevant establishment",
    "REG22": "Article 22(1), identification of receiving establishment",
    "REG22C": "Article 22(1), secondary evidence"
  },
  "conditions_context": "Remote software development, EUR 5,000 monthly. Assuming the actual US business establishment receives it for business use and no particular-place/use-enjoyment override applies, Article 44 places it in the US. Malta output VAT from this invoice is EUR 0; customer total EUR 5,000. Describe outside scope, not a statutory 0% Malta rate. Deduct qualifying Malta inputs under the conditions above; do not promise full recovery of every cost. The former Malta Box 2 instruction remains unconfirmed and must not be filed from this example. Sources: [official source]; [official source].",
  "evidence_entry_ids": [
    "EU44ACT",
    "EU44B",
    "EU44F",
    "EU44R",
    "REG21",
    "REG22",
    "REG22C"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "Original hypothetical fee5000, zero seller output follows outside-place assumption; independently recomputed, not a legal zero-rate threshold.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "0",
    "5,000."
  ],
  "id": 212,
  "line": 213,
  "original_review_exact_claim": "Malta output VAT from this invoice is EUR 0; customer total EUR 5,000.",
  "original_review_row_id": 208,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Example 1: Malta IT freelancer to US client, B2B",
  "source_keys": [
    "EU",
    "REG"
  ]
}
```

### 213

Describe outside scope, not a statutory 0% Malta rate.

```json
{
  "act_articles": {
    "EU44ACT": "Article44, first sentence, taxable business-capacity condition",
    "EU44B": "Article 44, first sentence",
    "EU44F": "Article 44, second sentence",
    "EU44R": "Article 44, third sentence",
    "REG21": "Article 21, first/second paragraphs, relevant establishment",
    "REG22": "Article 22(1), identification of receiving establishment",
    "REG22C": "Article 22(1), secondary evidence"
  },
  "conditions_context": "Remote software development, EUR 5,000 monthly. Assuming the actual US business establishment receives it for business use and no particular-place/use-enjoyment override applies, Article 44 places it in the US. Malta output VAT from this invoice is EUR 0; customer total EUR 5,000. Describe outside scope, not a statutory 0% Malta rate. Deduct qualifying Malta inputs under the conditions above; do not promise full recovery of every cost. The former Malta Box 2 instruction remains unconfirmed and must not be filed from this example. Sources: [official source]; [official source].",
  "evidence_entry_ids": [
    "EU44ACT",
    "EU44B",
    "EU44F",
    "EU44R",
    "REG21",
    "REG22",
    "REG22C"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "Original hypothetical fee5000, zero seller output follows outside-place assumption; independently recomputed, not a legal zero-rate threshold.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "0%"
  ],
  "id": 213,
  "line": 213,
  "original_review_exact_claim": "Describe outside scope, not a statutory 0% Malta rate.",
  "original_review_row_id": 209,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Example 1: Malta IT freelancer to US client, B2B",
  "source_keys": [
    "EU",
    "REG"
  ]
}
```

### 214

Deduct qualifying Malta inputs under the conditions above; do not promise full recovery of every cost.

```json
{
  "act_articles": {
    "EU168": "Article 168, chapeau",
    "EU169A": "Article 169(a), domestic-deductibility condition",
    "EU169AX": "Article 169(a), Article 284 exclusion",
    "EU169C": "Article 169(c), financial/insurance route",
    "EU173": "Article 173(1), mixed use",
    "EU176": "Article 176, second paragraph",
    "EU178": "Article 178(a), invoice condition"
  },
  "conditions_context": "Remote software development, EUR 5,000 monthly. Assuming the actual US business establishment receives it for business use and no particular-place/use-enjoyment override applies, Article 44 places it in the US. Malta output VAT from this invoice is EUR 0; customer total EUR 5,000. Describe outside scope, not a statutory 0% Malta rate. Deduct qualifying Malta inputs under the conditions above; do not promise full recovery of every cost. The former Malta Box 2 instruction remains unconfirmed and must not be filed from this example. Sources: [official source]; [official source].",
  "evidence_entry_ids": [
    "EU168",
    "EU169A",
    "EU169AX",
    "EU169C",
    "EU173",
    "EU176",
    "EU178"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 214,
  "line": 213,
  "original_review_exact_claim": "Deduct qualifying Malta inputs under the conditions above; do not promise full recovery of every cost.",
  "original_review_row_id": 210,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Example 1: Malta IT freelancer to US client, B2B",
  "source_keys": [
    "EU"
  ]
}
```

### 215

The former Malta Box 2 instruction remains unconfirmed and must not be filed from this example.

```json
{
  "act_articles": {},
  "conditions_context": "Remote software development, EUR 5,000 monthly. Assuming the actual US business establishment receives it for business use and no particular-place/use-enjoyment override applies, Article 44 places it in the US. Malta output VAT from this invoice is EUR 0; customer total EUR 5,000. Describe outside scope, not a statutory 0% Malta rate. Deduct qualifying Malta inputs under the conditions above; do not promise full recovery of every cost. The former Malta Box 2 instruction remains unconfirmed and must not be filed from this example. Sources: [official source]; [official source].",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": "Unconfirmed Maltese return field; no filing direction.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "2"
  ],
  "id": 215,
  "line": 213,
  "original_review_exact_claim": "The former Malta Box 2 instruction remains unconfirmed and must not be filed from this example.",
  "original_review_row_id": 211,
  "quotation_gaps": [],
  "result_boundary": "Reserved assertion or correction; not a usable old filing figure",
  "section": "Quick reference / Worked cases / Example 1: Malta IT freelancer to US client, B2B",
  "source_keys": [
    "POLICY"
  ]
}
```

### 216

Sources: [official source]; [official source].

```json
{
  "act_articles": {
    "EU168": "Article 168, chapeau",
    "EU169A": "Article 169(a), domestic-deductibility condition",
    "EU169AX": "Article 169(a), Article 284 exclusion",
    "EU169C": "Article 169(c), financial/insurance route",
    "EU173": "Article 173(1), mixed use",
    "EU176": "Article 176, second paragraph",
    "EU178": "Article 178(a), invoice condition",
    "EU44ACT": "Article44, first sentence, taxable business-capacity condition",
    "EU44B": "Article 44, first sentence",
    "EU44F": "Article 44, second sentence",
    "EU44R": "Article 44, third sentence",
    "REG21": "Article 21, first/second paragraphs, relevant establishment",
    "REG22": "Article 22(1), identification of receiving establishment",
    "REG22C": "Article 22(1), secondary evidence"
  },
  "conditions_context": "Remote software development, EUR 5,000 monthly. Assuming the actual US business establishment receives it for business use and no particular-place/use-enjoyment override applies, Article 44 places it in the US. Malta output VAT from this invoice is EUR 0; customer total EUR 5,000. Describe outside scope, not a statutory 0% Malta rate. Deduct qualifying Malta inputs under the conditions above; do not promise full recovery of every cost. The former Malta Box 2 instruction remains unconfirmed and must not be filed from this example. Sources: [official source]; [official source].",
  "evidence_entry_ids": [
    "EU44ACT",
    "EU44B",
    "EU44F",
    "EU44R",
    "REG21",
    "REG22",
    "REG22C",
    "EU168",
    "EU169A",
    "EU169AX",
    "EU169C",
    "EU173",
    "EU176",
    "EU178"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 216,
  "line": 213,
  "original_review_exact_claim": "Sources: [official source]; [official source].",
  "original_review_row_id": 212,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Example 1: Malta IT freelancer to US client, B2B",
  "source_keys": [
    "EU",
    "REG"
  ]
}
```

### 217

Branding invoice EUR 3,000, received by the Japanese business establishment.

```json
{
  "act_articles": {},
  "conditions_context": "Branding invoice EUR 3,000, received by the Japanese business establishment. On ordinary Article 44 facts, German output VAT is EUR 0 and invoice total EUR 3,000; 2026 UStVA row 36/KZ 45 applies if the stated non-taxable foreign-place reporting conditions hold. Sources: [official source]; [official source]; [official source].",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "3,000,"
  ],
  "id": 217,
  "line": 217,
  "original_review_exact_claim": "Branding invoice EUR 3,000, received by the Japanese business establishment.",
  "original_review_row_id": 213,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Example 2: German designer to Japanese client, B2B",
  "source_keys": [
    "POLICY"
  ]
}
```

### 218

On ordinary Article 44 facts, German output VAT is EUR 0 and invoice total EUR 3,000; 2026 UStVA row 36/KZ 45 applies if the stated non-taxable foreign-place reporting conditions hold.

```json
{
  "act_articles": {
    "DE45": "2026UStVA form PDFpage5, row36/KZ45",
    "DEEXROWS": "Same section, rows33-35 exclusion",
    "DEFOREIGN": "ELSTER2026 / Übrige nicht steuerbare Umsätze, first paragraph",
    "DETAXABLE": "Same paragraph, domestic-taxability condition",
    "EU44ACT": "Article44, first sentence, taxable business-capacity condition",
    "EU44B": "Article 44, first sentence",
    "EU44F": "Article 44, second sentence",
    "EU44R": "Article 44, third sentence",
    "REG21": "Article 21, first/second paragraphs, relevant establishment",
    "REG22": "Article 22(1), identification of receiving establishment",
    "REG22C": "Article 22(1), secondary evidence"
  },
  "conditions_context": "Branding invoice EUR 3,000, received by the Japanese business establishment. On ordinary Article 44 facts, German output VAT is EUR 0 and invoice total EUR 3,000; 2026 UStVA row 36/KZ 45 applies if the stated non-taxable foreign-place reporting conditions hold. Sources: [official source]; [official source]; [official source].",
  "evidence_entry_ids": [
    "EU44ACT",
    "EU44B",
    "EU44F",
    "EU44R",
    "REG21",
    "REG22",
    "REG22C",
    "DE45",
    "DEFOREIGN",
    "DETAXABLE",
    "DEEXROWS"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "Hypothetical3000+0=3000 independently recomputed; reporting conditional on same foreign-place/domestic-taxable facts.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "44",
    "0",
    "3,000",
    "2026",
    "36",
    "45"
  ],
  "id": 218,
  "line": 217,
  "original_review_exact_claim": "On ordinary Article 44 facts, German output VAT is EUR 0 and invoice total EUR 3,000; 2026 UStVA row 36/KZ 45 applies if the stated non-taxable foreign-place reporting conditions hold.",
  "original_review_row_id": 214,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Example 2: German designer to Japanese client, B2B",
  "source_keys": [
    "EU",
    "REG",
    "DE",
    "DEHELP"
  ]
}
```

### 219

Sources: [official source]; [official source]; [official source].

```json
{
  "act_articles": {
    "DE45": "2026UStVA form PDFpage5, row36/KZ45",
    "DEEXROWS": "Same section, rows33-35 exclusion",
    "DEFOREIGN": "ELSTER2026 / Übrige nicht steuerbare Umsätze, first paragraph",
    "DETAXABLE": "Same paragraph, domestic-taxability condition",
    "EU44ACT": "Article44, first sentence, taxable business-capacity condition",
    "EU44B": "Article 44, first sentence",
    "EU44F": "Article 44, second sentence",
    "EU44R": "Article 44, third sentence",
    "REG21": "Article 21, first/second paragraphs, relevant establishment",
    "REG22": "Article 22(1), identification of receiving establishment",
    "REG22C": "Article 22(1), secondary evidence"
  },
  "conditions_context": "Branding invoice EUR 3,000, received by the Japanese business establishment. On ordinary Article 44 facts, German output VAT is EUR 0 and invoice total EUR 3,000; 2026 UStVA row 36/KZ 45 applies if the stated non-taxable foreign-place reporting conditions hold. Sources: [official source]; [official source]; [official source].",
  "evidence_entry_ids": [
    "EU44ACT",
    "EU44B",
    "EU44F",
    "EU44R",
    "REG21",
    "REG22",
    "REG22C",
    "DE45",
    "DEFOREIGN",
    "DETAXABLE",
    "DEEXROWS"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 219,
  "line": 217,
  "original_review_exact_claim": "Sources: [official source]; [official source]; [official source].",
  "original_review_row_id": 215,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Example 2: German designer to Japanese client, B2B",
  "source_keys": [
    "EU",
    "REG",
    "DE",
    "DEHELP"
  ]
}
```

### 220

Tax advisory invoice GBP 10,000 to the Australian business establishment, with no special rule.

```json
{
  "act_articles": {},
  "conditions_context": "Tax advisory invoice GBP 10,000 to the Australian business establishment, with no special rule. Section 7A places it outside the UK; output VAT GBP 0 and total GBP 10,000. Under ordinary VAT accounting put GBP 10,000 in Box 6 and no output tax for this supply in Box 1. Input recovery is conditional. Sources: [official source]; [official source]; Notice 741A section 2.7, [official source].",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "10,000"
  ],
  "id": 220,
  "line": 221,
  "original_review_exact_claim": "Tax advisory invoice GBP 10,000 to the Australian business establishment, with no special rule.",
  "original_review_row_id": 216,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Example 3: UK accountant to Australian client, B2B",
  "source_keys": [
    "POLICY"
  ]
}
```

### 221

Section 7A places it outside the UK; output VAT GBP 0 and total GBP 10,000.

```json
{
  "act_articles": {
    "UKL2A": "VATA1994 section 7A(2)(a)",
    "UKL4": "VATA1994 section 7A(4)(a)/(b)",
    "UKL5": "VATA1994 section 7A(5)"
  },
  "conditions_context": "Tax advisory invoice GBP 10,000 to the Australian business establishment, with no special rule. Section 7A places it outside the UK; output VAT GBP 0 and total GBP 10,000. Under ordinary VAT accounting put GBP 10,000 in Box 6 and no output tax for this supply in Box 1. Input recovery is conditional. Sources: [official source]; [official source]; Notice 741A section 2.7, [official source].",
  "evidence_entry_ids": [
    "UKL2A",
    "UKL4",
    "UKL5"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "Hypothetical10000+0=10000 independently recomputed; recipient establishment and no exception assumed.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "7",
    "0",
    "10,000."
  ],
  "id": 221,
  "line": 221,
  "original_review_exact_claim": "Section 7A places it outside the UK; output VAT GBP 0 and total GBP 10,000.",
  "original_review_row_id": 217,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Example 3: UK accountant to Australian client, B2B",
  "source_keys": [
    "UKLAW"
  ]
}
```

### 222

Under ordinary VAT accounting put GBP 10,000 in Box 6 and no output tax for this supply in Box 1.

```json
{
  "act_articles": {
    "UKBOX1": "Notice700/12 section3.2, opening Box1 instruction",
    "UKBOX6": "Notice700/12 section3.7, Box6 list"
  },
  "conditions_context": "Tax advisory invoice GBP 10,000 to the Australian business establishment, with no special rule. Section 7A places it outside the UK; output VAT GBP 0 and total GBP 10,000. Under ordinary VAT accounting put GBP 10,000 in Box 6 and no output tax for this supply in Box 1. Input recovery is conditional. Sources: [official source]; [official source]; Notice 741A section 2.7, [official source].",
  "evidence_entry_ids": [
    "UKBOX6",
    "UKBOX1"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "10,000",
    "6",
    "1."
  ],
  "id": 222,
  "line": 221,
  "original_review_exact_claim": "Under ordinary VAT accounting put GBP 10,000 in Box 6 and no output tax for this supply in Box 1.",
  "original_review_row_id": 218,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Example 3: UK accountant to Australian client, B2B",
  "source_keys": [
    "UKRETURN"
  ]
}
```

### 223

Input recovery is conditional.

```json
{
  "act_articles": {
    "UKINPUT1": "Notice741A2.7, outside-UK taxable-if-domestic bullet",
    "UKINPUT2": "Notice741A2.7, opening qualification"
  },
  "conditions_context": "Tax advisory invoice GBP 10,000 to the Australian business establishment, with no special rule. Section 7A places it outside the UK; output VAT GBP 0 and total GBP 10,000. Under ordinary VAT accounting put GBP 10,000 in Box 6 and no output tax for this supply in Box 1. Input recovery is conditional. Sources: [official source]; [official source]; Notice 741A section 2.7, [official source].",
  "evidence_entry_ids": [
    "UKINPUT1",
    "UKINPUT2"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "F2: add UKNotice741A2.7 source alongside this repeated input-recovery assertion and to old row219 provenance; UKLAW7A/UKRETURN do not prove this input-credit rule.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 223,
  "line": 221,
  "original_review_exact_claim": "Input recovery is conditional.",
  "original_review_row_id": 219,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Example 3: UK accountant to Australian client, B2B",
  "source_keys": [
    "UK"
  ]
}
```

### 224

Sources: [official source]; [official source]; Notice 741A section 2.7, [official source].

```json
{
  "act_articles": {
    "UKBOX1": "Notice700/12 section3.2, opening Box1 instruction",
    "UKBOX6": "Notice700/12 section3.7, Box6 list",
    "UKINPUT1": "Notice741A2.7, outside-UK taxable-if-domestic bullet",
    "UKINPUT2": "Notice741A2.7, opening qualification",
    "UKL2A": "VATA1994 section 7A(2)(a)",
    "UKL5": "VATA1994 section 7A(5)"
  },
  "conditions_context": "Tax advisory invoice GBP 10,000 to the Australian business establishment, with no special rule. Section 7A places it outside the UK; output VAT GBP 0 and total GBP 10,000. Under ordinary VAT accounting put GBP 10,000 in Box 6 and no output tax for this supply in Box 1. Input recovery is conditional. Sources: [official source]; [official source]; Notice 741A section 2.7, [official source].",
  "evidence_entry_ids": [
    "UKL2A",
    "UKL5",
    "UKBOX6",
    "UKBOX1",
    "UKINPUT1",
    "UKINPUT2"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "F2: source line must also include the input-recovery source.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "741",
    "2.7,"
  ],
  "id": 224,
  "line": 221,
  "original_review_exact_claim": "Sources: [official source]; [official source].",
  "original_review_row_id": 220,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Example 3: UK accountant to Australian client, B2B",
  "source_keys": [
    "UKLAW",
    "UKRETURN",
    "UK"
  ]
}
```

### 225

App-development invoice AUD 20,000.

```json
{
  "act_articles": {},
  "conditions_context": "App-development invoice AUD 20,000. Assume the Canadian company is a non-resident outside Australia when the service is done, no local goods-work/property link, and no subsection (2)/(2A)/(3) exclusion. Item 2(a) gives GST-free output, GST AUD 0 and total AUD 20,000. Ordinary service proceeds go in G1 and, for full reporting, G3, not old G2. Sources: [official source]; [official source].",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "20,000."
  ],
  "id": 225,
  "line": 225,
  "original_review_exact_claim": "App-development invoice AUD 20,000.",
  "original_review_row_id": 221,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Example 4: Australian developer to Canadian client, B2B",
  "source_keys": [
    "POLICY"
  ]
}
```

### 226

Assume the Canadian company is a non-resident outside Australia when the service is done, no local goods-work/property link, and no subsection (2)/(2A)/(3) exclusion.

```json
{
  "act_articles": {
    "AU2A": "s38-190(1), item2(a)",
    "AU2ABS": "s38-190(1), item2 chapeau",
    "AU2ALAND": "s38-190(1), item2(a), land condition",
    "AU2AWHENDONE": "s38-190(1) item2(a), timing of local work",
    "AULOCAL": "s38-190(3)(b), local provision",
    "AULOCALA": "s38-190(3)(a), nonresident agreement",
    "AULOCALC": "s38-190(3)(c), input-taxed limitation on exceptions",
    "AULOCALX": "s38-190(3)(c)(i), business-recipient exception",
    "AULOCALX2": "s38-190(3)(c)(ii), employee/officer alternative",
    "AULOCALX3": "s38-190(3)(c)(iii), recipient creditable-purpose alternative",
    "AUPROP": "s38-190(2A), input-taxed property exclusion",
    "AUPROPALL": "s38-190(2A), item/application extent",
    "AUPROPITEMS": "s38-190(2A), items2-4",
    "AURIGHT": "s38-190(2), rights/options exclusion",
    "AUSCOPE": "s38-190(1), chapeau",
    "AUSCOPEEX": "s38-190(1), chapeau, exclusions"
  },
  "conditions_context": "App-development invoice AUD 20,000. Assume the Canadian company is a non-resident outside Australia when the service is done, no local goods-work/property link, and no subsection (2)/(2A)/(3) exclusion. Item 2(a) gives GST-free output, GST AUD 0 and total AUD 20,000. Ordinary service proceeds go in G1 and, for full reporting, G3, not old G2. Sources: [official source]; [official source].",
  "evidence_entry_ids": [
    "AUSCOPE",
    "AUSCOPEEX",
    "AU2ABS",
    "AU2A",
    "AU2AWHENDONE",
    "AU2ALAND",
    "AURIGHT",
    "AUPROPALL",
    "AUPROPITEMS",
    "AUPROP",
    "AULOCALA",
    "AULOCAL",
    "AULOCALC",
    "AULOCALX",
    "AULOCALX2",
    "AULOCALX3"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "20000 fee is a hypothetical input; output0/total20000 independently recomputed only under these item2(a) conditions.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "2",
    "2",
    "3"
  ],
  "id": 226,
  "line": 225,
  "original_review_exact_claim": "Assume the Canadian company is a non-resident outside Australia when the service is done, no local goods-work/property link, and no subsection (2)/(2A)/(3) exclusion.",
  "original_review_row_id": 222,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Example 4: Australian developer to Canadian client, B2B",
  "source_keys": [
    "AU"
  ]
}
```

### 227

Item 2(a) gives GST-free output, GST AUD 0 and total AUD 20,000.

```json
{
  "act_articles": {
    "AU2A": "s38-190(1), item2(a)",
    "AU2ABS": "s38-190(1), item2 chapeau",
    "AU2ALAND": "s38-190(1), item2(a), land condition",
    "AU2AWHENDONE": "s38-190(1) item2(a), timing of local work",
    "AULOCAL": "s38-190(3)(b), local provision",
    "AULOCALA": "s38-190(3)(a), nonresident agreement",
    "AULOCALC": "s38-190(3)(c), input-taxed limitation on exceptions",
    "AULOCALX": "s38-190(3)(c)(i), business-recipient exception",
    "AULOCALX2": "s38-190(3)(c)(ii), employee/officer alternative",
    "AULOCALX3": "s38-190(3)(c)(iii), recipient creditable-purpose alternative",
    "AUPROP": "s38-190(2A), input-taxed property exclusion",
    "AUPROPALL": "s38-190(2A), item/application extent",
    "AUPROPITEMS": "s38-190(2A), items2-4",
    "AURIGHT": "s38-190(2), rights/options exclusion",
    "AUSCOPE": "s38-190(1), chapeau",
    "AUSCOPEEX": "s38-190(1), chapeau, exclusions"
  },
  "conditions_context": "App-development invoice AUD 20,000. Assume the Canadian company is a non-resident outside Australia when the service is done, no local goods-work/property link, and no subsection (2)/(2A)/(3) exclusion. Item 2(a) gives GST-free output, GST AUD 0 and total AUD 20,000. Ordinary service proceeds go in G1 and, for full reporting, G3, not old G2. Sources: [official source]; [official source].",
  "evidence_entry_ids": [
    "AUSCOPE",
    "AUSCOPEEX",
    "AU2ABS",
    "AU2A",
    "AU2AWHENDONE",
    "AU2ALAND",
    "AURIGHT",
    "AUPROPALL",
    "AUPROPITEMS",
    "AUPROP",
    "AULOCALA",
    "AULOCAL",
    "AULOCALC",
    "AULOCALX",
    "AULOCALX2",
    "AULOCALX3"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "20000 fee is a hypothetical input; output0/total20000 independently recomputed only under these item2(a) conditions.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "2(a)",
    "0",
    "20,000."
  ],
  "id": 227,
  "line": 225,
  "original_review_exact_claim": "Item 2(a) gives GST-free output, GST AUD 0 and total AUD 20,000.",
  "original_review_row_id": 223,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Example 4: Australian developer to Canadian client, B2B",
  "source_keys": [
    "AU"
  ]
}
```

### 228

Ordinary service proceeds go in G1 and, for full reporting, G3, not old G2.

```json
{
  "act_articles": {
    "ABG1": "G1 total sales, accounts/calculation-method GST-free-sales bullets",
    "ABG2": "G2 Export sales, What not to report at G2, first bullet",
    "ABG2X": "Same G2 first bullet, exception",
    "ABG3": "G3 Other GST-free sales, What to report at G3"
  },
  "conditions_context": "App-development invoice AUD 20,000. Assume the Canadian company is a non-resident outside Australia when the service is done, no local goods-work/property link, and no subsection (2)/(2A)/(3) exclusion. Item 2(a) gives GST-free output, GST AUD 0 and total AUD 20,000. Ordinary service proceeds go in G1 and, for full reporting, G3, not old G2. Sources: [official source]; [official source].",
  "evidence_entry_ids": [
    "ABG1",
    "ABG3",
    "ABG2",
    "ABG2X"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 228,
  "line": 225,
  "original_review_exact_claim": "Ordinary service proceeds go in G1 and, for full reporting, G3, not old G2.",
  "original_review_row_id": 224,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Example 4: Australian developer to Canadian client, B2B",
  "source_keys": [
    "AUBAS"
  ]
}
```

### 229

Sources: [official source]; [official source].

```json
{
  "act_articles": {
    "ABG1": "G1 total sales, accounts/calculation-method GST-free-sales bullets",
    "ABG2": "G2 Export sales, What not to report at G2, first bullet",
    "ABG2X": "Same G2 first bullet, exception",
    "ABG3": "G3 Other GST-free sales, What to report at G3",
    "AU2A": "s38-190(1), item2(a)",
    "AU2ABS": "s38-190(1), item2 chapeau",
    "AU2ALAND": "s38-190(1), item2(a), land condition",
    "AU2AWHENDONE": "s38-190(1) item2(a), timing of local work",
    "AULOCAL": "s38-190(3)(b), local provision",
    "AULOCALA": "s38-190(3)(a), nonresident agreement",
    "AULOCALC": "s38-190(3)(c), input-taxed limitation on exceptions",
    "AULOCALX": "s38-190(3)(c)(i), business-recipient exception",
    "AULOCALX2": "s38-190(3)(c)(ii), employee/officer alternative",
    "AULOCALX3": "s38-190(3)(c)(iii), recipient creditable-purpose alternative",
    "AUPROP": "s38-190(2A), input-taxed property exclusion",
    "AUPROPALL": "s38-190(2A), item/application extent",
    "AUPROPITEMS": "s38-190(2A), items2-4",
    "AURIGHT": "s38-190(2), rights/options exclusion",
    "AUSCOPE": "s38-190(1), chapeau",
    "AUSCOPEEX": "s38-190(1), chapeau, exclusions"
  },
  "conditions_context": "App-development invoice AUD 20,000. Assume the Canadian company is a non-resident outside Australia when the service is done, no local goods-work/property link, and no subsection (2)/(2A)/(3) exclusion. Item 2(a) gives GST-free output, GST AUD 0 and total AUD 20,000. Ordinary service proceeds go in G1 and, for full reporting, G3, not old G2. Sources: [official source]; [official source].",
  "evidence_entry_ids": [
    "AUSCOPE",
    "AUSCOPEEX",
    "AU2ABS",
    "AU2A",
    "AU2AWHENDONE",
    "AU2ALAND",
    "AURIGHT",
    "AUPROPALL",
    "AUPROPITEMS",
    "AUPROP",
    "AULOCALA",
    "AULOCAL",
    "AULOCALC",
    "AULOCALX",
    "AULOCALX2",
    "AULOCALX3",
    "ABG1",
    "ABG3",
    "ABG2",
    "ABG2X"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 229,
  "line": 225,
  "original_review_exact_claim": "Sources: [official source]; [official source].",
  "original_review_row_id": 225,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Example 4: Australian developer to Canadian client, B2B",
  "source_keys": [
    "AU",
    "AUBAS"
  ]
}
```

### 230

Development invoice USD 10,000, with LUT filed.

```json
{
  "act_articles": {},
  "conditions_context": "Development invoice USD 10,000, with LUT filed. Confirm all 5 export conditions, including actual permitted-currency receipt and section 13 place, plus a valid financial-year LUT. On those additional proved facts no IGST is payable under the LUT route; receipt remains USD 10,000 before other contractual deductions. Convert/report the appropriate INR values in the export/zero-rated tables. Eligible ITC/refund is conditional, not FULL by default. Sources: [official source]; [official source]; [official source]; [official source]; [official source].",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "10,000,"
  ],
  "id": 230,
  "line": 229,
  "original_review_exact_claim": "Development invoice USD 10,000, with LUT filed.",
  "original_review_row_id": 226,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Example 5: Indian developer to UK client, B2B",
  "source_keys": [
    "POLICY"
  ]
}
```

### 231

Confirm all 5 export conditions, including actual permitted-currency receipt and section 13 place, plus a valid financial-year LUT.

```json
{
  "act_articles": {
    "IN13BASE": "IGST13(2), general rule",
    "IN13EVENT": "IGST13(5), scan PDFpage17",
    "IN13FALL": "IGST13(2), proviso",
    "IN13LAND": "IGST13(4)",
    "IN13PHYS": "IGST13(3)(b), physical presence",
    "IN16EXPORT": "IGST16(1)(a)",
    "IN16LUT": "IGST16(3), bond/LUT route",
    "IN250": "Same condition(i), strict threshold",
    "IN2FE": "IGST2(14)(c), relevant establishment",
    "IN2I": "IGST2(6)(i)",
    "IN2II": "IGST2(6)(ii)",
    "IN2III": "IGST2(6)(iii)",
    "IN2IV": "IGST2(6)(iv), as amended2018",
    "IN2V": "IGST2(6)(v)",
    "IN8EX": "IGST8Explanation1(i)",
    "IN96COMM": "Same substituted96A(1)(b), Commissioner extension",
    "IN96FEMA": "Same substituted96A(1)(b), FEMA/RBI later-period limb",
    "IN96INVOICE": "Notification12/2024 rule20(i), invoice starting date",
    "IN96PAY": "Same substituted96A(1)(b), payment qualification",
    "IN96TIME": "Notification12/2024-CentralTax rule20(i), substituted96A(1)(b)",
    "INARN": "Same substituted2(c)/(e), deemed acceptance",
    "INARNREJECT": "Same substituted2(e), ineligible LUT rejection",
    "INLUTPRIOR": "Circular8/8/2017 paragraph2(e), prior requirement",
    "INLUTYEAR": "Circular8/8/2017 paragraph2(b)",
    "INPROSEC": "Notification37/2017 condition(i), prosecution exclusion",
    "INRFD": "Circular40/14/2018 paragraph2 substituted2(c)"
  },
  "conditions_context": "Development invoice USD 10,000, with LUT filed. Confirm all 5 export conditions, including actual permitted-currency receipt and section 13 place, plus a valid financial-year LUT. On those additional proved facts no IGST is payable under the LUT route; receipt remains USD 10,000 before other contractual deductions. Convert/report the appropriate INR values in the export/zero-rated tables. Eligible ITC/refund is conditional, not FULL by default. Sources: [official source]; [official source]; [official source]; [official source]; [official source].",
  "evidence_entry_ids": [
    "IN2I",
    "IN2II",
    "IN2III",
    "IN2IV",
    "IN2V",
    "IN8EX",
    "IN2FE",
    "IN13BASE",
    "IN13FALL",
    "IN13PHYS",
    "IN13LAND",
    "IN13EVENT",
    "IN16EXPORT",
    "IN16LUT",
    "INLUTYEAR",
    "INLUTPRIOR",
    "INPROSEC",
    "IN250",
    "INRFD",
    "INARN",
    "INARNREJECT",
    "IN96TIME",
    "IN96FEMA",
    "IN96INVOICE",
    "IN96COMM",
    "IN96PAY"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "5",
    "13"
  ],
  "id": 231,
  "line": 229,
  "original_review_exact_claim": "Confirm all 5 export conditions, including actual permitted-currency receipt and section 13 place, plus a valid financial-year LUT.",
  "original_review_row_id": 227,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Example 5: Indian developer to UK client, B2B",
  "source_keys": [
    "IN",
    "INLUT",
    "IN37",
    "INONLINE",
    "IN96"
  ]
}
```

### 232

On those additional proved facts no IGST is payable under the LUT route; receipt remains USD 10,000 before other contractual deductions.

```json
{
  "act_articles": {
    "IN16EXPORT": "IGST16(1)(a)",
    "IN16LUT": "IGST16(3), bond/LUT route",
    "IN250": "Same condition(i), strict threshold",
    "IN2FE": "IGST2(14)(c), relevant establishment",
    "IN2I": "IGST2(6)(i)",
    "IN2II": "IGST2(6)(ii)",
    "IN2III": "IGST2(6)(iii)",
    "IN2IV": "IGST2(6)(iv), as amended2018",
    "IN2V": "IGST2(6)(v)",
    "IN8EX": "IGST8Explanation1(i)",
    "INARN": "Same substituted2(c)/(e), deemed acceptance",
    "INARNREJECT": "Same substituted2(e), ineligible LUT rejection",
    "INLUTPRIOR": "Circular8/8/2017 paragraph2(e), prior requirement",
    "INLUTYEAR": "Circular8/8/2017 paragraph2(b)",
    "INPROSEC": "Notification37/2017 condition(i), prosecution exclusion",
    "INRFD": "Circular40/14/2018 paragraph2 substituted2(c)"
  },
  "conditions_context": "Development invoice USD 10,000, with LUT filed. Confirm all 5 export conditions, including actual permitted-currency receipt and section 13 place, plus a valid financial-year LUT. On those additional proved facts no IGST is payable under the LUT route; receipt remains USD 10,000 before other contractual deductions. Convert/report the appropriate INR values in the export/zero-rated tables. Eligible ITC/refund is conditional, not FULL by default. Sources: [official source]; [official source]; [official source]; [official source]; [official source].",
  "evidence_entry_ids": [
    "IN2I",
    "IN2II",
    "IN2III",
    "IN2IV",
    "IN2V",
    "IN8EX",
    "IN2FE",
    "IN16EXPORT",
    "IN16LUT",
    "INLUTYEAR",
    "INLUTPRIOR",
    "INPROSEC",
    "IN250",
    "INRFD",
    "INARN",
    "INARNREJECT"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "Hypothetical USD10000 receipt under no-IGST LUT case, not computed INR or refund.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "10,000"
  ],
  "id": 232,
  "line": 229,
  "original_review_exact_claim": "On those additional proved facts no IGST is payable under the LUT route; receipt remains USD 10,000 before other contractual deductions.",
  "original_review_row_id": 228,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Example 5: Indian developer to UK client, B2B",
  "source_keys": [
    "IN",
    "INLUT",
    "IN37",
    "INONLINE"
  ]
}
```

### 233

Convert/report the appropriate INR values in the export/zero-rated tables.

```json
{
  "INR_boundary": "Entire actual live Rule34 heading, both operative subsections and historic substitution note personally read, with complete live Rules33 and35 neighbours. Current official index marks entry active and amendment27July2017. Service valuation uses GAAP rate at CGSTsection13 time of supply. This is different from IGSTsection13 place of supply and IGST2(6)(iv) receipt-currency permission. No actual FXrate, invoice/time-of-supply facts, accounting policy, INR amount, return-period cutoff or refund amount is supplied or cleared. Complete 2026Notification05 amendment targets independently checked; noRule34 amendment there. This is current official live-entry proof, not an assertion that the old full CBIC/Court compilation incorporates every2026amendment.",
  "act_articles": {
    "IN20APPLY": "IGSTAct20, operative line after(xxv), scanPDFpage26/printed219, subject to chapeau",
    "IN20TIME": "IGSTAct20(iii), scanPDFpage25/printed218",
    "ININR": "Central Goods and Services Tax Rules2017, Rule34(2), live active CBIC entry; heading specifies currency other than Indianrupees; read with34(1) and substitution footnote",
    "INRETURNMAP": "GSTR3B FAQ / system generated GSTR3B table, GSTR1 export6A/6B/9 amendments row to3.1(b)"
  },
  "conditions_context": "Development invoice USD 10,000, with LUT filed. Confirm all 5 export conditions, including actual permitted-currency receipt and section 13 place, plus a valid financial-year LUT. On those additional proved facts no IGST is payable under the LUT route; receipt remains USD 10,000 before other contractual deductions. Convert/report the appropriate INR values in the export/zero-rated tables. Eligible ITC/refund is conditional, not FULL by default. Sources: [official source]; [official source]; [official source]; [official source]; [official source].",
  "evidence_entry_ids": [
    "INRETURNMAP",
    "ININR",
    "IN20TIME",
    "IN20APPLY"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACTS_SUPPLIED_AUTHOR_DELTA_RECHECK_PENDING",
  "evidence_recommendation_note": "INR valuation-basis extract gap resolved by the bounded live Rule34(2)/IGST20 addendum; FAQ retained only where a separate return mapping is asserted. No actual exchange rate or converted amount is cleared.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 233,
  "line": 229,
  "original_review_exact_claim": "Convert/report the appropriate INR values in the export/zero-rated tables.",
  "original_review_row_id": 229,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Example 5: Indian developer to UK client, B2B",
  "source_keys": [
    "INRETURN",
    "INRULE34",
    "IN"
  ]
}
```

### 234

Eligible ITC/refund is conditional, not FULL by default.

```json
{
  "act_articles": {
    "IN16INPUT": "IGST16(2), blocked-credit qualification",
    "IN16REFUND": "IGST16(3), scanPDFpage21, section54/rules qualification"
  },
  "conditions_context": "Development invoice USD 10,000, with LUT filed. Confirm all 5 export conditions, including actual permitted-currency receipt and section 13 place, plus a valid financial-year LUT. On those additional proved facts no IGST is payable under the LUT route; receipt remains USD 10,000 before other contractual deductions. Convert/report the appropriate INR values in the export/zero-rated tables. Eligible ITC/refund is conditional, not FULL by default. Sources: [official source]; [official source]; [official source]; [official source]; [official source].",
  "evidence_entry_ids": [
    "IN16INPUT",
    "IN16REFUND"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "No numerical refund or universal credit promised; specific refund eligibility remains separately gated.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 234,
  "line": 229,
  "original_review_exact_claim": "Eligible ITC/refund is conditional, not FULL by default.",
  "original_review_row_id": 230,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Example 5: Indian developer to UK client, B2B",
  "source_keys": [
    "IN"
  ]
}
```

### 235

Sources: [official source]; [official source]; [official source]; [official source]; [official source].

```json
{
  "INR_boundary": "Entire actual live Rule34 heading, both operative subsections and historic substitution note personally read, with complete live Rules33 and35 neighbours. Current official index marks entry active and amendment27July2017. Service valuation uses GAAP rate at CGSTsection13 time of supply. This is different from IGSTsection13 place of supply and IGST2(6)(iv) receipt-currency permission. No actual FXrate, invoice/time-of-supply facts, accounting policy, INR amount, return-period cutoff or refund amount is supplied or cleared. Complete 2026Notification05 amendment targets independently checked; noRule34 amendment there. This is current official live-entry proof, not an assertion that the old full CBIC/Court compilation incorporates every2026amendment.",
  "act_articles": {
    "IN16EXPORT": "IGST16(1)(a)",
    "IN16INPUT": "IGST16(2), blocked-credit qualification",
    "IN16LUT": "IGST16(3), bond/LUT route",
    "IN20APPLY": "IGSTAct20, operative line after(xxv), scanPDFpage26/printed219, subject to chapeau",
    "IN20TIME": "IGSTAct20(iii), scanPDFpage25/printed218",
    "IN250": "Same condition(i), strict threshold",
    "IN2FE": "IGST2(14)(c), relevant establishment",
    "IN2I": "IGST2(6)(i)",
    "IN2II": "IGST2(6)(ii)",
    "IN2III": "IGST2(6)(iii)",
    "IN2IV": "IGST2(6)(iv), as amended2018",
    "IN2V": "IGST2(6)(v)",
    "IN8EX": "IGST8Explanation1(i)",
    "IN96COMM": "Same substituted96A(1)(b), Commissioner extension",
    "IN96FEMA": "Same substituted96A(1)(b), FEMA/RBI later-period limb",
    "IN96INVOICE": "Notification12/2024 rule20(i), invoice starting date",
    "IN96PAY": "Same substituted96A(1)(b), payment qualification",
    "IN96TIME": "Notification12/2024-CentralTax rule20(i), substituted96A(1)(b)",
    "INARN": "Same substituted2(c)/(e), deemed acceptance",
    "INARNREJECT": "Same substituted2(e), ineligible LUT rejection",
    "ININR": "Central Goods and Services Tax Rules2017, Rule34(2), live active CBIC entry; heading specifies currency other than Indianrupees; read with34(1) and substitution footnote",
    "INLUTPRIOR": "Circular8/8/2017 paragraph2(e), prior requirement",
    "INLUTYEAR": "Circular8/8/2017 paragraph2(b)",
    "INPROSEC": "Notification37/2017 condition(i), prosecution exclusion",
    "INRETURNMAP": "GSTR3B FAQ / system generated GSTR3B table, GSTR1 export6A/6B/9 amendments row to3.1(b)",
    "INRFD": "Circular40/14/2018 paragraph2 substituted2(c)"
  },
  "conditions_context": "Development invoice USD 10,000, with LUT filed. Confirm all 5 export conditions, including actual permitted-currency receipt and section 13 place, plus a valid financial-year LUT. On those additional proved facts no IGST is payable under the LUT route; receipt remains USD 10,000 before other contractual deductions. Convert/report the appropriate INR values in the export/zero-rated tables. Eligible ITC/refund is conditional, not FULL by default. Sources: [official source]; [official source]; [official source]; [official source]; [official source].",
  "evidence_entry_ids": [
    "IN2I",
    "IN2II",
    "IN2III",
    "IN2IV",
    "IN2V",
    "IN8EX",
    "IN2FE",
    "IN16EXPORT",
    "IN16LUT",
    "INLUTYEAR",
    "INLUTPRIOR",
    "INPROSEC",
    "IN250",
    "INRFD",
    "INARN",
    "INARNREJECT",
    "IN96TIME",
    "IN96FEMA",
    "IN96INVOICE",
    "IN96COMM",
    "IN96PAY",
    "IN16INPUT",
    "INRETURNMAP",
    "ININR",
    "IN20TIME",
    "IN20APPLY"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACTS_SUPPLIED_AUTHOR_DELTA_RECHECK_PENDING",
  "evidence_recommendation_note": "INR valuation-basis extract gap resolved by the bounded live Rule34(2)/IGST20 addendum; FAQ retained only where a separate return mapping is asserted. No actual exchange rate or converted amount is cleared.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 235,
  "line": 229,
  "original_review_exact_claim": "Sources: [official source]; [official source]; [official source]; [official source].",
  "original_review_row_id": 231,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Example 5: Indian developer to UK client, B2B",
  "source_keys": [
    "IN",
    "INLUT",
    "IN37",
    "INONLINE",
    "IN96",
    "INRETURN",
    "INRULE34"
  ]
}
```

### 236

Management-advisory invoice SGD 15,000.

```json
{
  "act_articles": {},
  "conditions_context": "Management-advisory invoice SGD 15,000. On proved section 21(3)(j) or applicable (k) facts, zero-rated GST is SGD 0 and total SGD 15,000; Box 2 includes SGD 15,000. Do not cite the former \"Fifth Schedule Para 1\". Sources: [official source]; [official source].",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "15,000."
  ],
  "id": 236,
  "line": 233,
  "original_review_exact_claim": "Management-advisory invoice SGD 15,000.",
  "original_review_row_id": 232,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Example 6: Singapore consultant to German client, B2B",
  "source_keys": [
    "POLICY"
  ]
}
```

### 237

On proved section 21(3)(j) or applicable (k) facts, zero-rated GST is SGD 0 and total SGD 15,000; Box 2 includes SGD 15,000.

```json
{
  "act_articles": {
    "SGABS": "IRAS table row13/(j), overseas customer absence and overseas direct beneficiary absence",
    "SGBOX2": "IRAS Completing GST returns / Box2 title and qualifying international-services explanation",
    "SGBUSINESS": "Same table row14/(k), contractual business-capacity limb",
    "SGCONTRACT": "IRAS international-services table row13/(j) and row14/(k), identical overseas-contract limb",
    "SGGOODS": "IRAS table rows9/10/12:21(3)(g)/(h)/(f), goods/export evidence",
    "SGKLAND": "IRAS table row14/(k), professional/data goods-for-export exception and definite/immediate intention condition",
    "SGLAND": "Same table row13/(j), Singapore goods/land restriction",
    "SGLOCAL": "Same table rows13/(j) and14/(k), identical local-beneficiary alternative"
  },
  "conditions_context": "Management-advisory invoice SGD 15,000. On proved section 21(3)(j) or applicable (k) facts, zero-rated GST is SGD 0 and total SGD 15,000; Box 2 includes SGD 15,000. Do not cite the former \"Fifth Schedule Para 1\". Sources: [official source]; [official source].",
  "current_goods_ships_boundary": "Singapore professional-versus-data Singapore-goods/ships conditions under the current Second Schedule: the retained 2020 official reproduction distinguishes professional services (export goods and ships) from data services (export goods only), while the current IRAS table combines the categories. The former combined proposition \"professional/data services must not directly relate to Singapore land/goods other than goods for export\" is individually unusable for this branch until the current regulatory text/version is reconciled; no ships relief or blanket ships exclusion is cleared here. ",
  "evidence_entry_ids": [
    "SGCONTRACT",
    "SGABS",
    "SGLOCAL",
    "SGLAND",
    "SGGOODS",
    "SGBUSINESS",
    "SGKLAND",
    "SGBOX2"
  ],
  "evidence_format_status": "CURRENT_SHORT_EXTRACT_STANDARD_APPLICABLE",
  "evidence_recommendation_note": "Hypothetical15000 fee,0output,total15000 andBox2value15000 independently recomputed; rule conditions remain proved facts.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "21(3)",
    "0",
    "15,000",
    "2",
    "15,000."
  ],
  "historical_format_status": "HOLD_EXPLICIT_EXTRACT_GAP",
  "historical_quotation_gaps": [
    "SGABS",
    "SGGOODS",
    "SGKLAND"
  ],
  "id": 237,
  "line": 233,
  "original_review_exact_claim": "On proved section 21(3)(j) or applicable (k) facts, zero-rated GST is SGD 0 and total SGD 15,000; Box 2 includes SGD 15,000.",
  "original_review_row_id": 233,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Example 6: Singapore consultant to German client, B2B",
  "source_keys": [
    "SG",
    "SGRETURN"
  ]
}
```

### 238

Do not cite the former "Fifth Schedule Para 1".

```json
{
  "act_articles": {
    "SGFIFTH": "IRAS telecommunications table row25, section21(3)(q), Fifth Schedule"
  },
  "conditions_context": "Management-advisory invoice SGD 15,000. On proved section 21(3)(j) or applicable (k) facts, zero-rated GST is SGD 0 and total SGD 15,000; Box 2 includes SGD 15,000. Do not cite the former \"Fifth Schedule Para 1\". Sources: [official source]; [official source].",
  "evidence_entry_ids": [
    "SGFIFTH"
  ],
  "evidence_format_status": "CURRENT_SHORT_EXTRACT_STANDARD_APPLICABLE",
  "evidence_recommendation_note": "Rejects former catch-all attribution, does not impose a different unsupported FifthSchedule rule.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "1"
  ],
  "historical_format_status": "HOLD_EXPLICIT_EXTRACT_GAP",
  "historical_quotation_gaps": [
    "SGFIFTH"
  ],
  "id": 238,
  "line": 233,
  "original_review_exact_claim": "Do not cite the former \"Fifth Schedule Para 1\".",
  "original_review_row_id": 234,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Example 6: Singapore consultant to German client, B2B",
  "source_keys": [
    "SG"
  ]
}
```

### 239

Sources: [official source]; [official source].

```json
{
  "act_articles": {
    "SGABS": "IRAS table row13/(j), overseas customer absence and overseas direct beneficiary absence",
    "SGBOX2": "IRAS Completing GST returns / Box2 title and qualifying international-services explanation",
    "SGBUSINESS": "Same table row14/(k), contractual business-capacity limb",
    "SGCONTRACT": "IRAS international-services table row13/(j) and row14/(k), identical overseas-contract limb",
    "SGGOODS": "IRAS table rows9/10/12:21(3)(g)/(h)/(f), goods/export evidence",
    "SGKLAND": "IRAS table row14/(k), professional/data goods-for-export exception and definite/immediate intention condition",
    "SGLAND": "Same table row13/(j), Singapore goods/land restriction",
    "SGLOCAL": "Same table rows13/(j) and14/(k), identical local-beneficiary alternative"
  },
  "conditions_context": "Management-advisory invoice SGD 15,000. On proved section 21(3)(j) or applicable (k) facts, zero-rated GST is SGD 0 and total SGD 15,000; Box 2 includes SGD 15,000. Do not cite the former \"Fifth Schedule Para 1\". Sources: [official source]; [official source].",
  "current_goods_ships_boundary": "Singapore professional-versus-data Singapore-goods/ships conditions under the current Second Schedule: the retained 2020 official reproduction distinguishes professional services (export goods and ships) from data services (export goods only), while the current IRAS table combines the categories. The former combined proposition \"professional/data services must not directly relate to Singapore land/goods other than goods for export\" is individually unusable for this branch until the current regulatory text/version is reconciled; no ships relief or blanket ships exclusion is cleared here. ",
  "evidence_entry_ids": [
    "SGCONTRACT",
    "SGABS",
    "SGLOCAL",
    "SGLAND",
    "SGGOODS",
    "SGBUSINESS",
    "SGKLAND",
    "SGBOX2"
  ],
  "evidence_format_status": "CURRENT_SHORT_EXTRACT_STANDARD_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "historical_format_status": "HOLD_EXPLICIT_EXTRACT_GAP",
  "historical_quotation_gaps": [
    "SGABS",
    "SGGOODS",
    "SGKLAND"
  ],
  "id": 239,
  "line": 233,
  "original_review_exact_claim": "Sources: [official source]; [official source].",
  "original_review_row_id": 235,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Example 6: Singapore consultant to German client, B2B",
  "source_keys": [
    "SG",
    "SGRETURN"
  ]
}
```

### 240

EUR 20,000 design fee for a building to be constructed in Switzerland.

```json
{
  "act_articles": {},
  "conditions_context": "EUR 20,000 design fee for a building to be constructed in Switzerland. A sufficiently connected architectural service falls under Article 47 at the Swiss property, outside French VAT. French output VAT EUR 0; invoice total EUR 20,000 before any Swiss tax. Swiss registration, acquisition tax, exemptions and liability need the Swiss Guide/current law; none is computed here. Source: [official source].",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "20,000"
  ],
  "id": 240,
  "line": 237,
  "original_review_exact_claim": "EUR 20,000 design fee for a building to be constructed in Switzerland.",
  "original_review_row_id": 236,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Example 7: French architect, Swiss property",
  "source_keys": [
    "POLICY"
  ]
}
```

### 241

A sufficiently connected architectural service falls under Article 47 at the Swiss property, outside French VAT.

```json
{
  "act_articles": {
    "EU47": "Article 47, final operative clause",
    "EU47A": "Article 47, construction-services inclusion",
    "REG31A": "Article 31a(1), sufficiently direct land connection"
  },
  "conditions_context": "EUR 20,000 design fee for a building to be constructed in Switzerland. A sufficiently connected architectural service falls under Article 47 at the Swiss property, outside French VAT. French output VAT EUR 0; invoice total EUR 20,000 before any Swiss tax. Swiss registration, acquisition tax, exemptions and liability need the Swiss Guide/current law; none is computed here. Source: [official source].",
  "evidence_entry_ids": [
    "EU47",
    "EU47A",
    "REG31A"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "47"
  ],
  "id": 241,
  "line": 237,
  "original_review_exact_claim": "A sufficiently connected architectural service falls under Article 47 at the Swiss property, outside French VAT.",
  "original_review_row_id": 237,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Example 7: French architect, Swiss property",
  "source_keys": [
    "EU",
    "REG"
  ]
}
```

### 242

French output VAT EUR 0; invoice total EUR 20,000 before any Swiss tax.

```json
{
  "act_articles": {
    "EU47": "Article 47, final operative clause",
    "REG31A": "Article 31a(1), sufficiently direct land connection"
  },
  "conditions_context": "EUR 20,000 design fee for a building to be constructed in Switzerland. A sufficiently connected architectural service falls under Article 47 at the Swiss property, outside French VAT. French output VAT EUR 0; invoice total EUR 20,000 before any Swiss tax. Swiss registration, acquisition tax, exemptions and liability need the Swiss Guide/current law; none is computed here. Source: [official source].",
  "evidence_entry_ids": [
    "EU47",
    "REG31A"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "Hypothetical20000+0=20000 before any Swiss tax, independently recomputed.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "0",
    "20,000"
  ],
  "id": 242,
  "line": 237,
  "original_review_exact_claim": "French output VAT EUR 0; invoice total EUR 20,000 before any Swiss tax.",
  "original_review_row_id": 238,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Example 7: French architect, Swiss property",
  "source_keys": [
    "EU",
    "REG"
  ]
}
```

### 243

Swiss registration, acquisition tax, exemptions and liability need the Swiss Guide/current law; none is computed here.

```json
{
  "act_articles": {},
  "conditions_context": "EUR 20,000 design fee for a building to be constructed in Switzerland. A sufficiently connected architectural service falls under Article 47 at the Swiss property, outside French VAT. French output VAT EUR 0; invoice total EUR 20,000 before any Swiss tax. Swiss registration, acquisition tax, exemptions and liability need the Swiss Guide/current law; none is computed here. Source: [official source].",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": "Swiss law expressly referred, not supplied or cleared.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 243,
  "line": 237,
  "original_review_exact_claim": "Swiss registration, acquisition tax, exemptions and liability need the Swiss Guide/current law; none is computed here.",
  "original_review_row_id": 239,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Example 7: French architect, Swiss property",
  "source_keys": [
    "POLICY"
  ]
}
```

### 244

Source: [official source].

```json
{
  "act_articles": {
    "EU47": "Article 47, final operative clause",
    "EU47A": "Article 47, construction-services inclusion",
    "REG31A": "Article 31a(1), sufficiently direct land connection"
  },
  "conditions_context": "EUR 20,000 design fee for a building to be constructed in Switzerland. A sufficiently connected architectural service falls under Article 47 at the Swiss property, outside French VAT. French output VAT EUR 0; invoice total EUR 20,000 before any Swiss tax. Swiss registration, acquisition tax, exemptions and liability need the Swiss Guide/current law; none is computed here. Source: [official source].",
  "evidence_entry_ids": [
    "EU47",
    "EU47A",
    "REG31A"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 244,
  "line": 237,
  "original_review_exact_claim": "Source: [official source].",
  "original_review_row_id": 240,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Example 7: French architect, Swiss property",
  "source_keys": [
    "EU",
    "REG"
  ]
}
```

### 245

Fee EUR 10,000.

```json
{
  "act_articles": {},
  "conditions_context": "Fee EUR 10,000. If it buys admission to a qualifying educational event in Malta, Article 53 locates the service there. Assuming ordinary taxable training, no exemption/reduced rate and ordinary registration, standard Malta VAT is 18% (in words on the page): derived VAT EUR 1,800 and total EUR 11,800. If the evidenced transaction instead is an ordinary bespoke B2B training service outside the admission rule, Article 44 can place it at the US establishment: output VAT EUR 0, total EUR 10,000. The classification is a legal/factual decision, not a choice of the cheaper answer. Closed attendance, advance registration/payment or the word \"bespoke\" alone does not resolve it: C-647/17 held a limited multi-day professional course could be admission. Sources: Articles 44/53 [official source]; Regulation Article 32 [official source]; judgment [official source]; Malta Article 19 [official source].",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "10,000."
  ],
  "id": 245,
  "line": 241,
  "original_review_exact_claim": "Fee EUR 10,000.",
  "original_review_row_id": 241,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Example 8: Maltese trainer, 3-day in-person Malta event for a US company",
  "source_keys": [
    "POLICY"
  ]
}
```

### 246

If it buys admission to a qualifying educational event in Malta, Article 53 locates the service there.

```json
{
  "act_articles": {
    "EU53": "Article 53, first paragraph",
    "REG32": "Article 32(1), admission essential characteristic",
    "REG32C": "Article 32(2)(c), educational admission"
  },
  "conditions_context": "Fee EUR 10,000. If it buys admission to a qualifying educational event in Malta, Article 53 locates the service there. Assuming ordinary taxable training, no exemption/reduced rate and ordinary registration, standard Malta VAT is 18% (in words on the page): derived VAT EUR 1,800 and total EUR 11,800. If the evidenced transaction instead is an ordinary bespoke B2B training service outside the admission rule, Article 44 can place it at the US establishment: output VAT EUR 0, total EUR 10,000. The classification is a legal/factual decision, not a choice of the cheaper answer. Closed attendance, advance registration/payment or the word \"bespoke\" alone does not resolve it: C-647/17 held a limited multi-day professional course could be admission. Sources: Articles 44/53 [official source]; Regulation Article 32 [official source]; judgment [official source]; Malta Article 19 [official source].",
  "evidence_entry_ids": [
    "EU53",
    "REG32",
    "REG32C"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "53"
  ],
  "id": 246,
  "line": 241,
  "original_review_exact_claim": "If it buys admission to a qualifying educational event in Malta, Article 53 locates the service there.",
  "original_review_row_id": 242,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Example 8: Maltese trainer, 3-day in-person Malta event for a US company",
  "source_keys": [
    "EU",
    "REG"
  ]
}
```

### 247

Assuming ordinary taxable training, no exemption/reduced rate and ordinary registration, standard Malta VAT is 18% (in words on the page): derived VAT EUR 1,800 and total EUR 11,800.

```json
{
  "act_articles": {
    "EU53": "Article 53, first paragraph",
    "MT18": "Cap406 Article19(1)",
    "MT8": "Cap406 Article19(2), Eighth Schedule qualification",
    "REG32": "Article 32(1), admission essential characteristic",
    "REG32C": "Article 32(2)(c), educational admission"
  },
  "conditions_context": "Fee EUR 10,000. If it buys admission to a qualifying educational event in Malta, Article 53 locates the service there. Assuming ordinary taxable training, no exemption/reduced rate and ordinary registration, standard Malta VAT is 18% (in words on the page): derived VAT EUR 1,800 and total EUR 11,800. If the evidenced transaction instead is an ordinary bespoke B2B training service outside the admission rule, Article 44 can place it at the US establishment: output VAT EUR 0, total EUR 10,000. The classification is a legal/factual decision, not a choice of the cheaper answer. Closed attendance, advance registration/payment or the word \"bespoke\" alone does not resolve it: C-647/17 held a limited multi-day professional course could be admission. Sources: Articles 44/53 [official source]; Regulation Article 32 [official source]; judgment [official source]; Malta Article 19 [official source].",
  "evidence_entry_ids": [
    "EU53",
    "REG32",
    "REG32C",
    "MT18",
    "MT8"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "Assumed taxable training10000 atactual18% gives1800 and11800; exemptions/reductions excluded by hypothetical facts, not denied universally.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "18%",
    "1,800",
    "11,800."
  ],
  "id": 247,
  "line": 241,
  "original_review_exact_claim": "Assuming ordinary taxable training, no exemption/reduced rate and ordinary registration, standard Malta VAT is 18% (in words on the page): derived VAT EUR 1,800 and total EUR 11,800.",
  "original_review_row_id": 243,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Example 8: Maltese trainer, 3-day in-person Malta event for a US company",
  "source_keys": [
    "EU",
    "REG",
    "MT"
  ]
}
```

### 248

If the evidenced transaction instead is an ordinary bespoke B2B training service outside the admission rule, Article 44 can place it at the US establishment: output VAT EUR 0, total EUR 10,000.

```json
{
  "act_articles": {
    "EU44ACT": "Article44, first sentence, taxable business-capacity condition",
    "EU44B": "Article 44, first sentence",
    "EU44F": "Article 44, second sentence",
    "EU44R": "Article 44, third sentence",
    "EU53": "Article 53, first paragraph",
    "REG21": "Article 21, first/second paragraphs, relevant establishment",
    "REG22": "Article 22(1), identification of receiving establishment",
    "REG22C": "Article 22(1), secondary evidence",
    "REG32": "Article 32(1), admission essential characteristic",
    "REG32C": "Article 32(2)(c), educational admission"
  },
  "conditions_context": "Fee EUR 10,000. If it buys admission to a qualifying educational event in Malta, Article 53 locates the service there. Assuming ordinary taxable training, no exemption/reduced rate and ordinary registration, standard Malta VAT is 18% (in words on the page): derived VAT EUR 1,800 and total EUR 11,800. If the evidenced transaction instead is an ordinary bespoke B2B training service outside the admission rule, Article 44 can place it at the US establishment: output VAT EUR 0, total EUR 10,000. The classification is a legal/factual decision, not a choice of the cheaper answer. Closed attendance, advance registration/payment or the word \"bespoke\" alone does not resolve it: C-647/17 held a limited multi-day professional course could be admission. Sources: Articles 44/53 [official source]; Regulation Article 32 [official source]; judgment [official source]; Malta Article 19 [official source].",
  "evidence_entry_ids": [
    "EU44ACT",
    "EU44B",
    "EU44F",
    "EU44R",
    "REG21",
    "REG22",
    "REG22C",
    "EU53",
    "REG32",
    "REG32C"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "Alternative classification, not tax-rate election; hypothetical10000+0=10000 independently recomputed.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "44",
    "0,",
    "10,000."
  ],
  "id": 248,
  "line": 241,
  "original_review_exact_claim": "If the evidenced transaction instead is an ordinary bespoke B2B training service outside the admission rule, Article 44 can place it at the US establishment: output VAT EUR 0, total EUR 10,000.",
  "original_review_row_id": 244,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Example 8: Maltese trainer, 3-day in-person Malta event for a US company",
  "source_keys": [
    "EU",
    "REG"
  ]
}
```

### 249

The classification is a legal/factual decision, not a choice of the cheaper answer.

```json
{
  "act_articles": {
    "REG32": "Article 32(1), admission essential characteristic",
    "REG32C": "Article 32(2)(c), educational admission"
  },
  "conditions_context": "Fee EUR 10,000. If it buys admission to a qualifying educational event in Malta, Article 53 locates the service there. Assuming ordinary taxable training, no exemption/reduced rate and ordinary registration, standard Malta VAT is 18% (in words on the page): derived VAT EUR 1,800 and total EUR 11,800. If the evidenced transaction instead is an ordinary bespoke B2B training service outside the admission rule, Article 44 can place it at the US establishment: output VAT EUR 0, total EUR 10,000. The classification is a legal/factual decision, not a choice of the cheaper answer. Closed attendance, advance registration/payment or the word \"bespoke\" alone does not resolve it: C-647/17 held a limited multi-day professional course could be admission. Sources: Articles 44/53 [official source]; Regulation Article 32 [official source]; judgment [official source]; Malta Article 19 [official source].",
  "evidence_entry_ids": [
    "REG32",
    "REG32C"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "Classification workflow, not free choice between legal results.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 249,
  "line": 241,
  "original_review_exact_claim": "The classification is a legal/factual decision, not a choice of the cheaper answer.",
  "original_review_row_id": 245,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Example 8: Maltese trainer, 3-day in-person Malta event for a US company",
  "source_keys": [
    "REG"
  ]
}
```

### 250

Closed attendance, advance registration/payment or the word "bespoke" alone does not resolve it: C-647/17 held a limited multi-day professional course could be admission.

```json
{
  "act_articles": {
    "C647ADV": "Same judgment paragraph35",
    "C647CLOSED": "Same paragraph36/conclusion",
    "C647LIMIT": "Judgment C647/17 paragraph36/conclusion"
  },
  "conditions_context": "Fee EUR 10,000. If it buys admission to a qualifying educational event in Malta, Article 53 locates the service there. Assuming ordinary taxable training, no exemption/reduced rate and ordinary registration, standard Malta VAT is 18% (in words on the page): derived VAT EUR 1,800 and total EUR 11,800. If the evidenced transaction instead is an ordinary bespoke B2B training service outside the admission rule, Article 44 can place it at the US establishment: output VAT EUR 0, total EUR 10,000. The classification is a legal/factual decision, not a choice of the cheaper answer. Closed attendance, advance registration/payment or the word \"bespoke\" alone does not resolve it: C-647/17 held a limited multi-day professional course could be admission. Sources: Articles 44/53 [official source]; Regulation Article 32 [official source]; judgment [official source]; Malta Article 19 [official source].",
  "evidence_entry_ids": [
    "C647LIMIT",
    "C647CLOSED",
    "C647ADV"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "647",
    "17"
  ],
  "id": 250,
  "line": 241,
  "original_review_exact_claim": "Closed attendance, advance registration/payment or the word \"bespoke\" alone does not resolve it: C-647/17 held a limited multi-day professional course could be admission.",
  "original_review_row_id": 246,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Example 8: Maltese trainer, 3-day in-person Malta event for a US company",
  "source_keys": [
    "C647"
  ]
}
```

### 251

Sources: Articles 44/53 [official source]; Regulation Article 32 [official source]; judgment [official source]; Malta Article 19 [official source].

```json
{
  "act_articles": {
    "C647ADV": "Same judgment paragraph35",
    "C647CLOSED": "Same paragraph36/conclusion",
    "C647LIMIT": "Judgment C647/17 paragraph36/conclusion",
    "EU53": "Article 53, first paragraph",
    "MT18": "Cap406 Article19(1)",
    "MT8": "Cap406 Article19(2), Eighth Schedule qualification",
    "REG32": "Article 32(1), admission essential characteristic",
    "REG32C": "Article 32(2)(c), educational admission"
  },
  "conditions_context": "Fee EUR 10,000. If it buys admission to a qualifying educational event in Malta, Article 53 locates the service there. Assuming ordinary taxable training, no exemption/reduced rate and ordinary registration, standard Malta VAT is 18% (in words on the page): derived VAT EUR 1,800 and total EUR 11,800. If the evidenced transaction instead is an ordinary bespoke B2B training service outside the admission rule, Article 44 can place it at the US establishment: output VAT EUR 0, total EUR 10,000. The classification is a legal/factual decision, not a choice of the cheaper answer. Closed attendance, advance registration/payment or the word \"bespoke\" alone does not resolve it: C-647/17 held a limited multi-day professional course could be admission. Sources: Articles 44/53 [official source]; Regulation Article 32 [official source]; judgment [official source]; Malta Article 19 [official source].",
  "evidence_entry_ids": [
    "EU53",
    "REG32",
    "REG32C",
    "C647LIMIT",
    "C647CLOSED",
    "C647ADV",
    "MT18",
    "MT8"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "44",
    "53",
    "32",
    "19"
  ],
  "id": 251,
  "line": 241,
  "original_review_exact_claim": "Sources: Articles 44/53 [official source]; Regulation Article 32 [official source]; judgment [official source]; Malta Article 19 [official source].",
  "original_review_row_id": 247,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Example 8: Maltese trainer, 3-day in-person Malta event for a US company",
  "source_keys": [
    "EU",
    "REG",
    "C647",
    "MT"
  ]
}
```

### 252

**EC1: Australian work split across Singapore and Australia.** The consultant spends 2 weeks in Singapore and 4 in Australia for a Singapore company.

```json
{
  "act_articles": {},
  "conditions_context": "**EC1: Australian work split across Singapore and Australia.** The consultant spends 2 weeks in Singapore and 4 in Australia for a Singapore company. Duration/location of the supplier's work alone does not decide export relief. Test the actual item 2 non-resident/absence/connection conditions and exclusions; if relying on item 3, test effective use/enjoyment. Local third-party provision needs subsection (3), not an invented universal use test. No IRAS challenge or relief for this Australian supply is inferred merely from the travel. Source: [official source].",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "2",
    "4"
  ],
  "id": 252,
  "line": 264,
  "original_review_exact_claim": "**EC1: Australian work split across Singapore and Australia.** The consultant spends 2 weeks in Singapore and 4 in Australia for a Singapore company.",
  "original_review_row_id": 248,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Edge cases: all original situations retained",
  "source_keys": [
    "POLICY"
  ]
}
```

### 253

Duration/location of the supplier's work alone does not decide export relief.

```json
{
  "act_articles": {
    "AU2A": "s38-190(1), item2(a)",
    "AU2ABS": "s38-190(1), item2 chapeau",
    "AU2ALAND": "s38-190(1), item2(a), land condition",
    "AU2AWHENDONE": "s38-190(1) item2(a), timing of local work",
    "AU3": "s38-190(1), item3(b)",
    "AU3ABS": "s38-190(1), item3(a)",
    "AU3EX": "s38-190(1), item3 final exclusion",
    "AU3LAND": "s38-190(1) item3, final exclusion",
    "AULOCAL": "s38-190(3)(b), local provision",
    "AULOCALA": "s38-190(3)(a), nonresident agreement",
    "AULOCALC": "s38-190(3)(c), input-taxed limitation on exceptions",
    "AULOCALX": "s38-190(3)(c)(i), business-recipient exception",
    "AULOCALX2": "s38-190(3)(c)(ii), employee/officer alternative",
    "AULOCALX3": "s38-190(3)(c)(iii), recipient creditable-purpose alternative",
    "AUPROP": "s38-190(2A), input-taxed property exclusion",
    "AUPROPALL": "s38-190(2A), item/application extent",
    "AUPROPITEMS": "s38-190(2A), items2-4",
    "AURIGHT": "s38-190(2), rights/options exclusion",
    "AUSCOPE": "s38-190(1), chapeau",
    "AUSCOPEEX": "s38-190(1), chapeau, exclusions"
  },
  "conditions_context": "**EC1: Australian work split across Singapore and Australia.** The consultant spends 2 weeks in Singapore and 4 in Australia for a Singapore company. Duration/location of the supplier's work alone does not decide export relief. Test the actual item 2 non-resident/absence/connection conditions and exclusions; if relying on item 3, test effective use/enjoyment. Local third-party provision needs subsection (3), not an invented universal use test. No IRAS challenge or relief for this Australian supply is inferred merely from the travel. Source: [official source].",
  "evidence_entry_ids": [
    "AUSCOPE",
    "AUSCOPEEX",
    "AU2ABS",
    "AU2A",
    "AU2AWHENDONE",
    "AU2ALAND",
    "AURIGHT",
    "AUPROPALL",
    "AUPROPITEMS",
    "AUPROP",
    "AULOCALA",
    "AULOCAL",
    "AULOCALC",
    "AULOCALX",
    "AULOCALX2",
    "AULOCALX3",
    "AU3ABS",
    "AU3",
    "AU3EX",
    "AU3LAND"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "Two/fourweek inputs do not themselves decide the item; not a statutory time threshold.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 253,
  "line": 264,
  "original_review_exact_claim": "Duration/location of the supplier's work alone does not decide export relief.",
  "original_review_row_id": 249,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Edge cases: all original situations retained",
  "source_keys": [
    "AU"
  ]
}
```

### 254

Test the actual item 2 non-resident/absence/connection conditions and exclusions; if relying on item 3, test effective use/enjoyment.

```json
{
  "act_articles": {
    "AU2A": "s38-190(1), item2(a)",
    "AU2ABS": "s38-190(1), item2 chapeau",
    "AU2ALAND": "s38-190(1), item2(a), land condition",
    "AU2AWHENDONE": "s38-190(1) item2(a), timing of local work",
    "AU3": "s38-190(1), item3(b)",
    "AU3ABS": "s38-190(1), item3(a)",
    "AU3EX": "s38-190(1), item3 final exclusion",
    "AU3LAND": "s38-190(1) item3, final exclusion",
    "AULOCAL": "s38-190(3)(b), local provision",
    "AULOCALA": "s38-190(3)(a), nonresident agreement",
    "AULOCALC": "s38-190(3)(c), input-taxed limitation on exceptions",
    "AULOCALX": "s38-190(3)(c)(i), business-recipient exception",
    "AULOCALX2": "s38-190(3)(c)(ii), employee/officer alternative",
    "AULOCALX3": "s38-190(3)(c)(iii), recipient creditable-purpose alternative",
    "AUPROP": "s38-190(2A), input-taxed property exclusion",
    "AUPROPALL": "s38-190(2A), item/application extent",
    "AUPROPITEMS": "s38-190(2A), items2-4",
    "AURIGHT": "s38-190(2), rights/options exclusion",
    "AUSCOPE": "s38-190(1), chapeau",
    "AUSCOPEEX": "s38-190(1), chapeau, exclusions"
  },
  "conditions_context": "**EC1: Australian work split across Singapore and Australia.** The consultant spends 2 weeks in Singapore and 4 in Australia for a Singapore company. Duration/location of the supplier's work alone does not decide export relief. Test the actual item 2 non-resident/absence/connection conditions and exclusions; if relying on item 3, test effective use/enjoyment. Local third-party provision needs subsection (3), not an invented universal use test. No IRAS challenge or relief for this Australian supply is inferred merely from the travel. Source: [official source].",
  "evidence_entry_ids": [
    "AUSCOPE",
    "AUSCOPEEX",
    "AU2ABS",
    "AU2A",
    "AU2AWHENDONE",
    "AU2ALAND",
    "AURIGHT",
    "AUPROPALL",
    "AUPROPITEMS",
    "AUPROP",
    "AULOCALA",
    "AULOCAL",
    "AULOCALC",
    "AULOCALX",
    "AULOCALX2",
    "AULOCALX3",
    "AU3ABS",
    "AU3",
    "AU3EX",
    "AU3LAND"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "2",
    "3,"
  ],
  "id": 254,
  "line": 264,
  "original_review_exact_claim": "Test the actual item 2 non-resident/absence/connection conditions and exclusions; if relying on item 3, test effective use/enjoyment.",
  "original_review_row_id": 250,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Edge cases: all original situations retained",
  "source_keys": [
    "AU"
  ]
}
```

### 255

Local third-party provision needs subsection (3), not an invented universal use test.

```json
{
  "act_articles": {
    "AULOCAL": "s38-190(3)(b), local provision",
    "AULOCALA": "s38-190(3)(a), nonresident agreement",
    "AULOCALC": "s38-190(3)(c), input-taxed limitation on exceptions",
    "AULOCALX": "s38-190(3)(c)(i), business-recipient exception",
    "AULOCALX2": "s38-190(3)(c)(ii), employee/officer alternative",
    "AULOCALX3": "s38-190(3)(c)(iii), recipient creditable-purpose alternative"
  },
  "conditions_context": "**EC1: Australian work split across Singapore and Australia.** The consultant spends 2 weeks in Singapore and 4 in Australia for a Singapore company. Duration/location of the supplier's work alone does not decide export relief. Test the actual item 2 non-resident/absence/connection conditions and exclusions; if relying on item 3, test effective use/enjoyment. Local third-party provision needs subsection (3), not an invented universal use test. No IRAS challenge or relief for this Australian supply is inferred merely from the travel. Source: [official source].",
  "evidence_entry_ids": [
    "AULOCALA",
    "AULOCAL",
    "AULOCALC",
    "AULOCALX",
    "AULOCALX2",
    "AULOCALX3"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "3"
  ],
  "id": 255,
  "line": 264,
  "original_review_exact_claim": "Local third-party provision needs subsection (3), not an invented universal use test.",
  "original_review_row_id": 251,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Edge cases: all original situations retained",
  "source_keys": [
    "AU"
  ]
}
```

### 256

No IRAS challenge or relief for this Australian supply is inferred merely from the travel.

```json
{
  "act_articles": {},
  "conditions_context": "**EC1: Australian work split across Singapore and Australia.** The consultant spends 2 weeks in Singapore and 4 in Australia for a Singapore company. Duration/location of the supplier's work alone does not decide export relief. Test the actual item 2 non-resident/absence/connection conditions and exclusions; if relying on item 3, test effective use/enjoyment. Local third-party provision needs subsection (3), not an invented universal use test. No IRAS challenge or relief for this Australian supply is inferred merely from the travel. Source: [official source].",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": "No asserted Singapore tax consequence or IRAS challenge.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 256,
  "line": 264,
  "original_review_exact_claim": "No IRAS challenge or relief for this Australian supply is inferred merely from the travel.",
  "original_review_row_id": 252,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Edge cases: all original situations retained",
  "source_keys": [
    "POLICY"
  ]
}
```

### 257

Source: [official source].

```json
{
  "act_articles": {
    "AU2A": "s38-190(1), item2(a)",
    "AU2ABS": "s38-190(1), item2 chapeau",
    "AU2ALAND": "s38-190(1), item2(a), land condition",
    "AU2AWHENDONE": "s38-190(1) item2(a), timing of local work",
    "AU3": "s38-190(1), item3(b)",
    "AU3ABS": "s38-190(1), item3(a)",
    "AU3EX": "s38-190(1), item3 final exclusion",
    "AU3LAND": "s38-190(1) item3, final exclusion",
    "AULOCAL": "s38-190(3)(b), local provision",
    "AULOCALA": "s38-190(3)(a), nonresident agreement",
    "AULOCALC": "s38-190(3)(c), input-taxed limitation on exceptions",
    "AULOCALX": "s38-190(3)(c)(i), business-recipient exception",
    "AULOCALX2": "s38-190(3)(c)(ii), employee/officer alternative",
    "AULOCALX3": "s38-190(3)(c)(iii), recipient creditable-purpose alternative",
    "AUPROP": "s38-190(2A), input-taxed property exclusion",
    "AUPROPALL": "s38-190(2A), item/application extent",
    "AUPROPITEMS": "s38-190(2A), items2-4",
    "AURIGHT": "s38-190(2), rights/options exclusion",
    "AUSCOPE": "s38-190(1), chapeau",
    "AUSCOPEEX": "s38-190(1), chapeau, exclusions"
  },
  "conditions_context": "**EC1: Australian work split across Singapore and Australia.** The consultant spends 2 weeks in Singapore and 4 in Australia for a Singapore company. Duration/location of the supplier's work alone does not decide export relief. Test the actual item 2 non-resident/absence/connection conditions and exclusions; if relying on item 3, test effective use/enjoyment. Local third-party provision needs subsection (3), not an invented universal use test. No IRAS challenge or relief for this Australian supply is inferred merely from the travel. Source: [official source].",
  "evidence_entry_ids": [
    "AUSCOPE",
    "AUSCOPEEX",
    "AU2ABS",
    "AU2A",
    "AU2AWHENDONE",
    "AU2ALAND",
    "AURIGHT",
    "AUPROPALL",
    "AUPROPITEMS",
    "AUPROP",
    "AULOCALA",
    "AULOCAL",
    "AULOCALC",
    "AULOCALX",
    "AULOCALX2",
    "AULOCALX3",
    "AU3ABS",
    "AU3",
    "AU3EX",
    "AU3LAND"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 257,
  "line": 264,
  "original_review_exact_claim": "Source: [official source].",
  "original_review_row_id": 253,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Edge cases: all original situations retained",
  "source_keys": [
    "AU"
  ]
}
```

### 258

**EC2: French yoga instructor and US tourist in Paris.** This is not automatically an Article 59 export.

```json
{
  "act_articles": {
    "EU45": "Article 45, first sentence",
    "EU54": "Article 54(1), first subparagraph",
    "EU59": "Article 59, chapeau, non-EU customer qualification",
    "EU59C": "Article 59(c)"
  },
  "conditions_context": "**EC2: French yoga instructor and US tourist in Paris.** This is not automatically an Article 59 export. Establish whether the in-person sporting/educational-activity rule in Article 54 or the residual Article 45 applies; both lead to France on the stated French-supplier/Paris facts. If the service is an ordinary taxable, non-exempt standard-rated supply, metropolitan France's standard rate is 20%; franchise/teaching/sports exemptions and any specific relief require the French Guide. The old unconditional \"Article 45 and 20%\" conclusion is not enough. Sources: [official source]; CGI Article 278 rate summary [official source].",
  "evidence_entry_ids": [
    "EU59",
    "EU59C",
    "EU54",
    "EU45"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "French yoga/US-tourist facts hypothetical; no automatic59professional-service classification.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "59"
  ],
  "id": 258,
  "line": 266,
  "original_review_exact_claim": "**EC2: French yoga instructor and US tourist in Paris.** This is not automatically an Article 59 export.",
  "original_review_row_id": 254,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Edge cases: all original situations retained",
  "source_keys": [
    "EU"
  ]
}
```

### 259

Establish whether the in-person sporting/educational-activity rule in Article 54 or the residual Article 45 applies; both lead to France on the stated French-supplier/Paris facts.

```json
{
  "act_articles": {
    "EU45": "Article 45, first sentence",
    "EU45F": "Article 45, second/third sentences",
    "EU54": "Article 54(1), first subparagraph"
  },
  "conditions_context": "**EC2: French yoga instructor and US tourist in Paris.** This is not automatically an Article 59 export. Establish whether the in-person sporting/educational-activity rule in Article 54 or the residual Article 45 applies; both lead to France on the stated French-supplier/Paris facts. If the service is an ordinary taxable, non-exempt standard-rated supply, metropolitan France's standard rate is 20%; franchise/teaching/sports exemptions and any specific relief require the French Guide. The old unconditional \"Article 45 and 20%\" conclusion is not enough. Sources: [official source]; CGI Article 278 rate summary [official source].",
  "evidence_entry_ids": [
    "EU54",
    "EU45",
    "EU45F"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "54",
    "45"
  ],
  "id": 259,
  "line": 266,
  "original_review_exact_claim": "Establish whether the in-person sporting/educational-activity rule in Article 54 or the residual Article 45 applies; both lead to France on the stated French-supplier/Paris facts.",
  "original_review_row_id": 255,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Edge cases: all original situations retained",
  "source_keys": [
    "EU"
  ]
}
```

### 260

If the service is an ordinary taxable, non-exempt standard-rated supply, metropolitan France's standard rate is 20%; franchise/teaching/sports exemptions and any specific relief require the French Guide.

```json
{
  "act_articles": {
    "FR20": "DGDDI Les taux de TVA / metropolitan rates / standard-rate explanation",
    "FRRESID": "Same standard-rate explanation, residual taxable scope"
  },
  "conditions_context": "**EC2: French yoga instructor and US tourist in Paris.** This is not automatically an Article 59 export. Establish whether the in-person sporting/educational-activity rule in Article 54 or the residual Article 45 applies; both lead to France on the stated French-supplier/Paris facts. If the service is an ordinary taxable, non-exempt standard-rated supply, metropolitan France's standard rate is 20%; franchise/teaching/sports exemptions and any specific relief require the French Guide. The old unconditional \"Article 45 and 20%\" conclusion is not enough. Sources: [official source]; CGI Article 278 rate summary [official source].",
  "evidence_entry_ids": [
    "FR20",
    "FRRESID"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "Conditional standard rate only, no blanket denial of sports/teaching/franchise relief.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "20%"
  ],
  "id": 260,
  "line": 266,
  "original_review_exact_claim": "If the service is an ordinary taxable, non-exempt standard-rated supply, metropolitan France's standard rate is 20%; franchise/teaching/sports exemptions and any specific relief require the French Guide.",
  "original_review_row_id": 256,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Edge cases: all original situations retained",
  "source_keys": [
    "FRRATE"
  ]
}
```

### 261

The old unconditional "Article 45 and 20%" conclusion is not enough.

```json
{
  "act_articles": {
    "EU45": "Article 45, first sentence",
    "EU54": "Article 54(1), first subparagraph",
    "FR20": "DGDDI Les taux de TVA / metropolitan rates / standard-rate explanation",
    "FRRESID": "Same standard-rate explanation, residual taxable scope"
  },
  "conditions_context": "**EC2: French yoga instructor and US tourist in Paris.** This is not automatically an Article 59 export. Establish whether the in-person sporting/educational-activity rule in Article 54 or the residual Article 45 applies; both lead to France on the stated French-supplier/Paris facts. If the service is an ordinary taxable, non-exempt standard-rated supply, metropolitan France's standard rate is 20%; franchise/teaching/sports exemptions and any specific relief require the French Guide. The old unconditional \"Article 45 and 20%\" conclusion is not enough. Sources: [official source]; CGI Article 278 rate summary [official source].",
  "evidence_entry_ids": [
    "EU54",
    "EU45",
    "FR20",
    "FRRESID"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "45",
    "20%"
  ],
  "id": 261,
  "line": 266,
  "original_review_exact_claim": "The old unconditional \"Article 45 and 20%\" conclusion is not enough.",
  "original_review_row_id": 257,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Edge cases: all original situations retained",
  "source_keys": [
    "EU",
    "FRRATE"
  ]
}
```

### 262

Sources: [official source]; CGI Article 278 rate summary [official source].

```json
{
  "act_articles": {
    "EU45": "Article 45, first sentence",
    "EU54": "Article 54(1), first subparagraph",
    "FR20": "DGDDI Les taux de TVA / metropolitan rates / standard-rate explanation",
    "FRRESID": "Same standard-rate explanation, residual taxable scope"
  },
  "conditions_context": "**EC2: French yoga instructor and US tourist in Paris.** This is not automatically an Article 59 export. Establish whether the in-person sporting/educational-activity rule in Article 54 or the residual Article 45 applies; both lead to France on the stated French-supplier/Paris facts. If the service is an ordinary taxable, non-exempt standard-rated supply, metropolitan France's standard rate is 20%; franchise/teaching/sports exemptions and any specific relief require the French Guide. The old unconditional \"Article 45 and 20%\" conclusion is not enough. Sources: [official source]; CGI Article 278 rate summary [official source].",
  "evidence_entry_ids": [
    "EU54",
    "EU45",
    "FR20",
    "FRRESID"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "278"
  ],
  "id": 262,
  "line": 266,
  "original_review_exact_claim": "Sources: [official source]; CGI Article 278 rate summary [official source].",
  "original_review_row_id": 258,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Edge cases: all original situations retained",
  "source_keys": [
    "EU",
    "FRRATE"
  ]
}
```

### 263

**EC3: Indian developer, Dubai client, payment in INR.** INR meets section 2(6)(iv) only where RBI permits it.

```json
{
  "act_articles": {
    "IN2IV": "IGST2(6)(iv), as amended2018"
  },
  "conditions_context": "**EC3: Indian developer, Dubai client, payment in INR.** INR meets section 2(6)(iv) only where RBI permits it. Obtain the actual transaction's permission/payment evidence; if it is not permitted, export qualification fails. Then determine the applicable tax/place/rate rather than inventing an IGST amount or assuming relief. Observe current rule 96A where exporting without payment. Sources: [official source]; [official source].",
  "evidence_entry_ids": [
    "IN2IV"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "2(6)"
  ],
  "id": 263,
  "line": 268,
  "original_review_exact_claim": "**EC3: Indian developer, Dubai client, payment in INR.** INR meets section 2(6)(iv) only where RBI permits it.",
  "original_review_row_id": 259,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Edge cases: all original situations retained",
  "source_keys": [
    "IN"
  ]
}
```

### 264

Obtain the actual transaction's permission/payment evidence; if it is not permitted, export qualification fails.

```json
{
  "act_articles": {
    "IN2IV": "IGST2(6)(iv), as amended2018"
  },
  "conditions_context": "**EC3: Indian developer, Dubai client, payment in INR.** INR meets section 2(6)(iv) only where RBI permits it. Obtain the actual transaction's permission/payment evidence; if it is not permitted, export qualification fails. Then determine the applicable tax/place/rate rather than inventing an IGST amount or assuming relief. Observe current rule 96A where exporting without payment. Sources: [official source]; [official source].",
  "evidence_entry_ids": [
    "IN2IV"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "Receipt-permission evidence required; no RBI permission is presumed.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 264,
  "line": 268,
  "original_review_exact_claim": "Obtain the actual transaction's permission/payment evidence; if it is not permitted, export qualification fails.",
  "original_review_row_id": 260,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Edge cases: all original situations retained",
  "source_keys": [
    "IN"
  ]
}
```

### 265

Then determine the applicable tax/place/rate rather than inventing an IGST amount or assuming relief.

```json
{
  "act_articles": {
    "IN13BASE": "IGST13(2), general rule",
    "IN13EVENT": "IGST13(5), scan PDFpage17",
    "IN13FALL": "IGST13(2), proviso",
    "IN13LAND": "IGST13(4)",
    "IN13PHYS": "IGST13(3)(b), physical presence",
    "IN2III": "IGST2(6)(iii)"
  },
  "conditions_context": "**EC3: Indian developer, Dubai client, payment in INR.** INR meets section 2(6)(iv) only where RBI permits it. Obtain the actual transaction's permission/payment evidence; if it is not permitted, export qualification fails. Then determine the applicable tax/place/rate rather than inventing an IGST amount or assuming relief. Observe current rule 96A where exporting without payment. Sources: [official source]; [official source].",
  "evidence_entry_ids": [
    "IN2III",
    "IN13BASE",
    "IN13FALL",
    "IN13PHYS",
    "IN13LAND",
    "IN13EVENT"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "Downstream liability/rate is referred; no invented amount.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 265,
  "line": 268,
  "original_review_exact_claim": "Then determine the applicable tax/place/rate rather than inventing an IGST amount or assuming relief.",
  "original_review_row_id": 261,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Edge cases: all original situations retained",
  "source_keys": [
    "IN"
  ]
}
```

### 266

Observe current rule 96A where exporting without payment.

```json
{
  "act_articles": {
    "IN96COMM": "Same substituted96A(1)(b), Commissioner extension",
    "IN96FEMA": "Same substituted96A(1)(b), FEMA/RBI later-period limb",
    "IN96INVOICE": "Notification12/2024 rule20(i), invoice starting date",
    "IN96PAY": "Same substituted96A(1)(b), payment qualification",
    "IN96TIME": "Notification12/2024-CentralTax rule20(i), substituted96A(1)(b)"
  },
  "conditions_context": "**EC3: Indian developer, Dubai client, payment in INR.** INR meets section 2(6)(iv) only where RBI permits it. Obtain the actual transaction's permission/payment evidence; if it is not permitted, export qualification fails. Then determine the applicable tax/place/rate rather than inventing an IGST amount or assuming relief. Observe current rule 96A where exporting without payment. Sources: [official source]; [official source].",
  "evidence_entry_ids": [
    "IN96TIME",
    "IN96FEMA",
    "IN96INVOICE",
    "IN96COMM",
    "IN96PAY"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "96"
  ],
  "id": 266,
  "line": 268,
  "original_review_exact_claim": "Observe current rule 96A where exporting without payment.",
  "original_review_row_id": 262,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Edge cases: all original situations retained",
  "source_keys": [
    "IN96"
  ]
}
```

### 267

Sources: [official source]; [official source].

```json
{
  "act_articles": {
    "IN2IV": "IGST2(6)(iv), as amended2018",
    "IN96COMM": "Same substituted96A(1)(b), Commissioner extension",
    "IN96FEMA": "Same substituted96A(1)(b), FEMA/RBI later-period limb",
    "IN96INVOICE": "Notification12/2024 rule20(i), invoice starting date",
    "IN96PAY": "Same substituted96A(1)(b), payment qualification",
    "IN96TIME": "Notification12/2024-CentralTax rule20(i), substituted96A(1)(b)"
  },
  "conditions_context": "**EC3: Indian developer, Dubai client, payment in INR.** INR meets section 2(6)(iv) only where RBI permits it. Obtain the actual transaction's permission/payment evidence; if it is not permitted, export qualification fails. Then determine the applicable tax/place/rate rather than inventing an IGST amount or assuming relief. Observe current rule 96A where exporting without payment. Sources: [official source]; [official source].",
  "evidence_entry_ids": [
    "IN2IV",
    "IN96TIME",
    "IN96FEMA",
    "IN96INVOICE",
    "IN96COMM",
    "IN96PAY"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 267,
  "line": 268,
  "original_review_exact_claim": "Sources: [official source]; [official source].",
  "original_review_row_id": 263,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Edge cases: all original situations retained",
  "source_keys": [
    "IN",
    "IN96"
  ]
}
```

### 268

**EC4: UK web developer to French company post-Brexit.** On ordinary B2B business-use/establishment facts, no UK VAT; French customer liability can arise under Article 196 as implemented in France, even though the supplier is outside the EU.

```json
{
  "act_articles": {
    "EU192A": "Article 192a(b), establishment intervention",
    "EU196": "Article 196",
    "EU44B": "Article 44, first sentence",
    "UKL2A": "VATA1994 section 7A(2)(a)",
    "UKL5": "VATA1994 section 7A(5)"
  },
  "conditions_context": "**EC4: UK web developer to French company post-Brexit.** On ordinary B2B business-use/establishment facts, no UK VAT; French customer liability can arise under Article 196 as implemented in France, even though the supplier is outside the EU. Article 196 is not limited to EU-established suppliers. Sources: [official source]; [official source].",
  "evidence_entry_ids": [
    "UKL2A",
    "UKL5",
    "EU44B",
    "EU192A",
    "EU196"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "196"
  ],
  "id": 268,
  "line": 270,
  "original_review_exact_claim": "**EC4: UK web developer to French company post-Brexit.** On ordinary B2B business-use/establishment facts, no UK VAT; French customer liability can arise under Article 196 as implemented in France, even though the supplier is outside the EU.",
  "original_review_row_id": 264,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Edge cases: all original situations retained",
  "source_keys": [
    "UKLAW",
    "EU"
  ]
}
```

### 269

Article 196 is not limited to EU-established suppliers.

```json
{
  "act_articles": {
    "EU196": "Article 196"
  },
  "conditions_context": "**EC4: UK web developer to French company post-Brexit.** On ordinary B2B business-use/establishment facts, no UK VAT; French customer liability can arise under Article 196 as implemented in France, even though the supplier is outside the EU. Article 196 is not limited to EU-established suppliers. Sources: [official source]; [official source].",
  "evidence_entry_ids": [
    "EU196"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "196"
  ],
  "id": 269,
  "line": 270,
  "original_review_exact_claim": "Article 196 is not limited to EU-established suppliers.",
  "original_review_row_id": 265,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Edge cases: all original situations retained",
  "source_keys": [
    "EU"
  ]
}
```

### 270

Sources: [official source]; [official source].

```json
{
  "act_articles": {
    "EU192A": "Article 192a(b), establishment intervention",
    "EU196": "Article 196",
    "EU44B": "Article 44, first sentence",
    "UKL2A": "VATA1994 section 7A(2)(a)",
    "UKL5": "VATA1994 section 7A(5)"
  },
  "conditions_context": "**EC4: UK web developer to French company post-Brexit.** On ordinary B2B business-use/establishment facts, no UK VAT; French customer liability can arise under Article 196 as implemented in France, even though the supplier is outside the EU. Article 196 is not limited to EU-established suppliers. Sources: [official source]; [official source].",
  "evidence_entry_ids": [
    "UKL2A",
    "UKL5",
    "EU44B",
    "EU192A",
    "EU196"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 270,
  "line": 270,
  "original_review_exact_claim": "Sources: [official source]; [official source].",
  "original_review_row_id": 266,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Edge cases: all original situations retained",
  "source_keys": [
    "UKLAW",
    "EU"
  ]
}
```

### 271

**EC5: Singapore advertising agency, overseas parent with Singapore branch.** Establish which establishment uses the contracted service, the actual overseas contractual person's belonging, direct beneficiary and GST registration, plus the exact advertising category.

```json
{
  "act_articles": {
    "SGAD": "IRAS advertising table rows1(a)-(e), different advertising categories",
    "SGBELONG": "IRAS Belonging status / Customer is a business / numbered1-3 plus business/fixed establishment definitions",
    "SGLOCAL": "Same table rows13/(j) and14/(k), identical local-beneficiary alternative"
  },
  "conditions_context": "**EC5: Singapore advertising agency, overseas parent with Singapore branch.** Establish which establishment uses the contracted service, the actual overseas contractual person's belonging, direct beneficiary and GST registration, plus the exact advertising category. A branch alone is not automatic denial, and local GST-registered direct benefit can qualify; Singapore-belonging contractual use or an unregistered local direct beneficiary may fail the relevant relief. No \"Fifth Schedule\" shortcut. Source: IRAS advertising/belonging/(j)/(k) table, [official source].",
  "evidence_entry_ids": [
    "SGBELONG",
    "SGLOCAL",
    "SGAD"
  ],
  "evidence_format_status": "CURRENT_SHORT_EXTRACT_STANDARD_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "historical_format_status": "HOLD_EXPLICIT_EXTRACT_GAP",
  "historical_quotation_gaps": [
    "SGBELONG",
    "SGAD"
  ],
  "id": 271,
  "line": 272,
  "original_review_exact_claim": "**EC5: Singapore advertising agency, overseas parent with Singapore branch.** Establish which establishment uses the contracted service, the actual overseas contractual person's belonging, direct beneficiary and GST registration, plus the exact advertising category.",
  "original_review_row_id": 267,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Edge cases: all original situations retained",
  "source_keys": [
    "SG"
  ]
}
```

### 272

A branch alone is not automatic denial, and local GST-registered direct benefit can qualify; Singapore-belonging contractual use or an unregistered local direct beneficiary may fail the relevant relief.

```json
{
  "act_articles": {
    "SGABS": "IRAS table row13/(j), overseas customer absence and overseas direct beneficiary absence",
    "SGBELONG": "IRAS Belonging status / Customer is a business / numbered1-3 plus business/fixed establishment definitions",
    "SGBUSINESS": "Same table row14/(k), contractual business-capacity limb",
    "SGCONTRACT": "IRAS international-services table row13/(j) and row14/(k), identical overseas-contract limb",
    "SGKLAND": "IRAS table row14/(k), professional/data goods-for-export exception and definite/immediate intention condition",
    "SGLOCAL": "Same table rows13/(j) and14/(k), identical local-beneficiary alternative"
  },
  "conditions_context": "**EC5: Singapore advertising agency, overseas parent with Singapore branch.** Establish which establishment uses the contracted service, the actual overseas contractual person's belonging, direct beneficiary and GST registration, plus the exact advertising category. A branch alone is not automatic denial, and local GST-registered direct benefit can qualify; Singapore-belonging contractual use or an unregistered local direct beneficiary may fail the relevant relief. No \"Fifth Schedule\" shortcut. Source: IRAS advertising/belonging/(j)/(k) table, [official source].",
  "current_goods_ships_boundary": "Singapore professional-versus-data Singapore-goods/ships conditions under the current Second Schedule: the retained 2020 official reproduction distinguishes professional services (export goods and ships) from data services (export goods only), while the current IRAS table combines the categories. The former combined proposition \"professional/data services must not directly relate to Singapore land/goods other than goods for export\" is individually unusable for this branch until the current regulatory text/version is reconciled; no ships relief or blanket ships exclusion is cleared here. ",
  "evidence_entry_ids": [
    "SGBELONG",
    "SGCONTRACT",
    "SGLOCAL",
    "SGABS",
    "SGBUSINESS",
    "SGKLAND"
  ],
  "evidence_format_status": "CURRENT_SHORT_EXTRACT_STANDARD_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "historical_format_status": "HOLD_EXPLICIT_EXTRACT_GAP",
  "historical_quotation_gaps": [
    "SGBELONG",
    "SGABS",
    "SGKLAND"
  ],
  "id": 272,
  "line": 272,
  "original_review_exact_claim": "A branch alone is not automatic denial, and local GST-registered direct benefit can qualify; Singapore-belonging contractual use or an unregistered local direct beneficiary may fail the relevant relief.",
  "original_review_row_id": 268,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Edge cases: all original situations retained",
  "source_keys": [
    "SG"
  ]
}
```

### 273

No "Fifth Schedule" shortcut.

```json
{
  "act_articles": {
    "SGFIFTH": "IRAS telecommunications table row25, section21(3)(q), Fifth Schedule"
  },
  "conditions_context": "**EC5: Singapore advertising agency, overseas parent with Singapore branch.** Establish which establishment uses the contracted service, the actual overseas contractual person's belonging, direct beneficiary and GST registration, plus the exact advertising category. A branch alone is not automatic denial, and local GST-registered direct benefit can qualify; Singapore-belonging contractual use or an unregistered local direct beneficiary may fail the relevant relief. No \"Fifth Schedule\" shortcut. Source: IRAS advertising/belonging/(j)/(k) table, [official source].",
  "evidence_entry_ids": [
    "SGFIFTH"
  ],
  "evidence_format_status": "CURRENT_SHORT_EXTRACT_STANDARD_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "historical_format_status": "HOLD_EXPLICIT_EXTRACT_GAP",
  "historical_quotation_gaps": [
    "SGFIFTH"
  ],
  "id": 273,
  "line": 272,
  "original_review_exact_claim": "No \"Fifth Schedule\" shortcut.",
  "original_review_row_id": 269,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Edge cases: all original situations retained",
  "source_keys": [
    "SG"
  ]
}
```

### 274

Source: IRAS advertising/belonging/(j)/(k) table, [official source].

```json
{
  "act_articles": {
    "SGABS": "IRAS table row13/(j), overseas customer absence and overseas direct beneficiary absence",
    "SGAD": "IRAS advertising table rows1(a)-(e), different advertising categories",
    "SGBELONG": "IRAS Belonging status / Customer is a business / numbered1-3 plus business/fixed establishment definitions",
    "SGBUSINESS": "Same table row14/(k), contractual business-capacity limb",
    "SGCONTRACT": "IRAS international-services table row13/(j) and row14/(k), identical overseas-contract limb",
    "SGGOODS": "IRAS table rows9/10/12:21(3)(g)/(h)/(f), goods/export evidence",
    "SGKLAND": "IRAS table row14/(k), professional/data goods-for-export exception and definite/immediate intention condition",
    "SGLAND": "Same table row13/(j), Singapore goods/land restriction",
    "SGLOCAL": "Same table rows13/(j) and14/(k), identical local-beneficiary alternative"
  },
  "conditions_context": "**EC5: Singapore advertising agency, overseas parent with Singapore branch.** Establish which establishment uses the contracted service, the actual overseas contractual person's belonging, direct beneficiary and GST registration, plus the exact advertising category. A branch alone is not automatic denial, and local GST-registered direct benefit can qualify; Singapore-belonging contractual use or an unregistered local direct beneficiary may fail the relevant relief. No \"Fifth Schedule\" shortcut. Source: IRAS advertising/belonging/(j)/(k) table, [official source].",
  "current_goods_ships_boundary": "Singapore professional-versus-data Singapore-goods/ships conditions under the current Second Schedule: the retained 2020 official reproduction distinguishes professional services (export goods and ships) from data services (export goods only), while the current IRAS table combines the categories. The former combined proposition \"professional/data services must not directly relate to Singapore land/goods other than goods for export\" is individually unusable for this branch until the current regulatory text/version is reconciled; no ships relief or blanket ships exclusion is cleared here. ",
  "evidence_entry_ids": [
    "SGBELONG",
    "SGLOCAL",
    "SGAD",
    "SGCONTRACT",
    "SGABS",
    "SGLAND",
    "SGGOODS",
    "SGBUSINESS",
    "SGKLAND"
  ],
  "evidence_format_status": "CURRENT_SHORT_EXTRACT_STANDARD_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "historical_format_status": "HOLD_EXPLICIT_EXTRACT_GAP",
  "historical_quotation_gaps": [
    "SGBELONG",
    "SGAD",
    "SGABS",
    "SGGOODS",
    "SGKLAND"
  ],
  "id": 274,
  "line": 272,
  "original_review_exact_claim": "Source: IRAS advertising/belonging/(j)/(k) table, [official source].",
  "original_review_row_id": 270,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Edge cases: all original situations retained",
  "source_keys": [
    "SG"
  ]
}
```

### 275

| Test 1: Malta sole trader, IT consulting to US company, EUR 3,000 | Ordinary Article 44 facts: output VAT EUR 0, total EUR 3,000. Conditional input deduction; former Box 2 = EUR 3,000 is unconfirmed and not a filing instruction | https://publications.europa.eu/resource/cellar/03c42d77-512a-11f0-a9d0-01aa75ed71a1.0007.02/DOC_1 ; https://publications.europa.eu/resource/cellar/5bc93f0b-2a93-11f0-8a44-01aa75ed71a1.0006.02/DOC_1 |

```json
{
  "act_articles": {
    "EU168": "Article 168, chapeau",
    "EU169A": "Article 169(a), domestic-deductibility condition",
    "EU169AX": "Article 169(a), Article 284 exclusion",
    "EU169C": "Article 169(c), financial/insurance route",
    "EU173": "Article 173(1), mixed use",
    "EU176": "Article 176, second paragraph",
    "EU178": "Article 178(a), invoice condition",
    "EU44ACT": "Article44, first sentence, taxable business-capacity condition",
    "EU44B": "Article 44, first sentence",
    "EU44F": "Article 44, second sentence",
    "EU44R": "Article 44, third sentence",
    "REG21": "Article 21, first/second paragraphs, relevant establishment",
    "REG22": "Article 22(1), identification of receiving establishment",
    "REG22C": "Article 22(1), secondary evidence"
  },
  "conditions_context": "| Test 1: Malta sole trader, IT consulting to US company, EUR 3,000 | Ordinary Article 44 facts: output VAT EUR 0, total EUR 3,000. Conditional input deduction; former Box 2 = EUR 3,000 is unconfirmed and not a filing instruction | [official source] ; [official source] |",
  "evidence_entry_ids": [
    "EU44ACT",
    "EU44B",
    "EU44F",
    "EU44R",
    "REG21",
    "REG22",
    "REG22C",
    "EU168",
    "EU169A",
    "EU169AX",
    "EU169C",
    "EU173",
    "EU176",
    "EU178"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "3000+0=3000 independently recomputed; Malta Box2 remains expressly unconfirmed.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "1",
    "3,000",
    "44",
    "0,",
    "3,000.",
    "2",
    "3,000",
    "03",
    "2",
    "7",
    "512",
    "11",
    "01",
    "5",
    "1",
    "0007.02",
    "1",
    "5",
    "3",
    "2",
    "3",
    "11",
    "8",
    "4",
    "01",
    "5",
    "1",
    "0006.02",
    "1"
  ],
  "id": 275,
  "line": 278,
  "original_review_exact_claim": "| Test 1: Malta sole trader, IT consulting to US company, EUR 3,000 | Ordinary Article 44 facts: output VAT EUR 0, total EUR 3,000. Conditional input deduction; former Box 2 = EUR 3,000 is unconfirmed and not a filing instruction | https://publications.europa.eu/resource/cellar/03c42d77-512a-11f0-a9d0-01aa75ed71a1.0007.02/DOC_1 ; https://publications.europa.eu/resource/cellar/5bc93f0b-2a93-11f0-8a44-01aa75ed71a1.0006.02/DOC_1 |",
  "original_review_row_id": 271,
  "quotation_gaps": [],
  "result_boundary": "Reserved assertion or correction; not a usable old filing figure",
  "section": "Quick reference / Worked cases / Original test suite, corrected expected results",
  "source_keys": [
    "EU",
    "REG"
  ]
}
```

### 276

| Test 2: French remote data processing to US individual, EUR 1,000 | Article 59 listed service, proved non-EU consumer location/no override: French output VAT EUR 0, total EUR 1,000 | https://publications.europa.eu/resource/cellar/03c42d77-512a-11f0-a9d0-01aa75ed71a1.0007.02/DOC_1 |

```json
{
  "act_articles": {
    "EU59": "Article 59, chapeau, non-EU customer qualification",
    "EU59A": "Article 59a, chapeau and points (a)/(b)",
    "EU59AU": "Article 59a(a)/(b), effective-use condition",
    "EU59B_AD": "Article59(b)",
    "EU59C": "Article 59(c)"
  },
  "conditions_context": "| Test 2: French remote data processing to US individual, EUR 1,000 | Article 59 listed service, proved non-EU consumer location/no override: French output VAT EUR 0, total EUR 1,000 | [official source] |",
  "evidence_entry_ids": [
    "EU59",
    "EU59C",
    "EU59B_AD",
    "EU59A",
    "EU59AU"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "Hypothetical1000data-processing fee, non-EU consumer/nooverride assumed;0output,total1000 independently recomputed.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "2",
    "1,000",
    "59",
    "0,",
    "1,000",
    "03",
    "2",
    "7",
    "512",
    "11",
    "01",
    "5",
    "1",
    "0007.02",
    "1"
  ],
  "id": 276,
  "line": 279,
  "original_review_exact_claim": "| Test 2: French remote data processing to US individual, EUR 1,000 | Article 59 listed service, proved non-EU consumer location/no override: French output VAT EUR 0, total EUR 1,000 | https://publications.europa.eu/resource/cellar/03c42d77-512a-11f0-a9d0-01aa75ed71a1.0007.02/DOC_1 |",
  "original_review_row_id": 272,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Original test suite, corrected expected results",
  "source_keys": [
    "EU"
  ]
}
```

### 277

| Test 3: Indian developer to US client, USD 5,000, LUT and USD payment | No IGST only once all export/receipt/LUT conditions are established; eligible ITC conditional; report INR equivalents in GSTR-1 6A / GSTR-3B 3.1(b) | https://thc.nic.in/Central%20Governmental%20Acts/Integrated%20Goods%20and%20Services%20Tax%20Act%2C%202017..pdf ; https://gstcouncil.gov.in/sites/default/files/2024-09/central-tax-12-2024-11072024.pdf ; https://tutorial.gst.gov.in/userguide/returns/GSTR3B.htm ; https://taxinformation.cbic.gov.in/content/html/tax_repository/gst/rules/cgst_rules/active/chapter4/rule34_v1.00.html |

```json
{
  "INR_boundary": "Entire actual live Rule34 heading, both operative subsections and historic substitution note personally read, with complete live Rules33 and35 neighbours. Current official index marks entry active and amendment27July2017. Service valuation uses GAAP rate at CGSTsection13 time of supply. This is different from IGSTsection13 place of supply and IGST2(6)(iv) receipt-currency permission. No actual FXrate, invoice/time-of-supply facts, accounting policy, INR amount, return-period cutoff or refund amount is supplied or cleared. Complete 2026Notification05 amendment targets independently checked; noRule34 amendment there. This is current official live-entry proof, not an assertion that the old full CBIC/Court compilation incorporates every2026amendment.",
  "act_articles": {
    "IN16EXPORT": "IGST16(1)(a)",
    "IN16INPUT": "IGST16(2), blocked-credit qualification",
    "IN16LUT": "IGST16(3), bond/LUT route",
    "IN20APPLY": "IGSTAct20, operative line after(xxv), scanPDFpage26/printed219, subject to chapeau",
    "IN20TIME": "IGSTAct20(iii), scanPDFpage25/printed218",
    "IN250": "Same condition(i), strict threshold",
    "IN2FE": "IGST2(14)(c), relevant establishment",
    "IN2I": "IGST2(6)(i)",
    "IN2II": "IGST2(6)(ii)",
    "IN2III": "IGST2(6)(iii)",
    "IN2IV": "IGST2(6)(iv), as amended2018",
    "IN2V": "IGST2(6)(v)",
    "IN8EX": "IGST8Explanation1(i)",
    "IN96COMM": "Same substituted96A(1)(b), Commissioner extension",
    "IN96FEMA": "Same substituted96A(1)(b), FEMA/RBI later-period limb",
    "IN96INVOICE": "Notification12/2024 rule20(i), invoice starting date",
    "IN96PAY": "Same substituted96A(1)(b), payment qualification",
    "IN96TIME": "Notification12/2024-CentralTax rule20(i), substituted96A(1)(b)",
    "INARN": "Same substituted2(c)/(e), deemed acceptance",
    "INARNREJECT": "Same substituted2(e), ineligible LUT rejection",
    "ININR": "Central Goods and Services Tax Rules2017, Rule34(2), live active CBIC entry; heading specifies currency other than Indianrupees; read with34(1) and substitution footnote",
    "INLUTPRIOR": "Circular8/8/2017 paragraph2(e), prior requirement",
    "INLUTYEAR": "Circular8/8/2017 paragraph2(b)",
    "INPROSEC": "Notification37/2017 condition(i), prosecution exclusion",
    "INRETURNMAP": "GSTR3B FAQ / system generated GSTR3B table, GSTR1 export6A/6B/9 amendments row to3.1(b)",
    "INRFD": "Circular40/14/2018 paragraph2 substituted2(c)"
  },
  "conditions_context": "| Test 3: Indian developer to US client, USD 5,000, LUT and USD payment | No IGST only once all export/receipt/LUT conditions are established; eligible ITC conditional; report INR equivalents in GSTR-1 6A / GSTR-3B 3.1(b) | [official source] ; [official source] ; [official source] ; [official source] |",
  "evidence_entry_ids": [
    "IN2I",
    "IN2II",
    "IN2III",
    "IN2IV",
    "IN2V",
    "IN8EX",
    "IN2FE",
    "IN16EXPORT",
    "IN16LUT",
    "INLUTYEAR",
    "INLUTPRIOR",
    "INPROSEC",
    "IN250",
    "INRFD",
    "INARN",
    "INARNREJECT",
    "IN96TIME",
    "IN96FEMA",
    "IN96INVOICE",
    "IN96COMM",
    "IN96PAY",
    "IN16INPUT",
    "INRETURNMAP",
    "ININR",
    "IN20TIME",
    "IN20APPLY"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACTS_SUPPLIED_AUTHOR_DELTA_RECHECK_PENDING",
  "evidence_recommendation_note": "INR valuation-basis extract gap resolved by the bounded live Rule34(2)/IGST20 addendum; FAQ retained only where a separate return mapping is asserted. No actual exchange rate or converted amount is cleared.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "3",
    "5,000,",
    "1",
    "6",
    "3",
    "3.1(b)",
    "20",
    "20",
    "20",
    "20",
    "20",
    "20",
    "20",
    "2",
    "202017..",
    "2024",
    "09",
    "12",
    "2024",
    "11072024.",
    "4",
    "00."
  ],
  "id": 277,
  "line": 280,
  "original_review_exact_claim": "| Test 3: Indian developer to US client, USD 5,000, LUT and USD payment | No IGST only once all export/receipt/LUT conditions are established; eligible ITC conditional; report INR equivalents in GSTR-1 6A / GSTR-3B 3.1(b) | https://thc.nic.in/Central%20Governmental%20Acts/Integrated%20Goods%20and%20Services%20Tax%20Act%2C%202017..pdf ; https://gstcouncil.gov.in/sites/default/files/2024-09/central-tax-12-2024-11072024.pdf ; https://tutorial.gst.gov.in/userguide/returns/GSTR3B.htm |",
  "original_review_row_id": 273,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Original test suite, corrected expected results",
  "source_keys": [
    "IN",
    "INLUT",
    "IN37",
    "INONLINE",
    "IN96",
    "INRETURN",
    "INRULE34"
  ]
}
```

### 278

| Test 4: Australian designer to UK company, AUD 8,000, client outside Australia | Add the non-resident, goods/property and exclusion evidence: item 2(a) GST-free, output GST AUD 0; G1 and full-reporting G3, not automatic G2 | https://www.legislation.gov.au/C2004A00446/2026-01-01/2026-01-01/text/original/epub/OEBPS/document_1/document_1.html ; https://www.ato.gov.au/api/public/content/0-98e0ef06-57b7-4811-a119-5236f1676a3c |

```json
{
  "act_articles": {
    "ABG1": "G1 total sales, accounts/calculation-method GST-free-sales bullets",
    "ABG2": "G2 Export sales, What not to report at G2, first bullet",
    "ABG2X": "Same G2 first bullet, exception",
    "ABG3": "G3 Other GST-free sales, What to report at G3",
    "AU2A": "s38-190(1), item2(a)",
    "AU2ABS": "s38-190(1), item2 chapeau",
    "AU2ALAND": "s38-190(1), item2(a), land condition",
    "AU2AWHENDONE": "s38-190(1) item2(a), timing of local work",
    "AULOCAL": "s38-190(3)(b), local provision",
    "AULOCALA": "s38-190(3)(a), nonresident agreement",
    "AULOCALC": "s38-190(3)(c), input-taxed limitation on exceptions",
    "AULOCALX": "s38-190(3)(c)(i), business-recipient exception",
    "AULOCALX2": "s38-190(3)(c)(ii), employee/officer alternative",
    "AULOCALX3": "s38-190(3)(c)(iii), recipient creditable-purpose alternative",
    "AUPROP": "s38-190(2A), input-taxed property exclusion",
    "AUPROPALL": "s38-190(2A), item/application extent",
    "AUPROPITEMS": "s38-190(2A), items2-4",
    "AURIGHT": "s38-190(2), rights/options exclusion",
    "AUSCOPE": "s38-190(1), chapeau",
    "AUSCOPEEX": "s38-190(1), chapeau, exclusions"
  },
  "conditions_context": "| Test 4: Australian designer to UK company, AUD 8,000, client outside Australia | Add the non-resident, goods/property and exclusion evidence: item 2(a) GST-free, output GST AUD 0; G1 and full-reporting G3, not automatic G2 | [official source] ; [official source] |",
  "evidence_entry_ids": [
    "AUSCOPE",
    "AUSCOPEEX",
    "AU2ABS",
    "AU2A",
    "AU2AWHENDONE",
    "AU2ALAND",
    "AURIGHT",
    "AUPROPALL",
    "AUPROPITEMS",
    "AUPROP",
    "AULOCALA",
    "AULOCAL",
    "AULOCALC",
    "AULOCALX",
    "AULOCALX2",
    "AULOCALX3",
    "ABG1",
    "ABG3",
    "ABG2",
    "ABG2X"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "8000 fee,0output independently recomputed; item2(a) facts and full-reporting distinction remain conditional.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "4",
    "8,000,",
    "2(a)",
    "0",
    "004",
    "0446",
    "2026",
    "01",
    "01",
    "2026",
    "01",
    "01",
    "1",
    "1.",
    "0",
    "98",
    "6",
    "57",
    "4811",
    "19",
    "5236",
    "676"
  ],
  "id": 278,
  "line": 281,
  "original_review_exact_claim": "| Test 4: Australian designer to UK company, AUD 8,000, client outside Australia | Add the non-resident, goods/property and exclusion evidence: item 2(a) GST-free, output GST AUD 0; G1 and full-reporting G3, not automatic G2 | https://www.legislation.gov.au/C2004A00446/2026-01-01/2026-01-01/text/original/epub/OEBPS/document_1/document_1.html ; https://www.ato.gov.au/api/public/content/0-98e0ef06-57b7-4811-a119-5236f1676a3c |",
  "original_review_row_id": 274,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Original test suite, corrected expected results",
  "source_keys": [
    "AU",
    "AUBAS"
  ]
}
```

### 279

| Test 5: UK surveyor, UK building, Singapore buyer, GBP 5,000 net | Sufficiently land-related service in UK; assume ordinary taxable standard-rate service: 20% VAT, derived GBP 1,000 tax and GBP 6,000 total, despite foreign buyer | https://www.legislation.gov.uk/ukpga/1994/23/schedule/4A/data.xml ; https://www.gov.uk/vat-rates |

```json
{
  "act_articles": {
    "UKRATE20": "HMRC VAT rates, standard-rate statement",
    "UKSLAND": "Schedule4A paragraph1(1)",
    "UKSSURVEY": "Schedule4A paragraph1(2)(f), professional land services"
  },
  "conditions_context": "| Test 5: UK surveyor, UK building, Singapore buyer, GBP 5,000 net | Sufficiently land-related service in UK; assume ordinary taxable standard-rate service: 20% VAT, derived GBP 1,000 tax and GBP 6,000 total, despite foreign buyer | [official source] ; [official source] |",
  "evidence_entry_ids": [
    "UKSLAND",
    "UKSSURVEY",
    "UKRATE20"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "Hypothetical5000net atactual20%=1000VAT and6000total independently recomputed; taxable standard-rate classification assumed.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "5",
    "5,000",
    "20%",
    "1,000",
    "6,000",
    "1994",
    "23",
    "4"
  ],
  "id": 279,
  "line": 282,
  "original_review_exact_claim": "| Test 5: UK surveyor, UK building, Singapore buyer, GBP 5,000 net | Sufficiently land-related service in UK; assume ordinary taxable standard-rate service: 20% VAT, derived GBP 1,000 tax and GBP 6,000 total, despite foreign buyer | https://www.legislation.gov.uk/ukpga/1994/23/schedule/4A/data.xml ; https://www.gov.uk/vat-rates |",
  "original_review_row_id": 275,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / Worked cases / Original test suite, corrected expected results",
  "source_keys": [
    "UKSCH",
    "UKRATE"
  ]
}
```

### 280

Test 5 recomputes the UK property's location-driven result; it is not a foreign-customer zero-rating case.

```json
{
  "act_articles": {
    "UKRATE20": "HMRC VAT rates, standard-rate statement",
    "UKSLAND": "Schedule4A paragraph1(1)",
    "UKSSURVEY": "Schedule4A paragraph1(2)(f), professional land services"
  },
  "conditions_context": "Test 5 recomputes the UK property's location-driven result; it is not a foreign-customer zero-rating case. A general B2B advisory service with a different actual nature would need a separate scope decision, rather than reuse the survey result.",
  "evidence_entry_ids": [
    "UKSLAND",
    "UKSSURVEY",
    "UKRATE20"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "Internal checklist or conditional recap; native extracts support the referenced underlying legal facts, not enactment of this workflow wording.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "5"
  ],
  "id": 280,
  "line": 284,
  "original_review_exact_claim": "Test 5 recomputes the UK property's location-driven result; it is not a foreign-customer zero-rating case.",
  "original_review_row_id": 276,
  "quotation_gaps": [],
  "result_boundary": "Internal workflow/provenance/example-intake policy; not external law",
  "section": "Quick reference / Worked cases / Original test suite, corrected expected results",
  "source_keys": [
    "UKSCH",
    "UKRATE"
  ]
}
```

### 281

A general B2B advisory service with a different actual nature would need a separate scope decision, rather than reuse the survey result.

```json
{
  "act_articles": {
    "UKL2A": "VATA1994 section 7A(2)(a)",
    "UKL5": "VATA1994 section 7A(5)",
    "UKSLAND": "Schedule4A paragraph1(1)"
  },
  "conditions_context": "Test 5 recomputes the UK property's location-driven result; it is not a foreign-customer zero-rating case. A general B2B advisory service with a different actual nature would need a separate scope decision, rather than reuse the survey result.",
  "evidence_entry_ids": [
    "UKL2A",
    "UKL5",
    "UKSLAND"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "Internal checklist or conditional recap; native extracts support the referenced underlying legal facts, not enactment of this workflow wording.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 281,
  "line": 284,
  "original_review_exact_claim": "A general B2B advisory service with a different actual nature would need a separate scope decision, rather than reuse the survey result.",
  "original_review_row_id": 277,
  "quotation_gaps": [],
  "result_boundary": "Internal workflow/provenance/example-intake policy; not external law",
  "section": "Quick reference / Worked cases / Original test suite, corrected expected results",
  "source_keys": [
    "UKLAW",
    "UKSCH"
  ]
}
```

### 282

1.

```json
{
  "act_articles": {},
  "conditions_context": "1. **Check place before charging:** never infer domestic tax or export relief from customer geography alone. Use country-specific general and particular rules, not a universal B2B default.",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "1."
  ],
  "id": 282,
  "line": 301,
  "original_review_exact_claim": "1.",
  "original_review_row_id": 278,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / When to refuse or refer",
  "source_keys": [
    "POLICY"
  ]
}
```

### 283

**Check place before charging:** never infer domestic tax or export relief from customer geography alone.

```json
{
  "act_articles": {
    "AU2A": "s38-190(1), item2(a)",
    "AU2ABS": "s38-190(1), item2 chapeau",
    "AU2ALAND": "s38-190(1), item2(a), land condition",
    "AU2AWHENDONE": "s38-190(1) item2(a), timing of local work",
    "AULOCAL": "s38-190(3)(b), local provision",
    "AULOCALA": "s38-190(3)(a), nonresident agreement",
    "AULOCALC": "s38-190(3)(c), input-taxed limitation on exceptions",
    "AULOCALX": "s38-190(3)(c)(i), business-recipient exception",
    "AULOCALX2": "s38-190(3)(c)(ii), employee/officer alternative",
    "AULOCALX3": "s38-190(3)(c)(iii), recipient creditable-purpose alternative",
    "AUPROP": "s38-190(2A), input-taxed property exclusion",
    "AUPROPALL": "s38-190(2A), item/application extent",
    "AUPROPITEMS": "s38-190(2A), items2-4",
    "AURIGHT": "s38-190(2), rights/options exclusion",
    "AUSCOPE": "s38-190(1), chapeau",
    "AUSCOPEEX": "s38-190(1), chapeau, exclusions",
    "EU44ACT": "Article44, first sentence, taxable business-capacity condition",
    "EU44B": "Article 44, first sentence",
    "EU44F": "Article 44, second sentence",
    "EU44R": "Article 44, third sentence",
    "IN2FE": "IGST2(14)(c), relevant establishment",
    "IN2I": "IGST2(6)(i)",
    "IN2II": "IGST2(6)(ii)",
    "IN2III": "IGST2(6)(iii)",
    "IN2IV": "IGST2(6)(iv), as amended2018",
    "IN2V": "IGST2(6)(v)",
    "IN8EX": "IGST8Explanation1(i)",
    "REG21": "Article 21, first/second paragraphs, relevant establishment",
    "REG22": "Article 22(1), identification of receiving establishment",
    "REG22C": "Article 22(1), secondary evidence",
    "SGABS": "IRAS table row13/(j), overseas customer absence and overseas direct beneficiary absence",
    "SGCONTRACT": "IRAS international-services table row13/(j) and row14/(k), identical overseas-contract limb",
    "SGGOODS": "IRAS table rows9/10/12:21(3)(g)/(h)/(f), goods/export evidence",
    "SGLAND": "Same table row13/(j), Singapore goods/land restriction",
    "SGLOCAL": "Same table rows13/(j) and14/(k), identical local-beneficiary alternative"
  },
  "conditions_context": "1. **Check place before charging:** never infer domestic tax or export relief from customer geography alone. Use country-specific general and particular rules, not a universal B2B default.",
  "evidence_entry_ids": [
    "EU44ACT",
    "EU44B",
    "EU44F",
    "EU44R",
    "REG21",
    "REG22",
    "REG22C",
    "AUSCOPE",
    "AUSCOPEEX",
    "AU2ABS",
    "AU2A",
    "AU2AWHENDONE",
    "AU2ALAND",
    "AURIGHT",
    "AUPROPALL",
    "AUPROPITEMS",
    "AUPROP",
    "AULOCALA",
    "AULOCAL",
    "AULOCALC",
    "AULOCALX",
    "AULOCALX2",
    "AULOCALX3",
    "IN2I",
    "IN2II",
    "IN2III",
    "IN2IV",
    "IN2V",
    "IN8EX",
    "IN2FE",
    "SGCONTRACT",
    "SGABS",
    "SGLOCAL",
    "SGLAND",
    "SGGOODS"
  ],
  "evidence_format_status": "CURRENT_SHORT_EXTRACT_STANDARD_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "historical_format_status": "HOLD_EXPLICIT_EXTRACT_GAP",
  "historical_quotation_gaps": [
    "SGABS",
    "SGGOODS"
  ],
  "id": 283,
  "line": 301,
  "original_review_exact_claim": "**Check place before charging:** never infer domestic tax or export relief from customer geography alone.",
  "original_review_row_id": 279,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / When to refuse or refer",
  "source_keys": [
    "EU",
    "REG",
    "AU",
    "IN",
    "SG"
  ]
}
```

### 284

Use country-specific general and particular rules, not a universal B2B default.

```json
{
  "act_articles": {
    "AU2A": "s38-190(1), item2(a)",
    "AU2ABS": "s38-190(1), item2 chapeau",
    "AU2ALAND": "s38-190(1), item2(a), land condition",
    "AU2AWHENDONE": "s38-190(1) item2(a), timing of local work",
    "AULOCAL": "s38-190(3)(b), local provision",
    "AULOCALA": "s38-190(3)(a), nonresident agreement",
    "AULOCALC": "s38-190(3)(c), input-taxed limitation on exceptions",
    "AULOCALX": "s38-190(3)(c)(i), business-recipient exception",
    "AULOCALX2": "s38-190(3)(c)(ii), employee/officer alternative",
    "AULOCALX3": "s38-190(3)(c)(iii), recipient creditable-purpose alternative",
    "AUPROP": "s38-190(2A), input-taxed property exclusion",
    "AUPROPALL": "s38-190(2A), item/application extent",
    "AUPROPITEMS": "s38-190(2A), items2-4",
    "AURIGHT": "s38-190(2), rights/options exclusion",
    "AUSCOPE": "s38-190(1), chapeau",
    "AUSCOPEEX": "s38-190(1), chapeau, exclusions",
    "EU45": "Article 45, first sentence",
    "IN2FE": "IGST2(14)(c), relevant establishment",
    "IN2I": "IGST2(6)(i)",
    "IN2II": "IGST2(6)(ii)",
    "IN2III": "IGST2(6)(iii)",
    "IN2IV": "IGST2(6)(iv), as amended2018",
    "IN2V": "IGST2(6)(v)",
    "IN8EX": "IGST8Explanation1(i)",
    "UKL5": "VATA1994 section 7A(5)"
  },
  "conditions_context": "1. **Check place before charging:** never infer domestic tax or export relief from customer geography alone. Use country-specific general and particular rules, not a universal B2B default.",
  "evidence_entry_ids": [
    "EU45",
    "UKL5",
    "AUSCOPE",
    "AUSCOPEEX",
    "AU2ABS",
    "AU2A",
    "AU2AWHENDONE",
    "AU2ALAND",
    "AURIGHT",
    "AUPROPALL",
    "AUPROPITEMS",
    "AUPROP",
    "AULOCALA",
    "AULOCAL",
    "AULOCALC",
    "AULOCALX",
    "AULOCALX2",
    "AULOCALX3",
    "IN2I",
    "IN2II",
    "IN2III",
    "IN2IV",
    "IN2V",
    "IN8EX",
    "IN2FE"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 284,
  "line": 301,
  "original_review_exact_claim": "Use country-specific general and particular rules, not a universal B2B default.",
  "original_review_row_id": 280,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / When to refuse or refer",
  "source_keys": [
    "EU",
    "UKLAW",
    "AU",
    "IN"
  ]
}
```

### 285

2.

```json
{
  "act_articles": {},
  "conditions_context": "2. **Keep categories and credits separate:** never equate zero-rated, outside scope and exempt, or promise full input recovery automatically. Apply actual credit restrictions and any specific exceptions.",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "2."
  ],
  "id": 285,
  "line": 302,
  "original_review_exact_claim": "2.",
  "original_review_row_id": 281,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / When to refuse or refer",
  "source_keys": [
    "POLICY"
  ]
}
```

### 286

**Keep categories and credits separate:** never equate zero-rated, outside scope and exempt, or promise full input recovery automatically.

```json
{
  "act_articles": {
    "AU11A": "s11-5(a)-(d), creditable acquisition",
    "AU11B": "s11-5(b)",
    "AU11C": "s11-5(c)",
    "AU11D": "s11-5(d)",
    "AU11ENTERPRISE": "s11-15(1)",
    "AU11ENTITLE": "s11-20",
    "AU11EX3": "s11-15(3), overseas-enterprise exception to11-15(2)(a)",
    "AU11EX4": "s11-15(4)(b), financial-acquisitions exception",
    "AU11EX5": "s11-15(5)(b), borrowing exception",
    "AU11INPUT": "s11-15(2)(a), subject3-5exceptions",
    "AU11PART": "s11-25 second sentence and11-30(1)/(3)",
    "AU11PRIVATE": "s11-15(2)(b)",
    "AU29INV": "s29-10(3), tax invoice attribution condition, exceptions in final paragraph",
    "AU29INVEX": "s29-10(3), Commissioner exception",
    "EU168": "Article 168, chapeau",
    "EU169A": "Article 169(a), domestic-deductibility condition",
    "EU169AX": "Article 169(a), Article 284 exclusion",
    "EU169C": "Article 169(c), financial/insurance route",
    "EU173": "Article 173(1), mixed use",
    "EU176": "Article 176, second paragraph",
    "EU178": "Article 178(a), invoice condition",
    "SGALL8": "IRAS Conditions you must meet, opening and complete enumerated conditions1-8",
    "SGATTRIB": "Same page, business/nonbusiness use paragraph following condition3"
  },
  "conditions_context": "2. **Keep categories and credits separate:** never equate zero-rated, outside scope and exempt, or promise full input recovery automatically. Apply actual credit restrictions and any specific exceptions.",
  "evidence_entry_ids": [
    "EU168",
    "EU169A",
    "EU169AX",
    "EU169C",
    "EU173",
    "EU176",
    "EU178",
    "AU11A",
    "AU11B",
    "AU11C",
    "AU11D",
    "AU11ENTERPRISE",
    "AU11ENTITLE",
    "AU11PRIVATE",
    "AU11INPUT",
    "AU11EX3",
    "AU11EX4",
    "AU11EX5",
    "AU11PART",
    "AU29INV",
    "AU29INVEX",
    "SGALL8",
    "SGATTRIB"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 286,
  "line": 302,
  "original_review_exact_claim": "**Keep categories and credits separate:** never equate zero-rated, outside scope and exempt, or promise full input recovery automatically.",
  "original_review_row_id": 282,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / When to refuse or refer",
  "source_keys": [
    "EU",
    "AU",
    "SGINPUT"
  ]
}
```

### 287

Apply actual credit restrictions and any specific exceptions.

```json
{
  "act_articles": {
    "AU11A": "s11-5(a)-(d), creditable acquisition",
    "AU11B": "s11-5(b)",
    "AU11C": "s11-5(c)",
    "AU11D": "s11-5(d)",
    "AU11ENTERPRISE": "s11-15(1)",
    "AU11ENTITLE": "s11-20",
    "AU11EX3": "s11-15(3), overseas-enterprise exception to11-15(2)(a)",
    "AU11EX4": "s11-15(4)(b), financial-acquisitions exception",
    "AU11EX5": "s11-15(5)(b), borrowing exception",
    "AU11INPUT": "s11-15(2)(a), subject3-5exceptions",
    "AU11PART": "s11-25 second sentence and11-30(1)/(3)",
    "AU11PRIVATE": "s11-15(2)(b)",
    "AU29INV": "s29-10(3), tax invoice attribution condition, exceptions in final paragraph",
    "AU29INVEX": "s29-10(3), Commissioner exception",
    "EU168": "Article 168, chapeau",
    "EU169A": "Article 169(a), domestic-deductibility condition",
    "EU169AX": "Article 169(a), Article 284 exclusion",
    "EU169C": "Article 169(c), financial/insurance route",
    "EU173": "Article 173(1), mixed use",
    "EU176": "Article 176, second paragraph",
    "EU178": "Article 178(a), invoice condition",
    "SGALL8": "IRAS Conditions you must meet, opening and complete enumerated conditions1-8",
    "SGATTRIB": "Same page, business/nonbusiness use paragraph following condition3"
  },
  "conditions_context": "2. **Keep categories and credits separate:** never equate zero-rated, outside scope and exempt, or promise full input recovery automatically. Apply actual credit restrictions and any specific exceptions.",
  "evidence_entry_ids": [
    "EU168",
    "EU169A",
    "EU169AX",
    "EU169C",
    "EU173",
    "EU176",
    "EU178",
    "AU11A",
    "AU11B",
    "AU11C",
    "AU11D",
    "AU11ENTERPRISE",
    "AU11ENTITLE",
    "AU11PRIVATE",
    "AU11INPUT",
    "AU11EX3",
    "AU11EX4",
    "AU11EX5",
    "AU11PART",
    "AU29INV",
    "AU29INVEX",
    "SGALL8",
    "SGATTRIB"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 287,
  "line": 302,
  "original_review_exact_claim": "Apply actual credit restrictions and any specific exceptions.",
  "original_review_row_id": 283,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / When to refuse or refer",
  "source_keys": [
    "EU",
    "AU",
    "SGINPUT"
  ]
}
```

### 288

3.

```json
{
  "act_articles": {},
  "conditions_context": "3. **Determine actual reporting:** never omit required returns just because output tax is nil, or invent a box. Slovakia's foreign-place omission and Australia's service/G2 distinction show why reporting is country-specific.",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "3."
  ],
  "id": 288,
  "line": 303,
  "original_review_exact_claim": "3.",
  "original_review_row_id": 284,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / When to refuse or refer",
  "source_keys": [
    "POLICY"
  ]
}
```

### 289

**Determine actual reporting:** never omit required returns just because output tax is nil, or invent a box.

```json
{
  "act_articles": {
    "ABG1": "G1 total sales, accounts/calculation-method GST-free-sales bullets",
    "ABG2": "G2 Export sales, What not to report at G2, first bullet",
    "ABG2X": "Same G2 first bullet, exception",
    "ABG3": "G3 Other GST-free sales, What to report at G3",
    "ASIMPLE": "GST reporting methods / Simpler BAS / What to report, complete three-label list",
    "DE21": "Same form, row35/KZ21",
    "DE45": "2026UStVA form PDFpage5, row36/KZ45",
    "DEEXROWS": "Same section, rows33-35 exclusion",
    "DEFOREIGN": "ELSTER2026 / Übrige nicht steuerbare Umsätze, first paragraph",
    "DETAXABLE": "Same paragraph, domestic-taxability condition",
    "FRE2": "CA3notice2026 PDFpage6, LigneE2, final bullet",
    "INRETURNMAP": "GSTR3B FAQ / system generated GSTR3B table, GSTR1 export6A/6B/9 amendments row to3.1(b)",
    "SGBOX2": "IRAS Completing GST returns / Box2 title and qualifying international-services explanation",
    "SKOMIT": "PFS Danove priznanie / Daňové priznanie, foreign-place sentence",
    "UKBOX1": "Notice700/12 section3.2, opening Box1 instruction",
    "UKBOX6": "Notice700/12 section3.7, Box6 list"
  },
  "conditions_context": "3. **Determine actual reporting:** never omit required returns just because output tax is nil, or invent a box. Slovakia's foreign-place omission and Australia's service/G2 distinction show why reporting is country-specific.",
  "evidence_entry_ids": [
    "DE45",
    "DE21",
    "DEFOREIGN",
    "DETAXABLE",
    "DEEXROWS",
    "FRE2",
    "SKOMIT",
    "UKBOX6",
    "UKBOX1",
    "ABG1",
    "ABG3",
    "ABG2",
    "ABG2X",
    "ASIMPLE",
    "INRETURNMAP",
    "SGBOX2"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 289,
  "line": 303,
  "original_review_exact_claim": "**Determine actual reporting:** never omit required returns just because output tax is nil, or invent a box.",
  "original_review_row_id": 285,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / When to refuse or refer",
  "source_keys": [
    "DE",
    "DEHELP",
    "FR",
    "SK",
    "UKRETURN",
    "AUBAS",
    "AUSIMPLE",
    "INRETURN",
    "SGRETURN"
  ]
}
```

### 290

Slovakia's foreign-place omission and Australia's service/G2 distinction show why reporting is country-specific.

```json
{
  "act_articles": {
    "ABG2": "G2 Export sales, What not to report at G2, first bullet",
    "ABG2X": "Same G2 first bullet, exception",
    "SKOMIT": "PFS Danove priznanie / Daňové priznanie, foreign-place sentence"
  },
  "conditions_context": "3. **Determine actual reporting:** never omit required returns just because output tax is nil, or invent a box. Slovakia's foreign-place omission and Australia's service/G2 distinction show why reporting is country-specific.",
  "evidence_entry_ids": [
    "SKOMIT",
    "ABG2",
    "ABG2X"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 290,
  "line": 303,
  "original_review_exact_claim": "Slovakia's foreign-place omission and Australia's service/G2 distinction show why reporting is country-specific.",
  "original_review_row_id": 286,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / When to refuse or refer",
  "source_keys": [
    "SK",
    "AUBAS"
  ]
}
```

### 291

4.

```json
{
  "act_articles": {},
  "conditions_context": "4. **Check all B2C rules:** never assume every foreign consumer receives an outside-scope service, or that Article 59 is the only exception to Article 45.",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "4."
  ],
  "id": 291,
  "line": 304,
  "original_review_exact_claim": "4.",
  "original_review_row_id": 287,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / When to refuse or refer",
  "source_keys": [
    "POLICY"
  ]
}
```

### 292

**Check all B2C rules:** never assume every foreign consumer receives an outside-scope service, or that Article 59 is the only exception to Article 45.

```json
{
  "act_articles": {
    "EU45": "Article 45, first sentence",
    "EU45F": "Article 45, second/third sentences",
    "EU47": "Article 47, final operative clause",
    "EU54": "Article 54(1), first subparagraph",
    "EU54V": "Article 54(1), second subparagraph",
    "EU58": "Article 58(1), chapeau",
    "EU59": "Article 59, chapeau, non-EU customer qualification"
  },
  "conditions_context": "4. **Check all B2C rules:** never assume every foreign consumer receives an outside-scope service, or that Article 59 is the only exception to Article 45.",
  "evidence_entry_ids": [
    "EU45",
    "EU45F",
    "EU47",
    "EU54",
    "EU54V",
    "EU58",
    "EU59"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "59",
    "45."
  ],
  "id": 292,
  "line": 304,
  "original_review_exact_claim": "**Check all B2C rules:** never assume every foreign consumer receives an outside-scope service, or that Article 59 is the only exception to Article 45.",
  "original_review_row_id": 288,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / When to refuse or refer",
  "source_keys": [
    "EU"
  ]
}
```

### 293

5.

```json
{
  "act_articles": {},
  "conditions_context": "5. **Check property and relief together:** never zero-rate merely because the buyer is abroad; land location, actual country relief/exemption and rate need checking. The old worldwide absolute prohibition is not a substitute for Australian/other particular statutory routes.",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "5."
  ],
  "id": 293,
  "line": 305,
  "original_review_exact_claim": "5.",
  "original_review_row_id": 289,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / When to refuse or refer",
  "source_keys": [
    "POLICY"
  ]
}
```

### 294

**Check property and relief together:** never zero-rate merely because the buyer is abroad; land location, actual country relief/exemption and rate need checking.

```json
{
  "act_articles": {
    "AU1": "s38-190(1), item1",
    "AU2ALAND": "s38-190(1), item2(a), land condition",
    "AUPROP": "s38-190(2A), input-taxed property exclusion",
    "EU47": "Article 47, final operative clause",
    "IN13LAND": "IGST13(4)",
    "REG31A": "Article 31a(1), sufficiently direct land connection",
    "SGKLAND": "IRAS table row14/(k), professional/data goods-for-export exception and definite/immediate intention condition",
    "SGLAND": "Same table row13/(j), Singapore goods/land restriction",
    "UKSLAND": "Schedule4A paragraph1(1)"
  },
  "conditions_context": "5. **Check property and relief together:** never zero-rate merely because the buyer is abroad; land location, actual country relief/exemption and rate need checking. The old worldwide absolute prohibition is not a substitute for Australian/other particular statutory routes.",
  "current_goods_ships_boundary": "Singapore professional-versus-data Singapore-goods/ships conditions under the current Second Schedule: the retained 2020 official reproduction distinguishes professional services (export goods and ships) from data services (export goods only), while the current IRAS table combines the categories. The former combined proposition \"professional/data services must not directly relate to Singapore land/goods other than goods for export\" is individually unusable for this branch until the current regulatory text/version is reconciled; no ships relief or blanket ships exclusion is cleared here. ",
  "evidence_entry_ids": [
    "EU47",
    "REG31A",
    "UKSLAND",
    "AU1",
    "AU2ALAND",
    "AUPROP",
    "IN13LAND",
    "SGLAND",
    "SGKLAND"
  ],
  "evidence_format_status": "CURRENT_SHORT_EXTRACT_STANDARD_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "historical_format_status": "HOLD_EXPLICIT_EXTRACT_GAP",
  "historical_quotation_gaps": [
    "SGKLAND"
  ],
  "id": 294,
  "line": 305,
  "original_review_exact_claim": "**Check property and relief together:** never zero-rate merely because the buyer is abroad; land location, actual country relief/exemption and rate need checking.",
  "original_review_row_id": 290,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / When to refuse or refer",
  "source_keys": [
    "EU",
    "REG",
    "UKSCH",
    "AU",
    "IN",
    "SG"
  ]
}
```

### 295

The old worldwide absolute prohibition is not a substitute for Australian/other particular statutory routes.

```json
{
  "act_articles": {
    "AU1": "s38-190(1), item1",
    "AU2BENT": "s38-190(1), item2(b), enterprise condition",
    "AU2BREG": "s38-190(1) item2(b), actual registration wording"
  },
  "conditions_context": "5. **Check property and relief together:** never zero-rate merely because the buyer is abroad; land location, actual country relief/exemption and rate need checking. The old worldwide absolute prohibition is not a substitute for Australian/other particular statutory routes.",
  "evidence_entry_ids": [
    "AU1",
    "AU2BENT",
    "AU2BREG"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "Rejects a former universal prohibition; does not clear another country rate.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 295,
  "line": 305,
  "original_review_exact_claim": "The old worldwide absolute prohibition is not a substitute for Australian/other particular statutory routes.",
  "original_review_row_id": 291,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / When to refuse or refer",
  "source_keys": [
    "AU"
  ]
}
```

### 296

6.

```json
{
  "act_articles": {},
  "conditions_context": "6. **India route and evidence:** never tell an exporter to skip a required LUT/bond, but do not say missing LUT inevitably requires tax payment followed by a guaranteed refund. Check eligibility, permitted late condonation, payment timing and notified paid-route conditions.",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "6."
  ],
  "id": 296,
  "line": 306,
  "original_review_exact_claim": "6.",
  "original_review_row_id": 292,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / When to refuse or refer",
  "source_keys": [
    "POLICY"
  ]
}
```

### 297

**India route and evidence:** never tell an exporter to skip a required LUT/bond, but do not say missing LUT inevitably requires tax payment followed by a guaranteed refund.

```json
{
  "act_articles": {
    "IN16EXPORT": "IGST16(1)(a)",
    "IN16LUT": "IGST16(3), bond/LUT route",
    "IN16PAID": "IGST16(4), scan PDFpage22, notified class/conditions",
    "IN250": "Same condition(i), strict threshold",
    "INARN": "Same substituted2(c)/(e), deemed acceptance",
    "INARNREJECT": "Same substituted2(e), ineligible LUT rejection",
    "INCONDONE": "Circular37/11/2018 paragraph4.1",
    "INCONDONEFACTS": "Same paragraph4.1, individual-facts qualification",
    "INLUTPRIOR": "Circular8/8/2017 paragraph2(e), prior requirement",
    "INLUTYEAR": "Circular8/8/2017 paragraph2(b)",
    "INPROSEC": "Notification37/2017 condition(i), prosecution exclusion",
    "INRFD": "Circular40/14/2018 paragraph2 substituted2(c)"
  },
  "conditions_context": "6. **India route and evidence:** never tell an exporter to skip a required LUT/bond, but do not say missing LUT inevitably requires tax payment followed by a guaranteed refund. Check eligibility, permitted late condonation, payment timing and notified paid-route conditions.",
  "evidence_entry_ids": [
    "IN16EXPORT",
    "IN16LUT",
    "INLUTYEAR",
    "INLUTPRIOR",
    "INPROSEC",
    "IN250",
    "INRFD",
    "INARN",
    "INARNREJECT",
    "INCONDONE",
    "INCONDONEFACTS",
    "IN16PAID"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 297,
  "line": 306,
  "original_review_exact_claim": "**India route and evidence:** never tell an exporter to skip a required LUT/bond, but do not say missing LUT inevitably requires tax payment followed by a guaranteed refund.",
  "original_review_row_id": 293,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / When to refuse or refer",
  "source_keys": [
    "IN",
    "INLUT",
    "IN37",
    "INONLINE",
    "INLATE"
  ]
}
```

### 298

Check eligibility, permitted late condonation, payment timing and notified paid-route conditions.

```json
{
  "act_articles": {
    "IN16PAID": "IGST16(4), scan PDFpage22, notified class/conditions",
    "IN250": "Same condition(i), strict threshold",
    "IN96COMM": "Same substituted96A(1)(b), Commissioner extension",
    "IN96FEMA": "Same substituted96A(1)(b), FEMA/RBI later-period limb",
    "IN96INVOICE": "Notification12/2024 rule20(i), invoice starting date",
    "IN96PAY": "Same substituted96A(1)(b), payment qualification",
    "IN96TIME": "Notification12/2024-CentralTax rule20(i), substituted96A(1)(b)",
    "INCONDONE": "Circular37/11/2018 paragraph4.1",
    "INCONDONEFACTS": "Same paragraph4.1, individual-facts qualification",
    "INPROSEC": "Notification37/2017 condition(i), prosecution exclusion"
  },
  "conditions_context": "6. **India route and evidence:** never tell an exporter to skip a required LUT/bond, but do not say missing LUT inevitably requires tax payment followed by a guaranteed refund. Check eligibility, permitted late condonation, payment timing and notified paid-route conditions.",
  "evidence_entry_ids": [
    "INPROSEC",
    "IN250",
    "IN96TIME",
    "IN96FEMA",
    "IN96INVOICE",
    "IN96COMM",
    "IN96PAY",
    "INCONDONE",
    "INCONDONEFACTS",
    "IN16PAID"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 298,
  "line": 306,
  "original_review_exact_claim": "Check eligibility, permitted late condonation, payment timing and notified paid-route conditions.",
  "original_review_row_id": 294,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / When to refuse or refer",
  "source_keys": [
    "IN37",
    "IN96",
    "INLATE",
    "IN"
  ]
}
```

### 299

7.

```json
{
  "act_articles": {},
  "conditions_context": "7. **Australian item-specific use test:** never impose or disregard effective use/enjoyment without identifying the relevant item, local-beneficiary provision and exclusions. The former blanket no-Australian-use rule is corrected above.",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "7."
  ],
  "id": 299,
  "line": 307,
  "original_review_exact_claim": "7.",
  "original_review_row_id": 295,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / When to refuse or refer",
  "source_keys": [
    "POLICY"
  ]
}
```

### 300

**Australian item-specific use test:** never impose or disregard effective use/enjoyment without identifying the relevant item, local-beneficiary provision and exclusions.

```json
{
  "act_articles": {
    "AU2A": "s38-190(1), item2(a)",
    "AU2ABS": "s38-190(1), item2 chapeau",
    "AU2ALAND": "s38-190(1), item2(a), land condition",
    "AU2AWHENDONE": "s38-190(1) item2(a), timing of local work",
    "AU3": "s38-190(1), item3(b)",
    "AU3ABS": "s38-190(1), item3(a)",
    "AU3EX": "s38-190(1), item3 final exclusion",
    "AU3LAND": "s38-190(1) item3, final exclusion",
    "AULOCAL": "s38-190(3)(b), local provision",
    "AULOCALA": "s38-190(3)(a), nonresident agreement",
    "AULOCALC": "s38-190(3)(c), input-taxed limitation on exceptions",
    "AULOCALX": "s38-190(3)(c)(i), business-recipient exception",
    "AULOCALX2": "s38-190(3)(c)(ii), employee/officer alternative",
    "AULOCALX3": "s38-190(3)(c)(iii), recipient creditable-purpose alternative",
    "AUPROP": "s38-190(2A), input-taxed property exclusion",
    "AUPROPALL": "s38-190(2A), item/application extent",
    "AUPROPITEMS": "s38-190(2A), items2-4",
    "AURIGHT": "s38-190(2), rights/options exclusion",
    "AUSCOPE": "s38-190(1), chapeau",
    "AUSCOPEEX": "s38-190(1), chapeau, exclusions"
  },
  "conditions_context": "7. **Australian item-specific use test:** never impose or disregard effective use/enjoyment without identifying the relevant item, local-beneficiary provision and exclusions. The former blanket no-Australian-use rule is corrected above.",
  "evidence_entry_ids": [
    "AUSCOPE",
    "AUSCOPEEX",
    "AU2ABS",
    "AU2A",
    "AU2AWHENDONE",
    "AU2ALAND",
    "AURIGHT",
    "AUPROPALL",
    "AUPROPITEMS",
    "AUPROP",
    "AULOCALA",
    "AULOCAL",
    "AULOCALC",
    "AULOCALX",
    "AULOCALX2",
    "AULOCALX3",
    "AU3ABS",
    "AU3",
    "AU3EX",
    "AU3LAND"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 300,
  "line": 307,
  "original_review_exact_claim": "**Australian item-specific use test:** never impose or disregard effective use/enjoyment without identifying the relevant item, local-beneficiary provision and exclusions.",
  "original_review_row_id": 296,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / When to refuse or refer",
  "source_keys": [
    "AU"
  ]
}
```

### 301

The former blanket no-Australian-use rule is corrected above.

```json
{
  "act_articles": {
    "AU2A": "s38-190(1), item2(a)",
    "AU2BENT": "s38-190(1), item2(b), enterprise condition",
    "AU2BREG": "s38-190(1) item2(b), actual registration wording",
    "AU3": "s38-190(1), item3(b)",
    "AULOCAL": "s38-190(3)(b), local provision"
  },
  "conditions_context": "7. **Australian item-specific use test:** never impose or disregard effective use/enjoyment without identifying the relevant item, local-beneficiary provision and exclusions. The former blanket no-Australian-use rule is corrected above.",
  "evidence_entry_ids": [
    "AU2A",
    "AU2BENT",
    "AU2BREG",
    "AU3",
    "AULOCAL"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 301,
  "line": 307,
  "original_review_exact_claim": "The former blanket no-Australian-use rule is corrected above.",
  "original_review_row_id": 297,
  "quotation_gaps": [],
  "result_boundary": "Supported within conditions; independent review pending",
  "section": "Quick reference / When to refuse or refer",
  "source_keys": [
    "AU"
  ]
}
```

### 302

Refer an unknown establishment, classification, local scheme/box, mixed supply, local-beneficiary chain, unproved Indian payment permission, foreign registration or tax-paid refund eligibility.

```json
{
  "act_articles": {},
  "conditions_context": "Refer an unknown establishment, classification, local scheme/box, mixed supply, local-beneficiary chain, unproved Indian payment permission, foreign registration or tax-paid refund eligibility. Preserve a clearly supported portion with open items, without presenting a complete cleared export conclusion. The [T1]/[T2]/[T3] labels never override missing evidence.",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 302,
  "line": 309,
  "original_review_exact_claim": "Refer an unknown establishment, classification, local scheme/box, mixed supply, local-beneficiary chain, unproved Indian payment permission, foreign registration or tax-paid refund eligibility.",
  "original_review_row_id": 298,
  "quotation_gaps": [],
  "result_boundary": "Internal workflow/provenance/example-intake policy; not external law",
  "section": "Quick reference / When to refuse or refer",
  "source_keys": [
    "POLICY"
  ]
}
```

### 303

Preserve a clearly supported portion with open items, without presenting a complete cleared export conclusion.

```json
{
  "act_articles": {},
  "conditions_context": "Refer an unknown establishment, classification, local scheme/box, mixed supply, local-beneficiary chain, unproved Indian payment permission, foreign registration or tax-paid refund eligibility. Preserve a clearly supported portion with open items, without presenting a complete cleared export conclusion. The [T1]/[T2]/[T3] labels never override missing evidence.",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 303,
  "line": 309,
  "original_review_exact_claim": "Preserve a clearly supported portion with open items, without presenting a complete cleared export conclusion.",
  "original_review_row_id": 299,
  "quotation_gaps": [],
  "result_boundary": "Internal workflow/provenance/example-intake policy; not external law",
  "section": "Quick reference / When to refuse or refer",
  "source_keys": [
    "POLICY"
  ]
}
```

### 304

The [T1]/[T2]/[T3] labels never override missing evidence.

```json
{
  "act_articles": {},
  "conditions_context": "Refer an unknown establishment, classification, local scheme/box, mixed supply, local-beneficiary chain, unproved Indian payment permission, foreign registration or tax-paid refund eligibility. Preserve a clearly supported portion with open items, without presenting a complete cleared export conclusion. The [T1]/[T2]/[T3] labels never override missing evidence.",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 304,
  "line": 309,
  "original_review_exact_claim": "The [T1]/[T2]/[T3] labels never override missing evidence.",
  "original_review_row_id": 300,
  "quotation_gaps": [],
  "result_boundary": "Internal workflow/provenance/example-intake policy; not external law",
  "section": "Quick reference / When to refuse or refer",
  "source_keys": [
    "POLICY"
  ]
}
```

### 305

Use the actual registration scheme, period and country return instructions.

```json
{
  "act_articles": {},
  "conditions_context": "Use the actual registration scheme, period and country return instructions. Keep the legal place/relief decision, contract, location/status/beneficiary evidence, input-tax support, invoice wording and return reconciliation together. No universal export-services filing deadline or late-penalty rate is supplied here; country Guides must supply the actual filing/payment/penalty computation.",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 305,
  "line": 313,
  "original_review_exact_claim": "Use the actual registration scheme, period and country return instructions.",
  "original_review_row_id": 301,
  "quotation_gaps": [],
  "result_boundary": "Internal workflow/provenance/example-intake policy; not external law",
  "section": "Quick reference / Filing and payment",
  "source_keys": [
    "POLICY"
  ]
}
```

### 306

Keep the legal place/relief decision, contract, location/status/beneficiary evidence, input-tax support, invoice wording and return reconciliation together.

```json
{
  "act_articles": {},
  "conditions_context": "Use the actual registration scheme, period and country return instructions. Keep the legal place/relief decision, contract, location/status/beneficiary evidence, input-tax support, invoice wording and return reconciliation together. No universal export-services filing deadline or late-penalty rate is supplied here; country Guides must supply the actual filing/payment/penalty computation.",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 306,
  "line": 313,
  "original_review_exact_claim": "Keep the legal place/relief decision, contract, location/status/beneficiary evidence, input-tax support, invoice wording and return reconciliation together.",
  "original_review_row_id": 302,
  "quotation_gaps": [],
  "result_boundary": "Internal workflow/provenance/example-intake policy; not external law",
  "section": "Quick reference / Filing and payment",
  "source_keys": [
    "POLICY"
  ]
}
```

### 307

No universal export-services filing deadline or late-penalty rate is supplied here; country Guides must supply the actual filing/payment/penalty computation.

```json
{
  "act_articles": {},
  "conditions_context": "Use the actual registration scheme, period and country return instructions. Keep the legal place/relief decision, contract, location/status/beneficiary evidence, input-tax support, invoice wording and return reconciliation together. No universal export-services filing deadline or late-penalty rate is supplied here; country Guides must supply the actual filing/payment/penalty computation.",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 307,
  "line": 313,
  "original_review_exact_claim": "No universal export-services filing deadline or late-penalty rate is supplied here; country Guides must supply the actual filing/payment/penalty computation.",
  "original_review_row_id": 303,
  "quotation_gaps": [],
  "result_boundary": "Internal workflow/provenance/example-intake policy; not external law",
  "section": "Quick reference / Filing and payment",
  "source_keys": [
    "POLICY"
  ]
}
```

### 308

Confirmed reporting pointers are the conditional German/French/Slovak directions above, ordinary UK Box 6/no output in Box 1, the Australian reporting-method distinction, Indian export/zero-rated tables, and Singapore Box 2.

```json
{
  "act_articles": {
    "ABG1": "G1 total sales, accounts/calculation-method GST-free-sales bullets",
    "ABG2": "G2 Export sales, What not to report at G2, first bullet",
    "ABG2X": "Same G2 first bullet, exception",
    "ABG3": "G3 Other GST-free sales, What to report at G3",
    "ASIMPLE": "GST reporting methods / Simpler BAS / What to report, complete three-label list",
    "DE21": "Same form, row35/KZ21",
    "DE45": "2026UStVA form PDFpage5, row36/KZ45",
    "DEEXROWS": "Same section, rows33-35 exclusion",
    "DEFOREIGN": "ELSTER2026 / Übrige nicht steuerbare Umsätze, first paragraph",
    "DETAXABLE": "Same paragraph, domestic-taxability condition",
    "FRE2": "CA3notice2026 PDFpage6, LigneE2, final bullet",
    "INRETURNMAP": "GSTR3B FAQ / system generated GSTR3B table, GSTR1 export6A/6B/9 amendments row to3.1(b)",
    "SGBOX2": "IRAS Completing GST returns / Box2 title and qualifying international-services explanation",
    "SKOMIT": "PFS Danove priznanie / Daňové priznanie, foreign-place sentence",
    "UKBOX1": "Notice700/12 section3.2, opening Box1 instruction",
    "UKBOX6": "Notice700/12 section3.7, Box6 list"
  },
  "conditions_context": "Confirmed reporting pointers are the conditional German/French/Slovak directions above, ordinary UK Box 6/no output in Box 1, the Australian reporting-method distinction, Indian export/zero-rated tables, and Singapore Box 2. The Italian evidence is explicitly the 2025-2026 filing cycle; Malta's former field remains unconfirmed. None of these pointers alone clears destination-country registration, reverse charge, income-tax withholding or permanent-establishment risk.",
  "evidence_entry_ids": [
    "DE45",
    "DE21",
    "DEFOREIGN",
    "DETAXABLE",
    "DEEXROWS",
    "FRE2",
    "SKOMIT",
    "UKBOX6",
    "UKBOX1",
    "ABG1",
    "ABG3",
    "ABG2",
    "ABG2X",
    "ASIMPLE",
    "INRETURNMAP",
    "SGBOX2"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "Reporting recap reuses only identical actual return directions separately supported in the country rows; all their conditions remain applicable.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "6",
    "1,",
    "2."
  ],
  "id": 308,
  "line": 315,
  "original_review_exact_claim": "Confirmed reporting pointers are the conditional German/French/Slovak directions above, ordinary UK Box 6/no output in Box 1, the Australian reporting-method distinction, Indian export/zero-rated tables, and Singapore Box 2.",
  "original_review_row_id": 304,
  "quotation_gaps": [],
  "result_boundary": "Internal workflow/provenance/example-intake policy; not external law",
  "section": "Quick reference / Filing and payment",
  "source_keys": [
    "DE",
    "DEHELP",
    "FR",
    "SK",
    "UKRETURN",
    "AUBAS",
    "AUSIMPLE",
    "INRETURN",
    "SGRETURN"
  ]
}
```

### 309

The Italian evidence is explicitly the 2025-2026 filing cycle; Malta's former field remains unconfirmed.

```json
{
  "act_articles": {
    "ITCYCLE": "IVA2026 cover",
    "ITINVOICE": "Same VE34 first sentence, invoice condition",
    "ITVE34": "IVA2026 instructions RigoVE34, first sentence"
  },
  "conditions_context": "Confirmed reporting pointers are the conditional German/French/Slovak directions above, ordinary UK Box 6/no output in Box 1, the Australian reporting-method distinction, Indian export/zero-rated tables, and Singapore Box 2. The Italian evidence is explicitly the 2025-2026 filing cycle; Malta's former field remains unconfirmed. None of these pointers alone clears destination-country registration, reverse charge, income-tax withholding or permanent-establishment risk.",
  "evidence_entry_ids": [
    "ITCYCLE",
    "ITVE34",
    "ITINVOICE"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "Italian 2025 period/2026 filing-cycle restriction supported; Malta field is expressly unresolved and has no fabricated extract.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "2025",
    "2026"
  ],
  "id": 309,
  "line": 315,
  "original_review_exact_claim": "The Italian evidence is explicitly the 2025-2026 filing cycle; Malta's former field remains unconfirmed.",
  "original_review_row_id": 305,
  "quotation_gaps": [],
  "result_boundary": "Internal workflow/provenance/example-intake policy; not external law",
  "section": "Quick reference / Filing and payment",
  "source_keys": [
    "IT"
  ]
}
```

### 310

None of these pointers alone clears destination-country registration, reverse charge, income-tax withholding or permanent-establishment risk.

```json
{
  "act_articles": {},
  "conditions_context": "Confirmed reporting pointers are the conditional German/French/Slovak directions above, ordinary UK Box 6/no output in Box 1, the Australian reporting-method distinction, Indian export/zero-rated tables, and Singapore Box 2. The Italian evidence is explicitly the 2025-2026 filing cycle; Malta's former field remains unconfirmed. None of these pointers alone clears destination-country registration, reverse charge, income-tax withholding or permanent-establishment risk.",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 310,
  "line": 315,
  "original_review_exact_claim": "None of these pointers alone clears destination-country registration, reverse charge, income-tax withholding or permanent-establishment risk.",
  "original_review_row_id": 306,
  "quotation_gaps": [],
  "result_boundary": "Internal workflow/provenance/example-intake policy; not external law",
  "section": "Quick reference / Filing and payment",
  "source_keys": [
    "POLICY"
  ]
}
```

### 311

- [ ] Actual seller scheme, recipient/status, relevant establishments and service classification established.

```json
{
  "act_articles": {
    "EU43": "Article 43(2)",
    "REG18A": "Article 18(3)(a), non-EU customer certificate",
    "REG18B": "Article 18(3)(b), alternative proof and verification",
    "REG18CONTRARY": "Article18(3), opening safeguard",
    "REG18ID": "Article18(3)(b), identifiers alternative",
    "REG18V": "Article 18(3)(b), verification condition",
    "REG19": "Article 19, first paragraph, private use",
    "UKBELONG": "Notice741A sections3-4 and6, customer business/status/belonging evidence and relevant establishment"
  },
  "conditions_context": "- [ ] Actual seller scheme, recipient/status, relevant establishments and service classification established.",
  "evidence_entry_ids": [
    "REG18CONTRARY",
    "REG18A",
    "REG18ID",
    "REG18B",
    "REG18V",
    "REG19",
    "EU43",
    "UKBELONG"
  ],
  "evidence_format_status": "CURRENT_SHORT_EXTRACT_STANDARD_APPLICABLE",
  "evidence_recommendation_note": "Internal checklist or conditional recap; native extracts support the referenced underlying legal facts, not enactment of this workflow wording.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "historical_format_status": "HOLD_EXPLICIT_EXTRACT_GAP",
  "historical_quotation_gaps": [
    "UKBELONG"
  ],
  "id": 311,
  "line": 319,
  "original_review_exact_claim": "- [ ] Actual seller scheme, recipient/status, relevant establishments and service classification established.",
  "original_review_row_id": 307,
  "quotation_gaps": [],
  "result_boundary": "Internal workflow/provenance/example-intake policy; not external law",
  "section": "Quick reference / Completion checklist",
  "source_keys": [
    "REG",
    "EU",
    "UK"
  ]
}
```

### 312

- [ ] Country-specific particular rules and actual local use/beneficiary exceptions checked before general relief.

```json
{
  "act_articles": {
    "AU2A": "s38-190(1), item2(a)",
    "AU2ABS": "s38-190(1), item2 chapeau",
    "AU2ALAND": "s38-190(1), item2(a), land condition",
    "AU2AWHENDONE": "s38-190(1) item2(a), timing of local work",
    "AU3": "s38-190(1), item3(b)",
    "AU3ABS": "s38-190(1), item3(a)",
    "AU3EX": "s38-190(1), item3 final exclusion",
    "AU3LAND": "s38-190(1) item3, final exclusion",
    "AULOCAL": "s38-190(3)(b), local provision",
    "AULOCALA": "s38-190(3)(a), nonresident agreement",
    "AULOCALC": "s38-190(3)(c), input-taxed limitation on exceptions",
    "AULOCALX": "s38-190(3)(c)(i), business-recipient exception",
    "AULOCALX2": "s38-190(3)(c)(ii), employee/officer alternative",
    "AULOCALX3": "s38-190(3)(c)(iii), recipient creditable-purpose alternative",
    "AUPROP": "s38-190(2A), input-taxed property exclusion",
    "AUPROPALL": "s38-190(2A), item/application extent",
    "AUPROPITEMS": "s38-190(2A), items2-4",
    "AURIGHT": "s38-190(2), rights/options exclusion",
    "AUSCOPE": "s38-190(1), chapeau",
    "AUSCOPEEX": "s38-190(1), chapeau, exclusions",
    "SGABS": "IRAS table row13/(j), overseas customer absence and overseas direct beneficiary absence",
    "SGCONTRACT": "IRAS international-services table row13/(j) and row14/(k), identical overseas-contract limb",
    "SGGOODS": "IRAS table rows9/10/12:21(3)(g)/(h)/(f), goods/export evidence",
    "SGLAND": "Same table row13/(j), Singapore goods/land restriction",
    "SGLOCAL": "Same table rows13/(j) and14/(k), identical local-beneficiary alternative"
  },
  "conditions_context": "- [ ] Country-specific particular rules and actual local use/beneficiary exceptions checked before general relief.",
  "evidence_entry_ids": [
    "AUSCOPE",
    "AUSCOPEEX",
    "AU2ABS",
    "AU2A",
    "AU2AWHENDONE",
    "AU2ALAND",
    "AURIGHT",
    "AUPROPALL",
    "AUPROPITEMS",
    "AUPROP",
    "AULOCALA",
    "AULOCAL",
    "AULOCALC",
    "AULOCALX",
    "AULOCALX2",
    "AULOCALX3",
    "AU3ABS",
    "AU3",
    "AU3EX",
    "AU3LAND",
    "SGCONTRACT",
    "SGABS",
    "SGLOCAL",
    "SGLAND",
    "SGGOODS"
  ],
  "evidence_format_status": "CURRENT_SHORT_EXTRACT_STANDARD_APPLICABLE",
  "evidence_recommendation_note": "Internal checklist or conditional recap; native extracts support the referenced underlying legal facts, not enactment of this workflow wording.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "historical_format_status": "HOLD_EXPLICIT_EXTRACT_GAP",
  "historical_quotation_gaps": [
    "SGABS",
    "SGGOODS"
  ],
  "id": 312,
  "line": 320,
  "original_review_exact_claim": "- [ ] Country-specific particular rules and actual local use/beneficiary exceptions checked before general relief.",
  "original_review_row_id": 308,
  "quotation_gaps": [],
  "result_boundary": "Internal workflow/provenance/example-intake policy; not external law",
  "section": "Quick reference / Completion checklist",
  "source_keys": [
    "AU",
    "SG"
  ]
}
```

### 313

- [ ] Outside scope, zero-rating/GST-free and exempt treatment distinguished; no fictitious 0% rate for an outside-scope EU invoice.

```json
{
  "act_articles": {
    "AUSCOPE": "s38-190(1), chapeau",
    "EU44B": "Article 44, first sentence",
    "IN16EXPORT": "IGST16(1)(a)"
  },
  "conditions_context": "- [ ] Outside scope, zero-rating/GST-free and exempt treatment distinguished; no fictitious 0% rate for an outside-scope EU invoice.",
  "evidence_entry_ids": [
    "EU44B",
    "AUSCOPE",
    "IN16EXPORT"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "Internal checklist or conditional recap; native extracts support the referenced underlying legal facts, not enactment of this workflow wording.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [
    "0%"
  ],
  "id": 313,
  "line": 321,
  "original_review_exact_claim": "- [ ] Outside scope, zero-rating/GST-free and exempt treatment distinguished; no fictitious 0% rate for an outside-scope EU invoice.",
  "original_review_row_id": 309,
  "quotation_gaps": [],
  "result_boundary": "Internal workflow/provenance/example-intake policy; not external law",
  "section": "Quick reference / Completion checklist",
  "source_keys": [
    "EU",
    "AU",
    "IN"
  ]
}
```

### 314

- [ ] Each input-credit claim separately supported; private, exempt and blocked expenditure considered.

```json
{
  "act_articles": {
    "AU11A": "s11-5(a)-(d), creditable acquisition",
    "AU11B": "s11-5(b)",
    "AU11C": "s11-5(c)",
    "AU11D": "s11-5(d)",
    "AU11ENTERPRISE": "s11-15(1)",
    "AU11ENTITLE": "s11-20",
    "AU11EX3": "s11-15(3), overseas-enterprise exception to11-15(2)(a)",
    "AU11EX4": "s11-15(4)(b), financial-acquisitions exception",
    "AU11EX5": "s11-15(5)(b), borrowing exception",
    "AU11INPUT": "s11-15(2)(a), subject3-5exceptions",
    "AU11PART": "s11-25 second sentence and11-30(1)/(3)",
    "AU11PRIVATE": "s11-15(2)(b)",
    "AU29INV": "s29-10(3), tax invoice attribution condition, exceptions in final paragraph",
    "AU29INVEX": "s29-10(3), Commissioner exception",
    "EU168": "Article 168, chapeau",
    "EU169A": "Article 169(a), domestic-deductibility condition",
    "EU169AX": "Article 169(a), Article 284 exclusion",
    "EU169C": "Article 169(c), financial/insurance route",
    "EU173": "Article 173(1), mixed use",
    "EU176": "Article 176, second paragraph",
    "EU178": "Article 178(a), invoice condition",
    "SGALL8": "IRAS Conditions you must meet, opening and complete enumerated conditions1-8",
    "SGATTRIB": "Same page, business/nonbusiness use paragraph following condition3"
  },
  "conditions_context": "- [ ] Each input-credit claim separately supported; private, exempt and blocked expenditure considered.",
  "evidence_entry_ids": [
    "EU168",
    "EU169A",
    "EU169AX",
    "EU169C",
    "EU173",
    "EU176",
    "EU178",
    "AU11A",
    "AU11B",
    "AU11C",
    "AU11D",
    "AU11ENTERPRISE",
    "AU11ENTITLE",
    "AU11PRIVATE",
    "AU11INPUT",
    "AU11EX3",
    "AU11EX4",
    "AU11EX5",
    "AU11PART",
    "AU29INV",
    "AU29INVEX",
    "SGALL8",
    "SGATTRIB"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "Internal checklist or conditional recap; native extracts support the referenced underlying legal facts, not enactment of this workflow wording.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 314,
  "line": 322,
  "original_review_exact_claim": "- [ ] Each input-credit claim separately supported; private, exempt and blocked expenditure considered.",
  "original_review_row_id": 310,
  "quotation_gaps": [],
  "result_boundary": "Internal workflow/provenance/example-intake policy; not external law",
  "section": "Quick reference / Completion checklist",
  "source_keys": [
    "EU",
    "AU",
    "SGINPUT"
  ]
}
```

### 315

- [ ] India currency/receipt and LUT/bond/paid-route eligibility evidenced for the correct financial year.

```json
{
  "act_articles": {
    "IN16EXPORT": "IGST16(1)(a)",
    "IN16LUT": "IGST16(3), bond/LUT route",
    "IN250": "Same condition(i), strict threshold",
    "IN2FE": "IGST2(14)(c), relevant establishment",
    "IN2I": "IGST2(6)(i)",
    "IN2II": "IGST2(6)(ii)",
    "IN2III": "IGST2(6)(iii)",
    "IN2IV": "IGST2(6)(iv), as amended2018",
    "IN2V": "IGST2(6)(v)",
    "IN8EX": "IGST8Explanation1(i)",
    "IN96COMM": "Same substituted96A(1)(b), Commissioner extension",
    "IN96FEMA": "Same substituted96A(1)(b), FEMA/RBI later-period limb",
    "IN96INVOICE": "Notification12/2024 rule20(i), invoice starting date",
    "IN96PAY": "Same substituted96A(1)(b), payment qualification",
    "IN96TIME": "Notification12/2024-CentralTax rule20(i), substituted96A(1)(b)",
    "INARN": "Same substituted2(c)/(e), deemed acceptance",
    "INARNREJECT": "Same substituted2(e), ineligible LUT rejection",
    "INLUTPRIOR": "Circular8/8/2017 paragraph2(e), prior requirement",
    "INLUTYEAR": "Circular8/8/2017 paragraph2(b)",
    "INPROSEC": "Notification37/2017 condition(i), prosecution exclusion",
    "INRFD": "Circular40/14/2018 paragraph2 substituted2(c)"
  },
  "conditions_context": "- [ ] India currency/receipt and LUT/bond/paid-route eligibility evidenced for the correct financial year.",
  "evidence_entry_ids": [
    "IN2I",
    "IN2II",
    "IN2III",
    "IN2IV",
    "IN2V",
    "IN8EX",
    "IN2FE",
    "IN16EXPORT",
    "IN16LUT",
    "INLUTYEAR",
    "INLUTPRIOR",
    "INPROSEC",
    "IN250",
    "INRFD",
    "INARN",
    "INARNREJECT",
    "IN96TIME",
    "IN96FEMA",
    "IN96INVOICE",
    "IN96COMM",
    "IN96PAY"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "Internal checklist or conditional recap; native extracts support the referenced underlying legal facts, not enactment of this workflow wording.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 315,
  "line": 323,
  "original_review_exact_claim": "- [ ] India currency/receipt and LUT/bond/paid-route eligibility evidenced for the correct financial year.",
  "original_review_row_id": 311,
  "quotation_gaps": [],
  "result_boundary": "Internal workflow/provenance/example-intake policy; not external law",
  "section": "Quick reference / Completion checklist",
  "source_keys": [
    "IN",
    "INLUT",
    "IN37",
    "INONLINE",
    "IN96"
  ]
}
```

### 316

- [ ] Actual form/period/return values reconciled; all unconfirmed fields and foreign-tax questions held open.

```json
{
  "act_articles": {
    "ABG1": "G1 total sales, accounts/calculation-method GST-free-sales bullets",
    "ABG2": "G2 Export sales, What not to report at G2, first bullet",
    "ABG2X": "Same G2 first bullet, exception",
    "ABG3": "G3 Other GST-free sales, What to report at G3",
    "ASIMPLE": "GST reporting methods / Simpler BAS / What to report, complete three-label list",
    "DE21": "Same form, row35/KZ21",
    "DE45": "2026UStVA form PDFpage5, row36/KZ45",
    "DEEXROWS": "Same section, rows33-35 exclusion",
    "DEFOREIGN": "ELSTER2026 / Übrige nicht steuerbare Umsätze, first paragraph",
    "DETAXABLE": "Same paragraph, domestic-taxability condition",
    "FRE2": "CA3notice2026 PDFpage6, LigneE2, final bullet",
    "INRETURNMAP": "GSTR3B FAQ / system generated GSTR3B table, GSTR1 export6A/6B/9 amendments row to3.1(b)",
    "SGBOX2": "IRAS Completing GST returns / Box2 title and qualifying international-services explanation",
    "SKOMIT": "PFS Danove priznanie / Daňové priznanie, foreign-place sentence",
    "UKBOX1": "Notice700/12 section3.2, opening Box1 instruction",
    "UKBOX6": "Notice700/12 section3.7, Box6 list"
  },
  "conditions_context": "- [ ] Actual form/period/return values reconciled; all unconfirmed fields and foreign-tax questions held open.",
  "evidence_entry_ids": [
    "DE45",
    "DE21",
    "DEFOREIGN",
    "DETAXABLE",
    "DEEXROWS",
    "FRE2",
    "SKOMIT",
    "UKBOX6",
    "UKBOX1",
    "ABG1",
    "ABG3",
    "ABG2",
    "ABG2X",
    "ASIMPLE",
    "INRETURNMAP",
    "SGBOX2"
  ],
  "evidence_format_status": "CLAUSE_SPECIFIC_EXTRACT_SUPPLIED",
  "evidence_recommendation_note": "Internal checklist or conditional recap; native extracts support the referenced underlying legal facts, not enactment of this workflow wording.",
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 316,
  "line": 324,
  "original_review_exact_claim": "- [ ] Actual form/period/return values reconciled; all unconfirmed fields and foreign-tax questions held open.",
  "original_review_row_id": 312,
  "quotation_gaps": [],
  "result_boundary": "Internal workflow/provenance/example-intake policy; not external law",
  "section": "Quick reference / Completion checklist",
  "source_keys": [
    "DE",
    "DEHELP",
    "FR",
    "SK",
    "UKRETURN",
    "AUBAS",
    "AUSIMPLE",
    "INRETURN",
    "SGRETURN"
  ]
}
```

### 317

- [ ] Every original scenario/edge/test retained with its necessary corrected conditions; arithmetic checked without changing the legal classification.

```json
{
  "act_articles": {},
  "conditions_context": "- [ ] Every original scenario/edge/test retained with its necessary corrected conditions; arithmetic checked without changing the legal classification.",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 317,
  "line": 325,
  "original_review_exact_claim": "- [ ] Every original scenario/edge/test retained with its necessary corrected conditions; arithmetic checked without changing the legal classification.",
  "original_review_row_id": 313,
  "quotation_gaps": [],
  "result_boundary": "Internal workflow/provenance/example-intake policy; not external law",
  "section": "Quick reference / Completion checklist",
  "source_keys": [
    "POLICY"
  ]
}
```

### 318

- [ ] Draft reviewed for the actual engagement by a qualified professional; source research is not accountant attestation.

```json
{
  "act_articles": {},
  "conditions_context": "- [ ] Draft reviewed for the actual engagement by a qualified professional; source research is not accountant attestation.",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 318,
  "line": 326,
  "original_review_exact_claim": "- [ ] Draft reviewed for the actual engagement by a qualified professional; source research is not accountant attestation.",
  "original_review_row_id": 314,
  "quotation_gaps": [],
  "result_boundary": "Internal workflow/provenance/example-intake policy; not external law",
  "section": "Quick reference / Completion checklist",
  "source_keys": [
    "POLICY"
  ]
}
```

### 319

This skill and its outputs are provided for informational and computational purposes only and do not constitute tax, legal, or financial advice.

```json
{
  "act_articles": {},
  "conditions_context": "This skill and its outputs are provided for informational and computational purposes only and do not constitute tax, legal, or financial advice. Open Accountants and its contributors accept no liability for any errors, omissions, or outcomes arising from the use of this skill. All outputs must be reviewed and signed off by a qualified professional (such as a CPA, EA, tax attorney, or equivalent licensed practitioner in your jurisdiction) before filing or acting upon.",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 319,
  "line": 330,
  "original_review_exact_claim": "This skill and its outputs are provided for informational and computational purposes only and do not constitute tax, legal, or financial advice.",
  "original_review_row_id": 315,
  "quotation_gaps": [],
  "result_boundary": "Internal workflow/provenance/example-intake policy; not external law",
  "section": "Quick reference / Completion checklist / Disclaimer",
  "source_keys": [
    "POLICY"
  ]
}
```

### 320

Open Accountants and its contributors accept no liability for any errors, omissions, or outcomes arising from the use of this skill.

```json
{
  "act_articles": {},
  "conditions_context": "This skill and its outputs are provided for informational and computational purposes only and do not constitute tax, legal, or financial advice. Open Accountants and its contributors accept no liability for any errors, omissions, or outcomes arising from the use of this skill. All outputs must be reviewed and signed off by a qualified professional (such as a CPA, EA, tax attorney, or equivalent licensed practitioner in your jurisdiction) before filing or acting upon.",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 320,
  "line": 330,
  "original_review_exact_claim": "Open Accountants and its contributors accept no liability for any errors, omissions, or outcomes arising from the use of this skill.",
  "original_review_row_id": 316,
  "quotation_gaps": [],
  "result_boundary": "Internal workflow/provenance/example-intake policy; not external law",
  "section": "Quick reference / Completion checklist / Disclaimer",
  "source_keys": [
    "POLICY"
  ]
}
```

### 321

All outputs must be reviewed and signed off by a qualified professional (such as a CPA, EA, tax attorney, or equivalent licensed practitioner in your jurisdiction) before filing or acting upon.

```json
{
  "act_articles": {},
  "conditions_context": "This skill and its outputs are provided for informational and computational purposes only and do not constitute tax, legal, or financial advice. Open Accountants and its contributors accept no liability for any errors, omissions, or outcomes arising from the use of this skill. All outputs must be reviewed and signed off by a qualified professional (such as a CPA, EA, tax attorney, or equivalent licensed practitioner in your jurisdiction) before filing or acting upon.",
  "evidence_entry_ids": [],
  "evidence_format_status": "NATIVE_EXTRACT_NOT_APPLICABLE",
  "evidence_recommendation_note": null,
  "figure_character": "Identifiers/dates, sourced legal figures, or explicitly hypothetical case inputs/derived outputs; full context controls",
  "figures_in_claim": [],
  "id": 321,
  "line": 330,
  "original_review_exact_claim": "All outputs must be reviewed and signed off by a qualified professional (such as a CPA, EA, tax attorney, or equivalent licensed practitioner in your jurisdiction) before filing or acting upon.",
  "original_review_row_id": 317,
  "quotation_gaps": [],
  "result_boundary": "Internal workflow/provenance/example-intake policy; not external law",
  "section": "Quick reference / Completion checklist / Disclaimer",
  "source_keys": [
    "POLICY"
  ]
}
```

## Original-topic destinations

The complete original-topic destination table is in `../non-eu-export-services/old-topic-map.json`.
