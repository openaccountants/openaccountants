# family-holding-company-location-compared figure and rule ledger

Public projection; canonical private SHA256: `ef3689f32893d326339fc69eb23bc5339e11ad7dc815f5c904822f6979899192`. Complete captured/native source passages remain local. The JSON companion preserves every retained evidence field.

## Whole rule groups

### MT-RATE

Company tax35% on chargeable income; no inference of final shareholder burden.

```json
{
  "act_article_or_scope": "Cap123 Art56(6), full paragraph and neighbouring company provisions",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "Company tax35% on chargeable income; no inference of final shareholder burden.",
  "id": "MT-RATE",
  "official_url": "https://legislation.mt/eli/cap/123/eng/pdf",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "| Company rate, article 56(6) | 35% | Apply the complete conditions in this country section; this value is not an unconditional bill. | https://legislation.mt/eli/cap/123/eng/pdf |",
      "line": 55
    },
    {
      "actual_text": "| Malta | 35% (article 56(6)); elective 15%, final, subject to the statutory floor and election conditions (L.N. 188 of 2025) | Participating holding (at least 5% of equity with 5% of 2 rights, or EUR 1,164,000 held 183 days, among other routes) plus anti-abuse test | Same participating holding test; restricted for Malta-resident investees (art. 12(1)(u) proviso) | Refunds to the shareholder (6/7, 5/7, 2/3 or 100%) on taxed-account dividends; fifteen per cent deducted on untaxed-account dividends to a \"recipient\" (article 61: mainly Malta-resident persons other than companies, and non-residents controlled by Malta ordinarily resident and domiciled individuals) | https://legislation.mt/eli/cap/123/eng/pdf; https://legislation.mt/eli/cap/372/eng/pdf; https://legislation.mt/eli/ln/2025/188/eng/pdf |",
      "line": 36
    }
  ],
  "short_exact_native_quotes": [
    "thirty-five cents"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/01.txt",
  "source_key": "01",
  "source_sha256": "4ab01721e228a68e059199bd668492461f8dea9ccbe8b74d427ded4e135a20cb",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### MT-EQUITY

Defined equity holding normally non-property company;2ofvotes/profits/liquidation rights. Direct and defined indirect Malta property, with business-premises exception, must be checked before any participation route.

```json
{
  "act_article_or_scope": "Art2 equity holding/property company/participating holding definitions, actual200–285/479–640",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "Defined equity holding normally non-property company;2ofvotes/profits/liquidation rights. Direct and defined indirect Malta property, with business-premises exception, must be checked before any participation route.",
  "id": "MT-EQUITY",
  "official_url": "https://legislation.mt/eli/cap/123/eng/pdf",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "- WHO: a company registered in Malta that holds a participating holding. An equity holding normally requires a company that is not a defined property company and at least 2 of votes, profits and winding-up assets. The property-company definition includes direct Malta immovable property or rights and specified indirect interests, with the statutory business-premises exception; test that definition before using any route. The definition in article 2(1) has several routes, any one of which is enough (OR): at least five percent of the equity shares with at least five percent of any two of votes, distributable profits and assets on a winding up; an option to acquire the entire remaining equity shares to the extent permitted by the investee country’s law; first refusal on a proposed disposal, redemption or cancellation of all remaining equity shares; the right to sit on or appoint a director to the board; an investment of at least the amount in the table held for an uninterrupted period of not less than 183 days; or a holding for the furtherance of its own business that is not trading stock.",
      "line": 65
    }
  ],
  "short_exact_native_quotes": [
    "at least two of the following rights"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/01.txt",
  "source_key": "01",
  "source_sha256": "4ab01721e228a68e059199bd668492461f8dea9ccbe8b74d427ded4e135a20cb",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### MT-PARTICIPATION-A

Direct5%equity AND5%ofany2ofvotes/profits/liquidation;not5%alone.

```json
{
  "act_article_or_scope": "Art2 participating holding(a), whole489–500",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "Direct5%equity AND5%ofany2ofvotes/profits/liquidation;not5%alone.",
  "id": "MT-PARTICIPATION-A",
  "official_url": "https://legislation.mt/eli/cap/123/eng/pdf",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "| Participating holding, route (a) | at least five percent of the equity shares | Apply the complete conditions in this country section; this value is not an unconditional bill. | https://legislation.mt/eli/cap/123/eng/pdf |",
      "line": 56
    },
    {
      "actual_text": "- WHO: a company registered in Malta that holds a participating holding. An equity holding normally requires a company that is not a defined property company and at least 2 of votes, profits and winding-up assets. The property-company definition includes direct Malta immovable property or rights and specified indirect interests, with the statutory business-premises exception; test that definition before using any route. The definition in article 2(1) has several routes, any one of which is enough (OR): at least five percent of the equity shares with at least five percent of any two of votes, distributable profits and assets on a winding up; an option to acquire the entire remaining equity shares to the extent permitted by the investee country’s law; first refusal on a proposed disposal, redemption or cancellation of all remaining equity shares; the right to sit on or appoint a director to the board; an investment of at least the amount in the table held for an uninterrupted period of not less than 183 days; or a holding for the furtherance of its own business that is not trading stock.",
      "line": 65
    }
  ],
  "short_exact_native_quotes": [
    "at least five percent of the"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/01.txt",
  "source_key": "01",
  "source_sha256": "4ab01721e228a68e059199bd668492461f8dea9ccbe8b74d427ded4e135a20cb",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### MT-PARTICIPATION-BCDF

Alternative entire-remaining-equity call to extent permitted, first refusal over all remaining shares, board seat/appointment, or own-business furtherance not trading stock.

```json
{
  "act_article_or_scope": "Art2 participating holding(b–d)/(f), whole501–536",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "Alternative entire-remaining-equity call to extent permitted, first refusal over all remaining shares, board seat/appointment, or own-business furtherance not trading stock.",
  "id": "MT-PARTICIPATION-BCDF",
  "official_url": "https://legislation.mt/eli/cap/123/eng/pdf",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "- WHO: a company registered in Malta that holds a participating holding. An equity holding normally requires a company that is not a defined property company and at least 2 of votes, profits and winding-up assets. The property-company definition includes direct Malta immovable property or rights and specified indirect interests, with the statutory business-premises exception; test that definition before using any route. The definition in article 2(1) has several routes, any one of which is enough (OR): at least five percent of the equity shares with at least five percent of any two of votes, distributable profits and assets on a winding up; an option to acquire the entire remaining equity shares to the extent permitted by the investee country’s law; first refusal on a proposed disposal, redemption or cancellation of all remaining equity shares; the right to sit on or appoint a director to the board; an investment of at least the amount in the table held for an uninterrupted period of not less than 183 days; or a holding for the furtherance of its own business that is not trading stock.",
      "line": 65
    }
  ],
  "short_exact_native_quotes": [
    "the entire balance of the equity shares"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/01.txt",
  "source_key": "01",
  "source_sha256": "4ab01721e228a68e059199bd668492461f8dea9ccbe8b74d427ded4e135a20cb",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### MT-PARTICIPATION-E

Alternative1.164m acquisition-value investment uninterrupted183days.

```json
{
  "act_article_or_scope": "Art2 participating holding(e), whole518–525",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "Alternative1.164m acquisition-value investment uninterrupted183days.",
  "id": "MT-PARTICIPATION-E",
  "official_url": "https://legislation.mt/eli/cap/123/eng/pdf",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "| Participating holding, route (e) | EUR 1,164,000 | Apply the complete conditions in this country section; this value is not an unconditional bill. | https://legislation.mt/eli/cap/123/eng/pdf |",
      "line": 57
    },
    {
      "actual_text": "- WHO: a company registered in Malta that holds a participating holding. An equity holding normally requires a company that is not a defined property company and at least 2 of votes, profits and winding-up assets. The property-company definition includes direct Malta immovable property or rights and specified indirect interests, with the statutory business-premises exception; test that definition before using any route. The definition in article 2(1) has several routes, any one of which is enough (OR): at least five percent of the equity shares with at least five percent of any two of votes, distributable profits and assets on a winding up; an option to acquire the entire remaining equity shares to the extent permitted by the investee country’s law; first refusal on a proposed disposal, redemption or cancellation of all remaining equity shares; the right to sit on or appoint a director to the board; an investment of at least the amount in the table held for an uninterrupted period of not less than 183 days; or a holding for the furtherance of its own business that is not trading stock.",
      "line": 65
    }
  ],
  "short_exact_native_quotes": [
    "(€1,164,000)"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/01.txt",
  "source_key": "01",
  "source_sha256": "4ab01721e228a68e059199bd668492461f8dea9ccbe8b74d427ded4e135a20cb",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### MT-EXEMPTION-CHOICE

Company registered Malta exemption income/gains/transfer only where not declared chargeable; statutory eligible partnership/EEIG/foreign similar limited CIV extensions; option to tax supports conditional shareholder refund.

```json
{
  "act_article_or_scope": "Art12(1)(u)(1) opening and Art2 participation extension, whole4335–4365/537–579",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "Company registered Malta exemption income/gains/transfer only where not declared chargeable; statutory eligible partnership/EEIG/foreign similar limited CIV extensions; option to tax supports conditional shareholder refund.",
  "id": "MT-EXEMPTION-CHOICE",
  "official_url": "https://legislation.mt/eli/cap/123/eng/pdf",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "- WHAT: income or gains from the participating holding, and gains on its transfer, are exempt where the company has not shown them as chargeable income in its return. The company may instead declare them; the shareholder may then claim a refund (below).",
      "line": 66
    },
    {
      "actual_text": "| Malta | Exemption can give nil on both items if the defined equity/participating holding, property restrictions, non-deductible EU distribution and remaining anti-abuse conditions hold. EU residence meets one dividend limb, not every prerequisite. | https://legislation.mt/eli/cap/123/eng/pdf |",
      "line": 278
    }
  ],
  "short_exact_native_quotes": [
    "has not"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/01.txt",
  "source_key": "01",
  "source_sha256": "4ab01721e228a68e059199bd668492461f8dea9ccbe8b74d427ded4e135a20cb",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### MT-DIVIDEND-ALTERNATIVES

Dividend post2007/pre2007from2011: EU residence/incorporation OR15%foreign tax ORpassiveinterestroyalty<=50%;ifnone, BOTHnonportfolio AND5%specifiedforeign-tax route.

```json
{
  "act_article_or_scope": "Art12(1)(u)(1) dividend provisos(i)/(ii), whole",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "Dividend post2007/pre2007from2011: EU residence/incorporation OR15%foreign tax ORpassiveinterestroyalty<=50%;ifnone, BOTHnonportfolio AND5%specifiedforeign-tax route.",
  "id": "MT-DIVIDEND-ALTERNATIVES",
  "official_url": "https://legislation.mt/eli/cap/123/eng/pdf",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "- DIVIDEND CONDITIONS: for a dividend from a participating holding acquired on or after 1 January 2007 (and, from 1 January 2011, also one acquired before), the exemption applies only if the subsidiary meets ANY ONE of: resident or incorporated in the EU; subject to foreign tax of at least the 15% in the table; not more than 50% of its income from passive interest or royalties. If it meets none of these, BOTH of these must hold: the holding is not a portfolio investment, AND the subsidiary or its passive interest or royalties were subject to foreign tax of at least 5%.",
      "line": 67
    },
    {
      "actual_text": "| Dividend anti-abuse, limb (i)(2) | 15% | Apply the complete conditions in this country section; this value is not an unconditional bill. | https://legislation.mt/eli/cap/123/eng/pdf |",
      "line": 58
    },
    {
      "actual_text": "| Dividend anti-abuse, limb (i)(3) | 50% | Apply the complete conditions in this country section; this value is not an unconditional bill. | https://legislation.mt/eli/cap/123/eng/pdf |",
      "line": 59
    },
    {
      "actual_text": "| Dividend anti-abuse, limb (ii)(2) | 5% | Apply the complete conditions in this country section; this value is not an unconditional bill. | https://legislation.mt/eli/cap/123/eng/pdf |",
      "line": 60
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/01.txt",
  "source_key": "01",
  "source_sha256": "4ab01721e228a68e059199bd668492461f8dea9ccbe8b74d427ded4e135a20cb",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### MT-LIST-HYBRID

EUlisted3month threshold incl consecutive cross-basis-year application; exemption denied unless commensurate significant people functions proved. EU deductible distributed-profit exclusion separately applies.

```json
{
  "act_article_or_scope": "Art12(1)(u) final distribution/list provisos, whole through u(2) opening; pages84–85",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "EUlisted3month threshold incl consecutive cross-basis-year application; exemption denied unless commensurate significant people functions proved. EU deductible distributed-profit exclusion separately applies.",
  "id": "MT-LIST-HYBRID",
  "official_url": "https://legislation.mt/eli/cap/123/eng/pdf",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "- EXCLUSION: the exemption does not apply to income from a participating holding in a body resident in a jurisdiction on the EU list of non-cooperative jurisdictions for at least three months in the year before the year of assessment, unless the company proves commensurate sufficient significant people functions there to the Commissioner. Consecutive months straddling two basis years can disqualify either year. For covered EU parent-subsidiary distributions, the exemption is also denied to the extent the subsidiary can deduct the distributed profits (the final provisos to article 12(1)(u)).",
      "line": 68
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/01.txt",
  "source_key": "01",
  "source_sha256": "4ab01721e228a68e059199bd668492461f8dea9ccbe8b74d427ded4e135a20cb",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### MT-DOMESTIC-GAIN-BO

Malta-resident direct/indirect participations disposal requires gain would be exempt for beneficial owner under12cii;multipleBOshare allocation;nonresident exemption has actual property/ownership/control limits and later nonqualifying BO charge.

```json
{
  "act_article_or_scope": "Art12(1)(u)(1) domestic-interest provisos and12(1)(c)(ii)/(iii), all operative plus neighbours",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "Malta-resident direct/indirect participations disposal requires gain would be exempt for beneficial owner under12cii;multipleBOshare allocation;nonresident exemption has actual property/ownership/control limits and later nonqualifying BO charge.",
  "id": "MT-DOMESTIC-GAIN-BO",
  "official_url": "https://legislation.mt/eli/cap/123/eng/pdf",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "- GAINS: the dividend conditions above apply to dividends only. A separate proviso covers a participating holding \"in a company or in a partnership, EEIG, other body of persons or collective investment scheme ... that is resident in Malta\", and holdings that hold such interests directly or indirectly. Gains on those \"shall only qualify for the exemption if such gains or profits would have been exempt in terms of sub-paragraph (ii) of paragraph (c) had the transfer of the holding been made by the beneficial owner\". Article 12(1)(c)(ii) exempts gains of \"any person not resident in Malta\". Where there are several beneficial owners, the exemption applies only to the exempt owners' share.",
      "line": 69
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/01.txt",
  "source_key": "01",
  "source_sha256": "4ab01721e228a68e059199bd668492461f8dea9ccbe8b74d427ded4e135a20cb",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### MT-REFUND-REGISTRATION

Dividend-receiving shareholder registered as prescribed; returns/FSS/VATcompliance gates; actual-paid cap. Resident-individual exempt-dividend refund-bar interaction is explicitly held, not presumed paid.

```json
{
  "act_article_or_scope": "Cap372Art48(1) final bar/1A/1B/2 and48(4)/(4A), whole assigned paragraphs",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "Dividend-receiving shareholder registered as prescribed; returns/FSS/VATcompliance gates; actual-paid cap. Resident-individual exempt-dividend refund-bar interaction is explicitly held, not presumed paid.",
  "id": "MT-REFUND-REGISTRATION",
  "official_url": "https://legislation.mt/eli/cap/372/eng/pdf",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "- WHO claims: the shareholder who receives the dividend, and only once registered for the purpose (\"provided that such person is for such purpose registered in such manner as may be prescribed\").",
      "line": 78
    },
    {
      "actual_text": "- CAP: the refund never exceeds the tax the company actually paid on the profits distributed. The 2/3 route’s Malta-tax base can include the specified double-taxation relief, but its separate actual-paid cap still applies (article 48(4)(c)). The tax-return, FSS and VAT-return compliance gates in article 48(1A)–(1B) remain relevant; registration is not by itself a payment promise.",
      "line": 80
    },
    {
      "actual_text": "- NOT SETTLED for Malta-resident individuals: article 12(1)(c)(iii) of the [Income Tax Act](https://legislation.mt/eli/cap/123/eng/pdf) exempts some taxed-account dividends paid to individuals and ties that exemption to the refund bar in the last proviso to article 48(1) of Cap. 372. How that interacts with the article 48(4A) refund was not settled from the text. Refer before telling a Malta-resident individual shareholder to rely on a refund (see `mt-holding-company-participation-exemption`).",
      "line": 81
    }
  ],
  "short_exact_native_quotes": [
    "registered in such manner as may be prescribed"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/04.txt",
  "source_key": "04",
  "source_sha256": "199e2362cce9930b3a23ee2d4566cefaeb880e365027e2a4f667f48bc6a735f8",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### MT-REFUND-RATES

6/7ordinary,5/7passiveinterestroyalty or failingparticipation dividend;2/3FIA-DTR with specialtaxbase andactualpaidcap;100%qualifyingFIAparticipation matching dividend tests;DTRbars4A.

```json
{
  "act_article_or_scope": "Art48(4A)(a) standard/passive proviso;48(4)(a)–(c) and4A DTR bar",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "6/7ordinary,5/7passiveinterestroyalty or failingparticipation dividend;2/3FIA-DTR with specialtaxbase andactualpaidcap;100%qualifyingFIAparticipation matching dividend tests;DTRbars4A.",
  "id": "MT-REFUND-RATES",
  "official_url": "https://legislation.mt/eli/cap/372/eng/pdf",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "| Standard refund, article 48(4A)(a) | 6/7 | Apply the complete conditions in this country section; this value is not an unconditional bill. | https://legislation.mt/eli/cap/372/eng/pdf |",
      "line": 73
    },
    {
      "actual_text": "| Passive interest or royalties, or a participating holding dividend that fails the anti-abuse test | 5/7 | Apply the complete conditions in this country section; this value is not an unconditional bill. | https://legislation.mt/eli/cap/372/eng/pdf |",
      "line": 74
    },
    {
      "actual_text": "| Profits from a participating holding distributed out of the foreign income account, article 48(4)(b) | all of the Malta tax | Apply the complete conditions in this country section; this value is not an unconditional bill. | https://legislation.mt/eli/cap/372/eng/pdf |",
      "line": 75
    },
    {
      "actual_text": "| Foreign income account profits, article 48(4)(a) (the route where the company claimed double taxation relief, since article 48(4A) is then barred) | 2/3 | Apply the complete conditions in this country section; this value is not an unconditional bill. | https://legislation.mt/eli/cap/372/eng/pdf |",
      "line": 76
    },
    {
      "actual_text": "- NO REFUND under article 48(4A) on foreign income account profits where the company claimed double taxation relief; a two-thirds refund under article 48(4)(a) may then be claimed.",
      "line": 79
    },
    {
      "actual_text": "- The full refund under article 48(4)(b) for participating holding dividends carries the same anti-abuse conditions as the exemption.",
      "line": 82
    }
  ],
  "short_exact_native_quotes": [
    "refund of six-sevenths"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/04.txt",
  "source_key": "04",
  "source_sha256": "199e2362cce9930b3a23ee2d4566cefaeb880e365027e2a4f667f48bc6a735f8",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### MT-FINAL-ELECTION

YA2025onpriorfiscalyear;15%electivenotice;5yearsminimumin,5ordinaryafterout;dividend/final-income exclusions;floorordinarytaxminusallclaimed/claimablerefunds;nocredit/setoff/refund;finaltaxaccount.

```json
{
  "act_article_or_scope": "LN188/2025Regs1–3 all3pages",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "YA2025onpriorfiscalyear;15%electivenotice;5yearsminimumin,5ordinaryafterout;dividend/final-income exclusions;floorordinarytaxminusallclaimed/claimablerefunds;nocredit/setoff/refund;finaltaxaccount.",
  "id": "MT-FINAL-ELECTION",
  "official_url": "https://legislation.mt/eli/ln/2025/188/eng/pdf",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "Elective final tax. [L.N. 188 of 2025](https://legislation.mt/eli/ln/2025/188/eng/pdf), the Final Income Tax Without Imputation Regulations, lets an entity elect to be taxed \"at the rate of fifteen cents (0.15) on every euro of the chargeable income, in lieu of the rate determined in article 56(6)\". It applies to income of the fiscal year preceding year of assessment 2025 and later years. Once elected, the entity cannot switch back before the end of a five-year period, and after switching back the ordinary rules apply for at least five consecutive years of assessment. The election is made by notice in the form and by the date the Commissioner sets. The 15-cent tax \"shall be final and shall not be available as a credit or set off against the tax liability of any individual or entity, or as a refund to any person\" (reg. 3(4)(b)), so no shareholder refund follows it. It \"shall in no case be lower than\" the ordinary tax \"reduced by the amount of refund claimed or claimable in terms of article 48(4) or (4A)\" by all shareholders (reg. 3(4)(a)). The taxed profits go to the final tax account (reg. 3(4)(c)). Chargeable income under the election excludes dividends received from profits that are not \"allocated to the final tax account of another company registered in Malta\" and income already taxed at a final rate (reg. 3(1) proviso). These regulations are S.L. 123.217.",
      "line": 84
    }
  ],
  "short_exact_native_quotes": [
    "fifteen cents (0.15)"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/06.txt",
  "source_key": "06",
  "source_sha256": "afaf3945fc1dde5bbf155b2720ea120ef181c296172669d777a8feec4272f436",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### MT-UNTAXED-RECIPIENT

FIAonlytaxableprofits;untaxedresidualaccount;definedrecipientinclresidentnoncompanies/specifiedtrusteesEU/EEA/nonrescontrolledMTresidentdomiciled;15%untaxeddividendwithheld,exempt-personexception,14daymonthafterpayment;64ordinaryfinal/65optionaldeclarecredit/66nonrecipientnottaxed. Specific allocation/personalrefundheld.

```json
{
  "act_article_or_scope": "Art2FIA/final/untaxeddefinitions;Arts61–66whole and67neighbour",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "FIAonlytaxableprofits;untaxedresidualaccount;definedrecipientinclresidentnoncompanies/specifiedtrusteesEU/EEA/nonrescontrolledMTresidentdomiciled;15%untaxeddividendwithheld,exempt-personexception,14daymonthafterpayment;64ordinaryfinal/65optionaldeclarecredit/66nonrecipientnottaxed. Specific allocation/personalrefundheld.",
  "id": "MT-UNTAXED-RECIPIENT",
  "official_url": "https://legislation.mt/eli/cap/123/eng/pdf",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "A Malta company paying a dividend out of its untaxed account to a recipient must, on that payment, \"deduct therefrom tax at a rate of fifteen per cent.\" under article 62(1) of the [Income Tax Act](https://legislation.mt/eli/cap/123/eng/pdf). Article 61 also includes specified trustees and EU/EEA individuals. It defines a recipient as, among others, a person, other than a company, resident in \"Malta in the year in which a dividend is received by him or by any person on his behalf\", and \"a non-resident person (including a non-resident company) who is owned and controlled by, directly or indirectly, or who acts on behalf of, an individual who is ordinarily resident and domiciled in Malta\". The foreign income account holds profits only \"to the extent that they result from taxable income\"; the untaxed account is the residual distributable-profit account after other taxed accounts under article 2. Do not decide a specific exempt-participation distribution’s account allocation or the resident individual’s refund position without the full tax-account and shareholder computation; that individual execution question remains unconfirmed below. Article 62 excludes payments to exempt persons and requires payment to the Commissioner by the 14th day after the payment month. Under articles 64–65 the recipient can use the ordinary final treatment or elect to declare the dividend with a withholding credit; article 66 excludes a non-recipient from this untaxed-dividend charge. Taxed-account refunds remain conditional as above.",
      "line": 86
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/01.txt",
  "source_key": "01",
  "source_sha256": "4ab01721e228a68e059199bd668492461f8dea9ccbe8b74d427ded4e135a20cb",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### CY-RATE

Company15%currenttaxableincome;notlegacy12.5.

```json
{
  "act_article_or_scope": "Law118(I)/2002SecondSchedule2, current through67(I)/2026; actual1689",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "Company15%currenttaxableincome;notlegacy12.5.",
  "id": "CY-RATE",
  "official_url": "https://www.cylaw.org/nomoi/enop/non-ind/2002_1_118/full.html",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "Cyprus’s current Income Tax Law, Second Schedule paragraph 2, sets corporate income tax at 15%. Article 8(20) exempts dividend income, except to the extent a corporate recipient’s dividend is deductible in computing the payer’s foreign tax; that denied amount is not a dividend for SDC. Article 8(22) exempts gains on defined titles. Article 2 includes shares, debentures, bonds, founders’ and other corporate/legal-person titles and rights over them, for Cyprus and foreign issuers. These provisions do not impose a general minimum participation percentage or holding period. The retained text is the Cyprus Bar’s current statutory consolidation, not a government presentation or an opinion. [Income Tax Law 118(I)/2002, articles 2/8 and Second Schedule](https://www.cylaw.org/nomoi/enop/non-ind/2002_1_118/full.html)",
      "line": 90
    },
    {
      "actual_text": "| Corporate tax | 15% | Current Second Schedule paragraph 2; separate dividend/title exemptions and SDC apply | https://www.cylaw.org/nomoi/enop/non-ind/2002_1_118/full.html |",
      "line": 94
    }
  ],
  "short_exact_native_quotes": [
    "δεκαπέντε τοις εκατόν (15%)"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/33-native.txt",
  "source_key": "CY-IT",
  "source_sha256": "92c0a12b127c8904f1cad387fa52b295ddc0996d44e96e171009b17bf60670e3",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### CY-DIVIDEND-TITLES

Dividendincomeexempt exceptcorporatepayerforeigndeductionthennotSDCdividend;definedtitlegains exempt;no generalminimumsize/period imposed here. Statutorytitles+rights scope preserved;unrecoveredadministrativederivativeslistindividuallyheld.

```json
{
  "act_article_or_scope": "Art8(20)allprovisos/8(22) andArt2titlesdefinition; actual214/365–368/387",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "Dividendincomeexempt exceptcorporatepayerforeigndeductionthennotSDCdividend;definedtitlegains exempt;no generalminimumsize/period imposed here. Statutorytitles+rights scope preserved;unrecoveredadministrativederivativeslistindividuallyheld.",
  "id": "CY-DIVIDEND-TITLES",
  "official_url": "https://www.cylaw.org/nomoi/enop/non-ind/2002_1_118/full.html",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "Cyprus’s current Income Tax Law, Second Schedule paragraph 2, sets corporate income tax at 15%. Article 8(20) exempts dividend income, except to the extent a corporate recipient’s dividend is deductible in computing the payer’s foreign tax; that denied amount is not a dividend for SDC. Article 8(22) exempts gains on defined titles. Article 2 includes shares, debentures, bonds, founders’ and other corporate/legal-person titles and rights over them, for Cyprus and foreign issuers. These provisions do not impose a general minimum participation percentage or holding period. The retained text is the Cyprus Bar’s current statutory consolidation, not a government presentation or an opinion. [Income Tax Law 118(I)/2002, articles 2/8 and Second Schedule](https://www.cylaw.org/nomoi/enop/non-ind/2002_1_118/full.html)",
      "line": 90
    },
    {
      "actual_text": "- Cyprus titles: the actual statute covers defined titles and rights. The former detailed list of options, futures, swaps and collective-investment units was on an inaccessible Tax Department page; product-specific inclusion is not confirmed by that unavailable page. Classify the actual instrument before applying article 8(22).",
      "line": 452
    }
  ],
  "short_exact_native_quotes": [
    "εισόδημα από μερίσματα"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/33-native.txt",
  "source_key": "CY-IT",
  "source_sha256": "92c0a12b127c8904f1cad387fa52b295ddc0996d44e96e171009b17bf60670e3",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### CY-DOMICILE-LEGACY

Residentdomiciledindividual5%;legacyprofits<=2025dividendsreceivedwithin6years17%through2031;priorchargeddividendreductions;non-domseparatetest;anti-interposed-company commercialpurpose rule.

```json
{
  "act_article_or_scope": "Law117(I)/2002Arts2/3(1)(a)allnative116–124 andcurrentdefinitions",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "Residentdomiciledindividual5%;legacyprofits<=2025dividendsreceivedwithin6years17%through2031;priorchargeddividendreductions;non-domseparatetest;anti-interposed-company commercialpurpose rule.",
  "id": "CY-DOMICILE-LEGACY",
  "official_url": "https://www.cylaw.org/nomoi/enop/non-ind/2002_1_117/full.html",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "| Dividend SDC on a Cyprus-resident, domiciled individual | 5% | Current article 3(1)(a), subject to legacy-profit treatment and reductions for previously charged dividends | https://www.cylaw.org/nomoi/enop/non-ind/2002_1_117/full.html |",
      "line": 95
    },
    {
      "actual_text": "| Legacy dividends from a Cyprus company’s profits through 2025 | 17% | Received within the statutory 6-year window from the 2026 reform, through 31 December 2031; test the profit year and prior charges | https://www.cylaw.org/nomoi/enop/non-ind/2002_1_117/full.html |",
      "line": 96
    },
    {
      "actual_text": "For individuals, residence and domicile are separate tests; the non-dom regime is retained. The 5% dividend rate does not erase the 17% legacy-profit window. Article 3(1)(a) also counters artificial interposed companies. An exempt non-dom does not automatically prove exemption from every other Cyprus levy or residence obligation.",
      "line": 103
    }
  ],
  "short_exact_native_quotes": [
    "πέντε τοις εκατό (5%)"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/29-native.txt",
  "source_key": "CY-SDC",
  "source_sha256": "b0029645946faac564b1f688d110cfff6e2bece8a0741e3d24ab865d23958a51",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### CY-FOREIGN-DIVIDEND

Foreigndividend5%SDC residentcompany/CyprusPE if BOTH payerdirect/indirectinvestmentincomeactivities>50 AND foreignburden<halfCyprusburden;deductible-dividendreclassificationseparate.

```json
{
  "act_article_or_scope": "Art3(1)(c)whole with3(1)(b)/(d)neighbours",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "Foreigndividend5%SDC residentcompany/CyprusPE if BOTH payerdirect/indirectinvestmentincomeactivities>50 AND foreignburden<halfCyprusburden;deductible-dividendreclassificationseparate.",
  "id": "CY-FOREIGN-DIVIDEND",
  "official_url": "https://www.cylaw.org/nomoi/enop/non-ind/2002_1_117/full.html",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "| Foreign corporate dividend SDC | 5% | Article 3(1)(c): BOTH investment-income activities above 50% AND foreign burden below 50% of the Cyprus burden | https://www.cylaw.org/nomoi/enop/non-ind/2002_1_117/full.html |",
      "line": 97
    },
    {
      "actual_text": "For foreign dividends into a Cyprus holding company, article 3(1)(c)’s two conditions are cumulative: more than 50% of the payer’s direct or indirect activity must produce investment income AND the foreign tax burden must be lower than half the Cyprus burden. A corporate-tax exemption alone does not settle SDC.",
      "line": 105
    }
  ],
  "short_exact_native_quotes": [
    "σε ποσοστό πέντε τοις εκατό (5%)"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/29-native.txt",
  "source_key": "CY-SDC",
  "source_sha256": "b0029645946faac564b1f688d110cfff6e2bece8a0741e3d24ab865d23958a51",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### CY-CONNECTED-OUTBOUND

5%lowtaxthirdcountryvs17%noncooperativeprevails;actualresidence/incorporationalternativesAND>50connection3routes+connectedpersons. Regulated-marketreasonableknowledgeexception,antiabuse/commercialreason andqualifiedPEexceptions. Notblanketforeignwithholding.

```json
{
  "act_article_or_scope": "Art3(1)(d)(i)–(v)all+Art2jurisdictiondefs; native139–167",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "5%lowtaxthirdcountryvs17%noncooperativeprevails;actualresidence/incorporationalternativesAND>50connection3routes+connectedpersons. Regulated-marketreasonableknowledgeexception,antiabuse/commercialreason andqualifiedPEexceptions. Notblanketforeignwithholding.",
  "id": "CY-CONNECTED-OUTBOUND",
  "official_url": "https://www.cylaw.org/nomoi/enop/non-ind/2002_1_117/full.html",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "| Outbound to a connected low-tax-jurisdiction company | 5% | Article 3(1)(d): qualifying jurisdiction/incorporation route AND connected-company gate; exceptions below | https://www.cylaw.org/nomoi/enop/non-ind/2002_1_117/full.html |",
      "line": 98
    },
    {
      "actual_text": "| Outbound to a connected non-cooperative-jurisdiction company | 17% | Same article; non-cooperative rule prevails if both jurisdiction tests apply | https://www.cylaw.org/nomoi/enop/non-ind/2002_1_117/full.html |",
      "line": 99
    },
    {
      "actual_text": "For outbound corporate dividends, article 3(1)(d)(ii) requires the specified direct or indirect connection: the recipient in the payer, the payer in the recipient, or the same person and connected persons in both, with MORE than 50% of votes, capital or profits. Low-tax means a third-country corporate rate below half the Cyprus corporate rate; non-cooperative status uses the statutory EU-list definition. Incorporation/residence alternatives, the regulated-market reasonable-knowledge exception, anti-abuse rules and qualified permanent-establishment exceptions must be tested. These are not universal 5%/17% charges on every foreign company. [SDC Law 117(I)/2002, articles 2 and 3(1)(d)](https://www.cylaw.org/nomoi/enop/non-ind/2002_1_117/full.html)",
      "line": 107
    }
  ],
  "short_exact_native_quotes": [
    "δικαιοδοσία με χαμηλό φορολογικό συντελεστή"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/29-native.txt",
  "source_key": "CY-SDC",
  "source_sha256": "b0029645946faac564b1f688d110cfff6e2bece8a0741e3d24ab865d23958a51",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### CY-PROPERTY

Cypruspropertydirectcompanyshares separately;indirect20%FMVpropertyvalueignoringliabilities. IncometitleexemptiondoesnotcancelCGT;actualtreatyrequiresseparateread,universal50%treatypromisereserved.

```json
{
  "act_article_or_scope": "CGTLaw52/1980Art2property(i)–(iv)whole64–80,Art4chargewith3/5neighbours",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "Cypruspropertydirectcompanyshares separately;indirect20%FMVpropertyvalueignoringliabilities. IncometitleexemptiondoesnotcancelCGT;actualtreatyrequiresseparateread,universal50%treatypromisereserved.",
  "id": "CY-PROPERTY",
  "official_url": "https://www.cylaw.org/nomoi/enop/non-ind/1980_1_52/full.html",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "| Indirect property-rich shares for CGT | 20% of market value | CGT Law article 2: Cyprus immovable-property value, ignoring liabilities; direct property-holding shares have a separate limb | https://www.cylaw.org/nomoi/enop/non-ind/1980_1_52/full.html |",
      "line": 100
    },
    {
      "actual_text": "Property-rich shares: the separate CGT Law covers direct Cyprus property-holding shares and indirect shares where at least 20% of market value derives from Cyprus immovable property, without deducting liabilities. A corporate title exemption does not override that charge. Apply the actual treaty if relevant; the old unqualified 50% treaty statement is not a universal treaty rule and is held below. [CGT Law 52/1980, article 2](https://www.cylaw.org/nomoi/enop/non-ind/1980_1_52/full.html)",
      "line": 109
    },
    {
      "actual_text": "- Cyprus treaties: the old statement that a treaty with a 50% property-value threshold overrides the domestic 20% test is not a universal treaty promise. Identify the actual treaty, covered person, date and article before a treaty computation.",
      "line": 453
    }
  ],
  "short_exact_native_quotes": [
    "τουλάχιστον το είκοσι τοις εκατό (20%)"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/47-native.txt",
  "source_key": "47",
  "source_sha256": "2a1ceb1fdf5b3c96b919ad16c13020ac4a1d87060942fe2ef1b23be1fc031b17",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### CY-DEEMED-DISTRIBUTION

70%2024/2025accountingprofitsafterdefinedtax,2yearenddeemed17%;actualdividendsprofit-year/2yearreduce;onlydirect/indirectresidentindividualatdate;liquidation/restructuring/nonperformingloan/reorgexceptions;companyinitialpayercharge shareholder. No2026newprofitdeeming. Separate2024/25intercompany17%timing andpriorcharge/nonresident-attributionexceptions.

```json
{
  "act_article_or_scope": "CurrentArt3C(1)–(7)whole258–288 and3(1)(b)whole124–138",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "70%2024/2025accountingprofitsafterdefinedtax,2yearenddeemed17%;actualdividendsprofit-year/2yearreduce;onlydirect/indirectresidentindividualatdate;liquidation/restructuring/nonperformingloan/reorgexceptions;companyinitialpayercharge shareholder. No2026newprofitdeeming. Separate2024/25intercompany17%timing andpriorcharge/nonresident-attributionexceptions.",
  "id": "CY-DEEMED-DISTRIBUTION",
  "official_url": "https://www.cylaw.org/nomoi/enop/non-ind/2002_1_117/full.html",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "| Deemed distribution of 2024/2025 profits | 70% at 17% SDC | Article 3C: after corporate tax, at end of 2 years; reductions, resident-attribution and other exceptions below | https://www.cylaw.org/nomoi/enop/non-ind/2002_1_117/full.html |",
      "line": 101
    },
    {
      "actual_text": "Deemed distributions: article 3C applies to 70% of the defined 2024/2025 accounting profits after corporate tax at the end of 2 years, reduced by actual dividends paid in the profit year or that period. It applies only to profits attributable directly or indirectly to an individual resident in Cyprus at the deemed-distribution date, subject to the statutory exceptions and domicile rules. Specific liquidation, restructuring, debt-write-off and reorganisation conditions remain relevant; the company initially pays and charges the shareholder. The new provision does not extend deemed distribution to profits of 2026 onward. Transitional intercompany dividends from 2024/2025 profits and older indirect distributions have separate article 3(1)(b) rules; obtain the profit-year chain before computing.",
      "line": 111
    }
  ],
  "short_exact_native_quotes": [
    "εβδομήντα τοις εκατό (70%)"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/29-native.txt",
  "source_key": "CY-SDC",
  "source_sha256": "b0029645946faac564b1f688d110cfff6e2bece8a0741e3d24ab865d23958a51",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### IE-RATES

12.5%trading,25%nontradingandexceptedtrades;accountingperiodmax12months/apportionratechanges.

```json
{
  "act_article_or_scope": "Revenuebasisofchargewholeoperativecurrent16Oct2026",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "12.5%trading,25%nontradingandexceptedtrades;accountingperiodmax12months/apportionratechanges.",
  "id": "IE-RATES",
  "official_url": "https://www.revenue.ie/en/companies-and-charities/corporation-tax-for-companies/corporation-tax/basis-of-charge.aspx",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "| Trading income | 12.5% | Apply the complete conditions in this country section; this value is not an unconditional bill. | https://www.revenue.ie/en/companies-and-charities/corporation-tax-for-companies/corporation-tax/basis-of-charge.aspx |",
      "line": 117
    },
    {
      "actual_text": "| Non-trading income (rental, investment) and excepted trades | 25% | Apply the complete conditions in this country section; this value is not an unconditional bill. | https://www.revenue.ie/en/companies-and-charities/corporation-tax-for-companies/corporation-tax/basis-of-charge.aspx |",
      "line": 118
    }
  ],
  "short_exact_native_quotes": [
    "12.5%"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/11.txt",
  "source_key": "11",
  "source_sha256": "d6f872fdd794ef58bcc05dac969153236582aad5dbbc7447b4efc66e7338b1c1",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### IE-831B-PARENT-HOLDING

ParentIrishresidentorqualifiedEEAforeign-taxresident/notgenerallyexempt+CaseIII/138IV;5%ordinary/profits/assetsrights,direct/permittedindirectchain,notstock,continuous12monthscanfinishlater+returncorrection.

```json
{
  "act_article_or_scope": "TDM35-02-11March2026sections2/4, pp8–10/25–28whole",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "ParentIrishresidentorqualifiedEEAforeign-taxresident/notgenerallyexempt+CaseIII/138IV;5%ordinary/profits/assetsrights,direct/permittedindirectchain,notstock,continuous12monthscanfinishlater+returncorrection.",
  "id": "IE-831B-PARENT-HOLDING",
  "official_url": "https://www.revenue.ie/en/tax-professionals/tdm/income-tax-capital-gains-tax-corporation-tax/part-35/35-02-11.pdf",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "- Foreign distributions, section 831B: a parent must be Irish resident, or EEA-resident for the specified foreign tax and not generally exempt, and otherwise within Irish Case III or section 138 Case IV. A qualifying participation requires at least 5% of ordinary capital, distributable profits and winding-up assets, directly or through a permitted chain, continuously for at least 12 months including the distribution date. Trading-stock shares and impermissible intermediary chains do not count. The 12 months may finish after a distribution where the conditions are subsequently fulfilled; correct the return if the expectation fails.",
      "line": 124
    }
  ],
  "short_exact_native_quotes": [
    "12 months"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/41.txt",
  "source_key": "41",
  "source_sha256": "d5cabdc8a76fb8b7f5a089019350911788ed0eae1a2bbafba0c7875aa89d2efa",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### IE-831B-SUBSIDIARY

RelevantterritoryEEA/treatyinforceorsigned/notlisted;2026specifiednonEEAnontreatyWHTnominal>0FULLpaidnotrefunded;distributiondateforeignresidence/nongeneralexemption;lookbackIrishresidentORqualifiedforeignresident/nongeneralexempt3years2026vs5years2025/newlyincorporatedshorter;specifiedforeignnominaltaxnotgenerallyexempt/notPillarTwotopup;datecompanylawduepayablefacts.

```json
{
  "act_article_or_scope": "Sections3.1–3.3wholepp10–20, specifically3.2.3/3.2.4/3.2.6;actual294–706/706–1050",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "RelevantterritoryEEA/treatyinforceorsigned/notlisted;2026specifiednonEEAnontreatyWHTnominal>0FULLpaidnotrefunded;distributiondateforeignresidence/nongeneralexemption;lookbackIrishresidentORqualifiedforeignresident/nongeneralexempt3years2026vs5years2025/newlyincorporatedshorter;specifiedforeignnominaltaxnotgenerallyexempt/notPillarTwotopup;datecompanylawduepayablefacts.",
  "id": "IE-831B-SUBSIDIARY",
  "official_url": "https://www.revenue.ie/en/tax-professionals/tdm/income-tax-capital-gains-tax-corporation-tax/part-35/35-02-11.pdf",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "- The foreign subsidiary must be resident in a relevant territory and not generally exempt from the specified foreign tax on the distribution date. Throughout the relevant period it must instead have been either Irish resident OR resident for foreign tax in a relevant territory and not generally exempt from that tax. For distributions in 2025 the lookback was 5 years; from 1 January 2026 it is 3 years, or since incorporation/formation if later. EEA/treaty-in-force and signed-but-not-in-force territories qualify, subject to the listed-territory exclusion and the current statutory treaty rules. From 2026 a specified non-EEA/non-treaty territory can qualify only with its nominal cross-border withholding tax above 0%, actually paid on the FULL distribution and not refunded to any person. Pillar Two top-up tax is not that foreign corporate tax.",
      "line": 125
    }
  ],
  "short_exact_native_quotes": [
    "1 January 2026"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/41.txt",
  "source_key": "41",
  "source_sha256": "d5cabdc8a76fb8b7f5a089019350911788ed0eae1a2bbafba0c7875aa89d2efa",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### IE-831B-MA-HISTORY

2026relevantreference3yearsforexcludedbusinessacquisition/mergersandtransferorhistory;shareacquisitionnotbusiness;newtreatyretrospectiveperiodand831B9fallbackconditionsdistinct.

```json
{
  "act_article_or_scope": "Section3.3wholeand3.4,pp16–24",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "2026relevantreference3yearsforexcludedbusinessacquisition/mergersandtransferorhistory;shareacquisitionnotbusiness;newtreatyretrospectiveperiodand831B9fallbackconditionsdistinct.",
  "id": "IE-831B-MA-HISTORY",
  "official_url": "https://www.revenue.ie/en/tax-professionals/tdm/income-tax-capital-gains-tax-corporation-tax/part-35/35-02-11.pdf",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "- The 2026 reference period for excluded business acquisitions and formation through excluded mergers is also 3 years; examine the transferor/merging entities’ territory history, not just the current subsidiary address. A share acquisition alone is not the excluded business acquisition. Section 831B(9)’s treaty-residence fallback for a jurisdiction without a domestic residence concept has its own conditions.",
      "line": 126
    }
  ],
  "short_exact_native_quotes": [
    "3 years"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/41.txt",
  "source_key": "41",
  "source_sha256": "d5cabdc8a76fb8b7f5a089019350911788ed0eae1a2bbafba0c7875aa89d2efa",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### IE-831B-DISTRIBUTION

Incomeoutofprofits/assetswithsubsidiarycost+626Bhypotheticalassetdisposal;allsharecapitalreceiptsbutqualifyingordinaryrights;offshorefund/windingup/debt/interestequivalentsout;foreigndeductiblepartbar inclavailableunuseddeduction except2026specifiedclosecompanysurcharge;genuinecommercialtargetedantiavoid.

```json
{
  "act_article_or_scope": "Section5wholepp28–31and6whole31–32, neighbours",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "Incomeoutofprofits/assetswithsubsidiarycost+626Bhypotheticalassetdisposal;allsharecapitalreceiptsbutqualifyingordinaryrights;offshorefund/windingup/debt/interestequivalentsout;foreigndeductiblepartbar inclavailableunuseddeduction except2026specifiedclosecompanysurcharge;genuinecommercialtargetedantiavoid.",
  "id": "IE-831B-DISTRIBUTION",
  "official_url": "https://www.revenue.ie/en/tax-professionals/tdm/income-tax-capital-gains-tax-corporation-tax/part-35/35-02-11.pdf",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "- The receipt must be income, from the relevant subsidiary’s share capital, out of profits or out of assets at a cost to the subsidiary. An asset distribution additionally requires a hypothetical section 626B-exempt share disposal on that date. Offshore-fund distributions, winding-up distributions and specified debt/interest-equivalent receipts are excluded. Foreign deductibility normally excludes the deductible part, including a deduction available but unused; from 2026 the narrowly specified foreign close-company-surcharge deduction is excepted. Genuine commercial reasons and the targeted tax-advantage anti-avoidance test apply.",
      "line": 127
    }
  ],
  "short_exact_native_quotes": [
    "valid commercial reasons"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/41.txt",
  "source_key": "41",
  "source_sha256": "d5cabdc8a76fb8b7f5a089019350911788ed0eae1a2bbafba0c7875aa89d2efa",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### IE-831B-ELECTION

CT1allrelevantdistributionsallsubsidiariesaccountperiodannualchoice;noadditionalFTCexemptincome/priorcreditsnotforfeited;doesnotexemptunrelatedtrade/110/fund/lifebusiness.

```json
{
  "act_article_or_scope": "Section7wholepp32–33/8.1–8.3whole33;8.4/8.5onlyopeningneighbour",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "CT1allrelevantdistributionsallsubsidiariesaccountperiodannualchoice;noadditionalFTCexemptincome/priorcreditsnotforfeited;doesnotexemptunrelatedtrade/110/fund/lifebusiness.",
  "id": "IE-831B-ELECTION",
  "official_url": "https://www.revenue.ie/en/tax-professionals/tdm/income-tax-capital-gains-tax-corporation-tax/part-35/35-02-11.pdf",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "- Claim on Form CT1 for the accounting period. The election covers ALL relevant distributions from ALL relevant subsidiaries for that period, never selected dividends; it can change next period. There is no additional foreign-tax credit on the exempt distributions; prior unused credits are not automatically forfeited. This is not a blanket exemption for trading receipts, section 110 companies or collective investment/life-business income. [Revenue TDM 35-02-11, March 2026, sections 2–7; TCA 831B](https://www.revenue.ie/en/tax-professionals/tdm/income-tax-capital-gains-tax-corporation-tax/part-35/35-02-11.pdf)",
      "line": 128
    }
  ],
  "short_exact_native_quotes": [
    "all relevant subsidiaries"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/41.txt",
  "source_key": "41",
  "source_sha256": "d5cabdc8a76fb8b7f5a089019350911788ed0eae1a2bbafba0c7875aa89d2efa",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### IE-626B-GAIN

Real5%allcapital/profit/assetsrights12continuousmonthsparentatdisposalorwithin2years;EU/treatyinforceorsigned;wholly/mainlytrading>halfnetprofits/assets+facts;specifiedIrishland/mineral/exploration/life/627/otherbars/590andassetloadingantiavoid;liquidationpracticewrittenapproval.

```json
{
  "act_article_or_scope": "TDM20-01-14September2026all5pagessections1–4",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "Real5%allcapital/profit/assetsrights12continuousmonthsparentatdisposalorwithin2years;EU/treatyinforceorsigned;wholly/mainlytrading>halfnetprofits/assets+facts;specifiedIrishland/mineral/exploration/life/627/otherbars/590andassetloadingantiavoid;liquidationpracticewrittenapproval.",
  "id": "IE-626B-GAIN",
  "official_url": "https://www.revenue.ie/en/tax-professionals/tdm/income-tax-capital-gains-tax-corporation-tax/part-20/20-01-14.pdf",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "- Gains, [section 626B](https://www.revenue.ie/en/tax-professionals/tdm/income-tax-capital-gains-tax-corporation-tax/part-20/20-01-14.pdf): a gain on disposal of shares is not a chargeable gain where the investor company has held a \"real\" holding of at least 5 per cent for a continuous period of 12 months (the disposal must be while it is a parent or within 2 years after), the investee is resident in an EU state or a territory with an Irish treaty in force or signed but not yet in force, AND at the time of disposal the investee or the group is wholly or mainly (more than half) trading. The exemption excludes the specified Irish land/mineral/exploration-rights shares, life-business shares, section 627 deemed disposals and other listed disposals; anti-avoidance applies. The September 2026 manual’s liquidation trading concession requires written Revenue approval. “More than half trading” is assessed primarily using net trading profits and net trading assets, with other relevant factors; it is not simply a label on the company.",
      "line": 129
    }
  ],
  "short_exact_native_quotes": [
    "5 per cent"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/14.txt",
  "source_key": "14",
  "source_sha256": "7876f83ce07d4536419232c3dd6eab2e3504267ed1a05bf447dc9c836cb3d9f0",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### IE-DWT-RATE

OrdinaryIrishcompanyDWT25%subjecttospecificexemptions.

```json
{
  "act_article_or_scope": "RevenueDWTcurrent24Aug2026wholeoverview",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "OrdinaryIrishcompanyDWT25%subjecttospecificexemptions.",
  "id": "IE-DWT-RATE",
  "official_url": "https://www.revenue.ie/en/companies-and-charities/dividend-withholding-tax/index.aspx",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "| Dividend withholding tax (DWT), 2026 | 25% | Apply the complete conditions in this country section; this value is not an unconditional bill. | https://www.revenue.ie/en/companies-and-charities/dividend-withholding-tax/index.aspx |",
      "line": 122
    },
    {
      "actual_text": "- Outbound: Irish companies withhold DWT at the rate in the table. A [qualifying non-resident](https://www.revenue.ie/en/companies-and-charities/dividend-withholding-tax/exemptions-for-non-residents.aspx) can claim exemption by declaration (Form V2B for a company, V2A for an individual). For an individual this means not resident or ordinarily resident in Ireland and resident in an EU or EEA state or treaty country. For a company it includes one resident in such a territory that is not directly or indirectly controlled by an Irish resident. The exemption is not automatic; current outbound defensive measures also apply. Forms V2A and V2C require foreign tax-authority certification; provide the declaration to the company/AWA/QI. It lasts until 31 December of the fifth year following issue and must be renewed. Other corporate control/listed-shareholding categories exist; the company’s form is V2B, other bodies use V2C.",
      "line": 130
    }
  ],
  "short_exact_native_quotes": [
    "25%"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/43.txt",
  "source_key": "43",
  "source_sha256": "333074d8e377a63560349fb4f70b8a6fb502f7ab0e1c4924c9c875dcd3a1b217",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### IE-DWT-EXEMPTION

IndividualsnotIEresidentORordinarilyresidentandEU/EEA/treatyresident;qualifiedforeigncompanynotIrishcontrolorotherlisted/control/75%classes;V2A/V2Cforeigncertification,V2Bcompany;declarationpayer/AWA/QIthrough31Dec5thfollowingyearrenew;defensivemeasuresseparate.

```json
{
  "act_article_or_scope": "RevenueExemptionsfornonresidentswholeoperative24Aug2026",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "IndividualsnotIEresidentORordinarilyresidentandEU/EEA/treatyresident;qualifiedforeigncompanynotIrishcontrolorotherlisted/control/75%classes;V2A/V2Cforeigncertification,V2Bcompany;declarationpayer/AWA/QIthrough31Dec5thfollowingyearrenew;defensivemeasuresseparate.",
  "id": "IE-DWT-EXEMPTION",
  "official_url": "https://www.revenue.ie/en/companies-and-charities/dividend-withholding-tax/exemptions-for-non-residents.aspx",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "- Outbound: Irish companies withhold DWT at the rate in the table. A [qualifying non-resident](https://www.revenue.ie/en/companies-and-charities/dividend-withholding-tax/exemptions-for-non-residents.aspx) can claim exemption by declaration (Form V2B for a company, V2A for an individual). For an individual this means not resident or ordinarily resident in Ireland and resident in an EU or EEA state or treaty country. For a company it includes one resident in such a territory that is not directly or indirectly controlled by an Irish resident. The exemption is not automatic; current outbound defensive measures also apply. Forms V2A and V2C require foreign tax-authority certification; provide the declaration to the company/AWA/QI. It lasts until 31 December of the fifth year following issue and must be renewed. Other corporate control/listed-shareholding categories exist; the company’s form is V2B, other bodies use V2C.",
      "line": 130
    }
  ],
  "short_exact_native_quotes": [
    "V2A"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/15.txt",
  "source_key": "15",
  "source_sha256": "a4185d2c58f2e14ea609d8203dcf0b2d88d4bc383a770af76ac72a926437b9b4",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### IE-CLOSE-COMPANY

Controlled5orfewerparticipatorsorbydirectors,participatorrightsincludeincomecapital/useassets;Part13surchargesnotcomputed/individualreferralretained.

```json
{
  "act_article_or_scope": "Revenueclosecompanyoverviewwholecurrent16Oct2026",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "Controlled5orfewerparticipatorsorbydirectors,participatorrightsincludeincomecapital/useassets;Part13surchargesnotcomputed/individualreferralretained.",
  "id": "IE-CLOSE-COMPANY",
  "official_url": "https://www.revenue.ie/en/companies-and-charities/corporation-tax-for-companies/corporation-tax/close-companies.aspx",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "- A family-owned Irish company will often be a [close company](https://www.revenue.ie/en/companies-and-charities/corporation-tax-for-companies/corporation-tax/close-companies.aspx) (controlled by five or fewer participators, or by its directors). Part 13 of the Tax and Duty Manuals then applies; its rates are not printed within the stated source scopes.",
      "line": 131
    }
  ],
  "short_exact_native_quotes": [
    "five or fewer participators"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/16.txt",
  "source_key": "16",
  "source_sha256": "8106eedbd93bc0b7fe5c1309d74f857baea7f4d15c3cbb731a9386f69acf212d",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### LU-IRC-RATE

14%<=175k;24500+30%excess175k–200k;16%above200k. Guidequotesonlytopband,notuniversalbill.

```json
{
  "act_article_or_scope": "ACDtariffwholeoperative2025onward;LIR174 separatelyread",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "14%<=175k;24500+30%excess175k–200k;16%above200k. Guidequotesonlytopband,notuniversalbill.",
  "id": "LU-IRC-RATE",
  "official_url": "https://impotsdirects.public.lu/fr/az/t/tarif-applicable-collectivites/tarif-collect.html",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "| Corporate income tax (IRC), taxable income above EUR 200,000, from tax year 2025 | 16% | Apply the complete conditions in this country section; this value is not an unconditional bill. | https://impotsdirects.public.lu/fr/az/t/tarif-applicable-collectivites/tarif-collect.html |",
      "line": 137
    },
    {
      "actual_text": "- The 16% in the first table applies to taxable income above EUR 200,000 and is corporate income tax only. The combined figure is the authority's own example for a company seated in the commune of Luxembourg; other communes differ. The coordinated law text in force on 1 January 2026 carries the same 16% in article 174.",
      "line": 155
    },
    {
      "actual_text": "| Luxembourg | 16% above EUR 200,000 taxable income; 23.87% combined in Luxembourg City | 10% or EUR 1,200,000, held 12 months | 10% or EUR 6,000,000, held 12 months | 15% withholding | https://impotsdirects.public.lu/dam-assets/fr/legislation/LIR/texte-coordonn-en-vigueur-au-1er-janvier-2026-ver-08052026.pdf; https://impotsdirects.public.lu/fr/az/c/charg_fisc.html; https://data.legilux.public.lu/eli/etat/leg/rgd/2001/12/21/n5/consolide/20250101/fr/pdf |",
      "line": 39
    }
  ],
  "short_exact_native_quotes": [
    "16%"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/17.txt",
  "source_key": "17",
  "source_sha256": "e8e51fa13fb2d24375eada9c4214fab87719b0b6838d20becc6eee7e354077ed",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### LU-CITY-COMBINED

LuxCity23.87=16IRC+7%fundonIRC1.12+municipal6.75,notallcommunes;separateminimumwealthtaxnotCITminimum.

```json
{
  "act_article_or_scope": "ACDchargefiscalecollectiviteswhole2025table/notes65–135",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "LuxCity23.87=16IRC+7%fundonIRC1.12+municipal6.75,notallcommunes;separateminimumwealthtaxnotCITminimum.",
  "id": "LU-CITY-COMBINED",
  "official_url": "https://impotsdirects.public.lu/fr/az/c/charg_fisc.html",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "| Combined IRC, employment fund surcharge and municipal business tax, Luxembourg City, from 2025 | 23.87% | Apply the complete conditions in this country section; this value is not an unconditional bill. | https://impotsdirects.public.lu/fr/az/c/charg_fisc.html |",
      "line": 141
    },
    {
      "actual_text": "- The 16% in the first table applies to taxable income above EUR 200,000 and is corporate income tax only. The combined figure is the authority's own example for a company seated in the commune of Luxembourg; other communes differ. The coordinated law text in force on 1 January 2026 carries the same 16% in article 174.",
      "line": 155
    }
  ],
  "short_exact_native_quotes": [
    "23,87"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/18.txt",
  "source_key": "18",
  "source_sha256": "174a02e9ea4a733116fdf1d7e983be3415a733ed22ec39db16171b7b93dc0463",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### LU-DIVIDEND-ENTRY

Qualifiedfullytaxedcapitalcompany/PErecipientandDirective2011/96Article2class/statusEUorganism(notlocationonly)/fullytaxedresident/comparableforeignpayer;direct10%OR1.2m12moheld/commit;cost-onlyannualperparticipationoptout;failedperiodcorrectiveassessment. Documentaryconsolidationnotauthenticlawclaim.

```json
{
  "act_article_or_scope": "LIR166(1)–(2)whole+recipientannex10/currentcoordinated1Jan2026updated8May",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "Qualifiedfullytaxedcapitalcompany/PErecipientandDirective2011/96Article2class/statusEUorganism(notlocationonly)/fullytaxedresident/comparableforeignpayer;direct10%OR1.2m12moheld/commit;cost-onlyannualperparticipationoptout;failedperiodcorrectiveassessment. Documentaryconsolidationnotauthenticlawclaim.",
  "id": "LU-DIVIDEND-ENTRY",
  "official_url": "https://impotsdirects.public.lu/dam-assets/fr/legislation/LIR/texte-coordonn-en-vigueur-au-1er-janvier-2026-ver-08052026.pdf",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "| Dividend exemption: minimum holding | 10% | Apply the complete conditions in this country section; this value is not an unconditional bill. | https://impotsdirects.public.lu/fr/az/r/regi_soc.html |",
      "line": 145
    },
    {
      "actual_text": "| Dividend exemption: alternative acquisition price | EUR 1,200,000 | Apply the complete conditions in this country section; this value is not an unconditional bill. | https://impotsdirects.public.lu/fr/az/r/regi_soc.html |",
      "line": 146
    },
    {
      "actual_text": "- Dividend exemption (article 166 LIR): a fully taxable resident capital company, or a qualifying permanent establishment, holding directly a participation in a fully taxable resident company, a non-resident company fully subject to a tax corresponding to IRC, or an organism covered by article 2 of Directive 2011/96/EU (the applicable company-class, residence and tax-status conditions, not EU location alone), is exempt on the dividend where, on the date the income is made available, it holds or undertakes to hold the participation for an uninterrupted period of at least 12 months AND throughout that period the holding does not fall below 10% OR the acquisition price does not fall below the amount in the table. If the 12 months are not reached, the exemption is withdrawn by a corrective assessment. Article 166(2bis) denies deductible or non-genuine EU tax-advantage distributions; directly related expenses and distribution-linked write-downs are restricted. A cost-only dividend exemption can be waived annually per participation; specified exchanged holdings have a separate 5-year restriction.",
      "line": 156
    }
  ],
  "short_exact_native_quotes": [
    "1.200.000 euros"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/20.txt",
  "source_key": "20",
  "source_sha256": "791c341ec06682ca83c18dd53bfa84a9688f61bc253583f264fd33d5b7949ef3",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### LU-DIVIDEND-RESTRICTIONS

Deductible/non-genuineEUtaxadvantagedistributionsbar;transparentproportion;expense/write-downlimits;5yearexchangebar;12monthfailurecorrectiveassessment.

```json
{
  "act_article_or_scope": "LIR166(2bis)/(3)–(9), wholewith165/167neighbours",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "Deductible/non-genuineEUtaxadvantagedistributionsbar;transparentproportion;expense/write-downlimits;5yearexchangebar;12monthfailurecorrectiveassessment.",
  "id": "LU-DIVIDEND-RESTRICTIONS",
  "official_url": "https://impotsdirects.public.lu/dam-assets/fr/legislation/LIR/texte-coordonn-en-vigueur-au-1er-janvier-2026-ver-08052026.pdf",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "- Dividend exemption (article 166 LIR): a fully taxable resident capital company, or a qualifying permanent establishment, holding directly a participation in a fully taxable resident company, a non-resident company fully subject to a tax corresponding to IRC, or an organism covered by article 2 of Directive 2011/96/EU (the applicable company-class, residence and tax-status conditions, not EU location alone), is exempt on the dividend where, on the date the income is made available, it holds or undertakes to hold the participation for an uninterrupted period of at least 12 months AND throughout that period the holding does not fall below 10% OR the acquisition price does not fall below the amount in the table. If the 12 months are not reached, the exemption is withdrawn by a corrective assessment. Article 166(2bis) denies deductible or non-genuine EU tax-advantage distributions; directly related expenses and distribution-linked write-downs are restricted. A cost-only dividend exemption can be waived annually per participation; specified exchanged holdings have a separate 5-year restriction.",
      "line": 156
    }
  ],
  "short_exact_native_quotes": [
    "non authentique"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/20.txt",
  "source_key": "20",
  "source_sha256": "791c341ec06682ca83c18dd53bfa84a9688f61bc253583f264fd33d5b7949ef3",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### LU-GAIN-ENTRY

Qualified166recipient/payerclasses,direct10%OR6m12moheld/commit;transparentproportionalsecuritisationbar. Documentaryconsolidationexpressnonlegalvalue.

```json
{
  "act_article_or_scope": "RGD21Dec2001current1Jan2025Art1(1)wholeand2–3neighbours,all2pages",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "Qualified166recipient/payerclasses,direct10%OR6m12moheld/commit;transparentproportionalsecuritisationbar. Documentaryconsolidationexpressnonlegalvalue.",
  "id": "LU-GAIN-ENTRY",
  "official_url": "https://data.legilux.public.lu/eli/etat/leg/rgd/2001/12/21/n5/consolide/20250101/fr/pdf",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "| Gains exemption: alternative acquisition price | EUR 6,000,000 | Apply the complete conditions in this country section; this value is not an unconditional bill. | https://impotsdirects.public.lu/fr/az/r/regi_soc.html |",
      "line": 147
    },
    {
      "actual_text": "- Gains: under the 21 December 2001 regulation, article 1, the 10% OR EUR 6,000,000 alternative and 12-month held/committed period apply to the specified article 166 recipient and investee classes. Transparent holdings count proportionately; securitisation interests are excluded. Prior negative participation income or deducted impairment, including qualifying subsidiary receivables, can be recaptured. Rolled-over gains under articles 53/54 and a specified exchanged participation’s first 5 years can also restrict exemption. A cost-only exemption may be waived per participation and tax year under article 1(2a), with separate recapture tracking. [Actual consolidated regulation, articles 1–3](https://data.legilux.public.lu/eli/etat/leg/rgd/2001/12/21/n5/consolide/20250101/fr/pdf)",
      "line": 157
    }
  ],
  "short_exact_native_quotes": [
    "seuil de 10%"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/61.txt",
  "source_key": "61",
  "source_sha256": "a2e4301b4e84eb04759ab8c9b0003ed762135d4f2764b5aa4d85a41ed563ee0a",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### LU-GAIN-RECAPTURE

Algebraicpreviousnegativeincome/depreciationinclsubsidiaryreceivablecurrent/priorrecapture;cost-onlyannualparticipationwaiver+tracking;53/54rolloverandfirst5taxyearsexchangebar.

```json
{
  "act_article_or_scope": "Art1(2)/(2a)/(3)/(4)whole",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "Algebraicpreviousnegativeincome/depreciationinclsubsidiaryreceivablecurrent/priorrecapture;cost-onlyannualparticipationwaiver+tracking;53/54rolloverandfirst5taxyearsexchangebar.",
  "id": "LU-GAIN-RECAPTURE",
  "official_url": "https://data.legilux.public.lu/eli/etat/leg/rgd/2001/12/21/n5/consolide/20250101/fr/pdf",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "- Gains: under the 21 December 2001 regulation, article 1, the 10% OR EUR 6,000,000 alternative and 12-month held/committed period apply to the specified article 166 recipient and investee classes. Transparent holdings count proportionately; securitisation interests are excluded. Prior negative participation income or deducted impairment, including qualifying subsidiary receivables, can be recaptured. Rolled-over gains under articles 53/54 and a specified exchanged participation’s first 5 years can also restrict exemption. A cost-only exemption may be waived per participation and tax year under article 1(2a), with separate recapture tracking. [Actual consolidated regulation, articles 1–3](https://data.legilux.public.lu/eli/etat/leg/rgd/2001/12/21/n5/consolide/20250101/fr/pdf)",
      "line": 157
    }
  ],
  "short_exact_native_quotes": [
    "somme algébrique des revenus"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/61.txt",
  "source_key": "61",
  "source_sha256": "a2e4301b4e84eb04759ab8c9b0003ed762135d4f2764b5aa4d85a41ed563ee0a",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### LU-OUTBOUND

147specifiedqualifiedcorporate/public/PEclasses10%OR1.2m12moheld/commit+antiabuse;futurecommitment1494guarantee/procedure;withoutundertaking1494awithhold/thenrefundafterperiod+continuousholdingproof,subordinateimplementationheld;notindividualfamilymerelyshareholder.148ordinary15gross,17.65ifpayerbearstax;Guideuses15only.2017agency20obsolete.

```json
{
  "act_article_or_scope": "LIR147allwith146end/148all;149(1)–(6)actual8140–8173whole,especially4/4a andmaterialneighbours personallyread16Nov19:00UTC",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "147specifiedqualifiedcorporate/public/PEclasses10%OR1.2m12moheld/commit+antiabuse;futurecommitment1494guarantee/procedure;withoutundertaking1494awithhold/thenrefundafterperiod+continuousholdingproof,subordinateimplementationheld;notindividualfamilymerelyshareholder.148ordinary15gross,17.65ifpayerbearstax;Guideuses15only.2017agency20obsolete.",
  "id": "LU-OUTBOUND",
  "official_url": "https://impotsdirects.public.lu/dam-assets/fr/legislation/LIR/texte-coordonn-en-vigueur-au-1er-janvier-2026-ver-08052026.pdf",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "| Withholding tax rate on dividends, article 148 | 15% | Apply the complete conditions in this country section; this value is not an unconditional bill. | https://impotsdirects.public.lu/dam-assets/fr/legislation/LIR/texte-coordonn-en-vigueur-au-1er-janvier-2026-ver-08052026.pdf |",
      "line": 153
    },
    {
      "actual_text": "- Outbound: current LIR article 147 exempts only its specified qualifying corporate/public/PE recipients with direct 10% OR EUR 1,200,000 participation for a held/committed 12 months and the relevant anti-abuse conditions; the future-commitment route is subject to article 149(4)’s applicable guarantee/procedure conditions. Without an undertaking, article 149(4a) instead requires withholding and permits a later refund after proof of the period and continuing holding threshold; an individual family shareholder does not qualify merely because the payer is a holding company. Article 148’s ordinary withholding is 15% of gross income; treaty relief is separate. The authority's page states that a company paying an exempt participation dividend is, under certain conditions, exempt from withholding. That page (last updated 9 January 2017) prints an older withholding rate; the law in force on 1 January 2026 prints the rate in the last table. Use the law.",
      "line": 158
    }
  ],
  "short_exact_native_quotes": [
    "1.200.000 euros"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/20.txt",
  "source_key": "20",
  "source_sha256": "791c341ec06682ca83c18dd53bfa84a9688f61bc253583f264fd33d5b7949ef3",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### NL-RATES

19%upthrough200000,25.8%above;same2025/24doesnotchangeactual2026basis.

```json
{
  "act_article_or_scope": "2026ratechartwholeoperative",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "19%upthrough200000,25.8%above;same2025/24doesnotchangeactual2026basis.",
  "id": "NL-RATES",
  "official_url": "https://www.belastingdienst.nl/wps/wcm/connect/bldcontentnl/belastingdienst/zakelijk/winst/vennootschapsbelasting/tarieven_vennootschapsbelasting",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "| Band limit | EUR 200,000 | Apply the complete conditions in this country section; this value is not an unconditional bill. | https://www.belastingdienst.nl/wps/wcm/connect/bldcontentnl/belastingdienst/zakelijk/winst/vennootschapsbelasting/tarieven_vennootschapsbelasting |",
      "line": 164
    },
    {
      "actual_text": "| Rate up to and including the band limit | 19.0% | Apply the complete conditions in this country section; this value is not an unconditional bill. | https://www.belastingdienst.nl/wps/wcm/connect/bldcontentnl/belastingdienst/zakelijk/winst/vennootschapsbelasting/tarieven_vennootschapsbelasting |",
      "line": 165
    },
    {
      "actual_text": "| Rate above the band limit | 25.8% | Apply the complete conditions in this country section; this value is not an unconditional bill. | https://www.belastingdienst.nl/wps/wcm/connect/bldcontentnl/belastingdienst/zakelijk/winst/vennootschapsbelasting/tarieven_vennootschapsbelasting |",
      "line": 166
    }
  ],
  "short_exact_native_quotes": [
    "€ 200.000"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/21.txt",
  "source_key": "21",
  "source_sha256": "7807a30c2840f42c6f1524e97ce68a3211981b39db0c0f3a9c2e54d89e49ea9c",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### NL-PARTICIPATION

Ordinary5%basicroute;associated-body/profitcertificate/hybridloan/votingextensions;after>1year5%holds3yearcontinuationifbelow5;notgeneralabsolute5bar.

```json
{
  "act_article_or_scope": "Deelnemingenwholeoperative65–85",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "Ordinary5%basicroute;associated-body/profitcertificate/hybridloan/votingextensions;after>1year5%holds3yearcontinuationifbelow5;notgeneralabsolute5bar.",
  "id": "NL-PARTICIPATION",
  "official_url": "https://www.belastingdienst.nl/wps/wcm/connect/bldcontentnl/belastingdienst/zakelijk/winst/vennootschapsbelasting/deelnemingsvrijstelling/deelnemingen",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "| Participation: minimum holding | 5% | Apply the complete conditions in this country section; this value is not an unconditional bill. | https://www.belastingdienst.nl/wps/wcm/connect/bldcontentnl/belastingdienst/zakelijk/winst/vennootschapsbelasting/deelnemingsvrijstelling/deelnemingen |",
      "line": 170
    },
    {
      "actual_text": "- Participation exemption: where a participation exists (at least 5% of the paid-up nominal capital, among other routes on the page), profits from it are generally exempt. The basic ordinary-capital route starts at 5%, but statutory associated-body, profit-certificate and hybrid-loan extensions exist. Separately, a participation of at least 5% held for more than 1 year that falls below 5% keeps the exemption for 3 more years.",
      "line": 176
    }
  ],
  "short_exact_native_quotes": [
    "ten minste 5%"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/22.txt",
  "source_key": "22",
  "source_sha256": "1eee4168c0f9f0b8189e314293638db4634fb957214ee4e68a0affcf64089a75",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### NL-EXEMPTION

Participationprofits/gainsexemptandlosses/acquisitiondisposalcostsnondeductible;nonqualportfolioexcludedwithcreditmayapply;fiscalinvestmentinstitutionbar.

```json
{
  "act_article_or_scope": "Deelnemingsvrijstellingwholeoperative63–68",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "Participationprofits/gainsexemptandlosses/acquisitiondisposalcostsnondeductible;nonqualportfolioexcludedwithcreditmayapply;fiscalinvestmentinstitutionbar.",
  "id": "NL-EXEMPTION",
  "official_url": "https://www.belastingdienst.nl/wps/wcm/connect/bldcontentnl/belastingdienst/zakelijk/winst/vennootschapsbelasting/deelnemingsvrijstelling/deelnemingsvrijstelling",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "- The exemption \"is niet van toepassing op een niet-kwalificerende beleggingsdeelneming\"; participation credit (deelnemingsverrekening) may be available instead, subject to its conditions. Whether a participation is held as an investment \"hangt onder meer af van het oogmerk\"; a top holding company with a real management, policy or financing function for the group may not hold it as an investment. A participation whose assets are mostly holdings below 5%, or whose function is mostly group financing, is always a portfolio participation. See [Deelnemingsvrijstelling](https://www.belastingdienst.nl/wps/wcm/connect/bldcontentnl/belastingdienst/zakelijk/winst/vennootschapsbelasting/deelnemingsvrijstelling/deelnemingsvrijstelling) and [Wanneer is een deelneming een beleggingsdeelneming?](https://www.belastingdienst.nl/wps/wcm/connect/bldcontentnl/belastingdienst/zakelijk/winst/vennootschapsbelasting/deelnemingsvrijstelling/wanneer_is_een_deelneming_een_beleggingsdeelneming).",
      "line": 177
    },
    {
      "actual_text": "- Holding period: the agency’s basic 5% test does not state a general minimum period. This does not remove the separate more-than-1-year and 3-year continuation conditions. A fiscal investment institution cannot apply the participation exemption; acquisition/disposal costs are not deductible.",
      "line": 179
    }
  ],
  "short_exact_native_quotes": [
    "niet-kwalificerende beleggingsdeelneming"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/24.txt",
  "source_key": "24",
  "source_sha256": "5b9865599b40bdc7994b1a39820dce101c07e7d4f96693893ea14c10e2c19677",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### NL-PURPOSE

Investmentreturnpurposevsbusinessgroupmanagement/policy/financing;mostlysub5holdingsorgroupfinancingdeemedportfolio.

```json
{
  "act_article_or_scope": "Portfolioholdingpurposewholeoperative64–70",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "Investmentreturnpurposevsbusinessgroupmanagement/policy/financing;mostlysub5holdingsorgroupfinancingdeemedportfolio.",
  "id": "NL-PURPOSE",
  "official_url": "https://www.belastingdienst.nl/wps/wcm/connect/bldcontentnl/belastingdienst/zakelijk/winst/vennootschapsbelasting/deelnemingsvrijstelling/wanneer_is_een_deelneming_een_beleggingsdeelneming",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "- The exemption \"is niet van toepassing op een niet-kwalificerende beleggingsdeelneming\"; participation credit (deelnemingsverrekening) may be available instead, subject to its conditions. Whether a participation is held as an investment \"hangt onder meer af van het oogmerk\"; a top holding company with a real management, policy or financing function for the group may not hold it as an investment. A participation whose assets are mostly holdings below 5%, or whose function is mostly group financing, is always a portfolio participation. See [Deelnemingsvrijstelling](https://www.belastingdienst.nl/wps/wcm/connect/bldcontentnl/belastingdienst/zakelijk/winst/vennootschapsbelasting/deelnemingsvrijstelling/deelnemingsvrijstelling) and [Wanneer is een deelneming een beleggingsdeelneming?](https://www.belastingdienst.nl/wps/wcm/connect/bldcontentnl/belastingdienst/zakelijk/winst/vennootschapsbelasting/deelnemingsvrijstelling/wanneer_is_een_deelneming_een_beleggingsdeelneming).",
      "line": 177
    }
  ],
  "short_exact_native_quotes": [
    "oogmerk"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/25.txt",
  "source_key": "25",
  "source_sha256": "bab55a5fa8725324ee10a443cc89800cede16cb2cf459a487e9041d5d94615b5",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### NL-QUALIFYING-PORTFOLIO

Regardlesspurpose exemptionifrealDutch-comparabletaxORgenerally<halfassetslowtaxfree;10normallyrealtaxbutbasecomparison;specifiedlookthroughand90externalfundingexception.

```json
{
  "act_article_or_scope": "Wholeoperative63–78withtests/lastnegativeconclusion",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "Regardlesspurpose exemptionifrealDutch-comparabletaxORgenerally<halfassetslowtaxfree;10normallyrealtaxbutbasecomparison;specifiedlookthroughand90externalfundingexception.",
  "id": "NL-QUALIFYING-PORTFOLIO",
  "official_url": "https://www.belastingdienst.nl/wps/wcm/connect/bldcontentnl/belastingdienst/zakelijk/winst/vennootschapsbelasting/deelnemingsvrijstelling/kwalificerende_beleggingsdeelneming",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "- Qualifying portfolio exception: exemption can still apply irrespective of purpose if the subsidiary bears a real profit tax by Dutch standards OR its assets generally consist for less than half, directly/indirectly, of low-tax free investments. A 10% rate is normally real only with the Dutch-comparable base; a headline rate alone is insufficient. Underlying-asset, external-financing and active-business exceptions need their own facts. [Qualifying investment participation](https://www.belastingdienst.nl/wps/wcm/connect/bldcontentnl/belastingdienst/zakelijk/winst/vennootschapsbelasting/deelnemingsvrijstelling/kwalificerende_beleggingsdeelneming); [Low-tax free investments](https://www.belastingdienst.nl/wps/wcm/connect/bldcontentnl/belastingdienst/zakelijk/winst/vennootschapsbelasting/deelnemingsvrijstelling/laagbelaste_vrije_beleggingen)",
      "line": 178
    }
  ],
  "short_exact_native_quotes": [
    "Een tarief van 10%"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/63.txt",
  "source_key": "63",
  "source_sha256": "3aa5008ca69d80d4dd3bb33cd507871168f8a20ed684bda55df3dc0599967a68",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### NL-LOWTAX-ASSETS

Freeinvestmentnotreasonablyneededbusiness;realpropertynotfreeexceptinvestmentinstitution;passivegroupfunding/lettingdeemingwith90%externalfunding/businessconditions. Noheadlinerate-onlytest.

```json
{
  "act_article_or_scope": "Wholeoperative63–74",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "Freeinvestmentnotreasonablyneededbusiness;realpropertynotfreeexceptinvestmentinstitution;passivegroupfunding/lettingdeemingwith90%externalfunding/businessconditions. Noheadlinerate-onlytest.",
  "id": "NL-LOWTAX-ASSETS",
  "official_url": "https://www.belastingdienst.nl/wps/wcm/connect/bldcontentnl/belastingdienst/zakelijk/winst/vennootschapsbelasting/deelnemingsvrijstelling/laagbelaste_vrije_beleggingen",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "- Qualifying portfolio exception: exemption can still apply irrespective of purpose if the subsidiary bears a real profit tax by Dutch standards OR its assets generally consist for less than half, directly/indirectly, of low-tax free investments. A 10% rate is normally real only with the Dutch-comparable base; a headline rate alone is insufficient. Underlying-asset, external-financing and active-business exceptions need their own facts. [Qualifying investment participation](https://www.belastingdienst.nl/wps/wcm/connect/bldcontentnl/belastingdienst/zakelijk/winst/vennootschapsbelasting/deelnemingsvrijstelling/kwalificerende_beleggingsdeelneming); [Low-tax free investments](https://www.belastingdienst.nl/wps/wcm/connect/bldcontentnl/belastingdienst/zakelijk/winst/vennootschapsbelasting/deelnemingsvrijstelling/laagbelaste_vrije_beleggingen)",
      "line": 178
    }
  ],
  "short_exact_native_quotes": [
    "90%"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/64.txt",
  "source_key": "64",
  "source_sha256": "35c5c28effd7dd9af4481486f92561a3a090f7c74b456deb45e56710dd65df32",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### NL-OUTBOUND-BASE

15%usualportfolioindividualcharge;usuallydomesticcorporateparticipationwithholdingexemption;individualcreditseparate.

```json
{
  "act_article_or_scope": "Alsudividenduitkeertwholeoperative37–57",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "15%usualportfolioindividualcharge;usuallydomesticcorporateparticipationwithholdingexemption;individualcreditseparate.",
  "id": "NL-OUTBOUND-BASE",
  "official_url": "https://www.belastingdienst.nl/wps/wcm/connect/bldcontentnl/belastingdienst/zakelijk/winst/dividendbelasting/als_u_dividend_uitkeert/als_u_dividend_uitkeert",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "| Dividend tax rate | 15% | Apply the complete conditions in this country section; this value is not an unconditional bill. | https://www.belastingdienst.nl/wps/wcm/connect/bldcontentnl/belastingdienst/zakelijk/winst/dividendbelasting/als_u_dividend_uitkeert/als_u_dividend_uitkeert |",
      "line": 174
    },
    {
      "actual_text": "- Outbound to a Dutch resident individual: the paying company \"meestal\" withholds the rate in the table on a portfolio dividend.",
      "line": 180
    },
    {
      "actual_text": "- Outbound to a company: on a participation dividend (5% or more) to a Dutch company, the company usually applies the withholding exemption. To a company in a [country with which the Netherlands has a tax treaty](https://www.belastingdienst.nl/wps/wcm/connect/bldcontentnl/belastingdienst/zakelijk/winst/dividendbelasting/als_u_dividend_uitkeert/deelnemingsdividend-uitkeren-aan-aandeelhouder-buiten-nederland), the agency describes a withholding exemption where there is no abuse; report the exempt foreign participation dividend with an opgaaf. Do not turn that abbreviated agency route into a complete exclusion of every other statutory exemption. If a lower treaty rate is used instead, the agency requires prior permission; reporting and the actual recipient conditions still apply.",
      "line": 181
    }
  ],
  "short_exact_native_quotes": [
    "15%"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/23.txt",
  "source_key": "23",
  "source_sha256": "43a867caf75b8631acc0572a44c5dd8ca88d26ad118abc2dfa1ca8c6c64c0b8f",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### NL-OUTBOUND-FOREIGN

Agencytreaty/noabuseexemptionroutewithopgaaf;priorpermitfortreatyreducedrate;abbreviatedagencyroutedoesnotexcludeeveryotherstatutoryroute.

```json
{
  "act_article_or_scope": "Foreignparticipationdividendwholeoperative38–71",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "Agencytreaty/noabuseexemptionroutewithopgaaf;priorpermitfortreatyreducedrate;abbreviatedagencyroutedoesnotexcludeeveryotherstatutoryroute.",
  "id": "NL-OUTBOUND-FOREIGN",
  "official_url": "https://www.belastingdienst.nl/wps/wcm/connect/bldcontentnl/belastingdienst/zakelijk/winst/dividendbelasting/als_u_dividend_uitkeert/deelnemingsdividend-uitkeren-aan-aandeelhouder-buiten-nederland",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "- Outbound to a company: on a participation dividend (5% or more) to a Dutch company, the company usually applies the withholding exemption. To a company in a [country with which the Netherlands has a tax treaty](https://www.belastingdienst.nl/wps/wcm/connect/bldcontentnl/belastingdienst/zakelijk/winst/dividendbelasting/als_u_dividend_uitkeert/deelnemingsdividend-uitkeren-aan-aandeelhouder-buiten-nederland), the agency describes a withholding exemption where there is no abuse; report the exempt foreign participation dividend with an opgaaf. Do not turn that abbreviated agency route into a complete exclusion of every other statutory exemption. If a lower treaty rate is used instead, the agency requires prior permission; reporting and the actual recipient conditions still apply.",
      "line": 181
    }
  ],
  "short_exact_native_quotes": [
    "geen sprake van misbruik"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/26.txt",
  "source_key": "26",
  "source_sha256": "7893b1cb3f0d9eaf7b6c2ffb1b8b1bccc7bc1a78f6ba2a50247701df71210666",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### CH-RATE

Federal8.5netprofitnotcombinednationaltax;cantonal/communaloutsidecomputation.

```json
{
  "act_article_or_scope": "DBG68whole;67/69neighbours,current1Jan2026",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "Federal8.5netprofitnotcombinednationaltax;cantonal/communaloutsidecomputation.",
  "id": "CH-RATE",
  "official_url": "https://www.fedlex.admin.ch/filestore/fedlex.data.admin.ch/eli/cc/1991/1184_1184_1184/20260101/de/pdf-a/fedlex-data-admin-ch-eli-cc-1991-1184_1184_1184-20260101-de-pdf-a.pdf",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "- Rate, article 68: The federal company/cooperative profit tax is 8.5% of net profit. This is the federal tax only. Cantonal and communal profit taxes come on top and are not covered by this Guide.",
      "line": 192
    }
  ],
  "short_exact_native_quotes": [
    "8,5 Prozent"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/28.txt",
  "source_key": "28",
  "source_sha256": "9fb0308ce1e6ca1b74abb702b24e27094bafe178ecf6533c4c7690132dd63109",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### CH-PARTICIPATION

TaxreductionratioNETparticipationincome/totalnetprofit,notfullreceipt exemption;10capitalOR10profitreservesOR1mFMV.

```json
{
  "act_article_or_scope": "DBG69whole",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "TaxreductionratioNETparticipationincome/totalnetprofit,notfullreceipt exemption;10capitalOR10profitreservesOR1mFMV.",
  "id": "CH-PARTICIPATION",
  "official_url": "https://www.fedlex.admin.ch/filestore/fedlex.data.admin.ch/eli/cc/1991/1184_1184_1184/20260101/de/pdf-a/fedlex-data-admin-ch-eli-cc-1991-1184_1184_1184-20260101-de-pdf-a.pdf",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "- Participation reduction, article 69: the federal profit tax is REDUCED in the ratio of net participation income to total net profit (it is not an exemption) where the company holds at least 10% of capital OR at least 10% of profits and reserves of another company, OR holds participation rights with a market value of at least one million francs.",
      "line": 193
    }
  ],
  "short_exact_native_quotes": [
    "mindestens 10 Prozent"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/28.txt",
  "source_key": "28",
  "source_sha256": "9fb0308ce1e6ca1b74abb702b24e27094bafe178ecf6533c4c7690132dd63109",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### CH-NET-RESTRICTIONS

Financing+5adminorprovedactualreduceparticipationnet;relatedwrite-down/payerdeductible/revaluationexclude;unjustifiedintragroupsavingsadjust;specialsystemicbankruleoutsidecase.

```json
{
  "act_article_or_scope": "DBG70(1)–(3)/(5)/(6)whole",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "Financing+5adminorprovedactualreduceparticipationnet;relatedwrite-down/payerdeductible/revaluationexclude;unjustifiedintragroupsavingsadjust;specialsystemicbankruleoutsidecase.",
  "id": "CH-NET-RESTRICTIONS",
  "official_url": "https://www.fedlex.admin.ch/filestore/fedlex.data.admin.ch/eli/cc/1991/1184_1184_1184/20260101/de/pdf-a/fedlex-data-admin-ch-eli-cc-1991-1184_1184_1184-20260101-de-pdf-a.pdf",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "- Net income, article 70: participation income less related financing costs and a flat contribution of 5% for administration (or actual administrative costs if proved). Write-downs linked to the income reduce the relief. Income deductible as an expense by the payer and participation revaluation gains are excluded; unjustified intra-group tax savings can cause an adjustment.",
      "line": 194
    }
  ],
  "short_exact_native_quotes": [
    "5 Prozent"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/28.txt",
  "source_key": "28",
  "source_sha256": "9fb0308ce1e6ca1b74abb702b24e27094bafe178ecf6533c4c7690132dd63109",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### CH-GAIN

Onlyproceedsabovecost,10%capital/profitreserveAND1year;afterbelow10latergainsneed1mFMVpriorYE.

```json
{
  "act_article_or_scope": "DBG70(4)whole",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "Onlyproceedsabovecost,10%capital/profitreserveAND1year;afterbelow10latergainsneed1mFMVpriorYE.",
  "id": "CH-GAIN",
  "official_url": "https://www.fedlex.admin.ch/filestore/fedlex.data.admin.ch/eli/cc/1991/1184_1184_1184/20260101/de/pdf-a/fedlex-data-admin-ch-eli-cc-1991-1184_1184_1184-20260101-de-pdf-a.pdf",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "- Gains, article 70(4): count only to the extent the sale price exceeds cost, AND only if the holding sold was at least 10% of capital or of profits and reserves AND was held for at least one year. After a part sale takes the holding below 10%, later sales qualify only if the holding had a market value of at least one million francs at the end of the tax year before the sale.",
      "line": 195
    }
  ],
  "short_exact_native_quotes": [
    "Gestehungskosten übersteigt"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/28.txt",
  "source_key": "28",
  "source_sha256": "9fb0308ce1e6ca1b74abb702b24e27094bafe178ecf6533c4c7690132dd63109",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### CH-WHT

35%capitalincome;Swissindividualdeclareassets+income/companybookincome;3yearendclaimdeadlineandantiavoidancebar;foreignqualifiedtreatyclaimconditional.

```json
{
  "act_article_or_scope": "ESTVVerrechnungssteuerwholeoperative44–63",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "35%capitalincome;Swissindividualdeclareassets+income/companybookincome;3yearendclaimdeadlineandantiavoidancebar;foreignqualifiedtreatyclaimconditional.",
  "id": "CH-WHT",
  "official_url": "https://www.estv.admin.ch/estv/de/home/verrechnungssteuer.html",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "| Withholding tax (Verrechnungssteuer) on investment income | 35% | Apply the complete conditions in this country section; this value is not an unconditional bill. | https://www.estv.admin.ch/estv/de/home/verrechnungssteuer.html |",
      "line": 188
    },
    {
      "actual_text": "- Outbound: the withholding tax in the table is charged on dividends. For a Swiss-resident recipient relief requires correct declaration of the assets and income, or company booking of the income. Apply within 3 years after the end of the calendar year in which the taxable payment fell due, and test the anti-avoidance bar. For others, treaty relief applies on a qualifying claim. The treaty rates are not printed on the page read.",
      "line": 196
    }
  ],
  "short_exact_native_quotes": [
    "35 %"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/27.txt",
  "source_key": "27",
  "source_sha256": "34cf8f281b5867a5fb2b61074f566c0367ab86224bf0c2a34d8409a02f5c1801",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### SG-RATE

17%headlinebeforeseparaterebate/exemptions/minimumtax,notnetbill.

```json
{
  "act_article_or_scope": "IRASCITratecurrentwhole990–1009",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "17%headlinebeforeseparaterebate/exemptions/minimumtax,notnetbill.",
  "id": "SG-RATE",
  "official_url": "https://www.iras.gov.sg/taxes/corporate-income-tax/basics-of-corporate-income-tax/corporate-income-tax-rate-rebates-and-tax-exemption-schemes",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "| Corporate income tax rate | 17% | Apply the complete conditions in this country section; this value is not an unconditional bill. | https://www.iras.gov.sg/taxes/corporate-income-tax/basics-of-corporate-income-tax/corporate-income-tax-rate-rebates-and-tax-exemption-schemes |",
      "line": 202
    }
  ],
  "short_exact_native_quotes": [
    "17%"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/29.txt",
  "source_key": "29",
  "source_sha256": "4cace0f06b695b1d16e842016632d78d9118acff5edf3e76d6771ff97e86c4f7",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### SG-ONE-TIER

Singapore-residentcompanyone-tierdividendnotshareholdertaxexceptcooperative;foreignindividual/REITexceptionsnotborrowedintoholdingcorporateFSIE.

```json
{
  "act_article_or_scope": "IRASdividendswholeoperative1000–1047",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "Singapore-residentcompanyone-tierdividendnotshareholdertaxexceptcooperative;foreignindividual/REITexceptionsnotborrowedintoholdingcorporateFSIE.",
  "id": "SG-ONE-TIER",
  "official_url": "https://www.iras.gov.sg/taxes/individual-income-tax/basics-of-individual-income-tax/what-is-taxable-what-is-not/dividends",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "- Singapore dividends: under the one-tier system, dividends paid by a Singapore resident company are not taxable in the shareholder's hands (\"as the tax paid by a company is final\"), except dividends from co-operatives ([IRAS dividends page](https://www.iras.gov.sg/taxes/individual-income-tax/basics-of-individual-income-tax/what-is-taxable-what-is-not/dividends)).",
      "line": 212
    }
  ],
  "short_exact_native_quotes": [
    "as the tax paid by a company is final"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/31.txt",
  "source_key": "31",
  "source_sha256": "8b467a9357b8f7a95a8d26daca7f4883ded5dc7eebb47c6c2ff65eb9d7dc6ce1",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### SG-FSIE-THREE-GATES

ResidentcompanyforeigndividendreceivedSG;remit/businessdebt/movableimport;ALLsubjecttotax/15headlineinreceiptyear/beneficialCIT;underlyingpaidpayable/incentiveandcustodyexceptionsbounded;consistentdocumentmethod/returndeclarationsrecords.

```json
{
  "act_article_or_scope": "IRASFSIE5thed30Jan2026sections5–9allpp4–10with8.2tableandfootnotes",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "ResidentcompanyforeigndividendreceivedSG;remit/businessdebt/movableimport;ALLsubjecttotax/15headlineinreceiptyear/beneficialCIT;underlyingpaidpayable/incentiveandcustodyexceptionsbounded;consistentdocumentmethod/returndeclarationsrecords.",
  "id": "SG-FSIE-THREE-GATES",
  "official_url": "https://www.iras.gov.sg/media/docs/default-source/e-tax/tax-exemption-for-foreign-sourced-income285e5d43d6af4001b3ce35da1e9005b5.pdf",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "| Foreign headline tax rate condition | 15% | Apply the complete conditions in this country section; this value is not an unconditional bill. | https://www.iras.gov.sg/media/docs/default-source/e-tax/tax-exemption-for-foreign-sourced-income285e5d43d6af4001b3ce35da1e9005b5.pdf |",
      "line": 206
    },
    {
      "actual_text": "- Foreign dividends received in Singapore by a resident company are exempt only if ALL three conditions hold: the income was subject to tax abroad; the foreign headline corporate rate is at least the 15% in the table when the income is received; AND the Comptroller is satisfied the exemption benefits the company. Foreign income can be received by remittance, paying a Singapore-business debt, or buying movable property brought into Singapore. For dividends, subject-to-tax includes qualifying underlying tax paid/payable, with the agency’s limited substantive-business incentive and custody conditions; a high headline rate alone is insufficient. The rate is the source country’s highest relevant rate in the receipt year, with the special-legislation qualification. Declare the qualifying income and retain the supporting documents; section 13(7A)–(11) and the January 2026 FSIE guide control.",
      "line": 213
    }
  ],
  "short_exact_native_quotes": [
    "Subject to tax"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/30.txt",
  "source_key": "30",
  "source_sha256": "61f04502bf991b47601a1ecdd6d9c0901791b0f5795fd73de49a8e833c25bf67",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### SG-13W-OWNERSHIP

2026ordinary+equityqualifiedpreferences,totalpaidup20%24continuousmonths;group>50beneficialordinarylinks/commonparent+specificsharescontinuousFIFO;RBT/VCCgrouproutebar,section26divestingbar;returnelectionrecords.

```json
{
  "act_article_or_scope": "IRAS4thed30Sep2025sections5.2–7allpp3–10",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "2026ordinary+equityqualifiedpreferences,totalpaidup20%24continuousmonths;group>50beneficialordinarylinks/commonparent+specificsharescontinuousFIFO;RBT/VCCgrouproutebar,section26divestingbar;returnelectionrecords.",
  "id": "SG-13W-OWNERSHIP",
  "official_url": "https://www.iras.gov.sg/docs/default-source/e-tax/etaxguide_certainty-of-non-taxation-of-companies-gain-on-disposal-of-equity-investments.pdf?sfvrsn=ceb9a99_18",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "| Section 13W minimum shareholding | 20% | Apply the complete conditions in this country section; this value is not an unconditional bill. | https://www.iras.gov.sg/docs/default-source/e-tax/etaxguide_certainty-of-non-taxation-of-companies-gain-on-disposal-of-equity-investments.pdf?sfvrsn=ceb9a99_18 |",
      "line": 210
    },
    {
      "actual_text": "- Gains, section 13W: for disposals from 1 January 2026, gains on ordinary shares and/or qualifying preference shares are not taxable if the divesting company held at least the 20% in the table for a continuous period of at least 24 months immediately before the disposal; for 2026 the threshold concerns the total paid-up capital of ordinary and equity-accounted qualifying preference shares. Group assessment requires the specified more-than-50% beneficial ordinary-share connections or common corporate parent, the continuously held shares throughout the 24 months, and FIFO tracking. RBTs/VCCs cannot use the group basis. Section 26 divesting companies are excluded; supply the election information in the income-tax return and keep records. The scheme does not apply to non-listed shares in a company that trades immovable property, or whose principal activity is holding immovable property whereby passive or no income is derived (Singapore or elsewhere, for disposals from 1 June 2022), or a company that \"has undertaken property development activities (in Singapore or elsewhere)\", unless it uses the property in its own trade and did no development in the past 60 months. A gain outside section 13W is not automatically taxable; ordinary income/capital analysis and section 10L must both be considered.",
      "line": 214
    }
  ],
  "short_exact_native_quotes": [
    "20%"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/03.txt",
  "source_key": "03",
  "source_sha256": "77f406ddb532688d75bce0049005d3ec40acb4a58cc14927973f937c4c2f8059",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### SG-13W-PROPERTY

Nonlistedpropertytrading/passiveholding/developingexcluded;developmentown-tradeexceptionANDnodevelopment60months;outside13Wnotautomaticallytaxable,10Loverrideadjacent.

```json
{
  "act_article_or_scope": "Section6all/7–8wholewith5.2.7neighbours",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "Nonlistedpropertytrading/passiveholding/developingexcluded;developmentown-tradeexceptionANDnodevelopment60months;outside13Wnotautomaticallytaxable,10Loverrideadjacent.",
  "id": "SG-13W-PROPERTY",
  "official_url": "https://www.iras.gov.sg/docs/default-source/e-tax/etaxguide_certainty-of-non-taxation-of-companies-gain-on-disposal-of-equity-investments.pdf?sfvrsn=ceb9a99_18",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "- Gains, section 13W: for disposals from 1 January 2026, gains on ordinary shares and/or qualifying preference shares are not taxable if the divesting company held at least the 20% in the table for a continuous period of at least 24 months immediately before the disposal; for 2026 the threshold concerns the total paid-up capital of ordinary and equity-accounted qualifying preference shares. Group assessment requires the specified more-than-50% beneficial ordinary-share connections or common corporate parent, the continuously held shares throughout the 24 months, and FIFO tracking. RBTs/VCCs cannot use the group basis. Section 26 divesting companies are excluded; supply the election information in the income-tax return and keep records. The scheme does not apply to non-listed shares in a company that trades immovable property, or whose principal activity is holding immovable property whereby passive or no income is derived (Singapore or elsewhere, for disposals from 1 June 2022), or a company that \"has undertaken property development activities (in Singapore or elsewhere)\", unless it uses the property in its own trade and did no development in the past 60 months. A gain outside section 13W is not automatically taxable; ordinary income/capital analysis and section 10L must both be considered.",
      "line": 214
    }
  ],
  "short_exact_native_quotes": [
    "60 months"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/03.txt",
  "source_key": "03",
  "source_sha256": "77f406ddb532688d75bce0049005d3ec40acb4a58cc14927973f937c4c2f8059",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### SG-10L

Foreignassets>=1Jan2024disposalreceivedSGcoveredrelevantgroupcanoverridecapital/exempt13W;groupforeignentity/place/consolidationfacts;pureequityfilingSGmanagedadequatepeoplepremises,nomineesecretaryaddressalonefails;otherentities/outsource/SPVconditions;IPseparateuncomputed.

```json
{
  "act_article_or_scope": "IRAS3rded6June2025wholepp1–12sections1–8.18;notIPsection9orcomputationlater",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "Foreignassets>=1Jan2024disposalreceivedSGcoveredrelevantgroupcanoverridecapital/exempt13W;groupforeignentity/place/consolidationfacts;pureequityfilingSGmanagedadequatepeoplepremises,nomineesecretaryaddressalonefails;otherentities/outsource/SPVconditions;IPseparateuncomputed.",
  "id": "SG-10L",
  "official_url": "https://www.iras.gov.sg/docs/default-source/e-tax/tax-treatment-of-gains-or-losses-from-the-sale-of-foreign-assets.pdf?sfvrsn=a0e0458b_15",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "- Foreign-disposal override: section 10L can tax otherwise capital or exempt foreign disposal gains, including section 13W gains, from disposals on or after 1 January 2024 when received in Singapore by a covered relevant-group entity. A group’s foreign entity or foreign place of business, consolidation and the particular recipient matter. For a pure equity-holding entity, the non-IP exception requires regular legal filings, operations managed/performed in Singapore and adequate Singapore human resources/premises in the disposal period. A nominee director or unused registered address alone is insufficient. Non-pure entities, outsourcing and SPVs have separately defined conditions; foreign IP has different rules. No economic-substance result is inferred from a 30% holding alone. [IRAS foreign-assets guide, June 2025, sections 2–8](https://www.iras.gov.sg/docs/default-source/e-tax/tax-treatment-of-gains-or-losses-from-the-sale-of-foreign-assets.pdf?sfvrsn=a0e0458b_15)",
      "line": 216
    }
  ],
  "short_exact_native_quotes": [
    "1 January 2024"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/54.txt",
  "source_key": "54",
  "source_sha256": "554eac4a456dc24d7c8686b286741d2c1d3ea2ac3ce116042d87a551e013e87b",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### AE-ORDINARY-BANDS

CD116ordinary0/9bands375000combinedallbusinesses+antiartificialfragmentation;unofficialEnglishCD116actualreadandArabicMoFcorroboration,currentFDL3ordinarynotQFZP/topup.

```json
{
  "act_article_or_scope": "MoF1Feb2023actualArabicrelease349–361;CD116whole1–5Englishownactualreuse;FDL47Arabic3(1–2)p7",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "CD116ordinary0/9bands375000combinedallbusinesses+antiartificialfragmentation;unofficialEnglishCD116actualreadandArabicMoFcorroboration,currentFDL3ordinarynotQFZP/topup.",
  "id": "AE-ORDINARY-BANDS",
  "official_url": "https://mof.gov.ae/ar/news/ministry-of-finance-confirms-applicable-taxable-income-threshold-for-corporate-tax-abu-dhabi-uae/",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "| Rate on taxable income up to the threshold | 0% | Apply the complete conditions in this country section; this value is not an unconditional bill. | https://tax.gov.ae/Datafolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%20No.%20116%20of%202022%20-%20for%20publishing.pdf |",
      "line": 222
    },
    {
      "actual_text": "| Threshold | AED 375,000 | Apply the complete conditions in this country section; this value is not an unconditional bill. | https://tax.gov.ae/Datafolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%20No.%20116%20of%202022%20-%20for%20publishing.pdf |",
      "line": 223
    },
    {
      "actual_text": "| Rate above the threshold | 9% | Apply the complete conditions in this country section; this value is not an unconditional bill. | https://tax.gov.ae/Datafolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%20No.%20116%20of%202022%20-%20for%20publishing.pdf |",
      "line": 224
    },
    {
      "actual_text": "- Outbound: current article 45, as replaced in 2024 and included in the Ministry’s January 2026 Arabic consolidation, uses 0% withholding for the specified non-resident State-Sourced Income not attributable to a UAE PE or nexus, subject to Cabinet powers. This does not establish a universal absence of corporate tax or the recipient’s home-country tax. The ordinary 0%/9% taxable-income bands and AED 375,000 threshold are separate from free-zone qualifying income, minimum tax and any small-business relief. The retained CD116 English text expressly labels itself an unofficial translation; its ordinary bands and anti-fragmentation scope were personally read, with that limitation retained. [Current Arabic FDL47, articles 3/22–23/45](https://mof.gov.ae/wp-content/uploads/2026/01/Federal-Decree-Law-No.-47-of-2022-and-its-amendments-ar-v13.1.26.pdf); [Arabic MD302/2024](https://mof.gov.ae/wp-content/uploads/2024/12/2-Ministerial-Decision-No-302-of-2024-on-the-Participation-Exemption-and-Foreign-Permanent-Establishment-Exemption-on-the-Taxation-of-Corporations-and-Businesses-for-publishing_ar.pdf); [CD116 threshold decision](https://tax.gov.ae/Datafolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%20No.%20116%20of%202022%20-%20for%20publishing.pdf)",
      "line": 241
    }
  ],
  "short_exact_native_quotes": [
    "(375,000) درهم إماراتي"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/73-web-response.json",
  "source_key": "73",
  "source_sha256": "ec5098787028d4141ef68ecb7ee2e6d70ae91a81d0784eadae323651000d3a79",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### AE-BASE-PARTICIPATION

Art22UAEresidentjuridicaldividendexempt;Art23ordinary5rights12month9similartax/assettest anddeductibledistribution/priorimpairment/exchange2year/failedperiodrecapture;MD302currentcost/relatedpartyoverridebelow.

```json
{
  "act_article_or_scope": "ArabicFDL47Jan2026physical23–26Art22/23all,21/24neighbours",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "Art22UAEresidentjuridicaldividendexempt;Art23ordinary5rights12month9similartax/assettest anddeductibledistribution/priorimpairment/exchange2year/failedperiodrecapture;MD302currentcost/relatedpartyoverridebelow.",
  "id": "AE-BASE-PARTICIPATION",
  "manual_native_image_verification": {
    "actual_visual_read_on": "2026-11-16",
    "images": [
      {
        "path": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/72-page-23.png",
        "sha256": "4893be1dc317da1e48df59e9b5f1dc549a09b2cc8d9a5f286617a81b44b962b0"
      },
      {
        "path": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/72-page-24.png",
        "sha256": "43f0c0481fedb8e59834550fe2f232377e5285ef961f8f0bfda17b42ac80e3b4"
      },
      {
        "path": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/72-page-25.png",
        "sha256": "500aa414ab240b0ffc91cb233e8662edb443ccd6cbc785334577fa138dc4748a"
      },
      {
        "path": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/72-page-26.png",
        "sha256": "0a5931af73b829666d354fa2121a6d4564bf8be3e404145a14d8b13f2cdcd1de"
      }
    ],
    "why_not_plain_text_literal": "PDF font/layout extraction corrupts Arabic glyphs and bidi order; exact short manually transcribed native phrase checked visually against actual retained primary page, not inferred from English."
  },
  "official_url": "https://mof.gov.ae/wp-content/uploads/2026/01/Federal-Decree-Law-No.-47-of-2022-and-its-amendments-ar-v13.1.26.pdf",
  "quote_mode": "Arabic actual physicalPDF23–26 personally visually read; short native phrase literal in actual page; full own conditional paraphrase plus Englishunofficialcrosscheck. Manual clean text avoids bidi/PDF-font extraction corruption.",
  "sections": [
    {
      "actual_text": "- Participation exemption: article 23’s ordinary route starts with 5% ownership; the holding/intention must be uninterrupted for at least 12 months, with at least 5% of distributable profits and liquidation proceeds, the specified 9%-similar-tax condition and other exclusions. MD302 article 8’s aggregated acquisition-cost alternative of at least AED 4,000,000 is treated as satisfying BOTH the minimum ownership requirement and the 5% profits/liquidation requirement. Do not incorrectly impose those ownership-rights tests again on that alternative.",
      "line": 237
    },
    {
      "actual_text": "- Dividends from a UAE-resident juridical person are exempt under article 22 without proving a foreign participating interest. For foreign interests, gains are exempt only after the applicable holding/acquisition period; failed 12-month conditions can recapture earlier exempt income. Deductible payer distributions and specified prior impairment deductions restrict relief; the 2-year acquisition-exchange rule, liquidation losses and the MD302 cost/repayment/continuity provisions require their own facts.",
      "line": 240
    }
  ],
  "short_exact_native_quotes": [
    "توزيعات الأرباح المحصلة من شخص اعتباري"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/72.txt",
  "source_key": "72",
  "source_sha256": "09395fde70c419717263225c768aff2186a21311112f4e12f5f7ddc11c1a0f9a",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### AE-COST-RIGHTS

4maggregatedhistoricalcostalternative satisfies BOTHownershipANDprofit/liquidation5rights;netcapitalrepayment/currentforeignexchangeacqdate/partdisposalaverageandrecovery12mo;ownershipclasses+qualifyinggroupaggregation separately.

```json
{
  "act_article_or_scope": "ArabicMD302all11pages;Art8(1)–(8),Art2ownership and3continuity neighbours",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "4maggregatedhistoricalcostalternative satisfies BOTHownershipANDprofit/liquidation5rights;netcapitalrepayment/currentforeignexchangeacqdate/partdisposalaverageandrecovery12mo;ownershipclasses+qualifyinggroupaggregation separately.",
  "id": "AE-COST-RIGHTS",
  "manual_native_image_verification": {
    "actual_visual_read_on": "2026-11-16",
    "images": [
      {
        "path": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/66-page-07.png",
        "sha256": "0450616cd34049f9d0bdacb590fb2f2a3ac8752ed002b783b0adf6e70f25dab1"
      }
    ],
    "why_not_plain_text_literal": "PDF font/layout extraction corrupts Arabic glyphs and bidi order; exact short manually transcribed native phrase checked visually against actual retained primary page, not inferred from English."
  },
  "official_url": "https://mof.gov.ae/wp-content/uploads/2024/12/2-Ministerial-Decision-No-302-of-2024-on-the-Participation-Exemption-and-Foreign-Permanent-Establishment-Exemption-on-the-Taxation-of-Corporations-and-Businesses-for-publishing_ar.pdf",
  "quote_mode": "Exact short Arabic fragment personally visually read page7; whole operative article8 and neighbours actualread, English44unofficialcrosscheck.",
  "sections": [
    {
      "actual_text": "| Minimum ownership | 5% | Apply the complete conditions in this country section; this value is not an unconditional bill. | https://mof.gov.ae/wp-content/uploads/2024/12/2-Ministerial-Decision-No-302-of-2024-on-the-Participation-Exemption-and-Foreign-Permanent-Establishment-Exemption-on-the-Taxation-of-Corporations-and-Businesses-for-publishing_ar.pdf |",
      "line": 228
    },
    {
      "actual_text": "| Alternative acquisition cost | AED 4 million | Apply the complete conditions in this country section; this value is not an unconditional bill. | https://mof.gov.ae/wp-content/uploads/2024/12/2-Ministerial-Decision-No-302-of-2024-on-the-Participation-Exemption-and-Foreign-Permanent-Establishment-Exemption-on-the-Taxation-of-Corporations-and-Businesses-for-publishing_ar.pdf |",
      "line": 229
    },
    {
      "actual_text": "- Participation exemption: article 23’s ordinary route starts with 5% ownership; the holding/intention must be uninterrupted for at least 12 months, with at least 5% of distributable profits and liquidation proceeds, the specified 9%-similar-tax condition and other exclusions. MD302 article 8’s aggregated acquisition-cost alternative of at least AED 4,000,000 is treated as satisfying BOTH the minimum ownership requirement and the 5% profits/liquidation requirement. Do not incorrectly impose those ownership-rights tests again on that alternative.",
      "line": 237
    }
  ],
  "short_exact_native_quotes": [
    "أربعة ملايين درهم"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/66.txt",
  "source_key": "66",
  "source_sha256": "e60c1223b10c22fa36aec300e89e4bf08c8768f1c38571adb9534eeb60d4e508",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### AE-TAX-ASSET-TESTS

9similartaxstatutory/effectiveratealternatives;activityonly/refunddistribution-onlytaxbars;qualifiedholdingmanagedfilingadequatepeoplepremisesancillaryand2periodincomecondition;assettest50ONLYrelatedparty,wholeperiodconsolidatedbookorMV.

```json
{
  "act_article_or_scope": "MD302ArabicArts4–10allphysical2–7;English44all13pagesowncrosscheck",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "9similartaxstatutory/effectiveratealternatives;activityonly/refunddistribution-onlytaxbars;qualifiedholdingmanagedfilingadequatepeoplepremisesancillaryand2periodincomecondition;assettest50ONLYrelatedparty,wholeperiodconsolidatedbookorMV.",
  "id": "AE-TAX-ASSET-TESTS",
  "manual_native_image_verification": {
    "actual_visual_read_on": "2026-11-16",
    "images": [
      {
        "path": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/66-page-05.png",
        "sha256": "d9d5081589b8fbee52fa4161d9298fcc490c752545715bd0dc8b57248d492e7a"
      },
      {
        "path": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/66-page-06.png",
        "sha256": "33beccac4f4e18a6d1911e3e4084fe35517a7918067e720d1b582a046666511a"
      },
      {
        "path": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/66-page-08.png",
        "sha256": "9918a9dab6fc5eb2788988c1f852a555f99e71ab1ae3c48f3d89c6818612722f"
      }
    ],
    "why_not_plain_text_literal": "PDF font/layout extraction corrupts Arabic glyphs and bidi order; exact short manually transcribed native phrase checked visually against actual retained primary page, not inferred from English."
  },
  "official_url": "https://mof.gov.ae/wp-content/uploads/2024/12/2-Ministerial-Decision-No-302-of-2024-on-the-Participation-Exemption-and-Foreign-Permanent-Establishment-Exemption-on-the-Taxation-of-Corporations-and-Businesses-for-publishing_ar.pdf",
  "quote_mode": "Exact short Arabic phrase actualpage8; actual fullArts4–10visualread, sourcefilebidiwordorder not assertedclean manual law transcript.",
  "sections": [
    {
      "actual_text": "| Subject-to-tax rate | 9% | Apply the complete conditions in this country section; this value is not an unconditional bill. | https://mof.gov.ae/wp-content/uploads/2024/12/2-Ministerial-Decision-No-302-of-2024-on-the-Participation-Exemption-and-Foreign-Permanent-Establishment-Exemption-on-the-Taxation-of-Corporations-and-Businesses-for-publishing_ar.pdf |",
      "line": 230
    },
    {
      "actual_text": "| Asset test | Not more than 50% | Apply the complete conditions in this country section; this value is not an unconditional bill. | https://mof.gov.ae/wp-content/uploads/2024/12/2-Ministerial-Decision-No-302-of-2024-on-the-Participation-Exemption-and-Foreign-Permanent-Establishment-Exemption-on-the-Taxation-of-Corporations-and-Businesses-for-publishing_ar.pdf |",
      "line": 231
    },
    {
      "actual_text": "- MD302 applies to tax periods beginning on or after 1 January 2025; MD116 remains for earlier periods. The ordinary asset test requires that not more than 50% of the participation’s direct and indirect assets consist of ownership interests that would not qualify for the exemption if held directly; MD302 limits that test to a participation that is a Related Party (article 9), and must be met throughout the period using the permitted consolidated-account or market-value method (article 10).",
      "line": 238
    },
    {
      "actual_text": "- The subject-to-tax rules permit specified statutory or effective-rate alternatives; taxes limited to selected activities, refunded on distribution or due only on distribution do not meet the similar-tax test. Qualifying holding-company participations have separate local management, filing, adequate people/premises, ancillary-activity and two-period income conditions; free-zone/exempt participations are separately addressed. An investee country’s headline rate is not the whole test.",
      "line": 239
    }
  ],
  "short_exact_native_quotes": [
    "أن تكون المشاركة طرفاً"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/66.txt",
  "source_key": "66",
  "source_sha256": "e60c1223b10c22fa36aec300e89e4bf08c8768f1c38571adb9534eeb60d4e508",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### AE-EFFECT-EXCHANGE-LOSSES

Effectiveperiodstart>=1Jan2025repeals116saveearlier;costcapitalisationChapter9financing/ownerparticipationincomevsrelatednonownerbar;exchangecontinuity2yr/liqconditionsforeignPEloss ownscope.

```json
{
  "act_article_or_scope": "MD302ArabicArts11–17wholephysical7–11;allpagesownread",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "Effectiveperiodstart>=1Jan2025repeals116saveearlier;costcapitalisationChapter9financing/ownerparticipationincomevsrelatednonownerbar;exchangecontinuity2yr/liqconditionsforeignPEloss ownscope.",
  "id": "AE-EFFECT-EXCHANGE-LOSSES",
  "manual_native_image_verification": {
    "actual_visual_read_on": "2026-11-16",
    "images": [
      {
        "path": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/66-page-09.png",
        "sha256": "3efb7306a3b4e52d33b4d6d7ac012163757474947d284bbd7b4fdac52cda8f38"
      },
      {
        "path": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/66-page-10.png",
        "sha256": "e0420ad1d3eef0ba43ff1211cd3363f2744da2a3fe8476aca48bbda289260649"
      },
      {
        "path": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/66-page-11.png",
        "sha256": "e41902be528a1a6b4a9cb532c3c834c392fd5be216311cb4d0fb078975246c7f"
      }
    ],
    "why_not_plain_text_literal": "PDF font/layout extraction corrupts Arabic glyphs and bidi order; exact short manually transcribed native phrase checked visually against actual retained primary page, not inferred from English."
  },
  "official_url": "https://mof.gov.ae/wp-content/uploads/2024/12/2-Ministerial-Decision-No-302-of-2024-on-the-Participation-Exemption-and-Foreign-Permanent-Establishment-Exemption-on-the-Taxation-of-Corporations-and-Businesses-for-publishing_ar.pdf",
  "quote_mode": "Short Arabic source-language fragment; entire11pageactualvisualownread, precise assignedArts11–17 and complete condition paraphrase, no Englishasnativeclaim.",
  "sections": [
    {
      "actual_text": "- MD302 applies to tax periods beginning on or after 1 January 2025; MD116 remains for earlier periods. The ordinary asset test requires that not more than 50% of the participation’s direct and indirect assets consist of ownership interests that would not qualify for the exemption if held directly; MD302 limits that test to a participation that is a Related Party (article 9), and must be met throughout the period using the permitted consolidated-account or market-value method (article 10).",
      "line": 238
    },
    {
      "actual_text": "- Dividends from a UAE-resident juridical person are exempt under article 22 without proving a foreign participating interest. For foreign interests, gains are exempt only after the applicable holding/acquisition period; failed 12-month conditions can recapture earlier exempt income. Deductible payer distributions and specified prior impairment deductions restrict relief; the 2-year acquisition-exchange rule, liquidation losses and the MD302 cost/repayment/continuity provisions require their own facts.",
      "line": 240
    }
  ],
  "short_exact_native_quotes": [
    "الفترات الضريبية"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/66.txt",
  "source_key": "66",
  "source_sha256": "e60c1223b10c22fa36aec300e89e4bf08c8768f1c38571adb9534eeb60d4e508",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### AE-CURRENT-WHT

0specifiedNRStateSourceunlessattributablePE/nexus+Cabinetpowers;notuniversalnoCT/homecountrytax;currentArabicconsolidationactualreadJan2026,Englishtranslationlabelnotnative.

```json
{
  "act_article_or_scope": "CurrentArabicArt45wholephysical42,44/46and43/47neighbours;amended40/2024cover;28/2025updates44not23",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "0specifiedNRStateSourceunlessattributablePE/nexus+Cabinetpowers;notuniversalnoCT/homecountrytax;currentArabicconsolidationactualreadJan2026,Englishtranslationlabelnotnative.",
  "id": "AE-CURRENT-WHT",
  "manual_native_image_verification": {
    "actual_visual_read_on": "2026-11-16",
    "images": [
      {
        "path": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/72-page-42.png",
        "sha256": "3cb26fcc9f117ee7f1ce108ba939d81e02ac82d630ed1261f388b40dd22ad82e"
      }
    ],
    "why_not_plain_text_literal": "PDF font/layout extraction corrupts Arabic glyphs and bidi order; exact short manually transcribed native phrase checked visually against actual retained primary page, not inferred from English."
  },
  "official_url": "https://mof.gov.ae/wp-content/uploads/2026/01/Federal-Decree-Law-No.-47-of-2022-and-its-amendments-ar-v13.1.26.pdf",
  "quote_mode": "SHORT actual operativeArabicArticle45(1)clause fragments personallyvisuallyreadphysical42again16Nov19:00UTC plus fulloperativeparagraphs and neighbours; no pageextract bidi corruption treatednative.",
  "sections": [
    {
      "actual_text": "| Withholding tax, article 45 | 0% | Apply the complete conditions in this country section; this value is not an unconditional bill. | https://mof.gov.ae/wp-content/uploads/2026/01/Federal-Decree-Law-No.-47-of-2022-and-its-amendments-ar-v13.1.26.pdf |",
      "line": 235
    },
    {
      "actual_text": "- Outbound: current article 45, as replaced in 2024 and included in the Ministry’s January 2026 Arabic consolidation, uses 0% withholding for the specified non-resident State-Sourced Income not attributable to a UAE PE or nexus, subject to Cabinet powers. This does not establish a universal absence of corporate tax or the recipient’s home-country tax. The ordinary 0%/9% taxable-income bands and AED 375,000 threshold are separate from free-zone qualifying income, minimum tax and any small-business relief. The retained CD116 English text expressly labels itself an unofficial translation; its ordinary bands and anti-fragmentation scope were personally read, with that limitation retained. [Current Arabic FDL47, articles 3/22–23/45](https://mof.gov.ae/wp-content/uploads/2026/01/Federal-Decree-Law-No.-47-of-2022-and-its-amendments-ar-v13.1.26.pdf); [Arabic MD302/2024](https://mof.gov.ae/wp-content/uploads/2024/12/2-Ministerial-Decision-No-302-of-2024-on-the-Participation-Exemption-and-Foreign-Permanent-Establishment-Exemption-on-the-Taxation-of-Corporations-and-Businesses-for-publishing_ar.pdf); [CD116 threshold decision](https://tax.gov.ae/Datafolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%20No.%20116%20of%202022%20-%20for%20publishing.pdf)",
      "line": 241
    }
  ],
  "short_exact_native_quotes": [
    "للشخص غير المقيم للضريبة بنسبة (0%) صفر بالمائة"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/72.txt",
  "source_key": "72",
  "source_sha256": "09395fde70c419717263225c768aff2186a21311112f4e12f5f7ddc11c1a0f9a",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### UK-RATES

FYfrom1Apr2026main25/small19,50000/250000limitsconditionsassociatedcompanies,CIHCbarseparate.

```json
{
  "act_article_or_scope": "HMRCratesandallowances2026tablewhole70–111/125–131",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "FYfrom1Apr2026main25/small19,50000/250000limitsconditionsassociatedcompanies,CIHCbarseparate.",
  "id": "UK-RATES",
  "official_url": "https://www.gov.uk/government/publications/rates-and-allowances-corporation-tax/rates-and-allowances-corporation-tax",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "| Main rate, financial year from 1 April 2026, profits above GBP 250,000 before the limit adjustments below | 25% | Apply the complete conditions in this country section; this value is not an unconditional bill. | https://www.gov.uk/government/publications/rates-and-allowances-corporation-tax/rates-and-allowances-corporation-tax |",
      "line": 248
    },
    {
      "actual_text": "| Small profits rate, profits at or below GBP 50,000 before the limit adjustments below | 19% | Apply the complete conditions in this country section; this value is not an unconditional bill. | https://www.gov.uk/government/publications/rates-and-allowances-corporation-tax/rates-and-allowances-corporation-tax |",
      "line": 249
    }
  ],
  "short_exact_native_quotes": [
    "25%"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/35.txt",
  "source_key": "35",
  "source_sha256": "774a0fa332a7c4db367c288096461b56bc9e09403882240a1c2cf521ffca50c1",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### UK-DIVIDEND-NONSMALL

NonsmallactualclassE–IANDnotdeemedinterestANDnoforeigndeduction;J–Qantiavoidseparate.

```json
{
  "act_article_or_scope": "INTM653010wholeoperative67–77/CTA2009Part9A931D",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "NonsmallactualclassE–IANDnotdeemedinterestANDnoforeigndeduction;J–Qantiavoidseparate.",
  "id": "UK-DIVIDEND-NONSMALL",
  "official_url": "https://www.gov.uk/hmrc-internal-manuals/international-manual/intm653010",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "- Dividends: a company that is not small is exempt on a distribution that falls into an exempt class in sections 931E to 931I of the Corporation Tax Act 2009, is not a deemed interest distribution, AND is not deductible for any foreign resident ([INTM653010](https://www.gov.uk/hmrc-internal-manuals/international-manual/intm653010)). The exempt classes and anti-avoidance rules are in INTM653000 to INTM654000 and are not reproduced here.",
      "line": 259
    }
  ],
  "short_exact_native_quotes": [
    "exempt class"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/36.txt",
  "source_key": "36",
  "source_sha256": "30f32d314800382ebc005021d134a976201c677a75c4334a6d88ae95d28f9af8",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### UK-DIVIDEND-SMALL

FourgatesUK/qualifyingterritorypayernotdualresident;notdeemedinterest;noforeigndeduction;notaxadvantagescheme. Small931Snot19profitband;detailedterritoryapplicationsheld.

```json
{
  "act_article_or_scope": "INTM652010wholeoperative/931B,definition931S",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "FourgatesUK/qualifyingterritorypayernotdualresident;notdeemedinterest;noforeigndeduction;notaxadvantagescheme. Small931Snot19profitband;detailedterritoryapplicationsheld.",
  "id": "UK-DIVIDEND-SMALL",
  "official_url": "https://www.gov.uk/hmrc-internal-manuals/international-manual/intm652010",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "- A small company has its own exemption ([INTM650000](https://www.gov.uk/hmrc-internal-manuals/international-manual/intm650000) lists \"Exemption for small companies\"), whose current section 931B conditions include a UK/qualifying-territory payer that is not dual-resident, no specified deemed-interest distribution, no foreign deduction and no tax-advantage scheme. “Small” uses section 931S, not merely the 19% profit band; detailed territory/class applications remain outside computation here. [INTM652010](https://www.gov.uk/hmrc-internal-manuals/international-manual/intm652010) The ordinary bands are 19% at profits of GBP 50,000 or less and 25% above GBP 250,000, with Marginal Relief between. For the rate bands, HMRC's [Marginal Relief page](https://www.gov.uk/guidance/corporation-tax-marginal-relief) says the limits are proportionately reduced for accounting periods shorter than 12 months and divided by the number of associated companies plus one, profits include \"distributions from unrelated, unassociated companies\", and that close investment-holding companies cannot claim Marginal Relief. More strongly, CTM03951 confirms they cannot use the 19% small-profits rate either: they pay the main rate. Not every holding company is a CIHC; a holding/service company in a qualifying trading or commercial unconnected-property-letting group can fall outside it. [CTA2010 section 18N / CTM03951](https://www.gov.uk/hmrc-internal-manuals/company-taxation-manual/ctm03951)",
      "line": 260
    }
  ],
  "short_exact_native_quotes": [
    "qualifying territory"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/56.txt",
  "source_key": "56",
  "source_sha256": "685f3ad021f1135c514dde210ed3cc5ddfe4c1a6837304dcd9b768dca64343b5",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### UK-CIHC-MARGINAL

CIHCmain25not19orMR;notallholdcosCIHCqualifyingtrading/unconnectedcommercialletting/groupholdingservicespermitted;liquidationpriorperiodexception.

```json
{
  "act_article_or_scope": "CTM03951wholeoperative67–72/CTA201018N",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "CIHCmain25not19orMR;notallholdcosCIHCqualifyingtrading/unconnectedcommercialletting/groupholdingservicespermitted;liquidationpriorperiodexception.",
  "id": "UK-CIHC-MARGINAL",
  "official_url": "https://www.gov.uk/hmrc-internal-manuals/company-taxation-manual/ctm03951",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "- A small company has its own exemption ([INTM650000](https://www.gov.uk/hmrc-internal-manuals/international-manual/intm650000) lists \"Exemption for small companies\"), whose current section 931B conditions include a UK/qualifying-territory payer that is not dual-resident, no specified deemed-interest distribution, no foreign deduction and no tax-advantage scheme. “Small” uses section 931S, not merely the 19% profit band; detailed territory/class applications remain outside computation here. [INTM652010](https://www.gov.uk/hmrc-internal-manuals/international-manual/intm652010) The ordinary bands are 19% at profits of GBP 50,000 or less and 25% above GBP 250,000, with Marginal Relief between. For the rate bands, HMRC's [Marginal Relief page](https://www.gov.uk/guidance/corporation-tax-marginal-relief) says the limits are proportionately reduced for accounting periods shorter than 12 months and divided by the number of associated companies plus one, profits include \"distributions from unrelated, unassociated companies\", and that close investment-holding companies cannot claim Marginal Relief. More strongly, CTM03951 confirms they cannot use the 19% small-profits rate either: they pay the main rate. Not every holding company is a CIHC; a holding/service company in a qualifying trading or commercial unconnected-property-letting group can fall outside it. [CTA2010 section 18N / CTM03951](https://www.gov.uk/hmrc-internal-manuals/company-taxation-manual/ctm03951)",
      "line": 260
    }
  ],
  "short_exact_native_quotes": [
    "CT main rate"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/55.txt",
  "source_key": "55",
  "source_sha256": "10dab04e3658d24cf9519c3675bbc240132dbcb8dcb4fbab20003c2e2ffddbec",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### UK-ASSOCIATED-LIMITS

50000/250000apportionforAP/associateddivisorincludingcompanyitself;unrelatedunassociateddistributionsaugmentedprofits;nonresident/CIHCcannotMR.

```json
{
  "act_article_or_scope": "Marginalreliefwholeoperative75–99",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "50000/250000apportionforAP/associateddivisorincludingcompanyitself;unrelatedunassociateddistributionsaugmentedprofits;nonresident/CIHCcannotMR.",
  "id": "UK-ASSOCIATED-LIMITS",
  "official_url": "https://www.gov.uk/guidance/corporation-tax-marginal-relief",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "- A small company has its own exemption ([INTM650000](https://www.gov.uk/hmrc-internal-manuals/international-manual/intm650000) lists \"Exemption for small companies\"), whose current section 931B conditions include a UK/qualifying-territory payer that is not dual-resident, no specified deemed-interest distribution, no foreign deduction and no tax-advantage scheme. “Small” uses section 931S, not merely the 19% profit band; detailed territory/class applications remain outside computation here. [INTM652010](https://www.gov.uk/hmrc-internal-manuals/international-manual/intm652010) The ordinary bands are 19% at profits of GBP 50,000 or less and 25% above GBP 250,000, with Marginal Relief between. For the rate bands, HMRC's [Marginal Relief page](https://www.gov.uk/guidance/corporation-tax-marginal-relief) says the limits are proportionately reduced for accounting periods shorter than 12 months and divided by the number of associated companies plus one, profits include \"distributions from unrelated, unassociated companies\", and that close investment-holding companies cannot claim Marginal Relief. More strongly, CTM03951 confirms they cannot use the 19% small-profits rate either: they pay the main rate. Not every holding company is a CIHC; a holding/service company in a qualifying trading or commercial unconnected-property-letting group can fall outside it. [CTA2010 section 18N / CTM03951](https://www.gov.uk/hmrc-internal-manuals/company-taxation-manual/ctm03951)",
      "line": 260
    }
  ],
  "short_exact_native_quotes": [
    "£50,000"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/38.txt",
  "source_key": "38",
  "source_sha256": "98e922aebeb7baf26849b51c23c543e46f2781b40047a98121e6592ebc79f146",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### UK-SSE-RIGHTS

10ordinarycapitalAND10profitAND10liquidationbeneficialrights/equityholdermodifiedrules;noinferenceothercontexts10substantial.

```json
{
  "act_article_or_scope": "CG53072wholeoperative67–82/TCGA92Sch7AC8/17",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "10ordinarycapitalAND10profitAND10liquidationbeneficialrights/equityholdermodifiedrules;noinferenceothercontexts10substantial.",
  "id": "UK-SSE-RIGHTS",
  "official_url": "https://www.gov.uk/hmrc-internal-manuals/capital-gains-manual/cg53072",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "| Substantial shareholding | 10% | Apply the complete conditions in this country section; this value is not an unconditional bill. | https://www.gov.uk/hmrc-internal-manuals/capital-gains-manual/cg53072 |",
      "line": 253
    },
    {
      "actual_text": "- Gains, substantial shareholdings exemption: the investing company must hold at least 10% of ordinary share capital AND be entitled to at least 10% of distributable profits and of assets on a winding up ([CG53072](https://www.gov.uk/hmrc-internal-manuals/capital-gains-manual/cg53072)), for a continuous period of at least 12 months; for disposals from 1 April 2017 that period may end up to five years before the disposal ([CG53078](https://www.gov.uk/hmrc-internal-manuals/capital-gains-manual/cg53078)). The investee must be a qualifying (trading) company throughout the qualifying period ([CG53106](https://www.gov.uk/hmrc-internal-manuals/capital-gains-manual/cg53106)). Since 1 April 2017 the investing company itself need not be trading.",
      "line": 261
    }
  ],
  "short_exact_native_quotes": [
    "at least 10%"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/02.txt",
  "source_key": "02",
  "source_sha256": "1cc34ff45b9257bf859a9e2c2b7147502c942f18cb60775bfaa8651e6de1c2fc",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### UK-SSE-PERIOD

12continuousmonths;post1Apr2017periodmayendupto5yrsbeforedisposal;oldpre2017windowdifferent.

```json
{
  "act_article_or_scope": "CG53078wholeoperative67–77/Sch7AC7",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "12continuousmonths;post1Apr2017periodmayendupto5yrsbeforedisposal;oldpre2017windowdifferent.",
  "id": "UK-SSE-PERIOD",
  "official_url": "https://www.gov.uk/hmrc-internal-manuals/capital-gains-manual/cg53078",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "- Gains, substantial shareholdings exemption: the investing company must hold at least 10% of ordinary share capital AND be entitled to at least 10% of distributable profits and of assets on a winding up ([CG53072](https://www.gov.uk/hmrc-internal-manuals/capital-gains-manual/cg53072)), for a continuous period of at least 12 months; for disposals from 1 April 2017 that period may end up to five years before the disposal ([CG53078](https://www.gov.uk/hmrc-internal-manuals/capital-gains-manual/cg53078)). The investee must be a qualifying (trading) company throughout the qualifying period ([CG53106](https://www.gov.uk/hmrc-internal-manuals/capital-gains-manual/cg53106)). Since 1 April 2017 the investing company itself need not be trading.",
      "line": 261
    }
  ],
  "short_exact_native_quotes": [
    "12 months"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/39.txt",
  "source_key": "39",
  "source_sha256": "55f5f4b1f442ec4d6c40d559868bea420f29d01527c040b478398102d28ab430",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### UK-SSE-TRADING

Investeequalifyingtradingthroughactualperiodanddisposaldependency;investortradingrequirementrepealed2017;15Areorgexceptionnotgeneralabolition.

```json
{
  "act_article_or_scope": "CG53106wholeoperative68–83/Sch7AC18",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "Investeequalifyingtradingthroughactualperiodanddisposaldependency;investortradingrequirementrepealed2017;15Areorgexceptionnotgeneralabolition.",
  "id": "UK-SSE-TRADING",
  "official_url": "https://www.gov.uk/hmrc-internal-manuals/capital-gains-manual/cg53106",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "- Gains, substantial shareholdings exemption: the investing company must hold at least 10% of ordinary share capital AND be entitled to at least 10% of distributable profits and of assets on a winding up ([CG53072](https://www.gov.uk/hmrc-internal-manuals/capital-gains-manual/cg53072)), for a continuous period of at least 12 months; for disposals from 1 April 2017 that period may end up to five years before the disposal ([CG53078](https://www.gov.uk/hmrc-internal-manuals/capital-gains-manual/cg53078)). The investee must be a qualifying (trading) company throughout the qualifying period ([CG53106](https://www.gov.uk/hmrc-internal-manuals/capital-gains-manual/cg53106)). Since 1 April 2017 the investing company itself need not be trading.",
      "line": 261
    }
  ],
  "short_exact_native_quotes": [
    "1 April 2017"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/40.txt",
  "source_key": "40",
  "source_sha256": "cc86a12bdb6b79bb83d6b0deeb8610f8f7bef02f5c88146d6b9e3beb5dc78834",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

### UK-PILLARTWO

750m365dayconsolidatedgroupincl excludedentities;exceeded2of4priornottestedperiod+UKmember;periodadjust/mergerdemergerseparate;notuniversalglobalorpersonal-familyexclusion.

```json
{
  "act_article_or_scope": "MTT11010wholeoperative67–132",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "34ea8aee420be18b6d8487414adda5fe42b77818fbeb7c72338ba400b0b24049",
  "complete_condition_paraphrase": "750m365dayconsolidatedgroupincl excludedentities;exceeded2of4priornottestedperiod+UKmember;periodadjust/mergerdemergerseparate;notuniversalglobalorpersonal-familyexclusion.",
  "id": "UK-PILLARTWO",
  "official_url": "https://www.gov.uk/hmrc-internal-manuals/multinational-top-up-tax-and-domestic-top-up-tax/mtt11010",
  "quote_mode": "short exact source-language extract; full operative conditions and material neighbours personally read",
  "sections": [
    {
      "actual_text": "| Pillar Two revenue threshold, 365-day period | EUR 750 million | Apply the complete conditions in this country section; this value is not an unconditional bill. | https://www.gov.uk/hmrc-internal-manuals/multinational-top-up-tax-and-domestic-top-up-tax/mtt11010 |",
      "line": 257
    },
    {
      "actual_text": "- Pillar Two: under the cited UK framework the EUR 750 million threshold for a 365-day period must be exceeded in two of the four immediately preceding periods, with a UK member and the specified consolidated group revenue, including excluded entities. Adjust non-365-day periods and test merger/demerger rules separately. This one-line flag does not compute another country’s implementation.",
      "line": 262
    }
  ],
  "short_exact_native_quotes": [
    "€750 million"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/holding-location/sources/05.txt",
  "source_key": "05",
  "source_sha256": "55e34bee86f21f514bb977ade7e6d06cb9489db144e7d1eeccfc2d3290d724f3",
  "source_version_basis": "Actual retained primary body, bounded own-read scopes and version/translation limitations below; not a download-only or parent-read claim."
}
```

## Original-topic destinations

The complete original-topic destination table is in `../family-holding-company-location-compared/old-topic-map.json`.
