# family-office-residency-regimes-compared figure and rule ledger

Public projection; canonical private SHA256: `ab3943cceab6db8462dabfbbb6e80014207e144d1e40dfa2d67c62079b3a5ec7`. Complete captured/native source passages remain local. The JSON companion preserves every retained evidence field.

## Whole rule groups

### MT-REMITTANCE

Foreign income remittance basis for not ordinarily resident OR not domiciled; foreign gains exemption; longterm/permanentcertificate/card and ordinarilyresident+domiciledspouse exceptions.

```json
{
  "act_article_or_scope": "Cap123article4(1)(a)–(g), provisos(i)/(ii), subsequentlongterm/spouseprovisos; pp14–16, actual709–824",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "complete_condition_paraphrase": "Foreign income remittance basis for not ordinarily resident OR not domiciled; foreign gains exemption; longterm/permanentcertificate/card and ordinarilyresident+domiciledspouse exceptions.",
  "id": "MT-REMITTANCE",
  "official_url": "https://legislation.mt/eli/cap/123/eng/pdf",
  "public_law": true,
  "quote_mode": "Short exact source-language extracts, whitespace normalized only; complete material conditional scope personally read, no invented requirement to reproduce full paragraphs.",
  "sections": [
    {
      "actual_text": "**Remittance basis.** A person who is not ordinarily resident in Malta or not domiciled in Malta pays Malta tax on foreign income only on the amount received in Malta. Foreign capital gains of such a person are not taxed in Malta, even if brought in. Neither rule is available to everyone. From year of assessment 2019 they do \"not apply to an individual who is a long-term resident, or who holds a permanent residence certificate or a permanent residence card, in respect of any income derived by such individual in the year of being granted long-term resident status or the right of permanent residence and in subsequent years\". They also \"shall not apply to an individual whose spouse is ordinarily resident and domiciled in Malta\". The full test is in `mt-non-dom`. ([Income Tax Act, Cap. 123, article 4(1), provisos (i) and (ii)](https://legislation.mt/eli/cap/123/eng/pdf))",
      "line": 56
    },
    {
      "actual_text": "| Malta | Remittance basis for non-domiciled residents, with a minimum tax | A person resident in Malta who is not ordinarily resident or not domiciled in Malta, other than a long-term resident, a holder of a permanent residence certificate or card, or a person whose spouse is ordinarily resident and domiciled in Malta. The minimum tax applies to an ordinarily resident non-dom who meets the article 56(27) foreign-income test of EUR 35,000; the published MTCA guidance counts foreign income, with the statutory remittance and eligibility conditions below | Minimum tax EUR 5,000 a year (only where the EUR 35,000 test is met) | Continuing statutory residence/domicile and exception conditions | Foreign income taxed only when received in Malta; foreign capital gains not taxed | [Income Tax Act, Cap. 123](https://legislation.mt/eli/cap/123/eng/pdf) |",
      "line": 26,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    },
    {
      "actual_text": "| Malta | Global Residence Programme | Third-country nationals only (not Maltese, EEA or Swiss), not long-term residents, holding a qualifying owned or rented property as their main home; EU/EEA/Swiss nationals: Residence Programme, S.L. 123.160 | 15% on foreign income received in Malta, minimum EUR 15,000 a year; other income EUR 0.35 per euro | Existing programme in2026; rule6cessation and enacted2027transition below | Foreign income received in Malta at the flat rate; see the Malta section for gains | [Global Residence Programme Rules, S.L. 123.148](https://legislation.mt/eli/sl/123.148/eng/pdf) |",
      "line": 27,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/01.txt",
  "source_key": "01",
  "source_sha256": "4ab01721e228a68e059199bd668492461f8dea9ccbe8b74d427ded4e135a20cb",
  "source_version_basis": "Actual current official source personally read16November2026; operative scope and material neighbours recorded, not download-only."
}
```

### MT-MINIMUM-GATE

Ordinarily resident non-dom stilleligiblearticle4provisos, nootherminimumscheme; specifiedforeignincome>=35000not/notfullyreceived, article49coupleaggregate.

```json
{
  "act_article_or_scope": "Cap123article56(27)whole187; prior56(26)(c)/following57neighbours",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "complete_condition_paraphrase": "Ordinarily resident non-dom stilleligiblearticle4provisos, nootherminimumscheme; specifiedforeignincome>=35000not/notfullyreceived, article49coupleaggregate.",
  "id": "MT-MINIMUM-GATE",
  "official_url": "https://legislation.mt/eli/cap/123/eng/pdf",
  "public_law": true,
  "quote_mode": "Short exact source-language extracts, whitespace normalized only; complete material conditional scope personally read, no invented requirement to reproduce full paragraphs.",
  "sections": [
    {
      "actual_text": "**Minimum tax.** Article 56(27) applies to an ordinarily resident but non-domiciled individual who still qualifies under article 4(1)(i)–(ii), is not already taxed under a minimum-tax scheme, and derives the specified foreign income of at least EUR 35,000 which is not or not fully received in Malta. Article 49 couples aggregate both spouses' income. The minimum is EUR 5,000; tax already paid under the Act, including withholding, counts, but article 5A property-transfer tax does not. The statutory floor is before double-tax relief. If the person proves that worldwide-basis tax would be lower, the liability is capped at that lower amount. [Cap.123 article56(27)](https://legislation.mt/eli/cap/123/eng/pdf).",
      "line": 58
    },
    {
      "actual_text": "| Foreign-income threshold for the minimum tax, article 56(27) (at least; see statutory and administrative scope above) | EUR 35,000 | \"amounting to not less than thirty five thousand euro (€35,000)\" | https://legislation.mt/eli/cap/123/eng/pdf |",
      "line": 64
    },
    {
      "actual_text": "| Malta | Remittance basis for non-domiciled residents, with a minimum tax | A person resident in Malta who is not ordinarily resident or not domiciled in Malta, other than a long-term resident, a holder of a permanent residence certificate or card, or a person whose spouse is ordinarily resident and domiciled in Malta. The minimum tax applies to an ordinarily resident non-dom who meets the article 56(27) foreign-income test of EUR 35,000; the published MTCA guidance counts foreign income, with the statutory remittance and eligibility conditions below | Minimum tax EUR 5,000 a year (only where the EUR 35,000 test is met) | Continuing statutory residence/domicile and exception conditions | Foreign income taxed only when received in Malta; foreign capital gains not taxed | [Income Tax Act, Cap. 123](https://legislation.mt/eli/cap/123/eng/pdf) |",
      "line": 26,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    },
    {
      "actual_text": "| Malta | Global Residence Programme | Third-country nationals only (not Maltese, EEA or Swiss), not long-term residents, holding a qualifying owned or rented property as their main home; EU/EEA/Swiss nationals: Residence Programme, S.L. 123.160 | 15% on foreign income received in Malta, minimum EUR 15,000 a year; other income EUR 0.35 per euro | Existing programme in2026; rule6cessation and enacted2027transition below | Foreign income received in Malta at the flat rate; see the Malta section for gains | [Global Residence Programme Rules, S.L. 123.148](https://legislation.mt/eli/sl/123.148/eng/pdf) |",
      "line": 27,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/01.txt",
  "source_key": "01",
  "source_sha256": "4ab01721e228a68e059199bd668492461f8dea9ccbe8b74d427ded4e135a20cb",
  "source_version_basis": "Actual current official source personally read16November2026; operative scope and material neighbours recorded, not download-only."
}
```

### MT-MINIMUM-AMOUNT-RELIEF

Minimum5000beforeDTR, paidtax/withholdingcounts excluding5A; Commissioner-provedworldwidebasis lowercap.

```json
{
  "act_article_or_scope": "Cap123article56(27)wholeincludingbothprovisos",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "complete_condition_paraphrase": "Minimum5000beforeDTR, paidtax/withholdingcounts excluding5A; Commissioner-provedworldwidebasis lowercap.",
  "id": "MT-MINIMUM-AMOUNT-RELIEF",
  "official_url": "https://legislation.mt/eli/cap/123/eng/pdf",
  "public_law": true,
  "quote_mode": "Short exact source-language extracts, whitespace normalized only; complete material conditional scope personally read, no invented requirement to reproduce full paragraphs.",
  "sections": [
    {
      "actual_text": "**Minimum tax.** Article 56(27) applies to an ordinarily resident but non-domiciled individual who still qualifies under article 4(1)(i)–(ii), is not already taxed under a minimum-tax scheme, and derives the specified foreign income of at least EUR 35,000 which is not or not fully received in Malta. Article 49 couples aggregate both spouses' income. The minimum is EUR 5,000; tax already paid under the Act, including withholding, counts, but article 5A property-transfer tax does not. The statutory floor is before double-tax relief. If the person proves that worldwide-basis tax would be lower, the liability is capped at that lower amount. [Cap.123 article56(27)](https://legislation.mt/eli/cap/123/eng/pdf).",
      "line": 58
    },
    {
      "actual_text": "| Minimum tax per year | EUR 5,000 | \"not less than five thousand euro (€5,000) per annum (hereinafter \"the minimum tax\")\" | https://legislation.mt/eli/cap/123/eng/pdf |",
      "line": 65
    },
    {
      "actual_text": "| Malta | Remittance basis for non-domiciled residents, with a minimum tax | A person resident in Malta who is not ordinarily resident or not domiciled in Malta, other than a long-term resident, a holder of a permanent residence certificate or card, or a person whose spouse is ordinarily resident and domiciled in Malta. The minimum tax applies to an ordinarily resident non-dom who meets the article 56(27) foreign-income test of EUR 35,000; the published MTCA guidance counts foreign income, with the statutory remittance and eligibility conditions below | Minimum tax EUR 5,000 a year (only where the EUR 35,000 test is met) | Continuing statutory residence/domicile and exception conditions | Foreign income taxed only when received in Malta; foreign capital gains not taxed | [Income Tax Act, Cap. 123](https://legislation.mt/eli/cap/123/eng/pdf) |",
      "line": 26,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    },
    {
      "actual_text": "| Malta | Global Residence Programme | Third-country nationals only (not Maltese, EEA or Swiss), not long-term residents, holding a qualifying owned or rented property as their main home; EU/EEA/Swiss nationals: Residence Programme, S.L. 123.160 | 15% on foreign income received in Malta, minimum EUR 15,000 a year; other income EUR 0.35 per euro | Existing programme in2026; rule6cessation and enacted2027transition below | Foreign income received in Malta at the flat rate; see the Malta section for gains | [Global Residence Programme Rules, S.L. 123.148](https://legislation.mt/eli/sl/123.148/eng/pdf) |",
      "line": 27,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/01.txt",
  "source_key": "01",
  "source_sha256": "4ab01721e228a68e059199bd668492461f8dea9ccbe8b74d427ded4e135a20cb",
  "source_version_basis": "Actual current official source personally read16November2026; operative scope and material neighbours recorded, not download-only."
}
```

### MT-ADMINISTRATIVE-MINIMUM

Recoveredpublishedinterpretation countsforeignincome/coupletotal, one5000minimum; DTRonlyactuallyremittedforeigntaxedincome; lowerworldwideoption; sevennamedschemesexcluded. Old access-basedambiguity nowresolvedonagencyreading.

```json
{
  "act_article_or_scope": "GuidanceNote1.1–1.10/5.1–5.3/6.1–6.6; actualweb143–170, personallyreadfull20–170",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "complete_condition_paraphrase": "Section6.3 uses foreign income, couples combine total income and one5000minimum; section6.2includesMaltawithholding, excludes5AandrestrictsDTRtoactuallyremittedincomeonwhichforeigntaxpaid. Section6.4lowerworldwidebasis;6.5excludesreturnedmigrants/Residents/HNWIboth/ResidenceProgramme/GRP/MRP. Sections1and5source/remittance/capitalexceptions read; noimmigrationpermissioninferred.",
  "id": "MT-ADMINISTRATIVE-MINIMUM",
  "official_url": "https://mtca.gov.mt/docs/default-source/documents/mtca-guidelines-on-the-remittance-under-the-income-tax.pdf?sfvrsn=d2f39d05_1",
  "public_law": false,
  "quote_mode": "Short exact source-language extracts, whitespace normalized only; complete material conditional scope personally read, no invented requirement to reproduce full paragraphs.",
  "sections": [
    {
      "actual_text": "The old draft reserved whether the EUR 35,000 gate meant all foreign income or only its unremitted part. The actual MTCA remittance guidance has now been read: section6.3 uses foreign income, aggregates a married couple's total income, and applies one minimum to the couple; section6.2 restricts double-tax relief to actually remitted income taxed abroad. Use that published administrative reading together with the statute's not-or-not-fully-remitted condition. Keep the source/remittance records; do not compute the gate only from the unremitted balance. [MTCA guidance sections1/5/6](https://mtca.gov.mt/docs/default-source/documents/mtca-guidelines-on-the-remittance-under-the-income-tax.pdf?sfvrsn=d2f39d05_1).",
      "line": 60
    },
    {
      "actual_text": "| Malta | Remittance basis for non-domiciled residents, with a minimum tax | A person resident in Malta who is not ordinarily resident or not domiciled in Malta, other than a long-term resident, a holder of a permanent residence certificate or card, or a person whose spouse is ordinarily resident and domiciled in Malta. The minimum tax applies to an ordinarily resident non-dom who meets the article 56(27) foreign-income test of EUR 35,000; the published MTCA guidance counts foreign income, with the statutory remittance and eligibility conditions below | Minimum tax EUR 5,000 a year (only where the EUR 35,000 test is met) | Continuing statutory residence/domicile and exception conditions | Foreign income taxed only when received in Malta; foreign capital gains not taxed | [Income Tax Act, Cap. 123](https://legislation.mt/eli/cap/123/eng/pdf) |",
      "line": 26,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    },
    {
      "actual_text": "| Malta | Global Residence Programme | Third-country nationals only (not Maltese, EEA or Swiss), not long-term residents, holding a qualifying owned or rented property as their main home; EU/EEA/Swiss nationals: Residence Programme, S.L. 123.160 | 15% on foreign income received in Malta, minimum EUR 15,000 a year; other income EUR 0.35 per euro | Existing programme in2026; rule6cessation and enacted2027transition below | Foreign income received in Malta at the flat rate; see the Malta section for gains | [Global Residence Programme Rules, S.L. 123.148](https://legislation.mt/eli/sl/123.148/eng/pdf) |",
      "line": 27,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [
    "foreign income is less than €35,000"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/23-actual-web.txt",
  "source_key": "23",
  "source_sha256": "7ab5b7deea922588b7edc7ead823876faa032986b2e9c0d18e13fcc570040994",
  "source_version_basis": "Actual current official source personally read16November2026; operative scope and material neighbours recorded, not download-only."
}
```

### MT-GRP-PROPERTY

GRPmainhomeownership275000Malta/220000GozoSouth;rent9600/8750; occupantslimited/notified; prepublicationarchitectvalueexception.

```json
{
  "act_article_or_scope": "SL123.148rule2definitionsqualifyingproperty/owned/rented/primaryresidence/south; pp2–4, readwholedefinition+Schedule",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "complete_condition_paraphrase": "GRPmainhomeownership275000Malta/220000GozoSouth;rent9600/8750; occupantslimited/notified; prepublicationarchitectvalueexception.",
  "id": "MT-GRP-PROPERTY",
  "official_url": "https://legislation.mt/eli/sl/123.148/eng/pdf",
  "public_law": true,
  "quote_mode": "Short exact source-language extracts, whitespace normalized only; complete material conditional scope personally read, no invented requirement to reproduce full paragraphs.",
  "sections": [
    {
      "actual_text": "**Global Residence Programme (GRP).** Open only to third-country nationals: a Maltese, EEA or Swiss national cannot apply, and nor can a long-term resident or anyone already under another Malta tax scheme listed in rule 4. The rule2 long-term-resident definition also includes an applicant for that status. The applicant applies through an authorised registered mandatary and must, among other conditions, hold a qualifying owned or rented property as the main home, have stable and regular resources sufficient without Maltese social assistance, a valid travel document, sickness insurance covering the EU for self/dependants, adequate communication in an official language and fit-and-proper status ([S.L. 123.148, rules 3 and 4](https://legislation.mt/eli/sl/123.148/eng/pdf)).",
      "line": 67
    },
    {
      "actual_text": "| Qualifying owned property, Malta other than Gozo and the south of Malta (purchase price at least) | EUR 275,000 | \"two hundred and seventy-five thousand euro (€275,000) for a property situated in Malta\" | https://legislation.mt/eli/sl/123.148/eng/pdf |",
      "line": 82
    },
    {
      "actual_text": "| Qualifying owned property, Gozo or the south of Malta (at least) | EUR 220,000 | \"two hundred and twenty thousand euro (€220,000) for a property situated in Gozo or in the south of Malta\" | https://legislation.mt/eli/sl/123.148/eng/pdf |",
      "line": 83
    },
    {
      "actual_text": "| Qualifying rented property, Malta other than Gozo and the south of Malta (rent per year, at least) | EUR 9,600 | \"nine thousand and six hundred euro (€9,600) per annum for a property situated in Malta\" | https://legislation.mt/eli/sl/123.148/eng/pdf |",
      "line": 84
    },
    {
      "actual_text": "| Qualifying rented property, Gozo or the south of Malta (rent per year, at least) | EUR 8,750 | \"eight thousand and seven hundred and fifty euro (€8,750) per annum for a property situated in Gozo\" | https://legislation.mt/eli/sl/123.148/eng/pdf |",
      "line": 85
    },
    {
      "actual_text": "| Malta | Remittance basis for non-domiciled residents, with a minimum tax | A person resident in Malta who is not ordinarily resident or not domiciled in Malta, other than a long-term resident, a holder of a permanent residence certificate or card, or a person whose spouse is ordinarily resident and domiciled in Malta. The minimum tax applies to an ordinarily resident non-dom who meets the article 56(27) foreign-income test of EUR 35,000; the published MTCA guidance counts foreign income, with the statutory remittance and eligibility conditions below | Minimum tax EUR 5,000 a year (only where the EUR 35,000 test is met) | Continuing statutory residence/domicile and exception conditions | Foreign income taxed only when received in Malta; foreign capital gains not taxed | [Income Tax Act, Cap. 123](https://legislation.mt/eli/cap/123/eng/pdf) |",
      "line": 26,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    },
    {
      "actual_text": "| Malta | Global Residence Programme | Third-country nationals only (not Maltese, EEA or Swiss), not long-term residents, holding a qualifying owned or rented property as their main home; EU/EEA/Swiss nationals: Residence Programme, S.L. 123.160 | 15% on foreign income received in Malta, minimum EUR 15,000 a year; other income EUR 0.35 per euro | Existing programme in2026; rule6cessation and enacted2027transition below | Foreign income received in Malta at the flat rate; see the Malta section for gains | [Global Residence Programme Rules, S.L. 123.148](https://legislation.mt/eli/sl/123.148/eng/pdf) |",
      "line": 27,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [
    "two hundred and seventy-five thousand euro (€275,000)"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/02.txt",
  "source_key": "02",
  "source_sha256": "efc2a4250aaba6ae5803cd73462384fbd795d2704ab7fd485a3e6fd193c0da96",
  "source_version_basis": "Actual current official source personally read16November2026; operative scope and material neighbours recorded, not download-only."
}
```

### MT-GRP-APPLICATION

ARMapplicationwrittenapproval;thirdcountryNOTMT/EEA/CH/longterm(includingapplicant),namedschemesbar; property/resources/travel/EUhealth/language/fitproper; fee6000,5500onlyownedSouth.

```json
{
  "act_article_or_scope": "SL123.148rules2/3/4/10, whole3–4andneighbours; pp4–8",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "complete_condition_paraphrase": "ARMapplicationwrittenapproval;thirdcountryNOTMT/EEA/CH/longterm(includingapplicant),namedschemesbar; property/resources/travel/EUhealth/language/fitproper; fee6000,5500onlyownedSouth.",
  "id": "MT-GRP-APPLICATION",
  "official_url": "https://legislation.mt/eli/sl/123.148/eng/pdf",
  "public_law": true,
  "quote_mode": "Short exact source-language extracts, whitespace normalized only; complete material conditional scope personally read, no invented requirement to reproduce full paragraphs.",
  "sections": [
    {
      "actual_text": "**Global Residence Programme (GRP).** Open only to third-country nationals: a Maltese, EEA or Swiss national cannot apply, and nor can a long-term resident or anyone already under another Malta tax scheme listed in rule 4. The rule2 long-term-resident definition also includes an applicant for that status. The applicant applies through an authorised registered mandatary and must, among other conditions, hold a qualifying owned or rented property as the main home, have stable and regular resources sufficient without Maltese social assistance, a valid travel document, sickness insurance covering the EU for self/dependants, adequate communication in an official language and fit-and-proper status ([S.L. 123.148, rules 3 and 4](https://legislation.mt/eli/sl/123.148/eng/pdf)).",
      "line": 67
    },
    {
      "actual_text": "| Application fee, non-refundable | EUR 6,000 | \"non-refundable administrative fee of six thousand euro (€6,000) upon application\" | https://legislation.mt/eli/sl/123.148/eng/pdf |",
      "line": 86
    },
    {
      "actual_text": "| Application fee where the property is owned and in the south of Malta | EUR 5,500 | \"five thousand and five hundred euro (€5,500) to be paid upon application\" | https://legislation.mt/eli/sl/123.148/eng/pdf |",
      "line": 87
    },
    {
      "actual_text": "| Malta | Remittance basis for non-domiciled residents, with a minimum tax | A person resident in Malta who is not ordinarily resident or not domiciled in Malta, other than a long-term resident, a holder of a permanent residence certificate or card, or a person whose spouse is ordinarily resident and domiciled in Malta. The minimum tax applies to an ordinarily resident non-dom who meets the article 56(27) foreign-income test of EUR 35,000; the published MTCA guidance counts foreign income, with the statutory remittance and eligibility conditions below | Minimum tax EUR 5,000 a year (only where the EUR 35,000 test is met) | Continuing statutory residence/domicile and exception conditions | Foreign income taxed only when received in Malta; foreign capital gains not taxed | [Income Tax Act, Cap. 123](https://legislation.mt/eli/cap/123/eng/pdf) |",
      "line": 26,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    },
    {
      "actual_text": "| Malta | Global Residence Programme | Third-country nationals only (not Maltese, EEA or Swiss), not long-term residents, holding a qualifying owned or rented property as their main home; EU/EEA/Swiss nationals: Residence Programme, S.L. 123.160 | 15% on foreign income received in Malta, minimum EUR 15,000 a year; other income EUR 0.35 per euro | Existing programme in2026; rule6cessation and enacted2027transition below | Foreign income received in Malta at the flat rate; see the Malta section for gains | [Global Residence Programme Rules, S.L. 123.148](https://legislation.mt/eli/sl/123.148/eng/pdf) |",
      "line": 27,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [
    "six thousand euro (€6,000)"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/02.txt",
  "source_key": "02",
  "source_sha256": "efc2a4250aaba6ae5803cd73462384fbd795d2704ab7fd485a3e6fd193c0da96",
  "source_version_basis": "Actual current official source personally read16November2026; operative scope and material neighbours recorded, not download-only."
}
```

### MT-GRP-RATES-FAMILY

ForeignincomereceivedMaltaspouse+rule2(b)/(d)children15%,min15000fullgrant/endyears,DTR74(a)/(b);otherincome35cseparate.

```json
{
  "act_article_or_scope": "SL123.148rule5(1)–(2), pp5–6; actualPDFp5visuallyread",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "complete_condition_paraphrase": "ForeignincomereceivedMaltaspouse+rule2(b)/(d)children15%,min15000fullgrant/endyears,DTR74(a)/(b);otherincome35cseparate.",
  "id": "MT-GRP-RATES-FAMILY",
  "official_url": "https://legislation.mt/eli/sl/123.148/eng/pdf",
  "public_law": true,
  "quote_mode": "Short exact source-language extracts, whitespace normalized only; complete material conditional scope personally read, no invented requirement to reproduce full paragraphs.",
  "sections": [
    {
      "actual_text": "Under GRP rule 5 (S.L. 123.148), foreign income received in Malta by the beneficiary, the spouse and the qualifying children is taxed at the flat rate in the table below, subject to the annual minimum. The minimum is payable in full both in the year the status is granted and in the year it ends, normally by 30 April of the year before the year of assessment, with continuing-conditions return (not required in the grant year). If status will not be granted before that date, pay before the grant. It is not refundable. Other income of those persons is taxed at the higher rate in the table. Rule6(1) provides cessation with effect from the appointed day if the person becomes a Maltese, EEA or Swiss national, stops holding (or lets out) the qualifying property, becomes a long-term resident, loses the sickness insurance, the stay is not in the public interest, or stays in any other jurisdiction for more than 183 days in a calendar year ([S.L. 123.148, rule 6](https://legislation.mt/eli/sl/123.148/eng/pdf)). The status also ends from the year of assessment in which the person breaches the Income Tax Acts, and the Ministers may jointly condone a rule6(1) failure caused by unforeseen circumstances beyond control only where notified and best efforts were made to remedy it (rule6(4)–(5)). A rule6(1) cessation event must be notified within four weeks of awareness (rule6(2)); ordinary annual returns remain required (rule9).",
      "line": 75
    },
    {
      "actual_text": "| Rate on foreign income received in Malta | 15% | Foreign income received in Malta; exact family and minimum conditions in rule5. | https://legislation.mt/eli/sl/123.148/eng/pdf |",
      "line": 79
    },
    {
      "actual_text": "| Rate on foreign income paid from a blacklisted territory | 35% | The actual leaflet describes a withholding or autonomous 35% charge, subject to the statutory category rules. | https://info.portaldasfinancas.gov.pt/pt/apoio_contribuinte/Folhetos_informativos/Documents/incentivos_investigacao.pdf |",
      "line": 131
    },
    {
      "actual_text": "| Minimum tax per year of assessment | EUR 15,000 | \"shall be fifteen thousand euro (€15,000) for any year of assessment\" | https://legislation.mt/eli/sl/123.148/eng/pdf |",
      "line": 80
    },
    {
      "actual_text": "| Rate on other income of the beneficiary and family | EUR 0.35 per euro | \"charged as separate income at the rate of thirty-five cents (0.35) on every euro\" | https://legislation.mt/eli/sl/123.148/eng/pdf |",
      "line": 81
    },
    {
      "actual_text": "| Malta | Remittance basis for non-domiciled residents, with a minimum tax | A person resident in Malta who is not ordinarily resident or not domiciled in Malta, other than a long-term resident, a holder of a permanent residence certificate or card, or a person whose spouse is ordinarily resident and domiciled in Malta. The minimum tax applies to an ordinarily resident non-dom who meets the article 56(27) foreign-income test of EUR 35,000; the published MTCA guidance counts foreign income, with the statutory remittance and eligibility conditions below | Minimum tax EUR 5,000 a year (only where the EUR 35,000 test is met) | Continuing statutory residence/domicile and exception conditions | Foreign income taxed only when received in Malta; foreign capital gains not taxed | [Income Tax Act, Cap. 123](https://legislation.mt/eli/cap/123/eng/pdf) |",
      "line": 26,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    },
    {
      "actual_text": "| Malta | Global Residence Programme | Third-country nationals only (not Maltese, EEA or Swiss), not long-term residents, holding a qualifying owned or rented property as their main home; EU/EEA/Swiss nationals: Residence Programme, S.L. 123.160 | 15% on foreign income received in Malta, minimum EUR 15,000 a year; other income EUR 0.35 per euro | Existing programme in2026; rule6cessation and enacted2027transition below | Foreign income received in Malta at the flat rate; see the Malta section for gains | [Global Residence Programme Rules, S.L. 123.148](https://legislation.mt/eli/sl/123.148/eng/pdf) |",
      "line": 27,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [
    "rate of fifteen cents (0.15) on every"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/02.txt",
  "source_key": "02",
  "source_sha256": "efc2a4250aaba6ae5803cd73462384fbd795d2704ab7fd485a3e6fd193c0da96",
  "source_version_basis": "Actual current official source personally read16November2026; operative scope and material neighbours recorded, not download-only."
}
```

### MT-GRP-PAYMENT

Normally30AprilbeforeYAwithcontinuingconditionsreturnexceptgrantyear;wheregrantevidentlyafter30Aprilpaybeforegrant;taxnotrefundable;annualreturn9.

```json
{
  "act_article_or_scope": "SL123.148rule5(3)(a)–(c)/9, whole; pp5–6/8",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "complete_condition_paraphrase": "Normally30AprilbeforeYAwithcontinuingconditionsreturnexceptgrantyear;wheregrantevidentlyafter30Aprilpaybeforegrant;taxnotrefundable;annualreturn9.",
  "id": "MT-GRP-PAYMENT",
  "official_url": "https://legislation.mt/eli/sl/123.148/eng/pdf",
  "public_law": true,
  "quote_mode": "Short exact source-language extracts, whitespace normalized only; complete material conditional scope personally read, no invented requirement to reproduce full paragraphs.",
  "sections": [
    {
      "actual_text": "Under GRP rule 5 (S.L. 123.148), foreign income received in Malta by the beneficiary, the spouse and the qualifying children is taxed at the flat rate in the table below, subject to the annual minimum. The minimum is payable in full both in the year the status is granted and in the year it ends, normally by 30 April of the year before the year of assessment, with continuing-conditions return (not required in the grant year). If status will not be granted before that date, pay before the grant. It is not refundable. Other income of those persons is taxed at the higher rate in the table. Rule6(1) provides cessation with effect from the appointed day if the person becomes a Maltese, EEA or Swiss national, stops holding (or lets out) the qualifying property, becomes a long-term resident, loses the sickness insurance, the stay is not in the public interest, or stays in any other jurisdiction for more than 183 days in a calendar year ([S.L. 123.148, rule 6](https://legislation.mt/eli/sl/123.148/eng/pdf)). The status also ends from the year of assessment in which the person breaches the Income Tax Acts, and the Ministers may jointly condone a rule6(1) failure caused by unforeseen circumstances beyond control only where notified and best efforts were made to remedy it (rule6(4)–(5)). A rule6(1) cessation event must be notified within four weeks of awareness (rule6(2)); ordinary annual returns remain required (rule9).",
      "line": 75
    },
    {
      "actual_text": "| Malta | Remittance basis for non-domiciled residents, with a minimum tax | A person resident in Malta who is not ordinarily resident or not domiciled in Malta, other than a long-term resident, a holder of a permanent residence certificate or card, or a person whose spouse is ordinarily resident and domiciled in Malta. The minimum tax applies to an ordinarily resident non-dom who meets the article 56(27) foreign-income test of EUR 35,000; the published MTCA guidance counts foreign income, with the statutory remittance and eligibility conditions below | Minimum tax EUR 5,000 a year (only where the EUR 35,000 test is met) | Continuing statutory residence/domicile and exception conditions | Foreign income taxed only when received in Malta; foreign capital gains not taxed | [Income Tax Act, Cap. 123](https://legislation.mt/eli/cap/123/eng/pdf) |",
      "line": 26,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    },
    {
      "actual_text": "| Malta | Global Residence Programme | Third-country nationals only (not Maltese, EEA or Swiss), not long-term residents, holding a qualifying owned or rented property as their main home; EU/EEA/Swiss nationals: Residence Programme, S.L. 123.160 | 15% on foreign income received in Malta, minimum EUR 15,000 a year; other income EUR 0.35 per euro | Existing programme in2026; rule6cessation and enacted2027transition below | Foreign income received in Malta at the flat rate; see the Malta section for gains | [Global Residence Programme Rules, S.L. 123.148](https://legislation.mt/eli/sl/123.148/eng/pdf) |",
      "line": 27,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [
    "30th April"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/02.txt",
  "source_key": "02",
  "source_sha256": "efc2a4250aaba6ae5803cd73462384fbd795d2704ab7fd485a3e6fd193c0da96",
  "source_version_basis": "Actual current official source personally read16November2026; operative scope and material neighbours recorded, not download-only."
}
```

### MT-GRP-CESSATION

Sixrule6(1)eventsretroactiveappointeddayinclnationality/propertyletting/longterm/insurance/publicinterest/>183otherjurisdiction;4weeksnotice;breachfromYA;condonationonlyunforeseenbeyondcontrol+notice+besteffortremedy.

```json
{
  "act_article_or_scope": "SL123.148rule6(1)–(5)wholewith5(4)/7neighbours; pp6–7",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "complete_condition_paraphrase": "Sixrule6(1)eventsretroactiveappointeddayinclnationality/propertyletting/longterm/insurance/publicinterest/>183otherjurisdiction;4weeksnotice;breachfromYA;condonationonlyunforeseenbeyondcontrol+notice+besteffortremedy.",
  "id": "MT-GRP-CESSATION",
  "official_url": "https://legislation.mt/eli/sl/123.148/eng/pdf",
  "public_law": true,
  "quote_mode": "Short exact source-language extracts, whitespace normalized only; complete material conditional scope personally read, no invented requirement to reproduce full paragraphs.",
  "sections": [
    {
      "actual_text": "Under GRP rule 5 (S.L. 123.148), foreign income received in Malta by the beneficiary, the spouse and the qualifying children is taxed at the flat rate in the table below, subject to the annual minimum. The minimum is payable in full both in the year the status is granted and in the year it ends, normally by 30 April of the year before the year of assessment, with continuing-conditions return (not required in the grant year). If status will not be granted before that date, pay before the grant. It is not refundable. Other income of those persons is taxed at the higher rate in the table. Rule6(1) provides cessation with effect from the appointed day if the person becomes a Maltese, EEA or Swiss national, stops holding (or lets out) the qualifying property, becomes a long-term resident, loses the sickness insurance, the stay is not in the public interest, or stays in any other jurisdiction for more than 183 days in a calendar year ([S.L. 123.148, rule 6](https://legislation.mt/eli/sl/123.148/eng/pdf)). The status also ends from the year of assessment in which the person breaches the Income Tax Acts, and the Ministers may jointly condone a rule6(1) failure caused by unforeseen circumstances beyond control only where notified and best efforts were made to remedy it (rule6(4)–(5)). A rule6(1) cessation event must be notified within four weeks of awareness (rule6(2)); ordinary annual returns remain required (rule9).",
      "line": 75
    },
    {
      "actual_text": "**Malta traps.** The GRP is lost by a calendar year of more than 183 days in any other country, so a family that splits time across several homes must count the beneficiary's days in each other country. The minimum tax is due in full in the first and last year, however short. The GRP rules speak of foreign income received in Malta; foreign capital gains are free of Malta tax under article 4(1) proviso (ii) only if the person is not ordinarily resident or not domiciled in Malta; the GRP rules do not exempt gains themselves. Record residence and domicile evidence. Succession questions are not part of either regime; see `succession-and-forced-heirship-compared`.",
      "line": 89
    },
    {
      "actual_text": "| Malta | Remittance basis for non-domiciled residents, with a minimum tax | A person resident in Malta who is not ordinarily resident or not domiciled in Malta, other than a long-term resident, a holder of a permanent residence certificate or card, or a person whose spouse is ordinarily resident and domiciled in Malta. The minimum tax applies to an ordinarily resident non-dom who meets the article 56(27) foreign-income test of EUR 35,000; the published MTCA guidance counts foreign income, with the statutory remittance and eligibility conditions below | Minimum tax EUR 5,000 a year (only where the EUR 35,000 test is met) | Continuing statutory residence/domicile and exception conditions | Foreign income taxed only when received in Malta; foreign capital gains not taxed | [Income Tax Act, Cap. 123](https://legislation.mt/eli/cap/123/eng/pdf) |",
      "line": 26,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    },
    {
      "actual_text": "| Malta | Global Residence Programme | Third-country nationals only (not Maltese, EEA or Swiss), not long-term residents, holding a qualifying owned or rented property as their main home; EU/EEA/Swiss nationals: Residence Programme, S.L. 123.160 | 15% on foreign income received in Malta, minimum EUR 15,000 a year; other income EUR 0.35 per euro | Existing programme in2026; rule6cessation and enacted2027transition below | Foreign income received in Malta at the flat rate; see the Malta section for gains | [Global Residence Programme Rules, S.L. 123.148](https://legislation.mt/eli/sl/123.148/eng/pdf) |",
      "line": 27,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [
    "more than one hundred and"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/02.txt",
  "source_key": "02",
  "source_sha256": "efc2a4250aaba6ae5803cd73462384fbd795d2704ab7fd485a3e6fd193c0da96",
  "source_version_basis": "Actual current official source personally read16November2026; operative scope and material neighbours recorded, not download-only."
}
```

### MT-TRP-PARALLEL

TRPEU/EEA/SwissnotMaltese/notpermanent(applicantalso);same15%,15000minimumplusowneligibility/paymentrules;notimmigrationpermanentresidence.

```json
{
  "act_article_or_scope": "SL123.160rules2permanentapplicantdefinition/4(1)(a)–(h)/5(1)–(4), actualpp3–6plus6neighbour",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "complete_condition_paraphrase": "TRPEU/EEA/SwissnotMaltese/notpermanent(applicantalso);same15%,15000minimumplusowneligibility/paymentrules;notimmigrationpermanentresidence.",
  "id": "MT-TRP-PARALLEL",
  "official_url": "https://legislation.mt/eli/sl/123.160/eng/pdf",
  "public_law": true,
  "quote_mode": "Short exact source-language extracts, whitespace normalized only; complete material conditional scope personally read, no invented requirement to reproduce full paragraphs.",
  "sections": [
    {
      "actual_text": "EU, EEA and Swiss nationals (not Maltese nationals) cannot use the GRP but have a parallel scheme, the Residence Programme Rules, with the same flat rate on foreign income received in Malta and the annual minimum in the table below ([Residence Programme Rules, S.L. 123.160, rules 4 and 5](https://legislation.mt/eli/sl/123.160/eng/pdf)). See `mt-residence-programmes-for-wealthy-families`.",
      "line": 69
    },
    {
      "actual_text": "| Minimum tax per year of assessment, Residence Programme | EUR 15,000 | \"shall be fifteen thousand euro (€15,000) for any year of assessment\" | https://legislation.mt/eli/sl/123.160/eng/pdf |",
      "line": 73
    },
    {
      "actual_text": "| Malta | Remittance basis for non-domiciled residents, with a minimum tax | A person resident in Malta who is not ordinarily resident or not domiciled in Malta, other than a long-term resident, a holder of a permanent residence certificate or card, or a person whose spouse is ordinarily resident and domiciled in Malta. The minimum tax applies to an ordinarily resident non-dom who meets the article 56(27) foreign-income test of EUR 35,000; the published MTCA guidance counts foreign income, with the statutory remittance and eligibility conditions below | Minimum tax EUR 5,000 a year (only where the EUR 35,000 test is met) | Continuing statutory residence/domicile and exception conditions | Foreign income taxed only when received in Malta; foreign capital gains not taxed | [Income Tax Act, Cap. 123](https://legislation.mt/eli/cap/123/eng/pdf) |",
      "line": 26,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    },
    {
      "actual_text": "| Malta | Global Residence Programme | Third-country nationals only (not Maltese, EEA or Swiss), not long-term residents, holding a qualifying owned or rented property as their main home; EU/EEA/Swiss nationals: Residence Programme, S.L. 123.160 | 15% on foreign income received in Malta, minimum EUR 15,000 a year; other income EUR 0.35 per euro | Existing programme in2026; rule6cessation and enacted2027transition below | Foreign income received in Malta at the flat rate; see the Malta section for gains | [Global Residence Programme Rules, S.L. 123.148](https://legislation.mt/eli/sl/123.148/eng/pdf) |",
      "line": 27,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [
    "he is an EU, EEA or Swiss national but is not a Maltese national"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/11.txt",
  "source_key": "11",
  "source_sha256": "b92d9f9ec2ac14f970bee2d277bf2d1e87d0a87f59d9027b2761fe3fd7c0a273",
  "source_version_basis": "Actual current official source personally read16November2026; operative scope and material neighbours recorded, not download-only."
}
```

### MT-2027-TRANSITION

Commences1Jan2027,5yearterm/renewals,grants/applicationsreceivedby31Dec2026continueuntil31Dec2031;new2027minimadonotreplacecurrent2026figures.

```json
{
  "act_article_or_scope": "LN195/2026rule1(2),3(3)allprovisos, read2/3/4–6neighbours; actualPDFpp1/6–7, p7visual",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "complete_condition_paraphrase": "Commences1Jan2027,5yearterm/renewals,grants/applicationsreceivedby31Dec2026continueuntil31Dec2031;new2027minimadonotreplacecurrent2026figures.",
  "id": "MT-2027-TRANSITION",
  "official_url": "https://legislation.mt/eli/ln/2026/195/eng/pdf",
  "public_law": true,
  "quote_mode": "Short exact source-language extracts, whitespace normalized only; complete material conditional scope personally read, no invented requirement to reproduce full paragraphs.",
  "sections": [
    {
      "actual_text": "**Enacted transition, not a 2026 replacement.** L.N.195/2026 rule1(2) commences the Individual Tax Programme on 1 January 2027. Rule3(3) provides a five-year term, renewal provisions, and continuation until 31 December 2031 for status granted before or up to 31 December 2026, expressly including applications received up to that date. The old GRP/TRP rules alone therefore do not establish an indefinite future entitlement. This comparison's EUR15,000 and property/fee figures are the existing-programme figures, not the new-applicant 2027 minima. Obtain the applicable transition/grant before execution; this Guide does not compute the new programme. [Actual enacted rules1–3, read with4–6](https://legislation.mt/eli/ln/2026/195/eng/pdf).",
      "line": 91
    },
    {
      "actual_text": "| Malta | Remittance basis for non-domiciled residents, with a minimum tax | A person resident in Malta who is not ordinarily resident or not domiciled in Malta, other than a long-term resident, a holder of a permanent residence certificate or card, or a person whose spouse is ordinarily resident and domiciled in Malta. The minimum tax applies to an ordinarily resident non-dom who meets the article 56(27) foreign-income test of EUR 35,000; the published MTCA guidance counts foreign income, with the statutory remittance and eligibility conditions below | Minimum tax EUR 5,000 a year (only where the EUR 35,000 test is met) | Continuing statutory residence/domicile and exception conditions | Foreign income taxed only when received in Malta; foreign capital gains not taxed | [Income Tax Act, Cap. 123](https://legislation.mt/eli/cap/123/eng/pdf) |",
      "line": 26,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    },
    {
      "actual_text": "| Malta | Global Residence Programme | Third-country nationals only (not Maltese, EEA or Swiss), not long-term residents, holding a qualifying owned or rented property as their main home; EU/EEA/Swiss nationals: Residence Programme, S.L. 123.160 | 15% on foreign income received in Malta, minimum EUR 15,000 a year; other income EUR 0.35 per euro | Existing programme in2026; rule6cessation and enacted2027transition below | Foreign income received in Malta at the flat rate; see the Malta section for gains | [Global Residence Programme Rules, S.L. 123.148](https://legislation.mt/eli/sl/123.148/eng/pdf) |",
      "line": 27,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [
    "come into force on 1st January 2027"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/30.txt",
  "source_key": "30",
  "source_sha256": "61cfb6001b47d270d04145e604b2d7114d6e4a6cf39403cf968d4cb4b6c18092",
  "source_version_basis": "Actual current official source personally read16November2026; operative scope and material neighbours recorded, not download-only."
}
```

### IT-ELIGIBILITY-EXCLUDED-GAINS

Individualmovesunder2(2),atleast9nonresidentperiodsof10prior;foreignsource165(2);qualified67(1)(c)gainsfirst5periodsexcludedordinary68(3).

```json
{
  "act_article_or_scope": "TUIR24bis(1), current1Jan–31Dec2026, whole1–6andupdate181/233/242read",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "complete_condition_paraphrase": "Individualmovesunder2(2),atleast9nonresidentperiodsof10prior;foreignsource165(2);qualified67(1)(c)gainsfirst5periodsexcludedordinary68(3).",
  "id": "IT-ELIGIBILITY-EXCLUDED-GAINS",
  "official_url": "https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.del.presidente.della.repubblica:1986-12-22;917~art24bis!vig=",
  "public_law": true,
  "quote_mode": "Short exact source-language extracts, whitespace normalized only; complete material conditional scope personally read, no invented requirement to reproduce full paragraphs.",
  "sections": [
    {
      "actual_text": "Under article 24-bis of the TUIR, a person who moves tax residence to Italy may opt to pay a fixed substitute tax on foreign income instead of IRPEF on that income, if they were not Italian tax resident for at least nine of the ten tax periods before the option starts.",
      "line": 95
    },
    {
      "actual_text": "| Italy | Flat tax on foreign income, article 24-bis TUIR | A person who moves tax residence to Italy and was not Italian resident for at least nine of the ten tax periods before the option starts; option/eligibility evidence required; ruling optional under agency procedure, see below | EUR 300,000 a year; EUR 50,000 a year for each family member included (for moves from 1 January 2026) | Ends after 15 years at most; revocable | Foreign income covered by the flat amount; gains on qualifying shareholdings in the first five years taxed normally | [TUIR art. 24-bis](https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.del.presidente.della.repubblica:1986-12-22;917~art24bis!vig=) |",
      "line": 28,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [
    "nove periodi d'imposta"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/03.txt",
  "source_key": "03",
  "source_sha256": "c53869ede25f183fddeb9be10108dad8aef118fea03e5261c497a55c335883a5",
  "source_version_basis": "Actual current official source personally read16November2026; operative scope and material neighbours recorded, not download-only."
}
```

### IT-FIXED-PAYMENT

2026cohort300000main/50000eachfamilymember,eachperiodregardlessincome,onepaymentIRPEFbalancedate,nondeductible.

```json
{
  "act_article_or_scope": "TUIR24bis(2)whole+effectivenotes233/242",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "complete_condition_paraphrase": "2026cohort300000main/50000eachfamilymember,eachperiodregardlessincome,onepaymentIRPEFbalancedate,nondeductible.",
  "id": "IT-FIXED-PAYMENT",
  "official_url": "https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.del.presidente.della.repubblica:1986-12-22;917~art24bis!vig=",
  "public_law": true,
  "quote_mode": "Short exact source-language extracts, whitespace normalized only; complete material conditional scope personally read, no invented requirement to reproduce full paragraphs.",
  "sections": [
    {
      "actual_text": "The fixed amount is due for each tax period, whatever the income, in one payment by the balance date for income tax. It can be extended to family members within article 433 of the civil code who themselves meet the nine-of-ten test, at a lower amount for each. Gains on qualifying shareholdings (article 67(1)(c)) realised in the first five tax periods of the option are NOT covered and are taxed under the ordinary rules. The person may exclude one or more foreign countries: income from those countries is then taxed normally, with a foreign tax credit ([TUIR art. 24-bis, commi 1, 2, 5 and 6](https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.del.presidente.della.repubblica:1986-12-22;917~art24bis!vig=)).",
      "line": 99
    },
    {
      "actual_text": "| Substitute tax per tax period, main person (moves from 1 January 2026) | EUR 300,000 | \"nella misura di ((euro 300.000)) per ciascun periodo d'imposta in cui è valida la predetta opzione\" | https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.del.presidente.della.repubblica:1986-12-22;917~art24bis!vig= |",
      "line": 105
    },
    {
      "actual_text": "| Substitute tax per tax period, each family member included (moves from 1 January 2026) | EUR 50,000 | \"Tale importo è ridotto a ((euro 50.000)) per ciascun periodo d'imposta per ciascuno dei familiari\" | https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.del.presidente.della.repubblica:1986-12-22;917~art24bis!vig= |",
      "line": 106
    },
    {
      "actual_text": "| Italy | Flat tax on foreign income, article 24-bis TUIR | A person who moves tax residence to Italy and was not Italian resident for at least nine of the ten tax periods before the option starts; option/eligibility evidence required; ruling optional under agency procedure, see below | EUR 300,000 a year; EUR 50,000 a year for each family member included (for moves from 1 January 2026) | Ends after 15 years at most; revocable | Foreign income covered by the flat amount; gains on qualifying shareholdings in the first five years taxed normally | [TUIR art. 24-bis](https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.del.presidente.della.repubblica:1986-12-22;917~art24bis!vig=) |",
      "line": 28,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [
    "euro 300.000"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/03.txt",
  "source_key": "03",
  "source_sha256": "c53869ede25f183fddeb9be10108dad8aef118fea03e5261c497a55c335883a5",
  "source_version_basis": "Actual current official source personally read16November2026; operative scope and material neighbours recorded, not download-only."
}
```

### IT-LITERAL-PROCEDURE

Literalstatute saysfavourableinterpello+move-yearreturndeadline/jurisdictiondisclosure; mustreadactualadministrativeoptionalprocedureseparately.

```json
{
  "act_article_or_scope": "TUIR24bis(3)whole, adjacent2/4",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "complete_condition_paraphrase": "Literalstatute saysfavourableinterpello+move-yearreturndeadline/jurisdictiondisclosure; mustreadactualadministrativeoptionalprocedureseparately.",
  "id": "IT-LITERAL-PROCEDURE",
  "official_url": "https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.del.presidente.della.repubblica:1986-12-22;917~art24bis!vig=",
  "public_law": true,
  "quote_mode": "Short exact source-language extracts, whitespace normalized only; complete material conditional scope personally read, no invented requirement to reproduce full paragraphs.",
  "sections": [
    {
      "actual_text": "The literal text of article 24-bis(3) refers to a favourable ruling and the return deadline for the move year, including disclosure of the last residence jurisdictions. Read it with the actual published administrative procedure: Circular 17/E of 23 May 2017, Part III sections 3.1 and 4, says the ruling is optional; the option may be exercised directly in the return, or before the requested ruling arrives, with eligibility/checklist evidence retained. The agency describes the move-year return or the following-period return in its specified nine-of-ten situation. Do not make a favourable ruling a universal entry gate, or use the circular's historical filing dates/old tax amounts as 2026 deadlines or rates. [Current24-bis](https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.del.presidente.della.repubblica:1986-12-22;917~art24bis!vig=); [actual Finance Ministry-hosted Circular17/E, PartIII3–4](https://def.finanze.it/DocTribFrontend/getPrassiDetail.do?id=%7BDF6F5518-4D04-4718-B611-8AC67E8C08BC%7D).",
      "line": 97
    },
    {
      "actual_text": "| Italy | Flat tax on foreign income, article 24-bis TUIR | A person who moves tax residence to Italy and was not Italian resident for at least nine of the ten tax periods before the option starts; option/eligibility evidence required; ruling optional under agency procedure, see below | EUR 300,000 a year; EUR 50,000 a year for each family member included (for moves from 1 January 2026) | Ends after 15 years at most; revocable | Foreign income covered by the flat amount; gains on qualifying shareholdings in the first five years taxed normally | [TUIR art. 24-bis](https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.del.presidente.della.repubblica:1986-12-22;917~art24bis!vig=) |",
      "line": 28,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [
    "risposta favorevole a specifica istanza di interpello"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/03.txt",
  "source_key": "03",
  "source_sha256": "c53869ede25f183fddeb9be10108dad8aef118fea03e5261c497a55c335883a5",
  "source_version_basis": "Actual current official source personally read16November2026; operative scope and material neighbours recorded, not download-only."
}
```

### IT-OPTIONAL-RULING-AGENCY

Publishedadministrativeproceduremakesinterpellooptional; directreturnoption/documentchecklistretention;beforeanswersreturnedpossible; specifiedmove-year/followingreturn;nohistoricaldateborrowed.

```json
{
  "act_article_or_scope": "Circular17/E23May2017PartIII3/3.1–3.3and4whole, actualnative395–470; rawinlineXMLISO8859-1decodedJSescape, datedprocedurenot2026amounts",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "complete_condition_paraphrase": "PartIII3.1makesrequestoptional, directreturnoptionwhenall24bisconditionsmetwithdocumentretention; requestbeforemoveconditionaloneffectivemove; afteroptionrequestinadmissible; taxpayerwhopaidmayoptionbeforeanswer;negativeanswerdoesnotbindtaxpayerandcannotbeappealed.3.2–3.3checklist/evidenceforpersonandfamilyread.4coversmove-yearornextreturnspecified9-of10circumstances, optionalrequest,disclosureslastjurisdictions/excludedcountries/checklist, ordinaryverificationcaninvalidateregime, annualtacitrenewal. Historical2017deadlines/paymentratesnot2026execution.5.2exemptiononlycoveredjurisdictions; excludedassetskeepordinaryRW/IVIE/IVAFE.",
  "id": "IT-OPTIONAL-RULING-AGENCY",
  "official_url": "https://def.finanze.it/DocTribFrontend/getPrassiDetail.do?id=%7BDF6F5518-4D04-4718-B611-8AC67E8C08BC%7D",
  "public_law": false,
  "quote_mode": "Short exact source-language extracts, whitespace normalized only; complete material conditional scope personally read, no invented requirement to reproduce full paragraphs.",
  "sections": [
    {
      "actual_text": "The literal text of article 24-bis(3) refers to a favourable ruling and the return deadline for the move year, including disclosure of the last residence jurisdictions. Read it with the actual published administrative procedure: Circular 17/E of 23 May 2017, Part III sections 3.1 and 4, says the ruling is optional; the option may be exercised directly in the return, or before the requested ruling arrives, with eligibility/checklist evidence retained. The agency describes the move-year return or the following-period return in its specified nine-of-ten situation. Do not make a favourable ruling a universal entry gate, or use the circular's historical filing dates/old tax amounts as 2026 deadlines or rates. [Current24-bis](https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.del.presidente.della.repubblica:1986-12-22;917~art24bis!vig=); [actual Finance Ministry-hosted Circular17/E, PartIII3–4](https://def.finanze.it/DocTribFrontend/getPrassiDetail.do?id=%7BDF6F5518-4D04-4718-B611-8AC67E8C08BC%7D).",
      "line": 97
    },
    {
      "actual_text": "| Italy | Flat tax on foreign income, article 24-bis TUIR | A person who moves tax residence to Italy and was not Italian resident for at least nine of the ten tax periods before the option starts; option/eligibility evidence required; ruling optional under agency procedure, see below | EUR 300,000 a year; EUR 50,000 a year for each family member included (for moves from 1 January 2026) | Ends after 15 years at most; revocable | Foreign income covered by the flat amount; gains on qualifying shareholdings in the first five years taxed normally | [TUIR art. 24-bis](https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.del.presidente.della.repubblica:1986-12-22;917~art24bis!vig=) |",
      "line": 28,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [
    "una facoltà e non un obbligo"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/24-native.txt",
  "source_key": "24",
  "source_sha256": "f269944909ea5b81276e26a92a90cef9b6fec643f09b28c7087d39f4f10e6802",
  "source_version_basis": "Dated23May2017Circular17/EactualFinanceMinistry-hostedbody, ownoperativePartIII3–4read16Nov2026; onlytheprocedureandassigned5.2jurisdictionlimitationreused, notoldamounts/timing/taxrates."
}
```

### IT-DURATION-REVOCATION

Revocable,max15yearsfromfirstperiod;late/partial/nonpaymentendsregime,nofreshoption,pastyearsprotected;mainexitendsfamily,familydefaultnotmain.

```json
{
  "act_article_or_scope": "TUIR24bis(4)wholeand6relatedfamilylimbs",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "complete_condition_paraphrase": "Revocable,max15yearsfromfirstperiod;late/partial/nonpaymentendsregime,nofreshoption,pastyearsprotected;mainexitendsfamily,familydefaultnotmain.",
  "id": "IT-DURATION-REVOCATION",
  "official_url": "https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.del.presidente.della.repubblica:1986-12-22;917~art24bis!vig=",
  "public_law": true,
  "quote_mode": "Short exact source-language extracts, whitespace normalized only; complete material conditional scope personally read, no invented requirement to reproduce full paragraphs.",
  "sections": [
    {
      "actual_text": "The option can be revoked and in any case ends after fifteen years from the first tax period of the option. It also ends if the substitute tax is not paid, or paid only in part, on time. Revocation or loss bars a new option. Revocation or loss for the main person also ends the regime for the family members; a family member's own non-payment does not end it for the main person ([TUIR art. 24-bis, commi 4 and 6](https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.del.presidente.della.repubblica:1986-12-22;917~art24bis!vig=)).",
      "line": 101
    },
    {
      "actual_text": "| Italy | Flat tax on foreign income, article 24-bis TUIR | A person who moves tax residence to Italy and was not Italian resident for at least nine of the ten tax periods before the option starts; option/eligibility evidence required; ruling optional under agency procedure, see below | EUR 300,000 a year; EUR 50,000 a year for each family member included (for moves from 1 January 2026) | Ends after 15 years at most; revocable | Foreign income covered by the flat amount; gains on qualifying shareholdings in the first five years taxed normally | [TUIR art. 24-bis](https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.del.presidente.della.repubblica:1986-12-22;917~art24bis!vig=) |",
      "line": 28,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [
    "decorsi quindici anni"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/03.txt",
  "source_key": "03",
  "source_sha256": "c53869ede25f183fddeb9be10108dad8aef118fea03e5261c497a55c335883a5",
  "source_version_basis": "Actual current official source personally read16November2026; operative scope and material neighbours recorded, not download-only."
}
```

### IT-COUNTRY-EXCLUSIONS-FAMILY

Countryexclusionsordinarytax+foreigncreditonlythen;article433eligiblefamilyindividuallymeets1,lastjurisdictionsdisclosed;familyoptoutavailable.

```json
{
  "act_article_or_scope": "TUIR24bis(5)–(6)whole",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "complete_condition_paraphrase": "Countryexclusionsordinarytax+foreigncreditonlythen;article433eligiblefamilyindividuallymeets1,lastjurisdictionsdisclosed;familyoptoutavailable.",
  "id": "IT-COUNTRY-EXCLUSIONS-FAMILY",
  "official_url": "https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.del.presidente.della.repubblica:1986-12-22;917~art24bis!vig=",
  "public_law": true,
  "quote_mode": "Short exact source-language extracts, whitespace normalized only; complete material conditional scope personally read, no invented requirement to reproduce full paragraphs.",
  "sections": [
    {
      "actual_text": "The fixed amount is due for each tax period, whatever the income, in one payment by the balance date for income tax. It can be extended to family members within article 433 of the civil code who themselves meet the nine-of-ten test, at a lower amount for each. Gains on qualifying shareholdings (article 67(1)(c)) realised in the first five tax periods of the option are NOT covered and are taxed under the ordinary rules. The person may exclude one or more foreign countries: income from those countries is then taxed normally, with a foreign tax credit ([TUIR art. 24-bis, commi 1, 2, 5 and 6](https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.del.presidente.della.repubblica:1986-12-22;917~art24bis!vig=)).",
      "line": 99
    },
    {
      "actual_text": "| Italy | Flat tax on foreign income, article 24-bis TUIR | A person who moves tax residence to Italy and was not Italian resident for at least nine of the ten tax periods before the option starts; option/eligibility evidence required; ruling optional under agency procedure, see below | EUR 300,000 a year; EUR 50,000 a year for each family member included (for moves from 1 January 2026) | Ends after 15 years at most; revocable | Foreign income covered by the flat amount; gains on qualifying shareholdings in the first five years taxed normally | [TUIR art. 24-bis](https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.del.presidente.della.repubblica:1986-12-22;917~art24bis!vig=) |",
      "line": 28,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [
    "di cui all'articolo 433 del codice civile"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/03.txt",
  "source_key": "03",
  "source_sha256": "c53869ede25f183fddeb9be10108dad8aef118fea03e5261c497a55c335883a5",
  "source_version_basis": "Actual current official source personally read16November2026; operative scope and material neighbours recorded, not download-only."
}
```

### IT-2026-COHORT

Replaces200000→300000and25000→50000,applyingtoCivilCode43residencetransfersfromlawentry;current24bisdates1Jan2026. Notallpriorcohortssame.

```json
{
  "act_article_or_scope": "L199/2025article1commi25–26wholewith24/27neighbours; entryclausemustseparatelyconfirmdatefromcurrent24bis1Jan2026version",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "complete_condition_paraphrase": "Replaces200000→300000and25000→50000,applyingtoCivilCode43residencetransfersfromlawentry;current24bisdates1Jan2026. Notallpriorcohortssame.",
  "id": "IT-2026-COHORT",
  "official_url": "https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:legge:2025-12-30;199",
  "public_law": true,
  "quote_mode": "Short exact source-language extracts, whitespace normalized only; complete material conditional scope personally read, no invented requirement to reproduce full paragraphs.",
  "sections": [
    {
      "actual_text": "**Which amount applies.** Legge 199/2025 replaced the earlier amounts in the table below with the amounts above, but only for people who move residence to Italy (article 43 of the civil code) from the date the law entered into force, 1 January 2026 ([Legge 199/2025, art. 1, commi 25 and 26](https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:legge:2025-12-30;199)). A family that moved before that date is on the amount in force when it moved. The pages read for this Guide do not print the amount for each earlier arrival date, so confirm it from the person's own ruling and payment records.",
      "line": 108
    },
    {
      "actual_text": "| Amount replaced for the main person | EUR 200,000 | \"le parole: «euro 200.000» sono sostituite dalle seguenti\" | https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:legge:2025-12-30;199 |",
      "line": 112
    },
    {
      "actual_text": "| Amount replaced for each family member | EUR 25,000 | \"le parole: «euro 25.000» sono sostituite dalle seguenti\" | https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:legge:2025-12-30;199 |",
      "line": 113
    },
    {
      "actual_text": "| Italy | Flat tax on foreign income, article 24-bis TUIR | A person who moves tax residence to Italy and was not Italian resident for at least nine of the ten tax periods before the option starts; option/eligibility evidence required; ruling optional under agency procedure, see below | EUR 300,000 a year; EUR 50,000 a year for each family member included (for moves from 1 January 2026) | Ends after 15 years at most; revocable | Foreign income covered by the flat amount; gains on qualifying shareholdings in the first five years taxed normally | [TUIR art. 24-bis](https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.del.presidente.della.repubblica:1986-12-22;917~art24bis!vig=) |",
      "line": 28,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [
    "«euro 200.000»"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/12.txt",
  "source_key": "12",
  "source_sha256": "a527779065384fffe3a3a494cad56ea138abcd8b592a39612b3444afccb4d4fc",
  "source_version_basis": "Actual current official source personally read16November2026; operative scope and material neighbours recorded, not download-only."
}
```

### IT-RW-IVIE-IVAFE

Option/familyRW/IVIE/IVAFEexemptionandnoncumulationnamedresearcher/impatriateregimes;actualagency5.2restrictsexcludedjurisdictions.

```json
{
  "act_article_or_scope": "24bisupdate181quotesL232/2016article1commi153–154; readwhole24bisnotes",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "complete_condition_paraphrase": "Option/familyRW/IVIE/IVAFEexemptionandnoncumulationnamedresearcher/impatriateregimes;actualagency5.2restrictsexcludedjurisdictions.",
  "id": "IT-RW-IVIE-IVAFE",
  "official_url": "https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.del.presidente.della.repubblica:1986-12-22;917~art24bis!vig=",
  "public_law": true,
  "quote_mode": "Short exact source-language extracts, whitespace normalized only; complete material conditional scope personally read, no invented requirement to reproduce full paragraphs.",
  "sections": [
    {
      "actual_text": "**Italy traps.** People under the option, and the family members included, are exempt from the foreign-asset reporting (quadro RW) and from the taxes on foreign property and foreign financial assets (IVIE and IVAFE) for covered jurisdictions in the years of the option; the agency says excluded jurisdictions retain ordinary monitoring/IVIE/IVAFE obligations (Circular 17/E Part III section 5.2). The same dated agency section 5.2 also retains RW reporting for qualified participations during the first five periods; confirm the applicable current return instructions before filing. The statute basis is Legge 232/2016, art. 1, comma 153, quoted in the notes to [TUIR art. 24-bis](https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.del.presidente.della.repubblica:1986-12-22;917~art24bis!vig=). Inheritance and gift tax require their own scope analysis and are not computed in this comparison; see `succession-and-forced-heirship-compared`. The regime cannot be combined with the researcher/impatriate regimes named in that statutory note; do not generalise the 2017 list to every later incentive. Italian-source income stays taxable under the ordinary rules.",
      "line": 115
    },
    {
      "actual_text": "| Italy | Flat tax on foreign income, article 24-bis TUIR | A person who moves tax residence to Italy and was not Italian resident for at least nine of the ten tax periods before the option starts; option/eligibility evidence required; ruling optional under agency procedure, see below | EUR 300,000 a year; EUR 50,000 a year for each family member included (for moves from 1 January 2026) | Ends after 15 years at most; revocable | Foreign income covered by the flat amount; gains on qualifying shareholdings in the first five years taxed normally | [TUIR art. 24-bis](https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.del.presidente.della.repubblica:1986-12-22;917~art24bis!vig=) |",
      "line": 28,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [
    "non sono tenuti"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/03.txt",
  "source_key": "03",
  "source_sha256": "c53869ede25f183fddeb9be10108dad8aef118fea03e5261c497a55c335883a5",
  "source_version_basis": "Actual current official source personally read16November2026; operative scope and material neighbours recorded, not download-only."
}
```

### IT-RW-ADMIN-QUALIFIED-GAINS

CoveredjurisdictionsRW/IVIE/IVAFEexemption,excludedjurisdictionsordinaryobligations;datedagencyalsoRWforqualifiedparticipationsduringfirst5periods;currentfilinginstructionsseparatelyneeded.

```json
{
  "act_article_or_scope": "Circular17/EPartIII5.2wholeplus5.1end/5.3opening,native545–556,read16Nov2026",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "complete_condition_paraphrase": "CoveredjurisdictionsRW/IVIE/IVAFEexemption,excludedjurisdictionsordinaryobligations;datedagencyalsoRWforqualifiedparticipationsduringfirst5periods;currentfilinginstructionsseparatelyneeded.",
  "id": "IT-RW-ADMIN-QUALIFIED-GAINS",
  "official_url": "https://def.finanze.it/DocTribFrontend/getPrassiDetail.do?id=%7BDF6F5518-4D04-4718-B611-8AC67E8C08BC%7D",
  "public_law": false,
  "quote_mode": "Short exact source-language extracts, whitespace normalized only; complete material conditional scope personally read, no invented requirement to reproduce full paragraphs.",
  "sections": [
    {
      "actual_text": "**Italy traps.** People under the option, and the family members included, are exempt from the foreign-asset reporting (quadro RW) and from the taxes on foreign property and foreign financial assets (IVIE and IVAFE) for covered jurisdictions in the years of the option; the agency says excluded jurisdictions retain ordinary monitoring/IVIE/IVAFE obligations (Circular 17/E Part III section 5.2). The same dated agency section 5.2 also retains RW reporting for qualified participations during the first five periods; confirm the applicable current return instructions before filing. The statute basis is Legge 232/2016, art. 1, comma 153, quoted in the notes to [TUIR art. 24-bis](https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.del.presidente.della.repubblica:1986-12-22;917~art24bis!vig=). Inheritance and gift tax require their own scope analysis and are not computed in this comparison; see `succession-and-forced-heirship-compared`. The regime cannot be combined with the researcher/impatriate regimes named in that statutory note; do not generalise the 2017 list to every later incentive. Italian-source income stays taxable under the ordinary rules.",
      "line": 115
    },
    {
      "actual_text": "| Italy | Flat tax on foreign income, article 24-bis TUIR | A person who moves tax residence to Italy and was not Italian resident for at least nine of the ten tax periods before the option starts; option/eligibility evidence required; ruling optional under agency procedure, see below | EUR 300,000 a year; EUR 50,000 a year for each family member included (for moves from 1 January 2026) | Ends after 15 years at most; revocable | Foreign income covered by the flat amount; gains on qualifying shareholdings in the first five years taxed normally | [TUIR art. 24-bis](https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.del.presidente.della.repubblica:1986-12-22;917~art24bis!vig=) |",
      "line": 28,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [
    "primi 5 periodi"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/24-native.txt",
  "source_key": "24",
  "source_sha256": "f269944909ea5b81276e26a92a90cef9b6fec643f09b28c7087d39f4f10e6802",
  "source_version_basis": "Dated23May2017Circular17/EactualFinanceMinistry-hostedbody, assigned5.2wholepersonallyread;notunqualifiedcurrentreturnmanual."
}
```

### PT-IFICI-ENTRY-ACTIVITIES

NewPTresidentnotinanyprevious5years,7activity/employercategories;NHRprevious/currentandRegressarbar;CFI22(2)cjobsexcluded;singleuse.

```json
{
  "act_article_or_scope": "EBF58A(1)(a)–(g)whole,10–12; articlewhole1–12read",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "complete_condition_paraphrase": "EBF58-A(1) requires Portuguese tax residence under CIRS16(1)/(2), no Portuguese residence in any previous5years, and an actual listed activity. (a) Higher-education teaching/scientific research including scientific employment in national science/technology-system entities, structures and networks, plus jobs or board membership in recognised technology/innovation centres under DL126-B/2021. (b) Qualified jobs or board membership within contractual productive-investment benefits under CFIChapterII. (c) Prescribed highly-qualified professions at either (i) companies with relevant applications in the entry year or prior5financialyears benefiting or having benefited from RFAI/CFIChapterIII, OR (ii) industrial/service companies with a prescribed main CAE and exports of at least50%ofturnover in the entry year or either prior2years. (d) Other qualified jobs/board membership in entities whose economic activities AICEP or IAPMEI recognises as relevant to the national economy, especially productive investment/regional-asymmetry reduction. (e) Research/development personnel costs eligible under CFI37(1)(b)SIFIDE. (f) Jobs/board membership at startups certified under Law21/2023. (g) Jobs/other activities by Azores/Madeira tax residents under regional legislative-decree terms. Paragraph10 bars anyone benefiting/having benefited from NHR or electing CIRS12-A;11 excludes income from jobs under CFI22(2)(c);12 permits only one use. Each category has its own qualification/employer gate, not an automatic exemption for any person holding a job.",
  "id": "PT-IFICI-ENTRY-ACTIVITIES",
  "official_url": "https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/bf_rep/Pages/EBF58A.aspx",
  "public_law": true,
  "quote_mode": "Short exact source-language extracts, whitespace normalized only; complete material conditional scope personally read, no invented requirement to reproduce full paragraphs.",
  "sections": [
    {
      "actual_text": "IFICI covers a person who becomes Portuguese tax resident, was not resident in Portugal in any of the previous five years, AND carries on one of the listed activities: higher-education teaching and scientific research, qualified jobs under contractual investment benefits, highly qualified professions in qualifying companies, other qualified jobs in entities recognised by AICEP or IAPMEI, R&D staff, jobs in certified startups, or jobs in the Azores and Madeira. The special rate applies to net employment and self-employment income (categories A and B) from those activities, for 10 consecutive years from the year of registration as a resident, and only in years in which the person is resident and still earns income from a qualifying activity. It can be used only once. EBF58-A(4) permits a new eligible activity begun within six months after the former activity; missed years do not restart the ten-year clock, and late registration only gives the remaining period (5)/(7). Jobs covered by CFI22(2)(c) are excluded (11); each activity also has its own employer/qualification rules and registration authority (1)/(6). ([EBF article 58.º-A, n.os 1 to 3 and 12](https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/bf_rep/Pages/EBF58A.aspx))",
      "line": 121
    },
    {
      "actual_text": "| Portugal | IFICI (incentive for scientific research and innovation) | A person who becomes Portuguese resident, was not resident in any of the previous five years, works in a listed qualifying activity, never had the non-habitual resident regime and never opted for the Regressar regime | 20% on net employment and self-employment income from the qualifying activity; foreign income generally exempt, 35% if paid from a blacklisted territory | 10 consecutive years from registration as resident | Only qualifying work income at the special rate; not a regime for passive wealth | [EBF58-A](https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/bf_rep/Pages/EBF58A.aspx); [AT leaflet2](https://info.portaldasfinancas.gov.pt/pt/apoio_contribuinte/Folhetos_informativos/Documents/incentivos_investigacao.pdf) |",
      "line": 29,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [
    "qualquer dos cinco anos anteriores"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/04.txt",
  "source_key": "04",
  "source_sha256": "8b0e1e554fde0c8bf715354a478e4668f296d6f5f8d2ea81e7c8f6a4baaa96f2",
  "source_version_basis": "Actual current official source personally read16November2026; operative scope and material neighbours recorded, not download-only."
}
```

### PT-IFICI-RATE-DURATION

20%neteligibleA/Boptaggregation,10consecutiveyearsfromresidentregistration;annualresident+activity,6monthnewactivitybridge,remainingyearsresume,lateregistrationremainderonly,registrationauthorityspecific.

```json
{
  "act_article_or_scope": "EBF58A(2)–(7)wholewith1/8–12neighbours",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "complete_condition_paraphrase": "20%neteligibleA/Boptaggregation,10consecutiveyearsfromresidentregistration;annualresident+activity,6monthnewactivitybridge,remainingyearsresume,lateregistrationremainderonly,registrationauthorityspecific.",
  "id": "PT-IFICI-RATE-DURATION",
  "official_url": "https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/bf_rep/Pages/EBF58A.aspx",
  "public_law": true,
  "quote_mode": "Short exact source-language extracts, whitespace normalized only; complete material conditional scope personally read, no invented requirement to reproduce full paragraphs.",
  "sections": [
    {
      "actual_text": "IFICI covers a person who becomes Portuguese tax resident, was not resident in Portugal in any of the previous five years, AND carries on one of the listed activities: higher-education teaching and scientific research, qualified jobs under contractual investment benefits, highly qualified professions in qualifying companies, other qualified jobs in entities recognised by AICEP or IAPMEI, R&D staff, jobs in certified startups, or jobs in the Azores and Madeira. The special rate applies to net employment and self-employment income (categories A and B) from those activities, for 10 consecutive years from the year of registration as a resident, and only in years in which the person is resident and still earns income from a qualifying activity. It can be used only once. EBF58-A(4) permits a new eligible activity begun within six months after the former activity; missed years do not restart the ten-year clock, and late registration only gives the remaining period (5)/(7). Jobs covered by CFI22(2)(c) are excluded (11); each activity also has its own employer/qualification rules and registration authority (1)/(6). ([EBF article 58.º-A, n.os 1 to 3 and 12](https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/bf_rep/Pages/EBF58A.aspx))",
      "line": 121
    },
    {
      "actual_text": "| Special IRS rate on net category A and B income from the qualifying activity | 20% | \"à taxa especial de 20 % sobre os rendimentos líquidos das categorias A e B\" | https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/bf_rep/Pages/EBF58A.aspx |",
      "line": 125
    },
    {
      "actual_text": "| Portugal | IFICI (incentive for scientific research and innovation) | A person who becomes Portuguese resident, was not resident in any of the previous five years, works in a listed qualifying activity, never had the non-habitual resident regime and never opted for the Regressar regime | 20% on net employment and self-employment income from the qualifying activity; foreign income generally exempt, 35% if paid from a blacklisted territory | 10 consecutive years from registration as resident | Only qualifying work income at the special rate; not a regime for passive wealth | [EBF58-A](https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/bf_rep/Pages/EBF58A.aspx); [AT leaflet2](https://info.portaldasfinancas.gov.pt/pt/apoio_contribuinte/Folhetos_informativos/Documents/incentivos_investigacao.pdf) |",
      "line": 29,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [
    "à taxa especial de 20 %"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/04.txt",
  "source_key": "04",
  "source_sha256": "8b0e1e554fde0c8bf715354a478e4668f296d6f5f8d2ea81e7c8f6a4baaa96f2",
  "source_version_basis": "Actual current official source personally read16November2026; operative scope and material neighbours recorded, not download-only."
}
```

### PT-FOREIGN-EXEMPTION

ForeignA/B/E/F/GexemptionwithprogressionforIFICI;listedterritorynonresidentnoPEpayerscrossref71/72;Hnotlisted,noautomaticforeignpensionexemption.

```json
{
  "act_article_or_scope": "CIRS81(4)–(5)whole,1–3/6–10neighboursread",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "complete_condition_paraphrase": "ForeignA/B/E/F/GexemptionwithprogressionforIFICI;listedterritorynonresidentnoPEpayerscrossref71/72;Hnotlisted,noautomaticforeignpensionexemption.",
  "id": "PT-FOREIGN-EXEMPTION",
  "official_url": "https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/cirs_rep/Pages/irs81.aspx",
  "public_law": true,
  "quote_mode": "Short exact source-language extracts, whitespace normalized only; complete material conditional scope personally read, no invented requirement to reproduce full paragraphs.",
  "sections": [
    {
      "actual_text": "CIRS81(4) specifies exemption with progression for foreign A/B/E/F/G categories;81(5) cross-refers the listed-territory35% provisions in71(17)(b)/(c) and72(18). The Tax Authority's IFICI leaflet explains that foreign employment, self-employment, investment, rental and capital-gain income (categories A, B, E, F and G) of IFICI beneficiaries is, as a rule, exempt. Foreign income of any category paid by an entity in a territory with a clearly more favourable tax regime is taxed at the rate in the table below. ([CIRS81](https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/cirs_rep/Pages/irs81.aspx); [CIRS71](https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/cirs_rep/Pages/irs71.aspx); [CIRS72](https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/cirs_rep/Pages/irs72.aspx); [AT leaflet, IFICI](https://info.portaldasfinancas.gov.pt/pt/apoio_contribuinte/Folhetos_informativos/Documents/incentivos_investigacao.pdf))",
      "line": 127
    },
    {
      "actual_text": "**Portugal traps.** IFICI needs a qualifying job or activity. A family living on investment income, with no member in a listed activity, does not qualify on the pages read here. The leaflet's list of generally exempt foreign categories (A, B, E, F and G) does not include pensions (category H); confirm the treatment of a foreign pension before relying on IFICI for it.",
      "line": 133
    },
    {
      "actual_text": "| Portugal | IFICI (incentive for scientific research and innovation) | A person who becomes Portuguese resident, was not resident in any of the previous five years, works in a listed qualifying activity, never had the non-habitual resident regime and never opted for the Regressar regime | 20% on net employment and self-employment income from the qualifying activity; foreign income generally exempt, 35% if paid from a blacklisted territory | 10 consecutive years from registration as resident | Only qualifying work income at the special rate; not a regime for passive wealth | [EBF58-A](https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/bf_rep/Pages/EBF58A.aspx); [AT leaflet2](https://info.portaldasfinancas.gov.pt/pt/apoio_contribuinte/Folhetos_informativos/Documents/incentivos_investigacao.pdf) |",
      "line": 29,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [
    "categorias A, B, E, F e G"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/25.txt",
  "source_key": "25",
  "source_sha256": "371ca6d226280598d8eb2cd2897a8daab5d92f84effa2e0f140f7e665a68a465",
  "source_version_basis": "Actual current official source personally read16November2026; operative scope and material neighbours recorded, not download-only."
}
```

### PT-LEAFLET-35-SCOPE

Agencydescribesforeignanycategorylistedterritory35%withholding/autonomous;noHcategoryinforeignexemptlist;actualstatutorycrossrefsandclassificationcontrol.

```json
{
  "act_article_or_scope": "ATIFICIleafletPDFpp2–3whole,benefits/exclusions/generalconditionswithfootnotes; activitytablesonlyboundedpagesread",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "complete_condition_paraphrase": "Agencydescribesforeignanycategorylistedterritory35%withholding/autonomous;noHcategoryinforeignexemptlist;actualstatutorycrossrefsandclassificationcontrol.",
  "id": "PT-LEAFLET-35-SCOPE",
  "official_url": "https://info.portaldasfinancas.gov.pt/pt/apoio_contribuinte/Folhetos_informativos/Documents/incentivos_investigacao.pdf",
  "public_law": false,
  "quote_mode": "Short exact source-language extracts, whitespace normalized only; complete material conditional scope personally read, no invented requirement to reproduce full paragraphs.",
  "sections": [
    {
      "actual_text": "CIRS81(4) specifies exemption with progression for foreign A/B/E/F/G categories;81(5) cross-refers the listed-territory35% provisions in71(17)(b)/(c) and72(18). The Tax Authority's IFICI leaflet explains that foreign employment, self-employment, investment, rental and capital-gain income (categories A, B, E, F and G) of IFICI beneficiaries is, as a rule, exempt. Foreign income of any category paid by an entity in a territory with a clearly more favourable tax regime is taxed at the rate in the table below. ([CIRS81](https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/cirs_rep/Pages/irs81.aspx); [CIRS71](https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/cirs_rep/Pages/irs71.aspx); [CIRS72](https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/cirs_rep/Pages/irs72.aspx); [AT leaflet, IFICI](https://info.portaldasfinancas.gov.pt/pt/apoio_contribuinte/Folhetos_informativos/Documents/incentivos_investigacao.pdf))",
      "line": 127
    },
    {
      "actual_text": "| Rate on foreign income received in Malta | 15% | Foreign income received in Malta; exact family and minimum conditions in rule5. | https://legislation.mt/eli/sl/123.148/eng/pdf |",
      "line": 79
    },
    {
      "actual_text": "| Rate on foreign income paid from a blacklisted territory | 35% | The actual leaflet describes a withholding or autonomous 35% charge, subject to the statutory category rules. | https://info.portaldasfinancas.gov.pt/pt/apoio_contribuinte/Folhetos_informativos/Documents/incentivos_investigacao.pdf |",
      "line": 131
    },
    {
      "actual_text": "| Portugal | IFICI (incentive for scientific research and innovation) | A person who becomes Portuguese resident, was not resident in any of the previous five years, works in a listed qualifying activity, never had the non-habitual resident regime and never opted for the Regressar regime | 20% on net employment and self-employment income from the qualifying activity; foreign income generally exempt, 35% if paid from a blacklisted territory | 10 consecutive years from registration as resident | Only qualifying work income at the special rate; not a regime for passive wealth | [EBF58-A](https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/bf_rep/Pages/EBF58A.aspx); [AT leaflet2](https://info.portaldasfinancas.gov.pt/pt/apoio_contribuinte/Folhetos_informativos/Documents/incentivos_investigacao.pdf) |",
      "line": 29,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [
    "rendimentos obtidos no estrangeiro de quaisquer categorias"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/13.txt",
  "source_key": "13",
  "source_sha256": "e1b136bced0cf9bf03927b6a609f273433d427ef9104f0f8a82ed9687bdb7bde",
  "source_version_basis": "ActualofficialIFICIleaflet,read16Nov2026pp2–3andboundedactivitytablep7;notclaimwhole14pages."
}
```

### PT-BLACKLIST-WITHHOLDING

35%finalwithholdinglistedterritorycapital/securitiesincomeunderactual71scope;notfree-standinguniversaleveryforeigncashreceipt.

```json
{
  "act_article_or_scope": "CIRS71(17)(b)/(c)and1(a)/(b)definitionsplus16neighbour",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "complete_condition_paraphrase": "35%finalwithholdinglistedterritorycapital/securitiesincomeunderactual71scope;notfree-standinguniversaleveryforeigncashreceipt.",
  "id": "PT-BLACKLIST-WITHHOLDING",
  "official_url": "https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/cirs_rep/Pages/irs71.aspx",
  "public_law": true,
  "quote_mode": "Short exact source-language extracts, whitespace normalized only; complete material conditional scope personally read, no invented requirement to reproduce full paragraphs.",
  "sections": [
    {
      "actual_text": "CIRS81(4) specifies exemption with progression for foreign A/B/E/F/G categories;81(5) cross-refers the listed-territory35% provisions in71(17)(b)/(c) and72(18). The Tax Authority's IFICI leaflet explains that foreign employment, self-employment, investment, rental and capital-gain income (categories A, B, E, F and G) of IFICI beneficiaries is, as a rule, exempt. Foreign income of any category paid by an entity in a territory with a clearly more favourable tax regime is taxed at the rate in the table below. ([CIRS81](https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/cirs_rep/Pages/irs81.aspx); [CIRS71](https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/cirs_rep/Pages/irs71.aspx); [CIRS72](https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/cirs_rep/Pages/irs72.aspx); [AT leaflet, IFICI](https://info.portaldasfinancas.gov.pt/pt/apoio_contribuinte/Folhetos_informativos/Documents/incentivos_investigacao.pdf))",
      "line": 127
    },
    {
      "actual_text": "| Portugal | IFICI (incentive for scientific research and innovation) | A person who becomes Portuguese resident, was not resident in any of the previous five years, works in a listed qualifying activity, never had the non-habitual resident regime and never opted for the Regressar regime | 20% on net employment and self-employment income from the qualifying activity; foreign income generally exempt, 35% if paid from a blacklisted territory | 10 consecutive years from registration as resident | Only qualifying work income at the special rate; not a regime for passive wealth | [EBF58-A](https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/bf_rep/Pages/EBF58A.aspx); [AT leaflet2](https://info.portaldasfinancas.gov.pt/pt/apoio_contribuinte/Folhetos_informativos/Documents/incentivos_investigacao.pdf) |",
      "line": 29,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [
    "taxa liberatória de 35 %"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/31.txt",
  "source_key": "31",
  "source_sha256": "5883909b7efefd541124fdbc6576b854213e3a2b04af005c5a37c380fc88c93e",
  "source_version_basis": "Actual current official source personally read16November2026; operative scope and material neighbours recorded, not download-only."
}
```

### PT-BLACKLIST-AUTONOMOUS

35%autonomoustaxactualcapital/securities/trust/nonresidentpropertygaincategories, current19repealed;notanindiscriminateforeignpensionrate.

```json
{
  "act_article_or_scope": "CIRS72(18)(a)–(d)wholeand17/19–22neighbours",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "complete_condition_paraphrase": "35%autonomoustaxactualcapital/securities/trust/nonresidentpropertygaincategories, current19repealed;notanindiscriminateforeignpensionrate.",
  "id": "PT-BLACKLIST-AUTONOMOUS",
  "official_url": "https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/cirs_rep/Pages/irs72.aspx",
  "public_law": true,
  "quote_mode": "Short exact source-language extracts, whitespace normalized only; complete material conditional scope personally read, no invented requirement to reproduce full paragraphs.",
  "sections": [
    {
      "actual_text": "CIRS81(4) specifies exemption with progression for foreign A/B/E/F/G categories;81(5) cross-refers the listed-territory35% provisions in71(17)(b)/(c) and72(18). The Tax Authority's IFICI leaflet explains that foreign employment, self-employment, investment, rental and capital-gain income (categories A, B, E, F and G) of IFICI beneficiaries is, as a rule, exempt. Foreign income of any category paid by an entity in a territory with a clearly more favourable tax regime is taxed at the rate in the table below. ([CIRS81](https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/cirs_rep/Pages/irs81.aspx); [CIRS71](https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/cirs_rep/Pages/irs71.aspx); [CIRS72](https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/cirs_rep/Pages/irs72.aspx); [AT leaflet, IFICI](https://info.portaldasfinancas.gov.pt/pt/apoio_contribuinte/Folhetos_informativos/Documents/incentivos_investigacao.pdf))",
      "line": 127
    },
    {
      "actual_text": "| Portugal | IFICI (incentive for scientific research and innovation) | A person who becomes Portuguese resident, was not resident in any of the previous five years, works in a listed qualifying activity, never had the non-habitual resident regime and never opted for the Regressar regime | 20% on net employment and self-employment income from the qualifying activity; foreign income generally exempt, 35% if paid from a blacklisted territory | 10 consecutive years from registration as resident | Only qualifying work income at the special rate; not a regime for passive wealth | [EBF58-A](https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/bf_rep/Pages/EBF58A.aspx); [AT leaflet2](https://info.portaldasfinancas.gov.pt/pt/apoio_contribuinte/Folhetos_informativos/Documents/incentivos_investigacao.pdf) |",
      "line": 29,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [
    "autonomamente à taxa de 35 %"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/32.txt",
  "source_key": "32",
  "source_sha256": "86a63ab7387fd24f5690bd10857a89e74cf67f14f0f99bb6f56a5c6b31f82683",
  "source_version_basis": "Actual current official source personally read16November2026; operative scope and material neighbours recorded, not download-only."
}
```

### CH-EXPENDITURE-ELIGIBILITY

NonSwiss,firstunlimitedtaxor10yearbreak,noSwissgainfulactivity;bothlegally/factuallyunseparatedspousesqualify.

```json
{
  "act_article_or_scope": "DBG14(1)–(2)wholewith13/15neighbours,20260101compilationPDFpp7–8read/p7visual",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "complete_condition_paraphrase": "NonSwiss,firstunlimitedtaxor10yearbreak,noSwissgainfulactivity;bothlegally/factuallyunseparatedspousesqualify.",
  "id": "CH-EXPENDITURE-ELIGIBILITY",
  "official_url": "https://www.fedlex.admin.ch/filestore/fedlex.data.admin.ch/eli/cc/1991/1184_1184_1184/20260101/de/pdf-a/fedlex-data-admin-ch-eli-cc-1991-1184_1184_1184-20260101-de-pdf-a.pdf",
  "public_law": true,
  "quote_mode": "Short exact source-language extracts, whitespace normalized only; complete material conditional scope personally read, no invented requirement to reproduce full paragraphs.",
  "sections": [
    {
      "actual_text": "Under article 14 of the Federal Direct Tax Act (DBG), a natural person may pay a tax on expenditure instead of income tax if the person does NOT hold Swiss citizenship, AND is fully taxable in Switzerland for the first time or after a break of at least ten years, AND carries on no gainful activity in Switzerland. Spouses living together must both meet these conditions. The tax base is the person's annual worldwide living costs and those of the people they support, but at least the HIGHEST of: the fixed amount in the table below; for a person with their own household, seven times the annual rent or rental value; for others, three times the annual board and lodging price; and the gross income from Swiss sources and from income for which a Swiss treaty is used to obtain foreign tax relief. The ordinary federal tariff is then applied, without the specified article36(2bis) second-sentence reduction. CHF 435,000 is a base, not the annual tax bill. ([Federal Direct Tax Act, art. 14](https://www.fedlex.admin.ch/filestore/fedlex.data.admin.ch/eli/cc/1991/1184_1184_1184/20260101/de/pdf-a/fedlex-data-admin-ch-eli-cc-1991-1184_1184_1184-20260101-de-pdf-a.pdf))",
      "line": 137
    },
    {
      "actual_text": "| Switzerland | Taxation on expenditure (federal direct tax) | A person without Swiss citizenship, fully taxable in Switzerland for the first time or after a break of at least ten years, with no gainful activity in Switzerland; both spouses must qualify | Federal tax base at least CHF 435,000 (or a higher figure under the other limbs); cantonal amounts not printed on an allowed page | No fixed duration in article14; continuing conditions and annual indexed base | Federal tax on living expenditure instead of income; cantonal tax out of scope | [Federal Direct Tax Act, art. 14](https://www.fedlex.admin.ch/filestore/fedlex.data.admin.ch/eli/cc/1991/1184_1184_1184/20260101/de/pdf-a/fedlex-data-admin-ch-eli-cc-1991-1184_1184_1184-20260101-de-pdf-a.pdf) |",
      "line": 30,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [
    "nicht das Schweizer Bürgerrecht"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/05.txt",
  "source_key": "05",
  "source_sha256": "9fb0308ce1e6ca1b74abb702b24e27094bafe178ecf6533c4c7690132dd63109",
  "source_version_basis": "Actual current official source personally read16November2026; operative scope and material neighbours recorded, not download-only."
}
```

### CH-BASE-INDEX-435000

Highestannualworldwidelivingcosts/supportor435000,7annualrent/rentalvalueor3board/lodgingorcontrolincome;435000isbase,notbill. IndexedEFD2026amount.

```json
{
  "act_article_or_scope": "DBG14(3)(a)and6,footnote19AS2025579effective1Jan2026",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "complete_condition_paraphrase": "Highestannualworldwidelivingcosts/supportor435000,7annualrent/rentalvalueor3board/lodgingorcontrolincome;435000isbase,notbill. IndexedEFD2026amount.",
  "id": "CH-BASE-INDEX-435000",
  "official_url": "https://www.fedlex.admin.ch/filestore/fedlex.data.admin.ch/eli/cc/1991/1184_1184_1184/20260101/de/pdf-a/fedlex-data-admin-ch-eli-cc-1991-1184_1184_1184-20260101-de-pdf-a.pdf",
  "public_law": true,
  "quote_mode": "Short exact source-language extracts, whitespace normalized only; complete material conditional scope personally read, no invented requirement to reproduce full paragraphs.",
  "sections": [
    {
      "actual_text": "Under article 14 of the Federal Direct Tax Act (DBG), a natural person may pay a tax on expenditure instead of income tax if the person does NOT hold Swiss citizenship, AND is fully taxable in Switzerland for the first time or after a break of at least ten years, AND carries on no gainful activity in Switzerland. Spouses living together must both meet these conditions. The tax base is the person's annual worldwide living costs and those of the people they support, but at least the HIGHEST of: the fixed amount in the table below; for a person with their own household, seven times the annual rent or rental value; for others, three times the annual board and lodging price; and the gross income from Swiss sources and from income for which a Swiss treaty is used to obtain foreign tax relief. The ordinary federal tariff is then applied, without the specified article36(2bis) second-sentence reduction. CHF 435,000 is a base, not the annual tax bill. ([Federal Direct Tax Act, art. 14](https://www.fedlex.admin.ch/filestore/fedlex.data.admin.ch/eli/cc/1991/1184_1184_1184/20260101/de/pdf-a/fedlex-data-admin-ch-eli-cc-1991-1184_1184_1184-20260101-de-pdf-a.pdf))",
      "line": 137
    },
    {
      "actual_text": "| Minimum federal tax base, from 1 January 2026 (indexed by the Finance Department) | CHF 435,000 | \"435 000 Franken; b. für Steuerpflichtige mit eigenem Haushalt\" | https://www.fedlex.admin.ch/filestore/fedlex.data.admin.ch/eli/cc/1991/1184_1184_1184/20260101/de/pdf-a/fedlex-data-admin-ch-eli-cc-1991-1184_1184_1184-20260101-de-pdf-a.pdf |",
      "line": 141
    },
    {
      "actual_text": "| Switzerland | Taxation on expenditure (federal direct tax) | A person without Swiss citizenship, fully taxable in Switzerland for the first time or after a break of at least ten years, with no gainful activity in Switzerland; both spouses must qualify | Federal tax base at least CHF 435,000 (or a higher figure under the other limbs); cantonal amounts not printed on an allowed page | No fixed duration in article14; continuing conditions and annual indexed base | Federal tax on living expenditure instead of income; cantonal tax out of scope | [Federal Direct Tax Act, art. 14](https://www.fedlex.admin.ch/filestore/fedlex.data.admin.ch/eli/cc/1991/1184_1184_1184/20260101/de/pdf-a/fedlex-data-admin-ch-eli-cc-1991-1184_1184_1184-20260101-de-pdf-a.pdf) |",
      "line": 30,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [
    "435 000 Franken"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/05.txt",
  "source_key": "05",
  "source_sha256": "9fb0308ce1e6ca1b74abb702b24e27094bafe178ecf6533c4c7690132dd63109",
  "source_version_basis": "Actual current official source personally read16November2026; operative scope and material neighbours recorded, not download-only."
}
```

### CH-CONTROL-INCOME-TREATY

ControlbaseSwissreal/movable/capital/IP/pensionandforeigntreatyreliefincome;ordinarytariffwithoutspecifiedreduction;modifiedtreatyallallocatedsource-stateincomeconditional;nocantonratesinvented.

```json
{
  "act_article_or_scope": "DBG14(3)(d)(1)–(6)/4–5whole,13/15neighbours",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "complete_condition_paraphrase": "ControlbaseSwissreal/movable/capital/IP/pensionandforeigntreatyreliefincome;ordinarytariffwithoutspecifiedreduction;modifiedtreatyallallocatedsource-stateincomeconditional;nocantonratesinvented.",
  "id": "CH-CONTROL-INCOME-TREATY",
  "official_url": "https://www.fedlex.admin.ch/filestore/fedlex.data.admin.ch/eli/cc/1991/1184_1184_1184/20260101/de/pdf-a/fedlex-data-admin-ch-eli-cc-1991-1184_1184_1184-20260101-de-pdf-a.pdf",
  "public_law": true,
  "quote_mode": "Short exact source-language extracts, whitespace normalized only; complete material conditional scope personally read, no invented requirement to reproduce full paragraphs.",
  "sections": [
    {
      "actual_text": "Under article 14 of the Federal Direct Tax Act (DBG), a natural person may pay a tax on expenditure instead of income tax if the person does NOT hold Swiss citizenship, AND is fully taxable in Switzerland for the first time or after a break of at least ten years, AND carries on no gainful activity in Switzerland. Spouses living together must both meet these conditions. The tax base is the person's annual worldwide living costs and those of the people they support, but at least the HIGHEST of: the fixed amount in the table below; for a person with their own household, seven times the annual rent or rental value; for others, three times the annual board and lodging price; and the gross income from Swiss sources and from income for which a Swiss treaty is used to obtain foreign tax relief. The ordinary federal tariff is then applied, without the specified article36(2bis) second-sentence reduction. CHF 435,000 is a base, not the annual tax bill. ([Federal Direct Tax Act, art. 14](https://www.fedlex.admin.ch/filestore/fedlex.data.admin.ch/eli/cc/1991/1184_1184_1184/20260101/de/pdf-a/fedlex-data-admin-ch-eli-cc-1991-1184_1184_1184-20260101-de-pdf-a.pdf))",
      "line": 137
    },
    {
      "actual_text": "**Switzerland traps.** The figure above is the FEDERAL minimum base only. Cantonal and communal tax on expenditure, cantonal wealth tax and cantonal inheritance and gift taxes are set by each canton and are not printed on an allowed page; they are outside this Guide. Some treaty countries grant relief only if Switzerland taxes the income at the rate for total income; then the base also includes all income from that country (article 14(5)). Any gainful activity in Switzerland breaks the conditions.",
      "line": 143
    },
    {
      "actual_text": "| Switzerland | Taxation on expenditure (federal direct tax) | A person without Swiss citizenship, fully taxable in Switzerland for the first time or after a break of at least ten years, with no gainful activity in Switzerland; both spouses must qualify | Federal tax base at least CHF 435,000 (or a higher figure under the other limbs); cantonal amounts not printed on an allowed page | No fixed duration in article14; continuing conditions and annual indexed base | Federal tax on living expenditure instead of income; cantonal tax out of scope | [Federal Direct Tax Act, art. 14](https://www.fedlex.admin.ch/filestore/fedlex.data.admin.ch/eli/cc/1991/1184_1184_1184/20260101/de/pdf-a/fedlex-data-admin-ch-eli-cc-1991-1184_1184_1184-20260101-de-pdf-a.pdf) |",
      "line": 30,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [
    "der Summe der Bruttoerträge"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/05.txt",
  "source_key": "05",
  "source_sha256": "9fb0308ce1e6ca1b74abb702b24e27094bafe178ecf6533c4c7690132dd63109",
  "source_version_basis": "Actual current official source personally read16November2026; operative scope and material neighbours recorded, not download-only."
}
```

### AE-CT-TURNOVER-DEFINITIONS

NaturalpersonconductingUAEbusiness,totalturnover>1mGregoriancalendaryear;definedwage/ownpersonalnonlicensednoncommercialinvestment/nonlicensedrealestateexcludedwhateveramount;physicalresidencenotsameCTresidence.

```json
{
  "act_article_or_scope": "FTA CTGTNP1Nov2023definitionspp5–6/3.2–3.5pp11–14 and3.9wholepp23–24, ownallassignedparagraphsread",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "complete_condition_paraphrase": "UAE business-activity route requires total annual turnover above AED1m with the defined wage/personal-investment/real-estate exclusions. This is not the only possible corporate-tax nexus: section3.4 explicitly points to the separate nonresident State-Sourced Income route; section3.9 defines UAE resident/PE/activity-asset-capital-right/service sources and distinguishes withholding from PE/resident treatment. The Guide does not compute that separate route or infer natural-person income-tax immunity from residence.",
  "id": "AE-CT-TURNOVER-DEFINITIONS",
  "official_url": "https://tax.gov.ae/Datafolder/Files/Guides/CT/Taxation%20of%20natural%20persons%20-%2025%2011%202023.pdf",
  "public_law": false,
  "quote_mode": "Short exact source-language extracts, whitespace normalized only; complete material conditional scope personally read, no invented requirement to reproduce full paragraphs.",
  "sections": [
    {
      "actual_text": "For the UAE business-activity route, a natural person falls within Corporate Tax where total business turnover exceeds the threshold in the table below in a calendar year. A separate non-resident State-Sourced Income nexus also exists and is outside this business-turnover comparison. Statutorily defined wages, personal investment income and real estate investment income are disregarded and are not subject to Corporate Tax, whatever the amount. ([FTA, Taxation of natural persons under the Corporate Tax Law](https://tax.gov.ae/Datafolder/Files/Guides/CT/Taxation%20of%20natural%20persons%20-%2025%2011%202023.pdf))",
      "line": 149
    },
    {
      "actual_text": "| Business turnover in the UAE above which an individual is within Corporate Tax (per calendar year) | AED 1 million | Total UAE business turnover, not taxable profit; statutory income exclusions apply. | https://tax.gov.ae/Datafolder/Files/Guides/CT/Taxation%20of%20natural%20persons%20-%2025%2011%202023.pdf |",
      "line": 153
    },
    {
      "actual_text": "**UAE traps.** The investment exclusions require the actual definitions: personal investment must be for the person's own account, outside licensing and commercial-business treatment; the real-estate exclusion depends on activity not conducted or required through a licence. Corporate-tax residence for a natural person conducting business differs from physical/visa residence. The AED 1 million turnover gate is not a taxable-profit allowance.  UAE residence under these tests does not by itself end residence in the old country; the old country's own rules and any treaty decide that. See `uk-to-uae-relocation-tax` and `exit-taxes-when-a-family-moves`.",
      "line": 155
    },
    {
      "actual_text": "| UAE | No special regime; tax residence under Cabinet Decision No. 85 of 2022 | A natural person who meets one of the residence tests (see the UAE section) | Corporate Tax on a natural person’s UAE business activity uses a turnover threshold above AED 1 million; separate non-resident State-Sourced Income cases are outside this comparison; a personal income tax rate is not printed on an allowed page | Relevant rolling 12-month windows for day routes; factual conditions otherwise | Wages, personal investment income and real estate investment income are not subject to Corporate Tax | [CD85residence](https://tax.gov.ae/Datafolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing.pdf); [FTA natural persons3.3](https://tax.gov.ae/Datafolder/Files/Guides/CT/Taxation%20of%20natural%20persons%20-%2025%2011%202023.pdf) |",
      "line": 31,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [
    "exceeds AED 1 million"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/14.txt",
  "source_key": "14",
  "source_sha256": "4063508239da1a974514d2232264e1c6f1ea093788349b230a8f552805d18260",
  "source_version_basis": "ActualofficialFTAGuideNov2023CTGTNP1, ownassigneddefinitions/3.2–3.5and3.9wholepersonallyread16Nov2026;notwholeguideorupdated2026filingmanual."
}
```

### AE-CD85-4(1)

Native Art4(1) contains usual/main residence and centre of personal/financial interests plus authentic ORministerialconditions wording; English unofficial conjunction differs, so do not silently substitute it.

```json
{
  "act_article_or_scope": "CabinetDecision85/2022 Art4(1), native PDFpage2",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "id": "AE-CD85-4(1)",
  "official_url": "https://tax.gov.ae/DataFolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing%20Ar.pdf",
  "public_law": true,
  "quote_mode": "Own manual literal visual transcription; complete assigned clause losslessly split into <=25whitespace-word fragments",
  "reuse_scope": "Exact finalresidence6a18a2c0lawunit/sourcehash personallyread16Nov2026 and correctionsverified; applicabilityonce,boundedreuse, no freshwholecountryPASSinferred.",
  "section": {
    "actual_text": "**UAE.** Keep the alternative natural-person routes in Cabinet Decision 85/2022 Art 4 separate: the native usual/main-place-of-residence and personal/financial-interests route OR the ministerial-criteria limb in Art4(1); 183 or more days during a relevant consecutive 12 months; or the qualified 90-or-more-day route, with nationality/residence-permit and permanent-home or employment/business conditions. MD 27/2023 supplies detailed meanings and counting rules. The Arabic Art 4(1) wording must be retained accurately; the authority-hosted English translation is expressly unofficial and differs in its conjunction. Treaty certificates require the relevant treaty's separate test. [Native Cabinet Decision](https://tax.gov.ae/DataFolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing%20Ar.pdf); [native MD 27](https://tax.gov.ae//Datafolder/Files/Legislation/Corporate%20Tax/Ministerial%20Decision%20No.%2027%20of%202023%20-%20For%20publishing%20Arabic.pdf).",
    "line": 47
  },
  "sections": [
    {
      "actual_text": "A natural person is a UAE tax resident if ANY of these applies: (1) the usual or primary residence AND centre of financial/personal interests are in the UAE, OR the ministerial conditions/criteria are met; (2) physical presence in the UAE of 183 days or more within the relevant 12 consecutive months; or (3) physical presence of 90 days or more within the relevant 12 consecutive months by a UAE national, a holder of a valid UAE residence permit or a GCC national, who also has a permanent place of residence in the UAE OR carries on employment or business there. A tax resident may apply to the Federal Tax Authority for a tax residency certificate. (The linked English text expressly says it is not an official translation. The Arabic decision and MinisterialDecision27/2023 definitions govern: day parts count, continuous availability matters for a permanent home, and normal employment/business facts must be established; treaty-certificate criteria are separate under article6. [Actual ArabicCD85](https://tax.gov.ae/DataFolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing%20Ar.pdf); [MD27Arabic](https://tax.gov.ae//Datafolder/Files/Legislation/Corporate%20Tax/Ministerial%20Decision%20No.%2027%20of%202023%20-%20For%20publishing%20Arabic.pdf); [Cabinet Decision No. 85 of 2022, articles 4 and 5](https://tax.gov.ae/Datafolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing.pdf))",
      "line": 147
    },
    {
      "actual_text": "| UAE | No special regime; tax residence under Cabinet Decision No. 85 of 2022 | A natural person who meets one of the residence tests (see the UAE section) | Corporate Tax on a natural person’s UAE business activity uses a turnover threshold above AED 1 million; separate non-resident State-Sourced Income cases are outside this comparison; a personal income tax rate is not printed on an allowed page | Relevant rolling 12-month windows for day routes; factual conditions otherwise | Wages, personal investment income and real estate investment income are not subject to Corporate Tax | [CD85residence](https://tax.gov.ae/Datafolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing.pdf); [FTA natural persons3.3](https://tax.gov.ae/Datafolder/Files/Guides/CT/Taxation%20of%20natural%20persons%20-%2025%2011%202023.pdf) |",
      "line": 31,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [
    "إذا كان مكان إقامته المعتاد أو الأساسي ومركز مصالحه المالية والشخصية في الدولة أو يستوفي الشروط والمعايير التي يحددها قرار من الوزير."
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/ae-cd85-native.pdf",
  "source_sha256": "80f036e4dd7877836cb0b194409a3dbb784344b9171f5f66b170c97387eefd35",
  "source_version_basis": "Actual native PDF personally visually read; no unofficial English substitution",
  "visual_evidence_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/ae-cd85-native-visual-read.json"
}
```

### AE-CD85-4(2)

UAE183or more days in relevant12consecutive months is a separate naturalperson residence route.

```json
{
  "act_article_or_scope": "CabinetDecision85/2022 Art4(2), native PDFpage2",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "id": "AE-CD85-4(2)",
  "official_url": "https://tax.gov.ae/DataFolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing%20Ar.pdf",
  "public_law": true,
  "quote_mode": "Own manual literal visual transcription; complete assigned clause losslessly split into <=25whitespace-word fragments",
  "reuse_scope": "Exact finalresidence6a18a2c0lawunit/sourcehash personallyread16Nov2026 and correctionsverified; applicabilityonce,boundedreuse, no freshwholecountryPASSinferred.",
  "section": {
    "actual_text": "**UAE.** Keep the alternative natural-person routes in Cabinet Decision 85/2022 Art 4 separate: the native usual/main-place-of-residence and personal/financial-interests route OR the ministerial-criteria limb in Art4(1); 183 or more days during a relevant consecutive 12 months; or the qualified 90-or-more-day route, with nationality/residence-permit and permanent-home or employment/business conditions. MD 27/2023 supplies detailed meanings and counting rules. The Arabic Art 4(1) wording must be retained accurately; the authority-hosted English translation is expressly unofficial and differs in its conjunction. Treaty certificates require the relevant treaty's separate test. [Native Cabinet Decision](https://tax.gov.ae/DataFolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing%20Ar.pdf); [native MD 27](https://tax.gov.ae//Datafolder/Files/Legislation/Corporate%20Tax/Ministerial%20Decision%20No.%2027%20of%202023%20-%20For%20publishing%20Arabic.pdf).",
    "line": 47
  },
  "sections": [
    {
      "actual_text": "A natural person is a UAE tax resident if ANY of these applies: (1) the usual or primary residence AND centre of financial/personal interests are in the UAE, OR the ministerial conditions/criteria are met; (2) physical presence in the UAE of 183 days or more within the relevant 12 consecutive months; or (3) physical presence of 90 days or more within the relevant 12 consecutive months by a UAE national, a holder of a valid UAE residence permit or a GCC national, who also has a permanent place of residence in the UAE OR carries on employment or business there. A tax resident may apply to the Federal Tax Authority for a tax residency certificate. (The linked English text expressly says it is not an official translation. The Arabic decision and MinisterialDecision27/2023 definitions govern: day parts count, continuous availability matters for a permanent home, and normal employment/business facts must be established; treaty-certificate criteria are separate under article6. [Actual ArabicCD85](https://tax.gov.ae/DataFolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing%20Ar.pdf); [MD27Arabic](https://tax.gov.ae//Datafolder/Files/Legislation/Corporate%20Tax/Ministerial%20Decision%20No.%2027%20of%202023%20-%20For%20publishing%20Arabic.pdf); [Cabinet Decision No. 85 of 2022, articles 4 and 5](https://tax.gov.ae/Datafolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing.pdf))",
      "line": 147
    },
    {
      "actual_text": "| UAE | No special regime; tax residence under Cabinet Decision No. 85 of 2022 | A natural person who meets one of the residence tests (see the UAE section) | Corporate Tax on a natural person’s UAE business activity uses a turnover threshold above AED 1 million; separate non-resident State-Sourced Income cases are outside this comparison; a personal income tax rate is not printed on an allowed page | Relevant rolling 12-month windows for day routes; factual conditions otherwise | Wages, personal investment income and real estate investment income are not subject to Corporate Tax | [CD85residence](https://tax.gov.ae/Datafolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing.pdf); [FTA natural persons3.3](https://tax.gov.ae/Datafolder/Files/Guides/CT/Taxation%20of%20natural%20persons%20-%2025%2011%202023.pdf) |",
      "line": 31,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [
    "إذا كان متواجدًا"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/ae-cd85-native.pdf",
  "source_sha256": "80f036e4dd7877836cb0b194409a3dbb784344b9171f5f66b170c97387eefd35",
  "source_version_basis": "Actual native PDF personally visually read; no unofficial English substitution",
  "visual_evidence_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/ae-cd85-native-visual-read.json"
}
```

### AE-CD85-4(3)

UAE90or more days route also requires UAE/GCCnationality or valid residence permit plus a stated home/work limb.

```json
{
  "act_article_or_scope": "CabinetDecision85/2022 Art4(3), native PDFpage2",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "id": "AE-CD85-4(3)",
  "official_url": "https://tax.gov.ae/DataFolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing%20Ar.pdf",
  "public_law": true,
  "quote_mode": "Own manual literal visual transcription; complete assigned clause losslessly split into <=25whitespace-word fragments",
  "reuse_scope": "Exact finalresidence6a18a2c0lawunit/sourcehash personallyread16Nov2026 and correctionsverified; applicabilityonce,boundedreuse, no freshwholecountryPASSinferred.",
  "section": {
    "actual_text": "**UAE.** Keep the alternative natural-person routes in Cabinet Decision 85/2022 Art 4 separate: the native usual/main-place-of-residence and personal/financial-interests route OR the ministerial-criteria limb in Art4(1); 183 or more days during a relevant consecutive 12 months; or the qualified 90-or-more-day route, with nationality/residence-permit and permanent-home or employment/business conditions. MD 27/2023 supplies detailed meanings and counting rules. The Arabic Art 4(1) wording must be retained accurately; the authority-hosted English translation is expressly unofficial and differs in its conjunction. Treaty certificates require the relevant treaty's separate test. [Native Cabinet Decision](https://tax.gov.ae/DataFolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing%20Ar.pdf); [native MD 27](https://tax.gov.ae//Datafolder/Files/Legislation/Corporate%20Tax/Ministerial%20Decision%20No.%2027%20of%202023%20-%20For%20publishing%20Arabic.pdf).",
    "line": 47
  },
  "sections": [
    {
      "actual_text": "A natural person is a UAE tax resident if ANY of these applies: (1) the usual or primary residence AND centre of financial/personal interests are in the UAE, OR the ministerial conditions/criteria are met; (2) physical presence in the UAE of 183 days or more within the relevant 12 consecutive months; or (3) physical presence of 90 days or more within the relevant 12 consecutive months by a UAE national, a holder of a valid UAE residence permit or a GCC national, who also has a permanent place of residence in the UAE OR carries on employment or business there. A tax resident may apply to the Federal Tax Authority for a tax residency certificate. (The linked English text expressly says it is not an official translation. The Arabic decision and MinisterialDecision27/2023 definitions govern: day parts count, continuous availability matters for a permanent home, and normal employment/business facts must be established; treaty-certificate criteria are separate under article6. [Actual ArabicCD85](https://tax.gov.ae/DataFolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing%20Ar.pdf); [MD27Arabic](https://tax.gov.ae//Datafolder/Files/Legislation/Corporate%20Tax/Ministerial%20Decision%20No.%2027%20of%202023%20-%20For%20publishing%20Arabic.pdf); [Cabinet Decision No. 85 of 2022, articles 4 and 5](https://tax.gov.ae/Datafolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing.pdf))",
      "line": 147
    },
    {
      "actual_text": "| UAE | No special regime; tax residence under Cabinet Decision No. 85 of 2022 | A natural person who meets one of the residence tests (see the UAE section) | Corporate Tax on a natural person’s UAE business activity uses a turnover threshold above AED 1 million; separate non-resident State-Sourced Income cases are outside this comparison; a personal income tax rate is not printed on an allowed page | Relevant rolling 12-month windows for day routes; factual conditions otherwise | Wages, personal investment income and real estate investment income are not subject to Corporate Tax | [CD85residence](https://tax.gov.ae/Datafolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing.pdf); [FTA natural persons3.3](https://tax.gov.ae/Datafolder/Files/Guides/CT/Taxation%20of%20natural%20persons%20-%2025%2011%202023.pdf) |",
      "line": 31,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/ae-cd85-native.pdf",
  "source_sha256": "80f036e4dd7877836cb0b194409a3dbb784344b9171f5f66b170c97387eefd35",
  "source_version_basis": "Actual native PDF personally visually read; no unofficial English substitution",
  "visual_evidence_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/ae-cd85-native-visual-read.json"
}
```

### AE-CD85-4(3)(a)

Qualified90day route can use a permanenthome in UAE.

```json
{
  "act_article_or_scope": "CabinetDecision85/2022 Art4(3)(a), native PDFpage2",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "id": "AE-CD85-4(3)(a)",
  "official_url": "https://tax.gov.ae/DataFolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing%20Ar.pdf",
  "public_law": true,
  "quote_mode": "Own manual literal visual transcription; complete assigned clause losslessly split into <=25whitespace-word fragments",
  "reuse_scope": "Exact finalresidence6a18a2c0lawunit/sourcehash personallyread16Nov2026 and correctionsverified; applicabilityonce,boundedreuse, no freshwholecountryPASSinferred.",
  "section": {
    "actual_text": "**UAE.** Keep the alternative natural-person routes in Cabinet Decision 85/2022 Art 4 separate: the native usual/main-place-of-residence and personal/financial-interests route OR the ministerial-criteria limb in Art4(1); 183 or more days during a relevant consecutive 12 months; or the qualified 90-or-more-day route, with nationality/residence-permit and permanent-home or employment/business conditions. MD 27/2023 supplies detailed meanings and counting rules. The Arabic Art 4(1) wording must be retained accurately; the authority-hosted English translation is expressly unofficial and differs in its conjunction. Treaty certificates require the relevant treaty's separate test. [Native Cabinet Decision](https://tax.gov.ae/DataFolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing%20Ar.pdf); [native MD 27](https://tax.gov.ae//Datafolder/Files/Legislation/Corporate%20Tax/Ministerial%20Decision%20No.%2027%20of%202023%20-%20For%20publishing%20Arabic.pdf).",
    "line": 47
  },
  "sections": [
    {
      "actual_text": "A natural person is a UAE tax resident if ANY of these applies: (1) the usual or primary residence AND centre of financial/personal interests are in the UAE, OR the ministerial conditions/criteria are met; (2) physical presence in the UAE of 183 days or more within the relevant 12 consecutive months; or (3) physical presence of 90 days or more within the relevant 12 consecutive months by a UAE national, a holder of a valid UAE residence permit or a GCC national, who also has a permanent place of residence in the UAE OR carries on employment or business there. A tax resident may apply to the Federal Tax Authority for a tax residency certificate. (The linked English text expressly says it is not an official translation. The Arabic decision and MinisterialDecision27/2023 definitions govern: day parts count, continuous availability matters for a permanent home, and normal employment/business facts must be established; treaty-certificate criteria are separate under article6. [Actual ArabicCD85](https://tax.gov.ae/DataFolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing%20Ar.pdf); [MD27Arabic](https://tax.gov.ae//Datafolder/Files/Legislation/Corporate%20Tax/Ministerial%20Decision%20No.%2027%20of%202023%20-%20For%20publishing%20Arabic.pdf); [Cabinet Decision No. 85 of 2022, articles 4 and 5](https://tax.gov.ae/Datafolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing.pdf))",
      "line": 147
    },
    {
      "actual_text": "| UAE | No special regime; tax residence under Cabinet Decision No. 85 of 2022 | A natural person who meets one of the residence tests (see the UAE section) | Corporate Tax on a natural person’s UAE business activity uses a turnover threshold above AED 1 million; separate non-resident State-Sourced Income cases are outside this comparison; a personal income tax rate is not printed on an allowed page | Relevant rolling 12-month windows for day routes; factual conditions otherwise | Wages, personal investment income and real estate investment income are not subject to Corporate Tax | [CD85residence](https://tax.gov.ae/Datafolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing.pdf); [FTA natural persons3.3](https://tax.gov.ae/Datafolder/Files/Guides/CT/Taxation%20of%20natural%20persons%20-%2025%2011%202023.pdf) |",
      "line": 31,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/ae-cd85-native.pdf",
  "source_sha256": "80f036e4dd7877836cb0b194409a3dbb784344b9171f5f66b170c97387eefd35",
  "source_version_basis": "Actual native PDF personally visually read; no unofficial English substitution",
  "visual_evidence_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/ae-cd85-native-visual-read.json"
}
```

### AE-CD85-4(3)(b)

Qualified90day route alternatively uses UAEemployment/business.

```json
{
  "act_article_or_scope": "CabinetDecision85/2022 Art4(3)(b), native PDFpage2",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "id": "AE-CD85-4(3)(b)",
  "official_url": "https://tax.gov.ae/DataFolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing%20Ar.pdf",
  "public_law": true,
  "quote_mode": "Own manual literal visual transcription; complete assigned clause losslessly split into <=25whitespace-word fragments",
  "reuse_scope": "Exact finalresidence6a18a2c0lawunit/sourcehash personallyread16Nov2026 and correctionsverified; applicabilityonce,boundedreuse, no freshwholecountryPASSinferred.",
  "section": {
    "actual_text": "**UAE.** Keep the alternative natural-person routes in Cabinet Decision 85/2022 Art 4 separate: the native usual/main-place-of-residence and personal/financial-interests route OR the ministerial-criteria limb in Art4(1); 183 or more days during a relevant consecutive 12 months; or the qualified 90-or-more-day route, with nationality/residence-permit and permanent-home or employment/business conditions. MD 27/2023 supplies detailed meanings and counting rules. The Arabic Art 4(1) wording must be retained accurately; the authority-hosted English translation is expressly unofficial and differs in its conjunction. Treaty certificates require the relevant treaty's separate test. [Native Cabinet Decision](https://tax.gov.ae/DataFolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing%20Ar.pdf); [native MD 27](https://tax.gov.ae//Datafolder/Files/Legislation/Corporate%20Tax/Ministerial%20Decision%20No.%2027%20of%202023%20-%20For%20publishing%20Arabic.pdf).",
    "line": 47
  },
  "sections": [
    {
      "actual_text": "A natural person is a UAE tax resident if ANY of these applies: (1) the usual or primary residence AND centre of financial/personal interests are in the UAE, OR the ministerial conditions/criteria are met; (2) physical presence in the UAE of 183 days or more within the relevant 12 consecutive months; or (3) physical presence of 90 days or more within the relevant 12 consecutive months by a UAE national, a holder of a valid UAE residence permit or a GCC national, who also has a permanent place of residence in the UAE OR carries on employment or business there. A tax resident may apply to the Federal Tax Authority for a tax residency certificate. (The linked English text expressly says it is not an official translation. The Arabic decision and MinisterialDecision27/2023 definitions govern: day parts count, continuous availability matters for a permanent home, and normal employment/business facts must be established; treaty-certificate criteria are separate under article6. [Actual ArabicCD85](https://tax.gov.ae/DataFolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing%20Ar.pdf); [MD27Arabic](https://tax.gov.ae//Datafolder/Files/Legislation/Corporate%20Tax/Ministerial%20Decision%20No.%2027%20of%202023%20-%20For%20publishing%20Arabic.pdf); [Cabinet Decision No. 85 of 2022, articles 4 and 5](https://tax.gov.ae/Datafolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing.pdf))",
      "line": 147
    },
    {
      "actual_text": "| UAE | No special regime; tax residence under Cabinet Decision No. 85 of 2022 | A natural person who meets one of the residence tests (see the UAE section) | Corporate Tax on a natural person’s UAE business activity uses a turnover threshold above AED 1 million; separate non-resident State-Sourced Income cases are outside this comparison; a personal income tax rate is not printed on an allowed page | Relevant rolling 12-month windows for day routes; factual conditions otherwise | Wages, personal investment income and real estate investment income are not subject to Corporate Tax | [CD85residence](https://tax.gov.ae/Datafolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing.pdf); [FTA natural persons3.3](https://tax.gov.ae/Datafolder/Files/Guides/CT/Taxation%20of%20natural%20persons%20-%2025%2011%202023.pdf) |",
      "line": 31,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/ae-cd85-native.pdf",
  "source_sha256": "80f036e4dd7877836cb0b194409a3dbb784344b9171f5f66b170c97387eefd35",
  "source_version_basis": "Actual native PDF personally visually read; no unofficial English substitution",
  "visual_evidence_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/ae-cd85-native-visual-read.json"
}
```

### AE-CD85-6(1)

An internationalagreement specific tax-residence test controls residence for that agreement.

```json
{
  "act_article_or_scope": "CabinetDecision85/2022 Art6(1), native PDFpage3",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "id": "AE-CD85-6(1)",
  "official_url": "https://tax.gov.ae/DataFolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing%20Ar.pdf",
  "public_law": true,
  "quote_mode": "Own manual literal visual transcription; complete assigned clause losslessly split into <=25whitespace-word fragments",
  "reuse_scope": "Exact finalresidence6a18a2c0lawunit/sourcehash personallyread16Nov2026 and correctionsverified; applicabilityonce,boundedreuse, no freshwholecountryPASSinferred.",
  "section": {
    "actual_text": "**UAE.** Keep the alternative natural-person routes in Cabinet Decision 85/2022 Art 4 separate: the native usual/main-place-of-residence and personal/financial-interests route OR the ministerial-criteria limb in Art4(1); 183 or more days during a relevant consecutive 12 months; or the qualified 90-or-more-day route, with nationality/residence-permit and permanent-home or employment/business conditions. MD 27/2023 supplies detailed meanings and counting rules. The Arabic Art 4(1) wording must be retained accurately; the authority-hosted English translation is expressly unofficial and differs in its conjunction. Treaty certificates require the relevant treaty's separate test. [Native Cabinet Decision](https://tax.gov.ae/DataFolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing%20Ar.pdf); [native MD 27](https://tax.gov.ae//Datafolder/Files/Legislation/Corporate%20Tax/Ministerial%20Decision%20No.%2027%20of%202023%20-%20For%20publishing%20Arabic.pdf).",
    "line": 47
  },
  "sections": [
    {
      "actual_text": "A natural person is a UAE tax resident if ANY of these applies: (1) the usual or primary residence AND centre of financial/personal interests are in the UAE, OR the ministerial conditions/criteria are met; (2) physical presence in the UAE of 183 days or more within the relevant 12 consecutive months; or (3) physical presence of 90 days or more within the relevant 12 consecutive months by a UAE national, a holder of a valid UAE residence permit or a GCC national, who also has a permanent place of residence in the UAE OR carries on employment or business there. A tax resident may apply to the Federal Tax Authority for a tax residency certificate. (The linked English text expressly says it is not an official translation. The Arabic decision and MinisterialDecision27/2023 definitions govern: day parts count, continuous availability matters for a permanent home, and normal employment/business facts must be established; treaty-certificate criteria are separate under article6. [Actual ArabicCD85](https://tax.gov.ae/DataFolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing%20Ar.pdf); [MD27Arabic](https://tax.gov.ae//Datafolder/Files/Legislation/Corporate%20Tax/Ministerial%20Decision%20No.%2027%20of%202023%20-%20For%20publishing%20Arabic.pdf); [Cabinet Decision No. 85 of 2022, articles 4 and 5](https://tax.gov.ae/Datafolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing.pdf))",
      "line": 147
    },
    {
      "actual_text": "| UAE | No special regime; tax residence under Cabinet Decision No. 85 of 2022 | A natural person who meets one of the residence tests (see the UAE section) | Corporate Tax on a natural person’s UAE business activity uses a turnover threshold above AED 1 million; separate non-resident State-Sourced Income cases are outside this comparison; a personal income tax rate is not printed on an allowed page | Relevant rolling 12-month windows for day routes; factual conditions otherwise | Wages, personal investment income and real estate investment income are not subject to Corporate Tax | [CD85residence](https://tax.gov.ae/Datafolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing.pdf); [FTA natural persons3.3](https://tax.gov.ae/Datafolder/Files/Guides/CT/Taxation%20of%20natural%20persons%20-%2025%2011%202023.pdf) |",
      "line": 31,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/ae-cd85-native.pdf",
  "source_sha256": "80f036e4dd7877836cb0b194409a3dbb784344b9171f5f66b170c97387eefd35",
  "source_version_basis": "Actual native PDF personally visually read; no unofficial English substitution",
  "visual_evidence_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/ae-cd85-native-visual-read.json"
}
```

### AE-CD85-9

CabinetDecision85effective1March2023.

```json
{
  "act_article_or_scope": "CabinetDecision85/2022 Art9, native PDFpage3",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "id": "AE-CD85-9",
  "official_url": "https://tax.gov.ae/DataFolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing%20Ar.pdf",
  "public_law": true,
  "quote_mode": "Own manual literal visual transcription; complete assigned clause losslessly split into <=25whitespace-word fragments",
  "reuse_scope": "Exact finalresidence6a18a2c0lawunit/sourcehash personallyread16Nov2026 and correctionsverified; applicabilityonce,boundedreuse, no freshwholecountryPASSinferred.",
  "section": {
    "actual_text": "**UAE.** Keep the alternative natural-person routes in Cabinet Decision 85/2022 Art 4 separate: the native usual/main-place-of-residence and personal/financial-interests route OR the ministerial-criteria limb in Art4(1); 183 or more days during a relevant consecutive 12 months; or the qualified 90-or-more-day route, with nationality/residence-permit and permanent-home or employment/business conditions. MD 27/2023 supplies detailed meanings and counting rules. The Arabic Art 4(1) wording must be retained accurately; the authority-hosted English translation is expressly unofficial and differs in its conjunction. Treaty certificates require the relevant treaty's separate test. [Native Cabinet Decision](https://tax.gov.ae/DataFolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing%20Ar.pdf); [native MD 27](https://tax.gov.ae//Datafolder/Files/Legislation/Corporate%20Tax/Ministerial%20Decision%20No.%2027%20of%202023%20-%20For%20publishing%20Arabic.pdf).",
    "line": 47
  },
  "sections": [
    {
      "actual_text": "A natural person is a UAE tax resident if ANY of these applies: (1) the usual or primary residence AND centre of financial/personal interests are in the UAE, OR the ministerial conditions/criteria are met; (2) physical presence in the UAE of 183 days or more within the relevant 12 consecutive months; or (3) physical presence of 90 days or more within the relevant 12 consecutive months by a UAE national, a holder of a valid UAE residence permit or a GCC national, who also has a permanent place of residence in the UAE OR carries on employment or business there. A tax resident may apply to the Federal Tax Authority for a tax residency certificate. (The linked English text expressly says it is not an official translation. The Arabic decision and MinisterialDecision27/2023 definitions govern: day parts count, continuous availability matters for a permanent home, and normal employment/business facts must be established; treaty-certificate criteria are separate under article6. [Actual ArabicCD85](https://tax.gov.ae/DataFolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing%20Ar.pdf); [MD27Arabic](https://tax.gov.ae//Datafolder/Files/Legislation/Corporate%20Tax/Ministerial%20Decision%20No.%2027%20of%202023%20-%20For%20publishing%20Arabic.pdf); [Cabinet Decision No. 85 of 2022, articles 4 and 5](https://tax.gov.ae/Datafolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing.pdf))",
      "line": 147
    },
    {
      "actual_text": "| UAE | No special regime; tax residence under Cabinet Decision No. 85 of 2022 | A natural person who meets one of the residence tests (see the UAE section) | Corporate Tax on a natural person’s UAE business activity uses a turnover threshold above AED 1 million; separate non-resident State-Sourced Income cases are outside this comparison; a personal income tax rate is not printed on an allowed page | Relevant rolling 12-month windows for day routes; factual conditions otherwise | Wages, personal investment income and real estate investment income are not subject to Corporate Tax | [CD85residence](https://tax.gov.ae/Datafolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing.pdf); [FTA natural persons3.3](https://tax.gov.ae/Datafolder/Files/Guides/CT/Taxation%20of%20natural%20persons%20-%2025%2011%202023.pdf) |",
      "line": 31,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/ae-cd85-native.pdf",
  "source_sha256": "80f036e4dd7877836cb0b194409a3dbb784344b9171f5f66b170c97387eefd35",
  "source_version_basis": "Actual native PDF personally visually read; no unofficial English substitution",
  "visual_evidence_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/ae-cd85-native-visual-read.json"
}
```

### AE-MD27-1

Calendar days/months; every full or partial day physically present counts in the relevant consecutive12months; actual presence days need not themselves be consecutive for183/90day tests.

```json
{
  "act_article_or_scope": "MinisterialDecision27/2023 Art3(1)–(3), actualArabicPDFp2",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "correction_own_read_on": "2026-11-16",
  "final_native_delta_evidence": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/final-native-delta/resolutions.json",
  "id": "AE-MD27-1",
  "official_url": "https://tax.gov.ae//Datafolder/Files/Legislation/Corporate%20Tax/Ministerial%20Decision%20No.%2027%20of%202023%20-%20For%20publishing%20Arabic.pdf",
  "public_law": true,
  "quote_mode": "Full assigned actual public-law operative clause, losslessly split into ordered contiguous native fragments <=25 words and <=240 characters; manually read operative scope and neighbours.",
  "reuse_scope": "Exact finalresidence6a18a2c0lawunit/sourcehash personallyread16Nov2026 and correctionsverified; applicabilityonce,boundedreuse, no freshwholecountryPASSinferred.",
  "section": {
    "actual_text": "**UAE.** Keep the alternative natural-person routes in Cabinet Decision 85/2022 Art 4 separate: the native usual/main-place-of-residence and personal/financial-interests route OR the ministerial-criteria limb in Art4(1); 183 or more days during a relevant consecutive 12 months; or the qualified 90-or-more-day route, with nationality/residence-permit and permanent-home or employment/business conditions. MD 27/2023 supplies detailed meanings and counting rules. The Arabic Art 4(1) wording must be retained accurately; the authority-hosted English translation is expressly unofficial and differs in its conjunction. Treaty certificates require the relevant treaty's separate test. [Native Cabinet Decision](https://tax.gov.ae/DataFolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing%20Ar.pdf); [native MD 27](https://tax.gov.ae//Datafolder/Files/Legislation/Corporate%20Tax/Ministerial%20Decision%20No.%2027%20of%202023%20-%20For%20publishing%20Arabic.pdf).",
    "line": 47
  },
  "sections": [
    {
      "actual_text": "A natural person is a UAE tax resident if ANY of these applies: (1) the usual or primary residence AND centre of financial/personal interests are in the UAE, OR the ministerial conditions/criteria are met; (2) physical presence in the UAE of 183 days or more within the relevant 12 consecutive months; or (3) physical presence of 90 days or more within the relevant 12 consecutive months by a UAE national, a holder of a valid UAE residence permit or a GCC national, who also has a permanent place of residence in the UAE OR carries on employment or business there. A tax resident may apply to the Federal Tax Authority for a tax residency certificate. (The linked English text expressly says it is not an official translation. The Arabic decision and MinisterialDecision27/2023 definitions govern: day parts count, continuous availability matters for a permanent home, and normal employment/business facts must be established; treaty-certificate criteria are separate under article6. [Actual ArabicCD85](https://tax.gov.ae/DataFolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing%20Ar.pdf); [MD27Arabic](https://tax.gov.ae//Datafolder/Files/Legislation/Corporate%20Tax/Ministerial%20Decision%20No.%2027%20of%202023%20-%20For%20publishing%20Arabic.pdf); [Cabinet Decision No. 85 of 2022, articles 4 and 5](https://tax.gov.ae/Datafolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing.pdf))",
      "line": 147
    },
    {
      "actual_text": "| UAE | No special regime; tax residence under Cabinet Decision No. 85 of 2022 | A natural person who meets one of the residence tests (see the UAE section) | Corporate Tax on a natural person’s UAE business activity uses a turnover threshold above AED 1 million; separate non-resident State-Sourced Income cases are outside this comparison; a personal income tax rate is not printed on an allowed page | Relevant rolling 12-month windows for day routes; factual conditions otherwise | Wages, personal investment income and real estate investment income are not subject to Corporate Tax | [CD85residence](https://tax.gov.ae/Datafolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing.pdf); [FTA natural persons3.3](https://tax.gov.ae/Datafolder/Files/Guides/CT/Taxation%20of%20natural%20persons%20-%2025%2011%202023.pdf) |",
      "line": 31,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [
    "المادة (3) – احتساب المدد الزمنية 1. يقصد بمصطلح \"يوم\" اليوم التقويمي وبمصطلح \"الشهر\" الشهر التقويمي. 2. يتم احتساب جميع الأيام أو الأجزاء من اليوم"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/ae-residence27-ar.pdf",
  "source_sha256": "76a113486dc5fccf9a1c802ca4ee4932a922b4f2bef1dc2dc13ebbec04f1e6f4",
  "source_validation": "Own word-for-word comparison of every assigned manual clause against all3 actual rendered Arabic MD27 PDF pages16November2026. Art2(4) connective, Art4(1) repeated duration noun, Art6(1)(a) alternative OR and singular service, and Art6(1)(b) employment-income/part wording corrected explicitly. No substitution of unofficial English and no false machine literal-match claim for garbled Arabic PDF extraction. Source-layout line breaks are normalized; visual source diacritics are not claimed to be encoded identically.",
  "source_version_basis": "Actual native PDF personally visually read; no unofficial English substitution",
  "visual_evidence_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/ae-md27-native-visual-read.json"
}
```

### AE-MD27-2

Usual/main residence concerns the territory of habitual/normal living and the stable,more-than-transient pattern where most time is spent relative to other territories. Closest/most-significant personal/economic ties determine the interests centre; occupation,family/social/cultural ties,business/property administration and other relevant facts matter.

```json
{
  "act_article_or_scope": "MinisterialDecision27/2023 Art2(1)–(4), actualArabicPDFp1",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "correction_own_read_on": "2026-11-16",
  "final_native_delta_evidence": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/final-native-delta/resolutions.json",
  "id": "AE-MD27-2",
  "official_url": "https://tax.gov.ae//Datafolder/Files/Legislation/Corporate%20Tax/Ministerial%20Decision%20No.%2027%20of%202023%20-%20For%20publishing%20Arabic.pdf",
  "public_law": true,
  "quote_mode": "Full assigned actual public-law operative clause, losslessly split into ordered contiguous native fragments <=25 words and <=240 characters; manually read operative scope and neighbours.",
  "reuse_scope": "Exact finalresidence6a18a2c0lawunit/sourcehash personallyread16Nov2026 and correctionsverified; applicabilityonce,boundedreuse, no freshwholecountryPASSinferred.",
  "section": {
    "actual_text": "**UAE.** Keep the alternative natural-person routes in Cabinet Decision 85/2022 Art 4 separate: the native usual/main-place-of-residence and personal/financial-interests route OR the ministerial-criteria limb in Art4(1); 183 or more days during a relevant consecutive 12 months; or the qualified 90-or-more-day route, with nationality/residence-permit and permanent-home or employment/business conditions. MD 27/2023 supplies detailed meanings and counting rules. The Arabic Art 4(1) wording must be retained accurately; the authority-hosted English translation is expressly unofficial and differs in its conjunction. Treaty certificates require the relevant treaty's separate test. [Native Cabinet Decision](https://tax.gov.ae/DataFolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing%20Ar.pdf); [native MD 27](https://tax.gov.ae//Datafolder/Files/Legislation/Corporate%20Tax/Ministerial%20Decision%20No.%2027%20of%202023%20-%20For%20publishing%20Arabic.pdf).",
    "line": 47
  },
  "sections": [
    {
      "actual_text": "A natural person is a UAE tax resident if ANY of these applies: (1) the usual or primary residence AND centre of financial/personal interests are in the UAE, OR the ministerial conditions/criteria are met; (2) physical presence in the UAE of 183 days or more within the relevant 12 consecutive months; or (3) physical presence of 90 days or more within the relevant 12 consecutive months by a UAE national, a holder of a valid UAE residence permit or a GCC national, who also has a permanent place of residence in the UAE OR carries on employment or business there. A tax resident may apply to the Federal Tax Authority for a tax residency certificate. (The linked English text expressly says it is not an official translation. The Arabic decision and MinisterialDecision27/2023 definitions govern: day parts count, continuous availability matters for a permanent home, and normal employment/business facts must be established; treaty-certificate criteria are separate under article6. [Actual ArabicCD85](https://tax.gov.ae/DataFolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing%20Ar.pdf); [MD27Arabic](https://tax.gov.ae//Datafolder/Files/Legislation/Corporate%20Tax/Ministerial%20Decision%20No.%2027%20of%202023%20-%20For%20publishing%20Arabic.pdf); [Cabinet Decision No. 85 of 2022, articles 4 and 5](https://tax.gov.ae/Datafolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing.pdf))",
      "line": 147
    },
    {
      "actual_text": "| UAE | No special regime; tax residence under Cabinet Decision No. 85 of 2022 | A natural person who meets one of the residence tests (see the UAE section) | Corporate Tax on a natural person’s UAE business activity uses a turnover threshold above AED 1 million; separate non-resident State-Sourced Income cases are outside this comparison; a personal income tax rate is not printed on an allowed page | Relevant rolling 12-month windows for day routes; factual conditions otherwise | Wages, personal investment income and real estate investment income are not subject to Corporate Tax | [CD85residence](https://tax.gov.ae/Datafolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing.pdf); [FTA natural persons3.3](https://tax.gov.ae/Datafolder/Files/Guides/CT/Taxation%20of%20natural%20persons%20-%2025%2011%202023.pdf) |",
      "line": 31,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/ae-residence27-ar.pdf",
  "source_sha256": "76a113486dc5fccf9a1c802ca4ee4932a922b4f2bef1dc2dc13ebbec04f1e6f4",
  "source_validation": "Own word-for-word comparison of every assigned manual clause against all3 actual rendered Arabic MD27 PDF pages16November2026. Art2(4) connective, Art4(1) repeated duration noun, Art6(1)(a) alternative OR and singular service, and Art6(1)(b) employment-income/part wording corrected explicitly. No substitution of unofficial English and no false machine literal-match claim for garbled Arabic PDF extraction. Source-layout line breaks are normalized; visual source diacritics are not claimed to be encoded identically.",
  "source_version_basis": "Actual native PDF personally visually read; no unofficial English substitution",
  "visual_evidence_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/ae-md27-native-visual-read.json"
}
```

### AE-MD27-3

FTA discretion to disregard presence days for183/90tests requires an event outside the individual’s control,arising while already present,not reasonably foreseeable/preventable,and preventing departure as originally planned.

```json
{
  "act_article_or_scope": "MinisterialDecision27/2023 Art4(1)–(2), actualArabicPDFp2",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "correction_own_read_on": "2026-11-16",
  "final_native_delta_evidence": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/final-native-delta/resolutions.json",
  "id": "AE-MD27-3",
  "official_url": "https://tax.gov.ae//Datafolder/Files/Legislation/Corporate%20Tax/Ministerial%20Decision%20No.%2027%20of%202023%20-%20For%20publishing%20Arabic.pdf",
  "public_law": true,
  "quote_mode": "Full assigned actual public-law operative clause, losslessly split into ordered contiguous native fragments <=25 words and <=240 characters; manually read operative scope and neighbours.",
  "reuse_scope": "Exact finalresidence6a18a2c0lawunit/sourcehash personallyread16Nov2026 and correctionsverified; applicabilityonce,boundedreuse, no freshwholecountryPASSinferred.",
  "section": {
    "actual_text": "**UAE.** Keep the alternative natural-person routes in Cabinet Decision 85/2022 Art 4 separate: the native usual/main-place-of-residence and personal/financial-interests route OR the ministerial-criteria limb in Art4(1); 183 or more days during a relevant consecutive 12 months; or the qualified 90-or-more-day route, with nationality/residence-permit and permanent-home or employment/business conditions. MD 27/2023 supplies detailed meanings and counting rules. The Arabic Art 4(1) wording must be retained accurately; the authority-hosted English translation is expressly unofficial and differs in its conjunction. Treaty certificates require the relevant treaty's separate test. [Native Cabinet Decision](https://tax.gov.ae/DataFolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing%20Ar.pdf); [native MD 27](https://tax.gov.ae//Datafolder/Files/Legislation/Corporate%20Tax/Ministerial%20Decision%20No.%2027%20of%202023%20-%20For%20publishing%20Arabic.pdf).",
    "line": 47
  },
  "sections": [
    {
      "actual_text": "A natural person is a UAE tax resident if ANY of these applies: (1) the usual or primary residence AND centre of financial/personal interests are in the UAE, OR the ministerial conditions/criteria are met; (2) physical presence in the UAE of 183 days or more within the relevant 12 consecutive months; or (3) physical presence of 90 days or more within the relevant 12 consecutive months by a UAE national, a holder of a valid UAE residence permit or a GCC national, who also has a permanent place of residence in the UAE OR carries on employment or business there. A tax resident may apply to the Federal Tax Authority for a tax residency certificate. (The linked English text expressly says it is not an official translation. The Arabic decision and MinisterialDecision27/2023 definitions govern: day parts count, continuous availability matters for a permanent home, and normal employment/business facts must be established; treaty-certificate criteria are separate under article6. [Actual ArabicCD85](https://tax.gov.ae/DataFolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing%20Ar.pdf); [MD27Arabic](https://tax.gov.ae//Datafolder/Files/Legislation/Corporate%20Tax/Ministerial%20Decision%20No.%2027%20of%202023%20-%20For%20publishing%20Arabic.pdf); [Cabinet Decision No. 85 of 2022, articles 4 and 5](https://tax.gov.ae/Datafolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing.pdf))",
      "line": 147
    },
    {
      "actual_text": "| UAE | No special regime; tax residence under Cabinet Decision No. 85 of 2022 | A natural person who meets one of the residence tests (see the UAE section) | Corporate Tax on a natural person’s UAE business activity uses a turnover threshold above AED 1 million; separate non-resident State-Sourced Income cases are outside this comparison; a personal income tax rate is not printed on an allowed page | Relevant rolling 12-month windows for day routes; factual conditions otherwise | Wages, personal investment income and real estate investment income are not subject to Corporate Tax | [CD85residence](https://tax.gov.ae/Datafolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing.pdf); [FTA natural persons3.3](https://tax.gov.ae/Datafolder/Files/Guides/CT/Taxation%20of%20natural%20persons%20-%2025%2011%202023.pdf) |",
      "line": 31,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/ae-residence27-ar.pdf",
  "source_sha256": "76a113486dc5fccf9a1c802ca4ee4932a922b4f2bef1dc2dc13ebbec04f1e6f4",
  "source_validation": "Own word-for-word comparison of every assigned manual clause against all3 actual rendered Arabic MD27 PDF pages16November2026. Art2(4) connective, Art4(1) repeated duration noun, Art6(1)(a) alternative OR and singular service, and Art6(1)(b) employment-income/part wording corrected explicitly. No substitution of unofficial English and no false machine literal-match claim for garbled Arabic PDF extraction. Source-layout line breaks are normalized; visual source diacritics are not claimed to be encoded identically.",
  "source_version_basis": "Actual native PDF personally visually read; no unofficial English substitution",
  "visual_evidence_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/ae-md27-native-visual-read.json"
}
```

### AE-MD27-4

Permanent accommodation may be a house,flat,furnished room or other dwelling,but must be continuously available for regular stable occupation rather than occasional/short stays; ownership is unnecessary and rental/other occupancy can qualify.

```json
{
  "act_article_or_scope": "MinisterialDecision27/2023 Art5(1)–(3), actualArabicPDFp2",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "correction_own_read_on": "2026-11-16",
  "final_native_delta_evidence": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/final-native-delta/resolutions.json",
  "id": "AE-MD27-4",
  "official_url": "https://tax.gov.ae//Datafolder/Files/Legislation/Corporate%20Tax/Ministerial%20Decision%20No.%2027%20of%202023%20-%20For%20publishing%20Arabic.pdf",
  "public_law": true,
  "quote_mode": "Full assigned actual public-law operative clause, losslessly split into ordered contiguous native fragments <=25 words and <=240 characters; manually read operative scope and neighbours.",
  "reuse_scope": "Exact finalresidence6a18a2c0lawunit/sourcehash personallyread16Nov2026 and correctionsverified; applicabilityonce,boundedreuse, no freshwholecountryPASSinferred.",
  "section": {
    "actual_text": "**UAE.** Keep the alternative natural-person routes in Cabinet Decision 85/2022 Art 4 separate: the native usual/main-place-of-residence and personal/financial-interests route OR the ministerial-criteria limb in Art4(1); 183 or more days during a relevant consecutive 12 months; or the qualified 90-or-more-day route, with nationality/residence-permit and permanent-home or employment/business conditions. MD 27/2023 supplies detailed meanings and counting rules. The Arabic Art 4(1) wording must be retained accurately; the authority-hosted English translation is expressly unofficial and differs in its conjunction. Treaty certificates require the relevant treaty's separate test. [Native Cabinet Decision](https://tax.gov.ae/DataFolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing%20Ar.pdf); [native MD 27](https://tax.gov.ae//Datafolder/Files/Legislation/Corporate%20Tax/Ministerial%20Decision%20No.%2027%20of%202023%20-%20For%20publishing%20Arabic.pdf).",
    "line": 47
  },
  "sections": [
    {
      "actual_text": "A natural person is a UAE tax resident if ANY of these applies: (1) the usual or primary residence AND centre of financial/personal interests are in the UAE, OR the ministerial conditions/criteria are met; (2) physical presence in the UAE of 183 days or more within the relevant 12 consecutive months; or (3) physical presence of 90 days or more within the relevant 12 consecutive months by a UAE national, a holder of a valid UAE residence permit or a GCC national, who also has a permanent place of residence in the UAE OR carries on employment or business there. A tax resident may apply to the Federal Tax Authority for a tax residency certificate. (The linked English text expressly says it is not an official translation. The Arabic decision and MinisterialDecision27/2023 definitions govern: day parts count, continuous availability matters for a permanent home, and normal employment/business facts must be established; treaty-certificate criteria are separate under article6. [Actual ArabicCD85](https://tax.gov.ae/DataFolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing%20Ar.pdf); [MD27Arabic](https://tax.gov.ae//Datafolder/Files/Legislation/Corporate%20Tax/Ministerial%20Decision%20No.%2027%20of%202023%20-%20For%20publishing%20Arabic.pdf); [Cabinet Decision No. 85 of 2022, articles 4 and 5](https://tax.gov.ae/Datafolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing.pdf))",
      "line": 147
    },
    {
      "actual_text": "| UAE | No special regime; tax residence under Cabinet Decision No. 85 of 2022 | A natural person who meets one of the residence tests (see the UAE section) | Corporate Tax on a natural person’s UAE business activity uses a turnover threshold above AED 1 million; separate non-resident State-Sourced Income cases are outside this comparison; a personal income tax rate is not printed on an allowed page | Relevant rolling 12-month windows for day routes; factual conditions otherwise | Wages, personal investment income and real estate investment income are not subject to Corporate Tax | [CD85residence](https://tax.gov.ae/Datafolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing.pdf); [FTA natural persons3.3](https://tax.gov.ae/Datafolder/Files/Guides/CT/Taxation%20of%20natural%20persons%20-%2025%2011%202023.pdf) |",
      "line": 31,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/ae-residence27-ar.pdf",
  "source_sha256": "76a113486dc5fccf9a1c802ca4ee4932a922b4f2bef1dc2dc13ebbec04f1e6f4",
  "source_validation": "Own word-for-word comparison of every assigned manual clause against all3 actual rendered Arabic MD27 PDF pages16November2026. Art2(4) connective, Art4(1) repeated duration noun, Art6(1)(a) alternative OR and singular service, and Art6(1)(b) employment-income/part wording corrected explicitly. No substitution of unofficial English and no false machine literal-match claim for garbled Arabic PDF extraction. Source-layout line breaks are normalized; visual source diacritics are not claimed to be encoded identically.",
  "source_version_basis": "Actual native PDF personally visually read; no unofficial English substitution",
  "visual_evidence_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/ae-md27-native-visual-read.json"
}
```

### AE-MD27-5

Employment includes the prescribed UAE employer contract/services under direction or supervision for remuneration,or a continuing relationship deriving all/a substantial part of employment income from one party as wages for UAE work; fixed/indefinite and full/parttime can qualify; uncontracted voluntary roles excluded. Publication and effect1March2023.

```json
{
  "act_article_or_scope": "MinisterialDecision27/2023 Art6(1)–(3) andArt8, actualArabicPDFpp2–3",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "correction_own_read_on": "2026-11-16",
  "final_native_delta_evidence": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/final-native-delta/resolutions.json",
  "id": "AE-MD27-5",
  "official_url": "https://tax.gov.ae//Datafolder/Files/Legislation/Corporate%20Tax/Ministerial%20Decision%20No.%2027%20of%202023%20-%20For%20publishing%20Arabic.pdf",
  "public_law": true,
  "quote_mode": "Full assigned actual public-law operative clause, losslessly split into ordered contiguous native fragments <=25 words and <=240 characters; manually read operative scope and neighbours.",
  "reuse_scope": "Exact finalresidence6a18a2c0lawunit/sourcehash personallyread16Nov2026 and correctionsverified; applicabilityonce,boundedreuse, no freshwholecountryPASSinferred.",
  "section": {
    "actual_text": "**UAE.** Keep the alternative natural-person routes in Cabinet Decision 85/2022 Art 4 separate: the native usual/main-place-of-residence and personal/financial-interests route OR the ministerial-criteria limb in Art4(1); 183 or more days during a relevant consecutive 12 months; or the qualified 90-or-more-day route, with nationality/residence-permit and permanent-home or employment/business conditions. MD 27/2023 supplies detailed meanings and counting rules. The Arabic Art 4(1) wording must be retained accurately; the authority-hosted English translation is expressly unofficial and differs in its conjunction. Treaty certificates require the relevant treaty's separate test. [Native Cabinet Decision](https://tax.gov.ae/DataFolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing%20Ar.pdf); [native MD 27](https://tax.gov.ae//Datafolder/Files/Legislation/Corporate%20Tax/Ministerial%20Decision%20No.%2027%20of%202023%20-%20For%20publishing%20Arabic.pdf).",
    "line": 47
  },
  "sections": [
    {
      "actual_text": "A natural person is a UAE tax resident if ANY of these applies: (1) the usual or primary residence AND centre of financial/personal interests are in the UAE, OR the ministerial conditions/criteria are met; (2) physical presence in the UAE of 183 days or more within the relevant 12 consecutive months; or (3) physical presence of 90 days or more within the relevant 12 consecutive months by a UAE national, a holder of a valid UAE residence permit or a GCC national, who also has a permanent place of residence in the UAE OR carries on employment or business there. A tax resident may apply to the Federal Tax Authority for a tax residency certificate. (The linked English text expressly says it is not an official translation. The Arabic decision and MinisterialDecision27/2023 definitions govern: day parts count, continuous availability matters for a permanent home, and normal employment/business facts must be established; treaty-certificate criteria are separate under article6. [Actual ArabicCD85](https://tax.gov.ae/DataFolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing%20Ar.pdf); [MD27Arabic](https://tax.gov.ae//Datafolder/Files/Legislation/Corporate%20Tax/Ministerial%20Decision%20No.%2027%20of%202023%20-%20For%20publishing%20Arabic.pdf); [Cabinet Decision No. 85 of 2022, articles 4 and 5](https://tax.gov.ae/Datafolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing.pdf))",
      "line": 147
    },
    {
      "actual_text": "| UAE | No special regime; tax residence under Cabinet Decision No. 85 of 2022 | A natural person who meets one of the residence tests (see the UAE section) | Corporate Tax on a natural person’s UAE business activity uses a turnover threshold above AED 1 million; separate non-resident State-Sourced Income cases are outside this comparison; a personal income tax rate is not printed on an allowed page | Relevant rolling 12-month windows for day routes; factual conditions otherwise | Wages, personal investment income and real estate investment income are not subject to Corporate Tax | [CD85residence](https://tax.gov.ae/Datafolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing.pdf); [FTA natural persons3.3](https://tax.gov.ae/Datafolder/Files/Guides/CT/Taxation%20of%20natural%20persons%20-%2025%2011%202023.pdf) |",
      "line": 31,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/sources/ae-residence27-ar.pdf",
  "source_sha256": "76a113486dc5fccf9a1c802ca4ee4932a922b4f2bef1dc2dc13ebbec04f1e6f4",
  "source_validation": "Own word-for-word comparison of every assigned manual clause against all3 actual rendered Arabic MD27 PDF pages16November2026. Art2(4) connective, Art4(1) repeated duration noun, Art6(1)(a) alternative OR and singular service, and Art6(1)(b) employment-income/part wording corrected explicitly. No substitution of unofficial English and no false machine literal-match claim for garbled Arabic PDF extraction. Source-layout line breaks are normalized; visual source diacritics are not claimed to be encoded identically.",
  "source_version_basis": "Actual native PDF personally visually read; no unofficial English substitution",
  "visual_evidence_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/tax-residency/ae-md27-native-visual-read.json"
}
```

### AE-ENGLISH-CERTIFICATE

Englishunofficialstatusdisclosed;qualifiedtaxresidentmayapplyTRCnotautomatic; treatycriteriaArt6separate. NativeArabicoperativeunitsabovecontrol.

```json
{
  "act_article_or_scope": "CD85unofficialEnglishArt4–6whole,1–3/7–9neighbours; actual4PDFpagesread",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "complete_condition_paraphrase": "Englishunofficialstatusdisclosed;qualifiedtaxresidentmayapplyTRCnotautomatic; treatycriteriaArt6separate. NativeArabicoperativeunitsabovecontrol.",
  "id": "AE-ENGLISH-CERTIFICATE",
  "official_url": "https://tax.gov.ae/Datafolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing.pdf",
  "public_law": false,
  "quote_mode": "Short exact source-language extracts, whitespace normalized only; complete material conditional scope personally read, no invented requirement to reproduce full paragraphs.",
  "sections": [
    {
      "actual_text": "A natural person is a UAE tax resident if ANY of these applies: (1) the usual or primary residence AND centre of financial/personal interests are in the UAE, OR the ministerial conditions/criteria are met; (2) physical presence in the UAE of 183 days or more within the relevant 12 consecutive months; or (3) physical presence of 90 days or more within the relevant 12 consecutive months by a UAE national, a holder of a valid UAE residence permit or a GCC national, who also has a permanent place of residence in the UAE OR carries on employment or business there. A tax resident may apply to the Federal Tax Authority for a tax residency certificate. (The linked English text expressly says it is not an official translation. The Arabic decision and MinisterialDecision27/2023 definitions govern: day parts count, continuous availability matters for a permanent home, and normal employment/business facts must be established; treaty-certificate criteria are separate under article6. [Actual ArabicCD85](https://tax.gov.ae/DataFolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing%20Ar.pdf); [MD27Arabic](https://tax.gov.ae//Datafolder/Files/Legislation/Corporate%20Tax/Ministerial%20Decision%20No.%2027%20of%202023%20-%20For%20publishing%20Arabic.pdf); [Cabinet Decision No. 85 of 2022, articles 4 and 5](https://tax.gov.ae/Datafolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing.pdf))",
      "line": 147
    },
    {
      "actual_text": "| UAE | No special regime; tax residence under Cabinet Decision No. 85 of 2022 | A natural person who meets one of the residence tests (see the UAE section) | Corporate Tax on a natural person’s UAE business activity uses a turnover threshold above AED 1 million; separate non-resident State-Sourced Income cases are outside this comparison; a personal income tax rate is not printed on an allowed page | Relevant rolling 12-month windows for day routes; factual conditions otherwise | Wages, personal investment income and real estate investment income are not subject to Corporate Tax | [CD85residence](https://tax.gov.ae/Datafolder/Files/Legislation/Corporate%20Tax/Cabinet%20Decision%2085%20of%202022%20-%20For%20publishing.pdf); [FTA natural persons3.3](https://tax.gov.ae/Datafolder/Files/Guides/CT/Taxation%20of%20natural%20persons%20-%2025%2011%202023.pdf) |",
      "line": 31,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [
    "This is not an official Translation"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/06.txt",
  "source_key": "06",
  "source_sha256": "6e8038bfb3c20eba6db21237f1526c3962be7c68d3490b8adffa8fb2131338cb",
  "source_version_basis": "OfficiallyhostedEnglish expresslyunofficialtranslation, pairedactualArabicCD85/MD27ownread; notofficialEnglishlegislation."
}
```

### SG-FOREIGN-INCOME-GENERAL

Generallyreceivedoverseasincomeincludingbankdepositnottaxable,nodeclarationwhenexempt;notuniversalSingaporeworkincomeexemption.

```json
{
  "act_article_or_scope": "IRASIncomereceivedfromoverseasactual1007–1014withfull1015–1038exceptions/reportingneighbours",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "complete_condition_paraphrase": "Generallyreceivedoverseasincomeincludingbankdepositnottaxable,nodeclarationwhenexempt;notuniversalSingaporeworkincomeexemption.",
  "id": "SG-FOREIGN-INCOME-GENERAL",
  "official_url": "https://www.iras.gov.sg/taxes/individual-income-tax/basics-of-individual-income-tax/what-is-taxable-what-is-not/income-received-from-overseas",
  "public_law": false,
  "quote_mode": "Short exact source-language extracts, whitespace normalized only; complete material conditional scope personally read, no invented requirement to reproduce full paragraphs.",
  "sections": [
    {
      "actual_text": "IRAS states that, generally, overseas income received in Singapore, including overseas income paid into a Singapore bank account, is not taxable, and need not be declared. Overseas income IS taxable if: it is received through a partnership based in Singapore; overseas employment is incidental to a Singapore employment; an overseas trade or business is incidental to a Singapore trade; the person works in Singapore for a foreign employer; or, for a Singapore citizen or tax resident, overseas employment on behalf of the Singapore Government is deemed Singapore-source, subject to any Minister-approved remission of tax on overseas allowances. ([IRAS, income received from overseas](https://www.iras.gov.sg/taxes/individual-income-tax/basics-of-individual-income-tax/what-is-taxable-what-is-not/income-received-from-overseas))",
      "line": 159
    },
    {
      "actual_text": "| Singapore | Overseas income received in Singapore | Individuals | Generally not taxable, subject to the five exceptions below | No time limit on the page | Overseas income received in Singapore generally not taxable; five exceptions listed in the Singapore section | [IRAS, income received from overseas](https://www.iras.gov.sg/taxes/individual-income-tax/basics-of-individual-income-tax/what-is-taxable-what-is-not/income-received-from-overseas) |",
      "line": 32,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [
    "not taxable"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/07.txt",
  "source_key": "07",
  "source_sha256": "8fe0ad4a781b3d9355787268bbc2a8e9fdb5e135dd22526127ee602412f3eaa4",
  "source_version_basis": "Actual current official source personally read16November2026; operative scope and material neighbours recorded, not download-only."
}
```

### SG-PARTNERSHIP-EXCEPTION

Singapore-basedpartnershipreceiptistaxableexception.

```json
{
  "act_article_or_scope": "IRASactual1015–1016item1, readallfiveandreporting",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "complete_condition_paraphrase": "Singapore-basedpartnershipreceiptistaxableexception.",
  "id": "SG-PARTNERSHIP-EXCEPTION",
  "official_url": "https://www.iras.gov.sg/taxes/individual-income-tax/basics-of-individual-income-tax/what-is-taxable-what-is-not/income-received-from-overseas",
  "public_law": false,
  "quote_mode": "Short exact source-language extracts, whitespace normalized only; complete material conditional scope personally read, no invented requirement to reproduce full paragraphs.",
  "sections": [
    {
      "actual_text": "IRAS states that, generally, overseas income received in Singapore, including overseas income paid into a Singapore bank account, is not taxable, and need not be declared. Overseas income IS taxable if: it is received through a partnership based in Singapore; overseas employment is incidental to a Singapore employment; an overseas trade or business is incidental to a Singapore trade; the person works in Singapore for a foreign employer; or, for a Singapore citizen or tax resident, overseas employment on behalf of the Singapore Government is deemed Singapore-source, subject to any Minister-approved remission of tax on overseas allowances. ([IRAS, income received from overseas](https://www.iras.gov.sg/taxes/individual-income-tax/basics-of-individual-income-tax/what-is-taxable-what-is-not/income-received-from-overseas))",
      "line": 159
    },
    {
      "actual_text": "| Singapore | Overseas income received in Singapore | Individuals | Generally not taxable, subject to the five exceptions below | No time limit on the page | Overseas income received in Singapore generally not taxable; five exceptions listed in the Singapore section | [IRAS, income received from overseas](https://www.iras.gov.sg/taxes/individual-income-tax/basics-of-individual-income-tax/what-is-taxable-what-is-not/income-received-from-overseas) |",
      "line": 32,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [
    "partnerships based in Singapore"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/07.txt",
  "source_key": "07",
  "source_sha256": "8fe0ad4a781b3d9355787268bbc2a8e9fdb5e135dd22526127ee602412f3eaa4",
  "source_version_basis": "Actual current official source personally read16November2026; operative scope and material neighbours recorded, not download-only."
}
```

### SG-EMPLOYMENT-INCIDENTAL

ForeignemploymentincidentaltoSingaporeemploymentistaxable;examplealljobincometaxablebecauseoverseasworkrelatedtoSingaporejob.

```json
{
  "act_article_or_scope": "IRASactual1017–1021item2+regionalmanagerexample",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "complete_condition_paraphrase": "ForeignemploymentincidentaltoSingaporeemploymentistaxable;examplealljobincometaxablebecauseoverseasworkrelatedtoSingaporejob.",
  "id": "SG-EMPLOYMENT-INCIDENTAL",
  "official_url": "https://www.iras.gov.sg/taxes/individual-income-tax/basics-of-individual-income-tax/what-is-taxable-what-is-not/income-received-from-overseas",
  "public_law": false,
  "quote_mode": "Short exact source-language extracts, whitespace normalized only; complete material conditional scope personally read, no invented requirement to reproduce full paragraphs.",
  "sections": [
    {
      "actual_text": "IRAS states that, generally, overseas income received in Singapore, including overseas income paid into a Singapore bank account, is not taxable, and need not be declared. Overseas income IS taxable if: it is received through a partnership based in Singapore; overseas employment is incidental to a Singapore employment; an overseas trade or business is incidental to a Singapore trade; the person works in Singapore for a foreign employer; or, for a Singapore citizen or tax resident, overseas employment on behalf of the Singapore Government is deemed Singapore-source, subject to any Minister-approved remission of tax on overseas allowances. ([IRAS, income received from overseas](https://www.iras.gov.sg/taxes/individual-income-tax/basics-of-individual-income-tax/what-is-taxable-what-is-not/income-received-from-overseas))",
      "line": 159
    },
    {
      "actual_text": "| Singapore | Overseas income received in Singapore | Individuals | Generally not taxable, subject to the five exceptions below | No time limit on the page | Overseas income received in Singapore generally not taxable; five exceptions listed in the Singapore section | [IRAS, income received from overseas](https://www.iras.gov.sg/taxes/individual-income-tax/basics-of-individual-income-tax/what-is-taxable-what-is-not/income-received-from-overseas) |",
      "line": 32,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [
    "incidental to your Singapore employment"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/07.txt",
  "source_key": "07",
  "source_sha256": "8fe0ad4a781b3d9355787268bbc2a8e9fdb5e135dd22526127ee602412f3eaa4",
  "source_version_basis": "Actual current official source personally read16November2026; operative scope and material neighbours recorded, not download-only."
}
```

### SG-BUSINESS-INCIDENTAL

Overseastrade/businessincidentaltotheSingaporetrade/businessistaxable.

```json
{
  "act_article_or_scope": "IRASactual1022item3",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "complete_condition_paraphrase": "Overseastrade/businessincidentaltotheSingaporetrade/businessistaxable.",
  "id": "SG-BUSINESS-INCIDENTAL",
  "official_url": "https://www.iras.gov.sg/taxes/individual-income-tax/basics-of-individual-income-tax/what-is-taxable-what-is-not/income-received-from-overseas",
  "public_law": false,
  "quote_mode": "Short exact source-language extracts, whitespace normalized only; complete material conditional scope personally read, no invented requirement to reproduce full paragraphs.",
  "sections": [
    {
      "actual_text": "IRAS states that, generally, overseas income received in Singapore, including overseas income paid into a Singapore bank account, is not taxable, and need not be declared. Overseas income IS taxable if: it is received through a partnership based in Singapore; overseas employment is incidental to a Singapore employment; an overseas trade or business is incidental to a Singapore trade; the person works in Singapore for a foreign employer; or, for a Singapore citizen or tax resident, overseas employment on behalf of the Singapore Government is deemed Singapore-source, subject to any Minister-approved remission of tax on overseas allowances. ([IRAS, income received from overseas](https://www.iras.gov.sg/taxes/individual-income-tax/basics-of-individual-income-tax/what-is-taxable-what-is-not/income-received-from-overseas))",
      "line": 159
    },
    {
      "actual_text": "| Singapore | Overseas income received in Singapore | Individuals | Generally not taxable, subject to the five exceptions below | No time limit on the page | Overseas income received in Singapore generally not taxable; five exceptions listed in the Singapore section | [IRAS, income received from overseas](https://www.iras.gov.sg/taxes/individual-income-tax/basics-of-individual-income-tax/what-is-taxable-what-is-not/income-received-from-overseas) |",
      "line": 32,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [
    "incidental to your Singapore trade"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/07.txt",
  "source_key": "07",
  "source_sha256": "8fe0ad4a781b3d9355787268bbc2a8e9fdb5e135dd22526127ee602412f3eaa4",
  "source_version_basis": "Actual current official source personally read16November2026; operative scope and material neighbours recorded, not download-only."
}
```

### SG-FOREIGN-EMPLOYER

WorkinginSingaporeforforeignemployeristaxableexception.

```json
{
  "act_article_or_scope": "IRASactual1023item4",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "complete_condition_paraphrase": "WorkinginSingaporeforforeignemployeristaxableexception.",
  "id": "SG-FOREIGN-EMPLOYER",
  "official_url": "https://www.iras.gov.sg/taxes/individual-income-tax/basics-of-individual-income-tax/what-is-taxable-what-is-not/income-received-from-overseas",
  "public_law": false,
  "quote_mode": "Short exact source-language extracts, whitespace normalized only; complete material conditional scope personally read, no invented requirement to reproduce full paragraphs.",
  "sections": [
    {
      "actual_text": "IRAS states that, generally, overseas income received in Singapore, including overseas income paid into a Singapore bank account, is not taxable, and need not be declared. Overseas income IS taxable if: it is received through a partnership based in Singapore; overseas employment is incidental to a Singapore employment; an overseas trade or business is incidental to a Singapore trade; the person works in Singapore for a foreign employer; or, for a Singapore citizen or tax resident, overseas employment on behalf of the Singapore Government is deemed Singapore-source, subject to any Minister-approved remission of tax on overseas allowances. ([IRAS, income received from overseas](https://www.iras.gov.sg/taxes/individual-income-tax/basics-of-individual-income-tax/what-is-taxable-what-is-not/income-received-from-overseas))",
      "line": 159
    },
    {
      "actual_text": "| Singapore | Overseas income received in Singapore | Individuals | Generally not taxable, subject to the five exceptions below | No time limit on the page | Overseas income received in Singapore generally not taxable; five exceptions listed in the Singapore section | [IRAS, income received from overseas](https://www.iras.gov.sg/taxes/individual-income-tax/basics-of-individual-income-tax/what-is-taxable-what-is-not/income-received-from-overseas) |",
      "line": 32,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [
    "foreign employer"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/07.txt",
  "source_key": "07",
  "source_sha256": "8fe0ad4a781b3d9355787268bbc2a8e9fdb5e135dd22526127ee602412f3eaa4",
  "source_version_basis": "Actual current official source personally read16November2026; operative scope and material neighbours recorded, not download-only."
}
```

### SG-GOVERNMENT-EMPLOYMENT

Overseasgovernmentemploymentexception;citizen/taxresidentforeignexerciseonbehalfSGgovdeemedSingapore-source,remission/DTAreciprocalconditionalnotautomatic.

```json
{
  "act_article_or_scope": "IRASactual1024–1031item5+completegovernmenttreatmentneighbours",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "complete_condition_paraphrase": "Overseasgovernmentemploymentexception;citizen/taxresidentforeignexerciseonbehalfSGgovdeemedSingapore-source,remission/DTAreciprocalconditionalnotautomatic.",
  "id": "SG-GOVERNMENT-EMPLOYMENT",
  "official_url": "https://www.iras.gov.sg/taxes/individual-income-tax/basics-of-individual-income-tax/what-is-taxable-what-is-not/income-received-from-overseas",
  "public_law": false,
  "quote_mode": "Short exact source-language extracts, whitespace normalized only; complete material conditional scope personally read, no invented requirement to reproduce full paragraphs.",
  "sections": [
    {
      "actual_text": "IRAS states that, generally, overseas income received in Singapore, including overseas income paid into a Singapore bank account, is not taxable, and need not be declared. Overseas income IS taxable if: it is received through a partnership based in Singapore; overseas employment is incidental to a Singapore employment; an overseas trade or business is incidental to a Singapore trade; the person works in Singapore for a foreign employer; or, for a Singapore citizen or tax resident, overseas employment on behalf of the Singapore Government is deemed Singapore-source, subject to any Minister-approved remission of tax on overseas allowances. ([IRAS, income received from overseas](https://www.iras.gov.sg/taxes/individual-income-tax/basics-of-individual-income-tax/what-is-taxable-what-is-not/income-received-from-overseas))",
      "line": 159
    },
    {
      "actual_text": "| Singapore | Overseas income received in Singapore | Individuals | Generally not taxable, subject to the five exceptions below | No time limit on the page | Overseas income received in Singapore generally not taxable; five exceptions listed in the Singapore section | [IRAS, income received from overseas](https://www.iras.gov.sg/taxes/individual-income-tax/basics-of-individual-income-tax/what-is-taxable-what-is-not/income-received-from-overseas) |",
      "line": 32,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [
    "Singapore Government"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/07.txt",
  "source_key": "07",
  "source_sha256": "8fe0ad4a781b3d9355787268bbc2a8e9fdb5e135dd22526127ee602412f3eaa4",
  "source_version_basis": "Actual current official source personally read16November2026; operative scope and material neighbours recorded, not download-only."
}
```

### UK-FIG-ENTRY-WINDOW

SRTresidentfirst4taxyearsafter10consecutivenonresident;pre2025partialwindowonlyremaining;nonresidentgapunclaimablebutwindowdoesnotextend.

```json
{
  "act_article_or_scope": "HMRCFIGeligibility+bothactualexamples, wholeoperativeguidanceapprox74–121",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "complete_condition_paraphrase": "SRTresidentfirst4taxyearsafter10consecutivenonresident;pre2025partialwindowonlyremaining;nonresidentgapunclaimablebutwindowdoesnotextend.",
  "id": "UK-FIG-ENTRY-WINDOW",
  "official_url": "https://www.gov.uk/guidance/check-if-you-can-claim-the-4-year-foreign-income-and-gains-regime",
  "public_law": false,
  "quote_mode": "Short exact source-language extracts, whitespace normalized only; complete material conditional scope personally read, no invented requirement to reproduce full paragraphs.",
  "sections": [
    {
      "actual_text": "On 6 April 2025 the four-year foreign income and gains (FIG) regime replaced the remittance basis. A UK resident under the statutory residence test can claim it only within their first 4 years of UK residence that follow at least 10 consecutive tax years of non-UK residence. Those whose 4 years began before 6 April 2025 can use the years left from 2025 to 2026. Years spent non-resident inside the window cannot be claimed or rolled forward. The claim is made on the Self Assessment return, source by source. Eligible items include profits of a trade carried on wholly outside the UK, overseas property profits, dividends from non-UK companies and foreign interest. Foreign employment income is NOT eligible (Overseas Workday Relief may apply instead). A claim removes the income-tax and capital-gains allowances and the listed marriage/blind-person allowances; foreign income still enters adjusted-net-income calculations for relevant childcare/child-benefit rules. ([HMRC, 4-year FIG regime](https://www.gov.uk/guidance/check-if-you-can-claim-the-4-year-foreign-income-and-gains-regime))",
      "line": 165
    },
    {
      "actual_text": "| UK | Four-year foreign income and gains regime (replaced the remittance basis on 6 April 2025) | A UK resident in the first four tax years of UK residence after at least ten consecutive tax years of non-residence | No separate regime fee stated; old remittance-basis users can designate pre-6 April 2025 foreign income and gains at 12% in 2025 to 2026 and 2026 to 2027, and 15% in 2027 to 2028 | At most four consecutive tax years | Claimed foreign income and gains relieved; foreign employment income excluded; allowances lost | [FIG](https://www.gov.uk/guidance/check-if-you-can-claim-the-4-year-foreign-income-and-gains-regime); [TRF4](https://www.gov.uk/government/publications/remittance-basis-hs264-self-assessment-helpsheet/hs264-remittance-of-pre-6-april-2025-foreign-income-and-gains-and-the-temporary-repatriation-facility-trf) |",
      "line": 33,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [
    "4 consecutive years"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/08.txt",
  "source_key": "08",
  "source_sha256": "7158d877b448061544ebe90d072d9170c109f631ac485b8ff8e11e87b31470e7",
  "source_version_basis": "Actual current official source personally read16November2026; operative scope and material neighbours recorded, not download-only."
}
```

### UK-FIG-ELIGIBLE-CLAIM-COST

Foreigntrade/property/dividends/interesteligible;foreignemploymentnot,OWRseparate;SelfAssessmentclaimsourcechoice,personalCGT/marriage/blindallowanceslost;foreignincomecountsANIchildcare/HICBC.

```json
{
  "act_article_or_scope": "HMRCFIGeligibleincome/howclaim/allowanceswhole, actual122–153withneighbours",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "complete_condition_paraphrase": "Foreigntrade/property/dividends/interesteligible;foreignemploymentnot,OWRseparate;SelfAssessmentclaimsourcechoice,personalCGT/marriage/blindallowanceslost;foreignincomecountsANIchildcare/HICBC.",
  "id": "UK-FIG-ELIGIBLE-CLAIM-COST",
  "official_url": "https://www.gov.uk/guidance/check-if-you-can-claim-the-4-year-foreign-income-and-gains-regime",
  "public_law": false,
  "quote_mode": "Short exact source-language extracts, whitespace normalized only; complete material conditional scope personally read, no invented requirement to reproduce full paragraphs.",
  "sections": [
    {
      "actual_text": "On 6 April 2025 the four-year foreign income and gains (FIG) regime replaced the remittance basis. A UK resident under the statutory residence test can claim it only within their first 4 years of UK residence that follow at least 10 consecutive tax years of non-UK residence. Those whose 4 years began before 6 April 2025 can use the years left from 2025 to 2026. Years spent non-resident inside the window cannot be claimed or rolled forward. The claim is made on the Self Assessment return, source by source. Eligible items include profits of a trade carried on wholly outside the UK, overseas property profits, dividends from non-UK companies and foreign interest. Foreign employment income is NOT eligible (Overseas Workday Relief may apply instead). A claim removes the income-tax and capital-gains allowances and the listed marriage/blind-person allowances; foreign income still enters adjusted-net-income calculations for relevant childcare/child-benefit rules. ([HMRC, 4-year FIG regime](https://www.gov.uk/guidance/check-if-you-can-claim-the-4-year-foreign-income-and-gains-regime))",
      "line": 165
    },
    {
      "actual_text": "| UK | Four-year foreign income and gains regime (replaced the remittance basis on 6 April 2025) | A UK resident in the first four tax years of UK residence after at least ten consecutive tax years of non-residence | No separate regime fee stated; old remittance-basis users can designate pre-6 April 2025 foreign income and gains at 12% in 2025 to 2026 and 2026 to 2027, and 15% in 2027 to 2028 | At most four consecutive tax years | Claimed foreign income and gains relieved; foreign employment income excluded; allowances lost | [FIG](https://www.gov.uk/guidance/check-if-you-can-claim-the-4-year-foreign-income-and-gains-regime); [TRF4](https://www.gov.uk/government/publications/remittance-basis-hs264-self-assessment-helpsheet/hs264-remittance-of-pre-6-april-2025-foreign-income-and-gains-and-the-temporary-repatriation-facility-trf) |",
      "line": 33,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [
    "foreign earnings"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/08.txt",
  "source_key": "08",
  "source_sha256": "7158d877b448061544ebe90d072d9170c109f631ac485b8ff8e11e87b31470e7",
  "source_version_basis": "Actual current official source personally read16November2026; operative scope and material neighbours recorded, not download-only."
}
```

### UK-TRF-RATES-ELIGIBILITY

Three2025/26–27/28designationyears,12%first2/15%third;UKresidentdesignationyear+formerremitbasis,eligiblepre6April2025capitalincuncertainorigin/matchedtrust/assets;notallfreshincome.

```json
{
  "act_article_or_scope": "HS264section4–4.3wholewith3.2neighbour,actualpost2025/26helpsheetbasis",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "complete_condition_paraphrase": "Three2025/26–27/28designationyears,12%first2/15%third;UKresidentdesignationyear+formerremitbasis,eligiblepre6April2025capitalincuncertainorigin/matchedtrust/assets;notallfreshincome.",
  "id": "UK-TRF-RATES-ELIGIBILITY",
  "official_url": "https://www.gov.uk/government/publications/remittance-basis-hs264-self-assessment-helpsheet/hs264-remittance-of-pre-6-april-2025-foreign-income-and-gains-and-the-temporary-repatriation-facility-trf",
  "public_law": false,
  "quote_mode": "Short exact source-language extracts, whitespace normalized only; complete material conditional scope personally read, no invented requirement to reproduce full paragraphs.",
  "sections": [
    {
      "actual_text": "Former remittance-basis users can designate foreign income and gains from before 6 April 2025 under the Temporary Repatriation Facility at the rate in the table below. Designation requires UK residence in the designation year and former remittance-basis use. Designation and remittance are different: designated qualifying capital can be remitted later without another remittance charge; undesignated old income/gains retain their ordinary remittance rules. No foreign tax credit is given against the TRF charge. Retain origin, designation and mixed-fund records. ([HMRC, HS264](https://www.gov.uk/government/publications/remittance-basis-hs264-self-assessment-helpsheet/hs264-remittance-of-pre-6-april-2025-foreign-income-and-gains-and-the-temporary-repatriation-facility-trf))",
      "line": 167
    },
    {
      "actual_text": "| Temporary Repatriation Facility rate, designations in tax years 2025 to 2026 and 2026 to 2027 | 12% | Designation-year rate; eligible old capital only. | https://www.gov.uk/government/publications/remittance-basis-hs264-self-assessment-helpsheet/hs264-remittance-of-pre-6-april-2025-foreign-income-and-gains-and-the-temporary-repatriation-facility-trf |",
      "line": 171
    },
    {
      "actual_text": "| Temporary Repatriation Facility rate, designations in tax year 2027 to 2028 | 15% | Third designation-year rate; eligible old capital only. | https://www.gov.uk/government/publications/remittance-basis-hs264-self-assessment-helpsheet/hs264-remittance-of-pre-6-april-2025-foreign-income-and-gains-and-the-temporary-repatriation-facility-trf |",
      "line": 172
    },
    {
      "actual_text": "| UK | Four-year foreign income and gains regime (replaced the remittance basis on 6 April 2025) | A UK resident in the first four tax years of UK residence after at least ten consecutive tax years of non-residence | No separate regime fee stated; old remittance-basis users can designate pre-6 April 2025 foreign income and gains at 12% in 2025 to 2026 and 2026 to 2027, and 15% in 2027 to 2028 | At most four consecutive tax years | Claimed foreign income and gains relieved; foreign employment income excluded; allowances lost | [FIG](https://www.gov.uk/guidance/check-if-you-can-claim-the-4-year-foreign-income-and-gains-regime); [TRF4](https://www.gov.uk/government/publications/remittance-basis-hs264-self-assessment-helpsheet/hs264-remittance-of-pre-6-april-2025-foreign-income-and-gains-and-the-temporary-repatriation-facility-trf) |",
      "line": 33,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [
    "that rate is 12%"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/15.txt",
  "source_key": "15",
  "source_sha256": "0dcb28e08f78d13edb52ef7b2e81fac68644c90647a93416c7a0fd01bd572f5c",
  "source_version_basis": "ActualHMRC2025/26helpsheetwith3-yearTRFprovisions, readassigned4–4.3and3.2neighbour16Nov2026;historicfilingbox/yearnotgeneral2026/27manual."
}
```

### UK-TRF-REMITTANCE-NO-CREDIT

Designationnotremittance;eligiblecapitalcanremitlaterwithoutfreshcharge,undesignedoldFIGordinaryremit;noFTCagainstcharge;recordsorigin/designation/mixedfunds.

```json
{
  "act_article_or_scope": "HS2644/4.3steps1–4, actualoperativecapital/rates/mixedfunds/recordscope",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "complete_condition_paraphrase": "Designationnotremittance;eligiblecapitalcanremitlaterwithoutfreshcharge,undesignedoldFIGordinaryremit;noFTCagainstcharge;recordsorigin/designation/mixedfunds.",
  "id": "UK-TRF-REMITTANCE-NO-CREDIT",
  "official_url": "https://www.gov.uk/government/publications/remittance-basis-hs264-self-assessment-helpsheet/hs264-remittance-of-pre-6-april-2025-foreign-income-and-gains-and-the-temporary-repatriation-facility-trf",
  "public_law": false,
  "quote_mode": "Short exact source-language extracts, whitespace normalized only; complete material conditional scope personally read, no invented requirement to reproduce full paragraphs.",
  "sections": [
    {
      "actual_text": "Former remittance-basis users can designate foreign income and gains from before 6 April 2025 under the Temporary Repatriation Facility at the rate in the table below. Designation requires UK residence in the designation year and former remittance-basis use. Designation and remittance are different: designated qualifying capital can be remitted later without another remittance charge; undesignated old income/gains retain their ordinary remittance rules. No foreign tax credit is given against the TRF charge. Retain origin, designation and mixed-fund records. ([HMRC, HS264](https://www.gov.uk/government/publications/remittance-basis-hs264-self-assessment-helpsheet/hs264-remittance-of-pre-6-april-2025-foreign-income-and-gains-and-the-temporary-repatriation-facility-trf))",
      "line": 167
    },
    {
      "actual_text": "| UK | Four-year foreign income and gains regime (replaced the remittance basis on 6 April 2025) | A UK resident in the first four tax years of UK residence after at least ten consecutive tax years of non-residence | No separate regime fee stated; old remittance-basis users can designate pre-6 April 2025 foreign income and gains at 12% in 2025 to 2026 and 2026 to 2027, and 15% in 2027 to 2028 | At most four consecutive tax years | Claimed foreign income and gains relieved; foreign employment income excluded; allowances lost | [FIG](https://www.gov.uk/guidance/check-if-you-can-claim-the-4-year-foreign-income-and-gains-regime); [TRF4](https://www.gov.uk/government/publications/remittance-basis-hs264-self-assessment-helpsheet/hs264-remittance-of-pre-6-april-2025-foreign-income-and-gains-and-the-temporary-repatriation-facility-trf) |",
      "line": 33,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [
    "No foreign tax credit"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/15.txt",
  "source_key": "15",
  "source_sha256": "0dcb28e08f78d13edb52ef7b2e81fac68644c90647a93416c7a0fd01bd572f5c",
  "source_version_basis": "Sameactualdatedhelpsheetassignedscope, nocurrentfilingboxordeadlineinvented."
}
```

### UK-IHT-LTR-TAIL

From6April2025residence-basedIHT;10of20/prior10branch,3–10yearafterdeparturetail;30Oct2024/2025/26nonresident/transitionalrules;overseastrustscopewithspecificdeathassets3conditions,separatetrustcharges.

```json
{
  "act_article_or_scope": "HMRCIHTLTRwholeoperativeintro/qualification/leaving/transitionaldeemeddomicile/trustsections approx74–124",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "complete_condition_paraphrase": "NewLTRfrom6April2025,notpre-dateestates. Previous10consecutiveortotal10of20;10–13residenceyears→3tail,14→4,15→5,upto10tail. Tenconsecutivenonresidentyearsresetclock. 30Oct2024notdom/deemeddom+2025/26nonresident+notreturnexclusion;deemeddomtransitional3years. Overseastrustassetsset/upaddedcanchargewhileLTR;nodeathchargeonlyall3listedconditions(nonUKdomwhenplaced,overseas30Oct2024,overseasdeath/rightsend),trustchargescanremain. NofulltrustIHTcomputation.",
  "id": "UK-IHT-LTR-TAIL",
  "official_url": "https://www.gov.uk/guidance/inheritance-tax-if-youre-a-long-term-uk-resident",
  "public_law": false,
  "quote_mode": "Short exact source-language extracts, whitespace normalized only; complete material conditional scope personally read, no invented requirement to reproduce full paragraphs.",
  "sections": [
    {
      "actual_text": "**UK traps.** From 6 April 2025 inheritance tax follows long-term UK residence, not domicile. A person is long-term UK resident in a tax year if UK resident for the previous 10 consecutive years or for a total of 10 years or more within the previous 20 years. Long-term residence can continue for up to 10 tax years after leaving, less for shorter stays (3 years after leaving for 10 to 13 years of residence). The general tail is qualified by transitional rules: a person who had neither UK domicile nor deemed domicile on 30 October 2024, is non-resident in 2025 to 2026 and does not return is excluded. A person with deemed domicile on 30 October 2024 who is non-resident in 2025 to 2026 and does not return has the separate 3-year non-residence rule. After 10 consecutive non-resident years, the 10-out-of-20 test resets on return and counts only the return year and future years. Inheritance tax is charged on overseas assets in a trust the person set up or added to, even when the person was not long-term UK resident. HMRC lists trust assets on which there is no inheritance tax on the person's death: assets placed in the trust while the person was non-UK domiciled, overseas on 30 October 2024, and overseas on the date of death or when the person's rights in the trust ended. Separate trust charges may still apply ([HMRC, Inheritance Tax if you're a long-term UK resident](https://www.gov.uk/guidance/inheritance-tax-if-youre-a-long-term-uk-resident)). A family leaving the UK should read this with `exit-taxes-when-a-family-moves`; one arriving should note that the FIG window is short and fixed. Details are in `uk-non-dom`.",
      "line": 174
    },
    {
      "actual_text": "| UK | Four-year foreign income and gains regime (replaced the remittance basis on 6 April 2025) | A UK resident in the first four tax years of UK residence after at least ten consecutive tax years of non-residence | No separate regime fee stated; old remittance-basis users can designate pre-6 April 2025 foreign income and gains at 12% in 2025 to 2026 and 2026 to 2027, and 15% in 2027 to 2028 | At most four consecutive tax years | Claimed foreign income and gains relieved; foreign employment income excluded; allowances lost | [FIG](https://www.gov.uk/guidance/check-if-you-can-claim-the-4-year-foreign-income-and-gains-regime); [TRF4](https://www.gov.uk/government/publications/remittance-basis-hs264-self-assessment-helpsheet/hs264-remittance-of-pre-6-april-2025-foreign-income-and-gains-and-the-temporary-repatriation-facility-trf) |",
      "line": 33,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [
    "10 years or more within the previous 20 years"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/16.txt",
  "source_key": "16",
  "source_sha256": "f5f492a2b46652aafa7bc24d4bd6bb11eb5d0f6a9035436f422baa10573be6ca",
  "source_version_basis": "Actual current official source personally read16November2026; operative scope and material neighbours recorded, not download-only."
}
```

### IE-REMITTANCE-FOREIGN-GAINS-UK

Non-domCaseIIIforeignincomeactualremit,foreignCGTremit;citizen/nonordinarybasisended2010,notnon-domcitizensbar;UKincomefrom1Jan2008/gains20Nov2008;localemploymentdutiesexcluded.

```json
{
  "act_article_or_scope": "RevenueTDM05-01-21May2026all3PDFpagesread,sections1–3/Notes1–3",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "complete_condition_paraphrase": "Non-domCaseIIIforeignincomeactualremit,foreignCGTremit;citizen/nonordinarybasisended2010,notnon-domcitizensbar;UKincomefrom1Jan2008/gains20Nov2008;localemploymentdutiesexcluded.",
  "id": "IE-REMITTANCE-FOREIGN-GAINS-UK",
  "official_url": "https://www.revenue.ie/en/tax-professionals/tdm/income-tax-capital-gains-tax-corporation-tax/part-05/05-01-21.pdf",
  "public_law": false,
  "quote_mode": "Short exact source-language extracts, whitespace normalized only; complete material conditional scope personally read, no invented requirement to reproduce full paragraphs.",
  "sections": [
    {
      "actual_text": "An individual resident in Ireland but not domiciled there pays Irish tax on Irish source income in full and on foreign income only to the extent remitted into Ireland ([Revenue, domicile and the domicile levy](https://www.revenue.ie/en/jobs-and-pensions/tax-residence/domicile-domicile-levy.aspx)). The remittance basis rests on domicile: since tax year 2010 Irish citizenship plus non-ordinary residence alone no longer qualifies a domiciled individual; a non-domiciled citizen may still meet the domicile test. Case IV income is outside the remittance basis. Accumulated income does not automatically become capital; mixed funds, indirect remittances and spouse transfers need tracing. It also applies to foreign chargeable gains of non-domiciled individuals. Pay for duties performed in Ireland, even under a foreign employment, is taxed in full and is NOT on the remittance basis. ([Revenue, Tax and Duty Manual Part 05-01-21, the remittance basis of assessment as regards UK source income and gains](https://www.revenue.ie/en/tax-professionals/tdm/income-tax-capital-gains-tax-corporation-tax/part-05/05-01-21.pdf); [Tax and Duty Manual Part 05-01-21A](https://www.revenue.ie/en/tax-professionals/tdm/income-tax-capital-gains-tax-corporation-tax/part-05/05-01-21a.pdf))",
      "line": 178
    },
    {
      "actual_text": "| Ireland | Remittance basis for non-domiciled residents | An Irish resident who is not domiciled in Ireland | No separate regime fee stated; the domicile levy of EUR 200,000 applies to Irish-domiciled people who meet all its tests | No end date while not domiciled | Foreign income and foreign gains taxed when remitted; Irish source income taxed in full; pay for duties done in Ireland excluded | [Revenue, domicile and the domicile levy](https://www.revenue.ie/en/jobs-and-pensions/tax-residence/domicile-domicile-levy.aspx) |",
      "line": 34,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [
    "not domiciled in the State"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/17.txt",
  "source_key": "17",
  "source_sha256": "90e33185776c32dd2dc364bc290f403f106a5d52ae585e22a21f2bde86092f06",
  "source_version_basis": "ActualRevenueTDMreviewedMay2026,whole3pagespersonallyread;countrylawcrossrefs71/29/73/FinanceActsindicated,notnewuniversalremittanceexemption."
}
```

### IE-REMITTANCE-TRACING

CaseIIIonlynotCaseIV/ScheduleE;incomeaccumulationnotcapital,mixedincome-firstandtaxedScheduleEincomefirstpossibility;spousetransfer/loansantiavoidance,loanrepayment72,datedprearrivalpractice;currentcitizenshipcorrection.

```json
{
  "act_article_or_scope": "RevenueTDM05-01-21AMay2026sections1–7whole, actualPDFpp3–9; examplep9–10readneighbours",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "complete_condition_paraphrase": "CaseIIIonlynotCaseIV/ScheduleE;incomeaccumulationnotcapital,mixedincome-firstandtaxedScheduleEincomefirstpossibility;spousetransfer/loansantiavoidance,loanrepayment72,datedprearrivalpractice;currentcitizenshipcorrection.",
  "id": "IE-REMITTANCE-TRACING",
  "official_url": "https://www.revenue.ie/en/tax-professionals/tdm/income-tax-capital-gains-tax-corporation-tax/part-05/05-01-21a.pdf",
  "public_law": false,
  "quote_mode": "Short exact source-language extracts, whitespace normalized only; complete material conditional scope personally read, no invented requirement to reproduce full paragraphs.",
  "sections": [
    {
      "actual_text": "An individual resident in Ireland but not domiciled there pays Irish tax on Irish source income in full and on foreign income only to the extent remitted into Ireland ([Revenue, domicile and the domicile levy](https://www.revenue.ie/en/jobs-and-pensions/tax-residence/domicile-domicile-levy.aspx)). The remittance basis rests on domicile: since tax year 2010 Irish citizenship plus non-ordinary residence alone no longer qualifies a domiciled individual; a non-domiciled citizen may still meet the domicile test. Case IV income is outside the remittance basis. Accumulated income does not automatically become capital; mixed funds, indirect remittances and spouse transfers need tracing. It also applies to foreign chargeable gains of non-domiciled individuals. Pay for duties performed in Ireland, even under a foreign employment, is taxed in full and is NOT on the remittance basis. ([Revenue, Tax and Duty Manual Part 05-01-21, the remittance basis of assessment as regards UK source income and gains](https://www.revenue.ie/en/tax-professionals/tdm/income-tax-capital-gains-tax-corporation-tax/part-05/05-01-21.pdf); [Tax and Duty Manual Part 05-01-21A](https://www.revenue.ie/en/tax-professionals/tdm/income-tax-capital-gains-tax-corporation-tax/part-05/05-01-21a.pdf))",
      "line": 178
    },
    {
      "actual_text": "| Ireland | Remittance basis for non-domiciled residents | An Irish resident who is not domiciled in Ireland | No separate regime fee stated; the domicile levy of EUR 200,000 applies to Irish-domiciled people who meet all its tests | No end date while not domiciled | Foreign income and foreign gains taxed when remitted; Irish source income taxed in full; pay for duties done in Ireland excluded | [Revenue, domicile and the domicile levy](https://www.revenue.ie/en/jobs-and-pensions/tax-residence/domicile-domicile-levy.aspx) |",
      "line": 34,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [
    "Case IV"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/18.txt",
  "source_key": "18",
  "source_sha256": "aa24c2e827c2ea19e18b91142ba2ae3ff8d0de4463997ad331fc5028dfade8aa",
  "source_version_basis": "ActualRevenueMay2026TDMwholeoperative1–7personallyread; examplesreadasillustrationnotnewGuideinputs."
}
```

### IE-DOMICILE-LEVY-FOUR-GATES

IrishdomicileANDworldwideincome>1mANDIrishITliability<200kANDIrishpropertymarketvalue>5mat31Dec;residencenotfactor. LiabilitybeforeFTC;worldwidecomputation/disallowedallowancesnotnetcash.

```json
{
  "act_article_or_scope": "RevenueTDM18C-00-01Aug2026sections1–3.1/3.3/3.4, actualPDFpp3–8andneighbours; p3visual",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "complete_condition_paraphrase": "IrishdomicileANDworldwideincome>1mANDIrishITliability<200kANDIrishpropertymarketvalue>5mat31Dec;residencenotfactor. LiabilitybeforeFTC;worldwidecomputation/disallowedallowancesnotnetcash.",
  "id": "IE-DOMICILE-LEVY-FOUR-GATES",
  "official_url": "https://www.revenue.ie/en/tax-professionals/tdm/income-tax-capital-gains-tax-corporation-tax/part-18c/18c-00-01.pdf",
  "public_law": false,
  "quote_mode": "Short exact source-language extracts, whitespace normalized only; complete material conditional scope personally read, no invented requirement to reproduce full paragraphs.",
  "sections": [
    {
      "actual_text": "**Domicile levy.** The levy is the opposite case: it is charged on an individual who IS domiciled in Ireland, whatever their tax residence, if ALL of these apply in the tax year: worldwide income above the income test, Irish income tax below the tax test, AND Irish property on 31 December worth more than the property test, with no deduction for debts. Irish income tax paid for the year can be set against the levy; USC, PRSI and RZLT cannot. The credit is limited to Irish income tax paid no later than the levy; the income-tax liability gate is before foreign-tax credits. Worldwide income has a statutory computation, not simply net cash receipts; Irish-property market value ignores debts, has trading-company exceptions and anti-avoidance rules. The levy is normally paid and filed by 31 October of the following year, with the published ROS pay-and-file extension where applicable. ([Revenue, Tax and Duty Manual Part 18C-00-01](https://www.revenue.ie/en/tax-professionals/tdm/income-tax-capital-gains-tax-corporation-tax/part-18c/18c-00-01.pdf); [Revenue, domicile and the domicile levy](https://www.revenue.ie/en/jobs-and-pensions/tax-residence/domicile-domicile-levy.aspx))",
      "line": 180
    },
    {
      "actual_text": "| Income test: worldwide income more than | EUR 1,000,000 | Strictly greater; statutory worldwide-income computation. | https://www.revenue.ie/en/tax-professionals/tdm/income-tax-capital-gains-tax-corporation-tax/part-18c/18c-00-01.pdf |",
      "line": 185
    },
    {
      "actual_text": "| Tax test: Irish income tax for the year less than | EUR 200,000 | Strictly less; income-tax liability gate differs from paid-tax credit. | https://www.revenue.ie/en/tax-professionals/tdm/income-tax-capital-gains-tax-corporation-tax/part-18c/18c-00-01.pdf |",
      "line": 186
    },
    {
      "actual_text": "| Property test: Irish property on 31 December more than | EUR 5,000,000 | 31 December market value, without debt deduction; exclusions/anti-avoidance apply. | https://www.revenue.ie/en/tax-professionals/tdm/income-tax-capital-gains-tax-corporation-tax/part-18c/18c-00-01.pdf |",
      "line": 187
    },
    {
      "actual_text": "| Ireland | Remittance basis for non-domiciled residents | An Irish resident who is not domiciled in Ireland | No separate regime fee stated; the domicile levy of EUR 200,000 applies to Irish-domiciled people who meet all its tests | No end date while not domiciled | Foreign income and foreign gains taxed when remitted; Irish source income taxed in full; pay for duties done in Ireland excluded | [Revenue, domicile and the domicile levy](https://www.revenue.ie/en/jobs-and-pensions/tax-residence/domicile-domicile-levy.aspx) |",
      "line": 34,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [
    "exceeds €1m"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/19.txt",
  "source_key": "19",
  "source_sha256": "22d2d30d136cdc79bbc6d1f9ba7e16c51d8e611483cc51f79c2e8346d942c588",
  "source_version_basis": "ActualRevenueTDMreviewedAug2026,assignedsections1–4personallyreadwithneighbours, notwhole17pageexampleappendix."
}
```

### IE-LEVY-200000-CREDIT-DEADLINE

Annual200000minuseligibleIrishITpaidbylevypayment,noUSC/PRSI/RZLT/foreignFTC;normal31Octfollowingvaluation31Dec,conditionalROSextension.

```json
{
  "act_article_or_scope": "RevenueTDM18C2.2–2.3wholeactualPDFpp3–5",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "complete_condition_paraphrase": "Annual200000minuseligibleIrishITpaidbylevypayment,noUSC/PRSI/RZLT/foreignFTC;normal31Octfollowingvaluation31Dec,conditionalROSextension.",
  "id": "IE-LEVY-200000-CREDIT-DEADLINE",
  "official_url": "https://www.revenue.ie/en/tax-professionals/tdm/income-tax-capital-gains-tax-corporation-tax/part-18c/18c-00-01.pdf",
  "public_law": false,
  "quote_mode": "Short exact source-language extracts, whitespace normalized only; complete material conditional scope personally read, no invented requirement to reproduce full paragraphs.",
  "sections": [
    {
      "actual_text": "**Domicile levy.** The levy is the opposite case: it is charged on an individual who IS domiciled in Ireland, whatever their tax residence, if ALL of these apply in the tax year: worldwide income above the income test, Irish income tax below the tax test, AND Irish property on 31 December worth more than the property test, with no deduction for debts. Irish income tax paid for the year can be set against the levy; USC, PRSI and RZLT cannot. The credit is limited to Irish income tax paid no later than the levy; the income-tax liability gate is before foreign-tax credits. Worldwide income has a statutory computation, not simply net cash receipts; Irish-property market value ignores debts, has trading-company exceptions and anti-avoidance rules. The levy is normally paid and filed by 31 October of the following year, with the published ROS pay-and-file extension where applicable. ([Revenue, Tax and Duty Manual Part 18C-00-01](https://www.revenue.ie/en/tax-professionals/tdm/income-tax-capital-gains-tax-corporation-tax/part-18c/18c-00-01.pdf); [Revenue, domicile and the domicile levy](https://www.revenue.ie/en/jobs-and-pensions/tax-residence/domicile-domicile-levy.aspx))",
      "line": 180
    },
    {
      "actual_text": "| Domicile levy, per year | EUR 200,000 | Annual levy before eligible income-tax credit. | https://www.revenue.ie/en/tax-professionals/tdm/income-tax-capital-gains-tax-corporation-tax/part-18c/18c-00-01.pdf |",
      "line": 184
    },
    {
      "actual_text": "| Ireland | Remittance basis for non-domiciled residents | An Irish resident who is not domiciled in Ireland | No separate regime fee stated; the domicile levy of EUR 200,000 applies to Irish-domiciled people who meet all its tests | No end date while not domiciled | Foreign income and foreign gains taxed when remitted; Irish source income taxed in full; pay for duties done in Ireland excluded | [Revenue, domicile and the domicile levy](https://www.revenue.ie/en/jobs-and-pensions/tax-residence/domicile-domicile-levy.aspx) |",
      "line": 34,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [
    "€200,000"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/19.txt",
  "source_key": "19",
  "source_sha256": "22d2d30d136cdc79bbc6d1f9ba7e16c51d8e611483cc51f79c2e8346d942c588",
  "source_version_basis": "SameactualAug2026TDM2.2–2.3readwhole, noexact2027extendeddatedeadlineinvented."
}
```

### IE-LEVY-PROPERTY-ANTIAVOIDANCE

Propertymarketvalueignoresdebts;tradingcompany/holdingexceptions;ARF/partnershipandindirectIrishproperty/sharesantivoidance;family/trust/foundationbelowmarkettransferattribution.

```json
{
  "act_article_or_scope": "RevenueTDM18C3.4.1–3.4.4/4.1–4.2wholeactualPDFpp8–9with3.3/5neighbours",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "complete_condition_paraphrase": "Propertymarketvalueignoresdebts;tradingcompany/holdingexceptions;ARF/partnershipandindirectIrishproperty/sharesantivoidance;family/trust/foundationbelowmarkettransferattribution.",
  "id": "IE-LEVY-PROPERTY-ANTIAVOIDANCE",
  "official_url": "https://www.revenue.ie/en/tax-professionals/tdm/income-tax-capital-gains-tax-corporation-tax/part-18c/18c-00-01.pdf",
  "public_law": false,
  "quote_mode": "Short exact source-language extracts, whitespace normalized only; complete material conditional scope personally read, no invented requirement to reproduce full paragraphs.",
  "sections": [
    {
      "actual_text": "**Domicile levy.** The levy is the opposite case: it is charged on an individual who IS domiciled in Ireland, whatever their tax residence, if ALL of these apply in the tax year: worldwide income above the income test, Irish income tax below the tax test, AND Irish property on 31 December worth more than the property test, with no deduction for debts. Irish income tax paid for the year can be set against the levy; USC, PRSI and RZLT cannot. The credit is limited to Irish income tax paid no later than the levy; the income-tax liability gate is before foreign-tax credits. Worldwide income has a statutory computation, not simply net cash receipts; Irish-property market value ignores debts, has trading-company exceptions and anti-avoidance rules. The levy is normally paid and filed by 31 October of the following year, with the published ROS pay-and-file extension where applicable. ([Revenue, Tax and Duty Manual Part 18C-00-01](https://www.revenue.ie/en/tax-professionals/tdm/income-tax-capital-gains-tax-corporation-tax/part-18c/18c-00-01.pdf); [Revenue, domicile and the domicile levy](https://www.revenue.ie/en/jobs-and-pensions/tax-residence/domicile-domicile-levy.aspx))",
      "line": 180
    },
    {
      "actual_text": "| Ireland | Remittance basis for non-domiciled residents | An Irish resident who is not domiciled in Ireland | No separate regime fee stated; the domicile levy of EUR 200,000 applies to Irish-domiciled people who meet all its tests | No end date while not domiciled | Foreign income and foreign gains taxed when remitted; Irish source income taxed in full; pay for duties done in Ireland excluded | [Revenue, domicile and the domicile levy](https://www.revenue.ie/en/jobs-and-pensions/tax-residence/domicile-domicile-levy.aspx) |",
      "line": 34,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [
    "no deduction"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/19.txt",
  "source_key": "19",
  "source_sha256": "22d2d30d136cdc79bbc6d1f9ba7e16c51d8e611483cc51f79c2e8346d942c588",
  "source_version_basis": "SameactualAug2026TDMscopespersonallyread;headlinepropertygatenotapportionedfamilyaggregate."
}
```

### IE-GENERAL-DOMICILE

Originretaineduntilchoicewithpermanentintentionandnointentreturn;domicileversusresidencenotidentical,levyregardlessresidencelocalproperty;CAToutsideincome/CGTsource.

```json
{
  "act_article_or_scope": "RevenueWhatisdomicileactualintro/remittance/levy/property/filingwhole",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "complete_condition_paraphrase": "Originretaineduntilchoicewithpermanentintentionandnointentreturn;domicileversusresidencenotidentical,levyregardlessresidencelocalproperty;CAToutsideincome/CGTsource.",
  "id": "IE-GENERAL-DOMICILE",
  "official_url": "https://www.revenue.ie/en/jobs-and-pensions/tax-residence/domicile-domicile-levy.aspx",
  "public_law": false,
  "quote_mode": "Short exact source-language extracts, whitespace normalized only; complete material conditional scope personally read, no invented requirement to reproduce full paragraphs.",
  "sections": [
    {
      "actual_text": "An individual resident in Ireland but not domiciled there pays Irish tax on Irish source income in full and on foreign income only to the extent remitted into Ireland ([Revenue, domicile and the domicile levy](https://www.revenue.ie/en/jobs-and-pensions/tax-residence/domicile-domicile-levy.aspx)). The remittance basis rests on domicile: since tax year 2010 Irish citizenship plus non-ordinary residence alone no longer qualifies a domiciled individual; a non-domiciled citizen may still meet the domicile test. Case IV income is outside the remittance basis. Accumulated income does not automatically become capital; mixed funds, indirect remittances and spouse transfers need tracing. It also applies to foreign chargeable gains of non-domiciled individuals. Pay for duties performed in Ireland, even under a foreign employment, is taxed in full and is NOT on the remittance basis. ([Revenue, Tax and Duty Manual Part 05-01-21, the remittance basis of assessment as regards UK source income and gains](https://www.revenue.ie/en/tax-professionals/tdm/income-tax-capital-gains-tax-corporation-tax/part-05/05-01-21.pdf); [Tax and Duty Manual Part 05-01-21A](https://www.revenue.ie/en/tax-professionals/tdm/income-tax-capital-gains-tax-corporation-tax/part-05/05-01-21a.pdf))",
      "line": 178
    },
    {
      "actual_text": "**Ireland traps.** An Irish-domiciled family that moves abroad but keeps Irish property can still owe the levy, because residence does not matter for it. The pages above describe the remittance basis for income tax and capital gains tax only; gift and inheritance tax (CAT) has its own scope rules, set out in `ie-non-dom`.",
      "line": 189
    },
    {
      "actual_text": "| Ireland | Remittance basis for non-domiciled residents | An Irish resident who is not domiciled in Ireland | No separate regime fee stated; the domicile levy of EUR 200,000 applies to Irish-domiciled people who meet all its tests | No end date while not domiciled | Foreign income and foreign gains taxed when remitted; Irish source income taxed in full; pay for duties done in Ireland excluded | [Revenue, domicile and the domicile levy](https://www.revenue.ie/en/jobs-and-pensions/tax-residence/domicile-domicile-levy.aspx) |",
      "line": 34,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [
    "intend to live permanently"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/09.txt",
  "source_key": "09",
  "source_sha256": "501f4293fb641e2862e8c2004e33638732a061aee5950025d459f6d6c674e74c",
  "source_version_basis": "Actual current official source personally read16November2026; operative scope and material neighbours recorded, not download-only."
}
```

### CY-RESIDENCE-DAYS-GATES

>183totalCyprusOR60route,nootherstate>183presence+>=60Cy+business/employment/Cyresidententityoffice+owned/rentedpermanenthome;terminationyearfailsworklimb;actualarrival/departuredaysspecified.2026nootherresidentbar.

```json
{
  "act_article_or_scope": "IncomeTaxLaw118/2002Art2definitionresidentindividualwholeanddaycount, actualnative157–173;companydefinitionneighbour; historythrough67(I)/2026",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "complete_condition_paraphrase": ">183totalCyprusOR60route,nootherstate>183presence+>=60Cy+business/employment/Cyresidententityoffice+owned/rentedpermanenthome;terminationyearfailsworklimb;actualarrival/departuredaysspecified.2026nootherresidentbar.",
  "id": "CY-RESIDENCE-DAYS-GATES",
  "official_url": "https://www.cylaw.org/nomoi/enop/non-ind/2002_1_118/full.html",
  "public_law": true,
  "quote_mode": "Short exact source-language extracts, whitespace normalized only; complete material conditional scope personally read, no invented requirement to reproduce full paragraphs.",
  "sections": [
    {
      "actual_text": "An individual is Cyprus tax resident by spending more than 183 days in Cyprus in the tax year, or under the 60-day rule, which needs ALL of: at least 60 days in Cyprus, not spending more than 183 days in any one other state, a Cyprus business/employment or office in a Cyprus tax-resident person (with the statutory termination-in-year exclusion), and a permanent home in Cyprus owned or rented. An individual who is NOT domiciled in Cyprus (or not resident) pays no Special Defence Contribution (SDC) on dividends and interest; the current 2026 SDC charging provisions concern dividends and interest, not rental receipts. The former 2025 rental charge is an old historical claim, not a 2026 rate; the historic rental return remains outside current execution here. Whatever the domicile of origin, a person resident for at least 17 out of the last 20 years before the tax year is deemed domiciled, and stays so until completing 20 years of non-residence. ([IncomeTaxLaw2, actual CyprusBar consolidation](https://www.cylaw.org/nomoi/enop/non-ind/2002_1_118/full.html); [SDCLaw2/3/3B, actual CyprusBar consolidation](https://www.cylaw.org/nomoi/enop/non-ind/2002_1_117/full.html); [Tax Department, tax residency and domicile](https://www.gov.cy/mof-tax/en/documents/tax-residency-domicility/))",
      "line": 193
    },
    {
      "actual_text": "| Cyprus | Non-dom exemption from Special Defence Contribution, and the optional lump sum from 2026 | A Cyprus tax resident who is not domiciled in Cyprus; the lump sum is for people without a Cypriot domicile of origin who become deemed domiciled | No SDC on dividends or interest while non-domiciled; after deemed domicile, optional EUR 250,000 for each 5-year period (EUR 50,000 a year), up to two periods | Non-dom status until resident 17 of the last 20 years; lump sum up to two 5-year periods | SDC only; income tax is a separate question (see `cy-non-dom`) | [SDCLaw2/3D](https://www.cylaw.org/nomoi/enop/non-ind/2002_1_117/full.html) |",
      "line": 35,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [
    "εξήντα (60)"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/33-native.txt",
  "source_key": "33",
  "source_sha256": "92c0a12b127c8904f1cad387fa52b295ddc0996d44e96e171009b17bf60670e3",
  "source_version_basis": "ActualCyprusBarpublicnativeconsolidation, currenthistoryincludes244(I)/2025and2026amendments. GovernmentresidencyURL403;consolidationnotmislabelledgovernmentPDF."
}
```

### CY-DOMICILE-ORIGIN-DEEMED

SDCindividualresidentrequiresITresident+domicile;originexceptionschoiceabroad+20nonresidentyears/20beforecommencement;deemed17of20irrespectiveoriginretaineduntil20nonresidentyears.

```json
{
  "act_article_or_scope": "SDCLaw117/2002Art2(1)residentdefinition/2(3)wholeand2(2)neighbour, actualnative80–94",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "complete_condition_paraphrase": "SDCindividualresidentrequiresITresident+domicile;originexceptionschoiceabroad+20nonresidentyears/20beforecommencement;deemed17of20irrespectiveoriginretaineduntil20nonresidentyears.",
  "id": "CY-DOMICILE-ORIGIN-DEEMED",
  "official_url": "https://www.cylaw.org/nomoi/enop/non-ind/2002_1_117/full.html",
  "public_law": true,
  "quote_mode": "Short exact source-language extracts, whitespace normalized only; complete material conditional scope personally read, no invented requirement to reproduce full paragraphs.",
  "sections": [
    {
      "actual_text": "An individual is Cyprus tax resident by spending more than 183 days in Cyprus in the tax year, or under the 60-day rule, which needs ALL of: at least 60 days in Cyprus, not spending more than 183 days in any one other state, a Cyprus business/employment or office in a Cyprus tax-resident person (with the statutory termination-in-year exclusion), and a permanent home in Cyprus owned or rented. An individual who is NOT domiciled in Cyprus (or not resident) pays no Special Defence Contribution (SDC) on dividends and interest; the current 2026 SDC charging provisions concern dividends and interest, not rental receipts. The former 2025 rental charge is an old historical claim, not a 2026 rate; the historic rental return remains outside current execution here. Whatever the domicile of origin, a person resident for at least 17 out of the last 20 years before the tax year is deemed domiciled, and stays so until completing 20 years of non-residence. ([IncomeTaxLaw2, actual CyprusBar consolidation](https://www.cylaw.org/nomoi/enop/non-ind/2002_1_118/full.html); [SDCLaw2/3/3B, actual CyprusBar consolidation](https://www.cylaw.org/nomoi/enop/non-ind/2002_1_117/full.html); [Tax Department, tax residency and domicile](https://www.gov.cy/mof-tax/en/documents/tax-residency-domicility/))",
      "line": 193
    },
    {
      "actual_text": "**Cyprus traps.** The 17% interest number above is the ordinary individual rate, with statutory 3% rates for specified securities, a low-income refund rule and injury/death-compensation exemption in3B; it is not a universal charge on every interest receipt. Dividend 5% needs the pre-2026 profit and legacy 17% conditions and anti-abuse conditions in3(1)(a).  Non-dom status is an SDC rule, not an income tax exemption; income tax for residents is covered in `cy-non-dom` and `cyprus-income-tax`. The 17-of-20-year clock runs for every family member separately. Someone with a Cypriot domicile of origin cannot use the lump sum.",
      "line": 207
    },
    {
      "actual_text": "| Cyprus | Non-dom exemption from Special Defence Contribution, and the optional lump sum from 2026 | A Cyprus tax resident who is not domiciled in Cyprus; the lump sum is for people without a Cypriot domicile of origin who become deemed domiciled | No SDC on dividends or interest while non-domiciled; after deemed domicile, optional EUR 250,000 for each 5-year period (EUR 50,000 a year), up to two periods | Non-dom status until resident 17 of the last 20 years; lump sum up to two 5-year periods | SDC only; income tax is a separate question (see `cy-non-dom`) | [SDCLaw2/3D](https://www.cylaw.org/nomoi/enop/non-ind/2002_1_117/full.html) |",
      "line": 35,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [
    "δεκαεπτά (17)"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/29-native.txt",
  "source_key": "29",
  "source_sha256": "b0029645946faac564b1f688d110cfff6e2bece8a0741e3d24ab865d23958a51",
  "source_version_basis": "ActualCyprusBarstatutorynativeconsolidationthrough245(I)/2025personallyread;govURL403notclaimedread."
}
```

### CY-DIVIDEND-5-LEGACY

Residentdomiciledindividualdividends5%,reductions/legacy2025-or-earlierprofits17%within6-yearwindowandinterposedcompanyantivoidance;notall2026payments5%.

```json
{
  "act_article_or_scope": "SDCLaw3(1)(a)wholewith3(1)(b)neighbour,native116–125",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "complete_condition_paraphrase": "Residentdomiciledindividualdividends5%,reductions/legacy2025-or-earlierprofits17%within6-yearwindowandinterposedcompanyantivoidance;notall2026payments5%.",
  "id": "CY-DIVIDEND-5-LEGACY",
  "official_url": "https://www.cylaw.org/nomoi/enop/non-ind/2002_1_117/full.html",
  "public_law": true,
  "quote_mode": "Short exact source-language extracts, whitespace normalized only; complete material conditional scope personally read, no invented requirement to reproduce full paragraphs.",
  "sections": [
    {
      "actual_text": "| SDC on dividends for a resident domiciled individual, profits of 2026 onward (what the non-dom does not pay) | 5% | Article3(1)(a), with legacy-profit qualifications above. | https://www.cylaw.org/nomoi/enop/non-ind/2002_1_117/full.html |",
      "line": 200
    },
    {
      "actual_text": "**Cyprus traps.** The 17% interest number above is the ordinary individual rate, with statutory 3% rates for specified securities, a low-income refund rule and injury/death-compensation exemption in3B; it is not a universal charge on every interest receipt. Dividend 5% needs the pre-2026 profit and legacy 17% conditions and anti-abuse conditions in3(1)(a).  Non-dom status is an SDC rule, not an income tax exemption; income tax for residents is covered in `cy-non-dom` and `cyprus-income-tax`. The 17-of-20-year clock runs for every family member separately. Someone with a Cypriot domicile of origin cannot use the lump sum.",
      "line": 207
    },
    {
      "actual_text": "| Cyprus | Non-dom exemption from Special Defence Contribution, and the optional lump sum from 2026 | A Cyprus tax resident who is not domiciled in Cyprus; the lump sum is for people without a Cypriot domicile of origin who become deemed domiciled | No SDC on dividends or interest while non-domiciled; after deemed domicile, optional EUR 250,000 for each 5-year period (EUR 50,000 a year), up to two periods | Non-dom status until resident 17 of the last 20 years; lump sum up to two 5-year periods | SDC only; income tax is a separate question (see `cy-non-dom`) | [SDCLaw2/3D](https://www.cylaw.org/nomoi/enop/non-ind/2002_1_117/full.html) |",
      "line": 35,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [
    "πέντε τοις εκατό (5%)"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/29-native.txt",
  "source_key": "29",
  "source_sha256": "b0029645946faac564b1f688d110cfff6e2bece8a0741e3d24ab865d23958a51",
  "source_version_basis": "Sameactualnative2026lawversion;noforeign-taxcreditortransactionassessmentcomputed."
}
```

### CY-INTEREST-17-EXCEPTIONS

Individualordinaryinterest17%;injury/disability/deathcompensationexemption;totalincome<=12000refundexcess3%;specifiedgovernment/listedcorporate/localgovsecurities3%;notuniversal17.

```json
{
  "act_article_or_scope": "SDCLaw3B(a)(i)/(b)(i)whole+neighbours,actualnative232–240",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "complete_condition_paraphrase": "Individualordinaryinterest17%;injury/disability/deathcompensationexemption;totalincome<=12000refundexcess3%;specifiedgovernment/listedcorporate/localgovsecurities3%;notuniversal17.",
  "id": "CY-INTEREST-17-EXCEPTIONS",
  "official_url": "https://www.cylaw.org/nomoi/enop/non-ind/2002_1_117/full.html",
  "public_law": true,
  "quote_mode": "Short exact source-language extracts, whitespace normalized only; complete material conditional scope personally read, no invented requirement to reproduce full paragraphs.",
  "sections": [
    {
      "actual_text": "| SDC on interest for a resident domiciled individual (what the non-dom does not pay) | 17% | Article3B ordinary individual rate; exceptions above. | https://www.cylaw.org/nomoi/enop/non-ind/2002_1_117/full.html |",
      "line": 201
    },
    {
      "actual_text": "**Cyprus traps.** The 17% interest number above is the ordinary individual rate, with statutory 3% rates for specified securities, a low-income refund rule and injury/death-compensation exemption in3B; it is not a universal charge on every interest receipt. Dividend 5% needs the pre-2026 profit and legacy 17% conditions and anti-abuse conditions in3(1)(a).  Non-dom status is an SDC rule, not an income tax exemption; income tax for residents is covered in `cy-non-dom` and `cyprus-income-tax`. The 17-of-20-year clock runs for every family member separately. Someone with a Cypriot domicile of origin cannot use the lump sum.",
      "line": 207
    },
    {
      "actual_text": "| Cyprus | Non-dom exemption from Special Defence Contribution, and the optional lump sum from 2026 | A Cyprus tax resident who is not domiciled in Cyprus; the lump sum is for people without a Cypriot domicile of origin who become deemed domiciled | No SDC on dividends or interest while non-domiciled; after deemed domicile, optional EUR 250,000 for each 5-year period (EUR 50,000 a year), up to two periods | Non-dom status until resident 17 of the last 20 years; lump sum up to two 5-year periods | SDC only; income tax is a separate question (see `cy-non-dom`) | [SDCLaw2/3D](https://www.cylaw.org/nomoi/enop/non-ind/2002_1_117/full.html) |",
      "line": 35,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/29-native.txt",
  "source_key": "29",
  "source_sha256": "b0029645946faac564b1f688d110cfff6e2bece8a0741e3d24ab865d23958a51",
  "source_version_basis": "Sameactualnativecurrentlaw;actual3Bscopepersonallyreadwithinstitution/nonresidentcompanyneighbours."
}
```

### CY-LUMPSUM-ELIGIBILITY-PERIODS

NoCYoriginANDdeemeddomicilecanchoose50000annualfor5consecutiveyears,irrevocablebinding,approvedprescribedapplicationby30Junfirstyear,uptotwo5yearperiods.

```json
{
  "act_article_or_scope": "SDCLaw3D(1)–(3)/(9)wholewith3C/4neighbours, actualnative289–303",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "complete_condition_paraphrase": "NoCYoriginANDdeemeddomicilecanchoose50000annualfor5consecutiveyears,irrevocablebinding,approvedprescribedapplicationby30Junfirstyear,uptotwo5yearperiods.",
  "id": "CY-LUMPSUM-ELIGIBILITY-PERIODS",
  "official_url": "https://www.cylaw.org/nomoi/enop/non-ind/2002_1_117/full.html",
  "public_law": true,
  "quote_mode": "Short exact source-language extracts, whitespace normalized only; complete material conditional scope personally read, no invented requirement to reproduce full paragraphs.",
  "sections": [
    {
      "actual_text": "The 2026 reform keeps the non-dom status and adds an option (new article 3D of the SDC Law) for people who do NOT have a Cypriot domicile of origin and become deemed domiciled: they may pay a lump-sum SDC instead, for two 5-year periods. The election is irrevocable, is not automatic, needs an application approved by the Commissioner for each 5-year period, and must be filed by 30 June of the first year of that period. The lump sum for the whole period is paid by the end of the month after approval; it is not refundable and covers all SDC for those five years. Article 3D(4) is stricter than the old draft: late payment makes the article unavailable for ANY tax year, with ordinary SDC under articles3–3C; an application must separately meet3D(3). There is no set-off against other liabilities/credits or foreign-tax deduction, and no refund. The native 3D(1)–(9) has been read; the government form/circular URLs remained inaccessible, so current submission-channel/form execution remains unconfirmed. ([SDCLaw3D, actual statutory body](https://www.cylaw.org/nomoi/enop/non-ind/2002_1_117/full.html); [Tax Department, SDC presentation 2026](https://www.gov.cy/media/sites/167/2026/03/EEA-%CE%A6%CE%9A%CE%9A-%CE%9C%CE%95%CE%A4%CE%91%CE%A1%CE%A1%CE%A5%CE%98%CE%9C%CE%99%CE%A3%CE%97-06032026.pdf); [Application form, article 3D](https://www.gov.cy/media/sites/167/2026/06/Application-Extension-of-Non-Dom.pdf))",
      "line": 195
    },
    {
      "actual_text": "| Lump-sum SDC, per year, article 3D | EUR 50,000 | Article3D(1); annual amount paid for the entire approved period. | https://www.cylaw.org/nomoi/enop/non-ind/2002_1_117/full.html |",
      "line": 199
    },
    {
      "actual_text": "| Cyprus | Non-dom exemption from Special Defence Contribution, and the optional lump sum from 2026 | A Cyprus tax resident who is not domiciled in Cyprus; the lump sum is for people without a Cypriot domicile of origin who become deemed domiciled | No SDC on dividends or interest while non-domiciled; after deemed domicile, optional EUR 250,000 for each 5-year period (EUR 50,000 a year), up to two periods | Non-dom status until resident 17 of the last 20 years; lump sum up to two 5-year periods | SDC only; income tax is a separate question (see `cy-non-dom`) | [SDCLaw2/3D](https://www.cylaw.org/nomoi/enop/non-ind/2002_1_117/full.html) |",
      "line": 35,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/29-native.txt",
  "source_key": "29",
  "source_sha256": "b0029645946faac564b1f688d110cfff6e2bece8a0741e3d24ab865d23958a51",
  "source_version_basis": "SameactualCyprusBarstatutory3Dnativebody;unrecoveredofficialform/circular remainsindividuallyheld."
}
```

### CY-LUMPSUM-PAYMENT-DEFAULT

250000singlefull5yearpaymentbyendmonthafterapproval;latepaymentarticleinapplicableANYyear;nootherliability/creditsetoff,noFTC,norefund,paymentexhaustsSDC5years.

```json
{
  "act_article_or_scope": "SDCLaw3D(4)–(8)whole, actualnative293–301",
  "actual_read_on": "2026-11-16",
  "candidate_sha256": "4142b8cb7677053d271c20e80336494326da1dc5766ee1ec94e30df78af3af9f",
  "complete_condition_paraphrase": "250000singlefull5yearpaymentbyendmonthafterapproval;latepaymentarticleinapplicableANYyear;nootherliability/creditsetoff,noFTC,norefund,paymentexhaustsSDC5years.",
  "id": "CY-LUMPSUM-PAYMENT-DEFAULT",
  "official_url": "https://www.cylaw.org/nomoi/enop/non-ind/2002_1_117/full.html",
  "public_law": true,
  "quote_mode": "Short exact source-language extracts, whitespace normalized only; complete material conditional scope personally read, no invented requirement to reproduce full paragraphs.",
  "sections": [
    {
      "actual_text": "The 2026 reform keeps the non-dom status and adds an option (new article 3D of the SDC Law) for people who do NOT have a Cypriot domicile of origin and become deemed domiciled: they may pay a lump-sum SDC instead, for two 5-year periods. The election is irrevocable, is not automatic, needs an application approved by the Commissioner for each 5-year period, and must be filed by 30 June of the first year of that period. The lump sum for the whole period is paid by the end of the month after approval; it is not refundable and covers all SDC for those five years. Article 3D(4) is stricter than the old draft: late payment makes the article unavailable for ANY tax year, with ordinary SDC under articles3–3C; an application must separately meet3D(3). There is no set-off against other liabilities/credits or foreign-tax deduction, and no refund. The native 3D(1)–(9) has been read; the government form/circular URLs remained inaccessible, so current submission-channel/form execution remains unconfirmed. ([SDCLaw3D, actual statutory body](https://www.cylaw.org/nomoi/enop/non-ind/2002_1_117/full.html); [Tax Department, SDC presentation 2026](https://www.gov.cy/media/sites/167/2026/03/EEA-%CE%A6%CE%9A%CE%9A-%CE%9C%CE%95%CE%A4%CE%91%CE%A1%CE%A1%CE%A5%CE%98%CE%9C%CE%99%CE%A3%CE%97-06032026.pdf); [Application form, article 3D](https://www.gov.cy/media/sites/167/2026/06/Application-Extension-of-Non-Dom.pdf))",
      "line": 195
    },
    {
      "actual_text": "| Lump-sum SDC for each whole 5-year period, paid in one go | EUR 250,000 | Article 3D(4); single payment with statutory deadline and no-refund conditions. | https://www.cylaw.org/nomoi/enop/non-ind/2002_1_117/full.html |",
      "line": 205
    },
    {
      "actual_text": "| Cyprus | Non-dom exemption from Special Defence Contribution, and the optional lump sum from 2026 | A Cyprus tax resident who is not domiciled in Cyprus; the lump sum is for people without a Cypriot domicile of origin who become deemed domiciled | No SDC on dividends or interest while non-domiciled; after deemed domicile, optional EUR 250,000 for each 5-year period (EUR 50,000 a year), up to two periods | Non-dom status until resident 17 of the last 20 years; lump sum up to two 5-year periods | SDC only; income tax is a separate question (see `cy-non-dom`) | [SDCLaw2/3D](https://www.cylaw.org/nomoi/enop/non-ind/2002_1_117/full.html) |",
      "line": 35,
      "role": "Summary-countryrow; fullprecisebodyclaim/nativeconditiongrouppreserved."
    }
  ],
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/family-office/sources/29-native.txt",
  "source_key": "29",
  "source_sha256": "b0029645946faac564b1f688d110cfff6e2bece8a0741e3d24ab865d23958a51",
  "source_version_basis": "Sameactual3Dnativeoperative+neighbourread;notreadgovformscope."
}
```

## Original-topic destinations

The complete original-topic destination table is in `../family-office-residency-regimes-compared/old-topic-map.json`.
