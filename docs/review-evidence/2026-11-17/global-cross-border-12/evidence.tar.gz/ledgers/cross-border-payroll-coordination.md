# cross-border-payroll-coordination figure and rule ledger

Public projection; canonical private SHA256: `acfa0f4be82831204ae7acf6262ca072c2c4e834e0c6f95fcf70c34c4cb07520`. Complete captured/native source passages remain local. The JSON companion preserves every retained evidence field.

## Whole rule groups

### 1

# Cross-border payroll coordination

```json
{
  "figures": [],
  "id": 1,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 16,
  "operative_bindings": [],
  "section": "Who this applies to",
  "source_keys": []
}
```

### 2

Use the worker's actual location, employment facts and applicable treaty or coordination instrument to decide each obligation separately. A short visit, foreign payroll or contractor label does not establish an exemption.

```json
{
  "figures": [],
  "id": 2,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 18,
  "operative_bindings": [],
  "section": "Who this applies to",
  "source_keys": []
}
```

### 3

## Who this applies to

```json
{
  "figures": [],
  "id": 3,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 20,
  "operative_bindings": [],
  "section": "Who this applies to",
  "source_keys": []
}
```

### 4

For employers, employees, self-employed people and advisers planning remote work, assignments, business travel, shadow payroll or cross-border equity awards. The jurisdictions retained here are the EU, UK, US, Australia, India, Singapore and the individual country examples below. Contributor: OpenAccountants. This is a source-cited draft, not an accountant attestation.

```json
{
  "figures": [],
  "id": 4,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 22,
  "operative_bindings": [],
  "section": "Who this applies to",
  "source_keys": []
}
```

### 5

The former May 2026 validation and 2025 tax-year label did not establish current law. This revision distinguishes sources actually read, historical consolidations with a current amendment overlay, model provisions and individually unresolved national execution rules. Do not treat a model as the actual treaty.

```json
{
  "figures": [
    "2026",
    "2025"
  ],
  "id": 5,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 24,
  "operative_bindings": [],
  "section": "Who this applies to",
  "source_keys": []
}
```

### 6

| Obligation | Decision to make |

```json
{
  "figures": [],
  "id": 6,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 26,
  "operative_bindings": [],
  "section": "Who this applies to",
  "source_keys": []
}
```

### 7

| Employment income tax | Identify residence, actual work state, remuneration, domestic charge and the actual treaty's employment article and exceptions. Taxing rights and the employer's collection procedure are separate questions. [OECD Model 2025, employment article and Commentary](https://www.oecd.org/content/dam/oecd/en/publications/reports/2026/06/model-tax-convention-on-income-and-on-capital-2025-full-version_4fd97b89/db32e18b-en.pdf) [UK–Germany treaty, consolidated after2021Protocol](https://www.gov.uk/government/publications/germany-tax-treaties/2010-uk-germany-double-taxation-convention-as-amended-by-the-2021-protocol-in-force) |

```json
{
  "figures": [],
  "id": 7,
  "kind": "source-cited rule and its explicit conditions",
  "line": 28,
  "operative_bindings": [
    {
      "locator": "Article15(1)",
      "quote_id": "MODEL-001",
      "read_date": "2026-11-16",
      "source": "MODEL",
      "url": "https://www.oecd.org/content/dam/oecd/en/publications/reports/2026/06/model-tax-convention-on-income-and-on-capital-2025-full-version_4fd97b89/db32e18b-en.pdf"
    },
    {
      "locator": "Commentary15paragraph8.13",
      "quote_id": "MODEL-005",
      "read_date": "2026-11-16",
      "source": "MODEL",
      "url": "https://www.oecd.org/content/dam/oecd/en/publications/reports/2026/06/model-tax-convention-on-income-and-on-capital-2025-full-version_4fd97b89/db32e18b-en.pdf"
    },
    {
      "locator": "Article14(1)",
      "quote_id": "UKDE-007",
      "read_date": "2026-11-16",
      "source": "UKDE",
      "url": "https://www.gov.uk/government/publications/germany-tax-treaties/2010-uk-germany-double-taxation-convention-as-amended-by-the-2021-protocol-in-force"
    },
    {
      "locator": "Article14(2)(a)",
      "quote_id": "UKDE-008",
      "read_date": "2026-11-16",
      "source": "UKDE",
      "url": "https://www.gov.uk/government/publications/germany-tax-treaties/2010-uk-germany-double-taxation-convention-as-amended-by-the-2021-protocol-in-force"
    }
  ],
  "section": "Who this applies to",
  "source_keys": [
    "MODEL",
    "UKDE"
  ]
}
```

### 8

| Social security | Identify personal/material scope and the competent system; use the actual posting, multistate or bilateral conditions. An income-tax day count does not decide coverage. [Regulation883/2004,31July2019consolidation](https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1) [Regulation987/2009,1January2018consolidation](https://publications.europa.eu/resource/cellar/00185d05-a69f-4055-8a8e-341c14c29d50.0020.02/DOC_1) [US–Portugal SocialSecurityAgreement](https://www.ssa.gov/international/Agreement_Texts/portugal.html) |

```json
{
  "figures": [
    "83",
    "87"
  ],
  "id": 8,
  "kind": "source-cited rule and its explicit conditions",
  "line": 29,
  "operative_bindings": [
    {
      "locator": "Article2",
      "quote_id": "EU883-020",
      "read_date": "2026-11-16",
      "source": "EU883",
      "url": "https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1"
    },
    {
      "locator": "Article12(1)/(2)",
      "quote_id": "EU883-014",
      "read_date": "2026-11-16",
      "source": "EU883",
      "url": "https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1"
    },
    {
      "locator": "Article14(2)",
      "quote_id": "EU987-022",
      "read_date": "2026-11-16",
      "source": "EU987",
      "url": "https://publications.europa.eu/resource/cellar/00185d05-a69f-4055-8a8e-341c14c29d50.0020.02/DOC_1"
    },
    {
      "locator": "Article15(1)",
      "quote_id": "EU987-025",
      "read_date": "2026-11-16",
      "source": "EU987",
      "url": "https://publications.europa.eu/resource/cellar/00185d05-a69f-4055-8a8e-341c14c29d50.0020.02/DOC_1"
    },
    {
      "locator": "Article4(1)",
      "quote_id": "USPT-051",
      "read_date": "2026-11-16",
      "source": "USPT",
      "url": "https://www.ssa.gov/international/Agreement_Texts/portugal.html"
    },
    {
      "locator": "Article5(1)",
      "quote_id": "USPT-048",
      "read_date": "2026-11-16",
      "source": "USPT",
      "url": "https://www.ssa.gov/international/Agreement_Texts/portugal.html"
    }
  ],
  "section": "Who this applies to",
  "source_keys": [
    "EU883",
    "EU987",
    "USPT"
  ]
}
```

### 9

| Employment protection | Identify applicable law and mandatory host protections. Choosing a foreign law cannot necessarily remove habitual-work protections. The UK retained Rome I Article 8 is a bounded example, not a worldwide conflict rule. [UK-retained RomeI Article8](https://www.legislation.gov.uk/eur/2008/593/article/8/data.html) |

```json
{
  "figures": [
    "8"
  ],
  "id": 9,
  "kind": "source-cited rule and its explicit conditions",
  "line": 30,
  "operative_bindings": [
    {
      "locator": "Article8(1)",
      "quote_id": "ROME-040",
      "read_date": "2026-11-16",
      "source": "ROME",
      "url": "https://www.legislation.gov.uk/eur/2008/593/article/8/data.html"
    },
    {
      "locator": "Article8(2)",
      "quote_id": "ROME-041",
      "read_date": "2026-11-16",
      "source": "ROME",
      "url": "https://www.legislation.gov.uk/eur/2008/593/article/8/data.html"
    }
  ],
  "section": "Who this applies to",
  "source_keys": [
    "ROME"
  ]
}
```

### 10

| Employer corporate tax | Assess fixed-place, dependent-agent and any actual service/construction clause independently. A payroll registration or EOR arrangement is not a universal PE exemption. [UK–Germany treaty, consolidated after2021Protocol](https://www.gov.uk/government/publications/germany-tax-treaties/2010-uk-germany-double-taxation-convention-as-amended-by-the-2021-protocol-in-force) |

```json
{
  "figures": [],
  "id": 10,
  "kind": "source-cited rule and its explicit conditions",
  "line": 31,
  "operative_bindings": [
    {
      "locator": "Article5(1)",
      "quote_id": "UKDE-100",
      "read_date": "2026-11-16",
      "source": "UKDE",
      "url": "https://www.gov.uk/government/publications/germany-tax-treaties/2010-uk-germany-double-taxation-convention-as-amended-by-the-2021-protocol-in-force"
    },
    {
      "locator": "Article5(5)",
      "quote_id": "UKDE-101",
      "read_date": "2026-11-16",
      "source": "UKDE",
      "url": "https://www.gov.uk/government/publications/germany-tax-treaties/2010-uk-germany-double-taxation-convention-as-amended-by-the-2021-protocol-in-force"
    },
    {
      "locator": "Article5(1)",
      "quote_id": "UKDE-100",
      "read_date": "2026-11-16",
      "source": "UKDE",
      "url": "https://www.gov.uk/government/publications/germany-tax-treaties/2010-uk-germany-double-taxation-convention-as-amended-by-the-2021-protocol-in-force"
    },
    {
      "locator": "Article5(5)",
      "quote_id": "UKDE-101",
      "read_date": "2026-11-16",
      "source": "UKDE",
      "url": "https://www.gov.uk/government/publications/germany-tax-treaties/2010-uk-germany-double-taxation-convention-as-amended-by-the-2021-protocol-in-force"
    },
    {
      "locator": "Article5(4A)",
      "quote_id": "UKDE-102",
      "read_date": "2026-11-16",
      "source": "UKDE",
      "url": "https://www.gov.uk/government/publications/germany-tax-treaties/2010-uk-germany-double-taxation-convention-as-amended-by-the-2021-protocol-in-force"
    }
  ],
  "section": "Who this applies to",
  "source_keys": [
    "UKDE"
  ]
}
```

### 11

## Rates, bands and thresholds

```json
{
  "figures": [],
  "id": 11,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 33,
  "operative_bindings": [],
  "section": "Rates, bands and thresholds",
  "source_keys": []
}
```

### 12

| Figure | Operative boundary |

```json
{
  "figures": [],
  "id": 12,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 35,
  "operative_bindings": [],
  "section": "Rates, bands and thresholds",
  "source_keys": []
}
```

### 13

| 183 days | OECD Model Article 15(2) uses **not exceeding** 183 days in any twelve-month period commencing or ending in the fiscal year; all three conditions must hold. Actual treaty wording controls. UK–Germany uses Article **14**, not Article 15. [OECD Model 2025, employment article and Commentary](https://www.oecd.org/content/dam/oecd/en/publications/reports/2026/06/model-tax-convention-on-income-and-on-capital-2025-full-version_4fd97b89/db32e18b-en.pdf) [UK–Germany treaty, consolidated after2021Protocol](https://www.gov.uk/government/publications/germany-tax-treaties/2010-uk-germany-double-taxation-convention-as-amended-by-the-2021-protocol-in-force) |

```json
{
  "figures": [
    "183",
    "15",
    "2",
    "183",
    "14",
    "15"
  ],
  "id": 13,
  "kind": "source-cited rule and its explicit conditions",
  "line": 37,
  "operative_bindings": [
    {
      "locator": "Article15(2)(a)",
      "quote_id": "MODEL-002",
      "read_date": "2026-11-16",
      "source": "MODEL",
      "url": "https://www.oecd.org/content/dam/oecd/en/publications/reports/2026/06/model-tax-convention-on-income-and-on-capital-2025-full-version_4fd97b89/db32e18b-en.pdf"
    },
    {
      "locator": "Article15(2)(c)",
      "quote_id": "MODEL-006",
      "read_date": "2026-11-16",
      "source": "MODEL",
      "url": "https://www.oecd.org/content/dam/oecd/en/publications/reports/2026/06/model-tax-convention-on-income-and-on-capital-2025-full-version_4fd97b89/db32e18b-en.pdf"
    },
    {
      "locator": "Article14(2)(a)",
      "quote_id": "UKDE-008",
      "read_date": "2026-11-16",
      "source": "UKDE",
      "url": "https://www.gov.uk/government/publications/germany-tax-treaties/2010-uk-germany-double-taxation-convention-as-amended-by-the-2021-protocol-in-force"
    },
    {
      "locator": "Article5(3)",
      "quote_id": "UKDE-010",
      "read_date": "2026-11-16",
      "source": "UKDE",
      "url": "https://www.gov.uk/government/publications/germany-tax-treaties/2010-uk-germany-double-taxation-convention-as-amended-by-the-2021-protocol-in-force"
    }
  ],
  "section": "Rates, bands and thresholds",
  "source_keys": [
    "MODEL",
    "UKDE"
  ]
}
```

### 14

| 24 months | Current EU Article 12 posting requires the stated anticipated period, the employer's normal activity and no replacement of another posted person; self-employment has its own similar-activity test. It is not an automatically renewable A1 term. [Regulation883/2004,31July2019consolidation](https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1) |

```json
{
  "figures": [
    "24",
    "12",
    "83"
  ],
  "id": 14,
  "kind": "source-cited rule and its explicit conditions",
  "line": 38,
  "operative_bindings": [
    {
      "locator": "Article12(1)/(2)",
      "quote_id": "EU883-014",
      "read_date": "2026-11-16",
      "source": "EU883",
      "url": "https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1"
    },
    {
      "locator": "Article12(1)",
      "quote_id": "EU883-015",
      "read_date": "2026-11-16",
      "source": "EU883",
      "url": "https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1"
    }
  ],
  "section": "Rates, bands and thresholds",
  "source_keys": [
    "EU883"
  ]
}
```

### 15

| Less than 25% | Under implementing Article 14(8), this is an **indicator** that a substantial part is not performed in the state, within an overall assessment. It is not an isolated automatic residence-country switch. [Regulation987/2009,1January2018consolidation](https://publications.europa.eu/resource/cellar/00185d05-a69f-4055-8a8e-341c14c29d50.0020.02/DOC_1) |

```json
{
  "figures": [
    "25%",
    "14",
    "8",
    "87"
  ],
  "id": 15,
  "kind": "source-cited rule and its explicit conditions",
  "line": 39,
  "operative_bindings": [
    {
      "locator": "Article14(8)",
      "quote_id": "EU987-023",
      "read_date": "2026-11-16",
      "source": "EU987",
      "url": "https://publications.europa.eu/resource/cellar/00185d05-a69f-4055-8a8e-341c14c29d50.0020.02/DOC_1"
    },
    {
      "locator": "Article16(1)",
      "quote_id": "EU987-026",
      "read_date": "2026-11-16",
      "source": "EU987",
      "url": "https://publications.europa.eu/resource/cellar/00185d05-a69f-4055-8a8e-341c14c29d50.0020.02/DOC_1"
    }
  ],
  "section": "Rates, bands and thresholds",
  "source_keys": [
    "EU987"
  ]
}
```

### 16

| Less than 50% | The 2023 telework Framework is an Article 16 exception **on request**, with eligible signatory states and the other conditions below. Exactly 50% is outside that Framework route. [2023Framework Agreement on cross-border telework](https://socialsecurity.belgium.be/sites/default/files/content/docs/en/international/framework_agreement_on_cross-border_telework.pdf) |

```json
{
  "figures": [
    "50%",
    "2023",
    "16",
    "50%"
  ],
  "id": 16,
  "kind": "source-cited rule and its explicit conditions",
  "line": 40,
  "operative_bindings": [
    {
      "locator": "Article3(1)",
      "quote_id": "FRAME-034",
      "read_date": "2026-11-16",
      "source": "FRAME",
      "url": "https://socialsecurity.belgium.be/sites/default/files/content/docs/en/international/framework_agreement_on_cross-border_telework.pdf"
    },
    {
      "locator": "Article3(1)",
      "quote_id": "FRAME-035",
      "read_date": "2026-11-16",
      "source": "FRAME",
      "url": "https://socialsecurity.belgium.be/sites/default/files/content/docs/en/international/framework_agreement_on_cross-border_telework.pdf"
    }
  ],
  "section": "Rates, bands and thresholds",
  "source_keys": [
    "FRAME"
  ]
}
```

### 17

| 1 November 2026 / 2 November 2028 | Regulation 2026/2359 entered into force on the former date; listed attestation changes apply then, but the revised posting and business-trip notification provisions identified below apply from the latter date. [Regulation(EU)2026/2359, enacted English body](https://publications.europa.eu/resource/cellar/5794f71b-d1a7-11f1-9458-01aa75ed71a1.0006.03/DOC_1) |

```json
{
  "figures": [
    "1",
    "2026",
    "2",
    "2028",
    "2026",
    "2359",
    "026"
  ],
  "id": 17,
  "kind": "source-cited rule and its explicit conditions",
  "line": 41,
  "operative_bindings": [
    {
      "locator": "Article1(39)/Article2(52),applicationlists",
      "quote_id": "EU2026-028",
      "read_date": "2026-11-16",
      "source": "EU2026",
      "url": "https://publications.europa.eu/resource/cellar/5794f71b-d1a7-11f1-9458-01aa75ed71a1.0006.03/DOC_1"
    },
    {
      "locator": "Article1(39)/Article2(52),immediatelist",
      "quote_id": "EU2026-029",
      "read_date": "2026-11-16",
      "source": "EU2026",
      "url": "https://publications.europa.eu/resource/cellar/5794f71b-d1a7-11f1-9458-01aa75ed71a1.0006.03/DOC_1"
    }
  ],
  "section": "Rates, bands and thresholds",
  "source_keys": [
    "EU2026"
  ]
}
```

### 18

## The base

```json
{
  "figures": [],
  "id": 18,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 43,
  "operative_bindings": [],
  "section": "The base",
  "source_keys": []
}
```

### 19

### Step 1: choose an employment arrangement after checking the obligations

```json
{
  "figures": [
    "1"
  ],
  "id": 19,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 45,
  "operative_bindings": [],
  "section": "Step 1: choose an employment arrangement after checking the obligations",
  "source_keys": []
}
```

### 20

| Arrangement | What to document |

```json
{
  "figures": [],
  "id": 20,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 47,
  "operative_bindings": [],
  "section": "Step 1: choose an employment arrangement after checking the obligations",
  "source_keys": []
}
```

### 21

| Local subsidiary or branch | Identify the actual employer, local payroll/registration and who bears remuneration. A subsidiary's existence or group control alone does not create its parent's PE under UK–Germany Article 5(7). [UK–Germany treaty, consolidated after2021Protocol](https://www.gov.uk/government/publications/germany-tax-treaties/2010-uk-germany-double-taxation-convention-as-amended-by-the-2021-protocol-in-force) |

```json
{
  "figures": [
    "5",
    "7"
  ],
  "id": 21,
  "kind": "source-cited rule and its explicit conditions",
  "line": 49,
  "operative_bindings": [
    {
      "locator": "Article5(7)",
      "quote_id": "UKDE-011",
      "read_date": "2026-11-16",
      "source": "UKDE",
      "url": "https://www.gov.uk/government/publications/germany-tax-treaties/2010-uk-germany-double-taxation-convention-as-amended-by-the-2021-protocol-in-force"
    },
    {
      "locator": "Article14(2)(c)",
      "quote_id": "UKDE-009",
      "read_date": "2026-11-16",
      "source": "UKDE",
      "url": "https://www.gov.uk/government/publications/germany-tax-treaties/2010-uk-germany-double-taxation-convention-as-amended-by-the-2021-protocol-in-force"
    }
  ],
  "section": "Step 1: choose an employment arrangement after checking the obligations",
  "source_keys": [
    "UKDE"
  ]
}
```

### 22

| Employer of Record | Identify the licensed/legal employer, supervision, employment protections, payroll collection, social coverage and contractual allocation of duties. Do not assume outsourcing removes the end user's treaty-employer or PE analysis. [OECD Model 2025, employment article and Commentary](https://www.oecd.org/content/dam/oecd/en/publications/reports/2026/06/model-tax-convention-on-income-and-on-capital-2025-full-version_4fd97b89/db32e18b-en.pdf) [UK–Germany treaty, consolidated after2021Protocol](https://www.gov.uk/government/publications/germany-tax-treaties/2010-uk-germany-double-taxation-convention-as-amended-by-the-2021-protocol-in-force) |

```json
{
  "figures": [],
  "id": 22,
  "kind": "source-cited rule and its explicit conditions",
  "line": 50,
  "operative_bindings": [
    {
      "locator": "Article15(1)",
      "quote_id": "MODEL-001",
      "read_date": "2026-11-16",
      "source": "MODEL",
      "url": "https://www.oecd.org/content/dam/oecd/en/publications/reports/2026/06/model-tax-convention-on-income-and-on-capital-2025-full-version_4fd97b89/db32e18b-en.pdf"
    },
    {
      "locator": "Commentary15paragraph8.13",
      "quote_id": "MODEL-005",
      "read_date": "2026-11-16",
      "source": "MODEL",
      "url": "https://www.oecd.org/content/dam/oecd/en/publications/reports/2026/06/model-tax-convention-on-income-and-on-capital-2025-full-version_4fd97b89/db32e18b-en.pdf"
    },
    {
      "locator": "Article14(1)",
      "quote_id": "UKDE-007",
      "read_date": "2026-11-16",
      "source": "UKDE",
      "url": "https://www.gov.uk/government/publications/germany-tax-treaties/2010-uk-germany-double-taxation-convention-as-amended-by-the-2021-protocol-in-force"
    },
    {
      "locator": "Article5(1)",
      "quote_id": "UKDE-100",
      "read_date": "2026-11-16",
      "source": "UKDE",
      "url": "https://www.gov.uk/government/publications/germany-tax-treaties/2010-uk-germany-double-taxation-convention-as-amended-by-the-2021-protocol-in-force"
    }
  ],
  "section": "Step 1: choose an employment arrangement after checking the obligations",
  "source_keys": [
    "MODEL",
    "UKDE"
  ]
}
```

### 23

| Direct employment without a local entity | Check whether foreign-employer registration, withholding, reporting and representation are required or available in the work state. Short duration or a single worker is not clearance. This Guide does not verify every national registration route. |

```json
{
  "figures": [],
  "id": 23,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 51,
  "operative_bindings": [],
  "section": "Step 1: choose an employment arrangement after checking the obligations",
  "source_keys": []
}
```

### 24

The former EOR **1–10 employee** recommendation and **USD 300–700 per employee/month** range are not verified current market facts or legal thresholds. They remain individually non-usable in Sources. A commercial quote must cover the actual services and local licensing conditions.

```json
{
  "figures": [
    "1",
    "10",
    "300",
    "700"
  ],
  "id": 24,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 53,
  "operative_bindings": [],
  "section": "Step 1: choose an employment arrangement after checking the obligations",
  "source_keys": []
}
```

### 25

For PE risk, an actual fixed place and the business carried on through it require analysis; employer consent to a home office alone is insufficient. Dependent-agent provisions require their actual contracting conditions. Preparatory/auxiliary exceptions have their own scope and anti-fragmentation conditions. There is no universal **more-than-six-month** employee/project safe harbour or PE trigger: the read UK–Germany treaty, for example, uses **more than twelve months** for a building site/construction or installation project. Use `permanent-establishment-risk` for the fuller analysis. [UK–Germany treaty, consolidated after2021Protocol](https://www.gov.uk/government/publications/germany-tax-treaties/2010-uk-germany-double-taxation-convention-as-amended-by-the-2021-protocol-in-force)

```json
{
  "figures": [],
  "id": 25,
  "kind": "source-cited rule and its explicit conditions",
  "line": 55,
  "operative_bindings": [
    {
      "locator": "Article5(3)",
      "quote_id": "UKDE-010",
      "read_date": "2026-11-16",
      "source": "UKDE",
      "url": "https://www.gov.uk/government/publications/germany-tax-treaties/2010-uk-germany-double-taxation-convention-as-amended-by-the-2021-protocol-in-force"
    },
    {
      "locator": "Article5(1)",
      "quote_id": "UKDE-100",
      "read_date": "2026-11-16",
      "source": "UKDE",
      "url": "https://www.gov.uk/government/publications/germany-tax-treaties/2010-uk-germany-double-taxation-convention-as-amended-by-the-2021-protocol-in-force"
    },
    {
      "locator": "Article5(1)",
      "quote_id": "UKDE-100",
      "read_date": "2026-11-16",
      "source": "UKDE",
      "url": "https://www.gov.uk/government/publications/germany-tax-treaties/2010-uk-germany-double-taxation-convention-as-amended-by-the-2021-protocol-in-force"
    },
    {
      "locator": "Article5(5)",
      "quote_id": "UKDE-101",
      "read_date": "2026-11-16",
      "source": "UKDE",
      "url": "https://www.gov.uk/government/publications/germany-tax-treaties/2010-uk-germany-double-taxation-convention-as-amended-by-the-2021-protocol-in-force"
    },
    {
      "locator": "Article5(4A)",
      "quote_id": "UKDE-102",
      "read_date": "2026-11-16",
      "source": "UKDE",
      "url": "https://www.gov.uk/government/publications/germany-tax-treaties/2010-uk-germany-double-taxation-convention-as-amended-by-the-2021-protocol-in-force"
    }
  ],
  "section": "Step 1: choose an employment arrangement after checking the obligations",
  "source_keys": [
    "UKDE"
  ]
}
```

### 26

### Step 2: plan remote work before it starts

```json
{
  "figures": [
    "2"
  ],
  "id": 26,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 57,
  "operative_bindings": [],
  "section": "Step 2: plan remote work before it starts",
  "source_keys": []
}
```

### 27

| Original scenario | Required analysis |

```json
{
  "figures": [],
  "id": 27,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 59,
  "operative_bindings": [],
  "section": "Step 2: plan remote work before it starts",
  "source_keys": []
}
```

### 28

| Short stay, originally “under 183 days” | Check all actual treaty conditions, domestic collection relief, social coverage and employment/immigration rules. A visit of even a few days can fail the nonresident-employer limb; social-security documentation has a different test. [OECD Model 2025, employment article and Commentary](https://www.oecd.org/content/dam/oecd/en/publications/reports/2026/06/model-tax-convention-on-income-and-on-capital-2025-full-version_4fd97b89/db32e18b-en.pdf) [Regulation883/2004,31July2019consolidation](https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1) |

```json
{
  "figures": [
    "183",
    "83"
  ],
  "id": 28,
  "kind": "source-cited rule and its explicit conditions",
  "line": 61,
  "operative_bindings": [
    {
      "locator": "Article15(2)(c)",
      "quote_id": "MODEL-006",
      "read_date": "2026-11-16",
      "source": "MODEL",
      "url": "https://www.oecd.org/content/dam/oecd/en/publications/reports/2026/06/model-tax-convention-on-income-and-on-capital-2025-full-version_4fd97b89/db32e18b-en.pdf"
    },
    {
      "locator": "Article15(2)(a)",
      "quote_id": "MODEL-002",
      "read_date": "2026-11-16",
      "source": "MODEL",
      "url": "https://www.oecd.org/content/dam/oecd/en/publications/reports/2026/06/model-tax-convention-on-income-and-on-capital-2025-full-version_4fd97b89/db32e18b-en.pdf"
    },
    {
      "locator": "Article12(1)",
      "quote_id": "EU883-015",
      "read_date": "2026-11-16",
      "source": "EU883",
      "url": "https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1"
    },
    {
      "locator": "Article16(1)",
      "quote_id": "EU883-019",
      "read_date": "2026-11-16",
      "source": "EU883",
      "url": "https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1"
    }
  ],
  "section": "Step 2: plan remote work before it starts",
  "source_keys": [
    "MODEL",
    "EU883"
  ]
}
```

### 29

| Longer stay or failed treaty condition | Identify the host-attributable remuneration and domestic tax/withholding procedure. Do not tax all worldwide salary merely because one exemption condition fails. [OECD Model 2025, employment article and Commentary](https://www.oecd.org/content/dam/oecd/en/publications/reports/2026/06/model-tax-convention-on-income-and-on-capital-2025-full-version_4fd97b89/db32e18b-en.pdf) [UK–Germany treaty, consolidated after2021Protocol](https://www.gov.uk/government/publications/germany-tax-treaties/2010-uk-germany-double-taxation-convention-as-amended-by-the-2021-protocol-in-force) |

```json
{
  "figures": [],
  "id": 29,
  "kind": "source-cited rule and its explicit conditions",
  "line": 62,
  "operative_bindings": [
    {
      "locator": "Article15(1)",
      "quote_id": "MODEL-001",
      "read_date": "2026-11-16",
      "source": "MODEL",
      "url": "https://www.oecd.org/content/dam/oecd/en/publications/reports/2026/06/model-tax-convention-on-income-and-on-capital-2025-full-version_4fd97b89/db32e18b-en.pdf"
    },
    {
      "locator": "Article15(2)(c)",
      "quote_id": "MODEL-006",
      "read_date": "2026-11-16",
      "source": "MODEL",
      "url": "https://www.oecd.org/content/dam/oecd/en/publications/reports/2026/06/model-tax-convention-on-income-and-on-capital-2025-full-version_4fd97b89/db32e18b-en.pdf"
    },
    {
      "locator": "Article14(2)(a)",
      "quote_id": "UKDE-008",
      "read_date": "2026-11-16",
      "source": "UKDE",
      "url": "https://www.gov.uk/government/publications/germany-tax-treaties/2010-uk-germany-double-taxation-convention-as-amended-by-the-2021-protocol-in-force"
    },
    {
      "locator": "Article14(1)",
      "quote_id": "UKDE-007",
      "read_date": "2026-11-16",
      "source": "UKDE",
      "url": "https://www.gov.uk/government/publications/germany-tax-treaties/2010-uk-germany-double-taxation-convention-as-amended-by-the-2021-protocol-in-force"
    }
  ],
  "section": "Step 2: plan remote work before it starts",
  "source_keys": [
    "MODEL",
    "UKDE"
  ]
}
```

### 30

| Permanent relocation | Revisit residence, ordinary work-state coverage, payroll, contract and mandatory employment protections. Home payroll continuing is not proof that home law continues. [Regulation883/2004,31July2019consolidation](https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1) [UK-retained RomeI Article8](https://www.legislation.gov.uk/eur/2008/593/article/8/data.html) |

```json
{
  "figures": [
    "83"
  ],
  "id": 30,
  "kind": "source-cited rule and its explicit conditions",
  "line": 63,
  "operative_bindings": [
    {
      "locator": "Article11(1)",
      "quote_id": "EU883-013",
      "read_date": "2026-11-16",
      "source": "EU883",
      "url": "https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1"
    },
    {
      "locator": "Article13(1)/(2)",
      "quote_id": "EU883-017",
      "read_date": "2026-11-16",
      "source": "EU883",
      "url": "https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1"
    },
    {
      "locator": "Article8(1)",
      "quote_id": "ROME-040",
      "read_date": "2026-11-16",
      "source": "ROME",
      "url": "https://www.legislation.gov.uk/eur/2008/593/article/8/data.html"
    },
    {
      "locator": "Article8(2)",
      "quote_id": "ROME-041",
      "read_date": "2026-11-16",
      "source": "ROME",
      "url": "https://www.legislation.gov.uk/eur/2008/593/article/8/data.html"
    }
  ],
  "section": "Step 2: plan remote work before it starts",
  "source_keys": [
    "EU883",
    "ROME"
  ]
}
```

### 31

| Digital nomad / moving among states | Record physical presence and workdays separately, each employer, residence and changes in activity. Obtain the appropriate multistate determination rather than selecting a convenient system. [Regulation883/2004,31July2019consolidation](https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1) [Regulation987/2009,1January2018consolidation](https://publications.europa.eu/resource/cellar/00185d05-a69f-4055-8a8e-341c14c29d50.0020.02/DOC_1) |

```json
{
  "figures": [
    "83",
    "87"
  ],
  "id": 31,
  "kind": "source-cited rule and its explicit conditions",
  "line": 64,
  "operative_bindings": [
    {
      "locator": "Article13(1)/(2)",
      "quote_id": "EU883-017",
      "read_date": "2026-11-16",
      "source": "EU883",
      "url": "https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1"
    },
    {
      "locator": "Article11(1)",
      "quote_id": "EU883-013",
      "read_date": "2026-11-16",
      "source": "EU883",
      "url": "https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1"
    },
    {
      "locator": "Article16(1)",
      "quote_id": "EU987-026",
      "read_date": "2026-11-16",
      "source": "EU987",
      "url": "https://publications.europa.eu/resource/cellar/00185d05-a69f-4055-8a8e-341c14c29d50.0020.02/DOC_1"
    },
    {
      "locator": "Article14(2)",
      "quote_id": "EU987-022",
      "read_date": "2026-11-16",
      "source": "EU987",
      "url": "https://publications.europa.eu/resource/cellar/00185d05-a69f-4055-8a8e-341c14c29d50.0020.02/DOC_1"
    }
  ],
  "section": "Step 2: plan remote work before it starts",
  "source_keys": [
    "EU883",
    "EU987"
  ]
}
```

### 32

Before work begins, record the locations, dates and expected pattern; review PE, actual treaty, social-security coverage, immigration/work permission and host employment protections. During the arrangement, maintain travel/work records, pursue the competent institution's documents, reconcile payroll records and reassess changed facts. This is an internal control checklist, not a list of already verified national filing deadlines.

```json
{
  "figures": [],
  "id": 32,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 66,
  "operative_bindings": [],
  "section": "Step 2: plan remote work before it starts",
  "source_keys": []
}
```

### 33

An employer may impose approved/prohibited-country lists or a **30–90 day** internal limit. Neither that range nor any private approval policy is a statutory exemption from tax, social security, immigration or employment law. The original numerical policy range is retained only as an illustrative employer choice.

```json
{
  "figures": [
    "30",
    "90"
  ],
  "id": 33,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 68,
  "operative_bindings": [],
  "section": "Step 2: plan remote work before it starts",
  "source_keys": []
}
```

### 34

### Step 3: apply the actual employment treaty

```json
{
  "figures": [
    "3"
  ],
  "id": 34,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 70,
  "operative_bindings": [],
  "section": "Step 3: apply the actual employment treaty",
  "source_keys": []
}
```

### 35

Under OECD Model Article 15(1), subject to the special articles for directors, pensions and government service, remuneration for employment exercised in the other state may be taxed there. Article 15(2) retains exclusive residence-state taxation only if **all** of these hold: (a) physical presence does not exceed 183 days in the specified twelve-month period; (b) remuneration is paid by/on behalf of an employer not resident in the work state; and (c) it is not borne by the employer's PE there. The model has a distinct international ship/aircraft crew paragraph. Verify the actual instrument before applying any of these provisions. [OECD Model 2025, employment article and Commentary](https://www.oecd.org/content/dam/oecd/en/publications/reports/2026/06/model-tax-convention-on-income-and-on-capital-2025-full-version_4fd97b89/db32e18b-en.pdf)

```json
{
  "figures": [
    "15",
    "1",
    "15",
    "2",
    "183"
  ],
  "id": 35,
  "kind": "source-cited rule and its explicit conditions",
  "line": 72,
  "operative_bindings": [
    {
      "locator": "Article15(2)(a)",
      "quote_id": "MODEL-002",
      "read_date": "2026-11-16",
      "source": "MODEL",
      "url": "https://www.oecd.org/content/dam/oecd/en/publications/reports/2026/06/model-tax-convention-on-income-and-on-capital-2025-full-version_4fd97b89/db32e18b-en.pdf"
    },
    {
      "locator": "Article15(2)(c)",
      "quote_id": "MODEL-006",
      "read_date": "2026-11-16",
      "source": "MODEL",
      "url": "https://www.oecd.org/content/dam/oecd/en/publications/reports/2026/06/model-tax-convention-on-income-and-on-capital-2025-full-version_4fd97b89/db32e18b-en.pdf"
    }
  ],
  "section": "Step 3: apply the actual employment treaty",
  "source_keys": [
    "MODEL"
  ]
}
```

### 36

Failure of one limb removes this particular exemption for the remuneration within the actual work-state taxing rule, potentially from the first relevant workday. It does **not** itself create a domestic charge, a universal withholding deadline or tax all salary unrelated to that work. Older actual treaties may use a calendar/fiscal year instead of the model's rolling period. [OECD Model 2025, employment article and Commentary](https://www.oecd.org/content/dam/oecd/en/publications/reports/2026/06/model-tax-convention-on-income-and-on-capital-2025-full-version_4fd97b89/db32e18b-en.pdf)

```json
{
  "figures": [],
  "id": 36,
  "kind": "source-cited rule and its explicit conditions",
  "line": 74,
  "operative_bindings": [
    {
      "locator": "Article15(1)",
      "quote_id": "MODEL-001",
      "read_date": "2026-11-16",
      "source": "MODEL",
      "url": "https://www.oecd.org/content/dam/oecd/en/publications/reports/2026/06/model-tax-convention-on-income-and-on-capital-2025-full-version_4fd97b89/db32e18b-en.pdf"
    },
    {
      "locator": "Article15(2)(c)",
      "quote_id": "MODEL-006",
      "read_date": "2026-11-16",
      "source": "MODEL",
      "url": "https://www.oecd.org/content/dam/oecd/en/publications/reports/2026/06/model-tax-convention-on-income-and-on-capital-2025-full-version_4fd97b89/db32e18b-en.pdf"
    }
  ],
  "section": "Step 3: apply the actual employment treaty",
  "source_keys": [
    "MODEL"
  ]
}
```

### 37

The model Commentary uses physical presence, including parts of days, arrival/departure, weekends, holidays and generally sickness; it excludes transit between two outside points and addresses sickness that prevents leaving when the person otherwise qualified. Days wholly outside are not counted, and the residence-change qualification must be considered. Keep a separate service-day record for remuneration allocation. Do not interchange those two clocks. [OECD Model 2025, employment article and Commentary](https://www.oecd.org/content/dam/oecd/en/publications/reports/2026/06/model-tax-convention-on-income-and-on-capital-2025-full-version_4fd97b89/db32e18b-en.pdf)

```json
{
  "figures": [],
  "id": 37,
  "kind": "source-cited rule and its explicit conditions",
  "line": 76,
  "operative_bindings": [
    {
      "locator": "Commentary15paragraph5/5.1",
      "quote_id": "MODEL-003",
      "read_date": "2026-11-16",
      "source": "MODEL",
      "url": "https://www.oecd.org/content/dam/oecd/en/publications/reports/2026/06/model-tax-convention-on-income-and-on-capital-2025-full-version_4fd97b89/db32e18b-en.pdf"
    },
    {
      "locator": "Article15(1)",
      "quote_id": "MODEL-001",
      "read_date": "2026-11-16",
      "source": "MODEL",
      "url": "https://www.oecd.org/content/dam/oecd/en/publications/reports/2026/06/model-tax-convention-on-income-and-on-capital-2025-full-version_4fd97b89/db32e18b-en.pdf"
    }
  ],
  "section": "Step 3: apply the actual employment treaty",
  "source_keys": [
    "MODEL"
  ]
}
```

### 38

### Step 4: identify the substantive employer and collection procedure

```json
{
  "figures": [
    "4"
  ],
  "id": 38,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 78,
  "operative_bindings": [],
  "section": "Step 4: identify the substantive employer and collection procedure",
  "source_keys": []
}
```

### 39

The employment Commentary considers the domestic-law employment concept within treaty limits, the integral nature of services and who bears responsibility/risk. Relevant facts include authority over work, workplace control, tools, personnel selection, discipline and working arrangements. A state cannot arbitrarily deem every genuine inter-business service contract to be employment. Direct salary recharge is a relevant factor but **not necessarily conclusive**; a genuine service fee with salary as one of many cost inputs is not automatically a direct recharge. [OECD Model 2025, employment article and Commentary](https://www.oecd.org/content/dam/oecd/en/publications/reports/2026/06/model-tax-convention-on-income-and-on-capital-2025-full-version_4fd97b89/db32e18b-en.pdf)

```json
{
  "figures": [],
  "id": 39,
  "kind": "source-cited rule and its explicit conditions",
  "line": 80,
  "operative_bindings": [
    {
      "locator": "Commentary15paragraph8.15",
      "quote_id": "MODEL-004",
      "read_date": "2026-11-16",
      "source": "MODEL",
      "url": "https://www.oecd.org/content/dam/oecd/en/publications/reports/2026/06/model-tax-convention-on-income-and-on-capital-2025-full-version_4fd97b89/db32e18b-en.pdf"
    },
    {
      "locator": "Commentary15paragraph8.13",
      "quote_id": "MODEL-005",
      "read_date": "2026-11-16",
      "source": "MODEL",
      "url": "https://www.oecd.org/content/dam/oecd/en/publications/reports/2026/06/model-tax-convention-on-income-and-on-capital-2025-full-version_4fd97b89/db32e18b-en.pdf"
    }
  ],
  "section": "Step 4: identify the substantive employer and collection procedure",
  "source_keys": [
    "MODEL"
  ]
}
```

### 40

Do not equate a charge to a German **subsidiary** with remuneration borne by the foreign employer's **PE**. The actual economic-employer limb and the separate PE-cost limb must each be tested. The original Germany, Sweden, Denmark, Norway, Finland, UK, Australia, India and Singapore list is not verified as a uniform 2026 national adoption matrix; its unverified jurisdiction-specific positions are individually held in Sources. [OECD Model 2025, employment article and Commentary](https://www.oecd.org/content/dam/oecd/en/publications/reports/2026/06/model-tax-convention-on-income-and-on-capital-2025-full-version_4fd97b89/db32e18b-en.pdf) [UK–Germany treaty, consolidated after2021Protocol](https://www.gov.uk/government/publications/germany-tax-treaties/2010-uk-germany-double-taxation-convention-as-amended-by-the-2021-protocol-in-force)

```json
{
  "figures": [
    "2026"
  ],
  "id": 40,
  "kind": "source-cited rule and its explicit conditions",
  "line": 82,
  "operative_bindings": [
    {
      "locator": "Article15(2)(c)",
      "quote_id": "MODEL-006",
      "read_date": "2026-11-16",
      "source": "MODEL",
      "url": "https://www.oecd.org/content/dam/oecd/en/publications/reports/2026/06/model-tax-convention-on-income-and-on-capital-2025-full-version_4fd97b89/db32e18b-en.pdf"
    },
    {
      "locator": "Commentary15paragraph8.15",
      "quote_id": "MODEL-004",
      "read_date": "2026-11-16",
      "source": "MODEL",
      "url": "https://www.oecd.org/content/dam/oecd/en/publications/reports/2026/06/model-tax-convention-on-income-and-on-capital-2025-full-version_4fd97b89/db32e18b-en.pdf"
    },
    {
      "locator": "Article14(2)(c)",
      "quote_id": "UKDE-009",
      "read_date": "2026-11-16",
      "source": "UKDE",
      "url": "https://www.gov.uk/government/publications/germany-tax-treaties/2010-uk-germany-double-taxation-convention-as-amended-by-the-2021-protocol-in-force"
    },
    {
      "locator": "Article14(1)",
      "quote_id": "UKDE-007",
      "read_date": "2026-11-16",
      "source": "UKDE",
      "url": "https://www.gov.uk/government/publications/germany-tax-treaties/2010-uk-germany-double-taxation-convention-as-amended-by-the-2021-protocol-in-force"
    }
  ],
  "section": "Step 4: identify the substantive employer and collection procedure",
  "source_keys": [
    "MODEL",
    "UKDE"
  ]
}
```

### 41

| Original travel band | What the band can establish |

```json
{
  "figures": [],
  "id": 41,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 84,
  "operative_bindings": [],
  "section": "Step 4: identify the substantive employer and collection procedure",
  "source_keys": []
}
```

### 42

| 1–30 days/year | A tracking band only; no general exemption. |

```json
{
  "figures": [
    "1",
    "30"
  ],
  "id": 42,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 86,
  "operative_bindings": [],
  "section": "Step 4: identify the substantive employer and collection procedure",
  "source_keys": []
}
```

### 43

| 31–60 days/year | A tracking band only; identify any actual de minimis/collection arrangement separately. |

```json
{
  "figures": [
    "31",
    "60"
  ],
  "id": 43,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 87,
  "operative_bindings": [],
  "section": "Step 4: identify the substantive employer and collection procedure",
  "source_keys": []
}
```

### 44

| 61–90 days/year | A tracking band only; duration does not itself require or excuse shadow payroll. |

```json
{
  "figures": [
    "61",
    "90"
  ],
  "id": 44,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 88,
  "operative_bindings": [],
  "section": "Step 4: identify the substantive employer and collection procedure",
  "source_keys": []
}
```

### 45

| 91–183 days/year | Still requires every actual treaty condition; exactly 183 is not the same as exceeding 183. |

```json
{
  "figures": [
    "91",
    "183",
    "183",
    "183"
  ],
  "id": 45,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 89,
  "operative_bindings": [],
  "section": "Step 4: identify the substantive employer and collection procedure",
  "source_keys": []
}
```

### 46

| More than 183 days/year | Test the treaty's actual measuring period, not merely a calendar-year total. Where the relevant limit is exceeded, this short-stay exemption is unavailable. [OECD Model 2025, employment article and Commentary](https://www.oecd.org/content/dam/oecd/en/publications/reports/2026/06/model-tax-convention-on-income-and-on-capital-2025-full-version_4fd97b89/db32e18b-en.pdf) |

```json
{
  "figures": [
    "183"
  ],
  "id": 46,
  "kind": "source-cited rule and its explicit conditions",
  "line": 90,
  "operative_bindings": [
    {
      "locator": "Article15(2)(a)",
      "quote_id": "MODEL-002",
      "read_date": "2026-11-16",
      "source": "MODEL",
      "url": "https://www.oecd.org/content/dam/oecd/en/publications/reports/2026/06/model-tax-convention-on-income-and-on-capital-2025-full-version_4fd97b89/db32e18b-en.pdf"
    },
    {
      "locator": "Article15(1)",
      "quote_id": "MODEL-001",
      "read_date": "2026-11-16",
      "source": "MODEL",
      "url": "https://www.oecd.org/content/dam/oecd/en/publications/reports/2026/06/model-tax-convention-on-income-and-on-capital-2025-full-version_4fd97b89/db32e18b-en.pdf"
    }
  ],
  "section": "Step 4: identify the substantive employer and collection procedure",
  "source_keys": [
    "MODEL"
  ]
}
```

### 47

UK Appendix 4 short-term business visitor arrangements illustrate why treaty exemption and PAYE administration differ: there must be an actual HMRC arrangement and its detailed residence, employer, cost-bearing, duration and reporting conditions. The manual includes specific short-visit branches, not a general worldwide safe harbour. No current registration or filing approval for the reader's employer is supplied. [HMRC PAYE82000, short-term visitors](https://www.gov.uk/hmrc-internal-manuals/paye-manual/paye82000)

```json
{
  "figures": [
    "4"
  ],
  "id": 47,
  "kind": "source-cited rule and its explicit conditions",
  "line": 92,
  "operative_bindings": [
    {
      "locator": "PAYE82000openingandconditions68–89",
      "quote_id": "UKPAYE-042",
      "read_date": "2026-11-16",
      "source": "UKPAYE",
      "url": "https://www.gov.uk/hmrc-internal-manuals/paye-manual/paye82000"
    }
  ],
  "section": "Step 4: identify the substantive employer and collection procedure",
  "source_keys": [
    "UKPAYE"
  ]
}
```

### 48

### Step 5: coordinate home, shadow and hypothetical payroll

```json
{
  "figures": [
    "5"
  ],
  "id": 48,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 94,
  "operative_bindings": [],
  "section": "Step 5: coordinate home, shadow and hypothetical payroll",
  "source_keys": []
}
```

### 49

“Shadow payroll” here means the host calculation/reporting record used where required while cash continues through home payroll. It is not a second salary payment or an independent tax exemption. Reconcile taxable compensation/benefits, lawful currency conversion, actual remittances, home withholding relief, social coverage and annual statements. The legal payer, collection mechanism and reporting obligations must be confirmed locally.

```json
{
  "figures": [],
  "id": 49,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 96,
  "operative_bindings": [],
  "section": "Step 5: coordinate home, shadow and hypothetical payroll",
  "source_keys": []
}
```

### 50

| Home/host item | Treatment to establish |

```json
{
  "figures": [],
  "id": 50,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 98,
  "operative_bindings": [],
  "section": "Step 5: coordinate home, shadow and hypothetical payroll",
  "source_keys": []
}
```

### 51

| Salary cash | Identify which payroll pays; avoid paying twice merely because there are two records. |

```json
{
  "figures": [],
  "id": 51,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 100,
  "operative_bindings": [],
  "section": "Step 5: coordinate home, shadow and hypothetical payroll",
  "source_keys": []
}
```

### 52

| Income tax | Establish both countries' collection rules and actual treaty/credit/exemption relief; a shadow record alone does not remit tax. [UK–Germany treaty, consolidated after2021Protocol](https://www.gov.uk/government/publications/germany-tax-treaties/2010-uk-germany-double-taxation-convention-as-amended-by-the-2021-protocol-in-force) [HMRC PAYE82000, short-term visitors](https://www.gov.uk/hmrc-internal-manuals/paye-manual/paye82000) |

```json
{
  "figures": [],
  "id": 52,
  "kind": "source-cited rule and its explicit conditions",
  "line": 101,
  "operative_bindings": [
    {
      "locator": "Article23(2)(a)",
      "quote_id": "UKDE-012",
      "read_date": "2026-11-16",
      "source": "UKDE",
      "url": "https://www.gov.uk/government/publications/germany-tax-treaties/2010-uk-germany-double-taxation-convention-as-amended-by-the-2021-protocol-in-force"
    },
    {
      "locator": "Article14(2)(a)",
      "quote_id": "UKDE-008",
      "read_date": "2026-11-16",
      "source": "UKDE",
      "url": "https://www.gov.uk/government/publications/germany-tax-treaties/2010-uk-germany-double-taxation-convention-as-amended-by-the-2021-protocol-in-force"
    },
    {
      "locator": "PAYE82000openingandconditions68–89",
      "quote_id": "UKPAYE-042",
      "read_date": "2026-11-16",
      "source": "UKPAYE",
      "url": "https://www.gov.uk/hmrc-internal-manuals/paye-manual/paye82000"
    }
  ],
  "section": "Step 5: coordinate home, shadow and hypothetical payroll",
  "source_keys": [
    "UKDE",
    "UKPAYE"
  ]
}
```

### 53

| Social security | Follow the applicable system and coverage document; neither tax equalisation nor shadow payroll selects the system. [Regulation883/2004,31July2019consolidation](https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1) [US–Portugal SocialSecurityAgreement](https://www.ssa.gov/international/Agreement_Texts/portugal.html) |

```json
{
  "figures": [
    "83"
  ],
  "id": 53,
  "kind": "source-cited rule and its explicit conditions",
  "line": 102,
  "operative_bindings": [
    {
      "locator": "Article11(1)",
      "quote_id": "EU883-013",
      "read_date": "2026-11-16",
      "source": "EU883",
      "url": "https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1"
    },
    {
      "locator": "Article16(1)",
      "quote_id": "EU883-019",
      "read_date": "2026-11-16",
      "source": "EU883",
      "url": "https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1"
    },
    {
      "locator": "Article5(1)",
      "quote_id": "USPT-048",
      "read_date": "2026-11-16",
      "source": "USPT",
      "url": "https://www.ssa.gov/international/Agreement_Texts/portugal.html"
    },
    {
      "locator": "Article5(2)",
      "quote_id": "USPT-049",
      "read_date": "2026-11-16",
      "source": "USPT",
      "url": "https://www.ssa.gov/international/Agreement_Texts/portugal.html"
    }
  ],
  "section": "Step 5: coordinate home, shadow and hypothetical payroll",
  "source_keys": [
    "EU883",
    "USPT"
  ]
}
```

### 54

| Reporting | Identify employer payroll filings and employee returns separately. This Guide does not confirm every national form, return box or due date. |

```json
{
  "figures": [],
  "id": 54,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 103,
  "operative_bindings": [],
  "section": "Step 5: coordinate home, shadow and hypothetical payroll",
  "source_keys": []
}
```

### 55

Retain the original triggers as **review prompts**, not automatic conclusions: a worker paid from the UK but working **200 days in Germany**; a US parent's cost recharge to its German subsidiary; an asserted Swedish economic employer; and a worker moving to Portugal without an employer entity. Determine actual treaty period, substantive employer, domestic collection and social scope for each. Cost recharge to a subsidiary alone does not prove the PE limb fails. [OECD Model 2025, employment article and Commentary](https://www.oecd.org/content/dam/oecd/en/publications/reports/2026/06/model-tax-convention-on-income-and-on-capital-2025-full-version_4fd97b89/db32e18b-en.pdf) [UK–Germany treaty, consolidated after2021Protocol](https://www.gov.uk/government/publications/germany-tax-treaties/2010-uk-germany-double-taxation-convention-as-amended-by-the-2021-protocol-in-force) [US–Portugal SocialSecurityAgreement](https://www.ssa.gov/international/Agreement_Texts/portugal.html)

```json
{
  "figures": [
    "200"
  ],
  "id": 55,
  "kind": "source-cited rule and its explicit conditions",
  "line": 105,
  "operative_bindings": [
    {
      "locator": "Commentary15paragraph8.15",
      "quote_id": "MODEL-004",
      "read_date": "2026-11-16",
      "source": "MODEL",
      "url": "https://www.oecd.org/content/dam/oecd/en/publications/reports/2026/06/model-tax-convention-on-income-and-on-capital-2025-full-version_4fd97b89/db32e18b-en.pdf"
    },
    {
      "locator": "Article15(2)(a)",
      "quote_id": "MODEL-002",
      "read_date": "2026-11-16",
      "source": "MODEL",
      "url": "https://www.oecd.org/content/dam/oecd/en/publications/reports/2026/06/model-tax-convention-on-income-and-on-capital-2025-full-version_4fd97b89/db32e18b-en.pdf"
    },
    {
      "locator": "Article14(2)(c)",
      "quote_id": "UKDE-009",
      "read_date": "2026-11-16",
      "source": "UKDE",
      "url": "https://www.gov.uk/government/publications/germany-tax-treaties/2010-uk-germany-double-taxation-convention-as-amended-by-the-2021-protocol-in-force"
    },
    {
      "locator": "Article14(2)(a)",
      "quote_id": "UKDE-008",
      "read_date": "2026-11-16",
      "source": "UKDE",
      "url": "https://www.gov.uk/government/publications/germany-tax-treaties/2010-uk-germany-double-taxation-convention-as-amended-by-the-2021-protocol-in-force"
    },
    {
      "locator": "Effectivedate",
      "quote_id": "USPT-050",
      "read_date": "2026-11-16",
      "source": "USPT",
      "url": "https://www.ssa.gov/international/Agreement_Texts/portugal.html"
    },
    {
      "locator": "Article4(1)",
      "quote_id": "USPT-051",
      "read_date": "2026-11-16",
      "source": "USPT",
      "url": "https://www.ssa.gov/international/Agreement_Texts/portugal.html"
    }
  ],
  "section": "Step 5: coordinate home, shadow and hypothetical payroll",
  "source_keys": [
    "MODEL",
    "UKDE",
    "USPT"
  ]
}
```

### 56

Tax equalisation is a contractual allocation of tax cost, not treaty relief. HMRC's 2026 helpsheet describes specified net cash/non-cash earnings with the employer meeting UK income tax and providing tax support. A **hypothetical tax** deduction is an agreed home-tax comparator, not a payment discharging actual tax; **tax protection** describes an agreement reimbursing specified excess host costs. The policy must define scope, refunds, benefits, spouse/investment income and true-ups rather than assuming identical outcomes. In the read UK NIC guidance, employer-paid income tax is included in gross pay for Class 1 purposes, so gross-up consequences need attention. [HMRC2026 helpsheetHS212](https://www.gov.uk/government/publications/tax-equalisation-hs212-self-assessment-helpsheet/tax-equalisation-2026-hs212) [HMRC NIM02380](https://www.gov.uk/hmrc-internal-manuals/national-insurance-manual/nim02380)

```json
{
  "figures": [
    "2026",
    "1"
  ],
  "id": 56,
  "kind": "source-cited rule and its explicit conditions",
  "line": 107,
  "operative_bindings": [
    {
      "locator": "HS212section1definition",
      "quote_id": "TAXEQ-044",
      "read_date": "2026-11-16",
      "source": "TAXEQ",
      "url": "https://www.gov.uk/government/publications/tax-equalisation-hs212-self-assessment-helpsheet/tax-equalisation-2026-hs212"
    },
    {
      "locator": "HS212section1definition",
      "quote_id": "TAXEQ-043",
      "read_date": "2026-11-16",
      "source": "TAXEQ",
      "url": "https://www.gov.uk/government/publications/tax-equalisation-hs212-self-assessment-helpsheet/tax-equalisation-2026-hs212"
    },
    {
      "locator": "NIM02380thirdparagraph",
      "quote_id": "TAXEQNIC-045",
      "read_date": "2026-11-16",
      "source": "TAXEQNIC",
      "url": "https://www.gov.uk/hmrc-internal-manuals/national-insurance-manual/nim02380"
    }
  ],
  "section": "Step 5: coordinate home, shadow and hypothetical payroll",
  "source_keys": [
    "TAXEQ",
    "TAXEQNIC"
  ]
}
```

### 57

### Step 6: establish EU social-security coverage and evidence

```json
{
  "figures": [
    "6"
  ],
  "id": 57,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 109,
  "operative_bindings": [],
  "section": "Step 6: establish EU social-security coverage and evidence",
  "source_keys": []
}
```

### 58

First establish the personal/material and territorial scope: Regulation 883/2004 covers the defined persons and listed social-security branches, with separate extension instruments/agreements for other nationality or EEA/Swiss/UK situations. Do not presume every person in Europe qualifies. Within scope, Article 11's starting point is one applicable system and, for ordinary employment/self-employment, the work state's legislation, subject to the relevant exceptions. [Regulation883/2004,31July2019consolidation](https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1)

```json
{
  "figures": [
    "883",
    "2004",
    "11",
    "83"
  ],
  "id": 58,
  "kind": "source-cited rule and its explicit conditions",
  "line": 111,
  "operative_bindings": [
    {
      "locator": "Article11(1)",
      "quote_id": "EU883-013",
      "read_date": "2026-11-16",
      "source": "EU883",
      "url": "https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1"
    },
    {
      "locator": "Article2",
      "quote_id": "EU883-020",
      "read_date": "2026-11-16",
      "source": "EU883",
      "url": "https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1"
    }
  ],
  "section": "Step 6: establish EU social-security coverage and evidence",
  "source_keys": [
    "EU883"
  ]
}
```

### 59

| Situation | Current rule and material conditions |

```json
{
  "figures": [],
  "id": 59,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 113,
  "operative_bindings": [],
  "section": "Step 6: establish EU social-security coverage and evidence",
  "source_keys": []
}
```

### 60

| Employee posted temporarily | Article 12(1): employer normally carries out activities in the sending state; worker is posted on that employer's behalf; anticipated work does not exceed **24 months** and the person is not sent to replace another posted person. Implementing Article 14 requires meaningful activities beyond internal management and addresses prior coverage for a recruited worker. [Regulation883/2004,31July2019consolidation](https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1) [Regulation987/2009,1January2018consolidation](https://publications.europa.eu/resource/cellar/00185d05-a69f-4055-8a8e-341c14c29d50.0020.02/DOC_1) |

```json
{
  "figures": [
    "12",
    "1",
    "24",
    "14",
    "83",
    "87"
  ],
  "id": 60,
  "kind": "source-cited rule and its explicit conditions",
  "line": 115,
  "operative_bindings": [
    {
      "locator": "Article12(1)/(2)",
      "quote_id": "EU883-014",
      "read_date": "2026-11-16",
      "source": "EU883",
      "url": "https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1"
    },
    {
      "locator": "Article12(1)",
      "quote_id": "EU883-015",
      "read_date": "2026-11-16",
      "source": "EU883",
      "url": "https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1"
    },
    {
      "locator": "Article14(2)",
      "quote_id": "EU987-022",
      "read_date": "2026-11-16",
      "source": "EU987",
      "url": "https://publications.europa.eu/resource/cellar/00185d05-a69f-4055-8a8e-341c14c29d50.0020.02/DOC_1"
    },
    {
      "locator": "Article14(10)",
      "quote_id": "EU987-024",
      "read_date": "2026-11-16",
      "source": "EU987",
      "url": "https://publications.europa.eu/resource/cellar/00185d05-a69f-4055-8a8e-341c14c29d50.0020.02/DOC_1"
    }
  ],
  "section": "Step 6: establish EU social-security coverage and evidence",
  "source_keys": [
    "EU883",
    "EU987"
  ]
}
```

### 61

| Self-employed temporary work | Article 12(2): person normally self-employed in the sending state performs **similar** activity abroad, anticipated not more than **24 months**. Prior substantial activity, ability to resume and actual nature matter; registration alone is not enough. [Regulation883/2004,31July2019consolidation](https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1) [Regulation987/2009,1January2018consolidation](https://publications.europa.eu/resource/cellar/00185d05-a69f-4055-8a8e-341c14c29d50.0020.02/DOC_1) |

```json
{
  "figures": [
    "12",
    "2",
    "24",
    "83",
    "87"
  ],
  "id": 61,
  "kind": "source-cited rule and its explicit conditions",
  "line": 116,
  "operative_bindings": [
    {
      "locator": "Article12(2)",
      "quote_id": "EU883-016",
      "read_date": "2026-11-16",
      "source": "EU883",
      "url": "https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1"
    },
    {
      "locator": "Article12(1)/(2)",
      "quote_id": "EU883-014",
      "read_date": "2026-11-16",
      "source": "EU883",
      "url": "https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1"
    },
    {
      "locator": "Article14(10)",
      "quote_id": "EU987-024",
      "read_date": "2026-11-16",
      "source": "EU987",
      "url": "https://publications.europa.eu/resource/cellar/00185d05-a69f-4055-8a8e-341c14c29d50.0020.02/DOC_1"
    },
    {
      "locator": "Article14(8)",
      "quote_id": "EU987-023",
      "read_date": "2026-11-16",
      "source": "EU987",
      "url": "https://publications.europa.eu/resource/cellar/00185d05-a69f-4055-8a8e-341c14c29d50.0020.02/DOC_1"
    }
  ],
  "section": "Step 6: establish EU social-security coverage and evidence",
  "source_keys": [
    "EU883",
    "EU987"
  ]
}
```

### 62

| Employment normally in two or more states | Article 13(1): residence state if a substantial part is performed there; otherwise apply the complete employer branches. A single employer, or multiple employers all established in one state, points to that state. Two employer states including residence point to the other state. Multiple employers in at least two different states outside residence point to residence. Do not compress these into “otherwise employer country.” [Regulation883/2004,31July2019consolidation](https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1) |

```json
{
  "figures": [
    "13",
    "1",
    "83"
  ],
  "id": 62,
  "kind": "source-cited rule and its explicit conditions",
  "line": 117,
  "operative_bindings": [
    {
      "locator": "Article13(1)(b)",
      "quote_id": "EU883-018",
      "read_date": "2026-11-16",
      "source": "EU883",
      "url": "https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1"
    },
    {
      "locator": "Article11(1)",
      "quote_id": "EU883-013",
      "read_date": "2026-11-16",
      "source": "EU883",
      "url": "https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1"
    }
  ],
  "section": "Step 6: establish EU social-security coverage and evidence",
  "source_keys": [
    "EU883"
  ]
}
```

### 63

| Self-employment in multiple states / mixed employed and self-employed | Residence if substantial self-employed activity there, otherwise centre of interest. The mixed case follows the employed activity's state or its multistate determination. Article 14 sets the relevant factual criteria and excludes marginal activities. [Regulation883/2004,31July2019consolidation](https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1) [Regulation987/2009,1January2018consolidation](https://publications.europa.eu/resource/cellar/00185d05-a69f-4055-8a8e-341c14c29d50.0020.02/DOC_1) |

```json
{
  "figures": [
    "14",
    "83",
    "87"
  ],
  "id": 63,
  "kind": "source-cited rule and its explicit conditions",
  "line": 118,
  "operative_bindings": [
    {
      "locator": "Article13(1)/(2)",
      "quote_id": "EU883-017",
      "read_date": "2026-11-16",
      "source": "EU883",
      "url": "https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1"
    },
    {
      "locator": "Article12(2)",
      "quote_id": "EU883-016",
      "read_date": "2026-11-16",
      "source": "EU883",
      "url": "https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1"
    },
    {
      "locator": "Article16(1)",
      "quote_id": "EU987-026",
      "read_date": "2026-11-16",
      "source": "EU987",
      "url": "https://publications.europa.eu/resource/cellar/00185d05-a69f-4055-8a8e-341c14c29d50.0020.02/DOC_1"
    },
    {
      "locator": "Article14(2)",
      "quote_id": "EU987-022",
      "read_date": "2026-11-16",
      "source": "EU987",
      "url": "https://publications.europa.eu/resource/cellar/00185d05-a69f-4055-8a8e-341c14c29d50.0020.02/DOC_1"
    }
  ],
  "section": "Step 6: establish EU social-security coverage and evidence",
  "source_keys": [
    "EU883",
    "EU987"
  ]
}
```

### 64

| Substantial-activity assessment | Working time and/or remuneration for employment; turnover, time, services and/or income for self-employment. **Less than 25%** is an indicator within the overall assessment, using the situation projected over the next **12 calendar months**. Special foreign-employer and other Article 13/14 branches still require checking. [Regulation987/2009,1January2018consolidation](https://publications.europa.eu/resource/cellar/00185d05-a69f-4055-8a8e-341c14c29d50.0020.02/DOC_1) |

```json
{
  "figures": [
    "25%",
    "12",
    "13",
    "14",
    "87"
  ],
  "id": 64,
  "kind": "source-cited rule and its explicit conditions",
  "line": 119,
  "operative_bindings": [
    {
      "locator": "Article14(8)",
      "quote_id": "EU987-023",
      "read_date": "2026-11-16",
      "source": "EU987",
      "url": "https://publications.europa.eu/resource/cellar/00185d05-a69f-4055-8a8e-341c14c29d50.0020.02/DOC_1"
    },
    {
      "locator": "Article14(10)",
      "quote_id": "EU987-024",
      "read_date": "2026-11-16",
      "source": "EU987",
      "url": "https://publications.europa.eu/resource/cellar/00185d05-a69f-4055-8a8e-341c14c29d50.0020.02/DOC_1"
    }
  ],
  "section": "Step 6: establish EU social-security coverage and evidence",
  "source_keys": [
    "EU987"
  ]
}
```

### 65

| Exceptional continuation | Article 16 permits competent authorities to agree exceptions in the interests of certain persons/categories. There is no automatic renewal beyond Article 12's period. [Regulation883/2004,31July2019consolidation](https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1) |

```json
{
  "figures": [
    "16",
    "12",
    "83"
  ],
  "id": 65,
  "kind": "source-cited rule and its explicit conditions",
  "line": 120,
  "operative_bindings": [
    {
      "locator": "Article16(1)",
      "quote_id": "EU883-019",
      "read_date": "2026-11-16",
      "source": "EU883",
      "url": "https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1"
    },
    {
      "locator": "Article11(1)",
      "quote_id": "EU883-013",
      "read_date": "2026-11-16",
      "source": "EU883",
      "url": "https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1"
    }
  ],
  "section": "Step 6: establish EU social-security coverage and evidence",
  "source_keys": [
    "EU883"
  ]
}
```

### 66

For multistate work, notify the designated **residence-state** institution under implementing Article 16; it determines the applicable legislation provisionally and coordinates with the other institutions. It is wrong to tell every applicant to use the home/employer institution regardless of the relevant procedure. For current posting notifications, Article 15 calls for information whenever possible in advance. [Regulation987/2009,1January2018consolidation](https://publications.europa.eu/resource/cellar/00185d05-a69f-4055-8a8e-341c14c29d50.0020.02/DOC_1)

```json
{
  "figures": [
    "16",
    "15",
    "87"
  ],
  "id": 66,
  "kind": "source-cited rule and its explicit conditions",
  "line": 122,
  "operative_bindings": [
    {
      "locator": "Article16(1)",
      "quote_id": "EU987-026",
      "read_date": "2026-11-16",
      "source": "EU987",
      "url": "https://publications.europa.eu/resource/cellar/00185d05-a69f-4055-8a8e-341c14c29d50.0020.02/DOC_1"
    },
    {
      "locator": "Article15(1)",
      "quote_id": "EU987-025",
      "read_date": "2026-11-16",
      "source": "EU987",
      "url": "https://publications.europa.eu/resource/cellar/00185d05-a69f-4055-8a8e-341c14c29d50.0020.02/DOC_1"
    }
  ],
  "section": "Step 6: establish EU social-security coverage and evidence",
  "source_keys": [
    "EU987"
  ]
}
```

### 67

An A1 attests which legislation applies; it does not create a right to choose it. From **1 November 2026**, amended Article 19(2)/(3) requires an attestation on request by the person or employer, in a **standardised format**, stating relevant date/conditions, and a proper assessment of the facts with confirmation that its information is correct. Article 5 provides that another state's institutions accept an issued document until the issuing state withdraws or invalidates it, with a clarification/withdrawal procedure. Missing paperwork must be resolved, but it does **not automatically change the applicable law**; the 2026 amendment's new recital expressly recognizes that principle. Do not state that a missing A1 alone proves host contributions are due. [Regulation987/2009,1January2018consolidation](https://publications.europa.eu/resource/cellar/00185d05-a69f-4055-8a8e-341c14c29d50.0020.02/DOC_1) [Regulation(EU)2026/2359, enacted English body](https://publications.europa.eu/resource/cellar/5794f71b-d1a7-11f1-9458-01aa75ed71a1.0006.03/DOC_1)

```json
{
  "figures": [
    "1",
    "2026",
    "19",
    "2",
    "3",
    "5",
    "2026",
    "87",
    "026"
  ],
  "id": 67,
  "kind": "source-cited rule and its explicit conditions",
  "line": 124,
  "operative_bindings": [
    {
      "locator": "Article5(1)",
      "quote_id": "EU987-021",
      "read_date": "2026-11-16",
      "source": "EU987",
      "url": "https://publications.europa.eu/resource/cellar/00185d05-a69f-4055-8a8e-341c14c29d50.0020.02/DOC_1"
    },
    {
      "locator": "Article14(2)",
      "quote_id": "EU987-022",
      "read_date": "2026-11-16",
      "source": "EU987",
      "url": "https://publications.europa.eu/resource/cellar/00185d05-a69f-4055-8a8e-341c14c29d50.0020.02/DOC_1"
    },
    {
      "locator": "Article1(8),newrecital40b",
      "quote_id": "EU2026-033",
      "read_date": "2026-11-16",
      "source": "EU2026",
      "url": "https://publications.europa.eu/resource/cellar/5794f71b-d1a7-11f1-9458-01aa75ed71a1.0006.03/DOC_1"
    },
    {
      "locator": "Article2(13)(b),new19(3)",
      "quote_id": "EU2026-031",
      "read_date": "2026-11-16",
      "source": "EU2026",
      "url": "https://publications.europa.eu/resource/cellar/5794f71b-d1a7-11f1-9458-01aa75ed71a1.0006.03/DOC_1"
    }
  ],
  "section": "Step 6: establish EU social-security coverage and evidence",
  "source_keys": [
    "EU987",
    "EU2026"
  ]
}
```

### 68

### Step 7: use the telework Framework only within its scope

```json
{
  "figures": [
    "7"
  ],
  "id": 68,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 126,
  "operative_bindings": [],
  "section": "Step 7: use the telework Framework only within its scope",
  "source_keys": []
}
```

### 69

The 2023 Framework applies where residence and the employer's registered office/place of business are in two **signatory** states and, without the exception, habitual cross-border telework would produce residence-state coverage. The worker must be employed, with one or more employers all in the same other state; no habitual non-telework activity in residence and no habitual activity in a third state. Self-employed people are excluded. It is **upon request**, not an automatic “25–49.99%” rule. Verify that the actual pair and date are covered by the depositary's current signatory record. [2023Framework Agreement on cross-border telework](https://socialsecurity.belgium.be/sites/default/files/content/docs/en/international/framework_agreement_on_cross-border_telework.pdf)

```json
{
  "figures": [
    "2023",
    "25",
    "49.99%"
  ],
  "id": 69,
  "kind": "source-cited rule and its explicit conditions",
  "line": 128,
  "operative_bindings": [
    {
      "locator": "Article2(1)",
      "quote_id": "FRAME-039",
      "read_date": "2026-11-16",
      "source": "FRAME",
      "url": "https://socialsecurity.belgium.be/sites/default/files/content/docs/en/international/framework_agreement_on_cross-border_telework.pdf"
    },
    {
      "locator": "Article3(1)",
      "quote_id": "FRAME-035",
      "read_date": "2026-11-16",
      "source": "FRAME",
      "url": "https://socialsecurity.belgium.be/sites/default/files/content/docs/en/international/framework_agreement_on_cross-border_telework.pdf"
    }
  ],
  "section": "Step 7: use the telework Framework only within its scope",
  "source_keys": [
    "FRAME"
  ]
}
```

### 70

Residence-state telework must be **less than 50%** of total working time. Each agreement can cover at most **3 years**, with a new request for extension. Current retrospective requests are limited to **3 months**, subject to contributions paid/coverage in the requested employer state. The old **12-month** retrospective window applied only to requests submitted by **30 June 2024**; it is not a current option. An individual Article 16 exception may still be requested outside the Framework, without guaranteed agreement. The A1 procedure remains relevant. [2023Framework Agreement on cross-border telework](https://socialsecurity.belgium.be/sites/default/files/content/docs/en/international/framework_agreement_on_cross-border_telework.pdf)

```json
{
  "figures": [
    "50%",
    "3",
    "3",
    "12",
    "30",
    "2024",
    "16"
  ],
  "id": 70,
  "kind": "source-cited rule and its explicit conditions",
  "line": 130,
  "operative_bindings": [
    {
      "locator": "Article4(2)(b)(ii)",
      "quote_id": "FRAME-037",
      "read_date": "2026-11-16",
      "source": "FRAME",
      "url": "https://socialsecurity.belgium.be/sites/default/files/content/docs/en/international/framework_agreement_on_cross-border_telework.pdf"
    },
    {
      "locator": "Article4(3)",
      "quote_id": "FRAME-038",
      "read_date": "2026-11-16",
      "source": "FRAME",
      "url": "https://socialsecurity.belgium.be/sites/default/files/content/docs/en/international/framework_agreement_on_cross-border_telework.pdf"
    }
  ],
  "section": "Step 7: use the telework Framework only within its scope",
  "source_keys": [
    "FRAME"
  ]
}
```

### 71

### Step 8: distinguish enacted 2026 changes from future provisions

```json
{
  "figures": [
    "8",
    "2026"
  ],
  "id": 71,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 132,
  "operative_bindings": [],
  "section": "Step 8: distinguish enacted 2026 changes from future provisions",
  "source_keys": []
}
```

### 72

Regulation (EU) **2026/2359** was adopted on **7 October 2026**, published on **27 October**, and entered into force on **1 November 2026**. It supersedes the original description of an April provisional agreement. The actual operative application clauses, rather than a press-summary shorthand, control. [Regulation(EU)2026/2359, enacted English body](https://publications.europa.eu/resource/cellar/5794f71b-d1a7-11f1-9458-01aa75ed71a1.0006.03/DOC_1)

```json
{
  "figures": [
    "2026",
    "2359",
    "7",
    "2026",
    "27",
    "1",
    "2026",
    "026"
  ],
  "id": 72,
  "kind": "source-cited rule and its explicit conditions",
  "line": 134,
  "operative_bindings": [
    {
      "locator": "Article1(39)/Article2(52),immediatelist",
      "quote_id": "EU2026-029",
      "read_date": "2026-11-16",
      "source": "EU2026",
      "url": "https://publications.europa.eu/resource/cellar/5794f71b-d1a7-11f1-9458-01aa75ed71a1.0006.03/DOC_1"
    },
    {
      "locator": "Article2(13)(b),new19(3)",
      "quote_id": "EU2026-031",
      "read_date": "2026-11-16",
      "source": "EU2026",
      "url": "https://publications.europa.eu/resource/cellar/5794f71b-d1a7-11f1-9458-01aa75ed71a1.0006.03/DOC_1"
    }
  ],
  "section": "Step 8: distinguish enacted 2026 changes from future provisions",
  "source_keys": [
    "EU2026"
  ]
}
```

### 73

| Application date | Bounded payroll consequence |

```json
{
  "figures": [],
  "id": 73,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 136,
  "operative_bindings": [],
  "section": "Step 8: distinguish enacted 2026 changes from future provisions",
  "source_keys": []
}
```

### 74

| **1 November 2026** | Listed provisions apply, including the standardized attestation and proper facts assessment in implementing Article 19(2)/(3). Do not describe all Title II amendments as already applicable. [Regulation(EU)2026/2359, enacted English body](https://publications.europa.eu/resource/cellar/5794f71b-d1a7-11f1-9458-01aa75ed71a1.0006.03/DOC_1) |

```json
{
  "figures": [
    "1",
    "2026",
    "19",
    "2",
    "3",
    "026"
  ],
  "id": 74,
  "kind": "source-cited rule and its explicit conditions",
  "line": 138,
  "operative_bindings": [
    {
      "locator": "Article2(13)(b),new19(3)",
      "quote_id": "EU2026-031",
      "read_date": "2026-11-16",
      "source": "EU2026",
      "url": "https://publications.europa.eu/resource/cellar/5794f71b-d1a7-11f1-9458-01aa75ed71a1.0006.03/DOC_1"
    },
    {
      "locator": "Article1(39)/Article2(52),immediatelist",
      "quote_id": "EU2026-029",
      "read_date": "2026-11-16",
      "source": "EU2026",
      "url": "https://publications.europa.eu/resource/cellar/5794f71b-d1a7-11f1-9458-01aa75ed71a1.0006.03/DOC_1"
    }
  ],
  "section": "Step 8: distinguish enacted 2026 changes from future provisions",
  "source_keys": [
    "EU2026"
  ]
}
```

### 75

| **2 November 2028** | The listed revised posting Article 12 and implementing provisions, including the revised prior-notification/business-trip exception, apply from this date. They are not current 2026 exemptions from A1/notification. [Regulation(EU)2026/2359, enacted English body](https://publications.europa.eu/resource/cellar/5794f71b-d1a7-11f1-9458-01aa75ed71a1.0006.03/DOC_1) |

```json
{
  "figures": [
    "2",
    "2028",
    "12",
    "2026",
    "026"
  ],
  "id": 75,
  "kind": "source-cited rule and its explicit conditions",
  "line": 139,
  "operative_bindings": [
    {
      "locator": "Article1(39)/Article2(52),applicationlists",
      "quote_id": "EU2026-028",
      "read_date": "2026-11-16",
      "source": "EU2026",
      "url": "https://publications.europa.eu/resource/cellar/5794f71b-d1a7-11f1-9458-01aa75ed71a1.0006.03/DOC_1"
    },
    {
      "locator": "Article1(39)/Article2(52),immediatelist",
      "quote_id": "EU2026-029",
      "read_date": "2026-11-16",
      "source": "EU2026",
      "url": "https://publications.europa.eu/resource/cellar/5794f71b-d1a7-11f1-9458-01aa75ed71a1.0006.03/DOC_1"
    }
  ],
  "section": "Step 8: distinguish enacted 2026 changes from future provisions",
  "source_keys": [
    "EU2026"
  ]
}
```

### 76

| Transition | New Article 87b contains specific preservation/request rules for unchanged situations and pre-**2 November 2028** postings; the specified continuity can run no later than **2 November 2036**. Eligibility must be checked against that complete transitional clause, not assumed for every worker. [Regulation(EU)2026/2359, enacted English body](https://publications.europa.eu/resource/cellar/5794f71b-d1a7-11f1-9458-01aa75ed71a1.0006.03/DOC_1) |

```json
{
  "figures": [
    "2",
    "2028",
    "2",
    "2036",
    "026"
  ],
  "id": 76,
  "kind": "source-cited rule and its explicit conditions",
  "line": 140,
  "operative_bindings": [
    {
      "locator": "Article1(36),new87b(4)",
      "quote_id": "EU2026-032",
      "read_date": "2026-11-16",
      "source": "EU2026",
      "url": "https://publications.europa.eu/resource/cellar/5794f71b-d1a7-11f1-9458-01aa75ed71a1.0006.03/DOC_1"
    },
    {
      "locator": "Article1(39)/Article2(52),applicationlists",
      "quote_id": "EU2026-028",
      "read_date": "2026-11-16",
      "source": "EU2026",
      "url": "https://publications.europa.eu/resource/cellar/5794f71b-d1a7-11f1-9458-01aa75ed71a1.0006.03/DOC_1"
    }
  ],
  "section": "Step 8: distinguish enacted 2026 changes from future provisions",
  "source_keys": [
    "EU2026"
  ]
}
```

### 77

The business-trip exemption is a future **notification** exception within its precise scope, not a general income-tax, immigration, posted-worker-employment-law or social-coverage exemption. No general automatic **24-month certificate renewal** follows from the amendment. [Regulation(EU)2026/2359, enacted English body](https://publications.europa.eu/resource/cellar/5794f71b-d1a7-11f1-9458-01aa75ed71a1.0006.03/DOC_1)

```json
{
  "figures": [
    "24",
    "026"
  ],
  "id": 77,
  "kind": "source-cited rule and its explicit conditions",
  "line": 142,
  "operative_bindings": [
    {
      "locator": "Article1(39)/Article2(52),applicationlists",
      "quote_id": "EU2026-028",
      "read_date": "2026-11-16",
      "source": "EU2026",
      "url": "https://publications.europa.eu/resource/cellar/5794f71b-d1a7-11f1-9458-01aa75ed71a1.0006.03/DOC_1"
    },
    {
      "locator": "Article1(8),newrecital40b",
      "quote_id": "EU2026-033",
      "read_date": "2026-11-16",
      "source": "EU2026",
      "url": "https://publications.europa.eu/resource/cellar/5794f71b-d1a7-11f1-9458-01aa75ed71a1.0006.03/DOC_1"
    }
  ],
  "section": "Step 8: distinguish enacted 2026 changes from future provisions",
  "source_keys": [
    "EU2026"
  ]
}
```

### 78

### Step 9: use bilateral coverage instruments separately

```json
{
  "figures": [
    "9"
  ],
  "id": 78,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 144,
  "operative_bindings": [],
  "section": "Step 9: use bilateral coverage instruments separately",
  "source_keys": []
}
```

### 79

SSA's official status list confirms US agreements with the **UK, Germany, France, Italy, Japan and Portugal**. Their scope and detached-worker/self-employed branches are not identical; the list alone does not prove exemption from every host social charge. [SSA agreements-in-force register](https://www.ssa.gov/international/status.html)

```json
{
  "figures": [],
  "id": 79,
  "kind": "source-cited rule and its explicit conditions",
  "line": 146,
  "operative_bindings": [
    {
      "locator": "Officialcurrentregister,usedcountryrows",
      "quote_id": "SSALIST-046",
      "read_date": "2026-11-16",
      "source": "SSALIST",
      "url": "https://www.ssa.gov/international/status.html"
    },
    {
      "locator": "Portugalrow",
      "quote_id": "SSALIST-047",
      "read_date": "2026-11-16",
      "source": "SSALIST",
      "url": "https://www.ssa.gov/international/status.html"
    }
  ],
  "section": "Step 9: use bilateral coverage instruments separately",
  "source_keys": [
    "SSALIST"
  ]
}
```

### 80

The actual US–Portugal agreement has been in force since **1 August 1989**. Article 4 ordinarily follows employment's work state. Article 5 permits qualifying temporarily sent employees to remain under the sending state's covered legislation where expected work does not exceed **5 years**; an unforeseen extension requires competent-authority consent, requested before the five years expire, and is limited to **1 year**. Self-employment, transport and exceptional agreement branches have separate conditions; the material scope does not encompass every possible levy or benefit. This directly corrects the original “no US–Portugal totalization agreement” assertion. [US–Portugal SocialSecurityAgreement](https://www.ssa.gov/international/Agreement_Texts/portugal.html)

```json
{
  "figures": [
    "1",
    "1989",
    "4",
    "5",
    "5",
    "1"
  ],
  "id": 80,
  "kind": "source-cited rule and its explicit conditions",
  "line": 148,
  "operative_bindings": [
    {
      "locator": "Article4(1)",
      "quote_id": "USPT-051",
      "read_date": "2026-11-16",
      "source": "USPT",
      "url": "https://www.ssa.gov/international/Agreement_Texts/portugal.html"
    },
    {
      "locator": "Article5(2)",
      "quote_id": "USPT-049",
      "read_date": "2026-11-16",
      "source": "USPT",
      "url": "https://www.ssa.gov/international/Agreement_Texts/portugal.html"
    }
  ],
  "section": "Step 9: use bilateral coverage instruments separately",
  "source_keys": [
    "USPT"
  ]
}
```

### 81

Within the TCA’s applicable personal/material scope and UK–Member-State cross-border nexus, SSC.11 permits eligible detached employees and similar temporary self-employed activity to retain sending-state coverage for anticipated work not exceeding **24 months**. Employer normal activity, sending on its behalf, employee non-replacement and the relevant state participation conditions apply. Decision 1/2021 places all EU Member States in Annex SSC-8’s detached-worker category; this does not waive individual conditions. Foreign-employer obligations and any notified employee-payment agreement follow SSC.14; the employer is not released. The unchanged actual source scopes and completed independent social-security review are reused here. No EU Article16/telework derogation is imported into a TCA-only case. [UK–EU TCA Protocol](https://assets.publishing.service.gov.uk/media/608ae0c0d3bf7f0136332887/TS_8.2021_UK_EU_EAEC_Trade_and_Cooperation_Agreement.pdf) [UK–EU Decision1/2021,AnnexSSC8](https://assets.publishing.service.gov.uk/media/61a5f3ebe90e07043c35f448/TS_21.2021_Decision_No_1.2021_Specialised_Committee_Social_Security.pdf)

```json
{
  "figures": [
    "11",
    "24",
    "1",
    "2021",
    "8",
    "14",
    "6"
  ],
  "id": 81,
  "kind": "source-cited rule and its explicit conditions",
  "line": 150,
  "operative_bindings": [
    {
      "locator": "SSC14(2)",
      "quote_id": "TCA-096",
      "read_date": "2026-11-15",
      "source": "TCA",
      "url": "https://assets.publishing.service.gov.uk/media/608ae0c0d3bf7f0136332887/TS_8.2021_UK_EU_EAEC_Trade_and_Cooperation_Agreement.pdf"
    },
    {
      "locator": "SSC11(1)(a)/(b)",
      "quote_id": "TCA-095",
      "read_date": "2026-11-15",
      "source": "TCA",
      "url": "https://assets.publishing.service.gov.uk/media/608ae0c0d3bf7f0136332887/TS_8.2021_UK_EU_EAEC_Trade_and_Cooperation_Agreement.pdf"
    },
    {
      "locator": "Article1/AnnexII",
      "quote_id": "TCAAMEND-098",
      "read_date": "2026-11-15",
      "source": "TCAAMEND",
      "url": "https://assets.publishing.service.gov.uk/media/61a5f3ebe90e07043c35f448/TS_21.2021_Decision_No_1.2021_Specialised_Committee_Social_Security.pdf"
    },
    {
      "locator": "AnnexII",
      "quote_id": "TCAAMEND-099",
      "read_date": "2026-11-15",
      "source": "TCAAMEND",
      "url": "https://assets.publishing.service.gov.uk/media/61a5f3ebe90e07043c35f448/TS_21.2021_Decision_No_1.2021_Specialised_Committee_Social_Security.pdf"
    }
  ],
  "section": "Step 9: use bilateral coverage instruments separately",
  "source_keys": [
    "TCA",
    "TCAAMEND"
  ]
}
```

### 82

The original **Australia 30+ agreements** and **India–Germany/France/Belgium/Netherlands** statements remain individual research questions in Sources: current operative texts and their conditions were not read successfully here. Do not substitute EU Article 12 for UK TCA eligibility or infer contribution relief from an agreement count. Where no applicable coordination relief is established, assess both domestic systems; dual charges are a risk to establish, not an inevitable conclusion for every worker.

```json
{
  "figures": [
    "30",
    "12"
  ],
  "id": 82,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 152,
  "operative_bindings": [],
  "section": "Step 9: use bilateral coverage instruments separately",
  "source_keys": []
}
```

### 83

### Step 10: classify the worker under the relevant legal regime

```json
{
  "figures": [
    "10"
  ],
  "id": 83,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 154,
  "operative_bindings": [],
  "section": "Step 10: classify the worker under the relevant legal regime",
  "source_keys": []
}
```

### 84

| Jurisdiction | Verified routing and limits |

```json
{
  "figures": [],
  "id": 84,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 156,
  "operative_bindings": [],
  "section": "Step 10: classify the worker under the relevant legal regime",
  "source_keys": []
}
```

### 85

| US federal | IRS common-law analysis considers behavioral control, financial control and the relationship; all facts matter and no single factor decides. A remote location, invoice or contract label alone is insufficient. [IRS employee/contractor classification](https://www.irs.gov/businesses/small-businesses-self-employed/independent-contractor-self-employed-or-employee) |

```json
{
  "figures": [],
  "id": 85,
  "kind": "source-cited rule and its explicit conditions",
  "line": 158,
  "operative_bindings": [
    {
      "locator": "Remoteworkerparagraph",
      "quote_id": "USSTATUS-053",
      "read_date": "2026-11-16",
      "source": "USSTATUS",
      "url": "https://www.irs.gov/businesses/small-businesses-self-employed/independent-contractor-self-employed-or-employee"
    },
    {
      "locator": "Determiningrelationship,allfactorsparagraph",
      "quote_id": "USSTATUS-052",
      "read_date": "2026-11-16",
      "source": "USSTATUS",
      "url": "https://www.irs.gov/businesses/small-businesses-self-employed/independent-contractor-self-employed-or-employee"
    }
  ],
  "section": "Step 10: classify the worker under the relevant legal regime",
  "source_keys": [
    "USSTATUS"
  ]
}
```

### 86

| California | Where applicable, the hiring entity must satisfy **all three ABC limbs**: freedom from control in contract/fact; work outside its usual business; and an independently established same-nature business. Statutory exceptions and other tests, including Borello, must be checked. Do not declare the B limb universally “hardest” or import California's test into federal tax. [CaliforniaDIR employee/contractor guidance](https://www.dir.ca.gov/dlse/FAQ_IndependentContractor.htm) |

```json
{
  "figures": [],
  "id": 86,
  "kind": "source-cited rule and its explicit conditions",
  "line": 159,
  "operative_bindings": [
    {
      "locator": "Question1fullABClimbs",
      "quote_id": "CA-054",
      "read_date": "2026-11-16",
      "source": "CA",
      "url": "https://www.dir.ca.gov/dlse/FAQ_IndependentContractor.htm"
    },
    {
      "locator": "Question9",
      "quote_id": "CA-055",
      "read_date": "2026-11-16",
      "source": "CA",
      "url": "https://www.dir.ca.gov/dlse/FAQ_IndependentContractor.htm"
    }
  ],
  "section": "Step 10: classify the worker under the relevant legal regime",
  "source_keys": [
    "CA"
  ]
}
```

### 87

| UK | Off-payroll rules concern services through an intermediary and their actual charge/scope conditions. HMRC ESM10025 distinguishes a wholly overseas non-UK-connected client and the intermediary's Chapter 8 position; the worker's UK tax/NIC charge still matters. A worker abroad is not automatically outside every UK rule. Public/medium-large client responsibility must be assessed under current scope, not a universal contractor label. [HMRC ESM10025, international off-payroll](https://www.gov.uk/hmrc-internal-manuals/employment-status-manual/esm10025) |

```json
{
  "figures": [
    "0025",
    "8",
    "5"
  ],
  "id": 87,
  "kind": "source-cited rule and its explicit conditions",
  "line": 160,
  "operative_bindings": [
    {
      "locator": "ESM10025Workerlastparagraph",
      "quote_id": "UKIR35-058",
      "read_date": "2026-11-16",
      "source": "UKIR35",
      "url": "https://www.gov.uk/hmrc-internal-manuals/employment-status-manual/esm10025"
    },
    {
      "locator": "ESM10025Clientwhollyoverseas",
      "quote_id": "UKIR35-057",
      "read_date": "2026-11-16",
      "source": "UKIR35",
      "url": "https://www.gov.uk/hmrc-internal-manuals/employment-status-manual/esm10025"
    }
  ],
  "section": "Step 10: classify the worker under the relevant legal regime",
  "source_keys": [
    "UKIR35"
  ]
}
```

### 88

| Germany | SGB IV §7 focuses on dependent employment, especially instructions and integration. SGB VI §2(9) separately imposes pension coverage on specified genuinely self-employed people with no regular insured employee and essentially one permanent client. It is not an income-percentage employment-classification test. [Germany SGBIV section7](https://www.gesetze-im-internet.de/sgb_4/__7.html) [Germany SGBVI section2](https://www.gesetze-im-internet.de/sgb_6/__2.html) |

```json
{
  "figures": [
    "7",
    "2",
    "9"
  ],
  "id": 88,
  "kind": "source-cited rule and its explicit conditions",
  "line": 161,
  "operative_bindings": [
    {
      "locator": "SGBIV7(1)",
      "quote_id": "DESTATUS-059",
      "read_date": "2026-11-16",
      "source": "DESTATUS",
      "url": "https://www.gesetze-im-internet.de/sgb_4/__7.html"
    },
    {
      "locator": "SGBVI2sentence1number9(a)",
      "quote_id": "DEPENSION-060",
      "read_date": "2026-11-16",
      "source": "DEPENSION",
      "url": "https://www.gesetze-im-internet.de/sgb_6/__2.html"
    },
    {
      "locator": "SGBVI2sentence1number9(b)",
      "quote_id": "DEPENSION-061",
      "read_date": "2026-11-16",
      "source": "DEPENSION",
      "url": "https://www.gesetze-im-internet.de/sgb_6/__2.html"
    }
  ],
  "section": "Step 10: classify the worker under the relevant legal regime",
  "source_keys": [
    "DESTATUS",
    "DEPENSION"
  ]
}
```

### 89

| France | The read **28 May 2026** L.8221-6 version provides a nonemployment presumption for listed registered categories, rebuttable by a permanent legal-subordination relationship; intentional concealment and employer-contribution consequences have distinct conditions. That dated text is not clearance of every current French employment/tax rule. [France L8221-6,28May2026version](https://www.legifrance.gouv.fr/codes/section_lc/LEGITEXT000006072050/LEGISCTA000006178267/2026-05-28) |

```json
{
  "figures": [
    "28",
    "2026",
    "8221",
    "6"
  ],
  "id": 89,
  "kind": "source-cited rule and its explicit conditions",
  "line": 162,
  "operative_bindings": [
    {
      "locator": "L8221-6II",
      "quote_id": "FR-062",
      "read_date": "2026-11-16",
      "source": "FR",
      "url": "https://www.legifrance.gouv.fr/codes/section_lc/LEGITEXT000006072050/LEGISCTA000006178267/2026-05-28"
    },
    {
      "locator": "L8221-6II",
      "quote_id": "FR-063",
      "read_date": "2026-11-16",
      "source": "FR",
      "url": "https://www.legifrance.gouv.fr/codes/section_lc/LEGITEXT000006072050/LEGISCTA000006178267/2026-05-28"
    }
  ],
  "section": "Step 10: classify the worker under the relevant legal regime",
  "source_keys": [
    "FR"
  ]
}
```

### 90

| Netherlands | Official current guidance says the moratorium ended **1 January 2025**; corrections/assessments can follow without the former preliminary instruction. In **2026**, culpability penalties (**vergrijpboetes**) can apply, but default penalties (**verzuimboetes**) are not imposed. Ordinary retrospective assessment starts at **1 January 2025**, with malicious/ignored-instruction exceptions extending the period. [Belastingdienst, current labour-relation enforcement](https://www.belastingdienst.nl/wps/wcm/connect/nl/arbeidsrelaties/content/handhaving) |

```json
{
  "figures": [
    "1",
    "2025",
    "2026",
    "1",
    "2025"
  ],
  "id": 90,
  "kind": "source-cited rule and its explicit conditions",
  "line": 163,
  "operative_bindings": [
    {
      "locator": "Currentenforcementmain2026paragraph",
      "quote_id": "NL-064",
      "read_date": "2026-11-16",
      "source": "NL",
      "url": "https://www.belastingdienst.nl/wps/wcm/connect/nl/arbeidsrelaties/content/handhaving"
    },
    {
      "locator": "Mainretroactivitysection",
      "quote_id": "NL-066",
      "read_date": "2026-11-16",
      "source": "NL",
      "url": "https://www.belastingdienst.nl/wps/wcm/connect/nl/arbeidsrelaties/content/handhaving"
    }
  ],
  "section": "Step 10: classify the worker under the relevant legal regime",
  "source_keys": [
    "NL"
  ]
}
```

### 91

| Spain | Estatuto Article 1(1) addresses voluntary remunerated services for another within that person's organization/direction; Article 1 exclusions and special relationships must be considered. Classification does not automatically establish unlimited retroactive recovery of every benefit. [Spain Estatuto de los Trabajadores](https://www.boe.es/buscar/act.php?id=BOE-A-2015-11430) |

```json
{
  "figures": [
    "1",
    "1",
    "1"
  ],
  "id": 91,
  "kind": "source-cited rule and its explicit conditions",
  "line": 164,
  "operative_bindings": [
    {
      "locator": "Article1(1)",
      "quote_id": "ES-067",
      "read_date": "2026-11-16",
      "source": "ES",
      "url": "https://www.boe.es/buscar/act.php?id=BOE-A-2015-11430"
    }
  ],
  "section": "Step 10: classify the worker under the relevant legal regime",
  "source_keys": [
    "ES"
  ]
}
```

### 92

| Australia | FWO says constitutionally covered businesses use the whole-of-relationship test from **26 August 2024**: substance, practical reality, true nature, contract and performance. State-referred businesses, earlier work and valid high-income opt-outs follow the separate start-of-relationship route. All factors matter; an ABN/invoice alone does not decide. [FWO whole-of-relationship test](https://www.fairwork.gov.au/find-help-for/independent-contractors/whole-of-relationship-test) |

```json
{
  "figures": [
    "26",
    "2024"
  ],
  "id": 92,
  "kind": "source-cited rule and its explicit conditions",
  "line": 165,
  "operative_bindings": [
    {
      "locator": "Howthetestworks",
      "quote_id": "AU-069",
      "read_date": "2026-11-16",
      "source": "AU",
      "url": "https://www.fairwork.gov.au/find-help-for/independent-contractors/whole-of-relationship-test"
    },
    {
      "locator": "Whousesthistest",
      "quote_id": "AU-068",
      "read_date": "2026-11-16",
      "source": "AU",
      "url": "https://www.fairwork.gov.au/find-help-for/independent-contractors/whole-of-relationship-test"
    }
  ],
  "section": "Step 10: classify the worker under the relevant legal regime",
  "source_keys": [
    "AU"
  ]
}
```

### 93

| India | Original control/integration questions are retained as factual review prompts. The old Contract Labour Act label does not establish the current classification, applicable Labour Code, agency-employment, withholding or social-security result. Each remains non-usable pending the specified primary-source checks in Sources. |

```json
{
  "figures": [],
  "id": 93,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 166,
  "operative_bindings": [],
  "section": "Step 10: classify the worker under the relevant legal regime",
  "source_keys": []
}
```

### 94

### Step 11: assess equity awards without a universal vesting formula

```json
{
  "figures": [
    "11"
  ],
  "id": 94,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 168,
  "operative_bindings": [],
  "section": "Step 11: assess equity awards without a universal vesting formula",
  "source_keys": []
}
```

### 95

Record grant/award documents, service/vesting conditions, residence changes, actual workdays, taxable event, valuation/currency, restrictions, withholding and the actual employment/relief articles. A service-period allocation is a question to establish for the actual award and country; calendar vesting days and physical-presence treaty days are not interchangeable. The model employment framework alone does not verify domestic RSU/option timing. [OECD Model 2025, employment article and Commentary](https://www.oecd.org/content/dam/oecd/en/publications/reports/2026/06/model-tax-convention-on-income-and-on-capital-2025-full-version_4fd97b89/db32e18b-en.pdf)

```json
{
  "figures": [],
  "id": 95,
  "kind": "source-cited rule and its explicit conditions",
  "line": 170,
  "operative_bindings": [
    {
      "locator": "Commentary15paragraph5/5.1",
      "quote_id": "MODEL-003",
      "read_date": "2026-11-16",
      "source": "MODEL",
      "url": "https://www.oecd.org/content/dam/oecd/en/publications/reports/2026/06/model-tax-convention-on-income-and-on-capital-2025-full-version_4fd97b89/db32e18b-en.pdf"
    },
    {
      "locator": "Article15(1)",
      "quote_id": "MODEL-001",
      "read_date": "2026-11-16",
      "source": "MODEL",
      "url": "https://www.oecd.org/content/dam/oecd/en/publications/reports/2026/06/model-tax-convention-on-income-and-on-capital-2025-full-version_4fd97b89/db32e18b-en.pdf"
    }
  ],
  "section": "Step 11: assess equity awards without a universal vesting formula",
  "source_keys": [
    "MODEL"
  ]
}
```

### 96

Where the actual award/country rule requires a service-day allocation, the arithmetic is **relevant Country X service days ÷ total relevant service days × allocable employment income**. The original vesting-period formula is retained as that conditional computation, not as a universal legal rule. Establish the actual service period, denominator, sourcing exceptions and amount before using it.

```json
{
  "figures": [],
  "id": 96,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 172,
  "operative_bindings": [],
  "section": "Step 11: assess equity awards without a universal vesting formula",
  "source_keys": []
}
```

### 97

| Original country row | Current usable boundary |

```json
{
  "figures": [],
  "id": 97,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 174,
  "operative_bindings": [],
  "section": "Step 11: assess equity awards without a universal vesting formula",
  "source_keys": []
}
```

### 98

| US | IRS distinguishes statutory ISO/ESPP from nonstatutory options. Statutory options generally produce no grant/exercise gross income, but ISO exercise can cause AMT and disposition conditions affect ordinary/capital treatment. A nonstatutory option with readily determinable fair value can be taxed at grant; otherwise exercise generally produces the spread as income. Later sale has its own gain/loss. “ISO only capital gain at sale” is false. This source does **not** clear every RSU event. [IRS Topic427, stockoptions](https://www.irs.gov/taxtopics/tc427) |

```json
{
  "figures": [],
  "id": 98,
  "kind": "source-cited rule and its explicit conditions",
  "line": 176,
  "operative_bindings": [
    {
      "locator": "Nonstatutoryoptions",
      "quote_id": "USOPTIONS-074",
      "read_date": "2026-11-16",
      "source": "USOPTIONS",
      "url": "https://www.irs.gov/taxtopics/tc427"
    },
    {
      "locator": "Nonstatutoryoptionssale",
      "quote_id": "USOPTIONS-075",
      "read_date": "2026-11-16",
      "source": "USOPTIONS",
      "url": "https://www.irs.gov/taxtopics/tc427"
    }
  ],
  "section": "Step 11: assess equity awards without a universal vesting formula",
  "source_keys": [
    "USOPTIONS"
  ]
}
```

### 99

| UK | The old universal RSU-vesting/option-exercise table is held individually; actual plan, employment-income rules, international allocation and post-April-2025 rules must be verified. The recovered historic remittance-basis manual is not current-law clearance. |

```json
{
  "figures": [
    "2025"
  ],
  "id": 99,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 177,
  "operative_bindings": [],
  "section": "Step 11: assess equity awards without a universal vesting formula",
  "source_keys": []
}
```

### 100

| Germany | The old universal vest/exercise and flat Abgeltungsteuer sale description is held individually; actual plan, restrictions, employment income and later investment gain/relief require current sources. |

```json
{
  "figures": [],
  "id": 100,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 178,
  "operative_bindings": [],
  "section": "Step 11: assess equity awards without a universal vesting formula",
  "source_keys": []
}
```

### 101

| France | Qualified/nonqualified awards, acquisition/sale events and social charges require the actual statutory plan/date conditions; the old vesting/sale shorthand is held individually. |

```json
{
  "figures": [],
  "id": 101,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 179,
  "operative_bindings": [],
  "section": "Step 11: assess equity awards without a universal vesting formula",
  "source_keys": []
}
```

### 102

| India | The old vesting/allotment or option-exercise perquisite and capital-gain statements require current charging/valuation rules and plan facts; no universal result is supplied. |

```json
{
  "figures": [],
  "id": 102,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 180,
  "operative_bindings": [],
  "section": "Step 11: assess equity awards without a universal vesting formula",
  "source_keys": []
}
```

### 103

| Australia | The old upfront-vesting versus deferred-sale summary is held individually. Actual ESS conditions and taxing point must be read; sale is not assumed to be the universal deferral endpoint. |

```json
{
  "figures": [],
  "id": 103,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 181,
  "operative_bindings": [],
  "section": "Step 11: assess equity awards without a universal vesting formula",
  "source_keys": []
}
```

### 104

Treaty allocation, domestic tax timing and double-tax relief are separate. The actual treaty may provide exemption or a limited credit; UK–Germany Article 23's UK credit branch is subject to its conditions and does not prove that every German-resident award receives a credit. A mismatch in years, character or income attribution can prevent full matching. Contractual equalisation may allocate remaining cost but does not create statutory relief. [UK–Germany treaty, consolidated after2021Protocol](https://www.gov.uk/government/publications/germany-tax-treaties/2010-uk-germany-double-taxation-convention-as-amended-by-the-2021-protocol-in-force) [HMRC2026 helpsheetHS212](https://www.gov.uk/government/publications/tax-equalisation-hs212-self-assessment-helpsheet/tax-equalisation-2026-hs212)

```json
{
  "figures": [
    "23"
  ],
  "id": 104,
  "kind": "source-cited rule and its explicit conditions",
  "line": 183,
  "operative_bindings": [
    {
      "locator": "Article23(2)(a)",
      "quote_id": "UKDE-012",
      "read_date": "2026-11-16",
      "source": "UKDE",
      "url": "https://www.gov.uk/government/publications/germany-tax-treaties/2010-uk-germany-double-taxation-convention-as-amended-by-the-2021-protocol-in-force"
    },
    {
      "locator": "Article14(2)(a)",
      "quote_id": "UKDE-008",
      "read_date": "2026-11-16",
      "source": "UKDE",
      "url": "https://www.gov.uk/government/publications/germany-tax-treaties/2010-uk-germany-double-taxation-convention-as-amended-by-the-2021-protocol-in-force"
    },
    {
      "locator": "HS212section1definition",
      "quote_id": "TAXEQ-044",
      "read_date": "2026-11-16",
      "source": "TAXEQ",
      "url": "https://www.gov.uk/government/publications/tax-equalisation-hs212-self-assessment-helpsheet/tax-equalisation-2026-hs212"
    },
    {
      "locator": "HS212section1definition",
      "quote_id": "TAXEQ-043",
      "read_date": "2026-11-16",
      "source": "TAXEQ",
      "url": "https://www.gov.uk/government/publications/tax-equalisation-hs212-self-assessment-helpsheet/tax-equalisation-2026-hs212"
    }
  ],
  "section": "Step 11: assess equity awards without a universal vesting formula",
  "source_keys": [
    "UKDE",
    "TAXEQ"
  ]
}
```

### 105

## Deadlines and filing

```json
{
  "figures": [],
  "id": 105,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 185,
  "operative_bindings": [],
  "section": "Deadlines and filing",
  "source_keys": []
}
```

### 106

Build a country-specific calendar for employer registration, commencement/posted-worker notification, social-security application, periodic withholding/reporting/payment, annual employer statements and employee returns. Record the authority, rule version and party responsible. No universal payroll deadline or automatic short-visit collection relief is verified here. For multistate EU procedures and current advance-information duties, use the specific competent-institution route above; for UK short-term PAYE, confirm the employer's actual approved arrangement. [Regulation987/2009,1January2018consolidation](https://publications.europa.eu/resource/cellar/00185d05-a69f-4055-8a8e-341c14c29d50.0020.02/DOC_1) [HMRC PAYE82000, short-term visitors](https://www.gov.uk/hmrc-internal-manuals/paye-manual/paye82000)

```json
{
  "figures": [
    "87"
  ],
  "id": 106,
  "kind": "source-cited rule and its explicit conditions",
  "line": 187,
  "operative_bindings": [
    {
      "locator": "Article15(1)",
      "quote_id": "EU987-025",
      "read_date": "2026-11-16",
      "source": "EU987",
      "url": "https://publications.europa.eu/resource/cellar/00185d05-a69f-4055-8a8e-341c14c29d50.0020.02/DOC_1"
    },
    {
      "locator": "Article16(1)",
      "quote_id": "EU987-026",
      "read_date": "2026-11-16",
      "source": "EU987",
      "url": "https://publications.europa.eu/resource/cellar/00185d05-a69f-4055-8a8e-341c14c29d50.0020.02/DOC_1"
    },
    {
      "locator": "PAYE82000openingandconditions68–89",
      "quote_id": "UKPAYE-042",
      "read_date": "2026-11-16",
      "source": "UKPAYE",
      "url": "https://www.gov.uk/hmrc-internal-manuals/paye-manual/paye82000"
    }
  ],
  "section": "Deadlines and filing",
  "source_keys": [
    "EU987",
    "UKPAYE"
  ]
}
```

### 107

## Penalties and interest

```json
{
  "figures": [],
  "id": 107,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 189,
  "operative_bindings": [],
  "section": "Penalties and interest",
  "source_keys": []
}
```

### 108

| Country | Verified consequence and individually unresolved limits |

```json
{
  "figures": [],
  "id": 108,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 191,
  "operative_bindings": [],
  "section": "Penalties and interest",
  "source_keys": []
}
```

### 109

| Germany | SGB IV §25 normally limits contribution claims to **4 years after the end of the calendar year in which due**, and **30 years** for intentionally withheld contributions, with its suspension/extension rules. The original blanket fine and automatic criminal consequence were not verified and cannot be used as the result of every misclassification. [Germany SGBIV section25](https://www.gesetze-im-internet.de/sgb_4/__25.html) |

```json
{
  "figures": [
    "25",
    "4",
    "30"
  ],
  "id": 109,
  "kind": "source-cited rule and its explicit conditions",
  "line": 193,
  "operative_bindings": [
    {
      "locator": "Section25(1)sentence1",
      "quote_id": "DELIMIT-076",
      "read_date": "2026-11-16",
      "source": "DELIMIT",
      "url": "https://www.gesetze-im-internet.de/sgb_4/__25.html"
    },
    {
      "locator": "Section25(1)sentence2",
      "quote_id": "DELIMIT-077",
      "read_date": "2026-11-16",
      "source": "DELIMIT",
      "url": "https://www.gesetze-im-internet.de/sgb_4/__25.html"
    }
  ],
  "section": "Penalties and interest",
  "source_keys": [
    "DELIMIT"
  ]
}
```

### 110

| US federal | Section 3509 is a conditional worker-reclassification computation, **not “20% of wages plus 100% FICA.”** Under the ordinary lower branch: **1.5% of wages** for withholding and **20% of the employee FICA share**, plus the full employer share. Specified reporting failure raises the first amounts to **3% / 40%**, subject to reasonable-cause/not-willful-neglect relief. Intentional disregard and other statutory exclusions can make the reduced regime inapplicable; employer FICA/FUTA is not erased. Additional tax, interest and penalty provisions need their own conditions. The statute capture is the explicit **2024 edition**, corroborated by current IRS IRM 4.23.8.5. [USCode2024,26USC3509](https://www.govinfo.gov/content/pkg/USCODE-2024-title26/html/USCODE-2024-title26-subtitleC-chap25-sec3509.htm) [IRS IRM4.23.8.5](https://www.irs.gov/irm/part4/irm_04-023-008) |

```json
{
  "figures": [
    "3509",
    "20%",
    "100%",
    "1.5%",
    "20%",
    "3%",
    "40%",
    "2024",
    "4.23.8.5",
    "509"
  ],
  "id": 110,
  "kind": "source-cited rule and its explicit conditions",
  "line": 194,
  "operative_bindings": [
    {
      "locator": "3509(a)(2)",
      "quote_id": "US3509-079",
      "read_date": "2026-11-16",
      "source": "US3509",
      "url": "https://www.govinfo.gov/content/pkg/USCODE-2024-title26/html/USCODE-2024-title26-subtitleC-chap25-sec3509.htm"
    },
    {
      "locator": "3509(c)",
      "quote_id": "US3509-082",
      "read_date": "2026-11-16",
      "source": "US3509",
      "url": "https://www.govinfo.gov/content/pkg/USCODE-2024-title26/html/USCODE-2024-title26-subtitleC-chap25-sec3509.htm"
    },
    {
      "locator": "4.23.8.5.1/5.2",
      "quote_id": "USIRM-084",
      "read_date": "2026-11-16",
      "source": "USIRM",
      "url": "https://www.irs.gov/irm/part4/irm_04-023-008"
    },
    {
      "locator": "4.23.8.5.1",
      "quote_id": "USIRM-083",
      "read_date": "2026-11-16",
      "source": "USIRM",
      "url": "https://www.irs.gov/irm/part4/irm_04-023-008"
    }
  ],
  "section": "Penalties and interest",
  "source_keys": [
    "US3509",
    "USIRM"
  ]
}
```

### 111

| California | DIR describes **USD 5,000–25,000 per willful violation** under Labor Code 226.8, separate from other restitution/tax consequences. This is a summary range, not proof that the top applies to every error or a cleared statutory distinction between ordinary and pattern/practice branches. [CaliforniaDIR employee/contractor guidance](https://www.dir.ca.gov/dlse/FAQ_IndependentContractor.htm) |

```json
{
  "figures": [
    "5,000",
    "25,000",
    "226.8"
  ],
  "id": 111,
  "kind": "source-cited rule and its explicit conditions",
  "line": 195,
  "operative_bindings": [
    {
      "locator": "Question10willfulmisclassification",
      "quote_id": "CA-056",
      "read_date": "2026-11-16",
      "source": "CA",
      "url": "https://www.dir.ca.gov/dlse/FAQ_IndependentContractor.htm"
    },
    {
      "locator": "Question1fullABClimbs",
      "quote_id": "CA-054",
      "read_date": "2026-11-16",
      "source": "CA",
      "url": "https://www.dir.ca.gov/dlse/FAQ_IndependentContractor.htm"
    }
  ],
  "section": "Penalties and interest",
  "source_keys": [
    "CA"
  ]
}
```

### 112

| Netherlands | Current guidance distinguishes 2026 culpability/default penalties and the ordinary retrospective boundary described above. The original generic “penalties resumed” was incomplete. [Belastingdienst, current labour-relation enforcement](https://www.belastingdienst.nl/wps/wcm/connect/nl/arbeidsrelaties/content/handhaving) |

```json
{
  "figures": [
    "2026"
  ],
  "id": 112,
  "kind": "source-cited rule and its explicit conditions",
  "line": 196,
  "operative_bindings": [
    {
      "locator": "Currentenforcementmain2026paragraph",
      "quote_id": "NL-064",
      "read_date": "2026-11-16",
      "source": "NL",
      "url": "https://www.belastingdienst.nl/wps/wcm/connect/nl/arbeidsrelaties/content/handhaving"
    },
    {
      "locator": "Currentenforcementmain2026paragraph",
      "quote_id": "NL-065",
      "read_date": "2026-11-16",
      "source": "NL",
      "url": "https://www.belastingdienst.nl/wps/wcm/connect/nl/arbeidsrelaties/content/handhaving"
    }
  ],
  "section": "Penalties and interest",
  "source_keys": [
    "NL"
  ]
}
```

### 113

| Australia | FWO's current sham-contracting page requires consideration of the reasonable-belief defense and the particular prohibited conduct. It lists different ceilings for individuals and business sizes; the old uniform ceiling is non-usable. The page's size wording does not resolve the exact-15-employee case here; no universal maximum or automatic **6 years of back leave** is supplied. Superannuation, unpaid entitlements and limitation periods need their own applicable rules. [FWO sham contracting](https://www.fairwork.gov.au/find-help-for/independent-contractors/sham-contracting) |

```json
{
  "figures": [
    "15",
    "6"
  ],
  "id": 113,
  "kind": "source-cited rule and its explicit conditions",
  "line": 197,
  "operative_bindings": [
    {
      "locator": "Understandingcontracting",
      "quote_id": "AUSHAM-071",
      "read_date": "2026-11-16",
      "source": "AUSHAM",
      "url": "https://www.fairwork.gov.au/find-help-for/independent-contractors/sham-contracting"
    },
    {
      "locator": "Penaltyparagraph",
      "quote_id": "AUSHAM-072",
      "read_date": "2026-11-16",
      "source": "AUSHAM",
      "url": "https://www.fairwork.gov.au/find-help-for/independent-contractors/sham-contracting"
    }
  ],
  "section": "Penalties and interest",
  "source_keys": [
    "AUSHAM"
  ]
}
```

### 114

| France | Original blanket fine and imprisonment/repeat-offender claims and their current offence/person conditions are individually non-usable pending the actual penalty articles. Do not treat every reclassification as intentional concealed employment. [France L8221-6,28May2026version](https://www.legifrance.gouv.fr/codes/section_lc/LEGITEXT000006072050/LEGISCTA000006178267/2026-05-28) |

```json
{
  "figures": [],
  "id": 114,
  "kind": "source-cited rule and its explicit conditions",
  "line": 198,
  "operative_bindings": [
    {
      "locator": "L8221-6II",
      "quote_id": "FR-063",
      "read_date": "2026-11-16",
      "source": "FR",
      "url": "https://www.legifrance.gouv.fr/codes/section_lc/LEGITEXT000006072050/LEGISCTA000006178267/2026-05-28"
    },
    {
      "locator": "L8221-6II",
      "quote_id": "FR-062",
      "read_date": "2026-11-16",
      "source": "FR",
      "url": "https://www.legifrance.gouv.fr/codes/section_lc/LEGITEXT000006072050/LEGISCTA000006178267/2026-05-28"
    }
  ],
  "section": "Penalties and interest",
  "source_keys": [
    "FR"
  ]
}
```

### 115

| UK / Spain | Back-tax/NIC or employment-rights exposure must follow the applicable charging, culpability and limitation rules. The original automatic/unlimited retroactive benefits and generic penalty outcome are individually non-usable; no numeric assessment is supplied. |

```json
{
  "figures": [],
  "id": 115,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 199,
  "operative_bindings": [],
  "section": "Penalties and interest",
  "source_keys": []
}
```

### 116

### Platform work is a separate scope question

```json
{
  "figures": [],
  "id": 116,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 201,
  "operative_bindings": [],
  "section": "Platform work is a separate scope question",
  "source_keys": []
}
```

### 117

Directive (EU) **2024/2831** entered into force **1 December 2024**; Article 29 sets **2 December 2026** for transposition. Article 5's rebuttable presumption concerns facts indicating direction/control under the relevant national law, with the platform bearing rebuttal. It is not a universal presumption that every overseas contractor is employed. Article 5(3) does not itself apply the presumption to tax, criminal or social-security proceedings, **but a Member State may do so under national law**. For relationships entered into before and still ongoing on **2 December 2026**, Article 5(6) applies it only to the period starting then. National transposition and actual procedures must be checked; a transposition deadline alone is not proof of every state's implementation. [Directive(EU)2024/2831](https://publications.europa.eu/resource/cellar/564844cf-9fd2-11ef-85f0-01aa75ed71a1.0006.03/DOC_1)

```json
{
  "figures": [
    "2024",
    "2831",
    "1",
    "2024",
    "29",
    "2",
    "2026",
    "5",
    "5",
    "3",
    "2",
    "2026",
    "5",
    "6"
  ],
  "id": 117,
  "kind": "source-cited rule and its explicit conditions",
  "line": 203,
  "operative_bindings": [
    {
      "locator": "Article5(3)",
      "quote_id": "PLATFORM-086",
      "read_date": "2026-11-16",
      "source": "PLATFORM",
      "url": "https://publications.europa.eu/resource/cellar/564844cf-9fd2-11ef-85f0-01aa75ed71a1.0006.03/DOC_1"
    },
    {
      "locator": "Article5(1)",
      "quote_id": "PLATFORM-085",
      "read_date": "2026-11-16",
      "source": "PLATFORM",
      "url": "https://publications.europa.eu/resource/cellar/564844cf-9fd2-11ef-85f0-01aa75ed71a1.0006.03/DOC_1"
    }
  ],
  "section": "Platform work is a separate scope question",
  "source_keys": [
    "PLATFORM"
  ]
}
```

### 118

The original effective/proportionate/dissuasive national-sanctions topic is retained as a matter requiring the actual implementing penalty provision; this Guide does not approve a national tariff merely from the Directive's existence.

```json
{
  "figures": [],
  "id": 118,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 205,
  "operative_bindings": [],
  "section": "Platform work is a separate scope question",
  "source_keys": []
}
```

### 119

## Cross-border points

```json
{
  "figures": [],
  "id": 119,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 207,
  "operative_bindings": [],
  "section": "Cross-border points",
  "source_keys": []
}
```

### 120

### Original case 1: US employer and developer in Portugal

```json
{
  "figures": [
    "1"
  ],
  "id": 120,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 209,
  "operative_bindings": [],
  "section": "Original case 1: US employer and developer in Portugal",
  "source_keys": []
}
```

### 121

Original facts unchanged: a US tech company hires a developer living and working in Portugal, without EOR or Portuguese entity. Establish Portuguese employment, employer-registration/withholding and mandatory-protection rules before starting; absence of an entity does not itself remove these questions. Those specific Portuguese execution provisions are not cleared by this Guide.

```json
{
  "figures": [],
  "id": 121,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 211,
  "operative_bindings": [],
  "section": "Original case 1: US employer and developer in Portugal",
  "source_keys": []
}
```

### 122

The original assertion of **no US–Portugal agreement** is wrong. The actual agreement exists; ordinary local work generally points to Portugal within its covered scope, while a qualifying temporary sending could produce a different result. A newly hired permanent Portugal-based worker is not proven to be a detached employee merely because the payer is American. Assess home-office PE under the actual US–Portugal treaty/domestic facts, not a presumed consent test. EOR versus lawful direct registration remains an option to evaluate, not an already licensed solution. [US–Portugal SocialSecurityAgreement](https://www.ssa.gov/international/Agreement_Texts/portugal.html)

```json
{
  "figures": [],
  "id": 122,
  "kind": "source-cited rule and its explicit conditions",
  "line": 213,
  "operative_bindings": [
    {
      "locator": "Article4(1)",
      "quote_id": "USPT-051",
      "read_date": "2026-11-16",
      "source": "USPT",
      "url": "https://www.ssa.gov/international/Agreement_Texts/portugal.html"
    },
    {
      "locator": "Article5(1)",
      "quote_id": "USPT-048",
      "read_date": "2026-11-16",
      "source": "USPT",
      "url": "https://www.ssa.gov/international/Agreement_Texts/portugal.html"
    }
  ],
  "section": "Original case 1: US employer and developer in Portugal",
  "source_keys": [
    "USPT"
  ]
}
```

### 123

### Original case 2: UK employee, German subsidiary, 80 days

```json
{
  "figures": [
    "2",
    "80"
  ],
  "id": 123,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 215,
  "operative_bindings": [],
  "section": "Original case 2: UK employee, German subsidiary, 80 days",
  "source_keys": []
}
```

### 124

Original **80 days in a twelve-month period** retained. Under the read UK–Germany Article **14(2)**, 80 is below 183, but confirm residence, all relevant periods, nonresident employer and PE-cost conditions. A subsidiary recharge alone does not prove the UK's employer has a German PE or fail limb (c); determine the substantive employer and actual cost facts. Assess domestic collection separately, with shadow payroll if that is the applicable mechanism. Social coverage uses the actual UK–EU instrument and certificate procedure, not an assumption that UK workers are automatically under EU Article 12. The actual German collection and case-specific UK TCA coverage/certificate result remains unapproved pending worker/assignment facts and national procedures. [UK–Germany treaty, consolidated after2021Protocol](https://www.gov.uk/government/publications/germany-tax-treaties/2010-uk-germany-double-taxation-convention-as-amended-by-the-2021-protocol-in-force) [OECD Model 2025, employment article and Commentary](https://www.oecd.org/content/dam/oecd/en/publications/reports/2026/06/model-tax-convention-on-income-and-on-capital-2025-full-version_4fd97b89/db32e18b-en.pdf)

```json
{
  "figures": [
    "80",
    "14",
    "2",
    "80",
    "183",
    "12"
  ],
  "id": 124,
  "kind": "source-cited rule and its explicit conditions",
  "line": 217,
  "operative_bindings": [
    {
      "locator": "Article14(2)(c)",
      "quote_id": "UKDE-009",
      "read_date": "2026-11-16",
      "source": "UKDE",
      "url": "https://www.gov.uk/government/publications/germany-tax-treaties/2010-uk-germany-double-taxation-convention-as-amended-by-the-2021-protocol-in-force"
    },
    {
      "locator": "Article14(2)(a)",
      "quote_id": "UKDE-008",
      "read_date": "2026-11-16",
      "source": "UKDE",
      "url": "https://www.gov.uk/government/publications/germany-tax-treaties/2010-uk-germany-double-taxation-convention-as-amended-by-the-2021-protocol-in-force"
    },
    {
      "locator": "Article15(2)(a)",
      "quote_id": "MODEL-002",
      "read_date": "2026-11-16",
      "source": "MODEL",
      "url": "https://www.oecd.org/content/dam/oecd/en/publications/reports/2026/06/model-tax-convention-on-income-and-on-capital-2025-full-version_4fd97b89/db32e18b-en.pdf"
    },
    {
      "locator": "Article15(2)(c)",
      "quote_id": "MODEL-006",
      "read_date": "2026-11-16",
      "source": "MODEL",
      "url": "https://www.oecd.org/content/dam/oecd/en/publications/reports/2026/06/model-tax-convention-on-income-and-on-capital-2025-full-version_4fd97b89/db32e18b-en.pdf"
    }
  ],
  "section": "Original case 2: UK employee, German subsidiary, 80 days",
  "source_keys": [
    "UKDE",
    "MODEL"
  ]
}
```

### 125

### Original case 3: Indian developer, UK client, monthly GBP

```json
{
  "figures": [
    "3"
  ],
  "id": 125,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 219,
  "operative_bindings": [],
  "section": "Original case 3: Indian developer, UK client, monthly GBP",
  "source_keys": []
}
```

### 126

Original independent software developer in India, paid monthly in **GBP**, retained. Own clients/tools and limited integration are factual evidence, not automatic status clearance. The UK off-payroll analysis depends on the intermediary, client connection and worker's UK tax/NIC charge; “overseas contractors are always outside IR35” is wrong. If genuinely outside any UK tax/NIC charge, that affects the off-payroll analysis, but the currency and overseas address alone do not prove it. [HMRC ESM10025, international off-payroll](https://www.gov.uk/hmrc-internal-manuals/employment-status-manual/esm10025)

```json
{
  "figures": [
    "5",
    "5"
  ],
  "id": 126,
  "kind": "source-cited rule and its explicit conditions",
  "line": 221,
  "operative_bindings": [
    {
      "locator": "ESM10025Workerlastparagraph",
      "quote_id": "UKIR35-058",
      "read_date": "2026-11-16",
      "source": "UKIR35",
      "url": "https://www.gov.uk/hmrc-internal-manuals/employment-status-manual/esm10025"
    },
    {
      "locator": "ESM10025Clientwhollyoverseas",
      "quote_id": "UKIR35-057",
      "read_date": "2026-11-16",
      "source": "UKIR35",
      "url": "https://www.gov.uk/hmrc-internal-manuals/employment-status-manual/esm10025"
    }
  ],
  "section": "Original case 3: Indian developer, UK client, monthly GBP",
  "source_keys": [
    "UKIR35"
  ]
}
```

### 127

Indian classification/withholding, the applicable current labour legislation and GST registration/export conditions require separate verified sources. A registered person does **not** necessarily charge output GST merely because registered; use `non-eu-export-services` for the actually verified export-services/LUT route and its conditions. This case does not establish those facts, a registration threshold or a zero-rated export. Exclusivity is a risk fact, not conclusive Indian employment status.

```json
{
  "figures": [],
  "id": 127,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 223,
  "operative_bindings": [],
  "section": "Original case 3: Indian developer, UK client, monthly GBP",
  "source_keys": []
}
```

### 128

### Original case 4: Malta employer posts worker to Germany for 18 months

```json
{
  "figures": [
    "4",
    "18"
  ],
  "id": 128,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 225,
  "operative_bindings": [],
  "section": "Original case 4: Malta employer posts worker to Germany for 18 months",
  "source_keys": []
}
```

### 129

Original **18-month** sending retained. It is within Article 12's **24-month anticipated limit**, but continued Maltese coverage still requires actual scope, genuine normal activity, sending on the employer's behalf, no replacement and the other current conditions. Seek the competent institution's attestation; it is not automatically granted because 18 is below 24. No new **2 November 2028** posting/notification permission applies in 2026. [Regulation883/2004,31July2019consolidation](https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1) [Regulation987/2009,1January2018consolidation](https://publications.europa.eu/resource/cellar/00185d05-a69f-4055-8a8e-341c14c29d50.0020.02/DOC_1) [Regulation(EU)2026/2359, enacted English body](https://publications.europa.eu/resource/cellar/5794f71b-d1a7-11f1-9458-01aa75ed71a1.0006.03/DOC_1)

```json
{
  "figures": [
    "18",
    "12",
    "24",
    "18",
    "24",
    "2",
    "2028",
    "2026",
    "83",
    "87",
    "026"
  ],
  "id": 129,
  "kind": "source-cited rule and its explicit conditions",
  "line": 227,
  "operative_bindings": [
    {
      "locator": "Article12(1)/(2)",
      "quote_id": "EU883-014",
      "read_date": "2026-11-16",
      "source": "EU883",
      "url": "https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1"
    },
    {
      "locator": "Article12(1)",
      "quote_id": "EU883-015",
      "read_date": "2026-11-16",
      "source": "EU883",
      "url": "https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1"
    },
    {
      "locator": "Article14(2)",
      "quote_id": "EU987-022",
      "read_date": "2026-11-16",
      "source": "EU987",
      "url": "https://publications.europa.eu/resource/cellar/00185d05-a69f-4055-8a8e-341c14c29d50.0020.02/DOC_1"
    },
    {
      "locator": "Article15(1)",
      "quote_id": "EU987-025",
      "read_date": "2026-11-16",
      "source": "EU987",
      "url": "https://publications.europa.eu/resource/cellar/00185d05-a69f-4055-8a8e-341c14c29d50.0020.02/DOC_1"
    },
    {
      "locator": "Article1(39)/Article2(52),applicationlists",
      "quote_id": "EU2026-028",
      "read_date": "2026-11-16",
      "source": "EU2026",
      "url": "https://publications.europa.eu/resource/cellar/5794f71b-d1a7-11f1-9458-01aa75ed71a1.0006.03/DOC_1"
    },
    {
      "locator": "Article1(39)/Article2(52),immediatelist",
      "quote_id": "EU2026-029",
      "read_date": "2026-11-16",
      "source": "EU2026",
      "url": "https://publications.europa.eu/resource/cellar/5794f71b-d1a7-11f1-9458-01aa75ed71a1.0006.03/DOC_1"
    }
  ],
  "section": "Original case 4: Malta employer posts worker to Germany for 18 months",
  "source_keys": [
    "EU883",
    "EU987",
    "EU2026"
  ]
}
```

### 130

An 18-month duration is not itself a verified income-tax day-count: identify physical presence and the actual Malta–Germany treaty/collection rules. EU posted-worker employment conditions form a separate clock: Directive 96/71 Articles 1–3 cover qualifying transnational postings; mandatory host terms include remuneration, work/rest, leave, health/safety and other listed matters. After **12 months**, expanded host terms apply subject to the specified contract-conclusion/termination and occupational-pension exclusions; a motivated notification can extend that threshold to **18 months**. Same-task/place replacements are cumulated. More-favourable terms and applicable collective agreements still matter. Actual German notification/sector/remuneration execution is not cleared here. [Directive96/71/EC,30July2020consolidation](https://publications.europa.eu/resource/cellar/68a991b1-7027-11ea-a07e-01aa75ed71a1.0006.03/DOC_1)

```json
{
  "figures": [
    "18",
    "96",
    "71",
    "1",
    "3",
    "12",
    "18"
  ],
  "id": 130,
  "kind": "source-cited rule and its explicit conditions",
  "line": 229,
  "operative_bindings": [
    {
      "locator": "Article3(1a)",
      "quote_id": "POSTED-091",
      "read_date": "2026-11-16",
      "source": "POSTED",
      "url": "https://publications.europa.eu/resource/cellar/68a991b1-7027-11ea-a07e-01aa75ed71a1.0006.03/DOC_1"
    },
    {
      "locator": "Article3(1a)",
      "quote_id": "POSTED-092",
      "read_date": "2026-11-16",
      "source": "POSTED",
      "url": "https://publications.europa.eu/resource/cellar/68a991b1-7027-11ea-a07e-01aa75ed71a1.0006.03/DOC_1"
    }
  ],
  "section": "Original case 4: Malta employer posts worker to Germany for 18 months",
  "source_keys": [
    "POSTED"
  ]
}
```

### 131

## Worked examples

```json
{
  "figures": [],
  "id": 131,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 231,
  "operative_bindings": [],
  "section": "Worked examples",
  "source_keys": []
}
```

### 132

### Example 1: preserve the original mid-vest arithmetic

```json
{
  "figures": [
    "1"
  ],
  "id": 132,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 233,
  "operative_bindings": [],
  "section": "Example 1: preserve the original mid-vest arithmetic",
  "source_keys": []
}
```

### 133

Original inputs: **1,000 RSUs**, a **4-year** vest, Germany in years **1–2**, UK in years **3–4**, total vest value **EUR 200,000**, and the original illustrative **730 / 1,460** allocation to each country. The supplied UK **GBP 85,000** result implies a hypothetical conversion of **GBP 0.85 per EUR 1**; it is not a sourced current FX rate.

```json
{
  "figures": [
    "1,000",
    "4",
    "1",
    "2",
    "3",
    "4",
    "200,000",
    "730",
    "1,460",
    "85,000",
    "0.85",
    "1"
  ],
  "id": 133,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 235,
  "operative_bindings": [],
  "section": "Example 1: preserve the original mid-vest arithmetic",
  "source_keys": []
}
```

### 134

Each half is **50%**, hence **EUR 100,000**; the UK illustration converts EUR 100,000 × 0.85 to **GBP 85,000**. These original calendar-day counts are preserved for arithmetic only. They are not verified actual workdays, a legal service period, a domestic taxing event, applicable tax rate or automatic foreign-tax credit. The actual award and both countries' rules must establish those points; the old conclusion that both automatically tax these exact amounts with full residence-country credit is withdrawn.

```json
{
  "figures": [
    "50%",
    "100,000",
    "100,000",
    "0.85",
    "85,000"
  ],
  "id": 134,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 237,
  "operative_bindings": [],
  "section": "Example 1: preserve the original mid-vest arithmetic",
  "source_keys": []
}
```

### 135

### Example 2: the telework boundary is strictly below 50%

```json
{
  "figures": [
    "2",
    "50%"
  ],
  "id": 135,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 255,
  "operative_bindings": [],
  "section": "Example 2: the telework boundary is strictly below 50%",
  "source_keys": []
}
```

### 136

Assume an employee, two eligible signatory states, all Framework conditions satisfied, a valid request and **200 total working days**. At **80 residence telework days**, the share is **40%**, within the Framework's numerical ceiling; at **100 days**, it is **50%**, outside. The first result proves only this numerical condition, not approval, scope or automatic continuation under employer-state law. [2023Framework Agreement on cross-border telework](https://socialsecurity.belgium.be/sites/default/files/content/docs/en/international/framework_agreement_on_cross-border_telework.pdf)

```json
{
  "figures": [
    "200",
    "80",
    "40%",
    "100",
    "50%"
  ],
  "id": 136,
  "kind": "source-cited rule and its explicit conditions",
  "line": 257,
  "operative_bindings": [
    {
      "locator": "Article2(1)",
      "quote_id": "FRAME-039",
      "read_date": "2026-11-16",
      "source": "FRAME",
      "url": "https://socialsecurity.belgium.be/sites/default/files/content/docs/en/international/framework_agreement_on_cross-border_telework.pdf"
    },
    {
      "locator": "Article3(1)",
      "quote_id": "FRAME-034",
      "read_date": "2026-11-16",
      "source": "FRAME",
      "url": "https://socialsecurity.belgium.be/sites/default/files/content/docs/en/international/framework_agreement_on_cross-border_telework.pdf"
    }
  ],
  "section": "Example 2: the telework boundary is strictly below 50%",
  "source_keys": [
    "FRAME"
  ]
}
```

### 137

## Ask the client first

```json
{
  "figures": [],
  "id": 137,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 273,
  "operative_bindings": [],
  "section": "Ask the client first",
  "source_keys": []
}
```

### 138

Before asking, inspect the available case record, prior advice, payroll/travel logs, contract/award documents and authority correspondence. Then request only missing facts: worker/employer identities and residence, locations/dates/work patterns, actual employment/control/recharges, assignment origin and intended end, prior coverage and replacements, certificates/approvals, cash/benefits/equity facts and the relevant policies. This is an information checklist, not a request to expose personal identifiers in public evidence.

```json
{
  "figures": [],
  "id": 138,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 275,
  "operative_bindings": [],
  "section": "Ask the client first",
  "source_keys": []
}
```

### 139

## Reviewer output and completion checklist

```json
{
  "figures": [],
  "id": 139,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 277,
  "operative_bindings": [],
  "section": "Reviewer output and completion checklist",
  "source_keys": []
}
```

### 140

Return a country-by-country decision with the actual rule/version and facts: tax allocation, collection/registration, social system and document, employment protection, PE/immigration review, equity timing/allocation/relief, dates, responsible party and unresolved non-usable items. Do not call the file implementation-ready while a required authority/condition remains missing.

```json
{
  "figures": [],
  "id": 140,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 279,
  "operative_bindings": [],
  "section": "Reviewer output and completion checklist",
  "source_keys": []
}
```

### 141

Preserve the seven original prohibitions with correct scope: (1) no automatic 183-day exemption; (2) no ignoring the relevant substantive-employer test; (3) no status determination from the contract label alone; (4) no skipping competent social-security determination/documentation, while missing A1 alone does not change applicable law; (5) no assumption that all equity is taxed only at vesting residence; (6) no unassessed overseas remote arrangement; (7) no ignoring mandatory host employment protections. These are review controls, not seven new independent legal exemptions.

```json
{
  "figures": [
    "1",
    "183",
    "2",
    "3",
    "4",
    "5",
    "6",
    "7"
  ],
  "id": 141,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 281,
  "operative_bindings": [],
  "section": "Reviewer output and completion checklist",
  "source_keys": []
}
```

### 142

### Disclaimer

```json
{
  "figures": [],
  "id": 142,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 283,
  "operative_bindings": [],
  "section": "Disclaimer",
  "source_keys": []
}
```

### 143

Informational and computational material only; not tax, legal or financial advice. A qualified professional must review the actual facts and current applicable instruments before implementation. OpenAccountants and contributors do not approve a live payroll, return, certificate application or filing through this Guide. Contact: info@openaccountants.com.

```json
{
  "figures": [],
  "id": 143,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 285,
  "operative_bindings": [],
  "section": "Disclaimer",
  "source_keys": []
}
```

### 144

## Sources

```json
{
  "figures": [],
  "id": 144,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 287,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 145

Official operative scopes were actually read on **16 November 2026**, with the limits below. This is research verification only, not an accountant approval. Prior completed primary-source research is reused only within its unchanged scope; new EU application dates and the payroll-specific sources were read directly. No successful download, RDF metadata response, error page or blocked URL is represented as a source read.

```json
{
  "figures": [
    "16",
    "2026"
  ],
  "id": 145,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 289,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 146

| Official source | Actually read scope and limits | Read on |

```json
{
  "figures": [],
  "id": 146,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 291,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 147

| [OECD Model 2025, employment article and Commentary](https://www.oecd.org/content/dam/oecd/en/publications/reports/2026/06/model-tax-convention-on-income-and-on-capital-2025-full-version_4fd97b89/db32e18b-en.pdf) | Read for Article15; Commentary4–6.2 and8.1–8.15. Completed primary Model research reused; payroll-specific employer/recharge paragraphs actually read16November. Model only, not a national treaty. | 2026-11-16 |

```json
{
  "figures": [
    "2025",
    "5",
    "6.2",
    "1",
    "8.15",
    "2026",
    "11",
    "16"
  ],
  "id": 147,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 293,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 148

| [UK–Germany treaty, consolidated after2021Protocol](https://www.gov.uk/government/publications/germany-tax-treaties/2010-uk-germany-double-taxation-convention-as-amended-by-the-2021-protocol-in-force) | Read for Articles5(1)–(8),14(1)–(3),23(2)(a). Actual complete used PE/employment clauses and UKcredit branch read. No claim to German-resident relief or all domestic collection rules. | 2026-11-16 |

```json
{
  "figures": [
    "1",
    "8",
    "14",
    "1",
    "3",
    "23",
    "2",
    "2026",
    "11",
    "16"
  ],
  "id": 148,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 294,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 149

| [Regulation883/2004,31July2019consolidation](https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1) | Read for Articles2–3,11–16; current application checked against2026/2359. Completed full scoped primary/independent social review reused; payroll posting/multistate scopes also read directly. Historical source expressly overlaid, not silently treated as current full consolidation. | 2026-11-16 |

```json
{
  "figures": [
    "83",
    "2004,",
    "3,11",
    "16",
    "026",
    "2359",
    "2026",
    "11",
    "16"
  ],
  "id": 149,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 295,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 150

| [Regulation987/2009,1January2018consolidation](https://publications.europa.eu/resource/cellar/00185d05-a69f-4055-8a8e-341c14c29d50.0020.02/DOC_1) | Read for Articles5,14–16,19–21 with current19(2)/(3)overlay. Actual scoped reads and completed prior independent review reused; no flightcrew old-homebase instruction imported. | 2026-11-16 |

```json
{
  "figures": [
    "87",
    "2009,",
    "14",
    "16,19",
    "21",
    "9",
    "2",
    "3",
    "2026",
    "11",
    "16"
  ],
  "id": 150,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 296,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 151

| [Regulation(EU)2026/2359, enacted English body](https://publications.europa.eu/resource/cellar/5794f71b-d1a7-11f1-9458-01aa75ed71a1.0006.03/DOC_1) | Read for Article1(8),(13)–(15),(36),(39); Article2(13),(52); Article3. Actual application/transition and attestation scopes read; complete15Nov independent instrument review reused once, no repeat whole scan. Earlier RDF response is not this operative body. | 2026-11-16 |

```json
{
  "figures": [
    "2026",
    "2359",
    "8",
    "13",
    "15",
    "36",
    "39",
    "13",
    "52",
    "2026",
    "11",
    "16"
  ],
  "id": 151,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 297,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 152

| [2023Framework Agreement on cross-border telework](https://socialsecurity.belgium.be/sites/default/files/content/docs/en/international/framework_agreement_on_cross-border_telework.pdf) | Read for Wholepreamble andArticles1–6,including scope,request/retroactivity/term. Actual complete shortinstrument read. Current named-state eligibility not inferred; hypothetical pair only. | 2026-11-16 |

```json
{
  "figures": [
    "6,",
    "2026",
    "11",
    "16"
  ],
  "id": 152,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 298,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 153

| [UK-retained RomeI Article8](https://www.legislation.gov.uk/eur/2008/593/article/8/data.html) | Read for Article8(1)–(4)infull. Actual UK-hosted retained text read; not a worldwide conflict rule. | 2026-11-16 |

```json
{
  "figures": [
    "1",
    "4",
    "2026",
    "11",
    "16"
  ],
  "id": 153,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 299,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 154

| [HMRC PAYE82000, short-term visitors](https://www.gov.uk/hmrc-internal-manuals/paye-manual/paye82000) | Read for Opening operative conditions68–89. Actual conditions read; no unread reporting-tier dates or current employer approval claimed. | 2026-11-16 |

```json
{
  "figures": [
    "2000",
    "8",
    "89",
    "2026",
    "11",
    "16"
  ],
  "id": 154,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 300,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 155

| [HMRC2026 helpsheetHS212](https://www.gov.uk/government/publications/tax-equalisation-hs212-self-assessment-helpsheet/tax-equalisation-2026-hs212) | Read for Section1 definition,including contractualscope90. Actual definition and neighboring introductory paragraphs read; no universal private-policy promises. | 2026-11-16 |

```json
{
  "figures": [
    "026",
    "12",
    "0",
    "2026",
    "11",
    "16"
  ],
  "id": 155,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 301,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 156

| [HMRC NIM02380](https://www.gov.uk/hmrc-internal-manuals/national-insurance-manual/nim02380) | Read for Wholemain67–70. Actual mainbody read:employer-paidtax includedin Class1grosspay. | 2026-11-16 |

```json
{
  "figures": [
    "2380",
    "7",
    "70",
    "2026",
    "11",
    "16"
  ],
  "id": 156,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 302,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 157

| [SSA agreements-in-force register](https://www.ssa.gov/international/status.html) | Read for Germany,France,Italy,Japan,Portugal,UKrows andUKstagednote. Actual official web register read,not proof of each agreement’s complete scope. | 2026-11-16 |

```json
{
  "figures": [
    "2026",
    "11",
    "16"
  ],
  "id": 157,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 303,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 158

| [US–Portugal SocialSecurityAgreement](https://www.ssa.gov/international/Agreement_Texts/portugal.html) | Read for Articles1–8,inparticular materialscope2 andcoverage4–7;effectivedate. Actual official web legalbody read. No whole628line page/adminarrangementread claimed. | 2026-11-16 |

```json
{
  "figures": [
    "8,",
    "7",
    "2026",
    "11",
    "16"
  ],
  "id": 158,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 304,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 159

| [IRS employee/contractor classification](https://www.irs.gov/businesses/small-businesses-self-employed/independent-contractor-self-employed-or-employee) | Read for Mainbody260–285:threecontrolgroups andremote-worker paragraph. Actual used operative mainbody read; not state employmentlaw clearance. | 2026-11-16 |

```json
{
  "figures": [
    "60",
    "285",
    "2026",
    "11",
    "16"
  ],
  "id": 159,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 305,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 160

| [CaliforniaDIR employee/contractor guidance](https://www.dir.ca.gov/dlse/FAQ_IndependentContractor.htm) | Read for Questions1–4,9–10;exceptions scope,allABClimbs,willfulpenaltysummary. Actual operative guidance read; no claim to all industryexceptions or the blocked226.8operativebody. | 2026-11-16 |

```json
{
  "figures": [
    "4,9",
    "10",
    "26.",
    "2026",
    "11",
    "16"
  ],
  "id": 160,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 306,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 161

| [HMRC ESM10025, international off-payroll](https://www.gov.uk/hmrc-internal-manuals/employment-status-manual/esm10025) | Read for Main68–95:overseasclient/intermediary/workercharge. Actual whole used mainparagraphs read. No automatic overseasworker exception. | 2026-11-16 |

```json
{
  "figures": [
    "0025",
    "8",
    "95",
    "2026",
    "11",
    "16"
  ],
  "id": 161,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 307,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 162

| [Germany SGBIV section7](https://www.gesetze-im-internet.de/sgb_4/__7.html) | Read for Section7whole,especially(1). Actual German statutorybody read,not translatedsecondarysummary. | 2026-11-16 |

```json
{
  "figures": [
    "1",
    "2026",
    "11",
    "16"
  ],
  "id": 162,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 308,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 163

| [Germany SGBVI section2](https://www.gesetze-im-internet.de/sgb_6/__2.html) | Read for WholeSection2,especially9(a)/(b). Actual nativebody read;self-employedpensioncoverage distinguishedfromemployment. | 2026-11-16 |

```json
{
  "figures": [
    "2026",
    "11",
    "16"
  ],
  "id": 163,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 309,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 164

| [France L8221-6,28May2026version](https://www.legifrance.gouv.fr/codes/section_lc/LEGITEXT000006072050/LEGISCTA000006178267/2026-05-28) | Read for WholeL8221-6 I/II andneighborL8221-6-1. Actual official datedlegalwebbody read;directcurrentdatepath403,not currentpenaltyclearance. | 2026-11-16 |

```json
{
  "figures": [
    "221",
    "6,",
    "221",
    "6",
    "221",
    "6",
    "1",
    "03,",
    "2026",
    "11",
    "16"
  ],
  "id": 164,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 310,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 165

| [Belastingdienst, current labour-relation enforcement](https://www.belastingdienst.nl/wps/wcm/connect/nl/arbeidsrelaties/content/handhaving) | Read for Wholeoperativebody19–end. Actual Dutchmainbodyread;2026partialsoftlanding controlsoldergenericstatements. | 2026-11-16 |

```json
{
  "figures": [
    "9",
    "2026",
    "11",
    "16"
  ],
  "id": 165,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 311,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 166

| [Spain Estatuto de los Trabajadores](https://www.boe.es/buscar/act.php?id=BOE-A-2015-11430) | Read for Articles1–3:scope/exclusions/specialrelationships/mandatorysources. Actual completeusednativeclauses read;notbenefitlimitationorallretroactivityclearance. | 2026-11-16 |

```json
{
  "figures": [
    "3",
    "2026",
    "11",
    "16"
  ],
  "id": 166,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 312,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 167

| [FWO whole-of-relationship test](https://www.fairwork.gov.au/find-help-for/independent-contractors/whole-of-relationship-test) | Read for Main439–514:businessscope,startdate,optout,allfactors. Actual officialwebbody read;directrequesttimeoutnot calledsourceclearance. | 2026-11-16 |

```json
{
  "figures": [
    "39",
    "514",
    "2026",
    "11",
    "16"
  ],
  "id": 167,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 313,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 168

| [FWO sham contracting](https://www.fairwork.gov.au/find-help-for/independent-contractors/sham-contracting) | Read for Main446–464:prohibitedconduct,reasonablebelief,penaltysummary. Actual officialwebbodyread. Exact15employeesgapinwordingnotresolved,old469500notcurrentmax. | 2026-11-16 |

```json
{
  "figures": [
    "46",
    "464",
    "2026",
    "11",
    "16"
  ],
  "id": 168,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 314,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 169

| [IRS Topic427, stockoptions](https://www.irs.gov/taxtopics/tc427) | Read for Main250–262:statutory/nonstatutoryevents,AMT,disposition. Actual wholeusedbody read,updated24September2026. NotRSUclearance. | 2026-11-16 |

```json
{
  "figures": [
    "27",
    "50",
    "262",
    "026",
    "2026",
    "11",
    "16"
  ],
  "id": 169,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 315,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 170

| [Germany SGBIV section25](https://www.gesetze-im-internet.de/sgb_4/__25.html) | Read for Section25whole,including tolling/extension. Actual nativecompletebodyread;notcriminal/fineprovision. | 2026-11-16 |

```json
{
  "figures": [
    "5",
    "2026",
    "11",
    "16"
  ],
  "id": 170,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 316,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 171

| [USCode2024,26USC3509](https://www.govinfo.gov/content/pkg/USCODE-2024-title26/html/USCODE-2024-title26-subtitleC-chap25-sec3509.htm) | Read for Whole(a)–(d),amendment/effectivenotes. Actual valid2024statutecapture,editionexplicit;2025soft404notused. CurrentIRMcorroboratesusedstructure. | 2026-11-16 |

```json
{
  "figures": [
    "024,",
    "509",
    "2026",
    "11",
    "16"
  ],
  "id": 171,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 317,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 172

| [IRS IRM4.23.8.5](https://www.irs.gov/irm/part4/irm_04-023-008) | Read for 4.23.8.5–.5.2,completeusedrules/exclusions;685–749. Actual usedoperativeparagraphs read;no new generalizedpenaltytariff. | 2026-11-16 |

```json
{
  "figures": [
    "23.8.5",
    "4.23.8.5",
    "5.2,",
    "685",
    "749",
    "2026",
    "11",
    "16"
  ],
  "id": 172,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 318,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 173

| [Directive(EU)2024/2831](https://publications.europa.eu/resource/cellar/564844cf-9fd2-11ef-85f0-01aa75ed71a1.0006.03/DOC_1) | Read for Articles4–5,29–31. Actual fullusedlegalclausesread. InitialCELEXRDFnotbody;no nationaltranspositioninferred. | 2026-11-16 |

```json
{
  "figures": [
    "2024",
    "2831",
    "5,29",
    "31",
    "2026",
    "11",
    "16"
  ],
  "id": 173,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 319,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 174

| [Directive96/71/EC,30July2020consolidation](https://publications.europa.eu/resource/cellar/68a991b1-7027-11ea-a07e-01aa75ed71a1.0006.03/DOC_1) | Read for Articles1–3infull. Actual wholeusedlegalclausesreadincluding exceptions/remuneration/replacements/collectiveagreements. NotGermanexecutionclearance. | 2026-11-16 |

```json
{
  "figures": [
    "6",
    "71",
    "2026",
    "11",
    "16"
  ],
  "id": 174,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 320,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 175

| [UK–EU TCA Protocol](https://assets.publishing.service.gov.uk/media/608ae0c0d3bf7f0136332887/TS_8.2021_UK_EU_EAEC_Trade_and_Cooperation_Agreement.pdf) | Read for Official UK treaty publication of TCA: cover; Articles 489–490 and 783; SSC.2–3, 10–14, 17–18, 21–27, 56–58, 68–71; Annex SSC-7 SSCI.13–17 and opening SSCI.18(1). No blanket reading claim for the full treaty or every benefit annex.. Actual completed15Nov primary/independentreview reused unchanged;16Nov boundedapplicabilitycheck. EUamendmentnotimportedintoTCA. | 2026-11-15 |

```json
{
  "figures": [
    "489",
    "490",
    "783",
    "2",
    "3",
    "10",
    "14",
    "17",
    "18",
    "21",
    "27",
    "56",
    "58",
    "68",
    "71",
    "7",
    "13",
    "17",
    "18",
    "1",
    "2026",
    "11",
    "15"
  ],
  "id": 175,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 321,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 176

| [UK–EU Decision1/2021,AnnexSSC8](https://assets.publishing.service.gov.uk/media/61a5f3ebe90e07043c35f448/TS_21.2021_Decision_No_1.2021_Specialised_Committee_Social_Security.pdf) | Read for Decision 1/2021: cover, recitals, Articles 1–2 and complete Annex II replacement SSC-8 list; benefit-specific Annex I entries not relied on.. Actual completed15Nov primary/independentreview reused unchanged;16Nov boundedapplicabilitycheck. EUamendmentnotimportedintoTCA. | 2026-11-15 |

```json
{
  "figures": [
    "2021,",
    "1",
    "2021",
    "1",
    "2",
    "8",
    "2026",
    "11",
    "15"
  ],
  "id": 176,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 322,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 177

Individually **not yet confirmed and non-usable**: current EOR employee-count/fee/licensing claims; exact foreign-employer registration/withholding procedures in unlisted states; the former national economic-employer list for Germany/Sweden/Denmark/Norway/Finland/UK/Australia/India/Singapore as a uniform adoption claim; actual case-specific UK–Germany TCA coverage and national certificate routing; Australia's current “30+” agreement count and each agreement's scope; Indian agreements with Germany/France/Belgium/Netherlands and current domestic classification/labour-code/withholding/GST execution; French current penalty amounts/person/offence/recidivism; German EUR 500,000/§266a criminal claims; UK/Spain specific penalty and benefit limitation outcomes; Australia's old AUD 469,500 ceiling, exact-15 employee size branch, superannuation and six-year leave recovery; all original UK/German/French/Indian/Australian equity event/rate/relief rows and US RSU event; actual Germany–UK RSU workday/vesting/event/credit outcome and lawful FX conversion; US–Portugal PE and Portuguese payroll/employment execution; Malta–Germany tax treaty and German posted-worker notification/sector pay execution. Do not use these as current rules or pass them through a calculator. Failed ordinary retrievals, historical manual boundaries and the narrow reasons are retained in the private evidence register.

```json
{
  "figures": [
    "30",
    "500,000",
    "469,500",
    "15"
  ],
  "id": 177,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 324,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

### 178

The **USD 300–700** EOR range and **1–10** employee recommendation, **83%** German pension shorthand, **more-than-six-month** PE trigger, **EUR 45,000 / EUR 500,000 / AUD 469,500** blanket penalties, and **six years** of automatic leave remain here solely to identify superseded/unverified assertions. They do not supply a usable threshold or tariff. The original “20% of wages” federal computation and “no US–Portugal agreement” were affirmatively corrected, not put back into service through this reservation.

```json
{
  "figures": [
    "300",
    "700",
    "1",
    "10",
    "83%",
    "45,000",
    "500,000",
    "469,500",
    "20%"
  ],
  "id": 178,
  "kind": "heading/internal control/supplied case input/arithmetic or explicit non-usable reservation",
  "line": 326,
  "operative_bindings": [],
  "section": "Sources",
  "source_keys": []
}
```

## Short exact native registry

```json
{
  "AU-068": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "26 August 2024"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.fairwork.gov.au/find-help-for/independent-contractors/whole-of-relationship-test",
    "operative_locator": "Whousesthistest",
    "source_key": "AU",
    "terms": "2024 date"
  },
  "AU-069": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "all parts of the relationship"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.fairwork.gov.au/find-help-for/independent-contractors/whole-of-relationship-test",
    "operative_locator": "Howthetestworks",
    "source_key": "AU",
    "terms": "contract practical relationship"
  },
  "AU-070": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "opted out"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.fairwork.gov.au/find-help-for/independent-contractors/whole-of-relationship-test",
    "operative_locator": "Startofrelationshiptest",
    "source_key": "AU",
    "terms": "optout exceptions"
  },
  "AUSHAM-071": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "reasonably believed"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.fairwork.gov.au/find-help-for/independent-contractors/sham-contracting",
    "operative_locator": "Understandingcontracting",
    "source_key": "AUSHAM",
    "terms": "defense reasonable belief"
  },
  "AUSHAM-072": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "maximum penalties"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.fairwork.gov.au/find-help-for/independent-contractors/sham-contracting",
    "operative_locator": "Penaltyparagraph",
    "source_key": "AUSHAM",
    "terms": "penalties sizes"
  },
  "CA-054": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "all three of the following conditions"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.dir.ca.gov/dlse/FAQ_IndependentContractor.htm",
    "operative_locator": "Question1fullABClimbs",
    "source_key": "CA",
    "terms": "ABC all three"
  },
  "CA-055": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "does not determine employment status"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.dir.ca.gov/dlse/FAQ_IndependentContractor.htm",
    "operative_locator": "Question9",
    "source_key": "CA",
    "terms": "label contract"
  },
  "CA-056": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "between $5,000 and $25,000"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.dir.ca.gov/dlse/FAQ_IndependentContractor.htm",
    "operative_locator": "Question10willfulmisclassification",
    "source_key": "CA",
    "terms": "penalty willful"
  },
  "DELIMIT-076": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "vier Jahren nach Ablauf des Kalenderjahrs"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.gesetze-im-internet.de/sgb_4/__25.html",
    "operative_locator": "Section25(1)sentence1",
    "source_key": "DELIMIT",
    "terms": "4 years calendar"
  },
  "DELIMIT-077": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "dreißig Jahren"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.gesetze-im-internet.de/sgb_4/__25.html",
    "operative_locator": "Section25(1)sentence2",
    "source_key": "DELIMIT",
    "terms": "30 intentional"
  },
  "DEPENSION-060": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "regelmäßig keinen versicherungspflichtigen Arbeitnehmer beschäftigen"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.gesetze-im-internet.de/sgb_6/__2.html",
    "operative_locator": "SGBVI2sentence1number9(a)",
    "source_key": "DEPENSION",
    "terms": "employee pension"
  },
  "DEPENSION-061": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "auf Dauer und im Wesentlichen nur für einen Auftraggeber"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.gesetze-im-internet.de/sgb_6/__2.html",
    "operative_locator": "SGBVI2sentence1number9(b)",
    "source_key": "DEPENSION",
    "terms": "one client pension83"
  },
  "DESTATUS-059": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "Tätigkeit nach Weisungen und eine Eingliederung"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.gesetze-im-internet.de/sgb_4/__7.html",
    "operative_locator": "SGBIV7(1)",
    "source_key": "DESTATUS",
    "terms": "instructions integration"
  },
  "ES-067": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "servicios retribuidos por cuenta ajena"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.boe.es/buscar/act.php?id=BOE-A-2015-11430",
    "operative_locator": "Article1(1)",
    "source_key": "ES",
    "terms": "remuneration direction employment"
  },
  "EU2026-028": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "2 November 2028"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://publications.europa.eu/resource/cellar/5794f71b-d1a7-11f1-9458-01aa75ed71a1.0006.03/DOC_1",
    "operative_locator": "Article1(39)/Article2(52),applicationlists",
    "source_key": "EU2026",
    "terms": "2028 future posting notification business"
  },
  "EU2026-029": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "1 November 2026"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://publications.europa.eu/resource/cellar/5794f71b-d1a7-11f1-9458-01aa75ed71a1.0006.03/DOC_1",
    "operative_locator": "Article1(39)/Article2(52),immediatelist",
    "source_key": "EU2026",
    "terms": "2026 entry November"
  },
  "EU2026-030": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "standardised format"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://publications.europa.eu/resource/cellar/5794f71b-d1a7-11f1-9458-01aa75ed71a1.0006.03/DOC_1",
    "operative_locator": "Article2(13)(a),new19(2)",
    "source_key": "EU2026",
    "terms": "attestation format request"
  },
  "EU2026-031": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "proper assessment of the facts"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://publications.europa.eu/resource/cellar/5794f71b-d1a7-11f1-9458-01aa75ed71a1.0006.03/DOC_1",
    "operative_locator": "Article2(13)(b),new19(3)",
    "source_key": "EU2026",
    "terms": "assessment facts correct"
  },
  "EU2026-032": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "2 November 2036"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://publications.europa.eu/resource/cellar/5794f71b-d1a7-11f1-9458-01aa75ed71a1.0006.03/DOC_1",
    "operative_locator": "Article1(36),new87b(4)",
    "source_key": "EU2026",
    "terms": "transition 2036 unchanged"
  },
  "EU2026-033": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "does not automatically result"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://publications.europa.eu/resource/cellar/5794f71b-d1a7-11f1-9458-01aa75ed71a1.0006.03/DOC_1",
    "operative_locator": "Article1(8),newrecital40b",
    "source_key": "EU2026",
    "terms": "missing A1 automatically applicable law"
  },
  "EU883-013": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "legislation of a single Member State only"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1",
    "operative_locator": "Article11(1)",
    "source_key": "EU883",
    "terms": "single system ordinary work state"
  },
  "EU883-014": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "does not exceed 24 months"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1",
    "operative_locator": "Article12(1)/(2)",
    "source_key": "EU883",
    "terms": "posting posted Malta 18 24 temporary"
  },
  "EU883-015": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "replace another posted person"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1",
    "operative_locator": "Article12(1)",
    "source_key": "EU883",
    "terms": "replacement employer sending"
  },
  "EU883-016": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "similar activity"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1",
    "operative_locator": "Article12(2)",
    "source_key": "EU883",
    "terms": "self employed similar prior"
  },
  "EU883-017": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "substantial part"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1",
    "operative_locator": "Article13(1)/(2)",
    "source_key": "EU883",
    "terms": "multistate residence substantial"
  },
  "EU883-018": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "two or more undertakings or"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1",
    "operative_locator": "Article13(1)(b)",
    "source_key": "EU883",
    "terms": "employers two branches"
  },
  "EU883-019": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1",
    "operative_locator": "Article16(1)",
    "source_key": "EU883",
    "terms": "exceptions renewal mutual"
  },
  "EU883-020": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://publications.europa.eu/resource/cellar/296c9322-ca95-11e9-992f-01aa75ed71a1.0007.03/DOC_1",
    "operative_locator": "Article2",
    "source_key": "EU883",
    "terms": "personal material scope"
  },
  "EU987-021": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "for as long as they have not been withdrawn"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://publications.europa.eu/resource/cellar/00185d05-a69f-4055-8a8e-341c14c29d50.0020.02/DOC_1",
    "operative_locator": "Article5(1)",
    "source_key": "EU987",
    "terms": "accept document withdrawal A1 binding"
  },
  "EU987-022": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "substantial activities, other than purely internal management activities"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://publications.europa.eu/resource/cellar/00185d05-a69f-4055-8a8e-341c14c29d50.0020.02/DOC_1",
    "operative_locator": "Article14(2)",
    "source_key": "EU987",
    "terms": "employer normal posting activities"
  },
  "EU987-023": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "a share of less than 25 %"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://publications.europa.eu/resource/cellar/00185d05-a69f-4055-8a8e-341c14c29d50.0020.02/DOC_1",
    "operative_locator": "Article14(8)",
    "source_key": "EU987",
    "terms": "25 indicator substantial"
  },
  "EU987-024": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "following"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://publications.europa.eu/resource/cellar/00185d05-a69f-4055-8a8e-341c14c29d50.0020.02/DOC_1",
    "operative_locator": "Article14(10)",
    "source_key": "EU987",
    "terms": "12 projected criteria"
  },
  "EU987-025": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://publications.europa.eu/resource/cellar/00185d05-a69f-4055-8a8e-341c14c29d50.0020.02/DOC_1",
    "operative_locator": "Article15(1)",
    "source_key": "EU987",
    "terms": "notification advance posting"
  },
  "EU987-026": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://publications.europa.eu/resource/cellar/00185d05-a69f-4055-8a8e-341c14c29d50.0020.02/DOC_1",
    "operative_locator": "Article16(1)",
    "source_key": "EU987",
    "terms": "multistate residence institution provisional"
  },
  "EU987-027": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://publications.europa.eu/resource/cellar/00185d05-a69f-4055-8a8e-341c14c29d50.0020.02/DOC_1",
    "operative_locator": "Article21(1)",
    "source_key": "EU987",
    "terms": "foreign employer obligations payment"
  },
  "FR-062": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "lien de subordination juridique permanente"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.legifrance.gouv.fr/codes/section_lc/LEGITEXT000006072050/LEGISCTA000006178267/2026-05-28",
    "operative_locator": "L8221-6II",
    "source_key": "FR",
    "terms": "subordination"
  },
  "FR-063": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "s'est soustrait intentionnellement"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.legifrance.gouv.fr/codes/section_lc/LEGITEXT000006072050/LEGISCTA000006178267/2026-05-28",
    "operative_locator": "L8221-6II",
    "source_key": "FR",
    "terms": "intentional penalty"
  },
  "FRAME-034": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "less than 50%"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://socialsecurity.belgium.be/sites/default/files/content/docs/en/international/framework_agreement_on_cross-border_telework.pdf",
    "operative_locator": "Article3(1)",
    "source_key": "FRAME",
    "terms": "50 threshold ceiling numerical"
  },
  "FRAME-035": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "Upon request"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://socialsecurity.belgium.be/sites/default/files/content/docs/en/international/framework_agreement_on_cross-border_telework.pdf",
    "operative_locator": "Article3(1)",
    "source_key": "FRAME",
    "terms": "request not automatic"
  },
  "FRAME-036": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "does not exceed three"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://socialsecurity.belgium.be/sites/default/files/content/docs/en/international/framework_agreement_on_cross-border_telework.pdf",
    "operative_locator": "Article4(2)(b)(i)",
    "source_key": "FRAME",
    "terms": "retroactive 3 months"
  },
  "FRAME-037": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "no later than 30 June 2024"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://socialsecurity.belgium.be/sites/default/files/content/docs/en/international/framework_agreement_on_cross-border_telework.pdf",
    "operative_locator": "Article4(2)(b)(ii)",
    "source_key": "FRAME",
    "terms": "2024 expired 12"
  },
  "FRAME-038": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "maximum of 3 years"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://socialsecurity.belgium.be/sites/default/files/content/docs/en/international/framework_agreement_on_cross-border_telework.pdf",
    "operative_locator": "Article4(3)",
    "source_key": "FRAME",
    "terms": "3 years term extension"
  },
  "FRAME-039": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "signatory State"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://socialsecurity.belgium.be/sites/default/files/content/docs/en/international/framework_agreement_on_cross-border_telework.pdf",
    "operative_locator": "Article2(1)",
    "source_key": "FRAME",
    "terms": "scope signatory employers residence self"
  },
  "MODEL-001": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "unless the employment is exercised"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.oecd.org/content/dam/oecd/en/publications/reports/2026/06/model-tax-convention-on-income-and-on-capital-2025-full-version_4fd97b89/db32e18b-en.pdf",
    "operative_locator": "Article15(1)",
    "source_key": "MODEL",
    "terms": "employment allocation taxing rights remuneration"
  },
  "MODEL-002": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "183 days"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.oecd.org/content/dam/oecd/en/publications/reports/2026/06/model-tax-convention-on-income-and-on-capital-2025-full-version_4fd97b89/db32e18b-en.pdf",
    "operative_locator": "Article15(2)(a)",
    "source_key": "MODEL",
    "terms": "183 period twelve days limit failure"
  },
  "MODEL-003": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "physical presence"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.oecd.org/content/dam/oecd/en/publications/reports/2026/06/model-tax-convention-on-income-and-on-capital-2025-full-version_4fd97b89/db32e18b-en.pdf",
    "operative_locator": "Commentary15paragraph5/5.1",
    "source_key": "MODEL",
    "terms": "physical presence sickness transit counting residence"
  },
  "MODEL-004": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "not necessarily conclusive"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.oecd.org/content/dam/oecd/en/publications/reports/2026/06/model-tax-convention-on-income-and-on-capital-2025-full-version_4fd97b89/db32e18b-en.pdf",
    "operative_locator": "Commentary15paragraph8.15",
    "source_key": "MODEL",
    "terms": "recharge subsidiary cost conclusive service fee"
  },
  "MODEL-005": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "integral part of the business"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.oecd.org/content/dam/oecd/en/publications/reports/2026/06/model-tax-convention-on-income-and-on-capital-2025-full-version_4fd97b89/db32e18b-en.pdf",
    "operative_locator": "Commentary15paragraph8.13",
    "source_key": "MODEL",
    "terms": "employer integral risk responsibility control"
  },
  "MODEL-006": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "not borne by a permanent establishment"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.oecd.org/content/dam/oecd/en/publications/reports/2026/06/model-tax-convention-on-income-and-on-capital-2025-full-version_4fd97b89/db32e18b-en.pdf",
    "operative_locator": "Article15(2)(c)",
    "source_key": "MODEL",
    "terms": "PE borne limb all three conditions"
  },
  "NL-064": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "geen verzuimboetes"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.belastingdienst.nl/wps/wcm/connect/nl/arbeidsrelaties/content/handhaving",
    "operative_locator": "Currentenforcementmain2026paragraph",
    "source_key": "NL",
    "terms": "2026 default"
  },
  "NL-065": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "vergrijpboetes opleggen"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.belastingdienst.nl/wps/wcm/connect/nl/arbeidsrelaties/content/handhaving",
    "operative_locator": "Currentenforcementmain2026paragraph",
    "source_key": "NL",
    "terms": "culpability"
  },
  "NL-066": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "1 januari 2025"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.belastingdienst.nl/wps/wcm/connect/nl/arbeidsrelaties/content/handhaving",
    "operative_locator": "Mainretroactivitysection",
    "source_key": "NL",
    "terms": "2025 assessments"
  },
  "PLATFORM-085": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "facts indicating direction and control"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://publications.europa.eu/resource/cellar/564844cf-9fd2-11ef-85f0-01aa75ed71a1.0006.03/DOC_1",
    "operative_locator": "Article5(1)",
    "source_key": "PLATFORM",
    "terms": "presumption control"
  },
  "PLATFORM-086": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "as a matter of national law"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://publications.europa.eu/resource/cellar/564844cf-9fd2-11ef-85f0-01aa75ed71a1.0006.03/DOC_1",
    "operative_locator": "Article5(3)",
    "source_key": "PLATFORM",
    "terms": "tax criminal social"
  },
  "PLATFORM-087": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "2 December 2026"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://publications.europa.eu/resource/cellar/564844cf-9fd2-11ef-85f0-01aa75ed71a1.0006.03/DOC_1",
    "operative_locator": "Articles5(6)/29(1)",
    "source_key": "PLATFORM",
    "terms": "2026 transposition prospective"
  },
  "PLATFORM-088": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "twentieth day"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://publications.europa.eu/resource/cellar/564844cf-9fd2-11ef-85f0-01aa75ed71a1.0006.03/DOC_1",
    "operative_locator": "Article31",
    "source_key": "PLATFORM",
    "terms": "2024 entry"
  },
  "POSTED-089": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "transnational provision of services"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://publications.europa.eu/resource/cellar/68a991b1-7027-11ea-a07e-01aa75ed71a1.0006.03/DOC_1",
    "operative_locator": "Article1(1)/(3)",
    "source_key": "POSTED",
    "terms": "scope"
  },
  "POSTED-090": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "remuneration, including overtime rates"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://publications.europa.eu/resource/cellar/68a991b1-7027-11ea-a07e-01aa75ed71a1.0006.03/DOC_1",
    "operative_locator": "Article3(1)(c)",
    "source_key": "POSTED",
    "terms": "remuneration core conditions"
  },
  "POSTED-091": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "exceeds 12 months"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://publications.europa.eu/resource/cellar/68a991b1-7027-11ea-a07e-01aa75ed71a1.0006.03/DOC_1",
    "operative_locator": "Article3(1a)",
    "source_key": "POSTED",
    "terms": "12 expanded"
  },
  "POSTED-092": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "extend the period"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://publications.europa.eu/resource/cellar/68a991b1-7027-11ea-a07e-01aa75ed71a1.0006.03/DOC_1",
    "operative_locator": "Article3(1a)",
    "source_key": "POSTED",
    "terms": "18 notification"
  },
  "POSTED-093": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "cumulative duration"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://publications.europa.eu/resource/cellar/68a991b1-7027-11ea-a07e-01aa75ed71a1.0006.03/DOC_1",
    "operative_locator": "Article3(1a)",
    "source_key": "POSTED",
    "terms": "replacement same task"
  },
  "POSTED-094": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "more favourable to workers"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://publications.europa.eu/resource/cellar/68a991b1-7027-11ea-a07e-01aa75ed71a1.0006.03/DOC_1",
    "operative_locator": "Article3(7)",
    "source_key": "POSTED",
    "terms": "favourable"
  },
  "ROME-040": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "may not, however, have the result of depriving the employee"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.legislation.gov.uk/eur/2008/593/article/8/data.html",
    "operative_locator": "Article8(1)",
    "source_key": "ROME",
    "terms": "choice protection"
  },
  "ROME-041": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "shall not be deemed to have changed"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.legislation.gov.uk/eur/2008/593/article/8/data.html",
    "operative_locator": "Article8(2)",
    "source_key": "ROME",
    "terms": "habitual temporary"
  },
  "SSALIST-046": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "Agreement on Social Security"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.ssa.gov/international/status.html",
    "operative_locator": "Officialcurrentregister,usedcountryrows",
    "source_key": "SSALIST",
    "terms": "agreement countries list"
  },
  "SSALIST-047": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "Aug. 1, 1989"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.ssa.gov/international/status.html",
    "operative_locator": "Portugalrow",
    "source_key": "SSALIST",
    "terms": "Portugal"
  },
  "TAXEQ-043": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "specified net cash earnings"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.gov.uk/government/publications/tax-equalisation-hs212-self-assessment-helpsheet/tax-equalisation-2026-hs212",
    "operative_locator": "HS212section1definition",
    "source_key": "TAXEQ",
    "terms": "contract equalisation net"
  },
  "TAXEQ-044": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "meet UK Income Tax"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.gov.uk/government/publications/tax-equalisation-hs212-self-assessment-helpsheet/tax-equalisation-2026-hs212",
    "operative_locator": "HS212section1definition",
    "source_key": "TAXEQ",
    "terms": "tax costs actual"
  },
  "TAXEQNIC-045": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "included in the employee’s gross pay"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.gov.uk/hmrc-internal-manuals/national-insurance-manual/nim02380",
    "operative_locator": "NIM02380thirdparagraph",
    "source_key": "TAXEQNIC",
    "terms": "gross up NIC"
  },
  "TCA-095": {
    "actual_read_date": "2026-11-15",
    "literal_match": true,
    "native_quote": [
      "does not exceed 24 months"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://assets.publishing.service.gov.uk/media/608ae0c0d3bf7f0136332887/TS_8.2021_UK_EU_EAEC_Trade_and_Cooperation_Agreement.pdf",
    "operative_locator": "SSC11(1)(a)/(b)",
    "source_key": "TCA",
    "terms": "24 posting detached"
  },
  "TCA-096": {
    "actual_read_date": "2026-11-15",
    "literal_match": true,
    "native_quote": [
      "without prejudice to the employer's underlying obligations"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://assets.publishing.service.gov.uk/media/608ae0c0d3bf7f0136332887/TS_8.2021_UK_EU_EAEC_Trade_and_Cooperation_Agreement.pdf",
    "operative_locator": "SSC14(2)",
    "source_key": "TCA",
    "terms": "foreign employer payment"
  },
  "TCA-097": {
    "actual_read_date": "2026-11-15",
    "literal_match": true,
    "native_quote": [
      "United Kingdom"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://assets.publishing.service.gov.uk/media/608ae0c0d3bf7f0136332887/TS_8.2021_UK_EU_EAEC_Trade_and_Cooperation_Agreement.pdf",
    "operative_locator": "Articles489–490",
    "source_key": "TCA",
    "terms": "scope UK nexus"
  },
  "TCAAMEND-098": {
    "actual_read_date": "2026-11-15",
    "literal_match": true,
    "native_quote": [
      "Annex SSC-8"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://assets.publishing.service.gov.uk/media/61a5f3ebe90e07043c35f448/TS_21.2021_Decision_No_1.2021_Specialised_Committee_Social_Security.pdf",
    "operative_locator": "Article1/AnnexII",
    "source_key": "TCAAMEND",
    "terms": "states participation"
  },
  "TCAAMEND-099": {
    "actual_read_date": "2026-11-15",
    "literal_match": true,
    "native_quote": [
      "Germany"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://assets.publishing.service.gov.uk/media/61a5f3ebe90e07043c35f448/TS_21.2021_Decision_No_1.2021_Specialised_Committee_Social_Security.pdf",
    "operative_locator": "AnnexII",
    "source_key": "TCAAMEND",
    "terms": "Germany"
  },
  "UKDE-007": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "unless the employment is exercised"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.gov.uk/government/publications/germany-tax-treaties/2010-uk-germany-double-taxation-convention-as-amended-by-the-2021-protocol-in-force",
    "operative_locator": "Article14(1)",
    "source_key": "UKDE",
    "terms": "employment taxing remuneration"
  },
  "UKDE-008": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "183 days"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.gov.uk/government/publications/germany-tax-treaties/2010-uk-germany-double-taxation-convention-as-amended-by-the-2021-protocol-in-force",
    "operative_locator": "Article14(2)(a)",
    "source_key": "UKDE",
    "terms": "80 183 count days treaty exemption"
  },
  "UKDE-009": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "permanent establishment"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.gov.uk/government/publications/germany-tax-treaties/2010-uk-germany-double-taxation-convention-as-amended-by-the-2021-protocol-in-force",
    "operative_locator": "Article14(2)(c)",
    "source_key": "UKDE",
    "terms": "cost recharge subsidiary PE"
  },
  "UKDE-010": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "more than twelve months"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.gov.uk/government/publications/germany-tax-treaties/2010-uk-germany-double-taxation-convention-as-amended-by-the-2021-protocol-in-force",
    "operative_locator": "Article5(3)",
    "source_key": "UKDE",
    "terms": "project six construction building twelve"
  },
  "UKDE-011": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "shall not of itself constitute"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.gov.uk/government/publications/germany-tax-treaties/2010-uk-germany-double-taxation-convention-as-amended-by-the-2021-protocol-in-force",
    "operative_locator": "Article5(7)",
    "source_key": "UKDE",
    "terms": "control subsidiary parent"
  },
  "UKDE-012": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "credit against"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.gov.uk/government/publications/germany-tax-treaties/2010-uk-germany-double-taxation-convention-as-amended-by-the-2021-protocol-in-force",
    "operative_locator": "Article23(2)(a)",
    "source_key": "UKDE",
    "terms": "credit relief double taxation"
  },
  "UKDE-100": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "a fixed place of business"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.gov.uk/government/publications/germany-tax-treaties/2010-uk-germany-double-taxation-convention-as-amended-by-the-2021-protocol-in-force",
    "operative_locator": "Article5(1)",
    "source_key": "UKDE",
    "terms": "PE fixed place agency anti-fragmentation"
  },
  "UKDE-101": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.gov.uk/government/publications/germany-tax-treaties/2010-uk-germany-double-taxation-convention-as-amended-by-the-2021-protocol-in-force",
    "operative_locator": "Article5(5)",
    "source_key": "UKDE",
    "terms": "PE fixed place agency anti-fragmentation"
  },
  "UKDE-102": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.gov.uk/government/publications/germany-tax-treaties/2010-uk-germany-double-taxation-convention-as-amended-by-the-2021-protocol-in-force",
    "operative_locator": "Article5(4A)",
    "source_key": "UKDE",
    "terms": "PE fixed place agency anti-fragmentation"
  },
  "UKIR35-057": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "no UK connection"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.gov.uk/hmrc-internal-manuals/employment-status-manual/esm10025",
    "operative_locator": "ESM10025Clientwhollyoverseas",
    "source_key": "UKIR35",
    "terms": "client UK connection intermediary"
  },
  "UKIR35-058": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "not chargeable to UK tax or NICs"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.gov.uk/hmrc-internal-manuals/employment-status-manual/esm10025",
    "operative_locator": "ESM10025Workerlastparagraph",
    "source_key": "UKIR35",
    "terms": "worker overseas charge India"
  },
  "UKPAYE-042": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "PAYE can be disregarded in certain circumstances"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.gov.uk/hmrc-internal-manuals/paye-manual/paye82000",
    "operative_locator": "PAYE82000openingandconditions68–89",
    "source_key": "UKPAYE",
    "terms": "approval arrangement collection"
  },
  "US3509-078": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "1.5 percent"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.govinfo.gov/content/pkg/USCODE-2024-title26/html/USCODE-2024-title26-subtitleC-chap25-sec3509.htm",
    "operative_locator": "3509(a)(1)",
    "source_key": "US3509",
    "terms": "1.5 withholding"
  },
  "US3509-079": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "20 percent"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.govinfo.gov/content/pkg/USCODE-2024-title26/html/USCODE-2024-title26-subtitleC-chap25-sec3509.htm",
    "operative_locator": "3509(a)(2)",
    "source_key": "US3509",
    "terms": "20 employee share"
  },
  "US3509-080": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "3 percent"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.govinfo.gov/content/pkg/USCODE-2024-title26/html/USCODE-2024-title26-subtitleC-chap25-sec3509.htm",
    "operative_locator": "3509(b)(1)",
    "source_key": "US3509",
    "terms": "3 reporting"
  },
  "US3509-081": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "40 percent"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.govinfo.gov/content/pkg/USCODE-2024-title26/html/USCODE-2024-title26-subtitleC-chap25-sec3509.htm",
    "operative_locator": "3509(b)(2)",
    "source_key": "US3509",
    "terms": "40 reporting"
  },
  "US3509-082": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "intentional disregard"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.govinfo.gov/content/pkg/USCODE-2024-title26/html/USCODE-2024-title26-subtitleC-chap25-sec3509.htm",
    "operative_locator": "3509(c)",
    "source_key": "US3509",
    "terms": "intentional exclusions"
  },
  "USIRM-083": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "entire employer's share"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.irs.gov/irm/part4/irm_04-023-008",
    "operative_locator": "4.23.8.5.1",
    "source_key": "USIRM",
    "terms": "employer FICA"
  },
  "USIRM-084": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "reasonable cause and not willful neglect"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.irs.gov/irm/part4/irm_04-023-008",
    "operative_locator": "4.23.8.5.1/5.2",
    "source_key": "USIRM",
    "terms": "reasonable reporting exclusion"
  },
  "USOPTIONS-073": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "alternative minimum tax"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.irs.gov/taxtopics/tc427",
    "operative_locator": "Statutoryoptions",
    "source_key": "USOPTIONS",
    "terms": "ISO AMT"
  },
  "USOPTIONS-074": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "readily determined"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.irs.gov/taxtopics/tc427",
    "operative_locator": "Nonstatutoryoptions",
    "source_key": "USOPTIONS",
    "terms": "nonstatutory grant fair value"
  },
  "USOPTIONS-075": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "capital gain or loss"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.irs.gov/taxtopics/tc427",
    "operative_locator": "Nonstatutoryoptionssale",
    "source_key": "USOPTIONS",
    "terms": "sale capital"
  },
  "USPT-048": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "five years"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.ssa.gov/international/Agreement_Texts/portugal.html",
    "operative_locator": "Article5(1)",
    "source_key": "USPT",
    "terms": "5 temporary detached"
  },
  "USPT-049": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "one year"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.ssa.gov/international/Agreement_Texts/portugal.html",
    "operative_locator": "Article5(2)",
    "source_key": "USPT",
    "terms": "extension unforeseen request"
  },
  "USPT-050": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "August 1, 1989"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.ssa.gov/international/Agreement_Texts/portugal.html",
    "operative_locator": "Effectivedate",
    "source_key": "USPT",
    "terms": "Portugal exists"
  },
  "USPT-051": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "territory"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.ssa.gov/international/Agreement_Texts/portugal.html",
    "operative_locator": "Article4(1)",
    "source_key": "USPT",
    "terms": "ordinary work state scope"
  },
  "USSTATUS-052": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "no one factor stands alone"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.irs.gov/businesses/small-businesses-self-employed/independent-contractor-self-employed-or-employee",
    "operative_locator": "Determiningrelationship,allfactorsparagraph",
    "source_key": "USSTATUS",
    "terms": "all factors"
  },
  "USSTATUS-053": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "right to control"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "official_url": "https://www.irs.gov/businesses/small-businesses-self-employed/independent-contractor-self-employed-or-employee",
    "operative_locator": "Remoteworkerparagraph",
    "source_key": "USSTATUS",
    "terms": "remote control"
  }
}
```

## Original-topic destinations

The complete original-topic destination table is in `../cross-border-payroll-coordination/old-topic-map.json`.
