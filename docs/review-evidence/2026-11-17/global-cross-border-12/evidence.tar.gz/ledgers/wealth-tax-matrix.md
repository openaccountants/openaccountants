# wealth-tax-matrix figure and rule ledger

Public projection; canonical private SHA256: `56057a95ce71eba01b664342381913f03c046e4e1146af24020f084f5cbd7c97`. Complete captured/native source passages remain local. The JSON companion preserves every retained evidence field.

## Whole rule groups

### ES-SCOPE

IP under Ley 19/1991 is an individual tax. Habitually resident persons generally report worldwide wealth; nonresidents report Spanish-situs or exercisable/performable rights, including the specified unlisted property-rich entity rule. Residence and any special election require separate testing. The net base deducts real charges and substantiated debts; nonresidents deduct only qualifying charges and debts invested in taxable Spanish assets. There is no blanket prohibition on a debt merely because the lender is a foreign bank.

```json
{
  "act_article_or_scope": "Ley19/1991 Arts4–6/9/25/28–32/37, complete operative paragraphs and neighbours",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "IP under Ley 19/1991 is an individual tax. Habitually resident persons generally report worldwide wealth; nonresidents report Spanish-situs or exercisable/performable rights, including the specified unlisted property-rich entity rule. Residence and any special election require separate testing. The net base deducts real charges and substantiated debts; nonresidents deduct only qualifying charges and debts invested in taxable Spanish assets. There is no blanket prohibition on a debt merely because the lender is a foreign bank.",
  "guide_lines": [
    31
  ],
  "id": "ES-SCOPE",
  "official_url": "https://www.boe.es/buscar/act.php?id=BOE-A-1991-14392",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "por obligación personal"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/wealth-es-ip-law.txt",
  "source_key": "wealth-es-ip-law",
  "source_sha256": "5b5385fc1f94cd23ee01fd18bdc02d55370ba2b9558c7ee4ccc8cf2c8c2f52cf",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### ES-DEBT

Value debts at nominal amount on the accrual date and substantiate them. A mortgage is not an extra deduction in addition to its underlying loan. Guarantees are generally excluded until the statutory demand/insolvency conditions apply. Debt used to acquire exempt assets is excluded, proportionately where exemption is partial.

```json
{
  "act_article_or_scope": "Arts9(2)/(4),25 and26–27 neighbours",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "Value debts at nominal amount on the accrual date and substantiate them. A mortgage is not an extra deduction in addition to its underlying loan. Guarantees are generally excluded until the statutory demand/insolvency conditions apply. Debt used to acquire exempt assets is excluded, proportionately where exemption is partial.",
  "guide_lines": [
    33
  ],
  "id": "ES-DEBT",
  "official_url": "https://www.boe.es/buscar/act.php?id=BOE-A-1991-14392",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "Las deudas se valorarán por su nominal"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/wealth-es-ip-law.txt",
  "source_key": "wealth-es-ip-law",
  "source_sha256": "5b5385fc1f94cd23ee01fd18bdc02d55370ba2b9558c7ee4ccc8cf2c8c2f52cf",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### ES-ALLOWANCE-DATE

The state-default IP allowance is EUR 700,000 where the competent region has not replaced it; the habitual-home exemption is up to EUR 300,000 per taxpayer, separately. IP accrues on 31 December. Do not equate gross assets, net wealth, the allowance-adjusted base and the final bill.

```json
{
  "act_article_or_scope": "Arts4.Nueve,28–30 whole",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "The state-default IP allowance is EUR 700,000 where the competent region has not replaced it; the habitual-home exemption is up to EUR 300,000 per taxpayer, separately. IP accrues on 31 December. Do not equate gross assets, net wealth, the allowance-adjusted base and the final bill.",
  "guide_lines": [
    35
  ],
  "id": "ES-ALLOWANCE-DATE",
  "official_url": "https://www.boe.es/buscar/act.php?id=BOE-A-1991-14392",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "700.000 euros"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/wealth-es-ip-law.txt",
  "source_key": "wealth-es-ip-law",
  "source_sha256": "5b5385fc1f94cd23ee01fd18bdc02d55370ba2b9558c7ee4ccc8cf2c8c2f52cf",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### ES-FAMILY

The family-share exemption is conditional: the entity must not principally manage securities or other assets where for more than 90 days of the year more than half its assets are securities or non-business assets, subject to the defined management-holding and operating-profit exceptions; the individual holds at least 5%, or a group with spouse, ascendants, descendants or second-degree collateral relatives by blood, affinity or adoption holds at least 20%. Effective management must earn more than 50% of the relevant business, professional and employment income, with statutory exclusions; in a family group one qualifying member can meet the management/pay test. Relief covers only the proportion attributable to necessary business assets net of business liabilities, including the corresponding subsidiary analysis. Active ownership alone is insufficient.

```json
{
  "act_article_or_scope": "Art4.Ocho.Dos(a)–(c), entire management/asset/computation provisos",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "The family-share exemption is conditional: the entity must not principally manage securities or other assets where for more than 90 days of the year more than half its assets are securities or non-business assets, subject to the defined management-holding and operating-profit exceptions; the individual holds at least 5%, or a group with spouse, ascendants, descendants or second-degree collateral relatives by blood, affinity or adoption holds at least 20%. Effective management must earn more than 50% of the relevant business, professional and employment income, with statutory exclusions; in a family group one qualifying member can meet the management/pay test. Relief covers only the proportion attributable to necessary business assets net of business liabilities, including the corresponding subsidiary analysis. Active ownership alone is insufficient.",
  "guide_lines": [
    37
  ],
  "id": "ES-FAMILY",
  "official_url": "https://www.boe.es/buscar/act.php?id=BOE-A-1991-14392",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "cinco por ciento"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/wealth-es-ip-law.txt",
  "source_key": "wealth-es-ip-law",
  "source_sha256": "5b5385fc1f94cd23ee01fd18bdc02d55370ba2b9558c7ee4ccc8cf2c8c2f52cf",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### ES-OTHER-EXEMPTIONS

Check each classified historical/artistic asset against its actual registration, value, museum-deposit or creator conditions; a family heirloom is not automatically exempt. Household effects have their own definition and exclusions. Author intellectual property is exempt while remaining in the author’s estate, and industrial property only outside the stated business setting; inalienability is not the test. Only the defined pension, insurance, social-provision and PEPP rights qualify, rather than every retirement asset.

```json
{
  "act_article_or_scope": "Art4.Uno–Siete andNueve whole; all pension/IP/cultural limbs read",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "Check each classified historical/artistic asset against its actual registration, value, museum-deposit or creator conditions; a family heirloom is not automatically exempt. Household effects have their own definition and exclusions. Author intellectual property is exempt while remaining in the author’s estate, and industrial property only outside the stated business setting; inalienability is not the test. Only the defined pension, insurance, social-provision and PEPP rights qualify, rather than every retirement asset.",
  "guide_lines": [
    39
  ],
  "id": "ES-OTHER-EXEMPTIONS",
  "official_url": "https://www.boe.es/buscar/act.php?id=BOE-A-1991-14392",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "mientras permanezcan en el patrimonio del autor"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/wealth-es-ip-law.txt",
  "source_key": "wealth-es-ip-law",
  "source_sha256": "5b5385fc1f94cd23ee01fd18bdc02d55370ba2b9558c7ee4ccc8cf2c8c2f52cf",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### ES-ITSGF-SCOPE

ITSGF is complementary, not a flat charge on every euro above a gross threshold. The statutory wealth trigger is net wealth strictly exceeding EUR 3,000,000; IP exemptions apply, and the personal minimum is EUR 700,000 for both personal and real obligations after the amendment. Accrual is 31 December. Residence, territorial exceptions and any representative requirement must be checked.

```json
{
  "act_article_or_scope": "Ley38/2022Art3.Unos–Once;RDL8/2023Art17 overlay separately read",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "ITSGF is complementary, not a flat charge on every euro above a gross threshold. The statutory wealth trigger is net wealth strictly exceeding EUR 3,000,000; IP exemptions apply, and the personal minimum is EUR 700,000 for both personal and real obligations after the amendment. Accrual is 31 December. Residence, territorial exceptions and any representative requirement must be checked.",
  "guide_lines": [
    41
  ],
  "id": "ES-ITSGF-SCOPE",
  "official_url": "https://www.boe.es/buscar/act.php?id=BOE-A-2022-22684",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "superior a 3.000.000 de euros"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/wealth-es-solid-law.txt",
  "source_key": "wealth-es-solid-law",
  "source_sha256": "1495f87d30efbafb6e06650ff0a367b99360e19244616641c5dd625e9ddb5d20",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### ES-EXTENSION

RDL 8/2023 extended ITSGF until wealth taxation is reviewed in the autonomous-financing reform. The old attribution to RDL 9/2024 and a fixed 2025 sunset is not the operative extension.

```json
{
  "act_article_or_scope": "RDL8/2023DA5(2) andArt17 whole; surrounding dispositions",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "RDL 8/2023 extended ITSGF until wealth taxation is reviewed in the autonomous-financing reform. The old attribution to RDL 9/2024 and a fixed 2025 sunset is not the operative extension.",
  "guide_lines": [
    43
  ],
  "id": "ES-EXTENSION",
  "official_url": "https://www.boe.es/buscar/act.php?id=BOE-A-2023-26452",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "en tanto no se produzca la revisión"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/wealth-tax/sources/es-rdl8.txt",
  "source_key": "extension",
  "source_sha256": "d058b34aede4a9ce18d3a278cbf4d63516c78bf0dcd5b39ad009bfeec8abc829",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### ES-ITSGF-TARIFF

Apply the table to the allowance-adjusted base, not to net assets before the minimum. The zero-rate band is distinct from the initial scope trigger.

```json
{
  "act_article_or_scope": "Art3.Once entire table",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "Apply the table to the allowance-adjusted base, not to net assets before the minimum. The zero-rate band is distinct from the initial scope trigger.",
  "guide_lines": [
    45,
    46,
    47,
    48,
    49,
    50,
    52
  ],
  "id": "ES-ITSGF-TARIFF",
  "official_url": "https://www.boe.es/buscar/act.php?id=BOE-A-2022-22684",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "5.347.998,03"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/wealth-es-solid-law.txt",
  "source_key": "wealth-es-solid-law",
  "source_sha256": "1495f87d30efbafb6e06650ff0a367b99360e19244616641c5dd625e9ddb5d20",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### ES-CAPS-CREDITS

For the statutory personal-obligation route, the combined IRPF/IP/ITSGF cap uses 60% of the defined IRPF bases, subject to the incorporated exclusions and a maximum 80% ITSGF reduction. IP has its own corresponding cap and 80% reduction ceiling. The non-income-producing asset component is excluded from the cap calculation; this is not a rule that the entire cap disappears whenever assets are mostly nonproductive. Joint-income-return allocations must be respected. Apply qualifying foreign-tax relief and other reductions in order, then credit IP actually paid. Do not infer automatic nonresident cap entitlement from a form alone; the current procedural/judicial basis must be established for that separate route.

```json
{
  "act_article_or_scope": "Art3.Doce–Diecisiete whole, withLey19/1991Art31/32 personally read",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "For the statutory personal-obligation route, the combined IRPF/IP/ITSGF cap uses 60% of the defined IRPF bases, subject to the incorporated exclusions and a maximum 80% ITSGF reduction. IP has its own corresponding cap and 80% reduction ceiling. The non-income-producing asset component is excluded from the cap calculation; this is not a rule that the entire cap disappears whenever assets are mostly nonproductive. Joint-income-return allocations must be respected. Apply qualifying foreign-tax relief and other reductions in order, then credit IP actually paid. Do not infer automatic nonresident cap entitlement from a form alone; the current procedural/judicial basis must be established for that separate route.",
  "guide_lines": [
    54
  ],
  "id": "ES-CAPS-CREDITS",
  "official_url": "https://www.boe.es/buscar/act.php?id=BOE-A-2022-22684",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "60 por ciento"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/wealth-es-solid-law.txt",
  "source_key": "wealth-es-solid-law",
  "source_sha256": "1495f87d30efbafb6e06650ff0a367b99360e19244616641c5dd625e9ddb5d20",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### ES-CAT

Catalonia’s published statutory minimum is EUR 500,000. While ITSGF remains in force, its transitional tariff runs from 0.210% to 3.480%, including the 2.205% band starting at EUR 5,347,998.03 with prior quota EUR 74,930.46; 2.750% starts at EUR 10,695,996.06, and 3.480% above EUR 20,000,000. The old 2.75% ceiling is incomplete. The retained official consolidation is updated 18 December 2024; confirm subsequent regional changes before an actual 2026 year-end filing.

```json
{
  "act_article_or_scope": "CatalunyaCode621-1/621-2 andDT1 all3pages",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "Catalonia’s published statutory minimum is EUR 500,000. While ITSGF remains in force, its transitional tariff runs from 0.210% to 3.480%, including the 2.205% band starting at EUR 5,347,998.03 with prior quota EUR 74,930.46; 2.750% starts at EUR 10,695,996.06, and 3.480% above EUR 20,000,000. The old 2.75% ceiling is incomplete. The retained official consolidation is updated 18 December 2024; confirm subsequent regional changes before an actual 2026 year-end filing.",
  "guide_lines": [
    56
  ],
  "id": "ES-CAT",
  "official_url": "https://economia.gencat.cat/web/.content/70_tributs/Normativa/Refoses/IP.pdf",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "500.000 euros"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/wealth-tax/sources/cat.txt",
  "source_key": "cat",
  "source_sha256": "79b829ed5bf47fb077c10dacf825e37011517b49d76f08dd1ef4851ef7180775",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### ES-MADRID

Madrid’s current authority guidance suspends its general 100% IP rebate while ITSGF is in force and replaces it with the positive difference between IP after its cap and the corresponding ITSGF after its cap. Compute both charges and credit actual IP; do not begin with an assumed zero IP bill. The exact IP tariff and all case-specific caps remain prerequisites to a final Madrid computation.

```json
{
  "act_article_or_scope": "Actual2026regionalpage, minimum/rebate operative180–207",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "Madrid’s current authority guidance suspends its general 100% IP rebate while ITSGF is in force and replaces it with the positive difference between IP after its cap and the corresponding ITSGF after its cap. Compute both charges and credit actual IP; do not begin with an assumed zero IP bill. The exact IP tariff and all case-specific caps remain prerequisites to a final Madrid computation.",
  "guide_lines": [
    58
  ],
  "id": "ES-MADRID",
  "official_url": "https://www.comunidad.madrid/atencion-contribuyente/patrimonio",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "no será aplicable"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/wealth-tax/sources/madrid.txt",
  "source_key": "madrid",
  "source_sha256": "cae28ac6e9cdafbe608b9a5d5a89701599dd1459fcbae2c2a94898ed48a432fb",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### ES-MADRID-LAW

Madrid fixes the IP minimum at EUR 700,000. Its current IP chapter contains that minimum and the general rebate; DT7 suspends the rebate while ITSGF is in force and replaces it by the positive capped-IP/shadow-ITSGF difference. Apply the state supplementary tariff where no regional scale is approved. The current read legal version is updated 10 July 2026.

```json
{
  "act_article_or_scope": "DLeg1/2010current10July2026,wholeIPchapterArts19/20andDT7whole2910–2916",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "Madrid fixes the IP minimum at EUR 700,000. Its current IP chapter contains that minimum and the general rebate; DT7 suspends the rebate while ITSGF is in force and replaces it by the positive capped-IP/shadow-ITSGF difference. Apply the state supplementary tariff where no regional scale is approved. The current read legal version is updated 10 July 2026.",
  "guide_lines": [
    60
  ],
  "id": "ES-MADRID-LAW",
  "official_url": "https://www.boe.es/buscar/act.php?id=BOCM-m-2010-90068",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "700.000 euros"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/wealth-tax/madrid-law-web.json",
  "source_key": "madridlaw",
  "source_sha256": "c060028afc198f881505fc81666a6764d1936c5c252f2b9d6a91b46b62a15cc2",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### ES-IP-DEFAULT-TARIFF

The state fallback IP tariff applies absent an approved regional tariff. In the supplied Madrid case, the relevant base band starts at EUR 5,347,998.03 with prior quota EUR 71,362.33 and marginal rate 2.1%. This supports the computed pre-rebate amount; actual cap/credit changes require recomputation.

```json
{
  "act_article_or_scope": "Art30wholeincludingstatefallbackandall8bands,Art29/31neighbours",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "The state fallback IP tariff applies absent an approved regional tariff. In the supplied Madrid case, the relevant base band starts at EUR 5,347,998.03 with prior quota EUR 71,362.33 and marginal rate 2.1%. This supports the computed pre-rebate amount; actual cap/credit changes require recomputation.",
  "guide_lines": [
    62
  ],
  "id": "ES-IP-DEFAULT-TARIFF",
  "official_url": "https://www.boe.es/buscar/act.php?id=BOE-A-1991-14392",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "5.347.998,03"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/wealth-es-ip-law.txt",
  "source_key": "wealth-es-ip-law",
  "source_sha256": "5b5385fc1f94cd23ee01fd18bdc02d55370ba2b9558c7ee4ccc8cf2c8c2f52cf",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### ES-FOREIGN-CREDIT

For personal-obligation IP, foreign personal tax on included foreign assets is credited up to the lower of actual foreign tax and the Spanish average effective rate applied to the corresponding foreign-taxed base. The statutory average-rate precision and treaty provisions matter; a treaty capital article is not a prerequisite for this domestic route.

```json
{
  "act_article_or_scope": "Art32whole655–662with31/33neighbours",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "For personal-obligation IP, foreign personal tax on included foreign assets is credited up to the lower of actual foreign tax and the Spanish average effective rate applied to the corresponding foreign-taxed base. The statutory average-rate precision and treaty provisions matter; a treaty capital article is not a prerequisite for this domestic route.",
  "guide_lines": [
    64
  ],
  "id": "ES-FOREIGN-CREDIT",
  "official_url": "https://www.boe.es/buscar/act.php?id=BOE-A-1991-14392",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "la cantidad"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/wealth-es-ip-law.txt",
  "source_key": "wealth-es-ip-law",
  "source_sha256": "5b5385fc1f94cd23ee01fd18bdc02d55370ba2b9558c7ee4ccc8cf2c8c2f52cf",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### ES-ANDALUCIA

Andalusia’s current DT5 suspends its regional tariff and general 100% rebate while ITSGF remains in force. It substitutes the positive difference between IP after its cap and shadow ITSGF after its cap. The state supplementary tariff therefore matters; the old two-choice arrangement belongs to the prior version. This does not support an unconditional zero wealth-tax result.

```json
{
  "act_article_or_scope": "Ley5/2021DT5whole2144–2156 and currentversionheader; agency2024/25explanation neighbours",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "Andalusia’s current DT5 suspends its regional tariff and general 100% rebate while ITSGF remains in force. It substitutes the positive difference between IP after its cap and shadow ITSGF after its cap. The state supplementary tariff therefore matters; the old two-choice arrangement belongs to the prior version. This does not support an unconditional zero wealth-tax result.",
  "guide_lines": [
    66
  ],
  "id": "ES-ANDALUCIA",
  "official_url": "https://www.boe.es/buscar/act.php?id=BOE-A-2021-17915",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "No será aplicable la bonificación general"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/wealth-tax/wealthAndfind.json",
  "source_key": "andalucia",
  "source_sha256": "1df71f37fbda55720a1794d23a93568109d96d5e8c8c54b2015d59cd58b13595",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### ES-GALICIA

Galicia’s guidance distinguishes its ordinary 50% rebate and ordinary tariff from the temporary ITSGF overlay: the current temporary tariff reaches 3.5%, and the rebate is reduced by the ITSGF amount that would otherwise be payable, floored at zero, with the stated corresponding treatment of other regional deductions. Do not use the old 0.2%–2.5% comparison as the current final tariff.

```json
{
  "act_article_or_scope": "Actualregionguide currenttemporarybranch and priorbranch116–150",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "Galicia’s guidance distinguishes its ordinary 50% rebate and ordinary tariff from the temporary ITSGF overlay: the current temporary tariff reaches 3.5%, and the rebate is reduced by the ITSGF amount that would otherwise be payable, floored at zero, with the stated corresponding treatment of other regional deductions. Do not use the old 0.2%–2.5% comparison as the current final tariff.",
  "guide_lines": [
    68
  ],
  "id": "ES-GALICIA",
  "official_url": "https://www.atriga.gal/informacion-tributaria/tributos/patrimonio/informacion-del-tributo/guia-del-imposto-sobre-o-patrimonio",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "50 %"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/wealth-tax/sources/galicia.txt",
  "source_key": "galicia",
  "source_sha256": "6b6642731dd8684c72ee313a015d55993fcc5666411f27a3b5b4f0bebea46103",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### ES-IP-FILING

IP filing is required when a positive amount is payable after deductions/rebates, or when the law-valued assets/rights exceed EUR 2,000,000 even if no tax is payable. Form 714 and the precise annual campaign/electronic procedure require that period’s implementing order; the old universal May–June window is not a confirmed 2026-year deadline.

```json
{
  "act_article_or_scope": "Arts36–37whole;29accrual previouslyread",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "IP filing is required when a positive amount is payable after deductions/rebates, or when the law-valued assets/rights exceed EUR 2,000,000 even if no tax is payable. Form 714 and the precise annual campaign/electronic procedure require that period’s implementing order; the old universal May–June window is not a confirmed 2026-year deadline.",
  "guide_lines": [
    78
  ],
  "id": "ES-IP-FILING",
  "official_url": "https://www.boe.es/buscar/act.php?id=BOE-A-1991-14392",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/wealth-es-ip-law.txt",
  "source_key": "wealth-es-ip-law",
  "source_sha256": "5b5385fc1f94cd23ee01fd18bdc02d55370ba2b9558c7ee4ccc8cf2c8c2f52cf",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### ES-718

Form 718 is electronic; the ordinary presentation window is 1–31 July following accrual, with a separate direct-debit deadline. Filing is tied to the statutory payable-amount rule and exceptions. Do not substitute the IP campaign dates. A future amendment, calendar or a special nonresident route must be checked before execution.

```json
{
  "act_article_or_scope": "OrderHFP587/2023Arts1–5whole, latest29June2026consolidation",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "Form 718 is electronic; the ordinary presentation window is 1–31 July following accrual, with a separate direct-debit deadline. Filing is tied to the statutory payable-amount rule and exceptions. Do not substitute the IP campaign dates. A future amendment, calendar or a special nonresident route must be checked before execution.",
  "guide_lines": [
    80
  ],
  "id": "ES-718",
  "official_url": "https://www.boe.es/buscar/act.php?id=BOE-A-2023-13800",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "entre los días 1 y 31 de julio"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/wealth-tax/wealthFinalBodies2.json",
  "source_key": "718",
  "source_sha256": "dbb493f107a995d187f9f0cf04d869159261dfa16696edfd97e45498e82e2446",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### NO-RATES

For a single taxpayer the 2026 municipal schedule is zero through NOK 1,900,000 and 0.35% above; state tax is zero through NOK 1,900,000, 0.65% up to NOK 21,500,000 and 0.75% above. The combined marginal rates are 1.00% and 1.10%. The published thresholds double for spouses, registered partners or qualifying cohabitants jointly assessed on combined wealth: NOK 3,800,000 and NOK 43,000,000. These are marginal bands, not a charge on exempt wealth.

```json
{
  "act_article_or_scope": "Wholeactual2026municipal/state tables and jointassessmentnotes",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "For a single taxpayer the 2026 municipal schedule is zero through NOK 1,900,000 and 0.35% above; state tax is zero through NOK 1,900,000, 0.65% up to NOK 21,500,000 and 0.75% above. The combined marginal rates are 1.00% and 1.10%. The published thresholds double for spouses, registered partners or qualifying cohabitants jointly assessed on combined wealth: NOK 3,800,000 and NOK 43,000,000. These are marginal bands, not a charge on exempt wealth.",
  "guide_lines": [
    85
  ],
  "id": "NO-RATES",
  "official_url": "https://www.skatteetaten.no/satser/formuesskatt/?year=2026",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "1 900 000 kroner"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/wealth-no.txt",
  "source_key": "wealth-no",
  "source_sha256": "ec3874545767177403186db99c600ef78d8e360485c25900b542307f46272f79",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### NO-DISCOUNTS

Published valuation discounts concern directly owned assets and the corresponding debt where specified: primary home 75% discount up to NOK 14 million and 30% discount on the excess; secondary home no discount; shares including commercial property 20% discount; other operating assets 30% discount. Thus the corresponding taxable fractions are 25%, 70%, 100%, 80% and 70%. Do not treat operating assets as an undifferentiated 80% class or reduce assets without checking debt allocation. Cash is not one of the listed discounted classes.

```json
{
  "act_article_or_scope": "Whole2026discounttable plusdirectownership/assigneddebtsintro",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "Published valuation discounts concern directly owned assets and the corresponding debt where specified: primary home 75% discount up to NOK 14 million and 30% discount on the excess; secondary home no discount; shares including commercial property 20% discount; other operating assets 30% discount. Thus the corresponding taxable fractions are 25%, 70%, 100%, 80% and 70%. Do not treat operating assets as an undifferentiated 80% class or reduce assets without checking debt allocation. Cash is not one of the listed discounted classes.",
  "guide_lines": [
    87
  ],
  "id": "NO-DISCOUNTS",
  "official_url": "https://www.skatteetaten.no/satser/formuesskatt/?year=2026",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "75"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/wealth-no.txt",
  "source_key": "wealth-no",
  "source_sha256": "ec3874545767177403186db99c600ef78d8e360485c25900b542307f46272f79",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### NO-HOME

For the home, use the authority’s computed residential value and the documented market-value correction rules where applicable; the 25%/70% taxable fractions change at NOK 14 million, not the old NOK 10 million. Secondary homes use the published 100% fraction. These rules concern income year 2026, not a 2025 return filed in 2026.

```json
{
  "act_article_or_scope": "Wholeactual2026primary/secondaryhomevaluationbody",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "For the home, use the authority’s computed residential value and the documented market-value correction rules where applicable; the 25%/70% taxable fractions change at NOK 14 million, not the old NOK 10 million. Secondary homes use the published 100% fraction. These rules concern income year 2026, not a 2025 return filed in 2026.",
  "guide_lines": [
    89
  ],
  "id": "NO-HOME",
  "official_url": "https://www.skatteetaten.no/satser/formuesverdi-bolig/?year=2026",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "25 %"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/wealth-no-home.txt",
  "source_key": "wealth-no-home",
  "source_sha256": "b31334f7d9182020373ea49fcaaf43198bf018e6c6091bd2bfcb88aa436c5ed2",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### NO-FOREIGN

Norwegian tax residence generally brings foreign assets into reporting; limited liability does not generally include wealth abroad. Report the tax value of foreign financial assets at 31 December and convert currencies correctly. The authority permits a documented credit claim for foreign tax on the same wealth subject to Norwegian tax; treaty residence and the actual treaty can limit the charge. Do not assume that relief requires a treaty capital article, or that any Swiss payment is automatically creditable.

```json
{
  "act_article_or_scope": "Wholeoperative0–26, treatyresidenceneighbours",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "Norwegian tax residence generally brings foreign assets into reporting; limited liability does not generally include wealth abroad. Report the tax value of foreign financial assets at 31 December and convert currencies correctly. The authority permits a documented credit claim for foreign tax on the same wealth subject to Norwegian tax; treaty residence and the actual treaty can limit the charge. Do not assume that relief requires a treaty capital article, or that any Swiss payment is automatically creditable.",
  "guide_lines": [
    91
  ],
  "id": "NO-FOREIGN",
  "official_url": "https://www.skatteetaten.no/en/person/to-from-norway/to/work/the-tax-return/wealth-other-countries/",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "31 December"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/wealth-tax/wealthFinalBodies.json",
  "source_key": "no-foreign-current",
  "source_sha256": "109bd9d2ce5620d1a7ff954feacb5e84c5247231ec83d97b732c46dde30ee1ef",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### CH-STRUCTURE

There is no direct federal wealth tax on individuals; cantons and municipalities levy it. The current ESTV report states law as at 1 January 2026. Rates, tax-free amounts and deductions are cantonal; municipality and sometimes church affiliation affect the result. A single canton-wide headline percentage and threshold cannot establish a bill.

```json
{
  "act_article_or_scope": "ESTVSeptember2026report law1Jan2026, introduction1/1.1/1.2,2,3.1whole",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "There is no direct federal wealth tax on individuals; cantons and municipalities levy it. The current ESTV report states law as at 1 January 2026. Rates, tax-free amounts and deductions are cantonal; municipality and sometimes church affiliation affect the result. A single canton-wide headline percentage and threshold cannot establish a bill.",
  "guide_lines": [
    96
  ],
  "id": "CH-STRUCTURE",
  "official_url": "https://www.estv2.admin.ch/stp/ds/d-vermoegenssteuer-np-de.pdf",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "keine direkte Bundessteuer"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/wealth-ch-wealth-law.txt",
  "source_key": "wealth-ch-wealth-law",
  "source_sha256": "46744dc66c5a7e8c585401c6d5815211814300f6232239ce69e10cd0eaa78ae6",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### CH-BASE

Declare the whole wealth register, including foreign movable assets, ownership and usufruct. Unlimited and economic-connection liability, treaties and allocation rules decide the taxable share and rate-determining wealth. The old universal exclusion for foreign movable assets is incorrect. Value assets under the particular cantonal rules; there is no universal 60%–80% real-property rule. Subtract only proven debts under the applicable allocation rules; guarantees and contingent obligations are not universally deductible. Use the year-end reference and any change-of-liability rules.

```json
{
  "act_article_or_scope": "Sections2/2.1/2.2/3.1/5.1/6 whole assigned passages",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "Declare the whole wealth register, including foreign movable assets, ownership and usufruct. Unlimited and economic-connection liability, treaties and allocation rules decide the taxable share and rate-determining wealth. The old universal exclusion for foreign movable assets is incorrect. Value assets under the particular cantonal rules; there is no universal 60%–80% real-property rule. Subtract only proven debts under the applicable allocation rules; guarantees and contingent obligations are not universally deductible. Use the year-end reference and any change-of-liability rules.",
  "guide_lines": [
    98
  ],
  "id": "CH-BASE",
  "official_url": "https://www.estv2.admin.ch/stp/ds/d-vermoegenssteuer-np-de.pdf",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "Schweiz und im Ausland"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/wealth-ch-wealth-law.txt",
  "source_key": "wealth-ch-wealth-law",
  "source_sha256": "46744dc66c5a7e8c585401c6d5815211814300f6232239ce69e10cd0eaa78ae6",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### CH-EXEMPTIONS

Household goods/personal-use effects and qualifying second-pillar/3a retirement rights before payment have the stated exclusions. Annuity rights depend on their legal type and cantonal rule, not a universal exemption. Personal/family deductions and minimum wealth differ from a zero-rate threshold. The ten original cantons remain comparison candidates below, but their old approximate rates and allowances are individually unusable until the actual municipality, household and current cantonal schedule are supplied.

```json
{
  "act_article_or_scope": "Sections2.1/2.2/5.2/5.3/7 and7.1.4 whole operative scopes",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "Household goods/personal-use effects and qualifying second-pillar/3a retirement rights before payment have the stated exclusions. Annuity rights depend on their legal type and cantonal rule, not a universal exemption. Personal/family deductions and minimum wealth differ from a zero-rate threshold. The ten original cantons remain comparison candidates below, but their old approximate rates and allowances are individually unusable until the actual municipality, household and current cantonal schedule are supplied.",
  "guide_lines": [
    100,
    102,
    103,
    104,
    105,
    106,
    107,
    108,
    109,
    110,
    111,
    112,
    113
  ],
  "id": "CH-EXEMPTIONS",
  "official_url": "https://www.estv2.admin.ch/stp/ds/d-vermoegenssteuer-np-de.pdf",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "Hausrat"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/wealth-ch-wealth-law.txt",
  "source_key": "wealth-ch-wealth-law",
  "source_sha256": "46744dc66c5a7e8c585401c6d5815211814300f6232239ce69e10cd0eaa78ae6",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### AR-SCOPE

Bienes Personales generally measures assets at 31 December: residents report Argentine and foreign assets, nonresidents Argentine assets, with the estate/substitute-taxpayer rules separately checked. The authority’s latest recovered indexed table is tax period 2025: general minimum ARS 384,728,044.57 and home amount ARS 1,346,548,155.99. Those are 2025 amounts published for the corresponding return, not verified 2026 indexed peso values. The old ARS 100 million/350 million figures belong to 2023.

```json
{
  "act_article_or_scope": "Wholeoperativebody,2023/24/25periodtables",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "Bienes Personales generally measures assets at 31 December: residents report Argentine and foreign assets, nonresidents Argentine assets, with the estate/substitute-taxpayer rules separately checked. The authority’s latest recovered indexed table is tax period 2025: general minimum ARS 384,728,044.57 and home amount ARS 1,346,548,155.99. Those are 2025 amounts published for the corresponding return, not verified 2026 indexed peso values. The old ARS 100 million/350 million figures belong to 2023.",
  "guide_lines": [
    117
  ],
  "id": "AR-SCOPE",
  "official_url": "https://www.arca.gob.ar/gananciasYBienes/bienes-personales/conceptos-basicos/que-es.asp",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "31 de diciembre"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/wealth-ar-basics-full.txt",
  "source_key": "wealth-ar-basics-full",
  "source_sha256": "9ce2ba44c36c64a5c3f847fe247137a9018cd543a9e5cf641dc44f89a02f6f96",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### AR-RATE

The enacted ordinary 2026 schedule is 0.50% then 0.75% on the allowance-adjusted base, with the annually indexed band boundary; do not substitute the unindexed statutory peso boundary or the unrecovered 2026 indexed amount. The reformed table covers domestic and foreign property together. The old separate foreign surcharge, 50%–100% multiplier and 5% repatriation route are not the current ordinary schedule. The compliant-taxpayer 0.50-percentage-point reduction in article 64 covers 2023–2025, not automatically 2026.

```json
{
  "act_article_or_scope": "Law27743Art63replacementtable25–27 andArt64whole",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "The enacted ordinary 2026 schedule is 0.50% then 0.75% on the allowance-adjusted base, with the annually indexed band boundary; do not substitute the unindexed statutory peso boundary or the unrecovered 2026 indexed amount. The reformed table covers domestic and foreign property together. The old separate foreign surcharge, 50%–100% multiplier and 5% repatriation route are not the current ordinary schedule. The compliant-taxpayer 0.50-percentage-point reduction in article 64 covers 2023–2025, not automatically 2026.",
  "guide_lines": [
    119
  ],
  "id": "AR-RATE",
  "official_url": "https://biblioteca.arca.gob.ar/dcp/LEY_C_027743_2024_06_27",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "período fiscal 2026"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/wealth-ar-reibp-law.txt",
  "source_key": "wealth-ar-reibp-law",
  "source_sha256": "8bac6921aa1ebb7e1be6f61bc7709d88b42b1eea0ec5c2383e3977764a320d27",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### AR-EXEMPT

Specified bank deposits, public securities and certain qualifying investment instruments are exemptions, not a general lower rate for liquid assets. Check each statutory instrument, currency, institution and underlying-asset condition; some funds require at least 75% qualifying assets. Other listed categories include defined pension rights, cooperative interests, intellectual property, qualifying rural land and registered rental-home conditions. Exempt reporting can still be required.

```json
{
  "act_article_or_scope": "Wholeactualexempt-assetsbody1–45",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "Specified bank deposits, public securities and certain qualifying investment instruments are exemptions, not a general lower rate for liquid assets. Check each statutory instrument, currency, institution and underlying-asset condition; some funds require at least 75% qualifying assets. Other listed categories include defined pension rights, cooperative interests, intellectual property, qualifying rural land and registered rental-home conditions. Exempt reporting can still be required.",
  "guide_lines": [
    121
  ],
  "id": "AR-EXEMPT",
  "official_url": "https://arca.gob.ar/gananciasYBienes/bienes-personales/conceptos-basicos/bienes-exentos.asp",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "75%"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/wealth-ar-exempt.txt",
  "source_key": "wealth-ar-exempt",
  "source_sha256": "8be837915c8875b8495ec00b071a6fdcf28e7a5656c4298acad83d128f88ba36",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### AR-REIBP-SCOPE

REIBP is the special advance-payment regime under Ley 27.743, not a regime named Plan Aporte Especial. Existing eligible elections distinguish ordinary 2023–2027 coverage, a fivefold defined 2023 base at 0.45%, from regularised 2024–2027 coverage, a fourfold defined base at 0.50%, with its own currency/base rules. Eligibility, credits and original election deadlines matter; this Guide does not establish that a fresh 2026 election remains available. Specified gifts from related non-electors can trigger additional tax and require the complete special rules.

```json
{
  "act_article_or_scope": "Law27743Arts45–53whole/59–60whole/61openingneighbours",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "REIBP is the special advance-payment regime under Ley 27.743, not a regime named Plan Aporte Especial. Existing eligible elections distinguish ordinary 2023–2027 coverage, a fivefold defined 2023 base at 0.45%, from regularised 2024–2027 coverage, a fourfold defined base at 0.50%, with its own currency/base rules. Eligibility, credits and original election deadlines matter; this Guide does not establish that a fresh 2026 election remains available. Specified gifts from related non-electors can trigger additional tax and require the complete special rules.",
  "guide_lines": [
    123
  ],
  "id": "AR-REIBP-SCOPE",
  "official_url": "https://biblioteca.arca.gob.ar/dcp/LEY_C_027743_2024_06_27",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "0,45%"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/wealth-ar-reibp-law.txt",
  "source_key": "wealth-ar-reibp-law",
  "source_sha256": "8bac6921aa1ebb7e1be6f61bc7709d88b42b1eea0ec5c2383e3977764a320d27",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### AR-STABILITY

REIBP’s defined fiscal-stability protection extends through 2038, with the statutory 0.45%/0.50% ceiling through 2027 and 0.25% for 2028–2038 under its specified base and aggregate-national-asset-tax rules. It is not simply a guarantee ending in 2027 or an approximate 1.5% prepayment. The ordinary law separately provides a 0.25% 2027 schedule; future application still requires that year’s operative law.

```json
{
  "act_article_or_scope": "Arts59–60whole and63future2027table",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "REIBP’s defined fiscal-stability protection extends through 2038, with the statutory 0.45%/0.50% ceiling through 2027 and 0.25% for 2028–2038 under its specified base and aggregate-national-asset-tax rules. It is not simply a guarantee ending in 2027 or an approximate 1.5% prepayment. The ordinary law separately provides a 0.25% 2027 schedule; future application still requires that year’s operative law.",
  "guide_lines": [
    125
  ],
  "id": "AR-STABILITY",
  "official_url": "https://biblioteca.arca.gob.ar/dcp/LEY_C_027743_2024_06_27",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "2038"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/wealth-ar-reibp-law.txt",
  "source_key": "wealth-ar-reibp-law",
  "source_sha256": "8bac6921aa1ebb7e1be6f61bc7709d88b42b1eea0ec5c2383e3977764a320d27",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### CO-SUBJECT

The ordinary law targets resident individuals and qualifying estates, nonresident individuals/estates with Colombian exposure, and specified foreign non-filing entities subject to the detailed asset/portfolio/receivable/lease exclusions. It is not a general charge on Colombian companies. The charge arises on 1 January where net wealth reaches at least 72,000 UVT; retain the UVT base until the correct year’s official UVT is recovered rather than recycling the old COP 3,388 million or USD 850,000 conversions.

```json
{
  "act_article_or_scope": "Law2277Arts35–36/ET292-3/294-3whole",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "The ordinary law targets resident individuals and qualifying estates, nonresident individuals/estates with Colombian exposure, and specified foreign non-filing entities subject to the detailed asset/portfolio/receivable/lease exclusions. It is not a general charge on Colombian companies. The charge arises on 1 January where net wealth reaches at least 72,000 UVT; retain the UVT base until the correct year’s official UVT is recovered rather than recycling the old COP 3,388 million or USD 850,000 conversions.",
  "guide_lines": [
    130
  ],
  "id": "CO-SUBJECT",
  "official_url": "https://normograma.dian.gov.co/dian/compilacion/docs/ley_2277_2022.htm",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "primero (1) de enero"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/wealth-co-law.txt",
  "source_key": "wealth-co-law",
  "source_sha256": "8b833bfe02ad9ed667edc812937749a01b902d913fbfd35d659509d898bf5ce2",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### CO-BASE

Deduct the statutory liabilities and exclusions. The first 12,000 UVT of the qualifying habitual home is an exclusion from the taxable base, using the statutory net-to-gross proportion; it does not replace the initial net-wealth trigger. Permanent-establishment attribution, shares and foreign trust/foundation rights have separate valuation/look-through rules. The innovative-startup provisions require all specified conditions and change valuation; they are not a blanket active-business-share exemption. No general cultural/heirloom exemption is established by this source.

```json
{
  "act_article_or_scope": "Art37/ET295-3allparagraphs andvaluation/startupexceptions",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "Deduct the statutory liabilities and exclusions. The first 12,000 UVT of the qualifying habitual home is an exclusion from the taxable base, using the statutory net-to-gross proportion; it does not replace the initial net-wealth trigger. Permanent-establishment attribution, shares and foreign trust/foundation rights have separate valuation/look-through rules. The innovative-startup provisions require all specified conditions and change valuation; they are not a blanket active-business-share exemption. No general cultural/heirloom exemption is established by this source.",
  "guide_lines": [
    132
  ],
  "id": "CO-BASE",
  "official_url": "https://normograma.dian.gov.co/dian/compilacion/docs/ley_2277_2022.htm",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "doce mil (12.000) UVT"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/wealth-co-law.txt",
  "source_key": "wealth-co-law",
  "source_sha256": "8b833bfe02ad9ed667edc812937749a01b902d913fbfd35d659509d898bf5ce2",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### CO-TARIFF

The 1.5% band is expressly temporary for 2023–2026; the enacted schedule from 2027 has a 1% maximum unless later changed. Do not label the ordinary 2026 band as merely awaiting an unspecified constitutional review.

```json
{
  "act_article_or_scope": "Art38/ET296-3entiretable+paragraph,39chargeand40neighbour",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "The 1.5% band is expressly temporary for 2023–2026; the enacted schedule from 2027 has a 1% maximum unless later changed. Do not label the ordinary 2026 band as merely awaiting an unspecified constitutional review.",
  "guide_lines": [
    134,
    135,
    136,
    137,
    138,
    139,
    141
  ],
  "id": "CO-TARIFF",
  "official_url": "https://normograma.dian.gov.co/dian/compilacion/docs/ley_2277_2022.htm",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "72.000"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/wealth-co-law.txt",
  "source_key": "wealth-co-law",
  "source_sha256": "8b833bfe02ad9ed667edc812937749a01b902d913fbfd35d659509d898bf5ce2",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### CO-COURT

C-079/26 invalidated emergency Decree 1474/2025 and prescribed consequences for its taxes, including no declaration/assessment/collection of the affected direct taxes and specified refunds. This is not a judgment deleting the separate ordinary Ley 2277 individual tariff above. Any different 2026 emergency corporate charge needs its own current law and judicial status; it is outside this individual computation.

```json
{
  "act_article_or_scope": "C079/26actualdecisionandadjacentoperative1175–1205, notwholejudgment",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "C-079/26 invalidated emergency Decree 1474/2025 and prescribed consequences for its taxes, including no declaration/assessment/collection of the affected direct taxes and specified refunds. This is not a judgment deleting the separate ordinary Ley 2277 individual tariff above. Any different 2026 emergency corporate charge needs its own current law and judicial status; it is outside this individual computation.",
  "guide_lines": [
    143
  ],
  "id": "CO-COURT",
  "official_url": "https://www.corteconstitucional.gov.co/relatoria/2026/C-079-26.htm",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "1474 de 2025"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/wealth-co-court.txt",
  "source_key": "wealth-co-court",
  "source_sha256": "6cedda0c461ebea2f6440e207650c4391168803de2911c0451d76cd3ecbd0c9d",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### CO-CALENDAR

DIAN’s September 2026 notice identifies the ordinary wealth-tax population by 1 January 2026 and the 72,000-UVT trigger, and gives 14 September 2026 for its second instalment. That dated notice is not a complete annual return calendar. Form 420 is the original requested form topic, but the recovered live application supplies only a loading shell; current form/version and other deadlines remain execution prerequisites.

```json
{
  "act_article_or_scope": "ActualSeptember2026wealthparagraph andneighbours",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "DIAN’s September 2026 notice identifies the ordinary wealth-tax population by 1 January 2026 and the 72,000-UVT trigger, and gives 14 September 2026 for its second instalment. That dated notice is not a complete annual return calendar. Form 420 is the original requested form topic, but the recovered live application supplies only a loading shell; current form/version and other deadlines remain execution prerequisites.",
  "guide_lines": [
    145
  ],
  "id": "CO-CALENDAR",
  "official_url": "https://www.dian.gov.co/Paginas/Vencimientos-tributarios-septiembre-2026.aspx",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "14 de septiembre"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/wealth-co-sept.txt",
  "source_key": "wealth-co-sept",
  "source_sha256": "406defa296a0996cd8c1d91a995b9b7189f5024750e129a6b433b4aaecebd346",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### UY-BASE

The recovered DGI guide expressly concerns assets at 31 December 2025: minimum UYU 6,653,000 for an individual/estate and UYU 13,306,000 for a qualifying family unit. Spouses can elect the stated joint treatment or separate ownership/community allocation. These supersede the old approximate UYU 5.6 million for that period, but are not a verified year-end 2026 indexed allowance. Use the actual local asset valuations and household-effects computation; it is not a universal worldwide fair-market-value tax.

```json
{
  "act_article_or_scope": "DGI2025guide operativeintro/home/debts/household/minimum assigned pp1–7/12",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "The recovered DGI guide expressly concerns assets at 31 December 2025: minimum UYU 6,653,000 for an individual/estate and UYU 13,306,000 for a qualifying family unit. Spouses can elect the stated joint treatment or separate ownership/community allocation. These supersede the old approximate UYU 5.6 million for that period, but are not a verified year-end 2026 indexed allowance. Use the actual local asset valuations and household-effects computation; it is not a universal worldwide fair-market-value tax.",
  "guide_lines": [
    150
  ],
  "id": "UY-BASE",
  "official_url": "https://www.gub.uy/direccion-general-impositiva/sites/direccion-general-impositiva/files/documentos/publicaciones/PATRIMONIO%20PF%202025.pdf",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "6:653.000"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/wealth-uy.txt",
  "source_key": "wealth-uy",
  "source_sha256": "dd17e346983d02b3e5cc4b6b4d6ead8254181b3f61cd04f023f34671163a7f89",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### UY-HOME-DEBT

The qualifying home receives a 50% deduction up to the applicable minimum, with the actual-home and estate exclusions. Debt relief is restricted to the defined domestic financial creditors, generally average month-end balances supported by creditor certification, and is absorbed first by specified foreign/exempt/noncomputable assets. Do not deduct all face-value liabilities or assume a foreign-bank loan qualifies.

```json
{
  "act_article_or_scope": "Wholehomevaluationintro anddebt1.1/1.2/householdneighbours",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "The qualifying home receives a 50% deduction up to the applicable minimum, with the actual-home and estate exclusions. Debt relief is restricted to the defined domestic financial creditors, generally average month-end balances supported by creditor certification, and is absorbed first by specified foreign/exempt/noncomputable assets. Do not deduct all face-value liabilities or assume a foreign-bank loan qualifies.",
  "guide_lines": [
    152
  ],
  "id": "UY-HOME-DEBT",
  "official_url": "https://www.gub.uy/direccion-general-impositiva/sites/direccion-general-impositiva/files/documentos/publicaciones/PATRIMONIO%20PF%202025.pdf",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "50%"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/wealth-uy.txt",
  "source_key": "wealth-uy",
  "source_sha256": "dd17e346983d02b3e5cc4b6b4d6ead8254181b3f61cd04f023f34671163a7f89",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### UY-RATES

For the recovered 2025 period, DGI publishes 0.10% on taxable excess for the general population and a separate 0.70%/1.10%/1.40%/1.50% progressive schedule for nonresidents who do not pay IRNR. Thus neither the old 0.2%–0.7% resident schedule nor a flat 1.5% for every nonresident is reliable. The page URL’s historical suffix does not override its explicit 2025 title and table. The 2026 base, rate applicability and filing calendar must be confirmed from the current period’s instruments before execution; the old universal August filing claim is not established.

```json
{
  "act_article_or_scope": "Wholeoperative2025ratepublication16Jan2026, generalandnonIRNRnonresidenttables",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "For the recovered 2025 period, DGI publishes 0.10% on taxable excess for the general population and a separate 0.70%/1.10%/1.40%/1.50% progressive schedule for nonresidents who do not pay IRNR. Thus neither the old 0.2%–0.7% resident schedule nor a flat 1.5% for every nonresident is reliable. The page URL’s historical suffix does not override its explicit 2025 title and table. The 2026 base, rate applicability and filing calendar must be confirmed from the current period’s instruments before execution; the old universal August filing claim is not established.",
  "guide_lines": [
    154
  ],
  "id": "UY-RATES",
  "official_url": "https://www.gub.uy/direccion-general-impositiva/comunicacion/publicaciones/tasas-del-impuesto-patrimonio-personas-fisicas-2023",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "0,10%"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/wealth-uy-rates.txt",
  "source_key": "wealth-uy-rates",
  "source_sha256": "2a965df3174fcb54b4a7ec6be7596928e2c4b6144d14798e4fc9992ced474e0d",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### FR-SCOPE

The real-estate-only CGI 964 structure is effective from 1 January 2018, replacing the former ISF framework. IFI applies when the household’s net taxable immovable wealth strictly exceeds EUR 1,300,000 on 1 January. Residents generally include worldwide taxable immovables/indirect property interests; nonresidents French exposure. A qualifying new resident not resident in any of the five preceding calendar years has the specified temporary French-property-only treatment through the fifth year following arrival. Household aggregation and exceptions must be checked.

```json
{
  "act_article_or_scope": "CGI964whole, sourceeffective2018captured20Mar2026;965/966currentbodyseparatelyread",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "The real-estate-only CGI 964 structure is effective from 1 January 2018, replacing the former ISF framework. IFI applies when the household’s net taxable immovable wealth strictly exceeds EUR 1,300,000 on 1 January. Residents generally include worldwide taxable immovables/indirect property interests; nonresidents French exposure. A qualifying new resident not resident in any of the five preceding calendar years has the specified temporary French-property-only treatment through the fifth year following arrival. Household aggregation and exceptions must be checked.",
  "guide_lines": [
    159
  ],
  "id": "FR-SCOPE",
  "official_url": "https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000036384999/2026-03-20",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "supérieure à 1 300 000 €"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/wealth-fr-964-web.json",
  "source_key": "fr964",
  "source_sha256": "baaf5238f97de6a3575d7e285a83445adfd064c6a306062c2a69857137cbb940",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### FR-INDIRECT

Include the taxable property fraction of company, SCPI or OPCI interests, rather than automatically the full security value. Active-company, minority-holding, control and enjoyment exceptions require the actual statutory facts; own property management is not automatically an operating business. Use the statutory property valuation and ownership conditions.

```json
{
  "act_article_or_scope": "CGI965/966whole119–161 andneighbours,currentpageversion9Sep2026",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "Include the taxable property fraction of company, SCPI or OPCI interests, rather than automatically the full security value. Active-company, minority-holding, control and enjoyment exceptions require the actual statutory facts; own property management is not automatically an operating business. Use the statutory property valuation and ownership conditions.",
  "guide_lines": [
    161
  ],
  "id": "FR-INDIRECT",
  "official_url": "https://www.legifrance.gouv.fr/codes/section_lc/LEGITEXT000006069577/LEGISCTA000036384995/",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "fraction de leur valeur"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/wealth-tax/fr-current-unversioned.json",
  "source_key": "frcurrent",
  "source_sha256": "3d5960f817a479c748c60267bd951c046c751fb8c3bd3df376f16f1c228d5812",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### FR-HOME

The authority explains a 30% value reduction for the qualifying principal home. The legal ownership and household conditions must be checked; this is not a 30% reduction of all immovable holdings.

```json
{
  "act_article_or_scope": "Actual authority calculation page home paragraph and debt/cap neighbours, dated explanation",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "The authority explains a 30% value reduction for the qualifying principal home. The legal ownership and household conditions must be checked; this is not a 30% reduction of all immovable holdings.",
  "guide_lines": [
    163
  ],
  "id": "FR-HOME",
  "official_url": "https://www.impots.gouv.fr/particulier/calcul-de-lifi",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "30 %"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/wealth-fr-calc.txt",
  "source_key": "wealth-fr-calc",
  "source_sha256": "2bb826561247a7773a8b3c84f86bf0f389b1bbeba83a11fcdeaf252072ce67fd",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### FR-RATE

Only after the strict scope threshold is crossed do all applicable slices, including the EUR 800,000–1,300,000 slice, enter the tariff. For wealth in the statutory EUR 1.3–1.4 million range, subtract EUR 17,500 − 1.25% × taxable wealth. At exactly EUR 1,300,000 there is no IFI under the strict scope test; at EUR 1,350,000 the gross tariff is EUR 2,850, décote EUR 625, and IFI EUR 2,225 before other relief.

```json
{
  "act_article_or_scope": "CGI977entiretableandIIwhole",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "Only after the strict scope threshold is crossed do all applicable slices, including the EUR 800,000–1,300,000 slice, enter the tariff. For wealth in the statutory EUR 1.3–1.4 million range, subtract EUR 17,500 − 1.25% × taxable wealth. At exactly EUR 1,300,000 there is no IFI under the strict scope test; at EUR 1,350,000 the gross tariff is EUR 2,850, décote EUR 625, and IFI EUR 2,225 before other relief.",
  "guide_lines": [
    165,
    166,
    167,
    168,
    169,
    170,
    171,
    172,
    174
  ],
  "id": "FR-RATE",
  "official_url": "https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000036385041",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "800 000 €"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/wealth-fr-web.json",
  "source_key": "fr977",
  "source_sha256": "9a3cc2a16aa68897c35838ef9f6eaec75b1a311d4f6e9d0e2689af62716d2e3c",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### FR-DEBT

Debt must exist at 1 January, be borne by the taxpayer and concern taxable assets, subject to the statutory acquisition/repair/tax categories and proportional inclusion. Bullet/open-ended loans, family and controlled-entity borrowing have special limits and proof exceptions. If taxable assets exceed EUR 5 million and debts exceed 60% of their value, only half the excess debt is ordinarily deductible, subject to the non-mainly-tax-purpose exception.

```json
{
  "act_article_or_scope": "CGI974whole302–315with973/975neighbours",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "Debt must exist at 1 January, be borne by the taxpayer and concern taxable assets, subject to the statutory acquisition/repair/tax categories and proportional inclusion. Bullet/open-ended loans, family and controlled-entity borrowing have special limits and proof exceptions. If taxable assets exceed EUR 5 million and debts exceed 60% of their value, only half the excess debt is ordinarily deductible, subject to the non-mainly-tax-purpose exception.",
  "guide_lines": [
    176
  ],
  "id": "FR-DEBT",
  "official_url": "https://www.legifrance.gouv.fr/codes/section_lc/LEGITEXT000006069577/LEGISCTA000036384995/2026-07-20/",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "5 millions d'euros"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/wealth-tax/fr-operative-web.json",
  "source_key": "frchapter",
  "source_sha256": "ba40bd8c0d946cc41ad33ecd0f0719d41a90f630dd23c1b5e086b8ceee4b7589",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### FR-EXEMPTIONS

Professional-property relief has distinct own-business, partnership, corporate-director/pay/holding and leasing conditions; it is not triggered by a business label. Conditional 75% forestry relief and specific long-term rural-lease relief exist, but their incorporated certificate/management/ownership conditions must be recovered before use. Do not infer a general rent-capped-property exemption. The 2026 amendment’s separate relief for assets subject to article 235 ter C depends on its financial-year application; no automatic 2026 IFI exemption is assumed here.

```json
{
  "act_article_or_scope": "CGI975whole326–360updated21Feb2026;976assignedforest/leasebranches371–377",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "Professional-property relief has distinct own-business, partnership, corporate-director/pay/holding and leasing conditions; it is not triggered by a business label. Conditional 75% forestry relief and specific long-term rural-lease relief exist, but their incorporated certificate/management/ownership conditions must be recovered before use. Do not infer a general rent-capped-property exemption. The 2026 amendment’s separate relief for assets subject to article 235 ter C depends on its financial-year application; no automatic 2026 IFI exemption is assumed here.",
  "guide_lines": [
    178
  ],
  "id": "FR-EXEMPTIONS",
  "official_url": "https://www.legifrance.gouv.fr/codes/section_lc/LEGITEXT000006069577/LEGISCTA000036384995/2026-07-20/",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "activité industrielle, commerciale, artisanale, agricole ou libérale"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/wealth-tax/fr-operative-web.json",
  "source_key": "frchapter",
  "source_sha256": "ba40bd8c0d946cc41ad33ecd0f0719d41a90f630dd23c1b5e086b8ceee4b7589",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### FR-CAP

For the resident route, the statutory 75% cap compares the defined IFI and income-related taxes with prior-year worldwide income under its own inclusions and anti-abuse rule. It reduces IFI; it is not a promise that all excess taxes are refunded. Foreign similar-property-tax credit is limited to the corresponding foreign taxable-property fraction. File the prescribed immovable-wealth annex with the income return, commonly Form 2042-IFI, including gross/net values and supporting schedules; recover that campaign’s exact deadline.

```json
{
  "act_article_or_scope": "CGI979whole450–455/980whole465;982whole488–492and983neighbours",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "For the resident route, the statutory 75% cap compares the defined IFI and income-related taxes with prior-year worldwide income under its own inclusions and anti-abuse rule. It reduces IFI; it is not a promise that all excess taxes are refunded. Foreign similar-property-tax credit is limited to the corresponding foreign taxable-property fraction. File the prescribed immovable-wealth annex with the income return, commonly Form 2042-IFI, including gross/net values and supporting schedules; recover that campaign’s exact deadline.",
  "guide_lines": [
    180
  ],
  "id": "FR-CAP",
  "official_url": "https://www.legifrance.gouv.fr/codes/section_lc/LEGITEXT000006069577/LEGISCTA000036384995/2026-07-20/",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "75 %"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/wealth-tax/fr-operative-web.json",
  "source_key": "frchapter",
  "source_sha256": "ba40bd8c0d946cc41ad33ecd0f0719d41a90f630dd23c1b5e086b8ceee4b7589",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### NL-PARAMETERS

The 2026 provisional-assessment method uses 1 January asset values, a 1.28% provisional bank yield, fixed 6.00% other-asset yield and 2.70% provisional debt yield. Bank/debt percentages become final after year-end; do not present them as final statutory investment performance. The rate is 36%; allowance EUR 59,357 per person or EUR 118,714 for fiscal partners, with a EUR 3,800 single debt threshold before eligible debt enters the method.

```json
{
  "act_article_or_scope": "Whole2026authoritymethodandexamples17–176",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "The 2026 provisional-assessment method uses 1 January asset values, a 1.28% provisional bank yield, fixed 6.00% other-asset yield and 2.70% provisional debt yield. Bank/debt percentages become final after year-end; do not present them as final statutory investment performance. The rate is 36%; allowance EUR 59,357 per person or EUR 118,714 for fiscal partners, with a EUR 3,800 single debt threshold before eligible debt enters the method.",
  "guide_lines": [
    185
  ],
  "id": "NL-PARAMETERS",
  "official_url": "https://www.belastingdienst.nl/wps/wcm/connect/nl/box-3/content/berekening-box-3-inkomen-2026",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "1,28%"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/wealth-nl.txt",
  "source_key": "wealth-nl",
  "source_sha256": "9174ecb71d657ea38b01360d4032e59bde24309179fb42ac552d4acb3157500a",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### NL-METHOD

Compute bank and other-asset yields, subtract yield on eligible debt, then apply the taxable-ground/net-ground proportion after the allowance, and tax that apportioned return. Thus 6.00% × 36% = 2.16% is only a pre-allowance illustration for the other-asset class, not a universal effective wealth-tax rate. The old 6.04% × 36% = 2.1744% arithmetic does not supply current parameters. The authority says a lower actual return can be reflected in the 2026 return; this does not mean every taxpayer is automatically assessed solely on actual return or that a particular 2027–2028 reform date is enacted.

```json
{
  "act_article_or_scope": "Actualsixmethodstepswithactualreturnintroandexamples",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "Compute bank and other-asset yields, subtract yield on eligible debt, then apply the taxable-ground/net-ground proportion after the allowance, and tax that apportioned return. Thus 6.00% × 36% = 2.16% is only a pre-allowance illustration for the other-asset class, not a universal effective wealth-tax rate. The old 6.04% × 36% = 2.1744% arithmetic does not supply current parameters. The authority says a lower actual return can be reflected in the 2026 return; this does not mean every taxpayer is automatically assessed solely on actual return or that a particular 2027–2028 reform date is enacted.",
  "guide_lines": [
    187
  ],
  "id": "NL-METHOD",
  "official_url": "https://www.belastingdienst.nl/wps/wcm/connect/nl/box-3/content/berekening-box-3-inkomen-2026",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "werkelijke rendement"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/wealth-nl.txt",
  "source_key": "wealth-nl",
  "source_sha256": "9174ecb71d657ea38b01360d4032e59bde24309179fb42ac552d4acb3157500a",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### BE-ACCOUNT

Belgium’s annual securities-account tax concerns the account itself, not EUR 1 million per holder. For an average taxable account value exceeding EUR 1,000,000, the rate is 0.15% where the reference period ends by 31 May 2026 and 0.30% where it ends from 1 June 2026. Tax is capped at 10% of the excess over EUR 1 million near the threshold. Scope distinguishes residents’ Belgian/foreign accounts, nonresident permanent establishments and other nonresidents’ Belgian-intermediary accounts; the ordinary reference period is 1 October–30 September. This asset-specific tax does not prove the absence of every other wealth-related tax.

```json
{
  "act_article_or_scope": "FODwholeactual195–392;ProgrammeLaw30May2026/WDRT2013–6/20196asexplained",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "Belgium’s annual securities-account tax concerns the account itself, not EUR 1 million per holder. For an average taxable account value exceeding EUR 1,000,000, the rate is 0.15% where the reference period ends by 31 May 2026 and 0.30% where it ends from 1 June 2026. Tax is capped at 10% of the excess over EUR 1 million near the threshold. Scope distinguishes residents’ Belgian/foreign accounts, nonresident permanent establishments and other nonresidents’ Belgian-intermediary accounts; the ordinary reference period is 1 October–30 September. This asset-specific tax does not prove the absence of every other wealth-related tax.",
  "guide_lines": [
    192
  ],
  "id": "BE-ACCOUNT",
  "official_url": "https://finances.belgium.be/fr/node/14191",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "0,15 %"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/wealth-tax/be-and-de-web.json",
  "source_key": "be",
  "source_sha256": "00dd9e37fd5e622a1c1c28b787fd162cac28b7d9eabd96d6196a9bcf7ffd8e22",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### BE-FILING

A Belgian intermediary or approved foreign representative normally handles the charge. Otherwise holders may have to declare/pay, subject to proof of prior fulfilment. The holder’s ordinary return deadline is 15 July following the reference-period end and payment 31 August; intermediary return/payment is the twentieth day of the third following month. Correct rate-specific forms and anti-abuse rules must be checked.

```json
{
  "act_article_or_scope": "Actualfiling/paymentandintermediaryclauseswhole255–360",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "A Belgian intermediary or approved foreign representative normally handles the charge. Otherwise holders may have to declare/pay, subject to proof of prior fulfilment. The holder’s ordinary return deadline is 15 July following the reference-period end and payment 31 August; intermediary return/payment is the twentieth day of the third following month. Correct rate-specific forms and anti-abuse rules must be checked.",
  "guide_lines": [
    194
  ],
  "id": "BE-FILING",
  "official_url": "https://finances.belgium.be/fr/node/14191",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "15 juli"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/wealth-tax/be-and-de-web.json",
  "source_key": "be",
  "source_sha256": "00dd9e37fd5e622a1c1c28b787fd162cac28b7d9eabd96d6196a9bcf7ffd8e22",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### IT-AMENDMENT

Italy remains a separate IVIE/IVAFE workstream. The enacted amendment replaces IVIE’s old 0.76% with 1.06%, and introduces 4 per thousand from 2024 for financial products in the specified privileged jurisdictions. Do not repeat the old 0.76%/universal 0.2% pair as a current complete result. Ordinary IVAFE bases/rates, exemptions, timing, credits and any later changes need the full current Italian provisions before computation; no claim of a historic general Italian wealth-tax repeal is established by this amendment.

```json
{
  "act_article_or_scope": "Law213/2023Art1(91)(a)/(b)whole1959–1978and90/92neighbours",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "Italy remains a separate IVIE/IVAFE workstream. The enacted amendment replaces IVIE’s old 0.76% with 1.06%, and introduces 4 per thousand from 2024 for financial products in the specified privileged jurisdictions. Do not repeat the old 0.76%/universal 0.2% pair as a current complete result. Ordinary IVAFE bases/rates, exemptions, timing, credits and any later changes need the full current Italian provisions before computation; no claim of a historic general Italian wealth-tax repeal is established by this amendment.",
  "guide_lines": [
    196
  ],
  "id": "IT-AMENDMENT",
  "official_url": "https://www.gazzettaufficiale.it/atto/serie_generale/caricaArticoloDefault/originario?atto.codiceRedazionale=24A00001&atto.dataPubblicazioneGazzetta=2024-01-18&atto.tipoProvvedimento=LEGGE",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "« 0,76 per cento»"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/wealth-tax/wealthFinalBodies2.json",
  "source_key": "it",
  "source_sha256": "dbb493f107a995d187f9f0cf04d869159261dfa16696edfd97e45498e82e2446",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### DE-HISTORY

A 2003 official legislative record explains that wealth tax could no longer be collected for periods from 1997 after the constitutional decision and absent a compliant replacement. It also distinguishes non-collection from formal repeal and records opposition to the proposed repeal. It is historical evidence, not an enacted 2026 restoration or a complete current negative-tax opinion. The SPD/Greens proposal status remains separately unconfirmed.

```json
{
  "act_article_or_scope": "Bundestag15/4085Feb2003pp1/6–7wholehistoricalexplanation/governmentrejection",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "A 2003 official legislative record explains that wealth tax could no longer be collected for periods from 1997 after the constitutional decision and absent a compliant replacement. It also distinguishes non-collection from formal repeal and records opposition to the proposed repeal. It is historical evidence, not an enacted 2026 restoration or a complete current negative-tax opinion. The SPD/Greens proposal status remains separately unconfirmed.",
  "guide_lines": [
    198
  ],
  "id": "DE-HISTORY",
  "official_url": "https://dserver.bundestag.de/btd/15/004/1500408.pdf",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "ab 1997 nicht mehr weiter erhoben"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/wealth-tax/wealthLastScopes.json",
  "source_key": "de",
  "source_sha256": "c5bd292ae66d038fa66291b3f27e2145384e7fb6b71fed6782b5055b794095c0",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### UK-DATED

The Treasury stated on 7 March 2025 that the UK had no standalone wealth tax. Treat that as a dated statement. The original Wealth Tax Commission 2020 one-off 5% above GBP 500,000 proposal and asserted 2024 Labour rejection have not been established from their actual sources here; neither supplies a current charge or exemption.

```json
{
  "act_article_or_scope": "Treasurywrittenanswer34320,7March2025whole",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "The Treasury stated on 7 March 2025 that the UK had no standalone wealth tax. Treat that as a dated statement. The original Wealth Tax Commission 2020 one-off 5% above GBP 500,000 proposal and asserted 2024 Labour rejection have not been established from their actual sources here; neither supplies a current charge or exemption.",
  "guide_lines": [
    200
  ],
  "id": "UK-DATED",
  "official_url": "https://questions-statements.parliament.uk/written-questions/detail/2025-02-27/34320/",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "does not have a standalone wealth tax"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/wealth-tax/historical-2.json",
  "source_key": "uk",
  "source_sha256": "304f0201ca0aebb0f5aed549ffc46f2052ddfce90eca8916dedb59e6907e5c07",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### US-PROPOSAL

The recovered federal record identifies S.4246 as introduced in the Senate on 26 March 2026 by Elizabeth Warren and referred to Finance. An introduced version is not an enacted charging statute. Current California AB 259, New York AB 6010, Warren/Sanders section 2901–2902 proposals, Senator Wyden’s mark-to-market proposal and a comprehensive current federal absence claim remain individually unconfirmed; unrealised-gain income taxation must not be equated automatically with a net-wealth charge.

```json
{
  "act_article_or_scope": "GovInfoS4246ISmetadataintroduced26March2026whole21–64",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "The recovered federal record identifies S.4246 as introduced in the Senate on 26 March 2026 by Elizabeth Warren and referred to Finance. An introduced version is not an enacted charging statute. Current California AB 259, New York AB 6010, Warren/Sanders section 2901–2902 proposals, Senator Wyden’s mark-to-market proposal and a comprehensive current federal absence claim remain individually unconfirmed; unrealised-gain income taxation must not be equated automatically with a net-wealth charge.",
  "guide_lines": [
    202
  ],
  "id": "US-PROPOSAL",
  "official_url": "https://www.govinfo.gov/app/details/BILLS-119s4246is",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "Introduced in Senate (IS)"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/wealth-tax/us-is.json",
  "source_key": "us",
  "source_sha256": "165a82aa4e9d2f870695a841238c47968483407a6b6872bce720cdc906ca1799",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### BR-OMISSION

Brazil’s official ADO 55 record reports a finding of unconstitutional congressional omission concerning the complementary law for CF article 153(VII), communicated without a fixed congressional deadline. The judgment is not itself a rate/base charging code. Current PEC 162/2022 status and the old CSLL comparison need separate primary proof before use; the old pending-proposal summary is not current execution clearance.

```json
{
  "act_article_or_scope": "SenadoADO55officialrecordwhole19–38,judgment6Nov2025/publication13Apr2026",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "Brazil’s official ADO 55 record reports a finding of unconstitutional congressional omission concerning the complementary law for CF article 153(VII), communicated without a fixed congressional deadline. The judgment is not itself a rate/base charging code. Current PEC 162/2022 status and the old CSLL comparison need separate primary proof before use; the old pending-proposal summary is not current execution clearance.",
  "guide_lines": [
    204
  ],
  "id": "BR-OMISSION",
  "official_url": "https://legis.senado.leg.br/norma/43040855",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "Omissão inconstitucional reconhecida"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/wealth-tax/wealthLastScopes.json",
  "source_key": "br",
  "source_sha256": "c5bd292ae66d038fa66291b3f27e2145384e7fb6b71fed6782b5055b794095c0",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### SE-HISTORY

Sweden’s official record identifies repeal from 1 January 2008 and preserves older law for assessment in 2007 and earlier. This explains the common description of abolition for the 2007 wealth year; distinguish tax year from assessment/effective date. It does not establish a complete 2026 asset-tax exemption.

```json
{
  "act_article_or_scope": "RiksdagSFS1997323headerand20071403transitionwhole",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "Sweden’s official record identifies repeal from 1 January 2008 and preserves older law for assessment in 2007 and earlier. This explains the common description of abolition for the 2007 wealth year; distinguish tax year from assessment/effective date. It does not establish a complete 2026 asset-tax exemption.",
  "guide_lines": [
    206
  ],
  "id": "SE-HISTORY",
  "official_url": "https://www.riksdagen.se/sv/dokument-och-lagar/dokument/svensk-forfattningssamling/lag-1997323-om-statlig-formogenhetsskatt_sfs-1997-323/",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "2008-01-01"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/wealth-tax/sources/se.txt",
  "source_key": "se",
  "source_sha256": "8fe81655162e09027db0e3a23b9a61c0fd4c77368cbaf946f5b4c76c08e40878",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### DK-HISTORY

Denmark’s ministerial answer identifies abolition from income year 1997 under Law 1105 of 20 December 1995. Do not turn this historical repeal into an exemption from all current asset or property levies.

```json
{
  "act_article_or_scope": "Ministeranswer8Apr2022wholeoperative39–118",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "Denmark’s ministerial answer identifies abolition from income year 1997 under Law 1105 of 20 December 1995. Do not turn this historical repeal into an exemption from all current asset or property levies.",
  "guide_lines": [
    208
  ],
  "id": "DK-HISTORY",
  "official_url": "https://www.ft.dk/samling/20211/almdel/sau/spm/254/svar/1872957/2557507/index.htm",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "1997"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/wealth-tax/dk-actual-web.json",
  "source_key": "dk",
  "source_sha256": "a3813a78931b7dc059f4c5fdfecc15129cca469c7748f729ae8cb29f2f06888a",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### FI-HISTORY

Finland’s Law 1141/2005 repealed the Wealth Tax Act from 1 January 2006 while preserving older assessment, collection and appeal matters. The actual statute, rather than a blank Finlex application shell, supports this historical date.

```json
{
  "act_article_or_scope": "ActualstatutebookLaw1141/2005sections1–2wholeprinted5101/PDF1andnextlawneighbour",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "Finland’s Law 1141/2005 repealed the Wealth Tax Act from 1 January 2006 while preserving older assessment, collection and appeal matters. The actual statute, rather than a blank Finlex application shell, supports this historical date.",
  "guide_lines": [
    210
  ],
  "id": "FI-HISTORY",
  "official_url": "https://www.finlex.fi/files/extra/statute-book-of-finland-pdf/fin/2005/20050190.pdf",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "1 päivänä tammikuuta 2006"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/wealth-tax/sources/fi-book.txt",
  "source_key": "fi",
  "source_sha256": "7835ebb7f0f186db16166be0ef15d2de5468ec63391de28b1fdf9ed54ae2534f",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### IS-HISTORY

Iceland’s ministerial answer reports wealth-tax assessments for 2010–2014 and the supplementary charge for 2010–2013. The old phrase abolished 2014 is ambiguous about assessment versus wealth year; this source does not establish a current annual charge or a comprehensive 2026 absence opinion.

```json
{
  "act_article_or_scope": "Althingi2014–15ministeranswer1642wholeoperative10–52",
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "Iceland’s ministerial answer reports wealth-tax assessments for 2010–2014 and the supplementary charge for 2010–2013. The old phrase abolished 2014 is ambiguous about assessment versus wealth year; this source does not establish a current annual charge or a comprehensive 2026 absence opinion.",
  "guide_lines": [
    212
  ],
  "id": "IS-HISTORY",
  "official_url": "https://www.althingi.is/altext/144/s/1642.html",
  "quote_mode": "SHORT exact source-language extracts; actual whole assigned operative conditions and material neighbours read. No full-paragraph quota is imposed. Protected-source total extracts limited; own paraphrase carries full conditions.",
  "short_exact_native_quotes": [
    "gjalda 2010"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/wealth-tax/historical-2.json",
  "source_key": "is",
  "source_sha256": "304f0201ca0aebb0f5aed549ffc46f2052ddfce90eca8916dedb59e6907e5c07",
  "source_version_basis": "Actual retained primary body personally read on 16 November 2026 within the assigned operative scope and material neighbours. Legal dates and limitations in the claim control."
}
```

### CASE-MADRID

Hypothetical/derived arithmetic: 8000000-700000=7300000; IPbefore71362.33+(7300000-5347998.03)*.021=112354.37137; shadow39915.97+(7300000-5347998.03)*.021=80908.01137; rebate31446.36; IP80908.01; solidarity0 afterpaidIP.

```json
{
  "act_article_or_scope": [
    "DLeg1/2010current10July2026,wholeIPchapterArts19/20andDT7whole2910–2916",
    "Art30wholeincludingstatefallbackandall8bands,Art29/31neighbours",
    "Ley38/2022Art3.Unos–Once;RDL8/2023Art17 overlay separately read",
    "Art3.Once entire table"
  ],
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "All supplied assumptions remain binding; this is not a statutory quoted bill. 8000000-700000=7300000; IPbefore71362.33+(7300000-5347998.03)*.021=112354.37137; shadow39915.97+(7300000-5347998.03)*.021=80908.01137; rebate31446.36; IP80908.01; solidarity0 afterpaidIP.",
  "component_rule_ids": [
    "ES-MADRID-LAW",
    "ES-IP-DEFAULT-TARIFF",
    "ES-ITSGF-SCOPE",
    "ES-ITSGF-TARIFF"
  ],
  "guide_lines": [
    75
  ],
  "id": "CASE-MADRID",
  "official_url": [
    "https://www.boe.es/buscar/act.php?id=BOCM-m-2010-90068",
    "https://www.boe.es/buscar/act.php?id=BOE-A-1991-14392",
    "https://www.boe.es/buscar/act.php?id=BOE-A-2022-22684",
    "https://www.boe.es/buscar/act.php?id=BOE-A-2022-22684"
  ],
  "quote_mode": "Actually verified component-native extracts; arithmetic independently recomputed with Decimal and oa-check. No invented quote for derived result.",
  "short_exact_native_quotes": [
    "700.000 euros"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_files": [
    {
      "file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/wealth-tax/madrid-law-web.json",
      "sha256": "c060028afc198f881505fc81666a6764d1936c5c252f2b9d6a91b46b62a15cc2"
    },
    {
      "file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/wealth-es-ip-law.txt",
      "sha256": "5b5385fc1f94cd23ee01fd18bdc02d55370ba2b9558c7ee4ccc8cf2c8c2f52cf"
    },
    {
      "file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/wealth-es-solid-law.txt",
      "sha256": "1495f87d30efbafb6e06650ff0a367b99360e19244616641c5dd625e9ddb5d20"
    },
    {
      "file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/wealth-es-solid-law.txt",
      "sha256": "1495f87d30efbafb6e06650ff0a367b99360e19244616641c5dd625e9ddb5d20"
    }
  ]
}
```

### CASE-CATALONIA

Hypothetical/derived arithmetic: 8000000-500000=7500000;74930.46+(7500000-5347998.03)*.02205=122382.1034385;max(0,80908.01137-122382.1034385)=0.

```json
{
  "act_article_or_scope": [
    "CatalunyaCode621-1/621-2 andDT1 all3pages",
    "Ley38/2022Art3.Unos–Once;RDL8/2023Art17 overlay separately read",
    "Art3.Once entire table"
  ],
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "All supplied assumptions remain binding; this is not a statutory quoted bill. 8000000-500000=7500000;74930.46+(7500000-5347998.03)*.02205=122382.1034385;max(0,80908.01137-122382.1034385)=0.",
  "component_rule_ids": [
    "ES-CAT",
    "ES-ITSGF-SCOPE",
    "ES-ITSGF-TARIFF"
  ],
  "guide_lines": [
    76
  ],
  "id": "CASE-CATALONIA",
  "official_url": [
    "https://economia.gencat.cat/web/.content/70_tributs/Normativa/Refoses/IP.pdf",
    "https://www.boe.es/buscar/act.php?id=BOE-A-2022-22684",
    "https://www.boe.es/buscar/act.php?id=BOE-A-2022-22684"
  ],
  "quote_mode": "Actually verified component-native extracts; arithmetic independently recomputed with Decimal and oa-check. No invented quote for derived result.",
  "short_exact_native_quotes": [
    "500.000 euros"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_files": [
    {
      "file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-finish-2026-11-14/lane-1/resume-2026/wealth-evidence/wealth-tax/sources/cat.txt",
      "sha256": "79b829ed5bf47fb077c10dacf825e37011517b49d76f08dd1ef4851ef7180775"
    },
    {
      "file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/wealth-es-solid-law.txt",
      "sha256": "1495f87d30efbafb6e06650ff0a367b99360e19244616641c5dd625e9ddb5d20"
    },
    {
      "file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/wealth-es-solid-law.txt",
      "sha256": "1495f87d30efbafb6e06650ff0a367b99360e19244616641c5dd625e9ddb5d20"
    }
  ]
}
```

### CASE-FRANCE

Hypothetical/derived arithmetic: At1300000 strictscopefalse=0;1350000 gross2850 minusdecote625 =2225. Nootherrelief assumed.

```json
{
  "act_article_or_scope": [
    "CGI964whole, sourceeffective2018captured20Mar2026;965/966currentbodyseparatelyread",
    "CGI977entiretableandIIwhole"
  ],
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "All supplied assumptions remain binding; this is not a statutory quoted bill. At1300000 strictscopefalse=0;1350000 gross2850 minusdecote625 =2225. Nootherrelief assumed.",
  "component_rule_ids": [
    "FR-SCOPE",
    "FR-RATE"
  ],
  "guide_lines": [
    174
  ],
  "id": "CASE-FRANCE",
  "official_url": [
    "https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000036384999/2026-03-20",
    "https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000036385041"
  ],
  "quote_mode": "Actually verified component-native extracts; arithmetic independently recomputed with Decimal and oa-check. No invented quote for derived result.",
  "short_exact_native_quotes": [
    "supérieure à 1 300 000 €"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_files": [
    {
      "file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/wealth-fr-964-web.json",
      "sha256": "baaf5238f97de6a3575d7e285a83445adfd064c6a306062c2a69857137cbb940"
    },
    {
      "file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/wealth-fr-web.json",
      "sha256": "9a3cc2a16aa68897c35838ef9f6eaec75b1a311d4f6e9d0e2689af62716d2e3c"
    }
  ]
}
```

### CASE-NL

Hypothetical/derived arithmetic: 6.04*.36=2.1744 historical;6.00*.36=2.16 currentpreallowanceillustrationonly.

```json
{
  "act_article_or_scope": [
    "Whole2026authoritymethodandexamples17–176",
    "Actualsixmethodstepswithactualreturnintroandexamples"
  ],
  "actual_read_on": "2026-11-16",
  "complete_condition_paraphrase": "All supplied assumptions remain binding; this is not a statutory quoted bill. 6.04*.36=2.1744 historical;6.00*.36=2.16 currentpreallowanceillustrationonly.",
  "component_rule_ids": [
    "NL-PARAMETERS",
    "NL-METHOD"
  ],
  "guide_lines": [
    187
  ],
  "id": "CASE-NL",
  "official_url": [
    "https://www.belastingdienst.nl/wps/wcm/connect/nl/box-3/content/berekening-box-3-inkomen-2026",
    "https://www.belastingdienst.nl/wps/wcm/connect/nl/box-3/content/berekening-box-3-inkomen-2026"
  ],
  "quote_mode": "Actually verified component-native extracts; arithmetic independently recomputed with Decimal and oa-check. No invented quote for derived result.",
  "short_exact_native_quotes": [
    "1,28%"
  ],
  "short_exact_native_quotes_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
  "source_files": [
    {
      "file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/wealth-nl.txt",
      "sha256": "9174ecb71d657ea38b01360d4032e59bde24309179fb42ac552d4acb3157500a"
    },
    {
      "file": "/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-wave-2-2026-11-14/evidence-global-wealth-treaties/sources/wealth-nl.txt",
      "sha256": "9174ecb71d657ea38b01360d4032e59bde24309179fb42ac552d4acb3157500a"
    }
  ]
}
```

## Original-topic destinations

The complete original-topic destination table is in `../wealth-tax-matrix/old-topic-map.json`.
