# fatca-crs-automatic-exchange figure and rule ledger

Public projection; canonical private SHA256: `c16fc3a1d0895d044b409e96d24469ba35dbee2defd9490767b0c66a51f36dab`. Complete captured/native source passages remain local. The JSON companion preserves every retained evidence field.

## Whole rule groups

### 1

# FATCA and CRS automatic exchange v0.2

```json
{
  "figures": [
    "2"
  ],
  "id": 1,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 17,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Who this applies to",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 2

> **General reference only.** This Guide supports a practitioner review of financial-account classification, due diligence, reporting and FATCA withholding. Obtain advice for the actual entity, account, jurisdiction, reporting period and documents before signing a self-certification or filing.

```json
{
  "figures": [],
  "id": 2,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 19,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Who this applies to",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 3

## Who this applies to

```json
{
  "figures": [],
  "id": 3,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 21,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Who this applies to",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 4

This Guide loads on top of `cross-border-workflow-base`. Use it for Financial Institutions (FIs), trustees, account holders and crypto service providers assessing FATCA, CRS, DAC2 or DAC8. It produces a reviewer brief and working papers, rather than an executed return or a professional approval. Its scope includes entity classification, Financial Account types, Excluded Accounts, Reportable Persons, Controlling Persons, documentary status, due diligence, portals/XML, deadlines, penalties, withholding and crypto reporting.

```json
{
  "figures": [],
  "id": 4,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 23,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Who this applies to",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 5

FATCA is the US chapter 4 regime, IRC sections 1471–1474, operating with Treasury Regulations and the actual bilateral IGA. Model 1A is reciprocal, Model 1B is non-reciprocal, and Model 2 uses direct IRS reporting subject to the agreement. The Treasury model documents cited here illustrate their terms; they do not prove which signed agreement, annex or local implementing law applies to an actual institution. The old assertion of more than 100 signed jurisdictions is not a maintained count in this Guide. [Treasury Model 1A agreement, November 2014](https://home.treasury.gov/system/files/131/FATCA-Reciprocal-Model-1A-Agreement-Preexisting-TIEA-or-DTC-11-30-14.pdf) [Treasury, FATCA agreements and model list](https://home.treasury.gov/policy-issues/tax-policy/foreign-account-tax-compliance-act)

```json
{
  "figures": [
    "4",
    "1471",
    "1474",
    "2",
    "100"
  ],
  "id": 5,
  "kind": "sourced operative rule/condition",
  "line": 25,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Article 1(g)–(l) and (ff) definitions; full Article 2 partner and US reporting",
      "source": "IGA",
      "url": "https://home.treasury.gov/system/files/131/FATCA-Reciprocal-Model-1A-Agreement-Preexisting-TIEA-or-DTC-11-30-14.pdf"
    },
    {
      "actual_read_date": "2026-11-16",
      "locator": "FATCA introduction and reciprocal Model 1A, non-reciprocal Model 1B and Model 2 listings",
      "source": "TREASURY",
      "url": "https://home.treasury.gov/policy-issues/tax-policy/foreign-account-tax-compliance-act"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Who this applies to",
  "short_native_quote_ids": [
    "IGA003",
    "TREASURY019"
  ],
  "source_keys": [
    "IGA",
    "TREASURY"
  ]
}
```

### 6

CRS is an OECD standard implemented through domestic law and exchange agreements, including the multilateral competent-authority agreement or bilateral arrangements. A commitment is not itself domestic law or an activated reporting relationship. The former approximate 120-jurisdiction count is not a current population claim. Determine the FI's local Reportable Jurisdiction list for the relevant year, the agreement requiring exchange, and separately its Participating Jurisdiction list. The OECD model requires the exchange agreement and a published local list for Reportable Jurisdiction status. [OECD, consolidated CRS (2025)](https://www.oecd.org/content/dam/oecd/en/publications/reports/2025/04/consolidated-text-of-the-common-reporting-standard-2025_e478bc04/055664b1-en.pdf)

```json
{
  "figures": [
    "120"
  ],
  "id": 6,
  "kind": "sourced operative rule/condition",
  "line": 27,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Section VIII.D/E definitions and full Active categories; Commentary on Section I paragraph 13 joint reporting; selected FI and aggregation clauses",
      "source": "CRS",
      "url": "https://www.oecd.org/content/dam/oecd/en/publications/reports/2025/04/consolidated-text-of-the-common-reporting-standard-2025_e478bc04/055664b1-en.pdf"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Who this applies to",
  "short_native_quote_ids": [
    "CRS001",
    "CRS020"
  ],
  "source_keys": [
    "CRS"
  ]
}
```

### 7

The EU implements financial-account exchange through Directive 2011/16/EU, Annex I, as amended by DAC2 and DAC8. Apply the current consolidated text and national implementation. Do not assume every Member State's first CRS exchange was in 2017: Annex I Section X expressly provides Austria's later 2017/2018 substitution. The historical 2017/2018 rollout is background, rather than a test of current account reportability. [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1)

```json
{
  "figures": [
    "2011",
    "16",
    "2017",
    "2017",
    "2018",
    "2017",
    "2018"
  ],
  "id": 7,
  "kind": "sourced operative rule/condition",
  "line": 29,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Who this applies to",
  "short_native_quote_ids": [
    "EU044"
  ],
  "source_keys": [
    "EU"
  ]
}
```

### 8

**Period boundary:** the main rules below are checked for 2026, including returns for calendar 2025 filed in 2026 where expressly identified. The 2023 OECD amendments have jurisdiction-specific commencement. The EU amended financial-account scope applies for 2026 under the consolidated Annex I; the UK guidance says 1 January 2026, while Singapore says 1 January 2027. A filing year, data year and inter-authority exchange year are different. Do not apply a universal "CRS 2.0 in force 2026+" assumption. [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1) [HMRC, AEOI financial institutions](https://www.gov.uk/guidance/automatic-exchange-of-information-financial-institutions) [IRAS, CRS overview and latest developments](https://www.iras.gov.sg/taxes/international-tax/common-reporting-standard-%28crs%29/crs-overview-and-latest-developments)

```json
{
  "figures": [
    "2026",
    "2025",
    "2026",
    "2023",
    "2026",
    "1",
    "2026",
    "1",
    "2027",
    "2.0",
    "2026"
  ],
  "id": 8,
  "kind": "sourced operative rule/condition",
  "line": 31,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    },
    {
      "actual_read_date": "2026-11-16",
      "locator": "Main guidance: 2026 scope, reporting entity responsibility, group reports and nil returns",
      "source": "UKFI",
      "url": "https://www.gov.uk/guidance/automatic-exchange-of-information-financial-institutions"
    },
    {
      "actual_read_date": "2026-11-16",
      "locator": "2026 amendment publication, substantive commencement on 1 January 2027 and XML version transition",
      "source": "SGOV",
      "url": "https://www.iras.gov.sg/taxes/international-tax/common-reporting-standard-%28crs%29/crs-overview-and-latest-developments"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Who this applies to",
  "short_native_quote_ids": [
    "EU045",
    "UKFI011",
    "SGOV017"
  ],
  "source_keys": [
    "EU",
    "UKFI",
    "SGOV"
  ]
}
```

### 9

FBAR/FinCEN 114, Form 8938, beneficial-ownership registers under EU AML rules or the US Corporate Transparency Act, and independent AML/KYC compliance are separate. Do not assume that an intended `us-fbar-individual`, `us-fincen-cta-boi` or `eu-amld-boi` file exists or establishes an answer. CRS-avoidance intermediary disclosure belongs with `dac6-mdr-reportable-arrangements`; this Guide does not decide that filing. AEOI classification is fact-specific, but the old universal strict-liability description is incorrect: the UK reasonable-excuse and culpability rules and Germany's intentional/reckless offence conditions below must be considered. [UK SI 2025/740](https://www.legislation.gov.uk/uksi/2025/740/made/data.html) [Germany, FKAustG](https://www.gesetze-im-internet.de/fkaustg/BJNR253110015.html)

```json
{
  "figures": [
    "114",
    "8938"
  ],
  "id": 9,
  "kind": "sourced operative rule/condition",
  "line": 33,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Regulations 1, 3, 6, 9 and 11–14; substituted regulations 22A–22N, including all penalty conditions and commencement",
      "source": "UKLAW",
      "url": "https://www.legislation.gov.uk/uksi/2025/740/made/data.html"
    },
    {
      "actual_read_date": "2026-11-16",
      "locator": "Sections 27(1)–(3) and 28(1)–(3), including all offence branches and their application dates",
      "source": "DE",
      "url": "https://www.gesetze-im-internet.de/fkaustg/BJNR253110015.html"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Who this applies to",
  "short_native_quote_ids": [
    "UKLAW046",
    "DE013",
    "DE026"
  ],
  "source_keys": [
    "UKLAW",
    "DE"
  ]
}
```

### 10

## Rates, bands and thresholds

```json
{
  "figures": [],
  "id": 10,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 35,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Rates, bands and thresholds",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 11

### Quick reference

```json
{
  "figures": [],
  "id": 11,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 37,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Quick reference",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 12

| Question | Rule, figure and boundary | Official authority |

```json
{
  "figures": [],
  "id": 12,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 39,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Quick reference",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 13

| FATCA withholding | 30% of a qualifying withholdable payment when the payee/documentation rules require it; not an automatic charge on all foreign accounts or only a passive owner's proportional share | [IRS Publication 515 (2026)](https://www.irs.gov/publications/p515) |

```json
{
  "figures": [
    "30%",
    "15"
  ],
  "id": 13,
  "kind": "sourced operative rule/condition",
  "line": 41,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Form list; chapter 4 withholding requirements; documentation and reason-to-know rules; FI/NFFE/IGA definitions",
      "source": "IRS515",
      "url": "https://www.irs.gov/publications/p515"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Quick reference",
  "short_native_quote_ids": [
    "IRS515005"
  ],
  "source_keys": [
    "IRS515"
  ]
}
```

### 14

| Custodial institution | At least 20% of gross income attributable to holding Financial Assets and related financial services, over the shorter of the preceding three-year period and the entity's existence | [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1) |

```json
{
  "figures": [
    "20%"
  ],
  "id": 14,
  "kind": "sourced operative rule/condition",
  "line": 42,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Quick reference",
  "short_native_quote_ids": [
    "EU047"
  ],
  "source_keys": [
    "EU"
  ]
}
```

### 15

| Investment Entity | Relevant gross income at least 50%, over the shorter three-year/existence period; distinguish customer-business limb (a) from FI-managed investment limb (b) | [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1) |

```json
{
  "figures": [
    "50%"
  ],
  "id": 15,
  "kind": "sourced operative rule/condition",
  "line": 43,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Quick reference",
  "short_native_quote_ids": [
    "EU048"
  ],
  "source_keys": [
    "EU"
  ]
}
```

### 16

| Active NFE ordinary income/assets test | Both passive gross income and passive-producing/held-for-production assets must be less than 50% in the preceding calendar year or appropriate period | [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1) |

```json
{
  "figures": [
    "50%"
  ],
  "id": 16,
  "kind": "sourced operative rule/condition",
  "line": 44,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Quick reference",
  "short_native_quote_ids": [
    "EU049"
  ],
  "source_keys": [
    "EU"
  ]
}
```

### 17

| Start-up Active NFE | No prior operating history, investing toward a non-FI business; exception ends 24 months after initial organisation | [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1) |

```json
{
  "figures": [
    "24"
  ],
  "id": 17,
  "kind": "sourced operative rule/condition",
  "line": 45,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Quick reference",
  "short_native_quote_ids": [
    "EU050"
  ],
  "source_keys": [
    "EU"
  ]
}
```

### 18

| Liquidating/reorganising Active NFE | Not an FI in the preceding five years; liquidating assets or intending to continue/recommence a non-FI business. There is no general 24-month liquidation permission | [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1) |

```json
{
  "figures": [
    "24"
  ],
  "id": 18,
  "kind": "sourced operative rule/condition",
  "line": 46,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Quick reference",
  "short_native_quote_ids": [
    "EU051"
  ],
  "source_keys": [
    "EU"
  ]
}
```

### 19

| CRS high-value individual account | Aggregate value exceeds USD 1,000,000 at the applicable year-end; exactly USD 1,000,000 is not over the boundary | [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1) |

```json
{
  "figures": [
    "1,000,000",
    "1,000,000"
  ],
  "id": 19,
  "kind": "sourced operative rule/condition",
  "line": 47,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Quick reference",
  "short_native_quote_ids": [
    "EU052"
  ],
  "source_keys": [
    "EU"
  ]
}
```

### 20

| CRS optional pre-existing entity threshold | At most USD 250,000 at 31 December 2015, subject to the local election; review after a later year-end exceeds USD 250,000 | [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1) |

```json
{
  "figures": [
    "250,000",
    "31",
    "2015",
    "250,000"
  ],
  "id": 20,
  "kind": "sourced operative rule/condition",
  "line": 48,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Quick reference",
  "short_native_quote_ids": [
    "EU052"
  ],
  "source_keys": [
    "EU"
  ]
}
```

### 21

| Model 1 FATCA pre-existing entity threshold | At most USD 250,000 at the agreement's Determination Date; the model's later review trigger is above USD 1,000,000, not CRS's USD 250,000 trigger | [Treasury Model 1 Annex I](https://home.treasury.gov/system/files/131/FATCA-Annex-I-to-Model-1-Agreement-11-30-14.pdf) |

```json
{
  "figures": [
    "1",
    "250,000",
    "1,000,000",
    "250,000"
  ],
  "id": 21,
  "kind": "sourced operative rule/condition",
  "line": 49,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Section II.A individual exclusions; Section IV entity thresholds; Section VI.A/B Active NFFE categories and Determination Date",
      "source": "ANNEX",
      "url": "https://home.treasury.gov/system/files/131/FATCA-Annex-I-to-Model-1-Agreement-11-30-14.pdf"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Quick reference",
  "short_native_quote_ids": [
    "ANNEX004"
  ],
  "source_keys": [
    "ANNEX"
  ]
}
```

### 22

| Joint accounts | Attribute the full joint balance to each holder for aggregation; report the full balance for each reportable holder. No general documentary proportional-ownership election | [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1) [OECD, consolidated CRS (2025)](https://www.oecd.org/content/dam/oecd/en/publications/reports/2025/04/consolidated-text-of-the-common-reporting-standard-2025_e478bc04/055664b1-en.pdf) |

```json
{
  "figures": [],
  "id": 22,
  "kind": "sourced operative rule/condition",
  "line": 50,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    },
    {
      "actual_read_date": "2026-11-16",
      "locator": "Section VIII.D/E definitions and full Active categories; Commentary on Section I paragraph 13 joint reporting; selected FI and aggregation clauses",
      "source": "CRS",
      "url": "https://www.oecd.org/content/dam/oecd/en/publications/reports/2025/04/consolidated-text-of-the-common-reporting-standard-2025_e478bc04/055664b1-en.pdf"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Quick reference",
  "short_native_quote_ids": [
    "EU053",
    "CRS001",
    "CRS020"
  ],
  "source_keys": [
    "EU",
    "CRS"
  ]
}
```

### 23

| Insurance | No universal CRS USD 50,000 reporting floor. Model 1 pre-existing cash-value/annuity accounts can have a specific USD 250,000 exclusion; other USD 50,000 gates concern different account categories | [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1) [Treasury Model 1 Annex I](https://home.treasury.gov/system/files/131/FATCA-Annex-I-to-Model-1-Agreement-11-30-14.pdf) |

```json
{
  "figures": [
    "50,000",
    "1",
    "250,000",
    "50,000"
  ],
  "id": 23,
  "kind": "sourced operative rule/condition",
  "line": 51,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    },
    {
      "actual_read_date": "2026-11-16",
      "locator": "Section II.A individual exclusions; Section IV entity thresholds; Section VI.A/B Active NFFE categories and Determination Date",
      "source": "ANNEX",
      "url": "https://home.treasury.gov/system/files/131/FATCA-Annex-I-to-Model-1-Agreement-11-30-14.pdf"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Quick reference",
  "short_native_quote_ids": [
    "EU054",
    "ANNEX004"
  ],
  "source_keys": [
    "EU",
    "ANNEX"
  ]
}
```

### 24

| Crypto retail-payment category | Value must exceed USD 50,000 or equivalent; equality is insufficient. This is not a blanket exemption for all smaller crypto transactions | [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1) |

```json
{
  "figures": [
    "50,000"
  ],
  "id": 24,
  "kind": "sourced operative rule/condition",
  "line": 52,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Quick reference",
  "short_native_quote_ids": [
    "EU055"
  ],
  "source_keys": [
    "EU"
  ]
}
```

### 25

The USD amounts in the EU Annex are translated into the relevant domestic currency as prescribed there. Establish the reporting institution's applicable currency conversion and election; a table in USD does not authorise a reporting-system exchange rate. [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1)

```json
{
  "figures": [],
  "id": 25,
  "kind": "sourced operative rule/condition",
  "line": 54,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Quick reference",
  "short_native_quote_ids": [
    "EU056"
  ],
  "source_keys": [
    "EU"
  ]
}
```

### 26

## The base

```json
{
  "figures": [],
  "id": 26,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 56,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "The base",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 27

### Step 1: establish the institution and reporting route

```json
{
  "figures": [
    "1"
  ],
  "id": 27,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 58,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 1: establish the institution and reporting route",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 28

Model 1 Reporting FFIs generally report US Reportable Accounts to their local authority for exchange with the IRS. Model 2 FFIs and participating FFIs follow their direct IRS obligations; non-consenting Model 2 accounts have the special aggregate/reporting and request procedures of the actual IGA. A non-participating FFI may suffer chapter 4 withholding, but that is not a substitute reporting classification. [Treasury Model 1A agreement, November 2014](https://home.treasury.gov/system/files/131/FATCA-Reciprocal-Model-1A-Agreement-Preexisting-TIEA-or-DTC-11-30-14.pdf) [IRS Form 8966 instructions](https://www.irs.gov/instructions/i8966) [IRS Publication 515 (2026)](https://www.irs.gov/publications/p515)

```json
{
  "figures": [
    "1",
    "2",
    "2",
    "4",
    "966",
    "15"
  ],
  "id": 28,
  "kind": "sourced operative rule/condition",
  "line": 60,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Article 1(g)–(l) and (ff) definitions; full Article 2 partner and US reporting",
      "source": "IGA",
      "url": "https://home.treasury.gov/system/files/131/FATCA-Reciprocal-Model-1A-Agreement-Preexisting-TIEA-or-DTC-11-30-14.pdf"
    },
    {
      "actual_read_date": "2026-11-16",
      "locator": "General instructions, purpose, who must file, filing date, extensions and electronic filing",
      "source": "I8966",
      "url": "https://www.irs.gov/instructions/i8966"
    },
    {
      "actual_read_date": "2026-11-16",
      "locator": "Form list; chapter 4 withholding requirements; documentation and reason-to-know rules; FI/NFFE/IGA definitions",
      "source": "IRS515",
      "url": "https://www.irs.gov/publications/p515"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 1: establish the institution and reporting route",
  "short_native_quote_ids": [
    "IGA003",
    "I8966006",
    "I8966021",
    "IRS515005"
  ],
  "source_keys": [
    "IGA",
    "I8966",
    "IRS515"
  ]
}
```

### 29

**US institutions do not generally file Form 8966 for every foreign account holder.** The reciprocal Model 1A Article 2 US-side categories and information are narrower than the partner's US-reportable-account information. Establish the actual interest/income category and applicable Form 1099, Form 1042-S or other reporting duty. Form 8966 instructions separately identify participating FFIs, certain deemed-compliant/sponsoring/trustee entities, direct-reporting NFFEs and withholding agents reporting specified NFFE owners; the exact filer category controls. [Treasury Model 1A agreement, November 2014](https://home.treasury.gov/system/files/131/FATCA-Reciprocal-Model-1A-Agreement-Preexisting-TIEA-or-DTC-11-30-14.pdf) [IRS Form 8966 instructions](https://www.irs.gov/instructions/i8966)

```json
{
  "figures": [
    "8966",
    "2",
    "1099",
    "1042",
    "8966",
    "966"
  ],
  "id": 29,
  "kind": "sourced operative rule/condition",
  "line": 62,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Article 1(g)–(l) and (ff) definitions; full Article 2 partner and US reporting",
      "source": "IGA",
      "url": "https://home.treasury.gov/system/files/131/FATCA-Reciprocal-Model-1A-Agreement-Preexisting-TIEA-or-DTC-11-30-14.pdf"
    },
    {
      "actual_read_date": "2026-11-16",
      "locator": "General instructions, purpose, who must file, filing date, extensions and electronic filing",
      "source": "I8966",
      "url": "https://www.irs.gov/instructions/i8966"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 1: establish the institution and reporting route",
  "short_native_quote_ids": [
    "IGA003",
    "I8966006",
    "I8966021"
  ],
  "source_keys": [
    "IGA",
    "I8966"
  ]
}
```

### 30

For CRS, first determine Reporting FI versus Non-Reporting FI under local law. Then identify a Financial Account maintained by that FI, its actual holder, and either a Reportable Person holder or a Passive NFE with reportable Controlling Persons. An account is not reportable merely because its holder lives in any jurisdiction that has announced CRS participation. Do not confuse the holder's direct reportability with the Passive NFE look-through test. [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1) [OECD, consolidated CRS (2025)](https://www.oecd.org/content/dam/oecd/en/publications/reports/2025/04/consolidated-text-of-the-common-reporting-standard-2025_e478bc04/055664b1-en.pdf)

```json
{
  "figures": [],
  "id": 30,
  "kind": "sourced operative rule/condition",
  "line": 64,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    },
    {
      "actual_read_date": "2026-11-16",
      "locator": "Section VIII.D/E definitions and full Active categories; Commentary on Section I paragraph 13 joint reporting; selected FI and aggregation clauses",
      "source": "CRS",
      "url": "https://www.oecd.org/content/dam/oecd/en/publications/reports/2025/04/consolidated-text-of-the-common-reporting-standard-2025_e478bc04/055664b1-en.pdf"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 1: establish the institution and reporting route",
  "short_native_quote_ids": [
    "EU057",
    "CRS001",
    "CRS020"
  ],
  "source_keys": [
    "EU",
    "CRS"
  ]
}
```

### 31

### Step 2: classify the entity before choosing an NFE label

```json
{
  "figures": [
    "2"
  ],
  "id": 31,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 66,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 2: classify the entity before choosing an NFE label",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 32

CRS Financial Institutions comprise Custodial Institutions, Depository Institutions, Investment Entities and Specified Insurance Companies. The custodial 20% test includes related financial services; the measurement period is the shorter of the three-year period ending on 31 December (or the final day of a non-calendar accounting period) before the determination year, and the entity's existence. A Depository Institution accepts deposits in a banking/similar business; the amended EU definition also includes holding qualifying E-money or central-bank digital currencies for customers. A Specified Insurance Company, including a holding company, issues or owes payments under Cash Value Insurance or Annuity Contracts. [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1)

```json
{
  "figures": [
    "20%",
    "31"
  ],
  "id": 32,
  "kind": "sourced operative rule/condition",
  "line": 68,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 2: classify the entity before choosing an NFE label",
  "short_native_quote_ids": [
    "EU027"
  ],
  "source_keys": [
    "EU"
  ]
}
```

### 33

Investment Entity limb (a) covers a business conducting specified trading, portfolio management, or investing/administering/managing assets or money for customers. It does **not** require that business to be managed by another FI. Limb (b) covers an entity whose relevant investment income is primarily attributable to Financial Assets or, under the amended rules, Reportable Crypto-Assets, and which is managed by a Depository Institution, Custodial Institution, Specified Insurance Company or limb-(a) Investment Entity. The gross-income threshold is **at least 50%**, not greater than 50%, over the shorter three-year/existence period. [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1)

```json
{
  "figures": [
    "50%",
    "50%"
  ],
  "id": 33,
  "kind": "sourced operative rule/condition",
  "line": 70,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 2: classify the entity before choosing an NFE label",
  "short_native_quote_ids": [
    "EU048"
  ],
  "source_keys": [
    "EU"
  ]
}
```

### 34

The amended definition excludes mere services effectuating Exchange Transactions from limb (a)(iii), and excludes an entity qualifying as Active NFE under the non-financial holding/start-up/liquidation/treasury limbs (d)–(g). Classify the actual activity and manager; do not claim that a family-office-managed passive holding company became an FI only because a new "gap" closed in 2023. The FI-managed investment limb already needs a fact-specific test, and its local version and commencement matter. A direct non-debt interest in real property is outside the Financial Asset definition, while an interest in an investment entity is a different question. [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1)

```json
{
  "figures": [
    "2023"
  ],
  "id": 34,
  "kind": "sourced operative rule/condition",
  "line": 72,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 2: classify the entity before choosing an NFE label",
  "short_native_quote_ids": [
    "EU048"
  ],
  "source_keys": [
    "EU"
  ]
}
```

### 35

FATCA classifications must be tested separately under the relevant regulations/IGA. The Model 1 FI definition and US regulatory categories are not identical to the amended CRS definition; IRS Publication 515 also identifies holding/treasury entities in specified FFI groups. Do not paste the CRS result into a W-8BEN-E without checking the applicable FATCA route. [Treasury Model 1A agreement, November 2014](https://home.treasury.gov/system/files/131/FATCA-Reciprocal-Model-1A-Agreement-Preexisting-TIEA-or-DTC-11-30-14.pdf) [IRS Publication 515 (2026)](https://www.irs.gov/publications/p515)

```json
{
  "figures": [
    "1",
    "515",
    "15"
  ],
  "id": 35,
  "kind": "sourced operative rule/condition",
  "line": 74,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Article 1(g)–(l) and (ff) definitions; full Article 2 partner and US reporting",
      "source": "IGA",
      "url": "https://home.treasury.gov/system/files/131/FATCA-Reciprocal-Model-1A-Agreement-Preexisting-TIEA-or-DTC-11-30-14.pdf"
    },
    {
      "actual_read_date": "2026-11-16",
      "locator": "Form list; chapter 4 withholding requirements; documentation and reason-to-know rules; FI/NFFE/IGA definitions",
      "source": "IRS515",
      "url": "https://www.irs.gov/publications/p515"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 2: classify the entity before choosing an NFE label",
  "short_native_quote_ids": [
    "IGA031",
    "IRS515032"
  ],
  "source_keys": [
    "IGA",
    "IRS515"
  ]
}
```

### 36

### Step 3: apply the complete Active NFE category

```json
{
  "figures": [
    "3"
  ],
  "id": 36,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 76,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 3: apply the complete Active NFE category",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 37

The CRS model has eight lettered categories (a)–(h), with cumulative conditions inside each. EU Annex I uses the equivalent Section VIII.D(8). The FATCA Model 1 Annex I VI.B.4 instead has ten categories (a)–(j), including territory and excepted-NFFE routes. The former generic "nine categories" must not be reused. [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1) [OECD, consolidated CRS (2025)](https://www.oecd.org/content/dam/oecd/en/publications/reports/2025/04/consolidated-text-of-the-common-reporting-standard-2025_e478bc04/055664b1-en.pdf) [Treasury Model 1 Annex I](https://home.treasury.gov/system/files/131/FATCA-Annex-I-to-Model-1-Agreement-11-30-14.pdf)

```json
{
  "figures": [
    "8",
    "1",
    "4"
  ],
  "id": 37,
  "kind": "sourced operative rule/condition",
  "line": 78,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    },
    {
      "actual_read_date": "2026-11-16",
      "locator": "Section VIII.D/E definitions and full Active categories; Commentary on Section I paragraph 13 joint reporting; selected FI and aggregation clauses",
      "source": "CRS",
      "url": "https://www.oecd.org/content/dam/oecd/en/publications/reports/2025/04/consolidated-text-of-the-common-reporting-standard-2025_e478bc04/055664b1-en.pdf"
    },
    {
      "actual_read_date": "2026-11-16",
      "locator": "Section II.A individual exclusions; Section IV entity thresholds; Section VI.A/B Active NFFE categories and Determination Date",
      "source": "ANNEX",
      "url": "https://home.treasury.gov/system/files/131/FATCA-Annex-I-to-Model-1-Agreement-11-30-14.pdf"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 3: apply the complete Active NFE category",
  "short_native_quote_ids": [
    "EU058",
    "CRS001",
    "CRS020",
    "ANNEX004"
  ],
  "source_keys": [
    "EU",
    "CRS",
    "ANNEX"
  ]
}
```

### 38

| CRS/EU category | Required conditions and exclusions | Source |

```json
{
  "figures": [],
  "id": 38,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 80,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 3: apply the complete Active NFE category",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 39

| (a) Income/assets | Both preceding-period passive-income share and passive-asset share below 50%; failure of either defeats this category | [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1) |

```json
{
  "figures": [
    "50%"
  ],
  "id": 39,
  "kind": "sourced operative rule/condition",
  "line": 82,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 3: apply the complete Active NFE category",
  "short_native_quote_ids": [
    "EU049"
  ],
  "source_keys": [
    "EU"
  ]
}
```

### 40

| (b) Listed entity | Stock regularly traded on an established securities market, or Related Entity of such an entity | [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1) |

```json
{
  "figures": [],
  "id": 40,
  "kind": "sourced operative rule/condition",
  "line": 83,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 3: apply the complete Active NFE category",
  "short_native_quote_ids": [
    "EU059"
  ],
  "source_keys": [
    "EU"
  ]
}
```

### 41

| (c) Public bodies | Governmental Entity, International Organisation, Central Bank, or wholly owned by one or more of them | [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1) |

```json
{
  "figures": [],
  "id": 41,
  "kind": "sourced operative rule/condition",
  "line": 84,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 3: apply the complete Active NFE category",
  "short_native_quote_ids": [
    "EU060"
  ],
  "source_keys": [
    "EU"
  ]
}
```

### 42

| (d) Non-financial holding group | Substantially all activity consists of holding/financing/servicing subsidiaries carrying on non-FI businesses; an investment fund or vehicle holding businesses as capital investments is excluded | [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1) |

```json
{
  "figures": [],
  "id": 42,
  "kind": "sourced operative rule/condition",
  "line": 85,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 3: apply the complete Active NFE category",
  "short_native_quote_ids": [
    "EU061"
  ],
  "source_keys": [
    "EU"
  ]
}
```

### 43

| (e) Start-up | No operating business or prior operating history; investing capital toward a non-FI business, with the 24-month limit | [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1) |

```json
{
  "figures": [
    "24"
  ],
  "id": 43,
  "kind": "sourced operative rule/condition",
  "line": 86,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 3: apply the complete Active NFE category",
  "short_native_quote_ids": [
    "EU050"
  ],
  "source_keys": [
    "EU"
  ]
}
```

### 44

| (f) Liquidation/reorganisation | No FI status in the preceding five years; liquidation or reorganisation toward continuing/recommencing a non-FI business | [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1) |

```json
{
  "figures": [],
  "id": 44,
  "kind": "sourced operative rule/condition",
  "line": 87,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 3: apply the complete Active NFE category",
  "short_native_quote_ids": [
    "EU051"
  ],
  "source_keys": [
    "EU"
  ]
}
```

### 45

| (g) Treasury centre | Primarily finances/hedges with or for non-FI Related Entities; no financing/hedging for unrelated entities; related group primarily carries on non-FI business | [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1) |

```json
{
  "figures": [],
  "id": 45,
  "kind": "sourced operative rule/condition",
  "line": 88,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 3: apply the complete Active NFE category",
  "short_native_quote_ids": [
    "EU062"
  ],
  "source_keys": [
    "EU"
  ]
}
```

### 46

| (h) Non-profit | All conditions below must hold; a charity name alone is insufficient | [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1) |

```json
{
  "figures": [],
  "id": 46,
  "kind": "sourced operative rule/condition",
  "line": 89,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 3: apply the complete Active NFE category",
  "short_native_quote_ids": [
    "EU063"
  ],
  "source_keys": [
    "EU"
  ]
}
```

### 47

For non-profit category (h), the entity must be established and operated in its residence jurisdiction exclusively for the specified charitable/religious/scientific/artistic/cultural/athletic/educational purposes, or fall within the listed professional/business/labour/agricultural/horticultural/civic/social-welfare organisations; be income-tax-exempt there; have no shareholders or members with proprietary/beneficial interests; and have legal/constitutional restrictions on private distributions. Permitted charitable activities, reasonable service compensation and fair-market-value property purchases are the specified distribution exceptions. On dissolution, assets must go to government or another non-profit, or escheat to government, under the governing law/documents. Do not replace the last requirement with a generic transfer to any Active NFE. [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1)

```json
{
  "figures": [],
  "id": 47,
  "kind": "sourced operative rule/condition",
  "line": 91,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 3: apply the complete Active NFE category",
  "short_native_quote_ids": [
    "EU064"
  ],
  "source_keys": [
    "EU"
  ]
}
```

### 48

An ordinary Passive NFE is an NFE failing all Active categories. CRS also treats a limb-(b) Investment Entity that is not a Participating Jurisdiction FI as Passive for this purpose, so an apparent investment FI can still require look-through. Document the applicable Participating Jurisdiction list and the manager's status. FATCA "substantial US owners" under the regulations and IGA "Controlling Persons" must be distinguished. [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1) [Treasury Model 1A agreement, November 2014](https://home.treasury.gov/system/files/131/FATCA-Reciprocal-Model-1A-Agreement-Preexisting-TIEA-or-DTC-11-30-14.pdf) [IRS Publication 515 (2026)](https://www.irs.gov/publications/p515)

```json
{
  "figures": [
    "15"
  ],
  "id": 48,
  "kind": "sourced operative rule/condition",
  "line": 93,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    },
    {
      "actual_read_date": "2026-11-16",
      "locator": "Article 1(g)–(l) and (ff) definitions; full Article 2 partner and US reporting",
      "source": "IGA",
      "url": "https://home.treasury.gov/system/files/131/FATCA-Reciprocal-Model-1A-Agreement-Preexisting-TIEA-or-DTC-11-30-14.pdf"
    },
    {
      "actual_read_date": "2026-11-16",
      "locator": "Form list; chapter 4 withholding requirements; documentation and reason-to-know rules; FI/NFFE/IGA definitions",
      "source": "IRS515",
      "url": "https://www.irs.gov/publications/p515"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 3: apply the complete Active NFE category",
  "short_native_quote_ids": [
    "EU061",
    "IGA003",
    "IRS515005"
  ],
  "source_keys": [
    "EU",
    "IGA",
    "IRS515"
  ]
}
```

### 49

### Step 4: identify account types, holders and controlling persons

```json
{
  "figures": [
    "4"
  ],
  "id": 49,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 95,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 4: identify account types, holders and controlling persons",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 50

Inventory Depository Accounts, Custodial Accounts, relevant equity/debt interests in Investment Entities and anti-avoidance cases, Cash Value Insurance Contracts and Annuity Contracts. Apply the actual Financial Account and Excluded Account definitions before treating all equity/debt or every insurance policy as reportable. The EU definition contains the investment-advice/portfolio-management-only account exception and specified insurance/annuity exclusions; a "Documented Account" is an evidence status, not an independent statutory exemption. [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1)

```json
{
  "figures": [],
  "id": 50,
  "kind": "sourced operative rule/condition",
  "line": 97,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 4: identify account types, holders and controlling persons",
  "short_native_quote_ids": [
    "EU065"
  ],
  "source_keys": [
    "EU"
  ]
}
```

### 51

A nominee, custodian, agent or signatory that is not itself an FI generally does not displace the actual person for whose account it holds the Financial Account. For insurance/annuities, identify who can access cash value/change a beneficiary, or the contract owner/vested payee where neither right exists; at maturity identify each person entitled to payment. [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1)

```json
{
  "figures": [],
  "id": 51,
  "kind": "sourced operative rule/condition",
  "line": 99,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 4: identify account types, holders and controlling persons",
  "short_native_quote_ids": [
    "EU065"
  ],
  "source_keys": [
    "EU"
  ]
}
```

### 52

CRS Controlling Persons are natural persons exercising control, interpreted consistently with the applicable AML/FATF framework. Do not use ">25% beneficial owner" as a universal sole test or ignore control by other means and the applicable fallback. For trusts include settlors, trustees, protectors if any, beneficiaries/classes and other persons exercising ultimate effective control; equivalent positions apply to other legal arrangements. Record role, residence and required self-certification, rather than assuming a legal entity in one role ends the analysis. [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1)

```json
{
  "figures": [
    "25%"
  ],
  "id": 52,
  "kind": "sourced operative rule/condition",
  "line": 101,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 4: identify account types, holders and controlling persons",
  "short_native_quote_ids": [
    "EU066"
  ],
  "source_keys": [
    "EU"
  ]
}
```

### 53

A trust may be an Investment Entity under the relevant income/management conditions. A trustee title or professional registration alone does not prove the manager is a qualifying FI. The EU Trustee-Documented Trust exemption requires a trustee that is a Reporting FI and reports all Section I information required for all the trust's Reportable Accounts. FATCA TDT treatment needs its own applicable IGA/non-reporting category and documentation. [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1) [IRS Form 8966 instructions](https://www.irs.gov/instructions/i8966)

```json
{
  "figures": [
    "966"
  ],
  "id": 53,
  "kind": "sourced operative rule/condition",
  "line": 103,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    },
    {
      "actual_read_date": "2026-11-16",
      "locator": "General instructions, purpose, who must file, filing date, extensions and electronic filing",
      "source": "I8966",
      "url": "https://www.irs.gov/instructions/i8966"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 4: identify account types, holders and controlling persons",
  "short_native_quote_ids": [
    "EU067",
    "I8966006",
    "I8966021"
  ],
  "source_keys": [
    "EU",
    "I8966"
  ]
}
```

### 54

### Step 5: obtain new-account evidence and cure contradictions

```json
{
  "figures": [
    "5"
  ],
  "id": 54,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 105,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 5: obtain new-account evidence and cure contradictions",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 55

For new individual CRS accounts obtain self-certification at opening sufficient to determine all tax residences, and confirm reasonableness against opening/AML/KYC information. Apply the TIN and birth-information requirements and exceptions; do not treat citizenship, a residence permit or one postal address as conclusive tax residence. Changed or contradictory evidence prevents continued reliance without the required new valid evidence. [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1)

```json
{
  "figures": [],
  "id": 55,
  "kind": "sourced operative rule/condition",
  "line": 107,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 5: obtain new-account evidence and cure contradictions",
  "short_native_quote_ids": [
    "EU068"
  ],
  "source_keys": [
    "EU"
  ]
}
```

### 56

For new entities, obtain a self-certification establishing residence and confirm reasonableness; a no-tax-residence entity can use its principal-office address under Annex I VI.A(1). Determine Reportable Person status, and then Passive NFE/Controlling Person status separately. FI/Active status may in specified circumstances be reasonably determined from existing or public information. The new-entity Controlling Person residence route uses self-certification from the holder or person; existing AML evidence does not universally replace it. [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1)

```json
{
  "figures": [
    "1"
  ],
  "id": 56,
  "kind": "sourced operative rule/condition",
  "line": 109,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 5: obtain new-account evidence and cure contradictions",
  "short_native_quote_ids": [
    "EU069"
  ],
  "source_keys": [
    "EU"
  ]
}
```

### 57

The former general "correct the form within 90 days" permission is withdrawn. Annex II's particular residence-address change rule allows the **later of the relevant calendar-year end or 90 calendar days after notice/discovery** to obtain the required self-certification and documentary evidence; failing that, apply the electronic-record search. It is not a universal account-opening grace period. Annex I VII.Aa separately addresses exceptional temporary absence of new-account self-certification by applying pre-existing procedures until it is obtained/validated; establish the actual local rule before onboarding. [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1)

```json
{
  "figures": [
    "90",
    "90"
  ],
  "id": 57,
  "kind": "sourced operative rule/condition",
  "line": 111,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 5: obtain new-account evidence and cure contradictions",
  "short_native_quote_ids": [
    "EU070"
  ],
  "source_keys": [
    "EU"
  ]
}
```

### 58

For FATCA, W-9 documents the US-person/TIN position where appropriate; W-8BEN is the foreign individual beneficial-owner form, W-8BEN-E the entity form, W-8IMY the intermediary/flow-through/certain-US-branch form with required supporting allocation/documentation, W-8ECI the ECI claim, and W-8EXP specified foreign governments or other foreign organisations. Use the actual form instructions and required chapter 3/chapter 4 certifications; an ECI or exemption assertion does not remove unrelated reporting duties. Never rely on an incomplete form or one inconsistent with known facts. [IRS Publication 515 (2026)](https://www.irs.gov/publications/p515)

```json
{
  "figures": [
    "9",
    "3",
    "4",
    "15"
  ],
  "id": 58,
  "kind": "sourced operative rule/condition",
  "line": 113,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Form list; chapter 4 withholding requirements; documentation and reason-to-know rules; FI/NFFE/IGA definitions",
      "source": "IRS515",
      "url": "https://www.irs.gov/publications/p515"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 5: obtain new-account evidence and cure contradictions",
  "short_native_quote_ids": [
    "IRS515033"
  ],
  "source_keys": [
    "IRS515"
  ]
}
```

### 59

### Step 6: review pre-existing individual accounts

```json
{
  "figures": [
    "6"
  ],
  "id": 59,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 115,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 6: review pre-existing individual accounts",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 60

Under EU Annex I the ordinary old-account cut-off is 31 December 2015, with new accounts from 1 January 2016; newly included financial products under DAC8 have the 31 December 2025 / 1 January 2026 boundary. The FATCA Model 1 uses an agreement-specific Determination Date. The old 30 June 2014 FATCA date cannot be imposed on every IGA/account class. Preserve the actual local definition and permitted same-holder new-account treatment. [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1) [Treasury Model 1 Annex I](https://home.treasury.gov/system/files/131/FATCA-Annex-I-to-Model-1-Agreement-11-30-14.pdf)

```json
{
  "figures": [
    "31",
    "2015",
    "1",
    "2016",
    "31",
    "2025",
    "1",
    "2026",
    "1",
    "30",
    "2014"
  ],
  "id": 60,
  "kind": "sourced operative rule/condition",
  "line": 117,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    },
    {
      "actual_read_date": "2026-11-16",
      "locator": "Section II.A individual exclusions; Section IV entity thresholds; Section VI.A/B Active NFFE categories and Determination Date",
      "source": "ANNEX",
      "url": "https://home.treasury.gov/system/files/131/FATCA-Annex-I-to-Model-1-Agreement-11-30-14.pdf"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 6: review pre-existing individual accounts",
  "short_native_quote_ids": [
    "EU071",
    "ANNEX004"
  ],
  "source_keys": [
    "EU",
    "ANNEX"
  ]
}
```

### 61

For lower-value EU accounts the balance is at most USD 1,000,000 at the applicable cut-off. A current residence address based on Documentary Evidence can support the residence-address test. Otherwise search electronic records for the specified residence identification, current address, qualifying telephone numbers, standing transfer instructions excluding Depository Accounts, current power-of-attorney/signatory address, and sole hold-mail/in-care-of indicia. A tax-residence indicium is not the same as a universal nationality test. Apply the specific cure alternatives: some require both self-certification and Documentary Evidence, whereas the power-of-attorney limb permits either. Sole hold-mail/in-care-of cases require the special paper-search/evidence and undocumented-account route. [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1)

```json
{
  "figures": [
    "1,000,000"
  ],
  "id": 61,
  "kind": "sourced operative rule/condition",
  "line": 119,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 6: review pre-existing individual accounts",
  "short_native_quote_ids": [
    "EU072"
  ],
  "source_keys": [
    "EU"
  ]
}
```

### 62

For high-value accounts, add the paper-record review unless the electronic system contains all the specified information, and the relationship-manager actual-knowledge inquiry. A complete electronic record is a statutory exception to the paper search, not an exception to manager knowledge. After enhanced procedures, there is no automatic annual rerun of every paper search: the manager inquiry continues, changed circumstances must be addressed, and undocumented accounts have annual enhanced procedures until documented. An account first exceeding USD 1,000,000 at a later year-end must receive enhanced review within the next calendar year under the Annex. [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1)

```json
{
  "figures": [
    "1,000,000"
  ],
  "id": 62,
  "kind": "sourced operative rule/condition",
  "line": 121,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 6: review pre-existing individual accounts",
  "short_native_quote_ids": [
    "EU073"
  ],
  "source_keys": [
    "EU"
  ]
}
```

### 63

Use the actual FATCA IGA's pre-existing individual procedures and optional exclusions. In the Model 1 Annex, the specified USD 50,000 individual/deposit gates and USD 250,000 cash-value/annuity gate have different conditions, including applicable elections and restrictions on insurance sales to US residents. Do not transfer a CRS residence-address test or one category's threshold wholesale into FATCA. [Treasury Model 1 Annex I](https://home.treasury.gov/system/files/131/FATCA-Annex-I-to-Model-1-Agreement-11-30-14.pdf)

```json
{
  "figures": [
    "1",
    "50,000",
    "250,000"
  ],
  "id": 63,
  "kind": "sourced operative rule/condition",
  "line": 123,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Section II.A individual exclusions; Section IV entity thresholds; Section VI.A/B Active NFFE categories and Determination Date",
      "source": "ANNEX",
      "url": "https://home.treasury.gov/system/files/131/FATCA-Annex-I-to-Model-1-Agreement-11-30-14.pdf"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 6: review pre-existing individual accounts",
  "short_native_quote_ids": [
    "ANNEX004"
  ],
  "source_keys": [
    "ANNEX"
  ]
}
```

### 64

### Step 7: review pre-existing entities and aggregate accounts

```json
{
  "figures": [
    "7"
  ],
  "id": 64,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 125,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 7: review pre-existing entities and aggregate accounts",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 65

Determine both whether the entity holder is itself reportable and whether it is Passive with reportable Controlling Persons. For pre-existing EU entity accounts of at most USD 1,000,000, specified AML/KYC information can establish Controlling Person residence; otherwise obtain the required self-certification. The separate optional USD 250,000 review threshold does not make every account below that value permanently exempt. If an elected unreviewed account later exceeds USD 250,000 at year-end, review it within the following calendar year. Do not repeat the unsupported Netherlands-specific assertion that all accounts must be reviewed without current local authority. [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1)

```json
{
  "figures": [
    "1,000,000",
    "250,000",
    "250,000"
  ],
  "id": 65,
  "kind": "sourced operative rule/condition",
  "line": 127,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 7: review pre-existing entities and aggregate accounts",
  "short_native_quote_ids": [
    "EU074"
  ],
  "source_keys": [
    "EU"
  ]
}
```

### 66

Aggregate balances at the FI and Related Entities where computerised systems link accounts by a data element and permit aggregation; apply the special relationship-manager rule **for determining High Value Accounts**, aggregating accounts known to be commonly owned/controlled by the same person **other than in a fiduciary capacity**. Allocate the **entire joint account balance to each holder** for threshold tests, and the full reportable balance/payment amounts for each reportable holder. The former proportional pre-"CRS 2.0" rule and the claimed documentary proportional-ownership exception are both withdrawn. [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1) [OECD, consolidated CRS (2025)](https://www.oecd.org/content/dam/oecd/en/publications/reports/2025/04/consolidated-text-of-the-common-reporting-standard-2025_e478bc04/055664b1-en.pdf)

```json
{
  "figures": [
    "2.0"
  ],
  "id": 66,
  "kind": "sourced operative rule/condition",
  "line": 129,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    },
    {
      "actual_read_date": "2026-11-16",
      "locator": "Section VIII.D/E definitions and full Active categories; Commentary on Section I paragraph 13 joint reporting; selected FI and aggregation clauses",
      "source": "CRS",
      "url": "https://www.oecd.org/content/dam/oecd/en/publications/reports/2025/04/consolidated-text-of-the-common-reporting-standard-2025_e478bc04/055664b1-en.pdf"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 7: review pre-existing entities and aggregate accounts",
  "short_native_quote_ids": [
    "EU028",
    "CRS001",
    "CRS020"
  ],
  "source_keys": [
    "EU",
    "CRS"
  ]
}
```

### 67

For cash-value insurance and annuities there is no general CRS USD 50,000 floor. The optional special group-contract beneficiary procedure has cumulative conditions, including an employer group covering at least 25 employees/certificate holders and the USD 1,000,000 payable cap; it does not exempt every group contract or remove identification when a payment is due. Apply the actual VII.B conditions and normal account definitions. [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1)

```json
{
  "figures": [
    "50,000",
    "25",
    "1,000,000"
  ],
  "id": 67,
  "kind": "sourced operative rule/condition",
  "line": 131,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 7: review pre-existing entities and aggregate accounts",
  "short_native_quote_ids": [
    "EU076"
  ],
  "source_keys": [
    "EU"
  ]
}
```

### 68

### Step 8: determine reportable persons and required fields

```json
{
  "figures": [
    "8"
  ],
  "id": 68,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 133,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 8: determine reportable persons and required fields",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 69

For CRS apply the residence definition and all exclusions for the relevant version: publicly traded entities/related entities, government, international organisations, central banks and FIs. The amended EU text uses "Entity" for the traded-entity exclusions. Local Reportable Jurisdiction lists and competent-authority relationships control exchange; a Participating Jurisdiction is a distinct definition used, among other things, for investment-entity look-through. [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1) [OECD, consolidated CRS (2025)](https://www.oecd.org/content/dam/oecd/en/publications/reports/2025/04/consolidated-text-of-the-common-reporting-standard-2025_e478bc04/055664b1-en.pdf)

```json
{
  "figures": [],
  "id": 69,
  "kind": "sourced operative rule/condition",
  "line": 135,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    },
    {
      "actual_read_date": "2026-11-16",
      "locator": "Section VIII.D/E definitions and full Active categories; Commentary on Section I paragraph 13 joint reporting; selected FI and aggregation clauses",
      "source": "CRS",
      "url": "https://www.oecd.org/content/dam/oecd/en/publications/reports/2025/04/consolidated-text-of-the-common-reporting-standard-2025_e478bc04/055664b1-en.pdf"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 8: determine reportable persons and required fields",
  "short_native_quote_ids": [
    "EU077",
    "CRS001",
    "CRS020"
  ],
  "source_keys": [
    "EU",
    "CRS"
  ]
}
```

### 70

For FATCA use the actual Specified US Person definition. The correct regulatory reference is section **1.1473-1(c)**, not the old 1.1471-5(f)(2). Model 1 Article 1(ff) excludes the specified publicly traded corporations and expanded affiliated group members; section 501(a) organisations and individual retirement plans; US/state/DC/territory governmental bodies and wholly owned instrumentalities; banks; REITs; RICs and specified SEC-registered investment entities; common trust funds; section 664(c)/4947(a)(1) trusts; registered dealers; brokers; and section 403(b)/457(g) tax-exempt trusts. Match every condition, rather than treating this as a universal foreign-account exclusion list. [Treasury Model 1A agreement, November 2014](https://home.treasury.gov/system/files/131/FATCA-Reciprocal-Model-1A-Agreement-Preexisting-TIEA-or-DTC-11-30-14.pdf) [Official CFR 2025, section 1.1473-1](https://www.govinfo.gov/content/pkg/CFR-2025-title26-vol14/pdf/CFR-2025-title26-vol14-sec1-1473-1.pdf)

```json
{
  "figures": [
    "1.1473",
    "1",
    "1.1471",
    "5",
    "2",
    "1",
    "1",
    "501",
    "664",
    "4947",
    "1",
    "403",
    "457"
  ],
  "id": 70,
  "kind": "sourced operative rule/condition",
  "line": 137,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Article 1(g)–(l) and (ff) definitions; full Article 2 partner and US reporting",
      "source": "IGA",
      "url": "https://home.treasury.gov/system/files/131/FATCA-Reciprocal-Model-1A-Agreement-Preexisting-TIEA-or-DTC-11-30-14.pdf"
    },
    {
      "actual_read_date": "2026-11-16",
      "locator": "Section 1.1473-1(a)(1) and (c), read with Model 1 Article 1(ff)",
      "source": "CFR",
      "url": "https://www.govinfo.gov/content/pkg/CFR-2025-title26-vol14/pdf/CFR-2025-title26-vol14-sec1-1473-1.pdf"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 8: determine reportable persons and required fields",
  "short_native_quote_ids": [
    "CFR034"
  ],
  "source_keys": [
    "IGA",
    "CFR"
  ]
}
```

### 71

| Reporting item | FATCA Model 1 partner-to-US information | CRS/EU information | Source |

```json
{
  "figures": [
    "1"
  ],
  "id": 71,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 139,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 8: determine reportable persons and required fields",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 72

| Identity | Name, address, US TIN of specified US holder; entity and specified US Controlling Person details under the applicable NFFE rule | Name, address, residence jurisdiction(s), TIN(s), individual date/place of birth, and entity/Controlling Person identity where applicable; defined TIN/birth exceptions apply | [Treasury Model 1A agreement, November 2014](https://home.treasury.gov/system/files/131/FATCA-Reciprocal-Model-1A-Agreement-Preexisting-TIEA-or-DTC-11-30-14.pdf) [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1) |

```json
{
  "figures": [],
  "id": 72,
  "kind": "sourced operative rule/condition",
  "line": 141,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Article 1(g)–(l) and (ff) definitions; full Article 2 partner and US reporting",
      "source": "IGA",
      "url": "https://home.treasury.gov/system/files/131/FATCA-Reciprocal-Model-1A-Agreement-Preexisting-TIEA-or-DTC-11-30-14.pdf"
    },
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 8: determine reportable persons and required fields",
  "short_native_quote_ids": [
    "IGA003",
    "EU077"
  ],
  "source_keys": [
    "IGA",
    "EU"
  ]
}
```

### 73

| Account/FI | Account number or functional equivalent; Reporting FI name and identifying number | Account number/equivalent; FI name and identifying number if any; amended account-type/self-certification/joint-holder information | [Treasury Model 1A agreement, November 2014](https://home.treasury.gov/system/files/131/FATCA-Reciprocal-Model-1A-Agreement-Preexisting-TIEA-or-DTC-11-30-14.pdf) [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1) |

```json
{
  "figures": [],
  "id": 73,
  "kind": "sourced operative rule/condition",
  "line": 142,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Article 1(g)–(l) and (ff) definitions; full Article 2 partner and US reporting",
      "source": "IGA",
      "url": "https://home.treasury.gov/system/files/131/FATCA-Reciprocal-Model-1A-Agreement-Preexisting-TIEA-or-DTC-11-30-14.pdf"
    },
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 8: determine reportable persons and required fields",
  "short_native_quote_ids": [
    "IGA003",
    "EU077"
  ],
  "source_keys": [
    "IGA",
    "EU"
  ]
}
```

### 74

| Balance/closure | Year-end balance/value or applicable closure information under the IGA | Year-end balance/value; closure during the year, and cash/surrender value for relevant insurance/annuities | [Treasury Model 1A agreement, November 2014](https://home.treasury.gov/system/files/131/FATCA-Reciprocal-Model-1A-Agreement-Preexisting-TIEA-or-DTC-11-30-14.pdf) [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1) |

```json
{
  "figures": [],
  "id": 74,
  "kind": "sourced operative rule/condition",
  "line": 143,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Article 1(g)–(l) and (ff) definitions; full Article 2 partner and US reporting",
      "source": "IGA",
      "url": "https://home.treasury.gov/system/files/131/FATCA-Reciprocal-Model-1A-Agreement-Preexisting-TIEA-or-DTC-11-30-14.pdf"
    },
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 8: determine reportable persons and required fields",
  "short_native_quote_ids": [
    "IGA003",
    "EU078"
  ],
  "source_keys": [
    "IGA",
    "EU"
  ]
}
```

### 75

| Custodial account | Gross interest, dividends, other income and gross sale/redemption proceeds under Article 2 | Gross interest/dividends/other income and gross sale/redemption proceeds when acting as custodian/broker/nominee/agent; Annex I I.F excludes proceeds to the extent the same FI reports them under Article 8ad, unless it elects otherwise for a clearly identified account group | [Treasury Model 1A agreement, November 2014](https://home.treasury.gov/system/files/131/FATCA-Reciprocal-Model-1A-Agreement-Preexisting-TIEA-or-DTC-11-30-14.pdf) [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1) |

```json
{
  "figures": [
    "2"
  ],
  "id": 75,
  "kind": "sourced operative rule/condition",
  "line": 144,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Article 1(g)–(l) and (ff) definitions; full Article 2 partner and US reporting",
      "source": "IGA",
      "url": "https://home.treasury.gov/system/files/131/FATCA-Reciprocal-Model-1A-Agreement-Preexisting-TIEA-or-DTC-11-30-14.pdf"
    },
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 8: determine reportable persons and required fields",
  "short_native_quote_ids": [
    "EU029",
    "IGA003"
  ],
  "source_keys": [
    "IGA",
    "EU"
  ]
}
```

### 76

| Depository account | Gross interest | Gross interest | [Treasury Model 1A agreement, November 2014](https://home.treasury.gov/system/files/131/FATCA-Reciprocal-Model-1A-Agreement-Preexisting-TIEA-or-DTC-11-30-14.pdf) [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1) |

```json
{
  "figures": [],
  "id": 76,
  "kind": "sourced operative rule/condition",
  "line": 145,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Article 1(g)–(l) and (ff) definitions; full Article 2 partner and US reporting",
      "source": "IGA",
      "url": "https://home.treasury.gov/system/files/131/FATCA-Reciprocal-Model-1A-Agreement-Preexisting-TIEA-or-DTC-11-30-14.pdf"
    },
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 8: determine reportable persons and required fields",
  "short_native_quote_ids": [
    "IGA003",
    "EU080"
  ],
  "source_keys": [
    "IGA",
    "EU"
  ]
}
```

### 77

| Other account | Gross amounts paid/credited, including redemption payments where required | Gross paid/credited amounts where the FI is obligor/debtor, including aggregate redemption payments | [Treasury Model 1A agreement, November 2014](https://home.treasury.gov/system/files/131/FATCA-Reciprocal-Model-1A-Agreement-Preexisting-TIEA-or-DTC-11-30-14.pdf) [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1) |

```json
{
  "figures": [],
  "id": 77,
  "kind": "sourced operative rule/condition",
  "line": 146,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Article 1(g)–(l) and (ff) definitions; full Article 2 partner and US reporting",
      "source": "IGA",
      "url": "https://home.treasury.gov/system/files/131/FATCA-Reciprocal-Model-1A-Agreement-Preexisting-TIEA-or-DTC-11-30-14.pdf"
    },
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 8: determine reportable persons and required fields",
  "short_native_quote_ids": [
    "IGA003",
    "EU081"
  ],
  "source_keys": [
    "IGA",
    "EU"
  ]
}
```

### 78

The EU amended reporting fields include Controlling Person/equity-interest roles and applicable account/new-or-pre-existing/joint-holder/self-certification information. Annex I XI gives a limited transition for roles on accounts maintained at 31 December 2025: for reporting periods ending by the end of the second following calendar year, report those roles only if electronically searchable. It does not postpone all amended reporting fields. Record currency for each reported amount. Do not prescribe account currency as an absolute worldwide conversion rule or invent the receiving authority's year-end translation method. [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1)

```json
{
  "figures": [
    "31",
    "2025"
  ],
  "id": 78,
  "kind": "sourced operative rule/condition",
  "line": 148,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 8: determine reportable persons and required fields",
  "short_native_quote_ids": [
    "EU045"
  ],
  "source_keys": [
    "EU"
  ]
}
```

### 79

### Step 9: document FATCA status and GIIN

```json
{
  "figures": [
    "9"
  ],
  "id": 79,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 150,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 9: document FATCA status and GIIN",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 80

Distinguish a Participating FFI, Reporting Model 1 FFI, Reporting Model 2 FFI, Registered Deemed-Compliant FFI, Certified Deemed-Compliant FFI, Exempt Beneficial Owner and NPFFI. Model 1 reporting does not mean the FI has the same direct FFI agreement as a participating non-IGA FFI. Non-reporting IGA categories and exempt beneficial owners have specific conditions. The old shortcuts "small jurisdictions = certified deemed-compliant" and "all retirement funds = certified deemed-compliant" are unusable; establish the precise category and documentation. [IRS Publication 515 (2026)](https://www.irs.gov/publications/p515) [Treasury Model 1A agreement, November 2014](https://home.treasury.gov/system/files/131/FATCA-Reciprocal-Model-1A-Agreement-Preexisting-TIEA-or-DTC-11-30-14.pdf)

```json
{
  "figures": [
    "1",
    "2",
    "1",
    "15"
  ],
  "id": 80,
  "kind": "sourced operative rule/condition",
  "line": 152,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Form list; chapter 4 withholding requirements; documentation and reason-to-know rules; FI/NFFE/IGA definitions",
      "source": "IRS515",
      "url": "https://www.irs.gov/publications/p515"
    },
    {
      "actual_read_date": "2026-11-16",
      "locator": "Article 1(g)–(l) and (ff) definitions; full Article 2 partner and US reporting",
      "source": "IGA",
      "url": "https://home.treasury.gov/system/files/131/FATCA-Reciprocal-Model-1A-Agreement-Preexisting-TIEA-or-DTC-11-30-14.pdf"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 9: document FATCA status and GIIN",
  "short_native_quote_ids": [
    "IRS515035",
    "IGA031"
  ],
  "source_keys": [
    "IRS515",
    "IGA"
  ]
}
```

### 81

Where the category requires registration, establish lead/member/single/sponsoring/sponsored/branch status, obtain the GIIN and check its current IRS-list/documentation requirements. The GIIN has 19 characters, shaped `XXXXXX.XXXXX.XX.XXX`, including three periods; the last three positions are numeric ISO 3166-1 country/jurisdiction code (999 for Other). IRS composition guidance excludes the letter O. Direct-reporting NFFEs and sponsoring entities can also have GIINs, so possession alone does not prove FI classification or reporting compliance. Responsible-officer certification dates/status and the precise certified-deemed-compliant exceptions are engagement-specific open items here. [IRS GIIN composition](https://www.irs.gov/businesses/corporations/fatca-registration-and-ffi-list-giin-composition-information) [IRS Publication 515 (2026)](https://www.irs.gov/publications/p515)

```json
{
  "figures": [
    "19",
    "3166",
    "1",
    "999",
    "15"
  ],
  "id": 81,
  "kind": "sourced operative rule/condition",
  "line": 154,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Introductory 19-character rule and complete category/country position table",
      "source": "GIIN",
      "url": "https://www.irs.gov/businesses/corporations/fatca-registration-and-ffi-list-giin-composition-information"
    },
    {
      "actual_read_date": "2026-11-16",
      "locator": "Form list; chapter 4 withholding requirements; documentation and reason-to-know rules; FI/NFFE/IGA definitions",
      "source": "IRS515",
      "url": "https://www.irs.gov/publications/p515"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 9: document FATCA status and GIIN",
  "short_native_quote_ids": [
    "GIIN008",
    "IRS515005"
  ],
  "source_keys": [
    "GIIN",
    "IRS515"
  ]
}
```

### 82

### Step 10: compute FATCA withholding separately from account reporting

```json
{
  "figures": [
    "10"
  ],
  "id": 82,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 156,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 10: compute FATCA withholding separately from account reporting",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 83

Chapter 4 generally requires 30% withholding on a qualifying US-source FDAP withholdable payment to an FFI unless the documented status supplies a relevant participating/deemed-compliant/exempt exception. For an NFFE, the identification/certification of substantial US owners and the applicable section 1472 exception control. A failure is not a licence to withhold only the owners' proportional slice of an otherwise withholdable NFFE payment. PFFI recalcitrant-holder duties and the special IGA conditions must be checked separately. A compliant account report does not itself eliminate withholding. [IRS Publication 515 (2026)](https://www.irs.gov/publications/p515)

```json
{
  "figures": [
    "4",
    "30%",
    "1472",
    "15"
  ],
  "id": 83,
  "kind": "sourced operative rule/condition",
  "line": 158,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Form list; chapter 4 withholding requirements; documentation and reason-to-know rules; FI/NFFE/IGA definitions",
      "source": "IRS515",
      "url": "https://www.irs.gov/publications/p515"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 10: compute FATCA withholding separately from account reporting",
  "short_native_quote_ids": [
    "IRS515005"
  ],
  "source_keys": [
    "IRS515"
  ]
}
```

### 84

FDAP includes the relevant US-source interest, dividends, rents, royalties, salaries/wages, premiums, annuities and other fixed/determinable annual/periodical income, subject to the actual statutory/regulatory exceptions. Keep source, payee, beneficial-owner/intermediary allocation, ECI/exemption documentation and chapter 3 analysis. Chapter 3 and chapter 4 are not automatically stacked into 60% on one payment. Form 1042-S/1042 payment/withholding reporting is separate from Form 8966 account information. [IRS Publication 515 (2026)](https://www.irs.gov/publications/p515) [IRS Form 1042-S instructions (2026)](https://www.irs.gov/instructions/i1042s)

```json
{
  "figures": [
    "3",
    "3",
    "4",
    "60%",
    "1042",
    "1042",
    "8966",
    "15",
    "042"
  ],
  "id": 84,
  "kind": "sourced operative rule/condition",
  "line": 160,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Form list; chapter 4 withholding requirements; documentation and reason-to-know rules; FI/NFFE/IGA definitions",
      "source": "IRS515",
      "url": "https://www.irs.gov/publications/p515"
    },
    {
      "actual_read_date": "2026-11-16",
      "locator": "Reliance on proposed regulations and FATCA reporting reminders",
      "source": "I1042",
      "url": "https://www.irs.gov/instructions/i1042s"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 10: compute FATCA withholding separately from account reporting",
  "short_native_quote_ids": [
    "IRS515036"
  ],
  "source_keys": [
    "IRS515",
    "I1042"
  ]
}
```

### 85

**Gross-proceeds and foreign-passthru boundary:** the 2025 official CFR still contains gross proceeds in section 1.1473-1(a). The published 2018 **proposed** regulations REG-132881-17 would remove gross-proceeds withholding and allow reliance until final regulations, subject to their stated exceptions. Their foreign-passthru proposal defers it until two years after publication of final regulations defining that term. The 2026 Form 1042-S instructions still acknowledge general permitted reliance on those proposals. Do not describe a proposed amendment as already enacted or impose gross-proceeds/foreign-passthru withholding from an old table alone; verify the actual payment, reliance position and later applicable final guidance before instructing withholding. The Guide does not clear a transaction-specific current passthru obligation. [Official CFR 2025, section 1.1473-1](https://www.govinfo.gov/content/pkg/CFR-2025-title26-vol14/pdf/CFR-2025-title26-vol14-sec1-1473-1.pdf) [Published FATCA proposal, REG-132881-17](https://www.govinfo.gov/content/pkg/FR-2018-12-18/pdf/2018-27290.pdf) [IRS Form 1042-S instructions (2026)](https://www.irs.gov/instructions/i1042s)

```json
{
  "figures": [
    "2025",
    "1.1473",
    "1",
    "2018",
    "132881",
    "17",
    "2026",
    "1042",
    "042"
  ],
  "id": 85,
  "kind": "sourced operative rule/condition",
  "line": 162,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Section 1.1473-1(a)(1) and (c), read with Model 1 Article 1(ff)",
      "source": "CFR",
      "url": "https://www.govinfo.gov/content/pkg/CFR-2025-title26-vol14/pdf/CFR-2025-title26-vol14-sec1-1473-1.pdf"
    },
    {
      "actual_read_date": "2026-11-16",
      "locator": "83 FR 64757: preamble I, II, Reliance on Proposed Regulations and relevant proposed changes",
      "source": "PROPOSAL",
      "url": "https://www.govinfo.gov/content/pkg/FR-2018-12-18/pdf/2018-27290.pdf"
    },
    {
      "actual_read_date": "2026-11-16",
      "locator": "Reliance on proposed regulations and FATCA reporting reminders",
      "source": "I1042",
      "url": "https://www.irs.gov/instructions/i1042s"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 10: compute FATCA withholding separately from account reporting",
  "short_native_quote_ids": [
    "CFR037",
    "PROPOSAL010",
    "I1042007"
  ],
  "source_keys": [
    "CFR",
    "PROPOSAL",
    "I1042"
  ]
}
```

### 86

### Step 11: assess CARF and EU DAC8 independently

```json
{
  "figures": [
    "11"
  ],
  "id": 86,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 164,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 11: assess CARF and EU DAC8 independently",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 87

The OECD CARF is a model framework, rather than a worldwide self-executing tax statute. The OECD commitment list dated 14 September 2026 groups first exchanges into 2027, 2028 and 2029. The old first-exchange claim for early adopters in 2026 is withdrawn. A first-exchange commitment does not by itself prove the domestic first collection period, filing date, provider nexus or activated exchange relationship. [OECD, CARF commitments, September 2026](https://www.oecd.org/content/dam/oecd/en/networks/global-forum-tax-transparency/commitments-carf.pdf)

```json
{
  "figures": [
    "14",
    "2026",
    "2027",
    "2028",
    "2029",
    "2026"
  ],
  "id": 87,
  "kind": "sourced operative rule/condition",
  "line": 166,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Whole one-page list updated 14 September 2026, with first-exchange groups for 2027, 2028 and 2029",
      "source": "CARFCOMMIT",
      "url": "https://www.oecd.org/content/dam/oecd/en/networks/global-forum-tax-transparency/commitments-carf.pdf"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 11: assess CARF and EU DAC8 independently",
  "short_native_quote_ids": [
    "CARFCOMMIT002"
  ],
  "source_keys": [
    "CARFCOMMIT"
  ]
}
```

### 88

Under current EU DAC8, Reporting Crypto-Asset Service Providers include qualifying MiCA-authorised/notified providers **and** Crypto-Asset Operators conducting covered exchange services for Reportable Users. The scope is not limited to MiCA licensees. Annex VI I applies authorisation/notification, tax residence, incorporation/legal-personality or tax-filing, management, regular-business-place and branch nexuses, with specific duplicate-reporting relief where the equivalent duties are completed in another Member State or Qualified Non-Union Jurisdiction and required notifications are made. [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1)

```json
{
  "figures": [],
  "id": 88,
  "kind": "sourced operative rule/condition",
  "line": 168,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 11: assess CARF and EU DAC8 independently",
  "short_native_quote_ids": [
    "EU082"
  ],
  "source_keys": [
    "EU"
  ]
}
```

### 89

Reportable Crypto-Assets exclude central-bank digital currencies, qualifying E-money and assets adequately determined incapable of payment or investment use. Exchange transactions include crypto-to-fiat and crypto-to-crypto; transfers, including qualifying retail payments, also matter. A Reportable Retail Payment Transaction has value **exceeding USD 50,000**, rather than at least that amount. A merchant's customer is additionally treated as a Crypto-Asset User for that payment only where the specified domestic AML identity-verification condition holds. Smaller payments may still be reportable under another transfer/exchange category. [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1)

```json
{
  "figures": [
    "50,000"
  ],
  "id": 89,
  "kind": "sourced operative rule/condition",
  "line": 170,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 11: assess CARF and EU DAC8 independently",
  "short_native_quote_ids": [
    "EU065"
  ],
  "source_keys": [
    "EU"
  ]
}
```

### 90

EU reporting covers user/entity/Controlling Person and provider identifiers; aggregate acquisitions/disposals, units and transaction counts by crypto-asset/type; retail-payment and other transfers; and specified transfers to addresses not known to belong to an FI or virtual-asset provider. Use consistently determined transaction-time fiat values and identify the currency. Obtain/validate self-certifications and identify entity Controlling Persons under Annex VI III, rather than assume a CRS file satisfies all crypto duties. [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1)

```json
{
  "figures": [],
  "id": 90,
  "kind": "sourced operative rule/condition",
  "line": 172,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 11: assess CARF and EU DAC8 independently",
  "short_native_quote_ids": [
    "EU083"
  ],
  "source_keys": [
    "EU"
  ]
}
```

### 91

Article 8ad(6) makes 2026 the first relevant reporting period and requires inter-authority exchange within nine months after calendar-year end: the first calendar-2026 exchange is therefore due by 30 September 2027. That is not a common domestic provider filing date. The old description of 1 January 2026 as the directive's "entry into force" is not used: distinguish application/first period, national transposition and the directive's formal commencement. [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1)

```json
{
  "figures": [
    "6",
    "2026",
    "2026",
    "30",
    "2027",
    "1",
    "2026"
  ],
  "id": 91,
  "kind": "sourced operative rule/condition",
  "line": 174,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Step 11: assess CARF and EU DAC8 independently",
  "short_native_quote_ids": [
    "EU050"
  ],
  "source_keys": [
    "EU"
  ]
}
```

### 92

## Deadlines and filing

```json
{
  "figures": [],
  "id": 92,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 176,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Deadlines and filing",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 93

| Route / period | Deadline or operative boundary | Official source |

```json
{
  "figures": [],
  "id": 93,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 178,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Deadlines and filing",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 94

| Direct Form 8966 filer, where required | 31 March following the calendar year, with the stated US weekend/legal-holiday next-business-day rule. Eligible automatic 90-day extension uses Form 8809-I filed by the due date; additional hardship relief has separate conditions. The non-consenting Model 2 account report does not get that automatic extension | [IRS Form 8966 instructions](https://www.irs.gov/instructions/i8966) |

```json
{
  "figures": [
    "8966",
    "31",
    "90",
    "8809",
    "2",
    "966"
  ],
  "id": 94,
  "kind": "sourced operative rule/condition",
  "line": 180,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "General instructions, purpose, who must file, filing date, extensions and electronic filing",
      "source": "I8966",
      "url": "https://www.irs.gov/instructions/i8966"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Deadlines and filing",
  "short_native_quote_ids": [
    "I8966006",
    "I8966021"
  ],
  "source_keys": [
    "I8966"
  ]
}
```

### 95

| Model 1 local reporting | Actual national deadline, rather than a presumed 30 June or 31 July. Identify nil-report and registration duties separately | [Treasury Model 1A agreement, November 2014](https://home.treasury.gov/system/files/131/FATCA-Reciprocal-Model-1A-Agreement-Preexisting-TIEA-or-DTC-11-30-14.pdf) [HMRC, how to report AEOI](https://www.gov.uk/guidance/how-to-report-automatic-exchange-of-information) [IRAS, CRS filing](https://www.iras.gov.sg/taxes/international-tax/common-reporting-standard-%28crs%29/crs-filing) |

```json
{
  "figures": [
    "1",
    "30",
    "31"
  ],
  "id": 95,
  "kind": "sourced operative rule/condition",
  "line": 181,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Article 1(g)–(l) and (ff) definitions; full Article 2 partner and US reporting",
      "source": "IGA",
      "url": "https://home.treasury.gov/system/files/131/FATCA-Reciprocal-Model-1A-Agreement-Preexisting-TIEA-or-DTC-11-30-14.pdf"
    },
    {
      "actual_read_date": "2026-11-16",
      "locator": "Annual 31 May deadline and separate CRS/FATCA schemas from 2027",
      "source": "UKREPORT",
      "url": "https://www.gov.uk/guidance/how-to-report-automatic-exchange-of-information"
    },
    {
      "actual_read_date": "2026-11-16",
      "locator": "Annual and nil returns, 31 May deadline, late/non-filing penalty, extension exceptions, portal and XML change",
      "source": "SGFILE",
      "url": "https://www.iras.gov.sg/taxes/international-tax/common-reporting-standard-%28crs%29/crs-filing"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Deadlines and filing",
  "short_native_quote_ids": [
    "IGA003",
    "UKREPORT012",
    "UKREPORT022",
    "UKREPORT023",
    "SGFILE016",
    "SGFILE024",
    "SGFILE025"
  ],
  "source_keys": [
    "IGA",
    "UKREPORT",
    "SGFILE"
  ]
}
```

### 96

| UK CRS/FATCA return | 31 May after calendar-year end. Thus calendar 2025 is due 31 May 2026 under the published rule; apply any actual relief separately | [HMRC, how to report AEOI](https://www.gov.uk/guidance/how-to-report-automatic-exchange-of-information) |

```json
{
  "figures": [
    "31",
    "2025",
    "31",
    "2026"
  ],
  "id": 96,
  "kind": "sourced operative rule/condition",
  "line": 182,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Annual 31 May deadline and separate CRS/FATCA schemas from 2027",
      "source": "UKREPORT",
      "url": "https://www.gov.uk/guidance/how-to-report-automatic-exchange-of-information"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Deadlines and filing",
  "short_native_quote_ids": [
    "UKREPORT012",
    "UKREPORT022",
    "UKREPORT023"
  ],
  "source_keys": [
    "UKREPORT"
  ]
}
```

### 97

| Germany CRS, FKAustG section 27(2) | 31 July following the reporting calendar year, not the former 31 May. Authority-to-authority exchange by 30 September is a separate date | [Germany, FKAustG](https://www.gesetze-im-internet.de/fkaustg/BJNR253110015.html) |

```json
{
  "figures": [
    "27",
    "2",
    "31",
    "31",
    "30"
  ],
  "id": 97,
  "kind": "sourced operative rule/condition",
  "line": 183,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Sections 27(1)–(3) and 28(1)–(3), including all offence branches and their application dates",
      "source": "DE",
      "url": "https://www.gesetze-im-internet.de/fkaustg/BJNR253110015.html"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Deadlines and filing",
  "short_native_quote_ids": [
    "DE013",
    "DE026"
  ],
  "source_keys": [
    "DE"
  ]
}
```

### 98

| France CRS | 31 July after calendar-year end under the cited official BOFiP deadline; do not confuse the separate L.102 AG declaration due in March or the FATCA transmission calendar | [France, BOI-INT-AEA-20-40](https://bofip.impots.gouv.fr/bofip/10340-PGP.html/identifiant=BOI-INT-AEA-20-40-20200226) |

```json
{
  "figures": [
    "31",
    "102"
  ],
  "id": 98,
  "kind": "sourced operative rule/condition",
  "line": 184,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Version 26 February 2020, III.A/B paragraphs 330–355: CRS and separate L.102 AG declarations",
      "source": "FRCRS",
      "url": "https://bofip.impots.gouv.fr/bofip/10340-PGP.html/identifiant=BOI-INT-AEA-20-40-20200226"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Deadlines and filing",
  "short_native_quote_ids": [
    "FRCRS014"
  ],
  "source_keys": [
    "FRCRS"
  ]
}
```

### 99

| France FATCA income 2025, 2026 campaign | The official version 5.3 calendar specifies regulatory deposit by 15 July 2026. This particular campaign is not authority for an unverified 2027 deadline | [France, FATCA specifications v5.3](https://www.impots.gouv.fr/sites/default/files/media/1_metier/3_partenaire/tiers_declarants/cdc_td_bilateral/cahier-des-charges-fatca-v5.3.pdf) |

```json
{
  "figures": [
    "2025",
    "2026",
    "5.3",
    "15",
    "2026",
    "2027"
  ],
  "id": 99,
  "kind": "sourced operative rule/condition",
  "line": 185,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Cover, version history and printed page 10 calendar for 2026 deposits concerning 2025 income",
      "source": "FRFATCA",
      "url": "https://www.impots.gouv.fr/sites/default/files/media/1_metier/3_partenaire/tiers_declarants/cdc_td_bilateral/cahier-des-charges-fatca-v5.3.pdf"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Deadlines and filing",
  "short_native_quote_ids": [
    "FRFATCA015"
  ],
  "source_keys": [
    "FRFATCA"
  ]
}
```

### 100

| Singapore CRS | 31 May following the calendar year; nil return where applicable. Calendar 2025 return due 31 May 2026. Filing-extension exceptions are specific, not automatic | [IRAS, CRS filing](https://www.iras.gov.sg/taxes/international-tax/common-reporting-standard-%28crs%29/crs-filing) |

```json
{
  "figures": [
    "31",
    "2025",
    "31",
    "2026"
  ],
  "id": 100,
  "kind": "sourced operative rule/condition",
  "line": 186,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Annual and nil returns, 31 May deadline, late/non-filing penalty, extension exceptions, portal and XML change",
      "source": "SGFILE",
      "url": "https://www.iras.gov.sg/taxes/international-tax/common-reporting-standard-%28crs%29/crs-filing"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Deadlines and filing",
  "short_native_quote_ids": [
    "SGFILE016",
    "SGFILE024",
    "SGFILE025"
  ],
  "source_keys": [
    "SGFILE"
  ]
}
```

### 101

| Australia CRS/FATCA | The former blanket 31 May deadline is unusable; current local filing date, concessions and portal for the actual period remain on Not yet confirmed | Not yet confirmed: current Australian primary filing instructions |

```json
{
  "figures": [
    "31"
  ],
  "id": 101,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 187,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Deadlines and filing",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 102

Form 8966 FI filers generally use electronic filing regardless of return count, subject to the stated waiver process, and the instructions refer to IDES and the applicable XML publications. Do not treat Form 1042-S's filing system as the account-information route. For the UK, use HMRC registration/reporting access and the permitted submission format; CRS and FATCA become separate schemas from **1 January 2027**, including corrections for earlier periods, and the combined schema ends after **31 December 2026**. Singapore likewise requires CRS XML version 3 from **1 January 2027** for new/nil/corrected/deleted submissions; its amended CRS substantive rules start then. Portal acceptance and a technically optional field do not waive a legal information requirement. [IRS Form 8966 instructions](https://www.irs.gov/instructions/i8966) [HMRC, how to report AEOI](https://www.gov.uk/guidance/how-to-report-automatic-exchange-of-information) [IRAS, CRS filing](https://www.iras.gov.sg/taxes/international-tax/common-reporting-standard-%28crs%29/crs-filing) [IRAS, CRS overview and latest developments](https://www.iras.gov.sg/taxes/international-tax/common-reporting-standard-%28crs%29/crs-overview-and-latest-developments)

```json
{
  "figures": [
    "8966",
    "1042",
    "1",
    "2027",
    "31",
    "2026",
    "3",
    "1",
    "2027",
    "966"
  ],
  "id": 102,
  "kind": "sourced operative rule/condition",
  "line": 189,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "General instructions, purpose, who must file, filing date, extensions and electronic filing",
      "source": "I8966",
      "url": "https://www.irs.gov/instructions/i8966"
    },
    {
      "actual_read_date": "2026-11-16",
      "locator": "Annual 31 May deadline and separate CRS/FATCA schemas from 2027",
      "source": "UKREPORT",
      "url": "https://www.gov.uk/guidance/how-to-report-automatic-exchange-of-information"
    },
    {
      "actual_read_date": "2026-11-16",
      "locator": "Annual and nil returns, 31 May deadline, late/non-filing penalty, extension exceptions, portal and XML change",
      "source": "SGFILE",
      "url": "https://www.iras.gov.sg/taxes/international-tax/common-reporting-standard-%28crs%29/crs-filing"
    },
    {
      "actual_read_date": "2026-11-16",
      "locator": "2026 amendment publication, substantive commencement on 1 January 2027 and XML version transition",
      "source": "SGOV",
      "url": "https://www.iras.gov.sg/taxes/international-tax/common-reporting-standard-%28crs%29/crs-overview-and-latest-developments"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Deadlines and filing",
  "short_native_quote_ids": [
    "I8966006",
    "I8966021",
    "UKREPORT012",
    "UKREPORT022",
    "UKREPORT023",
    "SGFILE016",
    "SGFILE024",
    "SGFILE025",
    "SGOV017"
  ],
  "source_keys": [
    "I8966",
    "UKREPORT",
    "SGFILE",
    "SGOV"
  ]
}
```

### 103

An FI's use of an agent does not automatically transfer its legal responsibility. The UK guidance requires separate reports for each Reporting FI in a group; nil-report obligations differ, including specified de-minimis arrangements. Retain the return, acknowledgement/error log, submission authority and corrections schedule. This Guide does not authorise filing through a live account or provide a universal XML version for every receiving authority. [HMRC, AEOI financial institutions](https://www.gov.uk/guidance/automatic-exchange-of-information-financial-institutions) [IRS Form 8966 instructions](https://www.irs.gov/instructions/i8966)

```json
{
  "figures": [
    "966"
  ],
  "id": 103,
  "kind": "sourced operative rule/condition",
  "line": 191,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Main guidance: 2026 scope, reporting entity responsibility, group reports and nil returns",
      "source": "UKFI",
      "url": "https://www.gov.uk/guidance/automatic-exchange-of-information-financial-institutions"
    },
    {
      "actual_read_date": "2026-11-16",
      "locator": "General instructions, purpose, who must file, filing date, extensions and electronic filing",
      "source": "I8966",
      "url": "https://www.irs.gov/instructions/i8966"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Deadlines and filing",
  "short_native_quote_ids": [
    "UKFI038"
  ],
  "source_keys": [
    "UKFI",
    "I8966"
  ]
}
```

### 104

## Penalties and interest

```json
{
  "figures": [],
  "id": 104,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 193,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Penalties and interest",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 105

**UK replacement law:** SI 2025/740 took effect on **16 July 2025** and replaced regulations 13–22 with regulations 22A–22N. The old HMRC CC/FS46 factsheet's GBP 300 plus GBP 60/day amounts and the Guide's other GBP 3,000 shorthand are not current general AEOI penalties. Use the actual obligation-specific rules and transitional/application conditions; the same amending instrument defers specified amended CRS definitions to periods from 2026. [UK SI 2025/740](https://www.legislation.gov.uk/uksi/2025/740/made/data.html)

```json
{
  "figures": [
    "2025",
    "740",
    "16",
    "2025",
    "13",
    "22",
    "6",
    "300",
    "60",
    "3,000",
    "2026"
  ],
  "id": 105,
  "kind": "sourced operative rule/condition",
  "line": 195,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Regulations 1, 3, 6, 9 and 11–14; substituted regulations 22A–22N, including all penalty conditions and commencement",
      "source": "UKLAW",
      "url": "https://www.legislation.gov.uk/uksi/2025/740/made/data.html"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Penalties and interest",
  "short_native_quote_ids": [
    "UKLAW039",
    "UKLAW040"
  ],
  "source_keys": [
    "UKLAW"
  ]
}
```

### 106

| UK obligation | Current statutory maximum and operative condition | Source |

```json
{
  "figures": [],
  "id": 106,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 197,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Penalties and interest",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 107

| Due diligence, regulation 22A(1) | GBP 100 per person for failure to comply with the specified due-diligence requirements, subject to the self-certification exception below | [UK SI 2025/740](https://www.legislation.gov.uk/uksi/2025/740/made/data.html) |

```json
{
  "figures": [
    "1",
    "100"
  ],
  "id": 107,
  "kind": "sourced operative rule/condition",
  "line": 199,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Regulations 1, 3, 6, 9 and 11–14; substituted regulations 22A–22N, including all penalty conditions and commencement",
      "source": "UKLAW",
      "url": "https://www.legislation.gov.uk/uksi/2025/740/made/data.html"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Penalties and interest",
  "short_native_quote_ids": [
    "UKLAW085"
  ],
  "source_keys": [
    "UKLAW"
  ]
}
```

### 108

| Valid self-certification, 22A(2) | GBP 300 per person for the specified failure to obtain a valid self-certification | [UK SI 2025/740](https://www.legislation.gov.uk/uksi/2025/740/made/data.html) |

```json
{
  "figures": [
    "2",
    "300"
  ],
  "id": 108,
  "kind": "sourced operative rule/condition",
  "line": 200,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Regulations 1, 3, 6, 9 and 11–14; substituted regulations 22A–22N, including all penalty conditions and commencement",
      "source": "UKLAW",
      "url": "https://www.legislation.gov.uk/uksi/2025/740/made/data.html"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Penalties and interest",
  "short_native_quote_ids": [
    "UKLAW086"
  ],
  "source_keys": [
    "UKLAW"
  ]
}
```

### 109

| Records, 22B | GBP 5,000 for the specified relevant period's recordkeeping failure | [UK SI 2025/740](https://www.legislation.gov.uk/uksi/2025/740/made/data.html) |

```json
{
  "figures": [
    "5,000"
  ],
  "id": 109,
  "kind": "sourced operative rule/condition",
  "line": 201,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Regulations 1, 3, 6, 9 and 11–14; substituted regulations 22A–22N, including all penalty conditions and commencement",
      "source": "UKLAW",
      "url": "https://www.legislation.gov.uk/uksi/2025/740/made/data.html"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Penalties and interest",
  "short_native_quote_ids": [
    "UKLAW087"
  ],
  "source_keys": [
    "UKLAW"
  ]
}
```

### 110

| Report, 22C | GBP 5,000 for failure to report, with up to GBP 600/day for continuation after notification of assessment, subject to the statutory conditions | [UK SI 2025/740](https://www.legislation.gov.uk/uksi/2025/740/made/data.html) |

```json
{
  "figures": [
    "5,000",
    "600"
  ],
  "id": 110,
  "kind": "sourced operative rule/condition",
  "line": 202,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Regulations 1, 3, 6, 9 and 11–14; substituted regulations 22A–22N, including all penalty conditions and commencement",
      "source": "UKLAW",
      "url": "https://www.legislation.gov.uk/uksi/2025/740/made/data.html"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Penalties and interest",
  "short_native_quote_ids": [
    "UKLAW088"
  ],
  "source_keys": [
    "UKLAW"
  ]
}
```

### 111

| Inaccurate report, 22D | GBP 100 per person where the specified careless/deliberate or discovered-inaccuracy conditions apply | [UK SI 2025/740](https://www.legislation.gov.uk/uksi/2025/740/made/data.html) |

```json
{
  "figures": [
    "100"
  ],
  "id": 111,
  "kind": "sourced operative rule/condition",
  "line": 203,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Regulations 1, 3, 6, 9 and 11–14; substituted regulations 22A–22N, including all penalty conditions and commencement",
      "source": "UKLAW",
      "url": "https://www.legislation.gov.uk/uksi/2025/740/made/data.html"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Penalties and interest",
  "short_native_quote_ids": [
    "UKLAW089"
  ],
  "source_keys": [
    "UKLAW"
  ]
}
```

### 112

| Required notifications, 22E | GBP 100 per person and up to GBP 100/day for the stated continuing failure after assessment notification | [UK SI 2025/740](https://www.legislation.gov.uk/uksi/2025/740/made/data.html) |

```json
{
  "figures": [
    "100",
    "100"
  ],
  "id": 112,
  "kind": "sourced operative rule/condition",
  "line": 204,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Regulations 1, 3, 6, 9 and 11–14; substituted regulations 22A–22N, including all penalty conditions and commencement",
      "source": "UKLAW",
      "url": "https://www.legislation.gov.uk/uksi/2025/740/made/data.html"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Penalties and interest",
  "short_native_quote_ids": [
    "UKLAW090"
  ],
  "source_keys": [
    "UKLAW"
  ]
}
```

### 113

| Registration, 22F | GBP 1,000 and up to GBP 300/day for the stated continuing failure after assessment notification | [UK SI 2025/740](https://www.legislation.gov.uk/uksi/2025/740/made/data.html) |

```json
{
  "figures": [
    "1,000",
    "300"
  ],
  "id": 113,
  "kind": "sourced operative rule/condition",
  "line": 205,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Regulations 1, 3, 6, 9 and 11–14; substituted regulations 22A–22N, including all penalty conditions and commencement",
      "source": "UKLAW",
      "url": "https://www.legislation.gov.uk/uksi/2025/740/made/data.html"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Penalties and interest",
  "short_native_quote_ids": [
    "UKLAW041"
  ],
  "source_keys": [
    "UKLAW"
  ]
}
```

### 114

| Information/documents, 22G | GBP 5,000 and up to GBP 600/day after assessment notification for continued failure to comply | [UK SI 2025/740](https://www.legislation.gov.uk/uksi/2025/740/made/data.html) |

```json
{
  "figures": [
    "5,000",
    "600"
  ],
  "id": 114,
  "kind": "sourced operative rule/condition",
  "line": 206,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Regulations 1, 3, 6, 9 and 11–14; substituted regulations 22A–22N, including all penalty conditions and commencement",
      "source": "UKLAW",
      "url": "https://www.legislation.gov.uk/uksi/2025/740/made/data.html"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Penalties and interest",
  "short_native_quote_ids": [
    "UKLAW042"
  ],
  "source_keys": [
    "UKLAW"
  ]
}
```

### 115

| Self-certification provider, 22H | GBP 300 for a deliberate or careless failure to provide a valid self-certification under regulation 12GA | [UK SI 2025/740](https://www.legislation.gov.uk/uksi/2025/740/made/data.html) |

```json
{
  "figures": [
    "300"
  ],
  "id": 115,
  "kind": "sourced operative rule/condition",
  "line": 207,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Regulations 1, 3, 6, 9 and 11–14; substituted regulations 22A–22N, including all penalty conditions and commencement",
      "source": "UKLAW",
      "url": "https://www.legislation.gov.uk/uksi/2025/740/made/data.html"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Penalties and interest",
  "short_native_quote_ids": [
    "UKLAW091"
  ],
  "source_keys": [
    "UKLAW"
  ]
}
```

### 116

Read the statutory assessment and continued-failure triggers before computing days. Regulations 22I–22N include reasonable excuse, assessment/payment and appeal rules; funds shortage or reliance on another person alone is not an excuse, and a ceased excuse must be remedied without unreasonable delay. There is no double penalty under 22A, 22B and 22D for the same act/omission. The notification-based assessment and appeal time limits, and any reasonable care or other culpability condition, cannot be replaced with a strict-liability slogan. No general AEOI late-payment interest rate is determined here. [UK SI 2025/740](https://www.legislation.gov.uk/uksi/2025/740/made/data.html)

```json
{
  "figures": [],
  "id": 116,
  "kind": "sourced operative rule/condition",
  "line": 209,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Regulations 1, 3, 6, 9 and 11–14; substituted regulations 22A–22N, including all penalty conditions and commencement",
      "source": "UKLAW",
      "url": "https://www.legislation.gov.uk/uksi/2025/740/made/data.html"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Penalties and interest",
  "short_native_quote_ids": [
    "UKLAW046"
  ],
  "source_keys": [
    "UKLAW"
  ]
}
```

### 117

| Other jurisdiction | Confirmed position or explicit unusable hold | Official source |

```json
{
  "figures": [],
  "id": 117,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 211,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Penalties and interest",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 118

| Germany CRS | Section 28 covers intentional or reckless specified failures. Maximum EUR 50,000 applies to paragraph 1 points 5b and 6–20; the other listed cases have a EUR 10,000 maximum. It is not EUR 50,000 for every mistake | [Germany, FKAustG](https://www.gesetze-im-internet.de/fkaustg/BJNR253110015.html) |

```json
{
  "figures": [
    "28",
    "50,000",
    "1",
    "6",
    "20",
    "10,000",
    "50,000"
  ],
  "id": 118,
  "kind": "sourced operative rule/condition",
  "line": 213,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Sections 27(1)–(3) and 28(1)–(3), including all offence branches and their application dates",
      "source": "DE",
      "url": "https://www.gesetze-im-internet.de/fkaustg/BJNR253110015.html"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Penalties and interest",
  "short_native_quote_ids": [
    "DE013",
    "DE026"
  ],
  "source_keys": [
    "DE"
  ]
}
```

### 119

| Singapore CRS | IRAS filing guidance states a fine up to SGD 5,000 for late/non-filing. The old additional general 12-month imprisonment claim is not cleared for that offence by this source | [IRAS, CRS filing](https://www.iras.gov.sg/taxes/international-tax/common-reporting-standard-%28crs%29/crs-filing) |

```json
{
  "figures": [
    "5,000",
    "12"
  ],
  "id": 119,
  "kind": "sourced operative rule/condition",
  "line": 214,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Annual and nil returns, 31 May deadline, late/non-filing penalty, extension exceptions, portal and XML change",
      "source": "SGFILE",
      "url": "https://www.iras.gov.sg/taxes/international-tax/common-reporting-standard-%28crs%29/crs-filing"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Penalties and interest",
  "short_native_quote_ids": [
    "SGFILE016",
    "SGFILE024",
    "SGFILE025"
  ],
  "source_keys": [
    "SGFILE"
  ]
}
```

### 120

| US FATCA | Form 8966 instructions identify potential sections 6721–6724 consequences for failure to meet required electronic filing. The superseded/unverified general penalty amounts are individually unusable on Sources; identify the actual provision, year, correction window and intent before quoting an amount | [IRS Form 8966 instructions](https://www.irs.gov/instructions/i8966) |

```json
{
  "figures": [
    "8966",
    "6721",
    "6724",
    "966"
  ],
  "id": 120,
  "kind": "sourced operative rule/condition",
  "line": 215,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "General instructions, purpose, who must file, filing date, extensions and electronic filing",
      "source": "I8966",
      "url": "https://www.irs.gov/instructions/i8966"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Penalties and interest",
  "short_native_quote_ids": [
    "I8966043"
  ],
  "source_keys": [
    "I8966"
  ]
}
```

### 121

| Australia | The former base plus indexation is individually unusable on Sources pending current statutory penalty-unit, entity-size and offence verification | Not yet confirmed: current Australian AEOI penalty computation |

```json
{
  "figures": [],
  "id": 121,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 216,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Penalties and interest",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 122

| Switzerland | The former "per failure" amount is individually unusable on Sources as a universal FATCA/AEOIA penalty. Identify offence, responsible person/entity, culpability and operative current law | Not yet confirmed: current Swiss FATCA/AEOIA sanctions |

```json
{
  "figures": [],
  "id": 122,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 217,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Penalties and interest",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 123

FATCA 30% withholding exposure is separate from these administrative fines. Do not add it automatically to the account balance as a penalty or guarantee the account holder alone bears the legal liability. [IRS Publication 515 (2026)](https://www.irs.gov/publications/p515)

```json
{
  "figures": [
    "30%",
    "15"
  ],
  "id": 123,
  "kind": "sourced operative rule/condition",
  "line": 219,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Form list; chapter 4 withholding requirements; documentation and reason-to-know rules; FI/NFFE/IGA definitions",
      "source": "IRS515",
      "url": "https://www.irs.gov/publications/p515"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Penalties and interest",
  "short_native_quote_ids": [
    "IRS515005"
  ],
  "source_keys": [
    "IRS515"
  ]
}
```

### 124

## Cross-border points

```json
{
  "figures": [],
  "id": 124,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 221,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Cross-border points",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 125

**Anti-avoidance:** EU Annex I IX requires rules preventing circumvention, compliance and records, including records available **not longer than necessary but in any event not less than five years**. The actual local retention start event and any other applicable retention rule require their own authority; Annex I does not state the crypto-provider end-of-report-period clock. Do not invent a uniform worldwide "primary purpose" test or assume responsible-officer certification is itself the whole anti-avoidance law. Record the actual local rule, any FATCA responsible-officer obligations and whether the separate OECD MDR/DAC6 analysis is required; do not advise on reshuffling residence or entity labels to suppress reporting. [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1)

```json
{
  "figures": [],
  "id": 125,
  "kind": "sourced operative rule/condition",
  "line": 223,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Cross-border points",
  "short_native_quote_ids": [
    "EU030"
  ],
  "source_keys": [
    "EU"
  ]
}
```

### 126

**Privacy and US–EU exchange:** the original CJEU citation C-457/21 P is incorrect. The Court's official 14 December 2023 announcement identifies that appeal as **Commission v Amazon.com and Others**, concerning Luxembourg state aid. It does not establish blanket FATCA/GDPR legality. Preserve the privacy question as an unresolved, jurisdiction-specific legal check: the applicable IGA, domestic basis, data-protection safeguards and any operative restriction/judgment need actual review. No FATCA privacy clearance is supplied by the miscited case. [CJEU press release 190/23](https://curia.europa.eu/site/upload/docs/application/pdf/2023-12/cp230190en.pdf)

```json
{
  "figures": [
    "457",
    "21",
    "14",
    "2023"
  ],
  "id": 126,
  "kind": "sourced operative rule/condition",
  "line": 225,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Headline and opening paragraphs identifying C-457/21 P, Commission v Amazon.com and Others",
      "source": "CASE",
      "url": "https://curia.europa.eu/site/upload/docs/application/pdf/2023-12/cp230190en.pdf"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Cross-border points",
  "short_native_quote_ids": [
    "CASE018"
  ],
  "source_keys": [
    "CASE"
  ]
}
```

### 127

**Insurance, joint holders, trusts and low-value elections:** do not erase these questions merely because an account has one documented owner, a charitable label, a low balance or a trustee with a GIIN. Verify the account-definition/exclusion, all owners' full aggregation, the exact Active category, the controlling-person chain and the chosen local threshold election. A correct CRS classification does not prove FATCA, CARF or AML treatment. [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1) [Treasury Model 1 Annex I](https://home.treasury.gov/system/files/131/FATCA-Annex-I-to-Model-1-Agreement-11-30-14.pdf) [IRS Publication 515 (2026)](https://www.irs.gov/publications/p515)

```json
{
  "figures": [
    "15"
  ],
  "id": 127,
  "kind": "sourced operative rule/condition",
  "line": 227,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    },
    {
      "actual_read_date": "2026-11-16",
      "locator": "Section II.A individual exclusions; Section IV entity thresholds; Section VI.A/B Active NFFE categories and Determination Date",
      "source": "ANNEX",
      "url": "https://home.treasury.gov/system/files/131/FATCA-Annex-I-to-Model-1-Agreement-11-30-14.pdf"
    },
    {
      "actual_read_date": "2026-11-16",
      "locator": "Form list; chapter 4 withholding requirements; documentation and reason-to-know rules; FI/NFFE/IGA definitions",
      "source": "IRS515",
      "url": "https://www.irs.gov/publications/p515"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Cross-border points",
  "short_native_quote_ids": [
    "EU093",
    "ANNEX004",
    "IRS515005"
  ],
  "source_keys": [
    "EU",
    "ANNEX",
    "IRS515"
  ]
}
```

### 128

## Worked examples

```json
{
  "figures": [],
  "id": 128,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 229,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Worked examples",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 129

### Example 1: the Active NFE decision needs both tests

```json
{
  "figures": [
    "1"
  ],
  "id": 129,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 231,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Example 1: the Active NFE decision needs both tests",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 130

Assume a non-FI company with no other Active category, preceding-period gross income of USD 200,000, passive income USD 98,000 and average assets USD 600,000. With USD 294,000 passive-producing assets, both shares are 49%, so category (a) is available. If passive assets are instead USD 300,000, their share is exactly 50%, and that category fails despite the same 49% passive-income share. Identify reportable Controlling Persons if the resulting Passive NFE has the relevant account; this example does not prove its residence or a reportable jurisdiction. All dollar inputs are hypothetical; the dual less-than-50% test is EU Annex I VIII.D(8)(a). [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1)

```json
{
  "figures": [
    "200,000",
    "98,000",
    "600,000",
    "294,000",
    "49%",
    "300,000",
    "50%",
    "49%",
    "50%",
    "8"
  ],
  "id": 130,
  "kind": "sourced operative rule/condition",
  "line": 233,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Example 1: the Active NFE decision needs both tests",
  "short_native_quote_ids": [
    "EU083"
  ],
  "source_keys": [
    "EU"
  ]
}
```

### 131

### Example 2: full joint aggregation changes the high-value decision

```json
{
  "figures": [
    "2"
  ],
  "id": 131,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 253,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Example 2: full joint aggregation changes the high-value decision",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 132

Assume two reportable holders, A and B, share a USD 800,000 account. At the same FI A also has USD 250,000, and B USD 100,000, with the computerised linking conditions satisfied. Attribute USD 800,000 to **each**: A's aggregate is USD 1,050,000, above the USD 1,000,000 high-value threshold; B's is USD 900,000. A false half-share allocation would produce USD 650,000 for A and miss enhanced review. Report the full USD 800,000 joint-account balance for each reportable holder, not USD 400,000 each; this is not a statement that the underlying assets doubled. All inputs are hypothetical; use the actual account/year and residence facts. [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1) [OECD, consolidated CRS (2025)](https://www.oecd.org/content/dam/oecd/en/publications/reports/2025/04/consolidated-text-of-the-common-reporting-standard-2025_e478bc04/055664b1-en.pdf)

```json
{
  "figures": [
    "800,000",
    "250,000",
    "100,000",
    "800,000",
    "1,050,000",
    "1,000,000",
    "900,000",
    "650,000",
    "800,000",
    "400,000"
  ],
  "id": 132,
  "kind": "sourced operative rule/condition",
  "line": 255,
  "operative_bindings": [
    {
      "actual_read_date": "2026-11-16",
      "locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV",
      "source": "EU",
      "url": "https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1"
    },
    {
      "actual_read_date": "2026-11-16",
      "locator": "Section VIII.D/E definitions and full Active categories; Commentary on Section I paragraph 13 joint reporting; selected FI and aggregation clauses",
      "source": "CRS",
      "url": "https://www.oecd.org/content/dam/oecd/en/publications/reports/2025/04/consolidated-text-of-the-common-reporting-standard-2025_e478bc04/055664b1-en.pdf"
    }
  ],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Example 2: full joint aggregation changes the high-value decision",
  "short_native_quote_ids": [
    "EU052",
    "CRS001",
    "CRS020"
  ],
  "source_keys": [
    "EU",
    "CRS"
  ]
}
```

### 133

## Ask the client first

```json
{
  "figures": [],
  "id": 133,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 278,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Ask the client first",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 134

1. Where is each institution/branch/provider resident, established, authorised and reporting, and what are the exact data and filing periods?

```json
{
  "figures": [
    "1"
  ],
  "id": 134,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 280,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Ask the client first",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 135

2. What activities, gross-income/asset evidence, manager permissions and group relationships establish FI or a precise Active category?

```json
{
  "figures": [
    "2"
  ],
  "id": 135,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 281,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Ask the client first",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 136

3. Who legally/beneficially holds each account, who controls each relevant entity/trust, and where is each person tax-resident?

```json
{
  "figures": [
    "3"
  ],
  "id": 136,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 282,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Ask the client first",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 137

4. When was each account opened, what year-end/aggregate values and currencies apply, and what threshold elections/documentation changes are recorded?

```json
{
  "figures": [
    "4"
  ],
  "id": 137,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 283,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Ask the client first",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 138

5. What signed self-certifications, AML/KYC evidence, US indicia, GIIN status and reporting acknowledgements exist?

```json
{
  "figures": [
    "5"
  ],
  "id": 138,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 284,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Ask the client first",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 139

6. What US-source payments or crypto transactions occurred, what amounts/types, and which withholding, schema, portal and privacy issues remain unresolved?

```json
{
  "figures": [
    "6"
  ],
  "id": 139,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 285,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Ask the client first",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 140

## Reviewer output and completion checklist

```json
{
  "figures": [],
  "id": 140,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 287,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Reviewer output and completion checklist",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 141

The reviewer brief retains all ten original output topics: (1) FI/NFE conclusion and authority; (2) GIIN/registration/branch/sponsor status; (3) precise Active/Passive category and evidence; (4) Financial Account inventory, actual holders, Controlling Persons and full aggregates; (5) account-by-account reportability and local jurisdiction-list basis; (6) self-certification, indicia, cures and due-diligence log; (7) reporting schedule/schema/payload/deadline; (8) payment-specific FATCA withholding exposure; (9) CARF/DAC8 provider/user readiness; and (10) unresolved reviewer questions. Old T1/T2/T3 marks are not accountant approval or substitutes for an explicit non-usable hold.

```json
{
  "figures": [
    "1",
    "2",
    "3",
    "4",
    "5",
    "6",
    "7",
    "8",
    "9",
    "10"
  ],
  "id": 141,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 289,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Reviewer output and completion checklist",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 142

- [ ] Test all four CRS FI categories and the separately applicable FATCA definition.

```json
{
  "figures": [],
  "id": 142,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 291,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Reviewer output and completion checklist",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 143

- [ ] Apply both Investment Entity limbs correctly, with at-least-50% and the correct management condition.

```json
{
  "figures": [
    "50%"
  ],
  "id": 143,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 292,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Reviewer output and completion checklist",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 144

- [ ] Test every potentially applicable Active category: eight under CRS, the actual IGA/regulatory FATCA categories separately.

```json
{
  "figures": [],
  "id": 144,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 293,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Reviewer output and completion checklist",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 145

- [ ] Identify all relevant controlling persons and trust roles; do not stop at an ownership percentage alone.

```json
{
  "figures": [],
  "id": 145,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 294,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Reviewer output and completion checklist",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 146

- [ ] Complete required pre-existing-account indicia, paper-record and relationship-manager procedures and document exceptions.

```json
{
  "figures": [],
  "id": 146,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 295,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Reviewer output and completion checklist",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 147

- [ ] Apply linked-account aggregation and full joint balances to the actual threshold/year.

```json
{
  "figures": [],
  "id": 147,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 296,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Reviewer output and completion checklist",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 148

- [ ] Use full joint reporting for each reportable holder; do not invent a proportional-ownership exception.

```json
{
  "figures": [],
  "id": 148,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 297,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Reviewer output and completion checklist",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 149

- [ ] Verify GIIN/documentation status where required; do not infer compliance from its presence.

```json
{
  "figures": [],
  "id": 149,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 298,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Reviewer output and completion checklist",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 150

- [ ] Match XML/schema, legal fields and portal to the actual authority and submission date.

```json
{
  "figures": [],
  "id": 150,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 299,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Reviewer output and completion checklist",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 151

- [ ] Plot each local filing, permitted extension, correction and inter-authority exchange date separately.

```json
{
  "figures": [],
  "id": 151,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 300,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Reviewer output and completion checklist",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 152

- [ ] Determine crypto reporting independently, with actual provider nexus and domestic commencement.

```json
{
  "figures": [],
  "id": 152,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 301,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Reviewer output and completion checklist",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 153

- [ ] Flag all unresolved questions explicitly for the practitioner before any self-certification, onboarding or filing decision.

```json
{
  "figures": [],
  "id": 153,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 302,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Reviewer output and completion checklist",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 154

Retain the six refusal gates: no unsupported Active classification; no reliance on absence of indicia against actual manager knowledge; no reliance on contradictory self-certification; no undeclared threshold election; no exemption from crypto reporting merely because the provider is not a conventional FI; and no reporting-avoidance structuring advice without specialist escalation and the separate disclosure analysis. These are workflow safeguards, not invented statutory safe harbours.

```json
{
  "figures": [],
  "id": 154,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 304,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Reviewer output and completion checklist",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 155

### Disclaimer

```json
{
  "figures": [],
  "id": 155,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 306,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Disclaimer",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 156

This Guide and its outputs provide general tax/accounting reference, not tax, legal or financial advice for a person's facts. FATCA/CRS classification varies by applicable law, IGA, period and evidence. A qualified practitioner must review and sign off before a self-certification, filing or onboarding decision. Professional names, approvals or statutory culpability cannot be supplied by an AI research pass.

```json
{
  "figures": [],
  "id": 156,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 308,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Disclaimer",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 157

## Sources

```json
{
  "figures": [],
  "id": 157,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 310,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Sources",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 158

**Individual FATCA category reservations:** the original proposed **local FFI**, **qualified credit card issuer**, **limited-life debt funds**, and exempt-beneficial-owner examples of **government entities**, **international organisations**, **central banks** and **treaty-qualified retirement funds** are preserved as specific research questions. Their precise applicable regulatory/IGA category, conditions, certification/registration and current relief have not been established here; each proposed shortcut is **non-usable** until those conditions are verified. A category name alone does not confer deemed-compliant or exempt status.

```json
{
  "figures": [],
  "id": 158,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 312,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Sources",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 159

Actual reads on 16 November 2026 cover the operative scopes below and their stated neighboring conditions, rather than every page of every standard. Ordinary failed/challenge requests are not source reads. Retained official copies and successful official web-body reads were used; model standards are distinguished from enacted local law.

```json
{
  "figures": [
    "16",
    "2026"
  ],
  "id": 159,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 314,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Sources",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 160

| Official source | Actual operative read scope and limitations | Read on |

```json
{
  "figures": [],
  "id": 160,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 316,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Sources",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 161

| [EU Directive 2011/16/EU, consolidated 1 January 2026](https://publications.europa.eu/resource/cellar/4328aa6c-1209-11f1-8870-01aa75ed71a1.0002.02/DOC_1) | Read for Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV. Official current consolidated XHTML; actual used paragraphs and neighboring exceptions read; not every unrelated Directive article. | 2026-11-16 |

```json
{
  "figures": [
    "2011",
    "16",
    "1",
    "2026",
    "8",
    "8",
    "6",
    "1",
    "6",
    "2026",
    "11",
    "16"
  ],
  "id": 161,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 318,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Sources",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 162

| [Treasury Model 1A agreement, November 2014](https://home.treasury.gov/system/files/131/FATCA-Reciprocal-Model-1A-Agreement-Preexisting-TIEA-or-DTC-11-30-14.pdf) | Read for Article 1(g)–(l) and (ff) definitions; full Article 2 partner and US reporting. Model text only, not proof of actual national IGA/AnnexII. | 2026-11-16 |

```json
{
  "figures": [
    "2014",
    "1",
    "2",
    "2026",
    "11",
    "16"
  ],
  "id": 162,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 319,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Sources",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 163

| [Treasury Model 1 Annex I](https://home.treasury.gov/system/files/131/FATCA-Annex-I-to-Model-1-Agreement-11-30-14.pdf) | Read for Section II.A individual exclusions; Section IV entity thresholds; Section VI.A/B Active NFFE categories and Determination Date. Model threshold/election conditions, not uniform domestic elections. | 2026-11-16 |

```json
{
  "figures": [
    "1",
    "2026",
    "11",
    "16"
  ],
  "id": 163,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 320,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Sources",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 164

| [IRS Publication 515 (2026)](https://www.irs.gov/publications/p515) | Read for Form list; chapter 4 withholding requirements; documentation and reason-to-know rules; FI/NFFE/IGA definitions. Actual selected complete paragraphs and neighbors read; no blanket full-publication read. | 2026-11-16 |

```json
{
  "figures": [
    "515",
    "2026",
    "4",
    "2026",
    "11",
    "16"
  ],
  "id": 164,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 321,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Sources",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 165

| [IRS Form 8966 instructions](https://www.irs.gov/instructions/i8966) | Read for General instructions, purpose, who must file, filing date, extensions and electronic filing. Current official instructions read; no taxpayer account or live filing. | 2026-11-16 |

```json
{
  "figures": [
    "8966",
    "2026",
    "11",
    "16"
  ],
  "id": 165,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 322,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Sources",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 166

| [IRS Form 1042-S instructions (2026)](https://www.irs.gov/instructions/i1042s) | Read for Reliance on proposed regulations and FATCA reporting reminders. Current instructions corroborate permitted proposal reliance, not final enactment. | 2026-11-16 |

```json
{
  "figures": [
    "1042",
    "2026",
    "2026",
    "11",
    "16"
  ],
  "id": 166,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 323,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Sources",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 167

| [IRS GIIN composition](https://www.irs.gov/businesses/corporations/fatca-registration-and-ffi-list-giin-composition-information) | Read for Introductory 19-character rule and complete category/country position table. Official page reviewed5December2025; actual full used composition fields read. | 2026-11-16 |

```json
{
  "figures": [
    "19",
    "025",
    "2026",
    "11",
    "16"
  ],
  "id": 167,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 324,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Sources",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 168

| [Official CFR 2025, section 1.1473-1](https://www.govinfo.gov/content/pkg/CFR-2025-title26-vol14/pdf/CFR-2025-title26-vol14-sec1-1473-1.pdf) | Read for Section 1.1473-1(a)(1) and (c), read with Model 1 Article 1(ff). Historical annual edition, not falsely labelled live2026eCFR. LiveeCFRchallenge not read. | 2026-11-16 |

```json
{
  "figures": [
    "2025",
    "1.1473",
    "1",
    "1.1473",
    "1",
    "1",
    "1",
    "1",
    "2026",
    "11",
    "16"
  ],
  "id": 168,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 325,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Sources",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 169

| [Published FATCA proposal, REG-132881-17](https://www.govinfo.gov/content/pkg/FR-2018-12-18/pdf/2018-27290.pdf) | Read for 83 FR 64757: preamble I, II, Reliance on Proposed Regulations and relevant proposed changes. PROPOSED2018rules and permitted reliance explicitly separated from enacted rules. | 2026-11-16 |

```json
{
  "figures": [
    "132881",
    "17",
    "83",
    "64757",
    "2026",
    "11",
    "16"
  ],
  "id": 169,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 326,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Sources",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 170

| [HMRC, AEOI financial institutions](https://www.gov.uk/guidance/automatic-exchange-of-information-financial-institutions) | Read for Main guidance: 2026 scope, reporting entity responsibility, group reports and nil returns. Actual main body read; no universal nil exemption. | 2026-11-16 |

```json
{
  "figures": [
    "2026",
    "2026",
    "11",
    "16"
  ],
  "id": 170,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 327,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Sources",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 171

| [HMRC, how to report AEOI](https://www.gov.uk/guidance/how-to-report-automatic-exchange-of-information) | Read for Annual 31 May deadline and separate CRS/FATCA schemas from 2027. Actual main body read, technically optional fields not legal optionality. | 2026-11-16 |

```json
{
  "figures": [
    "31",
    "2027",
    "2026",
    "11",
    "16"
  ],
  "id": 171,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 328,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Sources",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 172

| [UK SI 2025/740](https://www.legislation.gov.uk/uksi/2025/740/made/data.html) | Read for Regulations 1, 3, 6, 9 and 11–14; substituted regulations 22A–22N, including all penalty conditions and commencement. Actual whole used operative amendment1–248 read. Current law controls superseded2025factsheet. | 2026-11-16 |

```json
{
  "figures": [
    "2025",
    "740",
    "1",
    "3",
    "6",
    "9",
    "11",
    "14",
    "248",
    "2026",
    "11",
    "16"
  ],
  "id": 172,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 329,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Sources",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 173

| [Germany, FKAustG](https://www.gesetze-im-internet.de/fkaustg/BJNR253110015.html) | Read for Sections 27(1)–(3) and 28(1)–(3), including all offence branches and their application dates. Current official consolidated German text, complete used sections and neighbors read. | 2026-11-16 |

```json
{
  "figures": [
    "27",
    "1",
    "3",
    "28",
    "1",
    "3",
    "2026",
    "11",
    "16"
  ],
  "id": 173,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 330,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Sources",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 174

| [France, BOI-INT-AEA-20-40](https://bofip.impots.gouv.fr/bofip/10340-PGP.html/identifiant=BOI-INT-AEA-20-40-20200226) | Read for Version 26 February 2020, III.A/B paragraphs 330–355: CRS and separate L.102 AG declarations. Version date disclosed; current-source recency boundary retained, not entire French regime clearance. | 2026-11-16 |

```json
{
  "figures": [
    "20",
    "40",
    "26",
    "2020",
    "330",
    "355",
    "102",
    "2026",
    "11",
    "16"
  ],
  "id": 174,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 331,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Sources",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 175

| [France, FATCA specifications v5.3](https://www.impots.gouv.fr/sites/default/files/media/1_metier/3_partenaire/tiers_declarants/cdc_td_bilateral/cahier-des-charges-fatca-v5.3.pdf) | Read for Cover, version history and printed page 10 calendar for 2026 deposits concerning 2025 income. Only2026campaign for2025income; not2027date. | 2026-11-16 |

```json
{
  "figures": [
    "3",
    "10",
    "2026",
    "2025",
    "2026",
    "11",
    "16"
  ],
  "id": 175,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 332,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Sources",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 176

| [IRAS, CRS filing](https://www.iras.gov.sg/taxes/international-tax/common-reporting-standard-%28crs%29/crs-filing) | Read for Annual and nil returns, 31 May deadline, late/non-filing penalty, extension exceptions, portal and XML change. Ordinary direct fetch403; actual successful official web body personally read, not eTaxPDF clearance. | 2026-11-16 |

```json
{
  "figures": [
    "31",
    "03",
    "2026",
    "11",
    "16"
  ],
  "id": 176,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 333,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Sources",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 177

| [IRAS, CRS overview and latest developments](https://www.iras.gov.sg/taxes/international-tax/common-reporting-standard-%28crs%29/crs-overview-and-latest-developments) | Read for 2026 amendment publication, substantive commencement on 1 January 2027 and XML version transition. Actual IRAS web body, eTaxPDF403 not read. | 2026-11-16 |

```json
{
  "figures": [
    "2026",
    "1",
    "2027",
    "03",
    "2026",
    "11",
    "16"
  ],
  "id": 177,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 334,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Sources",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 178

| [OECD, consolidated CRS (2025)](https://www.oecd.org/content/dam/oecd/en/publications/reports/2025/04/consolidated-text-of-the-common-reporting-standard-2025_e478bc04/055664b1-en.pdf) | Read for Section VIII.D/E definitions and full Active categories; Commentary on Section I paragraph 13 joint reporting; selected FI and aggregation clauses. 2025CCBY4standard, not domesticlaw. Actual selected clauses only, not whole128pages. | 2026-11-16 |

```json
{
  "figures": [
    "2025",
    "13",
    "2026",
    "11",
    "16"
  ],
  "id": 178,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 335,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Sources",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 179

| [OECD, CARF commitments, September 2026](https://www.oecd.org/content/dam/oecd/en/networks/global-forum-tax-transparency/commitments-carf.pdf) | Read for Whole one-page list updated 14 September 2026, with first-exchange groups for 2027, 2028 and 2029. Dated political commitments, not proof of national enactment. | 2026-11-16 |

```json
{
  "figures": [
    "2026",
    "14",
    "2026",
    "2027",
    "2028",
    "2029",
    "2026",
    "11",
    "16"
  ],
  "id": 179,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 336,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Sources",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 180

| [CJEU press release 190/23](https://curia.europa.eu/site/upload/docs/application/pdf/2023-12/cp230190en.pdf) | Read for Headline and opening paragraphs identifying C-457/21 P, Commission v Amazon.com and Others. Only caseidentity correction; no FATCA/GDPR judgment clearance. | 2026-11-16 |

```json
{
  "figures": [
    "190",
    "23",
    "457",
    "21",
    "2026",
    "11",
    "16"
  ],
  "id": 180,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 337,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Sources",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 181

| [Treasury, FATCA agreements and model list](https://home.treasury.gov/policy-issues/tax-policy/foreign-account-tax-compliance-act) | Read for FATCA introduction and reciprocal Model 1A, non-reciprocal Model 1B and Model 2 listings. Official model type list read, no jurisdiction-count verification. | 2026-11-16 |

```json
{
  "figures": [
    "2",
    "2026",
    "11",
    "16"
  ],
  "id": 181,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 338,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Sources",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

### 182

Not yet confirmed: actual signed country IGA/Annex II and local elections for a particular institution; live Reportable/Participating Jurisdiction lists and actual activated exchange relationships; current aggregate FATCA/CRS jurisdiction counts; exact registration, certified-deemed-compliant or exempt retirement-fund conditions and responsible-officer certification timetable for the engagement; the former Netherlands mandatory-all-account claim; current Australian filing date/concessions and former AUD 12,500 penalty base; current Swiss FATCA/AEOIA offence-specific sanctions and former CHF 50,000 general figure; current US offence/year-specific penalty amounts replacing the old USD 250 / USD 3,000,000 shorthand; Singapore's former blanket 12-month imprisonment claim; formal national DAC8 transposition/provider filing dates and non-EU CARF domestic commencement; transaction-specific gross-proceeds reliance/foreign-passthru duties and any later final guidance; operative FATCA privacy/GDPR restrictions and judgments. These are non-usable holds, not alternative rates or permissions. The old universal 90-day cure, nine Active categories, 24-month liquidation rule, proportional joint balances, all-foreign-account US Form 8966 claim, blanket strict liability, Amazon-case privacy clearance and universal 2026 amendment commencement have been corrected, not retained as usable alternatives.

```json
{
  "figures": [
    "12,500",
    "50,000",
    "250",
    "3,000,000",
    "12",
    "90",
    "24",
    "8966",
    "2026"
  ],
  "id": 182,
  "kind": "heading/internal workflow/example input or explicit unusable reservation",
  "line": 340,
  "operative_bindings": [],
  "result_boundary": "All stated conditions apply; models not domesticlaw; explicit Sources holds not usable.",
  "section": "Sources",
  "short_native_quote_ids": [],
  "source_keys": []
}
```

## Short exact native registry

```json
{
  "ANNEX004": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "does not exceed $250,000"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "II/IV distinct preexisting account thresholds",
    "source_key": "ANNEX"
  },
  "CARFCOMMIT002": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "Last update: 14 September 2026"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Cover/date; whole dated list",
    "source_key": "CARFCOMMIT"
  },
  "CASE018": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "Commission v Amazon.com and Others"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "OfficialCourtpress headline; no privacy ruling",
    "source_key": "CASE"
  },
  "CFR009": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "Specified U.S. person."
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Section1.1473-1(c); see also Model1Article1(ff)all13exclusions",
    "source_key": "CFR"
  },
  "CFR034": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "Any organization exempt from"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Section1.1473-1(c)(1)–(13),fullspecifiedUSpersonexclusionlist",
    "source_key": "CFR"
  },
  "CFR037": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "any gross proceeds from the sale or"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Section1.1473-1(a)(1)(ii),2025annualedition;proposalrelianceseparate",
    "source_key": "CFR"
  },
  "CRS001": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "which is identified in a published list"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "VIII.D(4) and (5)",
    "source_key": "CRS"
  },
  "CRS020": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "Each holder of a jointly held account is attributed the entire balance or value"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Commentary on Section I paragraph13, full paragraph and neighbors read",
    "source_key": "CRS"
  },
  "DE013": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "zum 31. Juli eines Jahres für das vorhergehende Kalenderjahr"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Section27(2)",
    "source_key": "DE"
  },
  "DE026": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "mit einer Geldbuße bis zu fünfzigtausend Euro, in den übrigen Fällen mit einer Geldbuße bis zu"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Section28(1a) with enumeratedoffences/culpability",
    "source_key": "DE"
  },
  "EU027": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "the final day of a non-calendar year accounting period"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "AnnexI VIII.A(4),complete three-year/shorterexistencealternative",
    "source_key": "EU"
  },
  "EU028": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "other than in a fiduciary capacity"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "AnnexI VII.C(3),specialaggregationforHighValueAccounts",
    "source_key": "EU"
  },
  "EU029": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "are reported by the Reporting Financial Institution"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "AnnexI I.F,fullArticle8adduplicateproceedsexception/election",
    "source_key": "EU"
  },
  "EU030": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "not longer than"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "AnnexI IXfinalparagraph,FIrecordsnotcrypto-providerretentionclock",
    "source_key": "EU"
  },
  "EU044": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV; captured text line1875",
    "source_key": "EU"
  },
  "EU045": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV; captured text line1884",
    "source_key": "EU"
  },
  "EU047": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV; captured text line1468",
    "source_key": "EU"
  },
  "EU048": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV; captured text line1488",
    "source_key": "EU"
  },
  "EU049": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV; captured text line1806",
    "source_key": "EU"
  },
  "EU050": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV; captured text line1814",
    "source_key": "EU"
  },
  "EU051": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV; captured text line1816",
    "source_key": "EU"
  },
  "EU052": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV; captured text line1683",
    "source_key": "EU"
  },
  "EU053": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV; captured text line1450",
    "source_key": "EU"
  },
  "EU054": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV; captured text line1681",
    "source_key": "EU"
  },
  "EU055": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV; captured text line2657",
    "source_key": "EU"
  },
  "EU056": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV; captured text line1444",
    "source_key": "EU"
  },
  "EU057": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV; captured text line1770",
    "source_key": "EU"
  },
  "EU058": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV; captured text line1796",
    "source_key": "EU"
  },
  "EU059": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV; captured text line1808",
    "source_key": "EU"
  },
  "EU060": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV; captured text line1810",
    "source_key": "EU"
  },
  "EU061": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV; captured text line1812",
    "source_key": "EU"
  },
  "EU062": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV; captured text line1818",
    "source_key": "EU"
  },
  "EU063": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV; captured text line1830",
    "source_key": "EU"
  },
  "EU064": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV; captured text line1822",
    "source_key": "EU"
  },
  "EU065": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV; captured text line1833",
    "source_key": "EU"
  },
  "EU066": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV; captured text line1616",
    "source_key": "EU"
  },
  "EU067": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV; captured text line1546",
    "source_key": "EU"
  },
  "EU068": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV; captured text line1365",
    "source_key": "EU"
  },
  "EU069": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV; captured text line1414",
    "source_key": "EU"
  },
  "EU070": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV; captured text line1890",
    "source_key": "EU"
  },
  "EU071": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV; captured text line1672",
    "source_key": "EU"
  },
  "EU072": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV; captured text line1294",
    "source_key": "EU"
  },
  "EU073": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV; captured text line1340",
    "source_key": "EU"
  },
  "EU074": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV; captured text line1374",
    "source_key": "EU"
  },
  "EU075": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV; captured text line1454",
    "source_key": "EU"
  },
  "EU076": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV; captured text line1440",
    "source_key": "EU"
  },
  "EU077": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV; captured text line1212",
    "source_key": "EU"
  },
  "EU078": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV; captured text line1221",
    "source_key": "EU"
  },
  "EU079": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV; captured text line1253",
    "source_key": "EU"
  },
  "EU080": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV; captured text line1230",
    "source_key": "EU"
  },
  "EU081": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV; captured text line1236",
    "source_key": "EU"
  },
  "EU082": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV; captured text line1788",
    "source_key": "EU"
  },
  "EU083": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV; captured text line1798",
    "source_key": "EU"
  },
  "EU092": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV; captured text line1871",
    "source_key": "EU"
  },
  "EU093": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Articles 8(3a), 8(6) and 8ad; used operative clauses and exceptions in Annex I Sections I–XI, Annex II paragraphs 1–6 and Annex VI Sections I–IV; captured text line1852",
    "source_key": "EU"
  },
  "FRCRS014": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "au plus tard le 31 juillet de chaque année pour les revenus de l'année civile précédente"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Paragraph350",
    "source_key": "FRCRS"
  },
  "FRFATCA015": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "15 juillet 2026"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Printed10 calendar2026",
    "source_key": "FRFATCA"
  },
  "GIIN008": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "19-character identification number"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "GIINcomposition introductory paragraph and completefieldtable",
    "source_key": "GIIN"
  },
  "I1042007": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "taxpayers may generally rely on the proposed regulations until final regulations are issued"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Relianceonproposedregulations",
    "source_key": "I1042"
  },
  "I8966006": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "March 31"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "WhenToFile and filer-specific exceptions",
    "source_key": "I8966"
  },
  "I8966021": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "Reporting Model 1 FFIs do not file Form 8966 directly to the IRS."
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "General instructions model reporting distinction",
    "source_key": "I8966"
  },
  "I8966043": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "penalties under sections 6721 through 6724 may apply"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Electronicfilingrequirement,actual424,requiredfilingfailureandnoapprovedwaiver",
    "source_key": "I8966"
  },
  "IGA003": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "the account balance or value"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Article2(a)(4), with Article1 and fullArticle2 conditions",
    "source_key": "IGA"
  },
  "IGA031": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "Custodial Institution, a Depository Institution"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Article1(g),completeFIdefinition",
    "source_key": "IGA"
  },
  "IRS515005": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "withhold 30%"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Chapter4withholding requirements, exceptions and documentation",
    "source_key": "IRS515"
  },
  "IRS515032": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "holding company or treasury center"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "FIdefinition,actualtext2787",
    "source_key": "IRS515"
  },
  "IRS515033": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "Certificate of Foreign Intermediary"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Formslist777–784,withW8BEN/BENE/ECI/EXPandW9distinctpurposes",
    "source_key": "IRS515"
  },
  "IRS515035": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "agreed to comply"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "ParticipatingFFIdefinition2799andcompleteadjacentFFIdefinitions",
    "source_key": "IRS515"
  },
  "IRS515036": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "U.S. source fixed or determinable annual or periodical"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Chapter4withholdablepayment828,readwithfullFDAPincomeandsourcerules",
    "source_key": "IRS515"
  },
  "PROPOSAL010": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "taxpayers may rely on the proposed regulations until final regulations are issued"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "RelianceonProposedRegulations plus I/II",
    "source_key": "PROPOSAL"
  },
  "SGFILE016": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "31 May"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "CRSfiling deadline and body923–992",
    "source_key": "SGFILE"
  },
  "SGFILE024": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "a penalty of up to $5,000"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "CRSlate/nonfiling enforcement, distinctfromunverifiedimprisonment",
    "source_key": "SGFILE"
  },
  "SGFILE025": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "1 January 2027"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "XML3.0start",
    "source_key": "SGFILE"
  },
  "SGOV017": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "will take effect from 1 January 2027"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "IRAS2026amendedCRSannouncement",
    "source_key": "SGOV"
  },
  "TREASURY019": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "Nonreciprocal Model 1B Agreement"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Official model list490–509",
    "source_key": "TREASURY"
  },
  "UKFI011": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "1 January 2026"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "AmendedFI scope and entity/nil duties",
    "source_key": "UKFI"
  },
  "UKFI038": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "responsible for submitting a yearly return"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Entitylevelreporting86–88,eachentitydutyandgroupmemberfiling",
    "source_key": "UKFI"
  },
  "UKLAW039": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "come into force on 16th July 2025"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Regulation1(1),withcomplete1(2)calendar2025andpriorapplicationexception",
    "source_key": "UKLAW"
  },
  "UKLAW040": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "calendar year 2025 and previous calendar years"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Regulation1(2),specifiedprovisionswithdeferredeffect",
    "source_key": "UKLAW"
  },
  "UKLAW041": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "£300 for each subsequent day on which the failure occurs"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Inserted22F(b),with22F(a)£1000andassessmentnotificationgate",
    "source_key": "UKLAW"
  },
  "UKLAW042": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "£600"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Inserted22G(b),with22G(a)£5000andassessmentnotificationgate",
    "source_key": "UKLAW"
  },
  "UKLAW046": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Regulations 1, 3, 6, 9 and 11–14; substituted regulations 22A–22N, including all penalty conditions and commencement; captured text line156",
    "source_key": "UKLAW"
  },
  "UKLAW084": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Regulations 1, 3, 6, 9 and 11–14; substituted regulations 22A–22N, including all penalty conditions and commencement; captured text line167",
    "source_key": "UKLAW"
  },
  "UKLAW085": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Regulations 1, 3, 6, 9 and 11–14; substituted regulations 22A–22N, including all penalty conditions and commencement; captured text line108",
    "source_key": "UKLAW"
  },
  "UKLAW086": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Regulations 1, 3, 6, 9 and 11–14; substituted regulations 22A–22N, including all penalty conditions and commencement; captured text line110",
    "source_key": "UKLAW"
  },
  "UKLAW087": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Regulations 1, 3, 6, 9 and 11–14; substituted regulations 22A–22N, including all penalty conditions and commencement; captured text line113",
    "source_key": "UKLAW"
  },
  "UKLAW088": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Regulations 1, 3, 6, 9 and 11–14; substituted regulations 22A–22N, including all penalty conditions and commencement; captured text line121",
    "source_key": "UKLAW"
  },
  "UKLAW089": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Regulations 1, 3, 6, 9 and 11–14; substituted regulations 22A–22N, including all penalty conditions and commencement; captured text line123",
    "source_key": "UKLAW"
  },
  "UKLAW090": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Regulations 1, 3, 6, 9 and 11–14; substituted regulations 22A–22N, including all penalty conditions and commencement; captured text line135",
    "source_key": "UKLAW"
  },
  "UKLAW091": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Regulations 1, 3, 6, 9 and 11–14; substituted regulations 22A–22N, including all penalty conditions and commencement; captured text line149",
    "source_key": "UKLAW"
  },
  "UKREPORT012": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "31 May"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Annualreporting and separate2027schema requirements",
    "source_key": "UKREPORT"
  },
  "UKREPORT022": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "1 January 2027"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "SeparateCRSandFATCAschema2027",
    "source_key": "UKREPORT"
  },
  "UKREPORT023": {
    "actual_read_date": "2026-11-16",
    "literal_match": true,
    "native_quote": [
      "31 December 2026"
    ],
    "native_quote_public_projection_note": "Selected short extract only, within the bundle source budget; canonical full evidence is retained locally under its SHA256. Omitted quotations are not missing source reads.",
    "operative_locator": "Endofcombinedschema",
    "source_key": "UKREPORT"
  }
}
```

## Original-topic destinations

The complete original-topic destination table is in `../fatca-crs-automatic-exchange/old-topic-map.json`.
