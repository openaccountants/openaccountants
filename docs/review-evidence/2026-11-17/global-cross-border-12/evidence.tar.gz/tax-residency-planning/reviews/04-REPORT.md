# Residence short-extract standard audit

16 November 2026. Standards read at main `bbab4f1a6d82cace432e6ca8eda89c98ffb1c038`. This is a separate audit; the complete prior independent source review and its historical final report remain unchanged.

**The 22 disclosed partial-extract rows meet the current short-extract requirement for their explicitly bounded claims. The earlier hold based solely on not reproducing complete operative paragraphs is removed.** No source, condition, no-loss or arithmetic review is waived. This does not grant accountant approval, publication approval or an untested fresh-head CI verdict.

## The actual requirement

- Current `docs/skill-template.md:74–80` requires actual official-page reading, exact source wording with link/read date, and neighboring exceptions and definitions. It does not require transcription of complete paragraphs.
- `docs/skill-template.md:86–89` permits the law register or authority's own page and requires honest actual read scopes. Lines 100–105 require conditions next to figures. Lines 114–121 require complete old-topic preservation. Lines 213–218 require full independent source/figure/example coverage, not sampling.
- `NEW-CHAT-COMMON-BRIEF.md:15` expressly requires a “short native quote”, an article/section, official URL and actual read date for every figure/rule. Lines 13 and 18 require actual operative paragraphs and neighbors to be read, and completed applicable review to be reused. Reading an entire condition is distinct from copying that entire condition into evidence.
- The coordinator's subsequent explicit instruction confirms the short-extract standard and proportionate reuse. There is no basis for imposing an extra full-paragraph quotation gate. Copyright limits are not bypassed by splitting protected paragraphs into many short fragments.

The relevant current standard files and brief are frozen beside this audit. `audit.json` records their hashes, all 22 row-by-row assessments and their source/locator/read-date bindings. The complete current-main residence original is still `c4387b76308afb59317109a411dfebd946f61c37759227f12d0bc9f502bedea2`, identical to the original used for the completed independent no-loss review.

## What was checked

The exact reviewed Guide remains `0efc4533c915175a5d5f0407773779e19edcb970eebc154ed4a3c1bbf0064daf`; ledger `6a18a2c0b32d94d588b810b599fb588d1b24cc7962e9d20673b1c11e46a31c27`; source register `10e075cb55350d834eb8407d183fe0c1086052a413b2c0bf24c545fe191ec99e`; old map `b96dd7cc1c8f3285ee91dd5dd5b84dc359d6db53778be4a25ab64126dc2b01ac`.

All 22 rows across 17 sources have actual short exact source-language extracts, claim-specific operative locators, official URLs and read dates. They do not claim reconstruction of whole paragraphs. Thirteen include explicit complete condition-paraphrase fields addressing longer or previously missing conditions; the remaining nine are narrower propositions supported by the personally read source scopes and their ledger claims. All were already covered by the completed full independent source review and correction review. Their operative sources were actually read; this audit does not substitute a hash, an extract or an author log for that reading.

The rows cover MM2H nature/work; the dated/current Cayman tax statements; dated Bahamas PIT and economic residence; Monaco PIT/resources; Portugal permit duration; four Singapore residence/concession/review rules; Estonia residence alternatives/form and visa duration; Croatia funds; Thailand permission duration; OECD remote-work Commentary; Malaysian foreign-income conditions; dated Costa Rican source activity; and the bounded UAE ordinary corporate-tax threshold explanation. Each row's precise assessment is in `audit.json`.

The two final public-law native defects previously identified in Thai article selection and manual Arabic wording were separately corrected and independently verified against actual pages before this standards audit. That substantive correction work remains necessary and valid. Their closure is not based on changing the quotation standard.

## Real limits that remain

The UAE CD116 row quotes the actual English text published by the FTA. That source expressly labels itself an unofficial translation. It is an exact extract in the language of the cited authority-hosted source, not a reviewer-created translation, and the Guide explicitly disclaims native Arabic verification and complete current company-tax execution. This audit does not turn that evidence into verified Arabic law. The bounded source-description is supported; the broader execution conclusion remains withheld.

Likewise, the dated Costa Rican presentation is not a recovered current statutory consolidation; OECD Commentary is not an operative bilateral treaty; the Malaysian dated guidance/original-order recovery limits remain explicit. Every other source/version/reservation boundary in the completed review is preserved. Short quotations alone could not cure a missing actual source read or dropped condition, and this audit grants no such exception.

Only quotation-standard applicability has changed. Reuse the completed source/no-loss/arithmetic review once when importing the exact candidate. Independently review actual changed claims or dependencies if any arise. Run the required current-head validation gates without repeating the whole source review merely because the checkout, wrapper or branch changed. The historical checks include three protected-original-footer dash warnings and the documented row-helper retrieval failures; this audit does not silently change those outputs or waive a required CI gate. Preserve raw/full protected sources locally and disclose only lawful short extracts and the reviewer's own paraphrases in public evidence.
