# Complete first independent holding-company review: HOLD for 12 finite groups

Frozen Guide SHA256 `0fe549c9c029f5c840688a593c697223ec7a191b686f9f31f4f239c398984169` at checkpoint `b6649f7ec3402cf0de2f88176eb6f0bd73486587`. Original `a6735b97c88154c705df36af1fe617323f0e6c30786ea57e27c7974065d93614` matches main.

The first review is complete: all71 rule groups,151 short native fragments,44 actual source identities/scopes,460 current Guide lines and282 original entries (265 body/17 headings) were assessed. Four complete scoped source-only readings were reused after exact artifact/image hash checks, as were unchanged completed Cyprus personal/non-dom and CD116 research. The other operative scopes and their material neighbors were personally read. This does not claim another whole-source read of reused laws. Actual read boundaries and truncation recovery are recorded in independent-own-source-read-scopes.json.

All worked cases, retained inputs and numeric boundaries were independently recomputed or assessed. The nine-country original universal-nil conclusion correctly became a conditional outcome inventory. Malta5/7 and6/7 arithmetic, Dutch band tax/withholding and4.99%/5% decision, Cyprus5% example and Luxembourg City23.87% recompute correctly. The two Malta cases need the remaining eligibility assumptions below. Six uncomputed country failure cases remain expressly uncomputed. See independent-all-arithmetic.json. The separate150-line inventory includes all numeric-bearing body lines outside example code, including repeated figures and article identifiers; it is not a count of unique statutory rates.

The finite correction batch is COMPLETE-FIRST-FINDINGS.json:

1. HOLD-SHAPE-001: keep the seven reservations within Sources by changing the following H2 to a bold/ordinary line. CLAUDE39 and template223 require this.
2. HOLD-CASE-001: make both Malta refund examples conditional on the remaining eligibility/compliance/actual-paid gates and the unresolved resident-individual bar; preserve every case input and result. Actual Cap37248(1)/(1A)/(1B)/(4A) supports this.
3. HOLD-IE-001: separate the foreign distribution-date test from the lookback test, which permits Irish residence as an alternative. Actual TDM35-02-11 Sections3.1/3.3, retained41.txt439–444/707–760.
4. HOLD-LU-001: an EU investee must qualify under Directive2011/96/EU Article2; EU location alone is insufficient. LIR166(2)(1), retained20.txt11242–11250.
5. HOLD-LU-002: the future holding commitment for outbound relief carries149(4) guarantee/procedure conditions. The actual adjacent149(4)/(4a),20.txt8151–8166, must be read and reflected; underlying regulation/form execution stays unconfirmed unless established.
6. HOLD-SG-001: restore the passive-or-no-income qualifier to the property-holding exclusion. Actual IRAS section13W Guide6.4.3(b),03.txt426–428; the private ledger already retains it.
7. HOLD-AE-001: restore the not-more-than50% operator and the definition of nonqualifying ownership-interest assets, alongside the current related-party limitation and time/valuation conditions. Actual FDL23(2)(d), MD3029–10.
8. HOLD-NOLOSS-001: retain Luxembourg's EUR200,000 cutoff beside the16% top-band figure. Original146; actual LIR174 and authority tariff agree.
9. HOLD-NOLOSS-002: retain the UK GBP50,000/250,000 ordinary rate limits, with the existing short-period/associated-company/CIHC qualifications. Original265/266; actual rate guidance125–127 and Marginal Relief83–92.
10. HOLD-NATIVE-001: replace/supplement the two UAE heading-only quotations with short exact operative anchors and subarticle/page locators. Both headings are literal; the issue is their failure to anchor the assigned rule. No full paragraph reproduction is requested.
11. HOLD-BIND-001: remove four cross-country ledger bindings and move the Malta exemption outcome from its unrelated rate group to the appropriate exemption group. Exact rows/lines are in the JSON.
12. HOLD-MAP-001: seven finite destination corrections, preserving the individual unusable family-size proposition, binding restored UK limits and removing wrong-country/wrong-case anchors. Exact original-line destinations are in the JSON. All other original topics were assessed against the actual rewritten body.

All44 source hashes and current row/map text bindings mechanically match. The four native fragments that do not match corrupted Arabic extraction were checked visually against actual retained pages:66pp7/8,72pp23/42. The remaining fragments literally match their declared source text; the longest short fragment has11 whitespace-delimited words. The two heading-only anchors remain a relevance finding, not a demand for longer protected quotation. Exact native-law source-only reading provenance is retained.

Required local-check artifacts were assessed faithfully:19 standard checks, two example blocks, sync, calculator quotes, copy and diff passed within their recorded scope; validation's only warnings concern unchanged protected residence footer dashes. The raw source helper returned70 rows,14 MISS and zero UNREADABLE. Each MISS is an explicitly supplied hypothetical input or independently recomputed result, rather than an unverified legal rate; its actual underlying rate/condition was separately checked. The raw helper is not described as green. Publisher index/cohort/full CI remain separate.

Identity, description, jurisdiction, licence, tier and domain are preserved; date advances and version/type are declared. There is no accountant approval or client-specific execution clearance. Existing source/version/translation and national implementation limits remain explicit. No Guide, author source, code or publication was modified by this reviewer.

After one writer correction batch, review the changed claims/dependencies and actual bindings only; reuse this completed source/no-loss/arithmetic review once. Do not repeat a whole-source scan or suite solely for a new hash. Review date:16November2026.
