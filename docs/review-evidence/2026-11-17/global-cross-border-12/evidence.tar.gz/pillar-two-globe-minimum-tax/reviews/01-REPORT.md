# Pillar Two independent legal/source review

**HOLD at `513fb568c4996f587eab80b3b566fcf36740b377`.** The first complete legal/source review is finished. Two narrow operative instructions require correction. This is an independent technical source review, not an accountant approval or a country-wide filing clearance.

Candidate: `skills/global/cross-border/pillar-two-globe-minimum-tax.md`, SHA256 `ccd79f1f21ea11479a416d0c3e8cf6cb794879d592d5064b09b26406bc25a166`, 102,517 bytes. The candidate and all older writer records remain unchanged.

## Findings

| Finding | Guide | Required correction |
| --- | --- | --- |
| P2-LEGAL-F01 | Line 197, R0117 | Include all QDMTT periods that begin **or** end in the UPE fiscal year. Add the defined UPE-2024 exception in Annex A3 paragraph 21.3 and preserve paragraph 21.5 switch-off priority and ordinary credit fallback. |
| P2-LEGAL-F02 | Line 195, R0116 | Once a non-severable tax meets the explicitly conditional classification, exclusion of the whole tax is mandatory, subject to the existing historical exception. Replace the permissive branch and keep the precise classification and severability gates. |

Both findings follow the actual [September 2026 OECD guidance](https://www.oecd.org/content/dam/oecd/en/topics/policy-sub-issues/global-minimum-tax/administrative-guidance-on-the-global-anti-base-erosion-model-rules-pillar-two-september-2026.pdf). Complete native clauses and neighbors were read in the retained capture: LF414–473 for 21.1–21.6, and LF192–230 for 23.1–23.6. Capture SHA256 `015b351f392bae96f1f0eb003e5307a9477191f376430e63db2f9189f36967a9`. Neither correction changes the supplied DE/IE example assumptions or SBIE rates.

The separate preservation/arithmetic reviewer also reported retired approval wording at line 317 (C01). That issue is not counted as a tax/source finding here.

## Scope actually completed

The whole Guide and all **216 parent groups / 653 subclaims** were considered in their complete parent context. All **25 official source records**, **133 operative read blocks**, **372 source-binding occurrences**, **685 short anchors** plus the separate German title/date header were bound to actual retained bodies. The full base Model operative Chapters 1–10, EU Articles 1–59, complete relevant 2026 safe-harbour contexts, September amendments, reporting-version provisions and the **19 national matrix rows** were reviewed. All **10 embedded EU formula images** were actually viewed, as were the two Central Record layout pages. Read ranges and specific limitations are in `SOURCE-READ-SCOPES.json`; this is not a claim that the entire Commentary, every GIR data point or every national law was reread.

The authentic EU published body was independently compared with the consolidation. Articles 30/49 differ only in whitespace layout; Article 3 has footnote formatting/numbering, and Article 59 includes signature/preamble-footnote material. No operative formula, threshold or condition difference was identified. The ten formulas support the Guide's ordinary-pool relationships and the separate allocation/recapture rules.

The actual legal dependencies supporting India's arithmetic component were confirmed: Model SBIE schedule, EU 31-December wording caveat, jurisdiction-specific Transition Year and 15/18-month GIR rule, and the supplied ordinary positive-income/no-safe-harbour/no-additional-tax/no-QDMTT example assumptions. No arithmetic rerun or duplicate old-topic audit was performed.

All 168 payloads in the frozen writer manifest matched. All 25 raw/capture hashes matched. One narrow automated anchor-window warning was independently resolved: the five-state list starts at LF37 and spans LF37–45, beyond the diagnostic six-line window; its complete actual list is correct. These are integrity controls, not substitutes for reading the legal conditions.

## Boundaries preserved

The Central Record is explicitly **as at 1 May 2026**. It proves the stated transitional qualified-status dates, not all current domestic returns, payments or entity-specific safe-harbour eligibility. National overviews retain their express limited scope. Australian direct-body access and Singapore statutory access failures remain genuine source holds; China/India historical non-adoption research leads are not converted into current absence claims. US NCTI/CAMT/FTC and detailed national interaction holds remain. Selected national official bodies support only the claims actually made and do not create full-country clearance.

The Model remains a common approach, the Directive an EU implementation, and later guidance must be tested against applicable domestic law. The source publications and retained retrieval/read dates are preserved honestly. Raw source bodies, images and transport metadata remain local. Public sharing should use this own report/outcomes/hash metadata, not indiscriminately publish the native corpus.

## Separate component and next action

India's preservation/arithmetic PASS is at `/Users/michaelcutajar/Documents/ChatGPT/OA/outputs/world-resume-2026-11-16/review-global-pillar-two-preservation-arithmetic/REPORT.md` (SHA256 `604e91f4a0c84d53a6f6ae26ee7e889a6746ac9b2e09ac5a97ddc5fd1e1dec08`). It covers 212 original mappings, 430 atoms, the two original cases/eight outputs, eleven SBIE rows and seven date controls. That proof is reusable for unchanged bytes; this report does not claim to duplicate it.

The writer should fix the two affected instructions plus the separately reported copy issue, freeze an exact delta and obtain a proportionate changed-claim review. No new full source sweep, full suite, source packaging or case reconstruction is required merely because unchanged content remains in the file. No candidate edits, commits, push, PR, merge or release were performed by this reviewer.
