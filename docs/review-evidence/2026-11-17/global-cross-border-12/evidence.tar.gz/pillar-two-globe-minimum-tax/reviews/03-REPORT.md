# Pillar Two: independent preservation and arithmetic component

Preservation and arithmetic PASS at `513fb568c4996f587eab80b3b566fcf36740b377`, subject to consolidation with the separate legal/source component. One copy-only finding remains for the coordinator; this is not an overall publication approval.

Guide: `skills/global/cross-border/pillar-two-globe-minimum-tax.md`. Candidate SHA256 `ccd79f1f21ea11479a416d0c3e8cf6cb794879d592d5064b09b26406bc25a166`, 102,517 bytes. Original SHA256 `31dfe1a0504af4f01902ac92b350e46c7fd1748af1b4a2b8c10815427d91ebe9`, identical to the file at the bound main checkpoint `bbab4f1a6d82cace432e6ca8eda89c98ffb1c038`. The frozen worktree was clean; saved and committed candidate bytes match.

This is the preservation/arithmetic part of one first independent review. The separate reviewer owns the 216 legal groups, 653 legal subclaims, source provenance/currentness and ten formula-image meanings. I did not rerun that source audit or treat my component as a second full legal approval.

## Complete preservation result

I read the complete original, complete candidate and all 212 original-line destination records semantically. The byte/locator checks were then independently executed; they did not substitute for the semantic read. Every original nonblank body line is represented exactly once in the original inventory: 212 entries, 34 Markdown headings and 430 bundled atoms. Each atom occurs in its full parent context, with only whitespace/table/semicolon partition separators left over. All parent and atom destination texts, line numbers and SHA256s match the actual candidate. No fuzzy-match locator was accepted as proof.

The preservation outcomes retain all scope exclusions, the required base dependency, CE-register fields and special pools, income adjustments, covered-tax and deferred-tax topics, SBIE eligibility, ordinary de minimis, charging order, CbCR conditions, GIR workflow, edge cases and all nine reviewer deliverables. Wrong original instructions are specifically corrected or explicitly made unusable; preservation does not require their continued execution. This includes the tested-short-year annualisation shortcut, unconditional loss/high-ETR result, rounding shortcut, recapture direction, qualified-credit/safe-harbour conflation, unsupported CAMT treatment and the erroneous US rate comparison.

All 19 original implementation rows remain: Germany, France, Netherlands, Ireland, Italy, Spain, Luxembourg, Belgium, United Kingdom, Switzerland, Japan, South Korea, Canada, Australia, Singapore, Hong Kong, United States, China and India. Their distinct original interaction/procedure/status questions are retained in their individual rows, including the explicit non-usable reservations. A later source table or search result is not substituted for a missing national conclusion.

All 13 original self-check themes and all five prohibitions remain, with corrected boundaries and additional safeguards. Some themes share a combined candidate checklist row; the actual original topics still have semantic destinations. The full disclaimer is byte-identical. There were no original named-person approval fields, human credits, CTA or calculator-quote lines to drop. Existing jurisdiction, tier, category, domain, name, licence and dependency are unchanged. No person or professional approval was added. The metadata changes are limited to description/current source scope, version 0.1 to 0.2, year 2025 to 2026, actual update date, type and source-check date; the legal/source reviewer owns the truth of the new currentness claims.

`independent-preservation-outcomes.json` records each of the 212 manually assessed parent outcomes and all exact destination hashes. `exact-bindings-and-protections.json` records the independently verified population and protection checks.

## Independent arithmetic result

Both original DE/IE table rows retain every input and output cell. Independent Decimal calculations, separate from the writer's audit and repository example runner, give:

| Case | ETR | Excess profit | Top-up rate | Pre-QDMTT top-up |
| --- | --- | --- | --- | --- |
| DE | 18% | EUR 88,000,000 | 0% | EUR 0 |
| IE | 12.5% | EUR 242,000,000 | 2.5% | EUR 6,050,000 |

All eight results match the candidate table and both new executable blocks. All six original raw inputs are unchanged. The new cases correctly identify supplied valid ordinary positive pools, no safe-harbour election, no additional current top-up and no QDMTT credit; no German/Irish statutory rate or collecting jurisdiction is inferred from their labels.

All 11 SBIE rows independently match a Decimal piecewise schedule: payroll 10%, falling by 0.2 points annually through 2028 and by 0.8 thereafter through 2032; assets 8%, falling by 0.2 through 2028 and by 0.4 thereafter through 2032; both 5% from 2033. The existing actual ordered German table was read narrowly for these cell comparisons. The seven corrected original asset rows are 2025, 2026, 2027, 2028, 2030, 2031 and 2032. The legal reviewer separately confirmed actual Model Article 9.2, base 5% rates, the German calendar-start wording and the different EU Article 48 wording. The candidate preserves the national-period gate; numerical agreement does not erase it.

Independent calendar logic gives 31 December 2024 plus 18 complete calendar months = 30 June 2026; the next ordinary year ending 31 December 2025 plus 15 months = 31 March 2027. A jurisdiction entering its own Transition Year in 2025 has the counterfactual 18-month date 30 June 2027. The candidate explicitly distinguishes that condition from a supposed first-UTPR reset. The Dutch example also recomputes: 18 months gives 30 June 2026 for information filing, 20 months gives 31 August 2026 for domestic filing/payment. Ordinary 15/17-month counterpart calculations are saved only as controls, not new published national guidance. The legal reviewer confirmed jurisdictional Transition Year and ordinary/transition filing periods from the actual Model and EU provisions.

The 28 December 2025 to 2 January 2027 period contains 371 inclusive days, exactly 53 weeks. This arithmetic does not itself establish legal relief eligibility. The US illustration recomputes `21% × (1 − 40%) = 12.6%`; the candidate expressly prevents treating that as a complete US effective rate. UTPR weights sum to 100%. Independent controls for non-negative excess profit, top-up percentage and QDMTT-result floors also pass. `independent-arithmetic.json` contains every result, source-period limit and seven date calculations.

## Finite finding

**C01, copy only, candidate line 317.** The sentence uses the retired labels “source-cited draft” and “professionally attested”. Current `CLAUDE.md` gives only `Approved by [name]` and `Not yet approved`. Preserve the no-professional-approval safeguard using the current `Not yet approved` wording. This does not require changing a tax claim, case input, source-read date or professional metadata. Sent to the coordinator; no candidate edit was made by this reviewer. Ordinary professional review/sign-off obligations elsewhere are not themselves trust labels.

There are no arithmetic or no-loss findings. C01 is a publication-copy correction, so this component's substantive PASS does not imply that its sentence can remain in the final published candidate.

## Reused checks and limits

The exact writer packet records structural `{}`, two cases with zero failures, copy tests passing, strict sync with zero errors and calculator-quote preservation. The first postcommit ordinary validator failed on stale generated-index counts; the existing isolated-cohort `--no-index-check` invocation passed with zero warnings. The coordinator owns final generated-index integration and required CI. Both real results remain in the immutable writer packet. I do not call that initial index failure a clean full-repository validation.

The preserved live row-helper stdout reports 20 eligible rows, zero MISS and zero UNREADABLE. Its process exit status was not recovered by the writer; none is invented here. That narrow helper is not an audit of all legal clauses or numerical tokens. I did not repeat its network scan, the repository suite or completed source research. The current public size gate is 112,640 bytes; this 102,517-byte candidate is below it. A stale 100,000-byte website limit is not applied as a public-repository defect.

No guide, source packet, Git state or protected metadata was changed. This report and independent scripts/results are new local review records. No push, publication, PR mutation, merge, deployment or production/database action occurred.
